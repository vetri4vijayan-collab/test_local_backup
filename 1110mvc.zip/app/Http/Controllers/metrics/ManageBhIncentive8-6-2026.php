<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;

class ManageBhIncentive extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;



    return view('content.metrics.manage_bh_incentive');
  }

  public function fetchIncentive(Request $request)
  {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id') ?? $request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('za_staff.staff_name')
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.role_id', $role_id)
      ->where('za_staff.status', 0)
      ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
      return response()->json([
        'status' => false,
        'message' => 'Staff not found'
      ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
      'status' => true,
      'staff_names' => $staffNames,
      'types' => $types
    ]);
  }


  public function getIncentiveMetrics(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $role_id = $request->role_id;

    $year = $request->year;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    // Generate all dates in the month
    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    // Directly use startDate and endDate for formatting
    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $current = Carbon::create($year, $month, 1);
    // 20 years ago from now
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month

    $query = StaffModel::join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
      ->where('za_staff.branch_id', $branchId);

    // Apply condition properly
    $query->where('za_staff.role_id', $role_id);

    $staffList = $query
      ->where('za_staff.status', 0)
      ->select(
        'za_staff.sno as staff_id',
        'za_staff.staff_name',
        'za_staff.role_id',
        'za_staff.department_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.branch_id',
        'za_branch.branch_name',
        'za_branch.franchise_name',
        'za_branch.cert_auth_sign',
        'za_staff.avaiable_points',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_sub_department.sub_department_id',
        'za_sub_department.sub_department_name',
        'za_department.department_name'
      )
      ->get();

    $departmentIds = $staffList->pluck('department_id')->unique()->toArray();

    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->whereMonth('branch_target.date', $request->month)
      ->whereYear('branch_target.date', $year)
      ->first();

    $result = [];

    foreach ($staffList as $staff) {
      $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $year)
        ->where('status', 0)
        ->first();

      $points = [];
      $calculations = [];

      // 1. 10X Award
      $result10xAward = $this->calculate10xAward($targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['10xaward'] = $result10xAward['value'];
      $calculations['10xaward'] = $result10xAward['calculation'];

      // 2. Ceiling
      $resultCeiling = $this->calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['ceiling'] = $resultCeiling['value'];
      $calculations['ceiling'] = $resultCeiling['calculation'];

      // 3. Quarterly
       $resultQuarterly = $this->calculateQuarterly($targets, $branchId, $incentive, $year, $month);
      $points['quarterly'] = $resultQuarterly['value'];
      $calculations['quarterly'] = $resultQuarterly['calculation'];

      // 4. 25%
      $result25 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 25);
      $points['twenty_five_percentage'] = $result25['value'];
      $calculations['twenty_five_percentage'] = $result25['calculation'];

      // 5. 50%
      $result50 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 50);
      $points['fifty_percentage'] = $result50['value'];
      $calculations['fifty_percentage'] = $result50['calculation'];

      // 6. 6 Month
      $result6Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 6);
      $points['six_month'] = $result6Month['value'];
      $calculations['six_month'] = $result6Month['calculation'];

      // 7. 12 Month
      $result12Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 12);
      $points['twelve_month'] = $result12Month['value'];
      $calculations['twelve_month'] = $result12Month['calculation'];

      // 8. 9 Month Add
      $result9MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 9);
      $points['nine_monthadd'] = $result9MonthAdd['value'];
      $calculations['nine_monthadd'] = $result9MonthAdd['calculation'];

      // 9. 12 Month Add
      $result12MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 12);
      $points['twelve_monthadd'] = $result12MonthAdd['value'];
      $calculations['twelve_monthadd'] = $result12MonthAdd['calculation'];

      // 10. Overall Year
      $resultOverallYear = $this->calculateOverallYear($targets, $branchId, $incentive, $year);
      $points['overall_year'] = $resultOverallYear['value'];
      $calculations['overall_year'] = $resultOverallYear['calculation'];

      // 11. Dynamic
      $resultDynamic = $this->calculateDynamic($staff);
      $points['dynamic'] = $resultDynamic['value'];
      $calculations['dynamic'] = $resultDynamic['calculation'];

      // 12. Presale
      $resultPresale = $this->calculatePresale($targets, $branchId, $incentive, $year);
      $points['presale'] = $resultPresale['value'];
      $calculations['presale'] = $resultPresale['calculation'];

      // 13. Mega Bonus
      $resultMegaBonus = $this->calculateMegaBonus($targets, $branchId, $incentive, $year);
      $points['megabonus'] = $resultMegaBonus['value'];
      $calculations['megabonus'] = $resultMegaBonus['calculation'];

      $result[] = [
        'staff_id'            => $staff->staff_id,
        'staff_name'          => $staff->staff_name,
        'branch_name'         => $staff->branch_name,
        'bh_signature'        => $staff->cert_auth_sign,
        'staff_image'         => $staff->staff_image,
        'role_id'             => $staff->role_id,
        'nick_name'           => $staff->nick_name,
        'sub_department_name' => $staff->sub_department_name,
        'department_name'     => $staff->department_name,
        'incentive_value'     => $points,
        'incentive_cal'       => $calculations,
        'incentive_type' => [  // Specify which incentives are gold-based
          'presale' => 'gold',
          'megabonus' => 'gold',
          'tenxaward' => 'gold',  // if 10X award is also gold
        ]
      ];
    }
    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }

  private function calculate10xAward($targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations'
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    $presaleCount = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    $calculation = [
      'target' => [
        'monthly_target' => $targets->monthly_target ?? 0,
        'registrations' => $targets->no_of_registrations ?? 0
      ],
      'actual' => [
        'total_credit' => $totalCredit,
        'presale_count' => $presaleCount
      ],
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations',
      'condition_met' => ($presaleCount >= ($targets->no_of_registrations ?? 0) && $totalCredit >= ($targets->monthly_target ?? 0))
    ];

    // Main condition
    if (
      $presaleCount >= ($targets->no_of_registrations ?? 0) &&
      $totalCredit >= ($targets->monthly_target ?? 0)
    ) {
      return ['value' => $incentive->tenx_award ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => 0,
      'percentage' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    $target = $targets->monthly_target ?? 0;

    $calculation = [
      'target' => $target,
      'actual' => $totalCredit,
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => max(0, $totalCredit - $target),
      'percentage' => $incentive->ceiling ?? 0
    ];

    // Only if target achieved
    if ($totalCredit > $target) {
      $profit = $totalCredit - $target;
      $percentage = $incentive->ceiling ?? 0;
      $percentageValue = ($profit * $percentage) / 100;
      $calculation['calculated_value'] = $percentageValue;
      return ['value' => $percentageValue, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateQuarterly($targets, $branchId, $incentive, $year, $currentMonth)
  {
    $calculation = [
      'eligible_quarter' => null,
      'months' => [],
      'message' => 'Not eligible'
    ];
 
    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    //  Define quarters
    $quarters = [
      1 => [4, 5, 6],   // Q1
      2 => [7, 8, 9],   // Q2
      3 => [10, 11, 12], // Q3
      4 => [1, 2, 3]    // Q4
    ];
 
    // Map reward month → previous quarter
    $rewardMap = [
      1  => 3,
      2  => 4,
      3  => 4,
      4  => 4,
      5  => 1,
      6  => 1,
      7  => 1,
      8  => 2,
      9  => 2,
      10 => 2,
      11 => 3,
      12 => 3,
    ];
 
    //  If current month is not reward month → no calculation
    if (!isset($rewardMap[$currentMonth])) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    $quarterKey = $rewardMap[$currentMonth];
    $months = $quarters[$quarterKey];
 
    $allAchieved = true;
    $monthData = [];
 
    foreach ($months as $m) {
 
      // Handle year change for Q4 (Jan–Mar belongs to NEXT year logic)
      $loopYear = ($quarterKey == 4) ? $year : $year;
 
      $startDate = Carbon::create($loopYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($loopYear, $m, 1)->endOfMonth();
 
      $totalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');
 
      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $loopYear)
        ->first();
 
      $target = $targetsMonth->monthly_target ?? $targets->monthly_target ?? 0;
 
      $achieved = ($target > 0 && $totalCredit >= $target);
 
      if (!$achieved) {
        $allAchieved = false;
      }
 
      $monthData[] = [
        'month' => $m,
        'month_name' => Carbon::create($loopYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }
 
    $calculation['eligible_quarter'] = "Q{$quarterKey}";
    $calculation['months'] = $monthData;
 
    // FINAL CHECK (strict 3/3)
    if ($allAchieved) {
      return [
        'value' => $incentive->quarterly ?? 0,
        'calculation' => $calculation
      ];
    }
 
    return [
      'value' => 0,
      'calculation' => $calculation
    ];
  }



  
  
  private function calculateMonthBased($targets, $branchId, $incentive, $year, $months)
  {
    $calculation = [
      'target_label' => "{$months} Month Achievement (FY Apr–Mar)",
      'months_achieved' => 0,
      'required_months' => $months,
      'monthly_breakdown' => []
    ];
 
    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    $startMonth = 4; // April
 
    $achievedMonths = 0;
    $monthlyBreakdown = [];
 
    for ($i = 0; $i < 12; $i++) {
 
      $m = (($startMonth + $i - 1) % 12) + 1;
      $fyYear = ($m >= 4) ? $year : $year + 1;
 
      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($fyYear, $m, 1)->endOfMonth();
 
      $totalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');
 
      $target = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first()
        ->monthly_target ?? 0;
 
      $achieved = ($target > 0 && $totalCredit >= $target);
 
      if ($achieved) {
        $achievedMonths++;
      }
 
      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }
 
    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;
 
    if ($achievedMonths >= 12) {
      return [
        'value' => $incentive->twelve_month ?? 0,
        'calculation' => $calculation
      ];
    }
 
    if ($achievedMonths >= 6) {
      return [
        'value' => $incentive->six_month ?? 0,
        'calculation' => $calculation
      ];
    }
 
    return [
      'value' => 0,
      'calculation' => $calculation
    ];
  }
 
  private function calculateMonthAdd($targets, $branchId, $incentive, $year, $months)
  {
    $calculation = [
      'target_label' => "{$months} Month Add-on (FY Apr–Mar)",
      'months_achieved' => 0,
      'monthly_breakdown' => []
    ];
 
    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    $startMonth = 4; // April
    $achievedMonths = 0;
    $monthlyBreakdown = [];
 
    for ($i = 0; $i < 12; $i++) {
 
      $m = (($startMonth + $i - 1) % 12) + 1;
 
      // financial year mapping
      $fyYear = ($m >= 4) ? $year : $year + 1;
 
      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($fyYear, $m, 1)->endOfMonth();
 
      $totalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');
 
      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first();
 
      $target = $targetsMonth->monthly_target ?? 0;
 
      $achieved = ($target > 0 && $totalCredit >= $target);
 
      if ($achieved) {
        $achievedMonths++;
      }
 
      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }
 
    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;
 
    if ($achievedMonths >= 12) {
      return ['value' => $incentive->twelve_monthadd ?? 0, 'calculation' => $calculation];
    }
 
    if ($achievedMonths >= 9) {
      return ['value' => $incentive->nine_monthadd ?? 0, 'calculation' => $calculation];
    }
 
    return ['value' => 0, 'calculation' => $calculation];
  }
  
//   private function calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $percent)
//   {
 
 
//     $calculation = [
//       'target' => 0,
//       'actual' => 0,
//       'unit' => '₹',
//       'target_label' => "{$percent}% Achievement",
//       'achievement_percent' => 0,
//       'applied_slab' => 'below_target'
//     ];
 
//     if (!$targets || !$incentive) {
//       return ['value' => 0, 'calculation' => $calculation];
//     }
 
//     $totalCredit = TransactionModel::where('branch_id', $branchId)
//       ->whereBetween('transaction_date', [$startDate, $endDate])
//       ->sum('credit');
 
//     $target = $targets->monthly_target ?? 0;
 
//     if ($target <= 0) {
//       return ['value' => 0, 'calculation' => $calculation];
//     }
 
//     // $achievementPercent = ($totalCredit / $target) * 100;
//     $achievementPercent = ($target > 0) ? ($totalCredit / $target) * 100 : 0;
 
//     $calculation = [
//       'target' => $target,
//       'actual' => $totalCredit,
//       'unit' => '₹',
//       'target_label' => "{$percent}% Achievement",
//       'achievement_percent' => round($achievementPercent, 2),
//       'profit' => max(0, $totalCredit - $target)
//     ];
 
//     //  BLOCK 25% if 50% slab is already achieved
//     if ($percent == 25 && $achievementPercent >= 50) {
//       return [
//         'value' => 0,
//         'calculation' => [
//           'target' => $target,
//           'actual' => $totalCredit,
//           'unit' => '₹',
//           'target_label' => "25% Achievement (blocked by 50%)",
//           'achievement_percent' => round($achievementPercent, 2),
//           'applied_slab' => 'blocked_by_50_percent'
//         ]
//       ];
//     }
 
//     // Only if target achieved
//     if ($totalCredit > $target) {
//       $profit = $totalCredit - $target;
 
//       // Apply slab logic
//       if ($achievementPercent >= 50) {
//         $percentage = $incentive->fifty_percentage ?? 0;
//         $calculation['applied_slab'] = '50%_slab';
//         $calculation['slab_percentage'] = $percentage;
//       } else {
//         $percentage = $incentive->twenty_five_percentage ?? 0;
//         $calculation['applied_slab'] = '25%_slab';
//         $calculation['slab_percentage'] = $percentage;
//       }
 
//       $percentageValue = ($profit * $percentage) / 100;
//       $calculation['calculated_value'] = $percentageValue;
//       return ['value' => $percentageValue, 'calculation' => $calculation];
//     }
 
//     $calculation['applied_slab'] = 'target_not_achieved';
//     return ['value' => 0, 'calculation' => $calculation];
//   }
  
    private function calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $percent)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => "{$percent}% Achievement",
      'achievement_percent' => 0,
      'applied_slab' => 'no_data'
    ];
 
    //  Missing data
    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    //  Get total credit
    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');
 
    $target = $targets->monthly_target ?? 0;
 
    //  Invalid target
    if ($target <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }
 
    //  Achievement %
    $achievementPercent = ($totalCredit / $target) * 100;
 
    //  Base calculation data
    $calculation = [
      'target' => $target,
      'actual' => $totalCredit,
      'unit' => '₹',
      'target_label' => "{$percent}% Achievement",
      'achievement_percent' => round($achievementPercent, 2),
      'profit' => max(0, $totalCredit - $target),
      'applied_slab' => 'target_not_achieved'
    ];
 
    //  If less than 100%, NOT achieved
    if ($achievementPercent < 100) {
      return [
        'value' => 0,
        'calculation' => $calculation
      ];
    }
 
    //  Profit after achieving target
    $profit = $totalCredit - $target;
 
    $percentage = 0;
 
    //  Slab logic (FIXED)
    if ($achievementPercent >= 150) {
      // 150% and above
      $percentage = $incentive->fifty_percentage ?? 0;
 
      $calculation['applied_slab'] = '150%_slab';
      $calculation['slab_percentage'] = $percentage;
    } elseif ($achievementPercent >= 100) {
      // 100% to 149%
      $percentage = $incentive->twenty_five_percentage ?? 0;
 
      $calculation['applied_slab'] = '100%_slab';
      $calculation['slab_percentage'] = $percentage;
    }
 
    //  Final incentive calculation
    $percentageValue = ($profit * $percentage) / 100;
 
    $calculation['calculated_value'] = $percentageValue;
 
    return [
      'value' => $percentageValue,
      'calculation' => $calculation
    ];
  }

  private function calculateOverallYear($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // Year start & end
    $startDate = Carbon::create($year, 1, 1)->startOfYear();
    $endDate   = Carbon::create($year, 12, 31)->endOfYear();

    // Total yearly credit
    $yearTotal = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    // Year target (monthly × 12)
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => $yearTarget,
      'actual' => $yearTotal,
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // Condition: 150% or more
    if ($achievementPercent >= 150) {
      return ['value' => $incentive->overall_year ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateDynamic($staff)
  {
    return ['value' => 0, 'calculation' => ['message' => 'Dynamic logic pending']];
  }

  private function calculatePresale($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => 0,
      'actual' => 0,
      'unit' => 'registrations',
      'achievement_percent' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // Total yearly presale count
    $yearCount = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->count();

    // Year target (monthly registrations × 12)
    $yearTarget = ($targets->no_of_registrations ?? 0) * 12;

    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => $yearTarget,
      'actual' => $yearCount,
      'unit' => 'registrations',
      'achievement_percent' => $yearTarget > 0 ? round(($yearCount / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearCount / $yearTarget) * 100;

    // Condition: 150% or more
    if ($achievementPercent >= 150) {
      return ['value' => $incentive->presale ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateMegaBonus($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // Year range
    $startDate = Carbon::create($year, 1, 1)->startOfYear();
    $endDate   = Carbon::create($year, 12, 31)->endOfYear();

    // Total yearly credit
    $yearTotal = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    // Year target
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => $yearTarget,
      'actual' => $yearTotal,
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // 200% condition (DOUBLE target)
    if ($achievementPercent >= 200) {
      return ['value' => $incentive->megabonus ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }
}
