<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoldenRuleModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\TrainingModel;
use App\Models\PaymentModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\CustomerModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
class ManageGoldenRules extends Controller
{
  public function index()
  {
    return view('content.metrics.manage_golden_rules');
  }
 public function GoldenRules(Request $request)
  {
      $branch_id = $request->user()->branch_id;

      if (is_numeric($request->month)) {
          $monthNumber = str_pad($request->month, 2, '0', STR_PAD_LEFT);
      } else {
          $monthNumber = date('m', strtotime("1 " . $request->month));
      }

         $targetDate = $request->year . '-' . $monthNumber . '-01';
        // Previous month date
        $prevMonthDate = Carbon::parse($targetDate)->subMonth()->format('Y-m-01');

          // Get monthly target for the branch
          $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                  ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                  ->where('branch_target.date', $targetDate)
                  ->select('branch_target.*')
                  ->first();
          if (!$targets) {
              return response()->json([
                  'status' => 404,
                  'message' => 'No data found — need to set target for this month.',
                  'data' => []
              ]);
          }

                //   return $targets;

          // Get branch info
          $branch = BranchModel::where('sno', $branch_id)
                      ->where('status', 0)
                  ->orderBy('sno', 'desc')
                  ->first();

          // Fetch latest golden rule record with actual values
          $goldenData = GoldenRuleModel::orderBy('sno', 'desc')->first();
            // rule 1
                $totalSumAll = TransactionModel::where('branch_id', $branch_id)->whereYear('transaction_date', $request->year)
                    ->whereMonth('transaction_date', $monthNumber)->sum('credit');

                $currentMonthCustomerTotal = CustomerModel::select('za_customer.course_id', 'za_customer.sno') ->whereIn('za_customer.status',[0,6])
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->whereIn('za_customer.status',[0,6])
                    ->whereYear('za_customer.created_at', $request->year)
                    ->whereMonth('za_customer.created_at', $monthNumber)
                    ->get();
                $customerConvertCountTotal= count($currentMonthCustomerTotal);
                $currentMonthCustomerPre = CustomerModel::select('za_customer.course_id', 'za_customer.sno','za_training.sno As training_id') ->whereIn('za_customer.status',[0,6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->whereIn('za_customer.status',[0,6])
                    ->whereYear('za_customer.created_at', $request->year)
                    ->whereMonth('za_customer.created_at', $monthNumber)
                    ->get();


                // Get all customer_ids as an array
                $customerIds = $currentMonthCustomerPre->pluck('training_id');

                // Use whereIn for transaction sum
                $totalSumPre = TransactionModel::where('branch_id', $branch_id)->whereIn('training_id', $customerIds)
                ->whereYear('transaction_date', $request->year)
                    ->whereMonth('transaction_date', $monthNumber)->sum('credit');

                if ($totalSumAll > 0) {
                    $preSalePercentage = ($totalSumPre / $totalSumAll) * 100;
                } else {
                    $preSalePercentage = 0; // avoid division by zero
                }

                $customerConvertCount= count($currentMonthCustomerPre);

                $currentMonthCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno','za_training.sno As training_id') ->whereIn('za_customer.status',[0,6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_customer.post_sale_check', 1)
                    ->where('za_training.post_sale_check', 1)
                    ->whereIn('za_customer.status',[0,6])
                    ->whereYear('za_training.created_at', $request->year)
                    ->whereMonth('za_training.created_at', $monthNumber)
                    ->get();


                    // Get all customer_ids as an array
                $customerIdsPost = $currentMonthCustomerPost->pluck('training_id');

                // Use whereIn for transaction sum
                $totalSumPost = TransactionModel::where('branch_id', $branch_id)->whereIn('training_id', $customerIdsPost)
                ->whereYear('transaction_date', $request->year)
                    ->whereMonth('transaction_date', $monthNumber)->sum('credit');

                if ($totalSumAll > 0) {
                    $postSalePercentage = ($totalSumPost / $totalSumAll) * 100;
                } else {
                    $postSalePercentage = 0; // avoid division by zero
                }
                //   return $currentMonthCustomerPost;
                $customerConvertCountPost= count($currentMonthCustomerPost);

                //closing find
                $totalSumClosing = $totalSumAll - ($totalSumPre + $totalSumPost);
                if ($totalSumAll > 0) {
                   $closingSalePercentage = ($totalSumClosing / $totalSumAll) * 100;
                } else {
                     $closingSalePercentage  = 0;
                }

               // Round for display
                $PrePercentage     = round($preSalePercentage);
                $PostPercentage    = round($postSalePercentage);
                $closingPercentage = round($closingSalePercentage); // force adjust

                // Determine status
                $statusrulePre = ($PrePercentage >= ($goldenData->pre_sale ?? 0) && $PostPercentage >= ($goldenData->post_sale ?? 0) && $closingPercentage >= ($goldenData->closing_sale ?? 0))
                  ? 'Completed'
                  : 'Failed';
               // rule 2

                $total_payment             = 0;
                $total_paid_payment        = 0;
                if ($currentMonthCustomerPre->isNotEmpty()) {

                      foreach ($currentMonthCustomerPre as $customer) {

                        $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                      ->where('za_training.customer_id', $customer->sno)
                                      ->where('za_training.tesbo_check', 0)
                                      ->sum('za_training.overall_fees');

                        $total_payment += $payment;


                        $latestTraining = DB::table('za_training')
                            ->where('customer_id', $customer->sno)
                            ->where('tesbo_check', 2)
                            ->orderByDesc('sno')
                            ->first();

                        if ($latestTraining) {
                            $total_payment += $latestTraining->overall_fees;
                        }

                        $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                          ->where('za_training.customer_id', $customer->sno)
                                          ->sum('za_training.paid_amount');

                        $total_paid_payment += $paid_payment;

                      }
                  }


                // average
                $averageBusinessValuePre   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValuePre = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;

            // Determine status
            $statusCusPre = ($averageBusinessValuePre >= ($goldenData->pre_abv ?? 0) && $averageCollectionValuePre >= ($goldenData->pre_acv ?? 0))
              ? 'Completed'
              : 'Failed';
              $total_payment_post=0;
              $total_paid_payment_post=0;
                if ($currentMonthCustomerPost->isNotEmpty()) {
                      foreach ($currentMonthCustomerPost as $customer) {

                        $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                      ->where('za_training.customer_id', $customer->sno)
                                      ->where('za_training.tesbo_check', 0)
                                      ->where('za_training.post_sale_check', 1)
                                      ->sum('za_training.overall_fees');

                        $total_payment_post += $payment;


                        $latestTraining = DB::table('za_training')
                            ->where('customer_id', $customer->sno)
                            ->where('tesbo_check', 2)
                            ->where('post_sale_check', 1)
                            ->orderByDesc('sno')
                            ->first();

                        if ($latestTraining) {
                            $total_payment_post += $latestTraining->overall_fees;
                        }

                        $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                          ->where('za_training.customer_id', $customer->sno)
                                          ->where('za_training.post_sale_check', 1)
                                          ->sum('za_training.paid_amount');

                        $total_paid_payment_post += $paid_payment;

                      }
                  }


                // average

                $averageBusinessValuePost   = $customerConvertCountPost > 0 ? $total_payment_post / $customerConvertCountPost : 0;
                $averageCollectionValuePost = $customerConvertCountPost > 0 ? $total_paid_payment_post / $customerConvertCountPost : 0;
            // Determine status

              $statusCusPost = ($averageBusinessValuePost >= ($goldenData->post_abv ?? 0) && $averageCollectionValuePost >= ($goldenData->post_acv ?? 0))
                ? 'Completed'
                : 'Failed';
            // rule 3
            $drop_customer_ids = DB::table('za_drop_refund')
                ->where('za_drop_refund.branch_id', $branch_id)
                ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
                ->where('za_drop_refund.bh_status', 1)
                ->pluck('za_training.payment_id')
                ->toArray();

            // get first day of NEXT month
            $nextMonthStart = Carbon::now()->addMonthNoOverflow()->startOfMonth()->toDateString();

            // now get only payments where nextPayDate is strictly in future months
            $totalAmount = PaymentModel::where('branch_id', $branch_id)
                    ->where('status', 0)
                    // ->whereDate('nextPayDate', '>=', $nextMonthStart)
                    ->when(!empty($drop_customer_ids), function ($q) use ($drop_customer_ids) {
                        $q->whereNotIn('sno', $drop_customer_ids);
                    })
                    ->sum('amount');

                // return $totalAmount;

                $pre_sale_value = $goldenData->pre_sale_value ?? 0;
                $target_value = $goldenData->target_value ?? 0;

                  $outstandingAmountTarget = $pre_sale_value *  $totalSumPre;
                  $outstandingAmountActual =  $totalAmount;


                  $targetValueTarget   =  $target_value * $targets->monthly_target ?? 0;
                  $targetValueActual   =  $totalAmount;

                  $statusOutstanding = ($outstandingAmountActual >= ($outstandingAmountTarget ?? 0) || $targetValueActual <= ($targetValueTarget ?? 0))
                ? 'Completed'
                : 'Failed';
                //   return $targetValueTarget;
            //rule 4 staff ration
            $targetSalesStaff = $goldenData->sales_staff_ration ?? 0;

            $targetTotal = $targets->monthly_target ?? 0;
            $miniProduct = $branch->min_prd_cost ?? 1; // avoid divide by zero

            // 80% of target
            $targetTotal80 = ($targetTotal * 80) / 100;

            // SalesPerson count
            $SalesDiv = $targetTotal80 / $miniProduct;

            $SalesPersonCount  =  $SalesDiv / $targetSalesStaff;

             $salesStaffCount = StaffModel::where('branch_id', $branch_id)
                  ->where('status', 0) // active
                  ->where('department_id', 1) // sales
                  ->get(); // get staff ids

            $salesStaffActualCount=  count($salesStaffCount);
             $statusSales = ($salesStaffActualCount >= $SalesPersonCount) ? 'Completed' : 'Failed';



            //production staff count
            $targetProduction = $goldenData->production_staff_ration ?? 0;
            $monthStart = \Carbon\Carbon::create($request->year, $monthNumber, 1)->startOfMonth();
            $monthEnd = \Carbon\Carbon::create($request->year, $monthNumber, 1)->endOfMonth();

             $customersTotal = CustomerModel::where('za_customer.branch_id', $branch_id)
                  ->where('za_customer.status',0)
                  ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
                  ->where('za_training.status', 0)
                  ->whereDate('za_training.start_date', '<=', $monthEnd)   // training started before month ends
                  ->whereDate('za_training.end_date', '>=', \Carbon\Carbon::today())
                  ->select('za_training.training_id')   // training ended after month starts
                  ->groupBy('za_training.training_id')
                  ->get();
            //  return count($customersTotal);
            $productionStaff = StaffModel::where('branch_id', $branch_id)
                  ->where('status', 0) // active
                  ->where('department_id', 2) // production
                   ->get(); // staff IDs

            $productionStaffActualCount=  count($productionStaff);


            $productionPersonCount = count($customersTotal) / $targetProduction;

            $productionStaffActualCount = (int) $productionStaffActualCount;
            $productionPersonCount      = (int) $productionPersonCount;

            $statusProduction = ($productionStaffActualCount >= $productionPersonCount)
                ? 'Completed'
                : 'Failed';

            // cre staff ration
            $targetCRE = $goldenData->cre_ration ?? 0;

            $tragetCREStaffDiv = count($customersTotal) / $targetCRE;

            $tragetCREStaffDiv  = round($tragetCREStaffDiv);

            $CreStaffActualCount = StaffModel::where('branch_id', $branch_id)
                    ->where('status', 0) // active
                    ->where('department_id', 5) // production
                    ->count(); // staff IDs

            $statusCre = ($CreStaffActualCount >= ($tragetCREStaffDiv ?? 0) )
                  ? 'Completed'
                  : 'Failed';

            // Pc staff ration
            $targetPC = $goldenData->pc_ration ?? 0;
            $PcStaffActualCount = StaffModel::where('branch_id', $branch_id)
                    ->where('status', 0) // active
                    ->where('department_id', 6) // production
                    ->count(); // staff IDs

            $targetStaffPCCount = $productionStaffActualCount / $targetPC;

            $statusPC = ($PcStaffActualCount >= (round($targetStaffPCCount ?? 0)) )
                  ? 'Completed'
                  : 'Failed';


            //rule 5 drop and customer ration
              $totalLead = LeadModel::where('branch_id', $branch_id)
                                ->whereNotIn('status',[2,6])
                                ->whereYear('registered_date', $request->year)
                                ->whereMonth('registered_date', $monthNumber)
                                ->where('spam_verified',0)
                                ->where('drop_verified', 0)
                                ->where('internal_status',0)
                                ->count();

              $dropCustomerCount = DB::table('za_drop_refund')->where('za_drop_refund.branch_id', $branch_id)
                        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
                        ->where('za_drop_refund.bh_status', 1)
                        ->whereYear('za_drop_refund.bh_status_date', $request->year)
                        ->whereMonth('za_drop_refund.bh_status_date', $monthNumber)
                        ->count();
                        // return $totalLead;
              $customerPercentage = $totalLead > 0
                ? round(($customerConvertCountTotal / $totalLead) * 100)
                : 0;
              $dropPercentage = $customerConvertCountTotal > 0
                ? round(($dropCustomerCount / $customerConvertCountTotal) * 100)
                : 0;

              // Determine status
              $statusCusDrp = ($customerPercentage >= ($goldenData->converation_rate ?? 0) && $dropPercentage >= ($goldenData->drop_rate ?? 0))
                ? 'Completed'
                : 'Failed';
             //rule 6 lead
              $postSaleActual = count($currentMonthCustomerPost);

              $TargetpotentialLead =  $goldenData->potential_lead ?? 0;
              $targetGolden        =    $TargetpotentialLead *  $targets->no_of_registrations;
               $potentialLead     =   $TargetpotentialLead * $customerConvertCountTotal + $postSaleActual;
            //   return $targetGolden;
               $statuspotential = ($potentialLead >= $targetGolden)
                ? 'Completed'
                : 'Failed';

            //rule 7 growth rate check
                // Target growth_ratecheck privous month increas or decrease

                   // Get previous month target
                    // $oldMonthTarget = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    //     ->where('branch_target.branch_id', $branch_id)
                    //     ->where('branch_target.date', $prevMonthDate)
                    //     ->select('branch_target.*')
                    //     ->first();

                    // $currentMonthTarget = $targets->monthly_target ?? 0;
                    // $previousMonthTarget = $oldMonthTarget->monthly_target ?? 0;
                    // // return $currentMonthTarget;
                    // // Expected growth rate percentage (e.g., 5 means 5%)


                    // // Calculate actual growth rate
                    // if ($previousMonthTarget > 0) {
                    //     $actualGrowthRate = (($currentMonthTarget - $previousMonthTarget) / $previousMonthTarget) * 100;
                    // } else {
                    //     $actualGrowthRate = 0;
                    // }

                   $prevMonth = Carbon::parse($targetDate)->subMonth();

                   $oldMonthTarget = TransactionModel::where('branch_id', $branch_id)
                                      ->whereYear('transaction_date', $prevMonth->year)
                                      ->whereMonth('transaction_date', $prevMonth->month)
                                      ->sum('credit');
                    $growthRateTarget = $goldenData->growth_rate ?? 0;
                    $currentMonthTarget = $totalSumAll ?? 0;
                    $previousMonthTarget = $oldMonthTarget ?? 0;
                    if ($currentMonthTarget > 0) {
                        $actualGrowthRate = (($currentMonthTarget - $previousMonthTarget) / $previousMonthTarget) * 100;
                    } else {
                        $actualGrowthRate = 0;
                    }
                    if ($actualGrowthRate > 0) {
                        $actualGrowthRate;
                    } else {
                        $actualGrowthRate = 0;
                    }
                    // return $previousMonthTarget;
                    // Status check
                    $statusRate = $actualGrowthRate >= $growthRateTarget ? 'Completed' : 'Failed';

            //rule 8

             // Date range calculation
                $startDate = Carbon::create( $request->year, $monthNumber, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year ==  $request->year && $currentDate->month == $monthNumber)
                            ? $currentDate
                            : $startDate->copy()->endOfMonth();
                $dayCount = $startDate->diffInDays($endDate) + 1;
                 $year= $request->year;

           $salesStaff = DB::table('za_staff')
              ->select(
                'za_staff.sno',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.gender',
                'za_staff.mobile_no',
                'za_staff.lead_bank_count',
                'za_staff.status as staff_status',
                'za_cug_management.staff_mobile as cug_mobile','za_department.department_name','za_department.sno as dept_id','za_job_position.job_position_name'
            )
             ->join('za_cug_management','za_staff.sno', '=', 'za_cug_management.staff_id')
             ->join('za_department','za_staff.department_id', '=', 'za_department.sno')
             ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id)
             ->where('za_cug_management.status', 0)
             ->Where('za_staff.status', 0);
            // ->where(function($query) use ($year, $monthNumber) {
            //     // Add conditions for status 4
            //     $query->where(function($query) use ($year, $monthNumber) {
            //             $query->where('za_staff.status', 4)
            //                 ->whereYear('za_staff.notice_end_date', '>=', $year)
            //                 ->whereMonth('za_staff.notice_end_date', '>=', $monthNumber);
            //         })
            //         // Add conditions for status 5
            //         ->orWhere(function($query) use ($year, $monthNumber) {
            //             $query->where('za_staff.status', 5)
            //                 ->whereYear('za_staff.updated_at', '>=', $year)
            //                 ->whereMonth('za_staff.updated_at', '>=', $monthNumber);
            //         })
            //         // Add conditions for status 6
            //         ->orWhere(function($query) use ($year, $monthNumber) {
            //             $query->where('za_staff.status', 6)
            //                 ->whereYear('za_staff.staff_last_date', '>=', $year)
            //                 ->whereMonth('za_staff.staff_last_date', '>=', $monthNumber);
            //         })
            //         // Add conditions for status 7
            //         ->orWhere(function($query) use ($year, $monthNumber) {
            //             $query->where('za_staff.status', 7)
            //                 ->whereYear('za_staff.updated_at', '>=', $year)
            //                 ->whereMonth('za_staff.updated_at', '>=', $monthNumber);
            //         })
            //         // Include status 0 regardless of date
            //         ->orWhere('za_staff.status', 0);
            // });



            $salesStaff = $salesStaff->orderBy('sno', 'desc')->count();
            // Fetch all call stats in ONE query to prevent N+1 queries
            $callData = DB::table('za_call_tracker')
                ->select(
                    DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count")
                )
                ->join('za_staff','za_staff.sno','=','za_call_tracker.branch_staff_id')
                ->where('za_staff.department_id', 1)
                ->where('za_staff.branch_id', $branch_id)
                ->whereYear('call_start_date', $request->year)
                ->whereMonth('call_start_date', $monthNumber)
                ->first(); // Use first() to get a single object

            $outgoingcall = $callData ? $callData->outgoingcall_count : 0;
             $outgoingcallrate = $dayCount > 0 ? round($outgoingcall / ($dayCount * $salesStaff)) : 0;
            //  return $outgoingcallrate;
              $statusCallRate = ($outgoingcallrate >= ($goldenData->outgoing_call_average ?? 0))
                ? 'Completed'
                : 'Failed';
            // return $outgoingcallrate;
            //rule 9
            // Get staff attendance for current month
            $StaffAttendance = StaffAttendanceModel::where('branch_id', $branch_id)
                                ->whereYear('date', $request->year)
                                ->whereMonth('date', $monthNumber)
                                ->get();

            // Total working days in month (assuming 'A' = Absent, 'L' = Leave, 'P' = Present)
            $totalDays = $StaffAttendance->count();
            $absentLeaveDays = $StaffAttendance->whereIn('attendace', ['A', 'L'])->count();

            $attendancePercentage = $totalDays > 0
                ? round((($totalDays - $absentLeaveDays) / $totalDays) * 100, 2)
                : 0;

            // Determine status
            $statusAtt = ($attendancePercentage >= ($goldenData->overall_leave_rate ?? 0))
                ? 'Completed'
                : 'Failed';
            //rule 10

              $currentMonth = Carbon::parse($targetDate); // Let's say current is October 2024

              $quarterStart = $currentMonth->copy()->subMonths(3)->startOfMonth(); // July 1, 2024
              $quarterEnd = $currentMonth->copy()->subMonths(1)->endOfMonth();     // September 30, 2024

              $quarterlySum = TransactionModel::where('branch_id', $branch_id)
                  ->whereBetween('transaction_date', [$quarterStart, $quarterEnd])
                  ->sum('credit');

              $quarterlyAverage = $quarterlySum / 3;

              $growthRateTarget = $goldenData->improvement ?? 0;
              $currentMonthTarget = $oldMonthTarget ?? 0;;
              $previousQuarterAverage = $quarterlyAverage;
              // return $previousQuarterAverage;
              if ($growthRateTarget > 0) {
                  $actualGrowthRatequarterly = (($currentMonthTarget - $previousQuarterAverage) / $previousQuarterAverage) * 100;
              } else {
                  $actualGrowthRatequarterly = 0;
              }
              if($actualGrowthRatequarterly > 0){
                  $actualGrowthRatequarterly;
              }else{
                $actualGrowthRatequarterly = 0;
              }
              // return $actualGrowthRatequarterly;
            // Manually separate into 10 rules
            $rulesResponse = [
                [
                    'id' => 1,
                    'name' => 'Sales Target',
                    'type' => 'type1', // 1st UI style (Post/Pre/Closing)
                    'target' => [
                          'Pre' => rtrim(rtrim(number_format($goldenData->pre_sale ?? 0, 2, '.', ''), '0'), '.') . '%',
                          'Post' => rtrim(rtrim(number_format($goldenData->post_sale ?? 0, 2, '.', ''), '0'), '.') . '%',
                          'Closing' => rtrim(rtrim(number_format($goldenData->closing_sale ?? 0, 2, '.', ''), '0'), '.') . '%',
                      ],
                    'actual' => [
                        'Pre' => rtrim(rtrim(number_format($PrePercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                        'Post' => rtrim(rtrim(number_format($PostPercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                        'Closing' => rtrim(rtrim(number_format($closingPercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],
                    'status' => $statusrulePre,
                ],
                [
                    'id' => 2,
                    'name' => 'Sales ABV / ACV.',
                    'type' => 'type4', // 4th UI style
                    'sub_targets' => [
                        'i.Pre Sale' => [
                            'ABV' => number_format($goldenData->pre_abv ?? 0, 0, '.', ','),
                            'ACV' => number_format($goldenData->pre_acv ?? 0, 0, '.', ','),
                        ],
                        'ii.Post Sale' => [
                            'ABV' => number_format($goldenData->post_abv ?? 0, 0, '.', ','),
                            'ACV' => number_format($goldenData->post_acv ?? 0, 0, '.', ','),
                        ],
                    ],
                    'sub_actuals' => [
                        'i.Pre Sale' => [
                            'ABV' => number_format($averageBusinessValuePre ?? 0, 0, '.', ','),
                            'ACV' => number_format($averageCollectionValuePre ?? 0, 0, '.', ','),
                        ],
                        'ii.Post Sale' => [
                            'ABV' => number_format($averageBusinessValuePost ?? 0, 0, '.', ','),
                            'ACV' => number_format($averageCollectionValuePost ?? 0, 0, '.', ','),
                        ],
                    ],
                  'sub_status' => [
                        'i.Pre Sale' => $statusCusPre,   // Pre status logic
                        'ii.Post Sale' => $statusCusPost // Post status logic
                    ]
                ],
                [
                    'id' => 3,
                    'name' => 'Outstanding Amount.',
                    'type' => 'type1', // 1st UI style (Post/Pre/Closing)
                    'target' => [
                        'Pre Sale value' => number_format($outstandingAmountTarget ?? 0, 0, '.', ','),
                        'Target value' => number_format($targetValueTarget ?? 0, 0, '.', ','),
                    ],
                    'actual' => [
                        'Pre Sale value' => number_format($outstandingAmountActual ?? 0, 0, '.', ','),
                        'Target value' => number_format($targetValueActual ?? 0, 0, '.', ','),
                    ],
                    'status' => $statusOutstanding,
                ],
                [
                    'id' => 4,
                    'name' => 'Staff Ratio',
                    'type' => 'type4', // 4nd UI style (multiple sub-items)
                    'sub_targets' => [
                        'i.Sales Person' => [
                            '' => round($SalesPersonCount ??0),
                        ],
                        'ii.Production Person' => [
                            '' => round($productionPersonCount ?? 0),
                        ],
                         'iii.CRE Person' => [
                            '' => $tragetCREStaffDiv ?? 0,
                        ],
                        'iv.PC Person' => [
                            '' => round($targetStaffPCCount) ?? 0,
                        ],
                    ],
                  'sub_actuals' => [
                        'i.Sales Person' => [
                            '' => round($salesStaffActualCount ?? 0),
                        ],
                        'ii.Production Person' => [
                            '' => round($productionStaffActualCount ?? 0),
                        ],
                        'iii.CRE Person' => [
                            '' => round($CreStaffActualCount ?? 0),
                        ],
                        'iv.PC Person' => [
                            '' => round($PcStaffActualCount ?? 0),
                        ],
                      ],

                    'sub_status' => [
                        'i.Sales Person' => $statusSales,   // Pre status logic
                        'ii.Production Person' => $statusProduction, // Post status logic
                        'iii.CRE Person' => $statusCre, // Post status logic
                        'iv.PC Person' => $statusPC // Post status logic
                    ]
                ],
                [
                    'id' => 5,
                    'name' => 'Conversion / Drop Rate.',
                    'type' => 'type1', // 1st UI style (Post/Pre/Closing)
                    'target' => [
                        'Converation Rate' => rtrim(rtrim(number_format($goldenData->converation_rate ?? 0, 2, '.', ''), '0'), '.') . '%',
                        'Drop Rate' => rtrim(rtrim(number_format($goldenData->drop_rate ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],
                    'actual' => [
                        'Converation Rate' => rtrim(rtrim(number_format($customerPercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                        'Drop Rate' =>  rtrim(rtrim(number_format($dropPercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],

                    'status' => 'Failed',
                ],
                [
                    'id' => 6,
                    'name' => 'Potential Lead Pre-Sale.',
                    'type' => 'type3', // 3rd UI style (single metric)
                    'target' => [
                        'Potential Lead' => $targetGolden,
                    ],
                    'actual' => [
                        'Potential Lead' => $potentialLead,
                    ],
                    'status' => $statuspotential,
                ],
                [
                    'id' => 7,
                    'name' => 'Growth Rate (%).',
                    'type' => 'type3', // 3rd UI style (single metric)
                      'target' => [
                          'Growth Rate' => rtrim(rtrim(number_format($goldenData->growth_rate ?? 0, 2, '.', ''), '0'), '.') . '%',
                      ],
                      'actual' => [
                          'Growth Rate' => sprintf("%02d", round($actualGrowthRate)). '%',
                      ],
                    'status' => $statusRate,
                ],
                [
                    'id' => 8,
                    'name' => 'Call Rate',
                    'type' => 'type3', // 3rd UI style (single metric)
                    'target' => [
                        'Avg Call' => rtrim(rtrim(number_format($goldenData->outgoing_call_average ?? 0, 2, '.', ''), '0'), '.'),
                    ],
                    'actual' => [
                        'Avg Call' => $outgoingcallrate,
                    ],
                    'status' => $statusCallRate,
                ],
                [
                    'id' => 9,
                    'name' => 'Overall Leave (Below %).',
                    'type' => 'type3',
                    'target' => [
                        'Overall Leave Rate' => rtrim(rtrim(number_format($goldenData->overall_leave_rate ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],
                    'actual' => [
                        'Overall Leave Rate' => rtrim(rtrim(number_format($attendancePercentage ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],
                    'status' => $statusAtt,
                ],
                [
                    'id' => 10,
                    'name' => 'Improvement Rate (Above %).',
                    'type' => 'type3', // 3rd UI style (single metric)
                    'target' => [
                        'Improvement' => rtrim(rtrim(number_format($goldenData->improvement ?? 0, 2, '.', ''), '0'), '.') . '%',
                    ],
                    'actual' => [
                        'Improvement' => sprintf("%02d", round($actualGrowthRatequarterly)) . '%',
                    ],
                    'status' => 'Failed',
                ],
            ];

            return response()->json([
                'status'          => 200,
                'data'            => $rulesResponse,
                'monthly_target'  => $targets->monthly_target ?? 0,
                'mpc_value'       => $branch->min_prd_cost ?? 0,
            ]);
  }


}
