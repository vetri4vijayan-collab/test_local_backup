<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use App\Models\PaymentModel;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Collection;
class OverallOutstanding extends Controller
{
  public function index()
  {
    return view('content.metrics.overall_outstanding.outstanding_list');
  }

public function overallOutstanding(Request $request)
{
    $branch_id = $request->user()->branch_id;

    // Get dropped customer IDs
    $drop_customer_ids = DB::table('za_drop_refund')->where('za_drop_refund.branch_id', $branch_id)
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->pluck('za_training.payment_id')
        ->toArray();
        // here drop condtion is tesbo means we need to get all

    $customers = CustomerModel::where('branch_id', $branch_id)->where('status', 0)
         ->with(['payments' => function($q) {
                $q->orderBy('sno', 'asc'); // ensure payments are in order
            }])
        ->get();

    $branchCost = BranchModel::where('sno', $branch_id)->where('status', 0)
        ->pluck('min_prd_cost')->first() ?? 0;

    $overallStandings = [];
    $grandTotal = 0.0;

    foreach ($customers as $customer) {
        $customerCumulative = 0.0;
        $reachedThreshold = false; // Track if we've exceeded branch cost

        foreach ($customer->payments as $payment) {
            // Skip inactive or negative payments
            if ((int)$payment->status === 2 || $payment->amount < 0 || $payment->paidAmount < 0) {
                continue;
            }

            $isDropped = in_array($payment->payment_id, $drop_customer_ids, true);

            // For paid payments, update cumulative first
            if ((int)$payment->status === 1) {
                $customerCumulative += (float)$payment->paidAmount;

                // Check if we should skip this paid payment
                if (!$reachedThreshold && $customerCumulative <= $branchCost) {
                    // Skip this payment because cumulative hasn't exceeded branch cost yet
                    continue;
                }

                // If we reach here, it means we've exceeded the threshold
                if (!$reachedThreshold && $customerCumulative > $branchCost) {
                    $reachedThreshold = true;
                }
            }

            // For unpaid payments, always include them (they don't affect cumulative)
            // OR for paid payments after reaching threshold

            // Determine month and amount
            if ((int)$payment->status === 0) {
                $month = \Carbon\Carbon::parse($payment->nextPayDate)->format('Y-m');
                $amount = (float)$payment->amount;
                $bg = '#ffcccc';
            } else {
                $month = \Carbon\Carbon::parse($payment->initialPayDate)->format('Y-m');
                $amount = (float)$payment->paidAmount;
                $bg = '#ccffcc';
            }
            // i want to send this also in actail not affecting any other,  the name is target

                $targetMonth = null;
                $targetAmount = null;

                if ((int)$payment->status === 1) {
                    $targetMonth  = \Carbon\Carbon::parse($payment->nextPayDate)->format('Y-m');
                    $targetAmount = (float)$payment->amount;
                }

                if ((int)$payment->status === 0) {
                    $targetMonth  = \Carbon\Carbon::parse($payment->nextPayDate)->format('Y-m');
                    $targetAmount = (float)$payment->amount;
                }

            // Ensure month exists before adding amounts
            if (!isset($overallStandings[$month])) {
                $overallStandings[$month] = ['month_total' => 0.0, 'rows' => []];
            }

            if (!$isDropped) {
                $overallStandings[$month]['month_total'] += $amount;
                if ((int)$payment->status === 0) {
                    $grandTotal += $amount; // only unpaid
                }
            }

            if ($isDropped) {
                $bg = '#9b9999b3';
            }

            $courseTypeName = $payment->course?->courseType?->course_type_name ?? null;
            $overallStandings[$month]['rows'][] = [
                'name'       => $customer->cus_name,
                'customerId' => $customer->customer_id,
                'courseType' => $courseTypeName,
                'amount'     => $amount,
                'bg'         => $bg,
                'payment_id' => $payment->payment_id,
                'status'     => $payment->status,
                'cumulative' => $customerCumulative,
                'reachedThreshold' => $reachedThreshold,
                'target' => [
                      'month'  => $targetMonth,
                      'amount' => $targetAmount
                  ]
            ];
        }
    }

    return response()->json([
        'status'                   => 200,
        'data'                     => $overallStandings,
        'grand_total_outstanding'  => $grandTotal,
        'branch_cost'              => $branchCost
    ]);
}





}
