<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoldenRuleModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\TrainingModel;
use App\Models\PaymentModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\CustomerModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
class ForecastMetrics extends Controller
{
  public function index()
  {
    return view('content.metrics.manage_forecast_metrics');
  }


public function getForecastMetrics(Request $request)
{
    $branch_id = $request->user()->branch_id;

    // Handle month input
    if (is_numeric($request->month)) {
        $monthNumber = str_pad($request->month, 2, '0', STR_PAD_LEFT);
    } else {
        $monthNumber = date('m', strtotime("1 " . $request->month));
    }

    $targetDate = $request->year . '-' . $monthNumber . '-01';

    // Get monthly target for the branch
    $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->where('branch_target.date', $targetDate)
        ->select('branch_target.*')
        ->first();

    // Actual collected so far
    $totalSumAll = TransactionModel::where('branch_id', $branch_id)
        ->whereYear('transaction_date', $request->year)
        ->whereMonth('transaction_date', $monthNumber)
        ->sum('credit');

    // Post-sale & pre-sale actuals
    $postSaleActual = CustomerModel::whereIn('status', [0, 6])
        ->where('post_sale_check', 1)
        ->where('branch_id', $branch_id)
        ->whereYear('created_at', $request->year)
        ->whereMonth('created_at', $monthNumber)
        ->count();

    $preSaleActual = CustomerModel::whereIn('status', [0, 6])
        ->where('branch_id', $branch_id)
        ->whereYear('created_at', $request->year)
        ->whereMonth('created_at', $monthNumber)
        ->count();

    // --- Day calculations ---
    $currentDay = Carbon::now()->day;
    $monthEndDay = Carbon::parse($targetDate)->daysInMonth;

    // --- Daily Averages ---
    // (divide by number of days passed so far)
    $totalSumAllAvg   = $currentDay > 0 ? round($totalSumAll / $currentDay, 2) : 0;
    $preSaleActualAvg = $currentDay > 0 ? round($preSaleActual / $currentDay, 2) : 0;
    $postSaleActualAvg = $currentDay > 0 ? round($postSaleActual / $currentDay, 2) : 0;

    // --- Predicted totals for the month ---
    $predictedMoney     = $currentDay > 0 ? round(($totalSumAll / $currentDay) * $monthEndDay) : 0;
    $predictedPreSale   = $currentDay > 0 ? round(($preSaleActual / $currentDay) * $monthEndDay) : 0;
    $predictedPostSale  = $currentDay > 0 ? round(($postSaleActual / $currentDay) * $monthEndDay) : 0;

    return response()->json([
        'status' => 200,
        'data' => $targets,
        'targetValue' => $totalSumAll ?? 0,
        'preSaleValue' => $preSaleActual ?? 0,
        'postSaleValue' => $postSaleActual ?? 0,

        // NEW: Daily averages section
        'daily_avg' => [
            'money_avg' => $totalSumAllAvg,
            'preSale_avg' => $preSaleActualAvg,
            'postSale_avg' => $postSaleActualAvg,
        ],

        // Existing predicted section
        'predicted' => [
            'money' => $predictedMoney,
            'preSale' => $predictedPreSale,
            'postSale' => $predictedPostSale,
        ],

        'monthEndDay' => $monthEndDay,
        'currentDay' => $currentDay,
    ]);
}




}
