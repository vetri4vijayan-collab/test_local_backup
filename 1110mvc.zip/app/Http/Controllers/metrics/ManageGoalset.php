<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CostingModel;
use App\Models\CustomerModel;
use App\Models\GoalsetModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ManageGoalset extends Controller
{
    public function Index(Request $request)
    {
        // min_prd_cost
        $branch_id = $request->user()->branch_id;

        $goalset_list = GoalsetModel::where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->orderBy('sno', 'desc')
            ->get();

        $min_prd_cost = BranchModel::where('sno', $branch_id)->where('status', '!=', 2)->value('min_prd_cost');

        // Get the total count of leads
        $totalLeadCount = LeadModel::whereNotIn('status', [3, 2]);
        if ($branch_id != 0) {
            $totalLeadCount->where('za_lead.branch_id', $branch_id);
        }

        $totalLeadCount = $totalLeadCount->count();
        // return $totalLeadCount;
        // exit;

        // Get the count of leads for the current month
        $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2]);
        if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
        }
        $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();

        $totalCustomerCount = CustomerModel::where('status', '!=', 2);
        if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
        }

        $totalCustomerCount = $totalCustomerCount->count();

        // return $totalCustomerCount;
        // exit;

        // Get the count of leads for the current month
        $currentMonthCustomerCount = CustomerModel::where('status', '!=', 2);
        if ($branch_id != 0) {
            $currentMonthCustomerCount->where('za_customer.branch_id', $branch_id);
        }
        $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();

        // Calculate the percentage
        $percentageover = 0;
        $percentagecurrentmonth = 0;
        if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
        }
        if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
        }

        // calculation for average business value

        // get all lead courses
        $allCourses_ids = LeadModel::whereNotIn('status', [3, 2])
            ->where('branch_id', $branch_id)
            ->pluck('course_id');
        $allCourses_ids = collect($allCourses_ids)->flatMap(function ($item) {
            return json_decode($item);
        })->values()->all();

        // get all payments
        $payments = [];
        foreach ($allCourses_ids as $id) {
            $payment = ManageCoursesModel::where('sno', $id)
                ->where('branch_id', $branch_id)
                ->pluck('course_max_price');

            if ($payment !== null) {
                $payments[] = $payment[0];
            } else {
                $payments[] = null;
            }
        }

        // sum total course amount
        $total_business_value = array_sum($payments);

        $average_business_value = 0;
        // formula for average business
        if ($currentMonthLeadCount > 0) {
            $average_business_value = $total_business_value / $currentMonthLeadCount;
        }

        // calculation for average collection value
        $allCourses_cus = CustomerModel::where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->pluck('course_id');
        $allCourses_cus = collect($allCourses_cus)->flatMap(function ($item) {
            return json_decode($item);
        })->values()->all();

        // get all payments
        $payments_cus = [];
        foreach ($allCourses_cus as $id) {
            $payment = ManageCoursesModel::where('sno', $id)
                ->where('branch_id', $branch_id)
                ->pluck('course_max_price');

            if ($payment !== null) {
                $payments_cus[] = $payment[0];
            } else {
                $payments_cus[] = null;
            }
        }

        // sum total collection course amount
        $total_collection_value = array_sum($payments_cus);

        // formula for average collection
        $average_collection_value = 0;
        if ($currentMonthCustomerCount > 0) {
            $average_collection_value = $total_collection_value / $currentMonthCustomerCount;
        }
        //calculation for slot alloted percent
        $slotNotAllt = CostingModel::where('status', '!=', 2)->where('branch_id', $branch_id)->where('slot_id', null)->distinct('customer_id')->count();

        $slot_alloted_per = 0;
        if ($currentMonthCustomerCount > 0) {
            $slot_alloted_per = ($slotNotAllt / $currentMonthCustomerCount) * 100;
        }

        // Format the percentage to 2 decimal places
        $conversionRatePercentage = number_format($percentageover, 1);
        $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
        $slot_alloted_percent = number_format($slot_alloted_per, 2);

        $pageConfigs = ['myLayout' => 'default'];
        return view('content.metrics.manage_goalset', [
            'goalset_list' => $goalset_list,
            'pageConfigs' => $pageConfigs,
            'min_prd_cost' => $min_prd_cost,
            'conversionRatePercentage' => $conversionRatePercentage,
            'average_business_value' => $average_business_value,
            'average_collection_value' => $average_collection_value,
            'slot_alloted_percent' => $slot_alloted_percent,
            'schd_month_fltr' => '',
            'dept_fill' => '',
            'sub_dept_fill' => '',
            'job_pos_fill' => '',
        ]);

    }

    public function goalset_filter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $helper = new \App\Helpers\Helpers();

        // Determine branch type
        $get_branch_type = $branch_id ? $helper->get_branch_id($branch_id)->branch_type ?? 0 : 0;

        $min_prd_cost = BranchModel::where('sno', $branch_id)->where('status', '!=', 2)->value('min_prd_cost');

        // Get the total count of leads
        $totalLeadCount = LeadModel::whereNotIn('status', [3, 2]);
        if ($branch_id != 0) {
            $totalLeadCount->where('za_lead.branch_id', $branch_id);
        }

        $totalLeadCount = $totalLeadCount->count();
        // return $totalLeadCount;
        // exit;

        // Get the count of leads for the current month
        $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2]);
        if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
        }
        $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();

        $totalCustomerCount = CustomerModel::where('status', '!=', 2);
        if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
        }

        $totalCustomerCount = $totalCustomerCount->count();

        // return $totalCustomerCount;
        // exit;

        // Get the count of leads for the current month
        $currentMonthCustomerCount = CustomerModel::where('status', '!=', 2);
        if ($branch_id != 0) {
            $currentMonthCustomerCount->where('za_customer.branch_id', $branch_id);
        }
        $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();

        // Calculate the percentage
        $percentageover = 0;
        $percentagecurrentmonth = 0;
        if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
        }
        if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
        }

        // calculation for average business value

        // get all lead courses
        $allCourses_ids = LeadModel::whereNotIn('status', [3, 2])
            ->where('branch_id', $branch_id)
            ->pluck('course_id');
        $allCourses_ids = collect($allCourses_ids)->flatMap(function ($item) {
            return json_decode($item);
        })->values()->all();

        // get all payments
        $payments = [];
        foreach ($allCourses_ids as $id) {
            $payment = ManageCoursesModel::where('sno', $id)
                ->where('branch_id', $branch_id)
                ->pluck('course_max_price');

            if ($payment !== null) {
                $payments[] = $payment[0];
            } else {
                $payments[] = null;
            }
        }

        // sum total course amount
        $total_business_value = array_sum($payments);

        $average_business_value = 0;
        // formula for average business
        if ($currentMonthLeadCount > 0) {
            $average_business_value = $total_business_value / $currentMonthLeadCount;
        }

        // calculation for average collection value
        $allCourses_cus = CustomerModel::where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->pluck('course_id');
        $allCourses_cus = collect($allCourses_cus)->flatMap(function ($item) {
            return json_decode($item);
        })->values()->all();

        // get all payments
        $payments_cus = [];
        foreach ($allCourses_cus as $id) {
            $payment = ManageCoursesModel::where('sno', $id)
                ->where('branch_id', $branch_id)
                ->pluck('course_max_price');

            if ($payment !== null) {
                $payments_cus[] = $payment[0];
            } else {
                $payments_cus[] = null;
            }
        }

        // sum total collection course amount
        $total_collection_value = array_sum($payments_cus);

        // formula for average collection
        $average_collection_value = 0;
        if ($currentMonthCustomerCount > 0) {
            $average_collection_value = $total_collection_value / $currentMonthCustomerCount;
        }

        // Format the percentage to 2 decimal places
        $conversionRatePercentage = number_format($percentageover, 1);
        $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

        // Retrieve filter parameters from request
        $schd_month_fltr = $request->schd_month_fltr ?? '';
        $dept_fill = $request->dept_fill ?? '';
        $sub_dept_fill = $request->sub_dept_fill ?? '';
        $job_pos_fill = $request->job_pos_fill ?? '';

        // Build the query
        $query = GoalsetModel::where('za_goalset.branch_id', $branch_id)
            ->where('za_goalset.status', '!=', 2);

        if ($schd_month_fltr) {
            $query->where('za_goalset.schedule_month', 'LIKE', "%{$schd_month_fltr}%");
        }
        if ($dept_fill) {
            $query->where('za_goalset.department_id', 'LIKE', "%{$dept_fill}%");
        }
        if ($sub_dept_fill) {
            $query->where('za_goalset.sub_department_id', 'LIKE', "%{$sub_dept_fill}%");
        }
        if ($job_pos_fill) {
            $query->where('za_goalset.job_position_id', 'LIKE', "%{$job_pos_fill}%");
        }

        // Fetch events ordered by sno in descending order
        $goalset_list = $query->orderBy('za_goalset.sno', 'desc')->distinct()->get();

        // Clear session data
        session()->forget('branch_id_ses');
        session()->forget('branch_type_ses');

        // Fetch other data for view
        // $branch_list = BranchModel::where('status', 0)->orderBy('sno', 'desc')->get();
        // $event_category_list = EventCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();
        // $event_type_list = EventTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        // Return the view with the necessary data
        return view('content.metrics.manage_goalset', [
            'goalset_list' => $goalset_list,
            'min_prd_cost' => $min_prd_cost,
            'conversionRatePercentage' => $conversionRatePercentage,
            'average_business_value' => $average_business_value,
            'average_collection_value' => $average_collection_value,
            'schd_month_fltr' => $schd_month_fltr,
            'dept_fill' => $dept_fill,
            'sub_dept_fill' => $sub_dept_fill,
            'job_pos_fill' => $job_pos_fill,
        ])->with('filter_on', true);
    }

    public function Add(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'goalset_sch_month' => 'required|max:255',
            'department' => 'required|max:255',
            'sub_dept' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $schedule_month = $request->goalset_sch_month;
            $department_id = $request->department;
            $sub_department_id = $request->sub_dept;
            $job_position_id = $request->job_ptn;

            if ($department_id == "Sales") {
                if ($sub_department_id == "Pre Sale" || $sub_department_id == "Post Sale") {
                    $Registration_count = $request->reg_count;
                    $Business_value = $request->business_value;
                    $collection_value = $request->collection_value;
                    $goalset_description = $request->desc_sale;

                } else if ($sub_department_id == "Closing Sale") {

                    $harvest_amount = $request->harvest_amount;
                    $min_harverst_amount = $request->min_collect_harvest_amt;
                    $goalset_description = $request->desc_sale_close;

                }
            } else if ($department_id == "Production") {
                if ($sub_department_id == "Trainer") {
                    $min_students_alloted = $request->min_students_allot;
                    $max_free_slot = $request->max_free_slot;
                    $productivity_performance = $request->productivity_perform;
                    $goalset_description = $request->desc_trainer;

                }
            } else if ($department_id == "Internal Support") {
                if ($sub_department_id == "BH") {
                    $target_amount = $request->target_amount;
                    $goalset_description = $request->desc_bh;

                } else if ($sub_department_id == "PC") {
                    $max_slot_alloted_hrs = $request->max_slot_allot;
                    $goalset_description = $request->desc_pc;

                } else if ($sub_department_id == "CRE") {
                    $max_resolved_complaint_hrs = $request->max_resolved_complt;
                    $goalset_description = $request->desc_cre;
                }
            }

            $user_id = $request->user()->user_id;

            $goalset_chk = GoalsetModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$goalset_chk) {

                $year = substr(date('y'), -2);
                $goalset_id = 'GLST-0001/' . $year;
            } else {

                $data = $goalset_chk->goalset_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);

                $next_number = (int) $result + 1;
                $request = sprintf('GLST-%04d', $next_number);

                $year = substr(date('y'), -2);
                $goalset_id = $request . '/' . $year;
            }
            // return $goalset_description;
            // exit;

            $add_goalset = new GoalsetModel();
            $add_goalset->goalset_id = $goalset_id;
            $add_goalset->schedule_month = $schedule_month;
            $add_goalset->department_id = $department_id;
            $add_goalset->sub_department_id = $sub_department_id;
            $add_goalset->job_position_id = $job_position_id;

            $add_goalset->Registration_count = $Registration_count ?? null;
            $add_goalset->Business_value = $Business_value ?? null;
            $add_goalset->collection_value = $collection_value ?? null;
            $add_goalset->harvest_amount = $harvest_amount ?? null;
            $add_goalset->min_harverst_amount = $min_harverst_amount ?? null;
            $add_goalset->min_students_alloted = $min_students_alloted ?? null;
            $add_goalset->max_free_slot = $max_free_slot ?? null;
            $add_goalset->productivity_performance = $productivity_performance ?? null;
            $add_goalset->target_amount = $target_amount ?? null;
            $add_goalset->max_slot_alloted_hrs = $max_slot_alloted_hrs ?? null;
            $add_goalset->max_resolved_complaint_hrs = $max_resolved_complaint_hrs ?? null;
            $add_goalset->goalset_description = $goalset_description ?? null;

            $add_goalset->branch_id = $branch_id;
            $add_goalset->created_by = $user_id;
            $add_goalset->updated_by = $user_id;

            $add_goalset->save();

            if ($add_goalset) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Goalset added Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Goalset!',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        // return ($request);
        // exit;

        $validator = Validator::make($request->all(), [
            'edit_goalset_id' => 'required|max:255',
            'goalset_sch_month' => 'required|max:255',
            'department' => 'required|max:255',
            'sub_dept' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $edit_goalset_id = $request->edit_goalset_id;
            $schedule_month = $request->goalset_sch_month;
            $department_id = $request->department;
            $sub_department_id = $request->sub_dept;
            $job_position_id = $request->job_ptn;

            if ($department_id == "Sales") {
                if ($sub_department_id == "Pre Sale" || $sub_department_id == "Post Sale") {
                    $Registration_count = $request->reg_count;
                    $Business_value = $request->business_value;
                    $collection_value = $request->collection_value;
                    $goalset_description = $request->desc_sale;

                } else if ($sub_department_id == "Closing Sale") {

                    $harvest_amount = $request->harvest_amount;
                    $min_harverst_amount = $request->min_collect_harvest_amt;
                    $goalset_description = $request->desc_sale_close;

                }
            } else if ($department_id == "Production") {
                if ($sub_department_id == "Trainer") {
                    $min_students_alloted = $request->min_students_allot;
                    $max_free_slot = $request->max_free_slot;
                    $productivity_performance = $request->productivity_perform;
                    $goalset_description = $request->desc_trainer;

                }
            } else if ($department_id == "Internal Support") {
                if ($sub_department_id == "BH") {
                    $target_amount = $request->target_amount;
                    $goalset_description = $request->desc_bh;

                } else if ($sub_department_id == "PC") {
                    $max_slot_alloted_hrs = $request->max_slot_allot;
                    $goalset_description = $request->desc_pc;

                } else if ($sub_department_id == "CRE") {
                    $max_resolved_complaint_hrs = $request->max_resolved_complt;
                    $goalset_description = $request->desc_cre;
                }
            }

            $user_id = $request->user()->user_id;

            // return $goalset_description;
            // exit;

            $upd_goalset = GoalsetModel::where('sno', $edit_goalset_id)->first();

            $upd_goalset->schedule_month = $schedule_month;
            $upd_goalset->department_id = $department_id;
            $upd_goalset->sub_department_id = $sub_department_id;
            $upd_goalset->job_position_id = $job_position_id;

            $upd_goalset->Registration_count = $Registration_count ?? null;
            $upd_goalset->Business_value = $Business_value ?? null;
            $upd_goalset->collection_value = $collection_value ?? null;
            $upd_goalset->harvest_amount = $harvest_amount ?? null;
            $upd_goalset->min_harverst_amount = $min_harverst_amount ?? null;
            $upd_goalset->min_students_alloted = $min_students_alloted ?? null;
            $upd_goalset->max_free_slot = $max_free_slot ?? null;
            $upd_goalset->productivity_performance = $productivity_performance ?? null;
            $upd_goalset->target_amount = $target_amount ?? null;
            $upd_goalset->max_slot_alloted_hrs = $max_slot_alloted_hrs ?? null;
            $upd_goalset->max_resolved_complaint_hrs = $max_resolved_complaint_hrs ?? null;
            $upd_goalset->goalset_description = $goalset_description ?? null;

            $upd_goalset->created_by = $user_id;
            $upd_goalset->updated_by = $user_id;

            $upd_goalset->save();

            if ($upd_goalset) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Goalset Update Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Goalset!',
                ]);
            }

            return redirect()->back();
        }

    }

    public function Delete($id)
    {

        $upd_goalset = GoalsetModel::where('sno', $id)->first();
        $upd_goalset->status = 2;
        $upd_goalset->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_goalset = GoalsetModel::where('sno', $id)->first();
        $upd_goalset->status = $request->input('status', 0);
        $upd_goalset->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
