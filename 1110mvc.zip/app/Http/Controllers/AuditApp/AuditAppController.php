<?php
namespace App\Http\Controllers\AuditApp;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use App\Mail\EAPLMail;
use App\Models\AppointmentModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CategoryQuestionModel;
use App\Models\CounsellorAssessmentSave;
use App\Models\CounsellorCategorySave;
use App\Models\CounsellorCourseSave;
use App\Models\CounsellorFeedbackSave;
use App\Models\AuditQuestionModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\FeedbackQuestionModel;
use App\Models\JobRollModel;
use App\Models\AuditCategoryModel;
use App\Models\LeadQuestionModel;
use App\Models\ManageCoursesModel;
use App\Models\OfferzoneModel;
use App\Models\OtpModel;
use App\Models\PaymentModel;
use App\Models\SelfAssessmentModel;
use App\Models\StaffModel;
use App\Models\BranchAuditModel;
use App\Models\AuditQuestionSave;
use Carbon\Carbon;
use Illuminate\Support\Facades\Config;
use App\Models\SmsTemplateModel;
use App\Models\TrainingModel;
use App\Models\AuditNotificationModel;
use App\Models\User;
use App\Models\WhatsappApiConfigureModel;
use App\Services\ElysiumQrCodeService;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Traits\AuditNodfiableTrait;
use Illuminate\Support\Str;

// Add this at the top to use Str::uuid()
class AuditAppController extends Controller
{
    protected $elysiumQrCodeService;
    use AuditNodfiableTrait;
    public function __construct(ElysiumQrCodeService $elysiumQrCodeService)
    {
        $this->elysiumQrCodeService = $elysiumQrCodeService;

        $whatsappConfig      = WhatsappApiConfigureModel::where('sno', 3)->first();
        $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
        $this->accessToken   = $whatsappConfig->access_tokken;  // Set your access token in the environment file
        $this->baseUrl       = 'https://graph.facebook.com/v17.0';
        $this->businessId    = $whatsappConfig->waba_id;
    }

    public function AuditLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $key       = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {
            
            
            $user = DB::table('za_audit_staff')->where('za_audit_staff.audit_staff_mobile', $mobile_no)
                ->where('za_audit_staff.status', 0)
                ->join('za_branch', 'za_branch.sno', '=', 'za_audit_staff.branch_id')
                 ->join('za_countrytimezones', 'za_branch.time_zone_id', '=', 'za_countrytimezones.sno')
                ->select('za_audit_staff.*', 'za_branch.branch_name', 'za_countrytimezones.time_zone')
                
                ->first();
            // return $user;
              if( $mobile_no == "9790464324"){
                    $otp_value  = 1234; // Random 6-digit OTP
                }else{
                   $otp_value = rand(1000, 9999); // Random 6-digit OTP
                }
            //   if ($user && $user->time_zone) {
            //         Config::set('app.timezone', $user->time_zone);
            //         date_default_timezone_set($user->time_zone);
            //     }
            if ($user) {
                // Save OTP to Database
                $otp = new OtpModel();

                $otp->user_id    = $user->sno;
                $otp->mobile_no =  $mobile_no;
                $otp->otp_number = $otp_value;
                $otp->created_by = $user->sno;
                $otp->updated_by = $user->sno;
                $otp->save();
                
                  if( $mobile_no != "9790464324"){
                    if ($otp_value) {

                        $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey         = $result_sms ? $result_sms->authkey : '';
                        $sender_id       = $result_sms ? $result_sms->sender_id : '';
                        $template_id     = $result_sms ? $result_sms->template_id : '';
                        $country_code    = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number   = $country_code . $mobile_no;
        
                        $app_name = "InspectO";
                        // $app_link = 'https://elysiumacademy.org/';
                        
                           $app_code = "g1VJuk1q3ew";
                   
        
                        // Replace placeholders with actual values
                        $replacement_values = [$user->audit_staff_name, $app_name, $otp_value,$app_code];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
        
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];

                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
        
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
        
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                  }
                // Send OTP via SMS
                // $this->sendSms($mobile_no, $otp_value);
                // $usertable = User::where('user_id', $user->sno)->first();
                // return $user->sno;
                // $user = Auth::user();
                // $token = $user->createToken('MobileApp')->plainTextToken;
                
                // $token     = $usertable->createToken('authToken')->accessToken;
                // $token = $usertable->createToken('authToken')->plainTextToken;
                // $token = $usertable->createToken('authToken', ['counsellor-access'])->plainTextToken;
                // $token = $usertable->createToken('authToken')->accessToken;
                // $token = $usertable->createToken('authToken', ['counsellor-access'])->plainTextToken;

                $baseUrl = 'https://erp.elysium.academy/audit_images/';
                // $baseUrl = 'http://192.168.3.130:6070/audit_images/';
                $staff_profile="";
                if($user->staff_image){
                    $staff_profile=$baseUrl.$user->staff_image;
                }else{
                    $staff_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
                }

                return response()->json([
                    // 'api_token'         => $token,
                    // 'tokenValue'          => $token->token,
                    'otp'                 => $otp_value,
                    // 'otp'                 => 7780,
                    'staff_name'     => $user->audit_staff_name,
                    'staff_id'       => strval($user->sno),
                    'staff_text_id'       => $user->audit_staff_id,
                    'branch_id'       => strval($user->branch_id),
                    'branch_name'         => $user->branch_name,
                    'mobile_no'           => strval($user->audit_staff_mobile),
                    'email_id'            => strval($user->email_id),
                    'alternative_no'      => strval($user->alternative_no),
                    'staff_image'         => $staff_profile,
                    'description'         => $user->audit_staff_desc,
                    'message'     => 'Successfully',

                ], 200);
            } else {
                $response = [
                    'status'    => "2",
                    'message'   => 'User does not exist',
                    "error_msg" => null,
                    'data'      => null,
                ];
                return response($response, 200);
            }
        }
    }
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
        
       // Ensure both times are in UTC and properly compare
        // $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        // $expiryTime = $createdAt->copy()->addMinutes(2);
        // $currentTime = Carbon::now('UTC');
    
        // if ($currentTime->greaterThan($expiryTime)) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'OTP expired. Please request a new one.',
        //         // 'details' => [
        //         //     'created_at' => $createdAt->toIso8601String(),
        //         //     'expiry_time' => $expiryTime->toIso8601String(),
        //         //     'current_time' => $currentTime->toIso8601String()
        //         // ]
        //     ], 410);
        // }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }

    public function auditDashCount(Request $request)
    {
        $staff_id = $request->staff_id;
        $audit_staff = DB::table('za_audit_staff')->select('za_audit_staff.sno')
            ->where('za_audit_staff.status', '!=', 2)
            ->where('za_audit_staff.sno',$staff_id)
            ->first();
    
        if (!$audit_staff) {
            return response()->json([
                'status'    => 404,
                'message'   => 'Staff not found',
                'error_msg' => 'Invalid staff ID',
                'staff_list' => null,
            ], 404);
        }
    
        $audit_totalCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4,2])
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();

        $pending_auditCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->where('za_branch_audit.audit_status', "1")
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();
    
        $audit_list = BranchAuditModel::select(
            'za_branch_audit.sno as audit_id',
            'za_branch_audit.audit_date',
            'za_branch_audit.audit_time',
            'za_branch.branch_name', 'za_branch.branch_type',
            'za_branch.franchise_name')
            ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
            ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->where('za_branch_audit.status', '!=', "2")
            ->where('za_branch_audit.audit_status', "1")
            ->where('za_branch_audit.staff_id',$staff_id)
            ->where('za_branch_audit.audit_date', '>', date('Y-m-d'))
            ->orderBy('za_branch_audit.audit_date', 'asc')
            ->get();
        
        foreach ($audit_list as $audit) {
            $formattedAuditDate = Carbon::parse($audit->audit_date)->format('F d, Y');
            $formattedAuditTime = Carbon::parse($audit->audit_time)->format('h:i A');
            if ($audit->branch_type == '1') {
                $audit_branch_name = $audit->branch_name;
                $audit_branch_type = 'Branch';
            } else if ($audit->branch_type == '2') {
                $audit_branch_name = $audit->franchise_name;
                $audit_branch_type = 'Franchise';
            }
    
            // Get current date and time with Carbon
            $currentDateTime = Carbon::now();  // Current date and time
            // Parse the audit's audit_date and audit_time
            $nextAuditDateTime = Carbon::parse($audit->audit_date . ' ' . $audit->audit_time); 
    
            // If the next audit time is in the future (today or tomorrow), calculate the coming days correctly
            $comingDays = $currentDateTime->diffInDays($nextAuditDateTime, false); 
    
            if ($comingDays < 0) {
                $formattedDifference = "0 day";
            } else {
                $diff = $currentDateTime->diff($nextAuditDateTime); // Get a detailed date diff
                $months = $diff->m;
                $days = $diff->d;
    
                if ($months == 0) {
                    $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
                } else {
                    $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') . " and {$days} day" . ($days != 1 ? 's' : '');
                }
            }
            $audit->audit_date = $formattedAuditDate;
            $audit->audit_time = $formattedAuditTime;
            $audit->coming_days = $formattedDifference;
            $audit->audit_branch_name = $audit_branch_name;
            $audit->audit_branch_type = $audit_branch_type;
        }
    
        return response()->json([
            'status'      => 200,
            'message'     => 'Data Retrieved Successfully',
            'error_msg'   => null,
            'total_audit' => $audit_totalCount,
            'pending_audit' => $pending_auditCount,
            'notification_list' => $audit_list,
        ], 200);
    }

     public function AuditActiveList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $staff_id=$request->staff_id;
        $allAuditData = [];
        $audit_list = BranchAuditModel::select(
            'za_branch_audit.sno as audit_id',
            'za_branch_audit.audit_status',
            'za_branch_audit.audit_start_status',
            'za_branch_audit.audit_date',
            'za_branch_audit.branch_id',
            'za_branch_audit.department_ids',
            'za_branch_audit.audit_time',
            'za_branch.branch_name',
            'za_branch.latitude',
            'za_branch.longitude',
            'za_branch.door_no',
            'za_branch.area_street',
            'za_branch.pincode',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_staff.staff_name as centerHead_name',
            'za_staff.mobile_no as centerHead_no',
            'za_branch.branch_type',
            'za_branch.franchise_name')
            ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
            ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_branch.authority_id')
            ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
            ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4,5])
            ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
             ->orderBy('za_branch_audit.audit_date', 'asc')
             ->orderBy('za_branch_audit.audit_time', 'asc') 
            ->get();
            
              $audit_totalCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4,2])
             ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();
            
            $audit_activeCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4])
             ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();
            
             $audit_CompletedCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
                ->where('za_branch_audit.status', '!=', "2")
                ->where('za_branch_audit.audit_status', 2)
                 ->whereYear('za_branch_audit.audit_date', $year)
                ->whereMonth('za_branch_audit.audit_date', $month)
                ->where('za_branch_audit.staff_id',$staff_id)
                ->count();

            $pending_auditCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
                ->where('za_branch_audit.status', '!=', "2")
                ->where('za_branch_audit.audit_status', "1")
                 ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
                ->where('za_branch_audit.staff_id',$staff_id)
                ->count();
            
            
        foreach ($audit_list as $audit) {
            $formattedAuditDate = Carbon::parse($audit->audit_date)->format('F d, Y');
            $formattedAuditTime = Carbon::parse($audit->audit_time)->format('h:i A');
            if ($audit->branch_type == '1') {
                $audit_branch_name = $audit->branch_name;
                $audit_branch_type = 'Branch';
            } else if ($audit->branch_type == '2') {
                $audit_branch_name = $audit->franchise_name;
                $audit_branch_type = 'Franchise';
            }
            $department_ids = json_decode($audit->department_ids, true); // Decode JSON to array
            $department_name = [];
        
            if (is_array($department_ids)) { // Ensure it's an array before looping
                foreach ($department_ids as $depart_id) {
                    $departmentData = DB::table('za_audit_category')
                        ->where('status', 0)
                        ->where('sno', $depart_id)
                        ->select('audit_category_name as department_name')
                        ->first();
        
                    if ($departmentData) {
                        $department_name[] = $departmentData->department_name; // Append to array
                    }
                }
            }
            $lastBranchData = DB::table('za_branch_audit')
                ->select('za_branch_audit.audit_date')
                ->where('za_branch_audit.branch_id', $audit->branch_id)
                ->where('za_branch_audit.status', '!=', "2")  
                ->whereIn('za_branch_audit.audit_status', [1, 4, 5]) 
                ->orderBy('za_branch_audit.audit_date', 'desc') 
                ->first();


            $address = ($audit->door_no ? $audit->door_no . ", " : "")
                . ($audit->area_street ? $audit->area_street . ", " : "")
                . ($audit->city_name ? $audit->city_name . ", " : "")
                . ($audit->state_name ? $audit->state_name : "")
                . ($audit->pincode ? " - " . $audit->pincode : "");
        
            $audit->department_name = $department_name;
            $audit->audit_format_date = $formattedAuditDate;
            $audit->audit_time = $formattedAuditTime;
            $audit->audit_branch_name = $audit_branch_name;
            $audit->audit_branch_type = $audit_branch_type;
            $audit->audit_address = $address;
            $audit->last_audit_date = $lastBranchData->audit_date  ?? '-';
            $audit->audit_status_name= $audit->audit_status == 1 ? 'Awaiting' :($audit->audit_status == 4 ? 'Cancelled' : 'Rescheduled') ;
           
           
            $allAuditData[]=[
                "audit_id" =>  $audit->audit_id,
                "audit_date" => $audit->audit_date,
                "audit_format_date" => $audit->audit_format_date ,
                "audit_time" =>$audit->audit_time,
                "department_name" =>  $audit->department_name,
                "audit_branch_name" => $audit->audit_branch_name ,
                "audit_branch_type" =>  $audit->audit_branch_type,
                "audit_address" => $audit->audit_address,
                "latitude" => $audit->latitude,
                "longitude" => $audit->longitude,
                "audit_status" =>  $audit->audit_status,
                "audit_status_name" =>  $audit->audit_status_name,
                "centerHead_name" =>  $audit->centerHead_name,
                "centreHead_number" =>  $audit->centerHead_no,
                "last_audit_date" =>  $audit->last_audit_date,
                "audit_start_status" =>  $audit->audit_start_status
            ];


        }
        
    //   return count($audit_activeCount);
        
        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
             'audit_totalCount' => $audit_totalCount,
             'audit_activeCount' => $audit_activeCount,
            'audit_CompletedCount' => $audit_CompletedCount,
            'active_list' => $allAuditData,
           
        ]);
    }


    
    public function AuditCompleteList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $staff_id=$request->staff_id;
        
            
       
        $allAuditData = [];
        $audit_list = BranchAuditModel::select(
            'za_branch_audit.sno as audit_id',
            'za_branch_audit.audit_status',
            'za_branch_audit.audit_date',
            'za_branch_audit.department_ids',
            'za_branch_audit.audit_time',
            'za_branch_audit.audit_start_time',
            'za_branch_audit.audit_end_time',
            'za_branch.branch_name',
            'za_branch.latitude',
            'za_branch.longitude',
            'za_branch.door_no',
            'za_branch.area_street',
            'za_branch.pincode',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_branch.branch_type',
            'za_branch.franchise_name')
            ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
            ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
            ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [2,3,4])
            ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->orderBy('za_branch_audit.audit_date', 'asc')
            ->get();
        
        foreach ($audit_list as $audit) {
            $formattedAuditDate = Carbon::parse($audit->audit_date)->format('F d, Y');
            $formattedAuditTime = Carbon::parse($audit->audit_time)->format('h:i A');
            if ($audit->branch_type == '1') {
                $audit_branch_name = $audit->branch_name;
                $audit_branch_type = 'Branch';
            } else if ($audit->branch_type == '2') {
                $audit_branch_name = $audit->franchise_name;
                $audit_branch_type = 'Franchise';
            }
            $department_ids = json_decode($audit->department_ids, true); // Decode JSON to array
            $department_name = [];
        
            if (is_array($department_ids)) { // Ensure it's an array before looping
                foreach ($department_ids as $depart_id) {
                    $departmentData = DB::table('za_audit_category')
                        ->where('status', 0)
                        ->where('sno', $depart_id)
                        ->select('audit_category_name as department_name')
                        ->first();
        
                    if ($departmentData) {
                        $department_name[] = $departmentData->department_name; // Append to array
                    }
                }
            }
            $lastBranchData=DB::table('za_branch_audit')
            ->select('za_branch_audit.audit_date')
            ->where('za_branch_audit.branch_id', $audit->branch_id)
            ->where('za_branch_audit.branch_id','!=','1')
            ->orderBy('za_branch_audit.audit_date', 'asc')->first();



            $address = ($audit->door_no ? $audit->door_no . ", " : "")
                . ($audit->area_street ? $audit->area_street . ", " : "")
                . ($audit->city_name ? $audit->city_name . ", " : "")
                . ($audit->state_name ? $audit->state_name : "")
                . ($audit->pincode ? " - " . $audit->pincode : "");

                $auditStartTime = Carbon::parse($audit->audit_start_time)->format('h:i A');
                $auditEndTime = Carbon::parse($audit->audit_end_time)->format('h:i A');
        
            $audit->department_name = $department_name;
            $audit->audit_format_date = $formattedAuditDate;
            $audit->audit_time = $formattedAuditTime;
            $audit->audit_branch_name = $audit_branch_name;
            $audit->audit_branch_type = $audit_branch_type;
            $audit->audit_address = $address;
            $audit->last_audit_date = $lastBranchData ? $lastBranchData->audit_date : '-';
            $audit->audit_status_name='Submitted';
            $audit->centerHead_name='Sujatha';
            $audit->centerHead_no='9098790789';
            $audit->audit_start_time=$auditStartTime;
            $audit->audit_end_time=$auditEndTime;
          

           

            $allAuditData[]=[
                "audit_id" =>  $audit->audit_id,
                "audit_date" => $audit->audit_date,
                "audit_format_date" => $audit->audit_format_date ,
                "audit_time" =>$audit->audit_time,
                "department_name" =>  $audit->department_name,
                "audit_branch_name" => $audit->audit_branch_name ,
                "audit_branch_type" =>  $audit->audit_branch_type,
                "audit_address" => $audit->audit_address,
                "latitude" => $audit->latitude,
                "longitude" => $audit->longitude,
                "audit_status" =>  $audit->audit_status,
                "audit_status_name" =>  $audit->audit_status_name,
                "centerHead_name" =>  $audit->centerHead_name,
                "centreHead_number" =>  $audit->centerHead_no,
                "last_audit_date" =>  $audit->last_audit_date,
                "audit_start_time" =>  $audit->audit_start_time,
                "audit_end_time" =>  $audit->audit_end_time
            ];


        }
           $audit_totalCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4,2])
             ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();
            
            $audit_activeCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
            ->where('za_branch_audit.status', '!=', "2")
            ->whereIN('za_branch_audit.audit_status', [1,4])
             ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->count();
            
             $audit_CompletedCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
                ->where('za_branch_audit.status', '!=', "2")
                ->where('za_branch_audit.audit_status', 2)
                 ->whereYear('za_branch_audit.audit_date', $year)
                ->whereMonth('za_branch_audit.audit_date', $month)
                ->where('za_branch_audit.staff_id',$staff_id)
                ->count();

            $pending_auditCount = DB::table('za_branch_audit')->select('za_branch_audit.sno')
                ->where('za_branch_audit.status', '!=', "2")
                ->where('za_branch_audit.audit_status', "1")
                 ->whereYear('za_branch_audit.audit_date', $year)
            ->whereMonth('za_branch_audit.audit_date', $month)
                ->where('za_branch_audit.staff_id',$staff_id)
                ->count();
        
        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
             'audit_totalCount' => $audit_totalCount,
             'audit_activeCount' => $audit_activeCount,
            'audit_CompletedCount' => $audit_CompletedCount,
            'completed_list' => $allAuditData,
        ]);
    }

    public function AuditStart(Request $request){
        
       
         $validator = Validator::make($request->all(), [
            'audit_id' => 'required|integer',
             'audit_staff_image' => 'required',
             'in_time'=>'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {
        
        $audit_id = $request->input('audit_id');
        $in_time=$request->in_time;
        $latitude=$request->latitude;
        $longitude=$request->longitude;
        $audit_staff_image_base64 = $request->input('audit_staff_image');
      
            if ($audit_staff_image_base64) {
                $base64_image = substr($audit_staff_image_base64, strpos($audit_staff_image_base64, ',') + 1);
                $decoded_image = base64_decode($base64_image);
            } 
        
                // Generate a unique filename for the image
                $imageName = 'audit_' . $audit_id . '.png'; // or use any other unique naming convention
            
                // Define the path to store the image in the public directory
                $imagePath = public_path('audit_staff_image/' . $imageName);
            
                // Ensure the directory exists
                if (!file_exists(public_path('audit_staff_image'))) {
                    mkdir(public_path('audit_staff_image'), 0777, true); 
                }
            
                // Save the image to the file system
                file_put_contents($imagePath, $decoded_image);
            
            // Now save the file path to the database
            $audit_data = BranchAuditModel::where('sno', $audit_id)->first();
            if ($audit_data) {
                $audit_data->audit_staff_image =$imageName; // Save the relative path
                $audit_data->audit_start_status =1; 
                $audit_data->audit_start_time =$in_time; // Save the relative path
                $audit_data->start_latitude =$latitude; // Save the relative path
                $audit_data->start_longitude =$longitude; // Save the relative path
                $audit_data->update();
            
               return response()->json([
                    'status' => 200,
                    'message' => 'Image Submitted Successfully',
                    'audit_start_status' => $audit_data->audit_start_status,
                ], 200);
                
            } else {
                return response()->json([
                    'status' => 404,
                    'message' => 'Audit not found.',
                ], 404);
            }
        }
        
    }

     public function AuditQuestionsList(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'audit_id' => 'required|integer',
            
        ]);


        // Extract the department_ids from the request
        $audit_id = $request->input('audit_id');

        
        
        

        // return $in_time;

       
        
     
        $audit_data = BranchAuditModel::where('sno', $audit_id)->first();
        if ($audit_data) {
            $audit_data->audit_start_status =2;
            $audit_data->update();
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Audit not found.',
            ], 404);
        }
        

        $audit_data = BranchAuditModel::select('za_branch_audit.department_ids')
            ->where('za_branch_audit.sno',$audit_id)
            ->first();

        $department_ids = json_decode($audit_data->department_ids, true);

        // Start timing
        $startTime = microtime(true);


        // Fetch categories
        $departments = collect(AuditCategoryModel::whereIn('sno', $department_ids)->orderBy('audit_category_name', 'asc')->get()->keyBy('sno'));

        // Fetch questions and join with departments
        $questions = collect(
            AuditQuestionModel::whereIn('za_audit_question.audit_category_id', $department_ids)
                ->where('za_audit_question.status', 0)
                ->join('za_audit_category', 'za_audit_category.sno', '=', 'za_audit_question.audit_category_id')
                ->select('za_audit_category.sno as audit_category_id', 'za_audit_category.audit_category_name', 'za_audit_question.*')
                ->orderBy('za_audit_question.sno', 'asc')
                ->get()
                ->groupBy('audit_category_id')
        );
        // return $questions;
        // Format the response
        $response = $departments->map(function ($category) use ($questions) {
            return [
                'audit_department_id'   => $category->sno,
                'department_name' => $category->audit_category_name,
                'question'      => $questions->get($category->sno, collect([]))
                    ->map(function ($question) {
                        return [
                            'department_question_id' => strval($question->sno),
                            'audit_department_id' => strval($question->audit_category_id),
                            'audit_question_name' => strval($question->audit_question_name),
                            'audit_question_type' => strval($question->audit_question_type),
                            // Ensure proper JSON handling
                            'audit_question_option' => json_decode($question->audit_question_option, true) ?? [],
                            'created_by' => strval($question->created_by),
                            'created_at' => $question->created_at->toISOString(),
                            'updated_by' => strval($question->updated_by),
                            'updated_at' => $question->updated_at->toISOString(),
                            'status' => strval($question->status),
                        ];
                    })
                    ->toArray()
            ];
        });



        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status'    => 200,
            'message'   => 'Audit Departmet Question List',
            'error_msg' => null,
            'data'      => $response,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    // public function AuditQuestionSave(Request $request)
    // {
    //     // Validate the incoming request
    //     $request->validate([
    //         'data' => 'required|array',
    //         'data.*.audit_department_id' => 'required|integer',
    //         'data.*.department_question_id' => 'required|integer',
    //         'data.*.audit_question_option' => 'required|array',
    //         'audit_id' => 'required|integer',
    //         'staff_id' => 'required|integer',
    //         'out_time'=>'required|string',
    //     ]);

    //     // Extract data from the request
    //     $data = $request->input('data');
    //     $audit_id = $request->input('audit_id');
    //     $staff_id = $request->input('staff_id');
    //     $out_time = $request->input('out_time');
        
    //     $staff_head_image_base64 = $request->input('staff_with_head_image');

    //     $branch = DB::table('za_audit_staff')->where('sno', $staff_id)->first();
    //     // Start timing
    //     $startTime = microtime(true);

    //     foreach ($data as $item) {
    //         // Extract the options
    //         $options = $item['audit_question_option'];

    //         // Fetch all question options and their scores
    //         $allOptions = AuditQuestionModel::where('sno', $item['department_question_id'])
    //             ->pluck('audit_question_option') // Fetch all JSON data
    //             ->toArray();

    //         // Decode JSON and extract scores
    //         $optionScores = [];
    //         foreach ($allOptions as $json) {
    //             $decoded = json_decode($json, true);
    //             if (is_array($decoded)) {
    //                 foreach ($decoded as $option) {
    //                     $optionScores[$option['value']] = $option['score'];
    //                 }
    //             }
    //         }


    //         // return $optionScores ;
    //         $totalScore = array_reduce($options, function ($carry, $option) use ($optionScores) {
    //             // Make sure to access the first element of the array
    //             return $carry + (int)($optionScores[$option][0] ?? 0); // Convert to integer
    //         }, 0);

    //         // Update or create the record
    //         $cat = AuditQuestionSave::updateOrCreate(
    //             [
    //                 'audit_id' => $audit_id,
    //                 'audit_department_id' => $item['audit_department_id'],
    //                 'department_question_id' => $item['department_question_id']
    //             ],
    //             [
    //                 'branch_id' => $branch->branch_id,
    //                 'audit_question_answer' => json_encode($options), // Store the options as JSON
    //                 'score' => $totalScore, // Store the total score
    //                 'created_by' => $staff_id,
    //                 'updated_by' => $staff_id
    //             ]
    //         );
    //     }
    //     if ($audit_id) {
            
    //          if($staff_head_image_base64){
                
    //             if ($staff_head_image_base64) {
    //                 $base64_image = substr($staff_head_image_base64, strpos($staff_head_image_base64, ',') + 1);
    //                 $decoded_image = base64_decode($base64_image);
    //                 // if ($decoded_image === false) {
    //                 //     return response()->json([
    //                 //         'status' => 400,
    //                 //         'message' => 'Invalid base64 string.',
    //                 //     ], 400);
    //                 // }
    //             } 
    //             // Generate a unique filename for the image
    //             $imageName = 'audit_' . $audit_id . '.png'; // or use any other unique naming convention
            
    //             // Define the path to store the image in the public directory
    //             $imagePath = public_path('audit_staff_image/staff_head_images' . $imageName);
            
    //             // Ensure the directory exists
    //             if (!file_exists(public_path('audit_staff_image'))) {
    //                 mkdir(public_path('audit_staff_image'), 0777, true); // Create directory if not exists
    //             }if (!file_exists(public_path('audit_staff_image/staff_head_images'))) {
    //                 mkdir(public_path('audit_staff_image/staff_head_images'), 0777, true); // Create directory if not exists
    //             }
            
    //             // Save the image to the file system
    //             file_put_contents($imagePath, $decoded_image);
               
    //         }
            
    //         $audit_id           = $audit_id;
    //         $upd_audit         =  BranchAuditModel::where('sno', $audit_id)->first();
    //         $upd_audit->pages   = 2;
    //         $audit_data->staff_head_image =$imageName ?? null;
    //         $upd_audit->audit_end_time   = $out_time ;
    //         $upd_audit->audit_status   = 2;
    //         $upd_audit->update();
    //     }

    //     // End timing
    //     $endTime = microtime(true);
    //     $executionTime = $endTime - $startTime;

    //     // Return the response
    //     return response()->json([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => 'Successfully',
    //         'execution_time' => $executionTime . ' seconds'
    //     ], 200);
    // }
    
    public function AuditQuestionSave(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'data' => 'required|array',
            'data.*.audit_department_id' => 'required|integer',
            'data.*.department_question_id' => 'required|integer',
            'data.*.audit_question_option' => 'required|array',
            'audit_id' => 'required|integer',
            'staff_id' => 'required|integer',
            'out_time' => 'required|string',
            'staff_with_head_image' => 'nullable|string',  // Make this field optional for validation
        ]);
    
        // Extract data from the request
        $data = $request->input('data');
        $audit_id = $request->input('audit_id');
        $staff_id = $request->input('staff_id');
        $out_time = $request->input('out_time');
        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');
        $staff_head_image_base64 = $request->input('staff_with_head_image');
    
        // Fetch branch details
        $branch = DB::table('za_audit_staff')->where('sno', $staff_id)->first();
    
        // Start timing for execution performance
        $startTime = microtime(true);
    
        foreach ($data as $item) {
            // Extract the options
            $options = $item['audit_question_option'];
    
            // Fetch all question options and their scores
            $allOptions = AuditQuestionModel::where('sno', $item['department_question_id'])
                ->pluck('audit_question_option') // Fetch all JSON data
                ->toArray();
    
            // Decode JSON and extract scores
            $optionScores = [];
            foreach ($allOptions as $json) {
                $decoded = json_decode($json, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $option) {
                        $optionScores[$option['value']] = $option['score'];
                    }
                }
            }
    
            // Calculate the total score based on selected options
            $totalScore = array_reduce($options, function ($carry, $option) use ($optionScores) {
                return $carry + (int)($optionScores[$option][0] ?? 0); // Safely access option scores
            }, 0);
    
            // Update or create the record
            AuditQuestionSave::updateOrCreate(
                [
                    'audit_id' => $audit_id,
                    'audit_department_id' => $item['audit_department_id'],
                    'department_question_id' => $item['department_question_id']
                ],
                [
                    'branch_id' => $branch->branch_id,
                    'audit_question_answer' => json_encode($options), // Store the options as JSON
                    'score' => $totalScore, // Store the total score
                    'created_by' => $staff_id,
                    'updated_by' => $staff_id
                ]
            );
        }
    
        // Handle the image upload (if exists)
        if ($audit_id && $staff_head_image_base64) {
            $base64_image = substr($staff_head_image_base64, strpos($staff_head_image_base64, ',') + 1);
            $decoded_image = base64_decode($base64_image);
    
            // Generate a unique filename for the image
            $imageName = 'audit_' . $audit_id . '.png'; // Using audit ID as part of the filename
    
            // Define the path to store the image
            $imagePath = public_path('audit_staff_image/staff_head_images/' . $imageName);
    
            // Ensure the directory exists
            $dirPath = public_path('audit_staff_image/staff_head_images');
            if (!file_exists($dirPath)) {
                mkdir($dirPath, 0777, true); // Create the directory if not exists
            }
    
            // Save the image to the file system
            file_put_contents($imagePath, $decoded_image);
            
            // Update the audit record with the image name
            $upd_audit = BranchAuditModel::where('sno', $audit_id)->first();
            if ($upd_audit) {
                $upd_audit->staff_head_image = $imageName; // Save the image name
                $upd_audit->audit_start_status =0;
                $upd_audit->audit_end_time = $out_time; // Set audit end time
                $upd_audit->end_latitude = $latitude; // Set audit end time
                $upd_audit->end_longitude = $longitude; // Set audit end time
                $upd_audit->audit_status = 2; // Update status (or any relevant status code)
                $upd_audit->audit_notification = 2; // Update status (or any relevant status code)
                $upd_audit->notification_time = date('Y-m-d H:i:s'); // Update status (or any relevant status code)
                $upd_audit->update(); // Save changes
                
                 $this->sendAuditNotification(
                    $audit_id,
                    $upd_audit->staff_id,
                    "Audit Submitted Successfully",
                    $upd_audit->staff_id,
                    2
                );
            }
        }
    
        // End timing for execution performance
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
    
        // Return the response
        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => 'Successfully',
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    
    
    public function ReviewAudit(Request $request)
    {   
    // Get audit ID from request
    $id = $request->audit_id;
    
    // Get audit data based on the ID
    $audit_data = DB::table('za_branch_audit')
        ->select('za_branch_audit.department_ids')
        ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
        ->where('za_branch_audit.status', '!=', 2)
        ->where('za_branch_audit.sno', $id)
        ->first();

    // Check if audit data exists
    if (!$audit_data) {
        return response()->json([
            'status' => 404,
            'success' => false,
            'message' => 'Audit not found',
            'error_msg' => 'No audit record found with the provided ID.',
            'data' => null,
        ], 404);
    }

    // Fetch general settings and format date
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings->date_format ?? 'd-M-y';

    // Decode department IDs
    $department_ids = json_decode($audit_data->department_ids, true);
    if (!$department_ids) {
        return response()->json([
            'status' => 400,
            'success' => false,
            'message' => 'Invalid department IDs.',
            'error_msg' => 'Department IDs are invalid or empty.',
            'data' => null,
        ], 400);
    }

    // Fetch department list
    $depart_list = DB::table('za_audit_category')
        ->select('za_audit_category.audit_category_name as audit_department_name', 'za_audit_category.sno as id')
        ->where('za_audit_category.status', '!=', 2)
        ->whereIn('za_audit_category.sno', $department_ids)
        ->get();

    // Fetch questions and answers
    $questions = DB::table('za_audit_question')
        ->select(
            'za_audit_question.sno as question_id',
            'za_audit_question.audit_question_name as question_name',
            'za_audit_question.audit_question_option',
            'za_audit_question.audit_question_type',
            'za_audit_question.audit_category_id as department_id',
            'za_audit_category.audit_category_name as audit_department_name',
            'za_audit_question_save.score',
            'za_audit_question_save.audit_question_answer'
        )
        ->join('za_audit_question_save', 'za_audit_question.sno', '=', 'za_audit_question_save.department_question_id')
        ->leftJoin('za_audit_category', 'za_audit_category.sno', '=', 'za_audit_question.audit_category_id')
        ->where('za_audit_question.status', 0)
        ->where('za_audit_question_save.audit_id', $id)
        ->whereIn('za_audit_question.audit_category_id', $department_ids)
        ->get();

    // Group questions by department
    $groupedQuestions = $questions->groupBy('department_id');

    // Process each question to calculate total score and handle answers
    foreach ($questions as $singleQuestion) {
        // Decode the answer (if it's stored as JSON and not already an array)
        if (is_string($singleQuestion->audit_question_answer)) {
            $answer = json_decode($singleQuestion->audit_question_answer);
            if (!is_array($answer)) {
                $answer = [$answer]; // If not an array, convert it to an array with a single value
            }
             if($singleQuestion->audit_question_type == 'checkbox'){
                $singleQuestion->audit_question_answer =  $answer;
            }else{
                $singleQuestion->audit_question_answer = implode(', ', $answer);
            }
        }

        // Decode options (only if they are strings)
        if (is_string($singleQuestion->audit_question_option)) {
            $options = json_decode($singleQuestion->audit_question_option, true);
            $singleQuestion->audit_question_option = $options;
        }

        // Initialize total score
        $total_score = 0;

        // Calculate score based on question type
        switch ($singleQuestion->audit_question_type) {
            case 'checkbox':
                foreach ($options as $option) {
                    if ($option['value']) { // Assuming option has 'value' as a key
                        $score = (int)$option['score'][0]; // Assuming score is a single element array
                        $total_score += $score; // Sum the score
                    }
                }
                break;

            case 'radio_button':
            case 'list_box':
                $max_score = 0;
                foreach ($options as $option) {
                    if ($option['value']) { // Assuming option has 'value' as a key
                        $score = (int)$option['score'][0]; // Assuming score is a single element array
                        $max_score = max($max_score, $score); // Get the maximum score
                    }
                }
                $total_score = $max_score;
                break;

            case 'text_field':
                $total_score = 5; // Assuming a fixed score for text field type
                break;
        }

        // Assign the total score
        $singleQuestion->total_score = $total_score;
    }

    // Collect department names
    $depart_names = $depart_list->pluck('audit_department_name')->toArray();
    $department_names = implode(', ', $depart_names);

    // Add department list and grouped questions to the audit data
    $audit_data->department_name = $department_names;
    $audit_data->department_list = $depart_list;

    // Format the grouped questions by department
    $audit_data->questions = $groupedQuestions->map(function ($questionsGroup, $departmentId) use ($depart_list) {
        $department = $depart_list->firstWhere('id', $departmentId);
        return [
            'department_id' => $departmentId,
            'department_name' => $department ? $department->audit_department_name : 'Unknown',
            'questions' => $questionsGroup->map(function ($question) {
                return [
                    'question_id' => $question->question_id,
                    'question_name' => $question->question_name,
                    'question_option' => $question->audit_question_option,
                    'question_type' => $question->audit_question_type,
                    'audit_question_answer' => $question->audit_question_answer,
                    'total_score' => $question->total_score,
                ];
            })->toArray(),
        ];
    });

    // Return response
    return response()->json([
        'status' => 200,
        'success' => true,
        'message' => null,
        'error_msg' => null,
        'department_names' => $department_names,
        'department_list' => $depart_list,
        'questions' => $audit_data->questions,
    ], 200);
}

   public function AuditReschedule(Request $request)
{
    // Validate input
    $request->validate([
        'audit_id' => 'required|integer',
        'reschedule_reason' => 'required|string',
        'reschedule_date' => 'required|string',
    ]);

    $audit_id = $request->audit_id;
    $reschedule_reason = $request->reschedule_reason;
    $reschedule_date = $request->reschedule_date;
    $reschedule_time = $request->reschedule_time;
    $audit_status = 5;

    // Fetch the existing audit
    $upd_audit = BranchAuditModel::where('sno', $audit_id)->first();

    if (!$upd_audit) {
        return response()->json([
            'status' => 404,
            'message' => 'Audit not found',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }

    // Update the current audit as canceled
    $upd_audit->reschedule_reason = $reschedule_reason;
    $upd_audit->audit_status = $audit_status;
    $upd_audit->audit_notification =5;
    $upd_audit->notification_time = date('Y-m-d H:i:s');
    $upd_audit->update();
    
     

    // Prepare new audit with rescheduled date
    $audit_data = BranchAuditModel::where('sno', $audit_id)->first();
    $branch_id = $audit_data->branch_id;
    $audit_date = date('Y-m-d', strtotime($reschedule_date));
    $audit_time = date('H:i:s', strtotime($reschedule_time));
    $reschedule_chk = 1;
    $reschedule_parent_id = $audit_id;
    $staff_id = $audit_data->staff_id;
    $department_ids = $audit_data->department_ids;

    // Generate new audit ID
    $branch_audit_chk = BranchAuditModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    if (!$branch_audit_chk) {
        $year = substr(date('y'), -2);
        $branch_audit_id = 'BRAD-0001/' . $year;
    } else {
        $data = $branch_audit_chk->branch_audit_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int) $result + 1;
        $year = substr(date('y'), -2);
        $branch_audit_id = sprintf('BRAD-%04d', $next_number) . '/' . $year;
    }

    // Create a new rescheduled audit
    $branch_ad_add = new BranchAuditModel();
    $branch_ad_add->branch_audit_id = $branch_audit_id;
    $branch_ad_add->branch_id = $branch_id;
    $branch_ad_add->staff_id = $staff_id;
    $branch_ad_add->department_ids = $department_ids;
    $branch_ad_add->audit_date = $audit_date;
    $branch_ad_add->audit_time = $audit_time;
    $branch_ad_add->created_by = $audit_data->created_by;
    $branch_ad_add->updated_by = $audit_data->created_by; // assumes auth middleware
    $branch_ad_add->notification_time = date('Y-m-d H:i:s'); // assumes auth middleware
    $branch_ad_add->audit_status = 1;
    $branch_ad_add->save();
    
    
    // ✅ Send notification only when points are added
       $this->sendAuditNotification(
            $branch_ad_add->sno,
            $branch_ad_add->staff_id,
            "Audit Rescheduled",
            $branch_ad_add->staff_id,
            5
        );
    

    return response()->json([
        'status' => 200,
        'message' => 'Reschedule Successful',
        'error_msg' => null,
        'data' => 'Reschedule Successfully',
    ], 200);
}


    public function auditNotficationListOld(Request $request){
        
        $staff_id=$request->staff_id;
       
        $allAuditData = [];
        $audit_list = BranchAuditModel::select(
            'za_branch_audit.sno as audit_id',
            'za_branch_audit.audit_status',
            'za_branch_audit.audit_date',
            'za_branch_audit.audit_time',
            'za_branch.branch_name',
            'za_branch.branch_type',
            'za_branch_audit.notification_read',
            'za_branch_audit.audit_notification',
            'za_branch_audit.notification_time',
            'za_branch_audit.created_at',
            'za_branch.franchise_name')
            ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
            ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
            ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
            ->where('za_branch_audit.status', '!=', "2")
            ->where('za_branch_audit.audit_notification', '!=',0)
            ->where('za_branch_audit.staff_id',$staff_id)
            ->orderBy('za_branch_audit.created_at', 'desc')
            ->get();
        
     
        foreach ($audit_list as $audit) {
            $formattedAuditDate = Carbon::parse($audit->audit_date)->format('F d, Y');
            $formattedAuditTime = Carbon::parse($audit->audit_time)->format('h:i A');
            if ($audit->branch_type == '1') {
                $audit_branch_name = $audit->branch_name;
                $audit_branch_type = 'Branch';
            } else if ($audit->branch_type == '2') {
                $audit_branch_name = $audit->franchise_name;
                $audit_branch_type = 'Franchise';
            }
            

            $auditStartTime = Carbon::parse($audit->audit_start_time)->format('h:i A');
            $auditEndTime = Carbon::parse($audit->audit_end_time)->format('h:i A');
        
            $audit->audit_format_date = $formattedAuditDate;
            $audit->audit_time = $formattedAuditTime;
            $audit->audit_branch_name = $audit_branch_name;
            $audit->audit_branch_type = $audit_branch_type;
            $title="";
            
            if($audit->audit_notification == 1 ){
                 $title="New Audit Created";
            }elseif($audit->audit_notification == 2){
                 $title="Audit Submitted Successfully";
            }elseif($audit->audit_notification == 4){  
                $title="Audit Cancelled";
            }elseif($audit->audit_notification == 5){
                 $title="Audit Rescheduled";
            }
            
            $audit->notification_title= $title;
         
          

           

            $allAuditData[]=[
                "audit_id" =>  $audit->audit_id,
                "audit_date" => $audit->audit_date,
                "audit_format_date" => $audit->audit_format_date ,
                "audit_time" =>$audit->audit_time,
                "audit_branch_name" => $audit->audit_branch_name ,
                "audit_branch_type" =>  $audit->audit_branch_type,
                "notification_title" =>  $audit->notification_title,
                "notification_status" =>  $audit->audit_notification,
                'time' => $audit->created_at->format('Y-m-d H:i:s'),
                'time_ago' => $this->formatTimeAgo($audit->created_at),
                'notification_read' =>$audit->notification_read,
            ];


        }
        
        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'notification_list' => $allAuditData,
        ]);
        
        
    }
    
     public function auditNotficationList(Request $request)
   {
      $staff_id=$request->staff_id; // for Student App

    if (!$staff_id) {
        return response()->json([
            'status' => 422,
            'message' => 'Staff ID is required',
            'data' => null,
        ], 422);
    }
    
     $audit_staff = DB::table('za_audit_staff')->where('sno', $staff_id)
                ->first();



    if (!$audit_staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Student not found',
            'data' => null,
        ], 404);
    }

    // Fetch notifications
    $notifications = AuditNotificationModel::where('audit_staff_id', $staff_id)
        ->where('notification_status', 0)
        ->orderBy('notification_date', 'desc')
        ->get();
        $notFound_ids =[];

    // Add time_ago, formatted date & time fields
    $notifications = $notifications->map(function ($item) {
        // $dt = Carbon::parse($item->notification_date);
        $audit_data = BranchAuditModel::select(
            'za_branch_audit.*',
            'za_branch.branch_name',
            'za_branch.branch_type',
            'za_branch.franchise_name')->where('za_branch_audit.status', '!=', "2")
            ->where('za_branch_audit.sno',$item->audit_id)
             ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->orderBy('za_branch_audit.created_at', 'desc')
            ->first();
            // if($audit_data){
            //     $notFound_ids =[];
            // }else{
            //     $notFound_ids =$item->audit_id;
            // }
        //   return $notFound_ids ;
            if ($audit_data->branch_type == '1') {
                $audit_branch_name = $audit_data->branch_name;
                $audit_branch_type = 'Branch';
            } else if ($audit_data->branch_type == '2') {
                $audit_branch_name = $audit_data->franchise_name;
                $audit_branch_type = 'Franchise';
            }
            $formattedAuditDate = Carbon::parse($audit_data->audit_date)->format('F d, Y');
            $formattedAuditTime = Carbon::parse($audit_data->audit_time)->format('h:i A');
         $dt = Carbon::parse($item->notification_date, 'Asia/Kolkata');
        $item->audit_date = $audit_data->audit_date;
        $item->audit_format_date = $formattedAuditDate;
        $item->audit_time = $formattedAuditTime;
        $item->audit_branch_name = $audit_branch_name;
        $item->audit_branch_type = $audit_branch_type;
        $item->time_ago = $dt->diffForHumans();
        $item->formated_date = $dt->format('d-M-Y'); // 08-Aug-2025
        $item->formated_time = $dt->format('h:i A');  // 11:12 AM
        return $item;
    });

    return response()->json([
        'status' => 200,
        'message' => 'Notification list fetched successfully',
        'data' => $notifications,
    ], 200);
}
    
    public function auditMarkUsRead(Request $request){
      
        $request->validate([
            'audit_id' => 'required|integer',
        ]);
    
        $audit_id = $request->audit_id;
        
        $upd_audit = BranchAuditModel::where('sno', $audit_id)->first();
    
        if (!$upd_audit) {
            return response()->json([
                'status' => 404,
                'message' => 'Audit not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }
    
        $upd_audit->notification_read =1;
        $upd_audit->update();
    
        return response()->json([
            'status' => 200,
            'message' => 'Mark Us Read',
            'error_msg' => null,
            'data' => 'Mark Us Read',
        ], 200);
    }
    
   private function formatTimeAgo($date)
    {
        $timezone = 'Asia/Kolkata'; // Replace with your actual timezone
    
        $notificationDate = Carbon::parse($date, $timezone);
        $now = Carbon::now($timezone);
    
        return $notificationDate->diffForHumans($now);
    }
    
    
       public function ClearAllNotifications(Request $request)
    {
        $staff_id = $request->staff_id;
    
        if (!$staff_id) {
            return response()->json([
                'status' => 422,
                'message' => 'Staff ID is required',
            ], 422);
        }
    
         $audit_staff = DB::table('za_audit_staff')->where('sno', $staff_id)
                ->first();
    
        if (!$audit_staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
            ], 404);
        }
    
        AuditNotificationModel::where('audit_staff_id', $staff_id)
            ->where('notification_status', 0) // only unread
            ->update(['notification_status' => 1]); // mark all as read
    
        return response()->json([
            'status' => 200,
            'message' => 'All notifications cleared successfully',
        ], 200);
    }
    public function ClearSingleNotification(Request $request,$id)
    {
        $notifyId = $id;
    
        if (!$notifyId) {
            return response()->json([
                'status' => 422,
                'message' => 'Notification ID is required',
            ], 422);
        }
    
        $notification = AuditNotificationModel::where('sno', $notifyId)
            ->where('notification_status', 0) // only unread
            ->first();
    
        if (!$notification) {
            return response()->json([
                'status' => 404,
                'message' => 'Notification not found or already cleared',
            ], 404);
        }
    
        $notification->notification_status = 1; // mark as read
        $notification->save();
    
        return response()->json([
            'status' => 200,
            'message' => 'Notification cleared successfully',
        ], 200);
    }

}
