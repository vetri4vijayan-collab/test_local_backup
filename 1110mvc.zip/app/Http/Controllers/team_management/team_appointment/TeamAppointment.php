<?php
namespace App\Http\Controllers\team_management\team_appointment;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamAppointment extends Controller
{

    public function index(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

        // $salesStaff = DB::table('za_staff')
        //     ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
        //     ->where('za_staff.status', 0)
        //     ->where('za_staff.department_id', 1)
        //     ->where('za_staff.branch_id', $branch_id);
        
         $salesStaff = DB::table('za_staff')
            ->select(
                'za_staff.sno',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.gender',
                'za_staff.mobile_no',
                'za_staff.lead_bank_count',
                'za_staff.status as staff_status'
            )
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $year)
                            ->whereMonth('za_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 5)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 6)
                            ->whereYear('za_staff.staff_last_date', '>=', $year)
                            ->whereMonth('za_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 7)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('za_staff.status', 0);
            });
        

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $totalStaff= $salesStaff->count();
        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);
        $totalSuccessRate=0;
        $totalFailureRate=0;

        $totalAllCount=0;
        $totalMonthCount=0;
        $totalCompleted=0;
        $totalcancelled=0;
        $totalPending=0;
        $totalAverageAppointment=0;

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        if ($currentDate->year == $year && $currentDate->month == $month) {
            $endDate = $currentDate;
        } else {
            $endDate = $startDate->copy()->endOfMonth();
        }
        $dayCount = $startDate->diffInDays($endDate) + 1;

        foreach ($salesStaff as $staff) {

            $allAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.staff_id', $staff->sno)
                ->count();

            $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
            ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->where('za_lead_appointment.status', 0)
            ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->count();

            $completedAppointementCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 2)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->count();
                $pendingAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 1)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now())
                ->count();
            $cancelledAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 3)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                 ->where('za_lead_appointment.staff_id', $staff->sno)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->count();

                $successAppointmentRate=0;
                $failAppointmentRate=0;

                $average_Appointment_rate=$dayCount>0 ? $monthAppointmentCount/$dayCount : 0;

               

                $successAppointmentRate=$monthAppointmentCount>0 ? ($completedAppointementCount/$monthAppointmentCount)*100 : 0;
                $failAppointmentRate=$monthAppointmentCount>0 ? ($cancelledAppointmentCount/$monthAppointmentCount)*100 : 0;


                $staff->allAppointmentCount     = $allAppointmentCount;
                $staff->monthAppointmentCount      = $monthAppointmentCount;
                $staff->completedAppointementCount   = $completedAppointementCount;
                $staff->pendingAppointmentCount    = $pendingAppointmentCount;
                $staff->cancelledAppointmentCount        = $cancelledAppointmentCount;
                $staff->successAppointmentRate = $successAppointmentRate;
                $staff->failAppointmentRate = $failAppointmentRate;
                $staff->average_Appointment_rate = $average_Appointment_rate;

            $totalAllCount+=$allAppointmentCount;
            $totalMonthCount+=$monthAppointmentCount;
            $totalCompleted+=$completedAppointementCount;
            $totalcancelled+=$cancelledAppointmentCount;
            $totalPending+=$pendingAppointmentCount;
         
            
            // $totalSuccessRate+=$successAppointmentRate;
            // $totalFailureRate+=$failAppointmentRate;
            
        }

                $totalSuccess=$totalMonthCount>0 ? ($totalCompleted/$totalMonthCount)*100 : 0;
                $totalFailure=$totalMonthCount>0 ? ($totalcancelled/$totalMonthCount)*100 : 0;
                $totalAverageAppointment=$dayCount>0 ? $totalMonthCount/$dayCount : 0;

        // $totalSuccess=$totalStaffCount>0 ? $totalSuccessRate/$totalStaffCount : 0;
        // $totalFailure=$totalStaffCount>0 ? $totalFailureRate/$totalStaffCount : 0;

        // return $salesStaff;
        return view('content.team_management.team_appointment.team_appointment_month', [
            'salesStaff'       => $salesStaff,
            'totalStaff'       => $totalStaff,
            'totalAllCount'       => $totalAllCount,
            'totalMonthCount'       => $totalMonthCount,
            'totalCompleted'       => $totalCompleted,
            'totalcancelled'       => $totalcancelled,
            'totalPending'       => $totalPending,
            'totalSuccess'       => $totalSuccess,
            'totalFailure'       => $totalFailure,
            'dayCount'       => $dayCount,
            'totalAverageAppointment'       => $totalAverageAppointment,
            'month_chk'        => $month_chk,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
        ]);
    }

    //manageteam functions
    public function teamAppointmentToday(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {

            $allAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.staff_id', $staff->sno)
                ->count();

            $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
            ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->where('za_lead_appointment.status', 0)
            ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                   ->where('za_lead_appointment.appointment_date', now()->toDateString())
                ->count();

            $completedAppointementCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 2)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.appointment_date', now()->toDateString())
                
                ->count();
                $pendingAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 1)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.appointment_date', now()->toDateString())
                                ->count();
            $cancelledAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 3)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                   ->where('za_lead_appointment.appointment_date', now()->toDateString())
                ->count();

            $successAppointmentRate=0;
            $failAppointmentRate=0;

            $successAppointmentRate=$monthAppointmentCount>0 ? ($completedAppointementCount/$monthAppointmentCount)*100 : 0;
            $failAppointmentRate=$monthAppointmentCount>0 ? ($cancelledAppointmentCount/$monthAppointmentCount)*100 : 0;


                $staff->allAppointmentCount     = $allAppointmentCount;
                $staff->monthAppointmentCount      = $monthAppointmentCount;
                $staff->completedAppointementCount   = $completedAppointementCount;
                $staff->pendingAppointmentCount    = $pendingAppointmentCount;
                $staff->cancelledAppointmentCount        = $cancelledAppointmentCount;
                $staff->successAppointmentRate = $successAppointmentRate;
                $staff->failAppointmentRate = $failAppointmentRate;
        }

        // return $salesStaff;
        return view('content.team_management.team_appointment.team_appointment_today', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function teamAppointmentTotal(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {

            $allAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.staff_id', $staff->sno)
                ->count();

            $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
            ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->where('za_lead_appointment.status', 0)
            ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                
                ->count();

            $completedAppointementCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 2)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
                
                ->count();
                $pendingAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 1)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->where('za_lead_appointment.branch_id', $branch_id)
               
                ->count();
            $cancelledAppointmentCount = DB::table('za_lead_appointment')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.appointment_status', 3)
                ->where('za_lead_appointment.status', 0)
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                   ->where('za_lead_appointment.staff_id', $staff->sno)
                ->count();

            $successAppointmentRate=0;
            $failAppointmentRate=0;

            $successAppointmentRate=$monthAppointmentCount>0 ? ($completedAppointementCount/$monthAppointmentCount)*100 : 0;
            $failAppointmentRate=$monthAppointmentCount>0 ? ($cancelledAppointmentCount/$monthAppointmentCount)*100 : 0;


                $staff->allAppointmentCount     = $allAppointmentCount;
                $staff->monthAppointmentCount      = $monthAppointmentCount;
                $staff->completedAppointementCount   = $completedAppointementCount;
                $staff->pendingAppointmentCount    = $pendingAppointmentCount;
                $staff->cancelledAppointmentCount        = $cancelledAppointmentCount;
                $staff->successAppointmentRate = $successAppointmentRate;
                $staff->failAppointmentRate = $failAppointmentRate;
        }
        // return $salesStaff;
        return view('content.team_management.team_appointment.team_appointment_all', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }
 
}