<?php
namespace App\Http\Controllers\team_management\team_followup;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamFollowup extends Controller
{

    public function index(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

        // $salesStaff = DB::table('za_staff')
        //     ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
        //     ->where('za_staff.status', 0)
        //     ->where('za_staff.department_id', 1)
        //     ->where('za_staff.branch_id', $branch_id);
         $salesStaff = DB::table('za_staff')
            ->select(
                'za_staff.sno',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.gender',
                'za_staff.mobile_no',
                'za_staff.lead_bank_count',
                'za_staff.status as staff_status'
            )
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $year)
                            ->whereMonth('za_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 5)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 6)
                            ->whereYear('za_staff.staff_last_date', '>=', $year)
                            ->whereMonth('za_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 7)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('za_staff.status', 0);
            });
        

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $totalStaff=$salesStaff->count();

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        $totalSuccessRate=0;
        $totalFailureRate=0;

        $totalAllFollowup=0;
        $totalMonthCount=0;
        $totalCompleted=0;
        $totalRescheduleFollowupCount=0;
        $totalPendingFollowupCount=0;
        $totalAverageFollowup=0;

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        if ($currentDate->year == $year && $currentDate->month == $month) {
            $endDate = $currentDate;
        } else {
            $endDate = $startDate->copy()->endOfMonth();
        }
        $dayCount = $startDate->diffInDays($endDate) + 1;

        foreach ($salesStaff as $staff) {

            $allFollowupCount = DB::table('za_appointment')
                ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
                ->whereIn('za_lead.status', [0,4])
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.created_by', $staff->sno)
                ->count();

            $monthFollowupCount = DB::table('za_appointment')
                ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
               ->whereIn('za_lead.status', [0,4])
                ->where('za_appointment.created_by', $staff->sno)
                ->whereYear('za_appointment.appointment_date', $year)
                ->whereMonth('za_appointment.appointment_date', $month)
                ->count();

              
            $completedFollowupCount = DB::table('za_appointment')
                ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_appointment.status', 4)
                ->whereNotIn('za_lead.status', [2, 5, 6,7])
                ->where('za_appointment.created_by', $staff->sno)
                ->whereYear('za_appointment.appointment_date', $year)
                ->whereMonth('za_appointment.appointment_date', $month)
                ->where('za_appointment.branch_id', $branch_id)->count();
            $rescheduleFollowupCount = DB::table('za_appointment')
                ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)
                ->whereNotIn('za_lead.status', [2, 5, 6,7])
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereYear('za_appointment.appointment_date', $year)
                ->whereMonth('za_appointment.appointment_date', $month)
                ->count();
            $pendingFollowupCount = DB::table('za_appointment')
                ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
                // ->where('za_appointment.progressed', null)
                ->where('za_appointment.status', 1)
               ->whereNotIn('za_lead.status', [2, 5, 6,7])
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.created_by', $staff->sno)
                ->whereYear('za_appointment.appointment_date', $year)
                ->whereMonth('za_appointment.appointment_date', $month)
                ->where('za_appointment.appointment_date', '<=', now()->format('Y-m-d'))
                ->where('za_appointment.appointment_time', '<=', now()->format('H:i'))     
                ->count();

                $successAppointmentRate=0;
                $failAppointmentRate=0;
    
                $successFollowupRate=$monthFollowupCount>0 ? ($completedFollowupCount/$monthFollowupCount)*100 : 0;
                $failFollowupRate=$monthFollowupCount>0 ? ($rescheduleFollowupCount/$monthFollowupCount)*100 : 0;
                $average_followup_rate=$dayCount>0 ? $monthFollowupCount/$dayCount : 0;                       
    
    

            $staff->allFollowupCount     = $allFollowupCount;
            $staff->monthFollowupCount      = $monthFollowupCount;
            $staff->completedFollowupCount   = $completedFollowupCount;
            $staff->rescheduleFollowupCount    = $rescheduleFollowupCount;
            $staff->pendingFollowupCount        = $pendingFollowupCount;
            $staff->successFollowupRate = $successFollowupRate;
            $staff->failFollowupRate = $failFollowupRate;
            $staff->average_followup_rate = $average_followup_rate;

            $totalAllFollowup+=$allFollowupCount;
            $totalMonthCount+=$monthFollowupCount;
            $totalCompleted+=$completedFollowupCount;
            $totalRescheduleFollowupCount+=$rescheduleFollowupCount;
            $totalPendingFollowupCount+=$pendingFollowupCount;
         
        }
        $totalSuccess=$totalMonthCount>0 ? ($totalCompleted/$totalMonthCount)*100 : 0;
        $totalFailure=$totalMonthCount>0 ? ($totalRescheduleFollowupCount/$totalMonthCount)*100 : 0;
        
        $total_staff = count($salesStaff) ?? 0;
        $totalAverageFollowup   = $dayCount > 0  ? round($totalMonthCount / ($total_staff * $dayCount)) : 0;
        
        // $totalAverageFollowup=$dayCount>0 ? $totalMonthCount/$dayCount : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.team_management.team_followup.team_followup_month', [
            'salesStaff'       => $salesStaff,
            'totalSuccess'       => $totalSuccess,
            'totalStaff'       => $totalStaff,
            'totalFailure'       => $totalFailure,
            'totalAllFollowup'       => $totalAllFollowup,
            'totalMonthCount'       => $totalMonthCount,
            'totalCompleted'       => $totalCompleted,
            'totalRescheduleFollowupCount'       => $totalRescheduleFollowupCount,
            'totalPendingFollowupCount'       => $totalPendingFollowupCount,
            'dayCount'       => $dayCount,
            'totalAverageFollowup'       => $totalAverageFollowup,
            'month_chk'        => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
        ]);
    }

    //manageteam functions
    public function teamFollowupToday(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_followup.team_followup_today', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function teamFollowupTotal(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_followup.team_followup_all', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

 

}