<?php
namespace App\Http\Controllers\team_management\team_ftot;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamFollowingTot extends Controller
{



    public function index(Request $request, $month = null, $year = null)
    {


        // return $salesStaff;
        return view('content.team_management.team_ftot.team_following_tot');
    }

    public function teamFtotList(Request $request, $month = null, $year = null)
{
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 10);
    $offset    = ($page - 1) * $perpage;

    $year  = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    if ($month . $year == date('mY') || $year > date('Y')) {
        $month_chk = 0;
    } else {
        $month_chk = 1;
    }

    $lead_fill = $request->input('lead_fill', '');

    $salesStaff = DB::table('za_staff')
        ->select(
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.gender',
            'za_staff.mobile_no',
            'za_staff.lead_bank_count',
            'za_staff.status as staff_status'
        )
        ->where('za_staff.department_id', 1)
        ->where('za_staff.branch_id', $branch_id)
        ->where(function($query) use ($year, $month) {
            $query->where(function($query) use ($year, $month) {
                    $query->where('za_staff.status', 4)
                        ->whereYear('za_staff.notice_end_date', '>=', $year)
                        ->whereMonth('za_staff.notice_end_date', '>=', $month);
                })
                ->orWhere(function($query) use ($year, $month) {
                    $query->where('za_staff.status', 5)
                        ->whereYear('za_staff.updated_at', '>=', $year)
                        ->whereMonth('za_staff.updated_at', '>=', $month);
                })
                ->orWhere(function($query) use ($year, $month) {
                    $query->where('za_staff.status', 6)
                        ->whereYear('za_staff.staff_last_date', '>=', $year)
                        ->whereMonth('za_staff.staff_last_date', '>=', $month);
                })
                ->orWhere(function($query) use ($year, $month) {
                    $query->where('za_staff.status', 7)
                        ->whereYear('za_staff.updated_at', '>=', $year)
                        ->whereMonth('za_staff.updated_at', '>=', $month);
                })
                ->orWhere('za_staff.status', 0);
        });

    if ($lead_fill != '') {
        $salesStaff->where(function ($query) use ($lead_fill) {
            $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
        });
    }
    $total_staff=$salesStaff->count();
    $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        $totalAverageBusinessValue = 0;
        $totalAverageCollectionValue     = 0;
        $totalAverageconvertRatio     = 0;
        $totalconvertRatio     = 0;
        $totalSpamLeadRatio     = 0;
        $totalDeadLeadRatio     = 0;
        $totalAllLead             = 0;
        $totalMonthLead            = 0;
        $totalconvertCustomer            = 0;
        $totalHotLead        = 0;
        $totalSpamLead      = 0;
        $totalDeadLead    = 0;

        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;

        $StaffaverageFtot        = 0;

        foreach ($salesStaff as $staff) {

          // Get all valid leads of this staff in given month/year
          $LeadFtot = DB::table('za_lead')
              ->select('za_lead.sno', 'za_lead.registered_date')
              ->where('za_lead.created_by', $staff->sno)
              ->where('za_lead.branch_id', $branch_id)
              ->whereYear('za_lead.registered_date', $year)
              ->whereMonth('za_lead.registered_date', $month)
              ->where('za_lead.status', 0)
              ->whereNotIn('za_lead.lead_status_id', [3]) // exclude specific status
              ->where('za_lead.spam_verified', 0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status', 0)
              ->get();

          // Initialize counters for fTot calculation
          $sumDays = 0;
          $totalLeads = $LeadFtot->count();

          foreach ($LeadFtot as $singleLead) {
              // Get last follow-up (if exists)
              $lastFollowup = DB::table('za_appointment')
                  ->where('lead_id', $singleLead->sno)
                  ->orderBy('sno', 'desc')
                  ->first();

              if ($lastFollowup) {
                  // Use follow-up date if found
                  $baseDate = Carbon::parse($lastFollowup->appointment_date);
              } else {
                  // Otherwise use registered_date
                  $baseDate = Carbon::parse($singleLead->registered_date);
              }

              // Days difference from last followup/registered_date until today
              $days = $baseDate->diffInDays(Carbon::now());

              $sumDays += $days;
          }

          // Average fTot for this staff
          $averageFtot = $totalLeads > 0 ? round($sumDays / $totalLeads, 2) : 0;

          // Attach to staff object
          $staff->average_fTot = $averageFtot;

            // Loop through each lead and calculate days difference
            foreach ($LeadFtot as $lead) {
                $registeredDate = Carbon::parse($lead->registered_date);
                $diff = $registeredDate->diff(Carbon::now());

                // Convert diff into total days (you can also store y/m separately if needed)
                $days = ($diff->y * 365) + ($diff->m * 30) + $diff->d;

                $sumDays += $days;
            }

            // Average fTot for this staff = total days / number of leads
            $averageFtot = $totalLeads > 0 ? round($sumDays / $totalLeads, 2) : 0;

            // Store into staff object for frontend usage
            $staff->average_fTot = $averageFtot;

            // Example: update totals if needed
            $totalAllLead += $totalLeads;

            $StaffaverageFtot += $averageFtot;



          $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.created_by', $staff->sno)
              ->where('za_lead.branch_id', $branch_id)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status',0)
              ->count();

            $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.created_by', $staff->sno)
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2,6])
            ->where('za_lead.spam_verified',0)
            ->where('za_lead.drop_verified', 0)
            ->where('za_lead.internal_status',0)
            ->count();

            $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.created_by', $staff->sno)
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2,6])
            ->where('za_lead.lead_status_id',3)
            ->where('za_lead.internal_status',0)
            ->where('za_lead.spam_verified',0)
            ->where('za_lead.drop_verified', 0)
            ->count();


            $customerConvertCount = CustomerModel::select('za_customer.sno') ->whereIn('za_customer.status',[0,6])
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
             ->whereIn('za_customer.status',[0,6])
            ->where('za_lead.created_by', $staff->sno)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->count();

            $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.created_by', $staff->sno)
            ->where('za_lead.spam_verified',1)
            ->where('za_lead.branch_id', $branch_id)
            ->where('za_lead.status', 7)->count();

            $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
                ->whereYear('za_lead.registered_date', $year)
                ->whereMonth('za_lead.registered_date', $month)
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.drop_verified', 1)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 5)->count();

            // Spam Ratio
            $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            // Dead ratio
            $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

            // customer ratio
            $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            //acr
            $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
            $averager_convertion_rate = number_format($averager_convertion_rate, 2);


            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($customerConvertCount > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno') ->whereIn('za_customer.status',[0,6])
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                     ->whereIn('za_customer.status',[0,6])
                    ->where('za_lead.created_by', $staff->sno)
                    ->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', $month)
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                      foreach ($currentMonthCustomer as $customer) {

                        $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                      ->where('za_training.customer_id', $customer->sno)
                                      ->where('za_training.tesbo_check', 0)
                                      ->sum('za_training.overall_fees');

                        $total_payment += $payment;


                        $latestTraining = DB::table('za_training')
                            ->where('customer_id', $customer->sno)
                            ->where('tesbo_check', 2)
                            ->orderByDesc('sno')
                            ->first();

                        if ($latestTraining) {
                            $total_payment += $latestTraining->overall_fees;
                        }

                        $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                          ->where('za_training.customer_id', $customer->sno)
                                          ->sum('za_training.paid_amount');

                        $total_paid_payment += $paid_payment;

                      }
                  }


                // average
                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
                $totalAllPayment +=$total_payment;
                $totalAllPaidPayment +=$total_paid_payment;
            }


            $staff->allLeadCount           = $allLeadCount;
            $staff->monthLeadCount       = $monthLeadCount;
            $staff->hotLeadCount        = $hotLeadCount;
            $staff->customerConvertCount      = $customerConvertCount;
            $staff->spamLeadCount            = $spamLeadCount;
            $staff->deadLeadCount      = $deadLeadCount;
            $staff->spam_lead_ratio            = $spam_lead_ratio;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->convertion_rate   = $convertion_rate;
            $staff->averager_convertion_rate   = $averager_convertion_rate;
            $staff->averageBusinessValue = $averageBusinessValue;
            $staff->averageCollectionValue    = $averageCollectionValue;

            // total cal
            $totalAllLead             += $allLeadCount;
            $totalMonthLead            += $monthLeadCount;
            $totalHotLead        += $hotLeadCount;
            $totalconvertCustomer            += $customerConvertCount;
            $totalSpamLead      += $spamLeadCount;
            $totalDeadLead    += $deadLeadCount;


        }

        // Calculate total ratio
    $totalFtotLeadRatio = $total_staff > 0 ? ($StaffaverageFtot / $total_staff) : 0;
    $totalFtotLeadRatio = round($totalFtotLeadRatio);

    $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
    $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);

    $totalDeadLeadRatio = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
    $totalDeadLeadRatio = number_format($totalDeadLeadRatio, 2);

    $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
    $totalconvertRatio = number_format($totalconvertRatio, 2);

    $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
    $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

    $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
    $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;

    $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();

    // return JSON instead of view
    return response()->json([
        'salesStaff'                  => $salesStaff,
        'totalAverageBusinessValue'   => $totalAverageBusinessValue,
        'totalAverageCollectionValue' => $totalAverageCollectionValue,
        'totalAverageconvertRatio'    => $totalAverageconvertRatio,
        'totalconvertRatio'           => $totalconvertRatio,
        'totalDeadLeadRatio'          => $totalDeadLeadRatio,
        'totalSpamLeadRatio'          => $totalSpamLeadRatio,
        'totalDeadLead'               => $totalDeadLead,
        'totalSpamLead'               => $totalSpamLead,
        'totalHotLead'                => $totalHotLead,
        'totalconvertCustomer'        => $totalconvertCustomer,
        'totalMonthLead'              => $totalMonthLead,
        'totalAllLead'                => $totalAllLead,
        'totalFtotLeadRatio'                => $totalFtotLeadRatio,
        'month_chk'                   => $month_chk,
        'Lead_metric_list'            => $Lead_metric_list,
        'perpage'                     => $perpage,
        'lead_fill'                   => $lead_fill,
    ]);
}




}
