<?php
namespace App\Http\Controllers\team_management\team_call;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamCall extends Controller
{


    
    public function index(Request $request, $month = null, $year = null)
{

    // $startTime = microtime(true);
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
    $lead_fill = $request->input('lead_fill', '');

    // Fetch staff data efficiently
    // $salesStaff = DB::table('za_staff')
    //     ->select('sno', 'staff_name', 'staff_image', 'gender', 'mobile_no', 'lead_bank_count')
    //     ->where('status', 0)
    //     ->where('department_id', 1)
    //     ->where('branch_id', $branch_id);
    
     $salesStaff = DB::table('za_staff')
            ->select(
                'za_staff.sno',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.gender',
                'za_staff.mobile_no',
                'za_staff.lead_bank_count',
                'za_staff.status as staff_status',
                'za_cug_management.staff_mobile as cug_mobile','za_department.department_name','za_department.sno as dept_id','za_job_position.job_position_name'
            )
             ->join('za_cug_management','za_staff.sno', '=', 'za_cug_management.staff_id')
             ->join('za_department','za_staff.department_id', '=', 'za_department.sno')
             ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            // ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id)
             ->where('za_cug_management.status', 0)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $year)
                            ->whereMonth('za_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 5)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 6)
                            ->whereYear('za_staff.staff_last_date', '>=', $year)
                            ->whereMonth('za_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('za_staff.status', 7)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('za_staff.status', 0);
            });
        

    if ($lead_fill != '') {
        $salesStaff->where(function ($query) use ($lead_fill) {
            $query->where('staff_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('nick_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('mobile_no', 'LIKE', "%{$lead_fill}%")
                ->orWhere('email_id', 'LIKE', "%{$lead_fill}%");
        });
    }

    $salesStaff = $salesStaff->orderBy('sno', 'desc')->paginate($perpage);
    
    // return $salesStaff;

    // Date range calculation
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
                ? $currentDate 
                : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;

    // Fetch all call stats in ONE query to prevent N+1 queries
    $callData = DB::table('za_call_tracker')
        ->select(
            'branch_staff_id',
            DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
            DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
            DB::raw("SUM(CASE WHEN customer_status = 0 THEN 1 ELSE 0 END) AS unknown_count")
        )
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray()) // Fetch only relevant staff
        ->groupBy('branch_staff_id')
        ->get()
        ->keyBy('branch_staff_id'); // Index by staff ID for fast lookup

    // Initialize total counts
    $total_incoming_call_count = 0;
    $total_outgoingcall_count = 0;
    $total_missedcall_count = 0;
    $total_rejected_call_count = 0;
    $total_unknown_count = 0;

    // Assign call data to staff
    foreach ($salesStaff as $staff) {
        $data = $callData[$staff->sno] ?? (object) [
            'incoming_call_count' => 0,
            'outgoingcall_count' => 0,
            'missedcall_count' => 0,
            'rejected_call_count' => 0,
            'unknown_count' => 0
        ];

        $staff->incoming_call_count = $data->incoming_call_count;
        $staff->outgoingcall_count = $data->outgoingcall_count;
        $staff->missedcall_count = $data->missedcall_count;
        $staff->rejected_call_count = $data->rejected_call_count;
        $staff->unknown_count = $data->unknown_count;

        // Ratios
        $staff->outgoing_call_ratio = $dayCount > 0 ? round($data->outgoingcall_count / $dayCount) : 0;
        $staff->incoming_call_ratio = $dayCount > 0 ? round($data->incoming_call_count / $dayCount) : 0;
        $staff->missed_call_rate = $dayCount > 0 ? round($data->missedcall_count / $dayCount) : 0;

        // Missed call ratio
        $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
        $staff->missed_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

        // Update total counters
        $total_incoming_call_count += $data->incoming_call_count;
        $total_outgoingcall_count += $data->outgoingcall_count;
        $total_missedcall_count += $data->missedcall_count;
        $total_rejected_call_count += $data->rejected_call_count;
        $total_unknown_count += $data->unknown_count;
    }

    // Compute overall ratios
    $total_staff = count($salesStaff) ?? 0;
    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_outgoingcall_count / ($total_staff * $dayCount)) : 0;
    $total_incoming_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_incoming_call_count / ($total_staff * $dayCount)) : 0;
    $total_missed_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_missedcall_count / ($total_staff * $dayCount)) : 0;
        
    // $total_outgoing_call_ratio = $dayCount > 0 ? round($total_outgoingcall_count / $dayCount) : 0;
    // $total_incoming_call_ratio = $dayCount > 0 ? round($total_incoming_call_count / $dayCount) : 0;
    // $total_missed_call_ratio   = $dayCount > 0 ? round($total_missedcall_count / $dayCount) : 0;

    $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
    // $endTime       = microtime(true);
    //     $executionTime = $endTime - $startTime;

    //     return($executionTime);

// return $salesStaff;
    return view('content.team_management.team_call.team_call_month', [
        'salesStaff' => $salesStaff,
        'total_incoming_call_count' => $total_incoming_call_count,
        'total_outgoingcall_count' => $total_outgoingcall_count,
        'total_missedcall_count' => $total_missedcall_count,
        'total_rejected_call_count' => $total_rejected_call_count,
        'total_unknown_count' => $total_unknown_count,
        'total_outgoing_call_ratio' => $total_outgoing_call_ratio,
        'total_incoming_call_ratio' => $total_incoming_call_ratio,
        'total_missed_call_ratio' => $total_missed_call_ratio,
        'dayCount' => $dayCount,
        'month_chk' => $month_chk,
        'Lead_metric_list' => $Lead_metric_list,
        'perpage' => $perpage,
        'lead_fill' => $lead_fill,
         'month' => $month,
          'year' => $year,
    ]);
}

    

    //call today functions
    public function teamCallToday(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_call.team_call_today', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function teamCallTotal(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_call.team_call_all', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }


}