<?php

namespace App\Http\Controllers\team_management\team_cloud_call;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamCloudCall extends Controller
{

    public function index(Request $request, $month = null, $year = null)
    {
        $startTime = microtime(true);
        $branch_id = $request->user()->branch_id;
        $role_id = $request->user()->role_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;

        $year = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        $lead_fill = $request->input('lead_fill', '');

        // Date range calculation
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $salesStaff = DB::table('za_cug_management')
            ->select('za_cug_management.staff_id', 'za_staff.sno', 'za_staff.staff_name', 'za_staff.mobile_no', 'za_staff.staff_image', 'za_staff.gender', 'za_cug_management.staff_mobile', 'za_department.department_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
            ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->distinct('za_cug_management.staff_id')
            // ->where('za_staff.status', '!=', 2)
            ->where('za_staff.branch_id', $branch_id)
            ->where('za_department.sno', 1)
            ->where(function ($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function ($query) use ($year, $month) {
                    $query->where('za_staff.status', 4)
                        ->whereYear('za_staff.notice_end_date', '>=', $year)
                        ->whereMonth('za_staff.notice_end_date', '>=', $month);
                })
                    // Add conditions for status 5
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('za_staff.status', 5)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('za_staff.status', 6)
                            ->whereYear('za_staff.staff_last_date', '>=', $year)
                            ->whereMonth('za_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('za_staff.status', 7)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('za_staff.status', 0);
            });
        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_cug_management.staff_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $staffMobiles = $salesStaff->pluck('staff_mobile')->toArray();

        $salesStaff = $salesStaff->orderBy('za_cug_management.sno', 'desc')->paginate($perpage);

        // $callData = DB::table('za_cloud_call')
        //     ->select(
        //         DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw')) AS contact_number_raw"),
        //         DB::raw("SUM(CASE WHEN action = 'received' THEN 1 ELSE 0 END) AS received_call_count"),
        //         DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
        //     )
        //     ->whereYear('start_time', $year)
        //     ->whereMonth('start_time', $month)
        //     ->whereNotNull(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))")) // Ensure no NULL values
        //     ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"), $staffMobiles) // Filtering by staff mobiles
        //     ->groupBy(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"))
        //     ->get()
        //     ->keyBy('contact_number_raw');

        $callData1 = DB::table('za_cloud_call')
            ->select(
                DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw')) AS contact_number_raw"),
                DB::raw("SUM(CASE WHEN action = 'received' THEN 1 ELSE 0 END) AS received_call_count"),
                DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
            )
            ->whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->where('call_app', 0)
            ->whereNotNull(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))")) // Ensure no NULL values
            ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"), $staffMobiles) // Filtering by staff mobiles
            ->groupBy(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"))
            ->get()
            ->keyBy('contact_number_raw');

        $normalizedStaffMobiles = array_map(function ($mobile) {
            return substr(preg_replace('/\D/', '', $mobile), -10);
        }, $staffMobiles);

        $callData2 = DB::table('za_cloud_call')
            ->select(
                DB::raw("RIGHT(received_by, 10) AS contact_number_raw"),
                DB::raw("SUM(CASE WHEN action = 'completed' THEN 1 ELSE 0 END) AS received_call_count"),
                DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
            )
            ->whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->where('call_app', 1)
            ->whereIn(
                DB::raw("RIGHT(received_by, 10)"),
                $normalizedStaffMobiles
            )
            ->groupBy(DB::raw("RIGHT(received_by, 10)"))
            ->get()
            ->keyBy('contact_number_raw');

        $callData = collect();

        foreach ([$callData1, $callData2] as $dataset) {
            foreach ($dataset as $mobile => $row) {
                if (!isset($callData[$mobile])) {
                    $callData[$mobile] = (object) [
                        'received_call_count' => 0,
                        'missed_call_count' => 0,
                    ];
                }

                $callData[$mobile]->received_call_count += $row->received_call_count;
                $callData[$mobile]->missed_call_count   += $row->missed_call_count;
            }
        }


        $unattend_count = DB::table('za_cloud_call')
            ->whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->whereNull('action') // Correct way to check NULL in Laravel
            ->where('status', 2)
            ->where('branch_id', $branch_id)
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('za_lead')
                    ->whereRaw("RIGHT(za_cloud_call.caller_number, 10) = za_lead.lead_mobile");
            })
            ->count();


        // Initialize total counts
        $total_received_call_count = 0;
        $total_missed_call_count = 0;
        $total_staff_call_count = 0;
        $total_received_call_rate = 0;
        $total_missed_call_rate = 0;

        // Assign call data to staff
        foreach ($salesStaff as $staff) {
            $data = $callData[$staff->staff_mobile] ?? (object) [
                'received_call_count' => 0,
                'missed_call_count' => 0,
            ];

            $staff_total_calls = ($data->received_call_count + $data->missed_call_count);
            $staff->month_total_call_count = $staff_total_calls;
            $staff->received_call_count = $data->received_call_count;
            $staff->missed_call_count = $data->missed_call_count;
            $staff->missed_call_ratio = 0;
            $staff->received_call_ratio = 0;
            $staff->missed_call_rate = 0;
            $staff->received_call_rate = 0;

            // Answer Rate = (Received Calls / Total Calls) * 100
            // Missed Call Rate = (Missed Calls / Total Calls) * 100
            $staff->missed_call_rate = $staff_total_calls > 0 ? ($data->missed_call_count / $staff_total_calls) * 100 : 0;
            $staff->received_call_rate =  $staff_total_calls > 0 ? ($data->received_call_count / $staff_total_calls) * 100 : 0;
            // $staff->missed_call_rate = $dayCount > 0 ? $data->missedcall_count / $dayCount : 0;

            // // Missed call ratio
            // $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
            // $staff->missed_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

            // Update total counters
            $total_received_call_count += $data->received_call_count;
            $total_missed_call_count += $data->missed_call_count;
            $total_staff_call_count += $staff_total_calls;
        }
        // return $salesStaff;
        // Compute overall ratios
        // $total_outgoing_call_ratio = $dayCount > 0 ? $total_outgoingcall_count / $dayCount : 0;
        $total_received_call_rate =  $total_staff_call_count > 0 ? ($total_received_call_count / $total_staff_call_count) * 100 : 0;
        $total_missed_call_rate =  $total_staff_call_count > 0 ? ($total_missed_call_count / $total_staff_call_count) * 100 : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        $endTime       = microtime(true);
        $executionTime = $endTime - $startTime;

        return view('content.team_management.team_cloud_call.team_cloud_call_month', [
            'salesStaff' => $salesStaff,
            'unattend_count' => $unattend_count,
            'total_received_call_count' => $total_received_call_count,
            'total_missed_call_count' => $total_missed_call_count,
            'total_received_call_rate' => $total_received_call_rate,
            'total_missed_call_rate' => $total_missed_call_rate,
            'total_staff_call_count' => $total_staff_call_count,
            'dayCount' => $dayCount,
            'month_chk' => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage' => $perpage,
            'lead_fill' => $lead_fill,
            'year' => $year,
            'month' => $month,
        ]);
    }
    //manageteam functions
    public function teamCloudCallToday(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_cloud_call.team_cloud_call_today', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function teamCloudCallTotal(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_appointment')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->whereNotIn('za_appointment.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_appointment')->select('za_appointment.*')
                ->where('za_appointment.created_at', now()->toDateString())
                ->where('za_appointment.created_by', $staff->sno)
                ->where('za_appointment.branch_id', $branch_id)
                ->where('za_appointment.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_appointment', 'za_appointment.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_appointment.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        // return $salesStaff;
        return view('content.team_management.team_cloud_call.team_cloud_call_all', [
            'salesStaff' => $salesStaff,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }
}
