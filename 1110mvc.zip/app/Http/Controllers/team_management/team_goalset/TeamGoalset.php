<?php

namespace App\Http\Controllers\team_management\team_goalset;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class TeamGoalset extends Controller
{


    public function Index()
    {
        return view('content.team_management.team_goalset.team_goalset');
    }
    // Fetch Departments based on Branch
    public function getDepartmentsGoal(Request $request)
    {

        $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
        return response()->json(['status' => 200, 'data' => $departments]);
    }


    public function getTeamGoal(Request $request)
    {
        $branchId = $request->user()->branch_id;
        $departmentId = $request->department_id;
        $month_id = $request->month_id;

        // Convert month name to number if necessary
        if (!empty($request->month_id)) {
            if (!is_numeric($request->month_id)) {
                $monthNumber = date('m', strtotime($request->month_id . ' 1'));
                // $request->month_id = (int) $monthNumber;
            } else {
                // $request->month_id = (int) $request->month_id;
            }
        }

        // Fetch the department details
        $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

        // Get goal records for the selected department and month
        $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
            ->where('branch_id', $branchId)
            ->where('team_goal_month', $request->month_id)
            ->first();
        // return $request->month_id;
        // Prepare goal details response
        $goalteamDetails = [
            'department_name' => $department->department_name ?? '',
            'department_id'   => $department->sno ?? '',
            'team_id'         => $goalteam->sno ?? '',
            'cr_over_all'     => $goalteam->cr_over_all ?? 0,
            'cr_check'        => $goalteam->cr_check ?? 0,
            'cr_type'         => $goalteam->cr_type ?? 0,
            'abv_over_all'    => $goalteam->abv_over_all ?? 0,
            'abv_check'       => $goalteam->abv_check ?? 0,
            'abv_type'        => $goalteam->abv_type ?? 0,
            'acv_over_all'    => $goalteam->acv_over_all ?? 0,
            'acv_check'       => $goalteam->acv_check ?? 0,
            'acv_type'        => $goalteam->acv_type ?? 0,
            'avg_call_out_over_all' => $goalteam->avg_call_out_over_all ?? 0,
            'avg_call_out_check'    => $goalteam->avg_call_out_check ?? 0,
            'avg_call_out_type'     => $goalteam->avg_call_out_type ?? 0,
            'no_of_walk_over_all'   => $goalteam->no_of_walk_over_all ?? 0,
            'no_of_walk_check'      => $goalteam->no_of_walk_check ?? 0,
            'no_of_walk_type'       => $goalteam->no_of_walk_type ?? 0,
            'status' => isset($goalteam) && $goalteam->status == 1 ? 'Goal Set' : 'Pending',
            'month'  => $month_id
        ];

        return response()->json([
            'status' => 200,
            'data'   => $goalteamDetails
        ]);
    }



    public function saveTeamGoal(Request $request)
    {
        // Validate incoming data
        $validatedData = $request->validate([
            'cr_over_all'             => 'nullable|numeric',
            'cr_check'                => 'nullable|numeric',
            'cr_type'                 => 'nullable|numeric',
            'abv_over_all'            => 'nullable|numeric',
            'abv_check'               => 'nullable|numeric',
            'abv_type'                => 'nullable|numeric',
            'acv_over_all'            => 'nullable|numeric',
            'acv_type'                => 'nullable|numeric',
            'acv_check'               => 'nullable|numeric',
            'avg_call_out_over_all'   => 'nullable|numeric',
            'avg_call_out_check'      => 'nullable|numeric',
            'avg_call_out_type'       => 'nullable|numeric',
            'no_of_walk_over_all'     => 'nullable|numeric',
            'no_of_walk_check'        => 'nullable|numeric',
            'no_of_walk_type'         => 'nullable|numeric',
        ]);

        $branchId = $request->user()->branch_id;
        $departmentId = $request->department_id;
        $month_id = $request->month_id;
        $createdBy = $request->user()->user_id;
        //  return $request->all();
        if (!empty($month_id)) {
            if (!is_numeric($month_id)) {
                // Convert month name (e.g., "February") to its numeric value
                $monthNumber = date('m', strtotime($month_id . ' 1'));
                $request->merge(['month_id' => (int)$monthNumber]);
            } else {
                // Ensure month_id is an integer if it's already numeric
                $request->merge(['month_id' => (int)$month_id]);
            }
        }

        // Update or create the goal record
        $goal = GoalSetTeamModel::updateOrCreate(
            [
                'team_goal_month' => $request->month_id,
                'branch_id'       => $branchId,
                'department_id'   => $departmentId,
            ],
            [
                'cr_over_all'            => $validatedData['cr_over_all'] ?? 0,
                'cr_check'               => $validatedData['cr_check'] ?? null,
                'cr_type'                => $validatedData['cr_type'] ?? null,
                'abv_over_all'           => $validatedData['abv_over_all'] ?? 0,
                'abv_check'              => $validatedData['abv_check'] ?? null,
                'abv_type'               => $validatedData['abv_type'] ?? null,
                'acv_over_all'           => $validatedData['acv_over_all'] ?? 0,
                'acv_type'               => $validatedData['acv_type'] ?? null,
                'acv_check'              => $validatedData['acv_check'] ?? null,
                'avg_call_out_over_all'  => $validatedData['avg_call_out_over_all'] ?? 0,
                'avg_call_out_check'     => $validatedData['avg_call_out_check'] ?? null,
                'avg_call_out_type'      => $validatedData['avg_call_out_type'] ?? null,
                'no_of_walk_over_all'    => $validatedData['no_of_walk_over_all'] ?? 0,
                'no_of_walk_check'       => $validatedData['no_of_walk_check'] ?? null,
                'no_of_walk_type'        => $validatedData['no_of_walk_type'] ?? null,
                'created_by'             => $createdBy,
                'updated_by'             => $createdBy,
                'status'                 => 1 // Mark as 'Goal Set'
            ]
        );

        return response()->json([
            'status' => 200,
            'message' => 'Team goal successfully updated!',
            'data' => $goal
        ]);
    }

    public function getStaffGoal(Request $request)
    {
        $branchId = $request->user()->branch_id;
        $departmentId = $request->department_id;
        $month_id = $request->month_id;

        if (!empty($month_id)) {
            if (!is_numeric($month_id)) {
                // Convert month name (e.g., "February") to its numeric value
                $monthNumber = date('m', strtotime($month_id . ' 1'));
                $request->merge(['month_id' => (int)$monthNumber]);
            } else {
                // Ensure month_id is an integer if it's already numeric
                $request->merge(['month_id' => (int)$month_id]);
            }
        }


        //  return $request->all();
        // return $request->month_id;
        // Get staff members with department and role details
        $staff = StaffModel::where('za_staff.branch_id', $branchId)
            ->where('za_staff.department_id', $departmentId)
            ->where('za_staff.status', 0)
            ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
            ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
            ->get([
                'za_staff.sno',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image',
                'za_department.department_name',
                'za_user_role.role_name'
            ]);
        $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', $departmentId)->where('za_goal_set_team.branch_id', $branchId)
            ->where('za_goal_set_team.team_goal_month', $request->month_id)
            ->first();
        // Get goal records for the selected department and month
        $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $departmentId)->where('za_goal_set_staff.branch_id', $branchId)
            ->where('za_goal_set_staff.goal_month', $request->month_id)
            ->get();
        // return $goalsetRecords;
        // Convert goalsetRecords to an associative array for easy lookup
        $goalsetData = [];
        foreach ($goalsetRecords as $goal) {
            $goalsetData[$goal->staff_id] = $goal;
        }

        // Attach goal details to staff members
        $staffDetails = [];
        foreach ($staff as $member) {
            $staffDetails[] = [
                'sno'           => $member->sno,
                'staff_name'    => $member->staff_name,
                'nick_name'     => $member->nick_name,
                'gender'        => $member->gender,
                'staff_image'   => $member->staff_image,
                'cr_check'       => $goalsetteam->cr_check ?? 0,
                'abv_check'       => $goalsetteam->abv_check ?? 0,
                'acv_check'       => $goalsetteam->acv_check ?? 0,
                'avg_call_out_check'       => $goalsetteam->avg_call_out_check ?? 0,
                'no_of_walk_check'       => $goalsetteam->no_of_walk_check ?? 0,
                'department_name' => $member->department_name, // Fetched directly from join
                'role_name'     => $member->role_name, // Fetched directly from join
                'team_id'            => $goalsetData[$member->sno]->team_id ?? '',
                'cr'            => $goalsetData[$member->sno]->CR ?? '',
                'abv'           => $goalsetData[$member->sno]->ABV ?? '',
                'acv'           => $goalsetData[$member->sno]->ACV ?? '',
                'avg_call_out'  => $goalsetData[$member->sno]->avg_call_out ?? '',
                'no_of_walk'    => $goalsetData[$member->sno]->no_of_walk ?? '',
                'status' => isset($goalsetData[$member->sno])
                    ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending')
                    : 'Pending',
                'month'         => $month_id
            ];
        }

        return response()->json([
            'status' => 200,
            'data' => $staffDetails
        ]);
    }


    public function addOrUpdateStaffGoal(Request $request)
    {
        // Convert month name to numeric format
        $monthName = $request->input('month_id');
        $monthNumber = date('m', strtotime($monthName . ' 1')); // Converts "February" to "02"

        // Replace month_id in the request before validation
        $request->merge(['month_id' => (int)$monthNumber]);
        $validatedData = $request->validate([
            'team_id' => 'required|integer',
            'month_id' => 'required|integer',
            'year' => 'required|integer',
            'department_id' => 'required|integer',
            'staff_goals' => 'required|array',
            'staff_goals.*.staff_id' => 'required|integer',
            'staff_goals.*.cr' => 'nullable|integer',
            'staff_goals.*.abv' => 'nullable|integer',
            'staff_goals.*.acv' => 'nullable|integer',
            'staff_goals.*.avg_call_out' => 'nullable|integer',
            'staff_goals.*.no_of_walk' => 'nullable|integer',
        ]);

        $branchId = $request->user()->branch_id;
        $departmentId = $validatedData['department_id'];
        $month = $validatedData['month_id'];
        $year = $validatedData['year'];
        $team_id = $validatedData['team_id'];
        $createdBy = $request->user()->user_id;
        // return $request->all();
        $branch_check = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        // Generate team ID only if needed
        // $team_check = GoalSetStaffModel::orderBy('sno', 'desc')->first();
        // $year = date("Y");

        // if (!$team_check) {
        //     $team_id = $year . '/' . $branch_code . '/' . "TEM0001";
        // } else {
        //     $data = $team_check->team_id;
        //     $slice = explode("/", $data);
        //     $result = preg_replace('/[^0-9]/', '', $slice[2]);
        //     $next_number = (int)$result + 1;
        //     $request_pay = sprintf("TEM%04d", $next_number);
        //     $team_id = $year . '/' . $branch_code . '/' . $request_pay;
        // }

        // Loop through staff goals
        foreach ($validatedData['staff_goals'] as $goalData) {
            // Check if a record already exists
            $existingRecord = GoalSetStaffModel::where([
                'goal_month' => $month,
                'goal_date' => "{$year}-{$month}-{$month}",
                'branch_id' => $branchId,
                'department_id' => $departmentId,
                'staff_id' => $goalData['staff_id'],
            ])->first();

            // If record exists, use existing team_id; otherwise, assign a new one
            $assignedTeamId = $existingRecord ? $existingRecord->team_id : $team_id;

            GoalSetStaffModel::updateOrCreate(
                [
                    'goal_month' => $month,
                    'goal_date' => "{$year}-{$month}-{$month}",
                    'branch_id' => $branchId,
                    'department_id' => $departmentId,
                    'staff_id' => $goalData['staff_id'],
                ],
                [
                    'team_id' => $assignedTeamId,
                    'CR' => $goalData['cr'] ?? 0,
                    'ABV' => $goalData['abv'] ?? 0,
                    'ACV' => $goalData['acv'] ?? 0,
                    'avg_call_out' => $goalData['avg_call_out'] ?? 0,
                    'no_of_walk' => $goalData['no_of_walk'] ?? 0,
                    'created_by' => $createdBy,
                    'updated_by' => $createdBy,
                    'status' => 1, // Default status
                ]
            );
        }


        return response()->json([
            'status' => 200,
            'message' => 'Goals updated successfully'
        ]);
    }
}