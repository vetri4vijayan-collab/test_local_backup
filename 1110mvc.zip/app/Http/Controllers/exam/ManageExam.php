<?php

namespace App\Http\Controllers\exam;

use App\Http\Controllers\Controller;
use App\Models\ExamersExportModel;
use App\Models\ExamModel;
use App\Models\LeadExportModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\TypeofExamModel;
use App\Models\ExamProcessModel;
use App\Models\StaffModel;

use App\Models\Student;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Auth; // Add this line
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
// use App\Models\ExamModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class ManageExam extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    
    $exam_list = ExamModel::select(
      'za_exam.sno',
      'za_exam.exam_name',
      'za_exam.exam_type',
      'za_exam.is_group',
      'za_exam.multi_exam_ids',
      'za_exam.exam_based_on',
      'za_exam.exam_start_date',
      'za_exam.exam_end_date',
      'za_exam.no_of_questions',
      'za_exam.status',
      'za_exam.created_at',
      'za_exam.exam_question_ids',
      'za_exam.exam_id',
      'za_exam.question_bank_id',
      'za_exam.question_generate',
      'za_type_of_exam.type_of_exam_name',
      DB::raw('COUNT(za_exam_question.sno) AS available_question_count')
    )
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->leftJoin('za_exam_question', 'za_exam_question.question_bank_id', '=', 'za_exam.question_bank_id')
      ->leftJoin('za_type_of_exam', 'za_type_of_exam.sno', '=', 'za_exam.exam_type')
      ->where('za_exam.status', '!=', 2);

    if ($branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $branch_id);
    }

    // Group by to ensure the COUNT works correctly with other fields.
    $exam_list = $exam_list->groupBy(
      'za_exam.sno',
      'za_exam.created_at',
      'za_exam.exam_name',
      'za_exam.exam_type',
      'za_exam.is_group',
      'za_exam.multi_exam_ids',
      'za_exam.exam_based_on',
      'za_exam.exam_start_date',
      'za_exam.exam_end_date',
      'za_exam.no_of_questions',
      'za_exam.status',
      'za_exam.exam_id',
      'za_exam.exam_question_ids',
      'za_exam.question_bank_id',
      'za_exam.question_generate',
      'za_exam_question_bank.question_bank_name',
      'za_type_of_exam.type_of_exam_name'
    )
      ->orderBy('za_exam.sno', 'desc');
      
      if ($cus_fill) {
        $exam_list->where(function ($customer) use ($cus_fill) {
            $customer->where( 'za_exam.is_group', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_exam_question_bank.question_bank_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_exam.exam_based_on', 'LIKE', "%{$cus_fill}%")
                ->orWhere( 'za_exam.exam_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere( 'za_exam.exam_type', 'LIKE', "%{$cus_fill}%")
                ->orWhere(  'za_type_of_exam.type_of_exam_name', 'LIKE', "%{$cus_fill}%");
        });
    }

    // Now paginate the result once.
    $exam_list = $exam_list->paginate($perpage);

    $pageConfigs = ['myLayout' => 'default'];



    $pageConfigs = ['myLayout' => 'default'];
    return view('content.exam.manage_exam.exam_list', [
      'exam_list' => $exam_list,
      'pageConfigs' => $pageConfigs,
      'perpage' => $perpage,
      'cus_fill' => $cus_fill,
      'exam_fill' => '',
      'based_on_fill' => '',
      'exam_type' => '',
      'exam_mode' => '',
      'knowledge_level' => '',
      'date_filter' => '',
    ])->with('filter_on', false);
  }
  
  public function Exam_list(Request $request)
  {

    // Get exam
    $exams = ExamModel::where('status', 0)->get();

    return response()->json([
      'status' => 200,
      'data' => $exams,
    ]);
  }
  
  public function exam_filter(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $exam_fill = $request->exam_fill ?? '';
    $based_on_fill = $request->based_on_fill ?? '';
    $exam_type = $request->exam_type ?? '';
    $exam_mode = $request->exam_mode ?? '';
    $knowledge_level = $request->knowledge_level ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';


    $exam_list = ExamModel::select('za_exam.sno',  'za_exam.multi_exam_ids', 'za_exam.is_group', 'za_exam.exam_name', 'za_exam.created_at', 'za_exam.exam_based_on', 'za_exam.question_generate', 'za_exam.exam_start_date', 'za_exam.exam_question_ids', 'za_exam.question_bank_id', 'za_exam.exam_end_date', 'za_exam.no_of_questions', 'za_exam.status', 'za_exam.exam_id', 'za_exam_question_bank.question_bank_name', 'za_type_of_exam.type_of_exam_name', DB::raw('COUNT(za_exam_question.sno) AS available_question_count'))
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->leftJoin('za_exam_question', 'za_exam_question.question_bank_id', '=', 'za_exam.question_bank_id')
      ->leftJoin('za_type_of_exam', 'za_type_of_exam.sno', '=', 'za_exam.exam_type')
      ->where('za_exam.status', '!=', 2);



    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $exam_list->whereDate('za_exam.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $exam_list->whereBetween('za_exam.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $exam_list->whereBetween('za_exam.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $exam_list->whereBetween('za_exam.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $exam_list->where('za_exam.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $exam_list->where('za_exam.created_at', '<=', $toDate);
      }
    }


    // Add conditions based on exam_based_on
    if ($exam_fill) {
      $exam_list->where('za_exam.exam_name', $exam_fill);
    }
     if ($based_on_fill == 0 || $based_on_fill == 1) {
      $exam_list->where('za_exam.exam_based_on', $based_on_fill);
    }
    if ($exam_type) {
      $exam_list->where('za_exam.exam_type', $exam_type);
    }
    if ($exam_mode) {
      $exam_list->where('za_exam.exam_mode', $exam_mode);
    }
    if ($knowledge_level) {
      $exam_list->where('za_exam.knowledge_level_id', $knowledge_level);
    }
    if ($branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $branch_id);
    }
    
    if ($cus_fill) {
        $exam_list->where(function ($customer) use ($cus_fill) {
            $customer->where( 'za_exam.is_group', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_exam_question_bank.question_bank_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_exam.exam_based_on', 'LIKE', "%{$cus_fill}%")
                ->orWhere( 'za_exam.exam_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere( 'za_exam.exam_type', 'LIKE', "%{$cus_fill}%")
                ->orWhere(  'za_type_of_exam.type_of_exam_name', 'LIKE', "%{$cus_fill}%");
        });
    }

    $exam_list = $exam_list->groupBy(
      'za_exam.sno',
      'za_exam.exam_name',
      'za_exam.is_group',
      'za_exam.multi_exam_ids',
      'za_exam.created_at',
      'za_exam.exam_based_on',
      'za_exam.exam_start_date',
      'za_exam.question_bank_id',
      'za_exam.question_generate',
      'za_exam.exam_end_date',
      'za_exam.no_of_questions',
      'za_exam.status',
      'za_exam.exam_question_ids',
      'za_exam.exam_id',
      'za_type_of_exam.type_of_exam_name',
      'za_exam_question_bank.question_bank_name'
    );


    $exam_list = $exam_list->orderBy('za_exam.sno', 'desc')->paginate($perpage);

    $pageConfigs = ['myLayout' => 'default'];


    return view('content.exam.manage_exam.exam_list', [
      'exam_list' => $exam_list,
      'pageConfigs' => $pageConfigs,
      'perpage' => $perpage,
      'cus_fill' => $cus_fill,
      'exam_fill' => $exam_fill,
      'based_on_fill' => $based_on_fill,
      'exam_type' => $exam_type,
      'exam_mode' => $exam_mode,
      'knowledge_level' => $knowledge_level,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
    ])->with('filter_on', true);
  }
  
  public function create_exam()
  {
    $exam_list = ExamModel::where('status', 0)->where('is_group', 0)->orderBy('exam_name', 'ASC')->get();
    return view('content.exam.manage_exam.exam_add', [
      'exam_list' => $exam_list
    ]);
  }
  public function create_multi_exam()
  {
    $exam_list = ExamModel::where('status', 0)->where('is_group', 0)->orderBy('exam_name', 'ASC')->get();
    return view('content.exam.manage_exam.multi_exam_add', [
      'exam_list' => $exam_list
    ]);
  }

  public function getChapter(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $course_id = $request->input('course_id');

    // Fetch chapter
    $chapter = ManageCoursesSyllabusModel::where('course_id', $course_id)
      ->where('status', 0)
      ->where('branch_id', $branch_id)
      ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
      ->groupBy('course_chapter_id', 'course_chapter_name')
      ->get();

    return response()->json([
      'status' => 200,
      'data' => $chapter,
    ]);
  }

  public function getSection(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $course_id = $request->input('course_id');
    $course_chapter_id = $request->input('course_chapter_id');

    // Fetch chapter
    $section = ManageCoursesSyllabusModel::where('course_id', $course_id)
      ->where('status', 0)
      ->where('branch_id', $branch_id)
      ->where('course_chapter_id', $course_chapter_id)
      ->select('session_name', 'session_id', DB::raw('MAX(sno) as max_sno'))
      ->groupBy('session_id', 'session_name')
      ->get();
    return response()->json([
      'status' => 200,
      'data' => $section,
    ]);
  }

  public function getQuestionBank(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    // Fetch chapter
    $questionBank = ManageQuestionBankModel::where('status', 0)
      ->where('branch_id', $branch_id)
      ->get();

    return response()->json([
      'status' => 200,
      'data' => $questionBank,
    ]);
  }

  public function getTypeOfExam(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    // Fetch type_of exam
    $type = TypeofExamModel::where('status', 0)
      // ->where('branch_id', $branch_id)
      ->get();

    return response()->json([
      'status' => 200,
      'data' => $type,
    ]);
  }

  public function exam_question_generate(Request $request)
  {



    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'exam_sno' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $sno = $request->exam_sno;
      $qsno = $request->qbank_id;

      $exam_details = ExamModel::where('sno', $sno)->first();
      $question_count = $exam_details->no_of_questions;
      // Fetch exam details
      $exam_details = ExamModel::where('sno', $sno)->first();
      $question_count = $exam_details->no_of_questions ?? 0; // Handle possible null

      // Fetch question bank details
      $qb_details = ManageQuestionBankModel::where('sno', $qsno)->first();

      // Determine if questions should be generated randomly or in sequence
      if ($request->question_generate == 0) {
        // Get random questions limited by $question_count
        $question_details = ManageQuestionModel::select('sno AS question_id')->where('question_bank_id', $qsno)
          ->inRandomOrder()
          ->limit($question_count)
          ->get();
      } else {
        // Get sequential questions limited by $question_count
        $question_details = ManageQuestionModel::select('sno AS question_id')->where('question_bank_id', $qsno)
          ->limit($question_count)
          ->get();
      }


    
      $exam_details->exam_question_ids = json_encode($question_details);
      $exam_details->update();
    //   return $exam_details;
      if ($exam_details) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Exam Question Genarated Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Genarate the Exam Question!',
        ]);
      }

      return redirect('/manage_exam');
    }
  }

   public function Add(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'exam_name' => 'required|max:255',
      'exam_category' => 'required|max:255',
      'bas_on' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $exam_name = $request->exam_name;
      $exam_category = $request->exam_category;
      $exam_based_on = $request->bas_on;
      $question_bank_id = $request->exam_qb_id;
      $exam_type = $request->exam_type;
      $no_of_questions = $request->no_of_questions;
      $exam_duration = $request->exam_duration;
      $exam_start_date = date('Y-m-d H:i:s', strtotime($request->exam_add_st_dt));
      $exam_end_date = date('Y-m-d H:i:s', strtotime($request->exam_add_ed_dt));
      $exam_attempt = $request->exam_add_chk;
      if ($exam_attempt == "unlimited") {
        $no_of_attempt = null;
      } else {
        $no_of_attempt = $request->no_of_attempt;
      }
      $positive_mark_per_quest = $request->positive_mark;
      $negative_mark_per_quest = $request->negative_mark;
      $total_marks = $request->total_marks;
      $passing_marks = $request->passing_marks;
      // $exam_batch = $request->exam_batch;
      if ($request->hints_id_add) {
        $exam_hint = $request->hints_id_add;
        $hint_text = $request->exam_hint;
      } else {
        $exam_hint = 0;
      }
      if ($request->expln_id_add) {
        $exam_explanation = $request->expln_id_add;
        $explanation_text = $request->exam_explanation;
      } else {
        $exam_explanation = 0;
      }
      $question_generate = $request->qb_gen_add_chk;
      $display_total_score = $request->tot_scr_add_chk;
      $display_report = $request->report_add_chk;
      $certificate = $request->certifi_add_chk;
      $display_answers = $request->display_answers_add_chk;
      $display_questbank = $request->display_questbank_add_chk;
      $exam_level = $request->exam_level_add_chk;
      if ($certificate == "yes") {
        $certificate_template = $request->certi_template;
      } elseif ($certificate == "no") {
        $certificate_template = null;
      }
      $exam_mode = $request->exam_mode;
      if ($exam_mode == "paid") {
        $exam_mode_amount = $request->exam_amount;
      }
      if ($exam_mode == "points") {
        $exam_mode_points = $request->exam_points;
      }

      $knowledge_level_id = $request->knowledge_level;
      $exam_description = $request->exam_desc;

      $user_id = $request->user()->user_id;

      if ($request->hasFile('thumbnail_image')) {
        $imageName = idate('B') . rand(1, 50) . '.' . $request->file('thumbnail_image')->extension();
        $destinationPath = public_path('exam_thumbnail');
        // Path to the logos directory
        $request->file('thumbnail_image')->move($destinationPath, $imageName);
        $logo = $imageName;
      } else {
        $logo = '';
      }

      $exam_chk = ExamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$exam_chk) {

        $year = substr(date('y'), -2);
        $exam_id = ' EAEX-0001/' . $year;
      } else {

        $data = $exam_chk->exam_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int) $result + 1;
        $request = sprintf(' EAEX-%04d', $next_number);

        $year = substr(date('y'), -2);
        $exam_id = $request . '/' . $year;
      }
      // return $goalset_description;
      // exit;

      $add_exam = new ExamModel();
      $add_exam->exam_id = $exam_id;
      $add_exam->exam_name = $exam_name;
      $add_exam->is_group = 0;
      $add_exam->exam_category = $exam_category;
      $add_exam->exam_based_on = $exam_based_on;
      $add_exam->question_bank_id = $question_bank_id ?? null;
      $add_exam->exam_type = $exam_type ?? null;
      $add_exam->no_of_questions = $no_of_questions ?? null;
      $add_exam->exam_duration = $exam_duration ?? null;
      $add_exam->exam_start_date = $exam_start_date ?? null;
      $add_exam->exam_end_date = $exam_end_date ?? null;
      $add_exam->exam_attempt = $exam_attempt ?? null;
      $add_exam->no_of_attempt = $no_of_attempt ?? null;
      $add_exam->positive_mark_per_quest = $positive_mark_per_quest ?? null;
      $add_exam->negative_mark_per_quest = $negative_mark_per_quest ?? null;
      $add_exam->total_marks = $total_marks ?? null;
      $add_exam->passing_marks = $passing_marks ?? null;
      // $add_exam->exam_batch = $exam_batch ?? null;
      $add_exam->exam_hint = $exam_hint ?? null;
      $add_exam->hint_text = $hint_text ?? null;
      $add_exam->exam_explanation = $exam_explanation ?? null;
      $add_exam->explanation_text = $explanation_text ?? null;
      $add_exam->question_generate = $question_generate ?? null;
      $add_exam->display_total_score = $display_total_score ?? null;
      $add_exam->display_report = $display_report ?? null;
      $add_exam->certificate = $certificate ?? null;
      $add_exam->display_answers = $display_answers;
      $add_exam->display_questbank = $display_questbank;
      $add_exam->exam_level = $exam_level;
      $add_exam->certificate_template = $certificate_template ?? null;
      $add_exam->exam_mode = $exam_mode ?? null;
      $add_exam->exam_mode_amount = $exam_mode_amount ?? null;
      $add_exam->exam_mode_points = $exam_mode_points ?? null;
      $add_exam->knowledge_level_id = $knowledge_level_id ?? null;
      $add_exam->exam_description = $exam_description ?? null;
      $add_exam->thumbnail_image = $logo ?? null;

      $add_exam->branch_id = $branch_id;
      $add_exam->created_by = $user_id;
      $add_exam->updated_by = $user_id;

      $add_exam->save();

      if ($add_exam) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Exam added Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Exam!',
        ]);
      }

      return redirect('/manage_exam');
    }
  }
  public function Add_multi_exam(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'exam_name' => 'required|max:255',
      'exam_category' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $exam_name = $request->exam_name;
      $exam_category = $request->exam_category;
      $exam_type = $request->exam_type;
      $exam_description = $request->exam_desc;
      $user_id = $request->user()->user_id;

      if ($request->hasFile('thumbnail_image')) {
        $imageName = idate('B') . rand(1, 50) . '.' . $request->file('thumbnail_image')->extension();
        $destinationPath = public_path('exam_thumbnail');
        // Path to the logos directory
        $request->file('thumbnail_image')->move($destinationPath, $imageName);
        $logo = $imageName;
      } else {
        $logo = '';
      }

      $exam_chk = ExamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$exam_chk) {

        $year = substr(date('y'), -2);
        $exam_id = ' EAEX-0001/' . $year;
      } else {

        $data = $exam_chk->exam_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int) $result + 1;
        $request_id = sprintf(' EAEX-%04d', $next_number);

        $year = substr(date('y'), -2);
        $exam_id = $request_id . '/' . $year;
      }
      // return $goalset_description;
      // exit;

      $add_exam = new ExamModel();
      $add_exam->exam_id = $exam_id;
      $add_exam->exam_name = $exam_name;
      $add_exam->exam_category = $exam_category;
      $add_exam->exam_type = $exam_type ?? null;
      $add_exam->exam_description = $exam_description ?? null;
      $add_exam->is_group = 1;
      $add_exam->multi_exam_ids = json_encode($request->multi_exam_id);
      $add_exam->thumbnail_image = $logo ?? null;
      $add_exam->branch_id = $branch_id;
      $add_exam->created_by = $user_id;
      $add_exam->updated_by = $user_id;
      $add_exam->save();

      if ($add_exam) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Multiple Exam added Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Multiple Exam!',
        ]);
      }
      return redirect('/manage_exam');
    }
  }
  public function Edit($id = '')
  {
    // return $id;

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $branch_id = auth()->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }

    $course_list = ManageCoursesModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $exam_list = ExamModel::select('za_exam.*',  'za_exam_question_bank.question_bank_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->where('za_exam.status', '!=', 2);
    if ($branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $branch_id);
    }
    $exam_list = $exam_list->where('za_exam.sno', $decryptedValue)
      ->first();

    // return $exam_list;
    return view('content.exam.manage_exam.exam_edit', [
      'edit' => $exam_list,
      'id' => $decryptedValue,
      'course_list' => $course_list
    ]);
  }
  public function Update(Request $request,)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;


    // Validate the request data
    $validator = Validator::make($request->all(), [
      'exam_name' => 'required|max:255',
      'exam_category' => 'required|max:255',
      'bas_on' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }


    $exam_id = $request->exam_id;
    $exam_name = $request->exam_name;
    $exam_category = $request->exam_category;
    $exam_based_on = $request->bas_on;
    $created_date = now();
    $question_bank_id = $request->exam_qb_id ?? null;
    $exam_type = $request->exam_type ?? null;
    $no_of_questions = $request->no_of_questions ?? null;
    $exam_duration = $request->exam_duration;
    $exam_attempt = $request->exam_add_chk;
    $exam_start_date =  date('Y-m-d H:i:s', strtotime($request->exam_add_st_dt));
    $exam_end_date =  date('Y-m-d H:i:s', strtotime($request->exam_add_ed_dt));
    $no_of_attempt = ($request->exam_add_chk === "unlimited") ? null : $request->no_of_attempt;
    $positive_mark_per_quest = $request->positive_mark;
    $negative_mark_per_quest = $request->negative_mark;
    $total_marks = $request->total_marks;
    $passing_marks = $request->passing_marks;
    // $exam_batch = $request->exam_batch;
    $exam_hint = $request->hints_id_add ?? 0;
    $hint_text = $request->exam_hint ?? null;
    $exam_explanation = $request->expln_id_add ?? 0;
    $explanation_text = $request->exam_explanation ?? null;
    $question_generate = $request->qb_gen_add_chk ?? null;
    $display_total_score = $request->tot_scr_add_chk ?? null;
    $display_report = $request->report_add_chk ?? null;
    $certificate = $request->certifi_add_chk ?? null;
    $display_answers = $request->display_answers_add_chk;
    $display_questbank = $request->display_questbank_add_chk;
    $exam_level = $request->exam_level_add_chk;
    $certificate_template = $request->certi_template ?? null;
    $exam_mode = $request->exam_mode ?? null;
    $exam_mode_amount = $request->exam_amount ?? null;
    $exam_mode_points = $request->exam_points ?? null;
    $knowledge_level_id = $request->knowledge_level ?? null;
    $exam_description = $request->exam_desc ?? null;
    $logo = '';
    if ($request->hasFile('cus_pic')) {
      $imageName = time() . '.' . $request->file('cus_pic')->extension();
      $destinationPath = public_path('exam_thumbnail');
      $request->file('cus_pic')->move($destinationPath, $imageName);
      $logo = $imageName;
    } else {
      $logo = $request->old_cus_pic;
    }
    $exam = ExamModel::where('sno', $exam_id)->first();

    // return $request->hasFile('thumbnail_image');
    // Update the exam record
   // return $exam_id;
    $exam->update([
      'exam_name' => $exam_name,
      'exam_category' => $exam_category,
      'exam_based_on' => $exam_based_on,
      'question_bank_id' => $question_bank_id,
      'exam_type' => $exam_type,
      'exam_attempt' => $exam_attempt,
      'no_of_questions' => $no_of_questions,
      'exam_duration' => $exam_duration,
      'exam_start_date' => $exam_start_date,
      'exam_end_date' => $exam_end_date,
      'no_of_attempt' => $no_of_attempt,
      'positive_mark_per_quest' => $positive_mark_per_quest,
      'negative_mark_per_quest' => $negative_mark_per_quest,
      'total_marks' => $total_marks,
      'passing_marks' => $passing_marks,
      // 'exam_batch' => $exam_batch,
      'exam_hint' => $exam_hint,
      'hint_text' => $hint_text,
      'exam_explanation' => $exam_explanation,
      'explanation_text' => $explanation_text,
      'question_generate' => $question_generate,
      'display_total_score' => $display_total_score,
      'display_report' => $display_report,
      'certificate' => $certificate,
      'display_answers' => $display_answers,
      'display_questbank' => $display_questbank,
      'exam_level' => $exam_level,
      'certificate_template' => $certificate_template,
      'exam_mode' => $exam_mode,
      'exam_mode_amount' => $exam_mode_amount,
      'exam_mode_points' => $exam_mode_points,
      'knowledge_level_id' => $knowledge_level_id,
      'exam_description' => $exam_description,
      'thumbnail_image' => $logo,
      'branch_id' => $branch_id,
      'updated_by' => $request->user()->user_id,
    ]);
    // return $exam;

    // Flash message for the session
    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Exam updated Successfully!',
    ]);

    return redirect('/manage_exam');
  }
  public function Multi_Edit($id = '')
  {
    // return $id;

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $exam_list = ExamModel::select('*')->where('sno', $decryptedValue)->first();

    $exam_drop_list = ExamModel::where('status', 0)->where('is_group', 0)->orderBy('exam_name', 'ASC')->get();

    // return $exam_list;
    return view('content.exam.manage_exam.multi_exam_edit', [
      'edit' => $exam_list,
      'id' => $decryptedValue,
      'exam_list' => $exam_drop_list
    ]);
  }
  public function Update_multi_exam(Request $request,)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'exam_name' => 'required|max:255',
      'edit_sno' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $edit_sno = $request->edit_sno;
      $exam_name = $request->exam_name;
      $exam_category = $request->exam_category;
      $exam_type = $request->exam_type;
      $exam_description = $request->exam_desc;
      $user_id = $request->user()->user_id;

      if ($request->hasFile('cus_pic')) {
        $imageName = idate('B') . rand(1, 50) . '.' . $request->file('cus_pic')->extension();
        $destinationPath = public_path('exam_thumbnail');
        // Path to the logos directory
        $request->file('cus_pic')->move($destinationPath, $imageName);
        $logo = $imageName;
      } else {
        $logo = $request->old_pic ?? '';
      }

      $add_exam =  ExamModel::where('sno', $edit_sno)->first();
      $add_exam->exam_name = $exam_name;
      $add_exam->exam_category = $exam_category;
      $add_exam->exam_type = $exam_type ?? null;
      $add_exam->exam_description = $exam_description ?? null;
      $add_exam->is_group = 1;
      $add_exam->multi_exam_ids = json_encode($request->multi_exam_id);
      $add_exam->thumbnail_image = $logo ?? null;
      $add_exam->branch_id = $branch_id;
      $add_exam->created_by = $user_id;
      $add_exam->updated_by = $user_id;
      $add_exam->save();

      if ($add_exam) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Multiple Exam added Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Multiple Exam!',
        ]);
      }
      return redirect('/manage_exam');
    }
  }
  public function View($id = '')
  {
    // return $id;

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $branch_id = auth()->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }

    $course_list = ManageCoursesModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name', 'za_type_of_exam.type_of_exam_name', 'za_certificate_template.certificate_template_name', 'za_knowledge_level.knowledge_level_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->leftJoin('za_type_of_exam', 'za_type_of_exam.sno', '=', 'za_exam.exam_type')
      ->leftJoin('za_certificate_template', 'za_certificate_template.sno', '=', 'za_exam.certificate_template')
      ->leftJoin('za_knowledge_level', 'za_knowledge_level.sno', '=', 'za_exam.knowledge_level_id')
      ->where('za_exam.status', '!=', 2);
    if ($branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $branch_id);
    }
    $exam_list = $exam_list->where('za_exam.sno', $decryptedValue)->first();

    $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
      ->pluck('question_id')->toArray();

    // Fetch questions with hints, explanations, and options
    $examQuestions = ManageQuestionModel::select('za_exam_question.*')
      ->whereIn('za_exam_question.sno', $examQuestionIds)
      ->where('za_exam_question.status', 0)
      ->get();

    $examiner = Student::select('*')->where('exam_id', $exam_list->sno)->get();
    // return $examiner;



    return view('content.exam.manage_exam.exam_view', [
      'view' => $exam_list,
      'id' => $decryptedValue,
      'questions' => $examQuestions,
      'examiner' => $examiner,
      'course_list' => $course_list
    ]);
  }

  public function student_login()
  {
    return view('content.exam.exam_live.student_login');
  }

  public function authenticateStudent(Request $request)
  {
    $request->validate([
      'email' => 'required|email',
      'password' => 'required',
    ]);

    $email = $request->input('email');
    $password = $request->input('password');

    // Attempt to find the student by email and phone number
    $student = Student::where('email_id', $email)
      ->where('phone_no', $password)
      ->where('status', 0)
      ->first();

    if ($student) {
      // Manually log in the student
      // Auth::login($student);
      Auth::guard('exam')->login($student);
      // Flash a success message for Toastr
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Login successful! Welcome to the exam portal.',
      ]);

      return redirect()->route('exam-rules'); // Redirect to exam rules or dashboard
    }

    // Flash an error message for Toastr
    session()->flash('toastr', [
      'type' => 'error',
      'message' => 'Invalid email or password. Please try again.',
    ]);

    return back();
  }

  public function logoutExam(Request $request)
  {
    Auth::guard('exam')->logout();
    $request->session()->forget('exam_data_key'); // Clear session data
    $request->session()->regenerateToken();
    return redirect()->route('student-login');
  }

  public function student_forgot_password()
  {
    return view('content.courses.exam_live.forgot_password');
  }
  public function student_new_password()
  {
    return view('content.courses.exam_live.new_password');
  }
  public function exam_rules()
  {
    return view('content.exam.exam_live.exam_rules');
  }
  public function welcome_message(Request $request)
  {
    // Get the authenticated student using the 'exam' guard
    $student = Auth::guard('exam')->user(); // Retrieve the authenticated student


    // Display the student's ID (or any other data you need)
    $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->where('za_exam.status', '!=', 2);
    if ($student->branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $student->branch_id);
    }
    $exam_list = $exam_list->where('za_exam.sno', $student->exam_id)
      ->first();

    // return $exam_list;
    return view('content.exam.exam_live.welcome_message', compact('exam_list', 'student'));
  }




  public function exam_live(Request $request)
  {
    // Retrieve the authenticated student
    $student = Auth::guard('exam')->user();

    // Fetch exam details associated with the student
    $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->where('za_exam.status', '!=', 2);

    // Filter by student's branch if applicable
    if ($student->branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $student->branch_id);
    }

    // Retrieve specific exam linked to the student’s exam ID
    $exam_list = $exam_list->where('za_exam.sno', $student->exam_id)->first();

    // Fetch branch information
    $branch = BranchModel::select('za_branch.*')
      ->where('za_branch.sno', $student->branch_id)
      ->where('za_branch.status', '!=', 2)
      ->first();

    // Decode question IDs from exam details
    $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
      ->pluck('question_id')->toArray();

    // Fetch questions with hints, explanations, and options
    $examQuestions = ManageQuestionModel::select('za_exam_question.*')
      ->whereIn('za_exam_question.sno', $examQuestionIds)
      ->where('za_exam_question.status', 0)
      ->get();

    $examProcess = ExamProcessModel::where('exam_id', $student->exam_id)
      ->where('student_id', $student->id)
      ->where('branch_id', $student->branch_id)
      ->first();

    // return $examProcess;

    // Check if $examProcess is not null before accessing its property
    if ($examProcess && isset($examProcess->exam_question_answers_datas)) {
      // If the field is already an array, use it directly
      $savedAnswers = is_array($examProcess->exam_question_answers_datas)
        ? $examProcess->exam_question_answers_datas
        : [];
    } else {
      // Handle the case where no exam process is found or the field is empty
      $savedAnswers = [];
    }
    // Count the number of saved answers
    $countsaved = count($savedAnswers) ?? 0;
    $countnext = $countsaved + 1;  // Set the next question index
    // return count($savedAnswers);
    // Pass all data to the view
    return view('content.exam.exam_live.exam_live', compact('exam_list', 'branch', 'examQuestions', 'savedAnswers', 'examProcess', 'countsaved', 'countnext'));
  }


  public function saveAnswer(Request $request)
  {
    // Find the related exam model to retrieve necessary data
    $examModel = ExamModel::where('sno', $request->exam_id)->first();

    // positive_mark_per_quest
    // Ensure the exam process record exists and initialize `exam_question_answers_datas` with an empty array
    $examProcess = ExamProcessModel::firstOrCreate(
      ['exam_id' => $request->exam_id, 'student_id' => auth()->id()],
      [
        'exam_process_id' => uniqid(),
        'branch_id' => $examModel->branch_id,
        'total_marks' => $examModel->total_marks ?? 0,
        'student_marks' => $examModel->total_marks ?? 0,
        'attempted_not_count' => 0,
        'total_attended_duration' => 0,
        'status' => 1,
        'exam_question_answers_datas' => [], // Initialize with an empty array
        'created_by' => auth()->id(), // Initialize with an empty array
        'updated_by' => auth()->id(), // Initialize with an empty array
      ]
    );

    // Retrieve existing answers or initialize an empty array
    $answers = $examProcess->exam_question_answers_datas ?? [];

    $index = array_search($request->question_id, array_column($answers, 'question_id'));

    if ($index === false) {
      // If the question isn't answered yet, add a new entry
      $answers[] = [
        'question_id' => $request->question_id,
        'answer' => $request->answer_data['answer'],
        'time_spent' => $request->answer_data['time_spent'],
        'correctness' => $this->checkAnswer($request->question_id, $request->answer_data['answer']),
      ];
    } else {
      // If already exists, update the existing answer
      $answers[$index]['answer'] = $request->answer_data['answer'];
      $answers[$index]['time_spent'] = $request->answer_data['time_spent'];
      $answers[$index]['correctness'] = $this->checkAnswer($request->question_id, $request->answer_data['answer']);
    }


    $skipcount = 0;
    $correctcount = 0;
    foreach ($answers as $answer) {
      if ($answer['answer'] === null) {
        $skipcount++;
      }
      if ($answer['correctness'] === 'correct') {
        $correctcount++;
      }
    }
    $examProcess->student_marks =  $correctcount * $examModel->positive_mark_per_quest;
    $notattempt = $examModel->no_of_questions - count($answers);

    // Update the count of attempted questions
    $examProcess->attempted_not_count =  $notattempt + $skipcount;
    // $examProcess->attempted_not_count =  $notattempt;


    // Calculate the total attended duration as a sum of time_spent
    $examProcess->total_attended_duration = array_reduce($answers, function ($carry, $item) {
      return $carry + $item['time_spent'];
    }, 0);
    // Check if the number of attempted questions equals total questions, mark exam as completed
    if (count($answers) == $examModel->no_of_questions) {
      $examProcess->status = 2;  // Mark exam as completed
    }
    // Save the updated answers
    $examProcess->exam_question_answers_datas = $answers;
    $examProcess->save();


    return response()->json(['message' => 'Answer and time saved successfully']);
  }


  public function checkAnswer($questionId, $answer)
  {
    // Logic to check if the answer is correct (you'll need to modify this)
    $question = ManageQuestionModel::find($questionId);
    if ($question->answer == $answer) {
      return 'correct';
    }
    return 'incorrect';
  }
  public function TimeOut(Request $request)
  {

    // Ensure the exam process record exists and initialize `exam_question_answers_datas` with an empty array
    $examProcess = ExamProcessModel::firstOrCreate(
      ['exam_id' => $request->exam_id, 'student_id' => auth()->id()],
      [
        'status' => 2,
        'created_by' => auth()->id(), // Initialize with an empty array
        'updated_by' => auth()->id(), // Initialize with an empty array
      ]
    );
    $examProcess->save();


    return response()->json(['message' => 'Time out successfully']);
  }
  // In your ExamController.php or related controller

  // public function getQuestionStatuses(Request $request)
  // {
  //   $savedAnswers = $request->input('savedAnswers', []);
  //   $examQuestions = ExamProcessModel::where('student_id', auth()->id())->get();
  //   $questionStatuses = [];
  //   $countsaved = 0;
  //   foreach ($examQuestions as $question) {
  //     // Check if `exam_question_answers_datas` is present and contains answers
  //     $answersData = $question->exam_question_answers_datas ?? [];

  //     foreach ($answersData as $answerData) {
  //       $questionId = (string)$answerData['question_id'];

  //       // Check if the answer for the question ID is provided
  //       if (isset($answerData['answer']) && $answerData['answer'] !== null) {
  //         $questionStatuses[$questionId] = 'attempted';
  //         $countsaved = count($answerData['answer']);
  //       } elseif ($savedAnswers) {
  //         $questionStatuses[$questionId] = 'not_attempted';
  //         $countsaved = count($answerData['answer']);
  //       } else {
  //         $questionStatuses[$questionId] = 'to_be_viewed';
  //         $countsaved = count($answerData['answer']);
  //       }
  //     }
  //   }



  //   // return response()->json($questionStatuses);  // Return all question statuses

  //   return response()->json([
  //     'questionStatuses' => $questionStatuses,
  //     'countsaved' => $countsaved
  //   ]);
  // }
  public function getQuestionStatuses(Request $request)
  {
    $savedAnswers = $request->input('savedAnswers', []);
    $examQuestions = ExamProcessModel::where('student_id', auth()->id())->get();
    $questionStatuses = [];
    $questionindex = [];

    foreach ($examQuestions as   $question) {
      $answersData = $question->exam_question_answers_datas ?? [];

      foreach ($answersData as $i => $answerData) {
        $questionId = (string)$answerData['question_id'];
        $questionindex[$i] = $i;
        if (isset($answerData['answer']) && $answerData['answer'] !== null) {
          // Mark as attempted if an answer exists
          $questionStatuses[$questionId] = 'attempted';
        } elseif ($answerData['answer'] == null) {
          // Mark as not_attempted if in savedAnswers but no answer
          $questionStatuses[$questionId] = 'not_attempted';
        } else {
          // Default to to_be_viewed
          $questionStatuses[$questionId] = 'to_be_viewed';
        }
      }
    }
    $countsaved = count($questionStatuses) ?? 0;
    return response()->json([
      'questionStatuses' => $questionStatuses,
      'countsaved' => $countsaved,
      'questionindex' => $questionindex,
    ]);
  }




  public function exam_result()
  {
    // Retrieve the authenticated student
    $student = Auth::guard('exam')->user();

    // Fetch exam details associated with the student
    $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->where('za_exam.status', '!=', 2);

    // Filter by student's branch if applicable
    if ($student->branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $student->branch_id);
    }

    // Retrieve specific exam linked to the student’s exam ID
    $exam_list = $exam_list->where('za_exam.sno', $student->exam_id)->first();

    // Fetch branch information
    $branch = BranchModel::select('za_branch.*')
      ->where('za_branch.sno', $student->branch_id)
      ->where('za_branch.status', '!=', 2)
      ->first();

    // Decode question IDs from exam details
    $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
      ->pluck('question_id')->toArray();

    // Fetch questions with hints, explanations, and options
    $examQuestions = ManageQuestionModel::select('za_exam_question.*')
      ->whereIn('za_exam_question.sno', $examQuestionIds)
      ->where('za_exam_question.status', 0)
      ->get();

    $examProcess = ExamProcessModel::where('exam_id', $student->exam_id)
      ->where('student_id', $student->id)
      ->where('branch_id', $student->branch_id)
      ->first();

    // return $examProcess;

    // Check if $examProcess is not null before accessing its property
    if ($examProcess && isset($examProcess->exam_question_answers_datas)) {
      // If the field is already an array, use it directly
      $savedAnswers = is_array($examProcess->exam_question_answers_datas)
        ? $examProcess->exam_question_answers_datas
        : [];
    } else {
      // Handle the case where no exam process is found or the field is empty
      $savedAnswers = [];
    }

    $totalCorrect = 0;
    $totalIncorrect = 0;

    foreach ($savedAnswers as $answer) {
      // Assuming $question->answer holds the correct answer and $answer['answer'] is the student's answer
      if (isset($answer['answer'])) {
        $isCorrect = ($answer['correctness'] === 'correct');
        if ($isCorrect) {
          $totalCorrect++;
        } else {
          $totalIncorrect++;
        }
      }
    }
    // return $examQuestions;

    return view('content.exam.exam_live.exam_result', compact('exam_list', 'branch', 'examQuestions', 'savedAnswers', 'examProcess', 'totalCorrect', 'totalIncorrect'));
  }
  public function question_answer()
  {
    // Retrieve the authenticated student
    $student = Auth::guard('exam')->user();

    // Fetch exam details associated with the student
    $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
      ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
      ->where('za_exam.status', '!=', 2);

    // Filter by student's branch if applicable
    if ($student->branch_id != 0) {
      $exam_list->where('za_exam.branch_id', $student->branch_id);
    }

    // Retrieve specific exam linked to the student’s exam ID
    $exam_list = $exam_list->where('za_exam.sno', $student->exam_id)->first();

    // Fetch branch information
    $branch = BranchModel::select('za_branch.*')
      ->where('za_branch.sno', $student->branch_id)
      ->where('za_branch.status', '!=', 2)
      ->first();

    $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
      ->pluck('question_id')->toArray();

    // Fetch questions with hints, explanations, and options
    $examQuestions = ManageQuestionModel::select('za_exam_question.*')
      ->whereIn('za_exam_question.sno', $examQuestionIds)
      ->where('za_exam_question.status', 0)
      ->get();
    // Decode question IDs from exam details

    // return $examQuestions;
    // Pass data to the view
    return view('content.exam.exam_live.exam_question_bank', compact('examQuestions'));
  }



  public function Status($id, Request $request)
  {

    $upd_exam = ExamModel::where('sno', $id)->first();
    $upd_exam->status = $request->input('status', 0);
    $upd_exam->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Delete($id)
  {

    $upd_exam = ExamModel::where('sno', $id)->first();
    $upd_exam->status = 2;
    $upd_exam->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function ExamersExportExcel()
  {
    return Excel::download(new ExamersExportModel, 'Examers-sample-export.xlsx'); // Adjust filename and extension as needed
  }
  function generateMixedToken($length = 8)
  {
    // Define the pool of characters: uppercase, lowercase, and digits
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $token = '';
    // Generate the token by randomly selecting characters from the pool
    for ($i = 0; $i < $length; $i++) {
      $token .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $token;
  }
  public function ExamersImport(Request $requestData)
  {
    // Validate request data
    $validator = Validator::make($requestData->all(), [
      'file_import' => 'required|file|mimes:xls,xlsx|max:5120',
      'place_name' => 'required|string',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->all(),
        'data' => null,
      ], 400);
    }

    $file_import = $requestData->file('file_import');
    $place_name = $requestData->input('place_name');
    $exam_id = $requestData->input('exam_id_hidden');

    // [{"exam_id": 12, "exam_status": 0}, {"exam_id": 4, "exam_status": 0}, {"exam_id": 3, "exam_status": 0}]
    $exam_details = ExamModel::where('sno', $exam_id)->first();
    $exam_status = '';
    $certificate_received = '';
    if (isset($exam_details)) {
      if ($exam_details->is_group == 1) {
        $multi_exam_ids = $exam_details->multi_exam_ids ? json_decode($exam_details->multi_exam_ids, true) : []; // Decode JSON string to array
        $exam_status = array_map(function ($exam_id) {
          return [
            'exam_id' => (int) $exam_id,
            'exam_status' => 0,
          ];
        }, $multi_exam_ids);
      }
    }
    
    if (isset($exam_details)) {
      if ($exam_details->is_group == 1) {
        $multi_exam_ids = $exam_details->multi_exam_ids ? json_decode($exam_details->multi_exam_ids, true) : []; // Decode JSON string to array
        $certificate_received = array_map(function ($exam_id) {
          return [
            'exam_id' => (int) $exam_id,
            'exam_certificate' => 0,
          ];
        }, $multi_exam_ids);
      }
    }
    // return $exam_status;
    // Check if the lead group already exists
    $chk = Student::where('place_name', $place_name)->where('exam_id', $exam_id)->where('status', '!=', 2)->first();
    if ($chk) {
      return response()->json([
        'status' => 'error',
        'message' => 'Place name already exists!',
        'error_msg' => ['Place name already exists!'],
      ], 207);
    }

    $data = Excel::toCollection(new Student, $file_import);

    if (!$data || $data->isEmpty() || $data[0]->isEmpty()) {
      return response()->json([
        'status' => 401,
        'message' => 'The uploaded file is empty.',
        'error_msg' => ['The uploaded file is empty.'],
        'data' => null,
      ], 400);
    }

    $errors = [];
    $successfulImports = 0;
    $user_id = $requestData->user()->user_id;
    $branch_id = $requestData->user()->branch_id;

    foreach ($data[0] as $key => $row) {
      if ($key > 0) {  // Skip the header row
        $Examers_name = $row[0] ?? null;
        $Examers_email = $row[1] ?? null;
        $Examers_mobile = $row[2] ?? null;

        if (empty($Examers_name) || empty($Examers_email) || empty($Examers_mobile)) {
          $errors[] = 'Missing required field in row ' . ($key + 1);
          continue;
        }

        // Check for existing mobile number or email
        $chk = Student::where(function ($query) use ($Examers_mobile, $Examers_email) {
          $query->where('phone_no', $Examers_mobile)
            ->orWhere('email_id', $Examers_email);
        })->where('status', '!=', 2)->where('exam_id', $exam_id)->first();

        if ($chk) {
          $errors[] = 'Row ' . ($key + 1) . ' Examer ' . $Examers_name . ': Mobile number or Email already exists!';
          continue;
        }

        $token = $this->generateMixedToken(8);
        // Create new examer
        $new_examer = new Student();
        $new_examer->user_name = ucfirst($Examers_name);
        $new_examer->exam_id = $exam_id;
        $new_examer->email_id = $Examers_email;
        $new_examer->phone_no = $Examers_mobile;
        $new_examer->password_token = $token;
        $new_examer->place_name = $place_name;
        $new_examer->exam_status = json_encode($exam_status);
        $new_examer->certificate_received = empty($certificate_received) ? null : json_encode($certificate_received);
        $new_examer->status = 0;
        $new_examer->branch_id = $branch_id;
        $new_examer->created_by = $user_id;
        $new_examer->updated_by = $user_id;
        // $new_examer->save();
        // return $new_examer;
        if ($new_examer->save()) {
          $successfulImports++;
        } else {
          $errors[] = 'Row ' . ($key + 1) . ': Could not import the Examer ' . $Examers_name . '!';
        }
      }
    }

    $responseMessage = $successfulImports . ' Examer(s) imported successfully.';

    if (!empty($errors)) {
      return response()->json([
        'status' => 'partial_success',
        'message' => $responseMessage,
        'error_msg' => $errors,
      ], 207);
    }

    return response()->json([
      'status' => 'success',
      'message' => $responseMessage,
      'data' => null,
    ], 200);
  }
  public function add_staff(Request $request)
  {
      // Validate the input data
      $validator = Validator::make($request->all(), [
          'staff_id' => 'required|array',
      ]);
  
      // If validation fails, return an error response
      if ($validator->fails()) {
          return response()->json([
              'status' => 'error',
              'message' => $validator->errors(),
          ], 400);
      }
      // return $request;
      // Get request data
      $staff_ids = $request->staff_id; // Array of staff IDs
      $exam_id = $request->exam_id_hidden_staff; // Exam ID
      $branch_id = $request->user()->branch_id; // Branch ID from authenticated user
  
      // return $exam_id;
      // Fetch exam details
      $exam_details = ExamModel::where('sno', $exam_id)->first();
      $exam_status = [];
      $certificate_received = [];
  
      // return $exam_details;
      // Prepare exam status if it's a group exam
      if (isset($exam_details) && $exam_details->is_group == 1) {
          $multi_exam_ids = $exam_details->multi_exam_ids ? json_decode($exam_details->multi_exam_ids, true) : [];
          $exam_status = array_map(function ($exam_id) {
              return [
                  'exam_id' => (int) $exam_id,
                  'exam_status' => 0,
              ];
          }, $multi_exam_ids);
      }
      
      
      if (isset($exam_details) && $exam_details->is_group == 1) {
          $multi_exam_ids = $exam_details->multi_exam_ids ? json_decode($exam_details->multi_exam_ids, true) : [];
          $certificate_received = array_map(function ($exam_id) {
              return [
                  'exam_id' => (int) $exam_id,
                  'exam_certificate' => 0,
              ];
          }, $multi_exam_ids);
      }
      
      // return $exam_status;
  
      // Initialize response data
      $response = [];
  
      // Loop through the staff IDs to process each one
      foreach ($staff_ids as $id) {
          // Fetch staff details
          $staff = StaffModel::select('staff_name', 'email_id')->where('branch_id', $branch_id)
              ->where('status', 0) 
              ->where('sno', $id)
              ->first();
  
          // If staff not found, continue to next ID
          if (!$staff) {
              $response[] = [
                  'staff_id' => $id,
                  'status' => 'error',
                  'message' => 'Staff not found or inactive.',
              ];
              continue;
          }
  
          // Check if the staff_id already exists for this exam in the Student model
          $existing_entry = Student::where('staff_id', $id)
              ->where('exam_id', $exam_id)
              ->where('status', '!=', 2) // Ignore if status is 2 (e.g., deleted)
              ->first();
  
          // If a record already exists, skip and return error for this staff ID
          if ($existing_entry) {
              $response[] = [
                  'staff_id' => $id,
                  'status' => 'error',
                  'message' => 'Staff already exists for this exam.',
              ];
              continue;
          }
  
          // Create a new Student record
          $new_examer = new Student();
          $new_examer->user_name = ucfirst($staff->staff_name);
          $new_examer->exam_id = $exam_id;
          $new_examer->email_id = $staff->email_id;
          $new_examer->phone_no = null;
          $new_examer->password_token = null;
          $new_examer->place_name = null;
          $new_examer->type = 1; // Assuming '1' is for staff
          $new_examer->staff_id = $id;
          $new_examer->username = $staff->user_name;
          $new_examer->password = $staff->password;
          $new_examer->exam_status = empty($exam_status) ? null : json_encode($exam_status);
          $new_examer->certificate_received = empty($certificate_received) ? null : json_encode($certificate_received);
          $new_examer->status = 0;
          $new_examer->branch_id = $branch_id;
          $new_examer->created_by = $request->user()->id;
          $new_examer->updated_by = $request->user()->id;
  
          // Save the new record
          $new_examer->save();
          // return $new_examer;
      }
  
      // Return the response
      return redirect('/manage_exam');
  }
}