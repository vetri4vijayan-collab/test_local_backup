<?php

namespace App\Http\Controllers\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\ManageQuestionBankModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\ManageQuestionModel;
use App\Models\AIQuestionModel;
use App\Services\ChatGPTService;

class ManageQuestionBank extends Controller
{
  protected $chatGPTService;

  public function __construct(ChatGPTService $chatGPTService)
  {
    $this->chatGPTService = $chatGPTService;
  }

  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $customer_fill = $request->input('cus_fill', '');

    // if ($request->user()->user_id != 125) {
    //     return 'Work on Progress';
    // }

    $branch_id = $request->user()->branch_id;

    $query = ManageQuestionBankModel::where('status', '!=', 2);

    if (!empty($customer_fill)) {
        $query->where(function ($q) use ($customer_fill) {
            $q->where('question_bank_name', 'LIKE', "%{$customer_fill}%")
              ->orWhere('question_bank_id', 'LIKE', "%{$customer_fill}%");
        });
    }

    $question_bank_list = $query->orderBy('sno', 'desc')->paginate($perpage);

    return view('content.exam.manage_question_bank.question_bank_list', [
        'question_bank_list' => $question_bank_list,
        'perpage' => $perpage,
        'cus_fill' => $customer_fill,
    ]);
}

  public function askChatGPT_old(Request $request)
  {
    $count = $request->input('question_count', 5);
    $topic = $request->input('question_topic');
    $hint_check = $request->input('hint_check', false);
    $explanations_check = $request->input('explanations_check', false);
    $snippet_check = $request->input('snippet_check', false);
    $bank_id = $request->input('bank_id');

    // Build the prompt dynamically based on user input
    $prompt = "Please provide _count_ {$topic} with answers";

    if ($hint_check) $prompt .= ", hints";
    if ($explanations_check) $prompt .= ", explanations";
    if ($snippet_check) $prompt .= ", and snippet content";

    $prompt .= " in JSON format with the following structure:
                [
                  {
                    \"question\": \"What is OOP?\",
                    \"options\": [\"Option 1\", \"Option 2\", \"Option 3\", \"Option 4\"],
                    \"answer\": \"Option 3\",
                    \"hint\": \"Hint for the question\",
                    \"explanation\": \"Explanation of the answer\",
                    \"snippet\": \"Code snippet or related content here.\"
                  }
                ]";

    // Get the response from ChatGPT
  return  $chatGPTResponse = $this->chatGPTService->getChatGPTResponse($prompt);
    // return $chatGPTResponse;

    if (!is_array($chatGPTResponse)) {
      return response()->json(['error' => 'AI response is not in valid JSON format.'], 500);
    }

    // Initialize counters
    $skippedCount = 0;
    $insertedCount = 0;

    foreach ($chatGPTResponse as $questionData) {
      if (!isset($questionData['question'], $questionData['options'], $questionData['answer'])) {
        continue; // Skip if required fields are missing
      }

      $chk = ManageQuestionModel::where('question_name', $questionData['question'])->first();

      if ($chk) {
        $skippedCount++; // Increment skipped count if duplicate found
        continue;
      }

      // Generate a new question_id
      $question_GET = ManageQuestionModel::orderBy('sno', 'desc')->first();
      if (!$question_GET) {
        $year = substr(date('y'), -2);
        $question_id = 'EAQ-0001/' . $year;
      } else {
        $data = $question_GET->question_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $question_id = sprintf('EAQ-%04d', $next_number) . '/' . substr(date('y'), -2);
      }

      // Create and save the new question
      $question = new ManageQuestionModel();
      $question->question_id = $question_id;
      $question->branch_id = $request->user()->branch_id;
      $question->question_bank_id = $bank_id;
      $question->question_name = $questionData['question'];
      $question->question_type = 'radio_button';
      $question->question_option = json_encode($questionData['options']);
      $question->answer = $questionData['answer'];

      if ($hint_check && isset($questionData['hint'])) {
        $question->question_hint = 1;
        $question->hint_text = $questionData['hint'];
      } else {
        $question->question_hint = 0;
      }

      if ($explanations_check && isset($questionData['explanation'])) {
        $question->question_explanation = 1;
        $question->explanation_text = $questionData['explanation'];
      } else {
        $question->question_explanation = 0;
      }

      if ($snippet_check && isset($questionData['snippet'])) {
        $question->question_snippet = 1;
        $question->snippet_content = $questionData['snippet'];
      } else {
        $question->question_snippet = 0;
      }

      $question->updated_by = $request->user()->user_id;
      $question->created_by = $request->user()->user_id;

      if ($question->save()) {
        $insertedCount++; // Increment inserted count
      }
    }

    // Flash success message with counts
    session()->flash('toastr', [
      'type' => 'success',
      'message' => "AI Questions Processed: {$insertedCount} inserted, {$skippedCount} skipped!"
    ]);

    return redirect('/manage_question_bank');
  }
  
  public function askChatGPT(Request $request)
  {
    
    $count = $request->input('question_count')??5;
    $topic = $request->input('question_topic');
    $hint_check = $request->boolean('hint_check', false);
    $explanations_check = $request->boolean('explanations_check', false);
    $snippet_check = $request->boolean('snippet_check', false);
    $bank_id = $request->input('bank_id');
    
    $previous_questions = ManageQuestionModel::select('question_name')
        ->where('question_bank_id', $bank_id)
        // ->limit(50)
        ->orderBy('sno', 'desc')
        ->pluck('question_name')
        ->toArray();
    $previous_count = count($previous_questions);
    
    // Build the prompt dynamically based on user input
    $prompt = "Please provide _count_ unique {$topic} questions with answers";
    
    // Add additional details if selected
    $additional_details = [];
    if ($hint_check) $additional_details[] = "hints";
    if ($explanations_check) $additional_details[] = "explanations";
    if ($snippet_check) $additional_details[] = "snippet content";
    
    if (!empty($additional_details)) {
        $prompt .= ", including " . implode(", ", $additional_details);
    }
    
    $exampleStructure = [
        "question" => "What is 1+1 ?",
        "options" => ["1", "2", "3", "4"],
        "answer" => "2"
    ];
    
    if ($hint_check) $exampleStructure["hint"] = "Hint for the question";
    if ($explanations_check) $exampleStructure["explanation"] = "Explanation of the answer";
    if ($snippet_check) $exampleStructure["snippet"] = "Code snippet or related content here.";
    
    $prompt .= " in JSON format with the following structure:\n" . json_encode([$exampleStructure], JSON_PRETTY_PRINT);
    
    // Insert AI Table 
    $ai_table = new AIQuestionModel();
    $ai_table->previous_count = $previous_count;
    $ai_table->ask_count = $count;
    $ai_table->completed_count = 0;
    $ai_table->pending_count = $count;
    $ai_table->question_bank_id = $bank_id;
    $ai_table->hint_check = $hint_check;
    $ai_table->explanations_check = $explanations_check;
    $ai_table->snippet_check = $snippet_check;
    $ai_table->prompt = $prompt;
    $ai_table->updated_by = $request->user()->user_id;
    $ai_table->created_by = $request->user()->user_id;
    
    if($ai_table->save()){
        
        // Flash success message with counts
        session()->flash('toastr', [
          'type' => 'success',
          'message' => "AI Questions request created successfully!"
        ]);
        
    }else{
        // Flash success message with counts
        session()->flash('toastr', [
          'type' => 'error',
          'message' => "Failed to create AI Questions. Please try again!"
        ]);
    }
    
    return redirect('/manage_question_bank');
  }
  
  public function chapter_list(Request $request)
  {
    $list = ManageCoursesSyllabusModel::where('status', 0)
      ->where('course_id', $request->course_id)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('course_chapter_id')
      ->map(function ($group) {
        // Assuming each group contains multiple chapters,
        // you can return the first chapter of each group or customize this logic.
        return $group->first();
      })
      ->values(); // To return a flat collection instead of an associative array

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $list
    ], 200);
  }


  public function section_list(Request $request)
  {
    // Retrieve and group by session_id
    $list = ManageCoursesSyllabusModel::where('status', 0)
      ->where('course_chapter_id', $request->course_chapter_id)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('session_id')
      ->map(function ($group) {
        // Customize this as per your requirement
        // Assuming each group contains multiple sections, return the first item of each group
        return $group->first();
      })
      ->values(); // To return a flat collection

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $list
    ], 200);
  }

  public function topic_list(Request $request)
  {

    $list = ManageCoursesSyllabusModel::where('status',  0)->where('course_chapter_id',  $request->course_chapter_id)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $list
    ], 200);
  }

  public function question_bank_add($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageQuestionBankModel::where('sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    return view('content.exam.manage_question_bank.question_bank_add', [
      'view' => $view
    ]);
  }
  public function question_bank_view($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageQuestionBankModel::where('sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    // Get questions if the course is found
    $questions = ManageQuestionModel::where('question_bank_id', $decryptedValue)->where('status', 0)->get();

    // Return the view with the course and questions data
    return view('content.exam.manage_question_bank.question_bank_view', [
      'view' => $view,
      'questions' => $questions
    ]);
  }


 


  public function Status($id, Request $request)
  {

    $upd_ManageQuestionBankModel =  ManageQuestionBankModel::where('sno', $id)->first();
    $upd_ManageQuestionBankModel->status = $request->input('status', 0);
    $upd_ManageQuestionBankModel->update();
    if ($upd_ManageQuestionBankModel) {
      return response([
        'status'    => 200,
        'message'   => 'Question Bank Status Successfully Updated!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Question Bank Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_ManageQuestionBankModel =  ManageQuestionBankModel::where('sno', $id)->first();
    $upd_ManageQuestionBankModel->status  = 2;
    $upd_ManageQuestionBankModel->Update();
    if ($upd_ManageQuestionBankModel) {
      return response([
        'status'    => 200,
        'message'   => 'Course  Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Course !',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Add(Request $request)
  {

    //
    $validator = Validator::make($request->all(), [
      'ques_bank_name' => 'required|max:255',
      'based_on' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $ques_bank_name   = $request->ques_bank_name;
      $chk = ManageQuestionBankModel::where('question_bank_name', ucwords($ques_bank_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Question Bank is exist!'
        ]);
        return redirect()->back();
      } else {
        $question_bank = ManageQuestionBankModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$question_bank) {

          $year = substr(date('y'), -2);
          $question_bank_id = 'EAQB-0001/' . $year;
        } else {

          $data = $question_bank->question_bank_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request_id = sprintf('EAQB-%04d', $next_number);

          $year = substr(date('y'), -2);
          $question_bank_id = $request_id . '/' . $year;
        }
        // return $request;
        $based_on = $request->based_on;

        if ($based_on == 1) {
          $course_id = $request->course_id;
          $chapter_id = $request->chapter_id;
          $section_id = $request->section_id;
          $title = '';
        } else {
          $course_id  = 0;
          $chapter_id = '';
          $section_id = '';
          $title = $request->title;
        }

        $add_question = new ManageQuestionBankModel();
        $add_question->question_bank_id    = $question_bank_id;
        $add_question->branch_id           = $request->user()->branch_id;
        $add_question->question_bank_name  = Ucfirst($ques_bank_name);
        $add_question->based_on            = $based_on;
        $add_question->course_id           = $course_id;
        $add_question->chapter_id          = $chapter_id;
        $add_question->section_id          = $section_id;
        $add_question->title               = $title;
        $add_question->knowledge_level_id  = $request->knowledge_id;
        $add_question->question_count      = 0;
        $add_question->question_bank_desc  = $request->exa_bank_desc;

        $add_question->created_by          = $request->user()->user_id;
        $add_question->updated_by          = $request->user()->user_id;

        $add_question->save();

        if ($add_question) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Question Bank added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Question Bank!'
          ]);
        }
      }
      return redirect('/manage_question_bank');
    }
  }
  
  public function importJson(Request $request)
{
    try {
        $request->validate([
            'file' => 'required|mimes:json,txt|max:2048',
            'question_bank_id' => 'required|integer',
        ]);

        $file = $request->file('file');
        $path = $file->getRealPath();
        $json = json_decode(file_get_contents($path), true);

        if (!$json || !is_array($json)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid JSON format or empty file.'
            ]);
        }

        $inserted = 0;
        $skipped = 0;

        foreach ($json as $task) {
            // Validate essential fields
            if (
                !isset($task['question']) ||
                !isset($task['options']) ||
                !isset($task['answer'])
            ) {
                $skipped++;
                continue;
            }

            // Generate unique question_id
            $latest = DB::table('za_exam_question')
                ->orderBy('sno', 'desc')
                ->first();

            if (!$latest) {
                $year = substr(date('y'), -2);
                $question_id = 'EAQ-0001/' . $year;
            } else {
                $data = $latest->question_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $year = substr(date('y'), -2);
                $question_id = sprintf('EAQ-%04d/%s', $next_number, $year);
            }

            // Prepare fields from JSON
            $question_name        = $task['question'] ?? '';
            $question_option      = json_encode($task['options'] ?? []);
            $answer               = $task['answer'] ?? '';
            $answer_type          = $task['answer_type'] ?? 'radio_button';
            $question_type        = $task['question_type'] ?? 'normal';
            $hint_text            = $task['tip'] ?? null;
            $explanation_text     = $task['explanation'] ?? null;
            $snippet_content      = ($question_type === 'snippet') ? $question_name : null;

            // Insert record
            DB::table('za_exam_question')->insert([
                'question_id'           => $question_id,
                'question_bank_id'      => $request->question_bank_id,
                'question_type'         => $answer_type,
                'question_name'         => $question_name,
                'question_option'       => $question_option,
                'answer'                => $answer,
                'question_hint'         => $hint_text ? 1 : 0,
                'hint_text'             => $hint_text,
                'question_explanation'  => $explanation_text ? 1 : 0,
                'explanation_text'      => $explanation_text,
                'question_snippet'      => $snippet_content ? 1 : 0,
                'snippet_content'       => $snippet_content,
                'branch_id'             => auth()->user()->branch_id ?? null,
                'created_by'            => auth()->user()->user_id ?? null,
                'updated_by'            => auth()->user()->user_id ?? null,
            ]);

            $inserted++;
        }

        return response()->json([
            'status' => true,
            'message' => 'JSON question import completed successfully.',
            'summary' => [
                'inserted' => $inserted,
                'skipped' => $skipped,
                'total' => $inserted + $skipped,
            ]
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => $e->getMessage(),
        ]);
    }
}
public function question_bank_edit($id = '')
{
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // 🛑 If decryption fails
    if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
    }

    // 🧩 Fetch main question bank record
    $view = \App\Models\ManageQuestionBankModel::where('sno', $decryptedValue)->first();

    if (!$view) {
        return redirect()->back()->with('error', 'Question Bank not found');
    }

    // 🧠 Fetch related course, chapter, and session info
    $list = \DB::table('za_course_chapter')
        ->join('za_course', 'za_course.sno', '=', 'za_course_chapter.course_id')
        ->where('za_course_chapter.course_id', $view->course_id)
        ->where('za_course_chapter.course_chapter_id', $view->chapter_id)
        ->where('za_course_chapter.session_id', $view->section_id)
        ->select(
            'za_course.course_name',
            'za_course_chapter.course_chapter_name',
            'za_course_chapter.session_name'
        )
        ->first();

    // 📝 Get all active questions for this bank
    $questions = \App\Models\ManageQuestionModel::where('question_bank_id', $decryptedValue)
        ->where('status', 0)
        ->get();
    // return $view;
    // ✅ Return to Blade view
    return view('content.exam.manage_question_bank.question_bank_edit', [
        'view' => $view,
        'questions' => $questions,
        'list' => $list
    ]);
}

public function fetchQuestionBankData($id)
{
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    if ($decryptedValue === false) {
        return response()->json(['status' => 'error', 'message' => 'Invalid ID'], 400);
    }

    $view = ManageQuestionBankModel::where('sno', $decryptedValue)->first();
    if (!$view) {
        return response()->json(['status' => 'error', 'message' => 'Question Bank not found'], 404);
    }

    $list = \DB::table('za_course_chapter')
        ->join('za_course', 'za_course.sno', '=', 'za_course_chapter.course_id')
        ->where('za_course_chapter.course_id', $view->course_id)
        ->where('za_course_chapter.course_chapter_id', $view->chapter_id)
        ->where('za_course_chapter.session_id', $view->section_id)
        ->select(
            'za_course.course_name',
            'za_course_chapter.course_chapter_name',
            'za_course_chapter.session_name'
        )
        ->first();

    $questions = ManageQuestionModel::where('question_bank_id', $decryptedValue)
        ->where('status', 0)
        ->get();

    return response()->json([
        'status' => 'success',
        'view' => $view,
        'list' => $list,
        'questions' => $questions
    ]);
}

}
