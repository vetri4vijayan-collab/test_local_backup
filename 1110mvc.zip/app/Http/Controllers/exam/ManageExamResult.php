<?php

namespace App\Http\Controllers\exam;

use App\Http\Controllers\Controller;
use App\Models\ExamersExportModel;
use App\Models\ExamModel;
use App\Models\LeadExportModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\TypeofExamModel;
use App\Models\ExamProcessModel;
use App\Models\Student;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Auth; // Add this line
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

// use App\Models\ExamModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class ManageExamResult extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    $exam_result_list = Student::select(
        'students.id',
        'students.exam_status',
        'students.certificate_received',
        'students.branch_id',
        'students.user_name',
        'students.email_id',
        'students.phone_no',
        'students.type',
        'students.place_name',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.staff_image',
        'students.staff_id'
    )
    ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
    ->where('students.status', 0);

    if ($branch_id != 0) {
        $exam_result_list->where('students.branch_id', $branch_id);
    }

    $exam_result_list = $exam_result_list->orderBy('students.id', 'desc')->paginate(10);

    // Modify each record to include exam counts
    $exam_result_list->getCollection()->transform(function ($student) {
        $exams = json_decode($student->exam_status, true);
        $certificate = $student->certificate_received ? json_decode($student->certificate_received, true) : null;

        $total_exam = is_array($exams) ? sprintf('%02d', count($exams)) : '0';
        $completed_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 2)->count()) : '0';
        $balance_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 0)->count()) : '0';
        $certificate_received = is_array($certificate) ? sprintf('%02d', collect($certificate)->where('exam_certificate', 1)->count()) : '0';

        // Add calculated fields to each student record
        $student->total_exam = $total_exam;
        $student->completed_exam = $completed_exam;
        $student->balance_exam = $balance_exam;
        $student->certificate_received = $certificate_received;

        return $student;
    });


      // return $exam_result_list;
      return view('content.exam.manage_exam.exam_result', [
        'exam_result_list' => $exam_result_list,
        'exam_fill' => '',
        'based_on_fill' => '',
        'exam_type' => '',
        'exam_mode' => '',
        'knowledge_level' => '',
        'date_filter' => '',
      ])->with('filter_on', false);
  }


  public function result_view(Request $request, $id)
  {
      $branch_id = $request->user()->branch_id;

      // Fetch student details
      $exam_person = Student::select(
          'students.id',
          'students.exam_status',
          'students.certificate_received',
          'students.branch_id',
          'students.user_name',
          'students.email_id',
          'students.phone_no',
          'students.type',
          'students.place_name',
          'za_staff.staff_name',
          'za_staff.nick_name',
          'za_staff.staff_image',
          'students.staff_id'
      )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
      ->where('students.status', 0)
      ->where('students.id', $id);

      if ($branch_id != 0) {
          $exam_person->where('students.branch_id', $branch_id);
      }

      $exam_person = $exam_person->first();

      // Check if student exists
      if (!$exam_person) {
          return response()->json(['message' => 'Student not found'], 404);
      }

      // Process exam_status JSON
      $exams = json_decode($exam_person->exam_status, true);
      $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();
      $certificate = $exam_person->certificate_received ? json_decode($exam_person->certificate_received, true) : null;
      $exam_person->total_exam = is_array($exams) ? sprintf('%02d', count($exams)) : '00';
      $exam_person->completed_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 2)->count()) : '00';
      $exam_person->balance_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 0)->count()) : '00';
      $exam_person->certificate_received = is_array($certificate) ? sprintf('%02d', collect($certificate)->where('exam_certificate', 1)->count()) : '0';
      // Fetch exam list related to this student
      $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
      $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();

      // Merge both lists while keeping all records from ExamModel
      $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
          $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
          return [
              'exam_id' => $exam->sno,
              'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
              'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
              'certificate' => $exam->certificate ?? null, // Adjust field names as needed
              'device_type' => $exam_process->device_type ?? 2,
              'student_marks' => $exam_process->student_marks ?? null,
              'updated_at' => $exam_process->updated_at ?? null,
              'exam_status' => $exam_process->status ?? 1,
              'student_id' => $exam_process->student_id ?? null,
          ];
      });

      return response()->json([
          'student_details' => $exam_person,
          'exam_list' => $exam_list
      ]);
  }

  public function certificate_view(Request $request, $id)
  {
      $branch_id = $request->user()->branch_id;

      // Fetch student details
      $exam_person = Student::select(
          'students.id',
          'students.exam_status',
          'students.branch_id',
          'students.certificate_received',
          'students.user_name',
          'students.email_id',
          'students.phone_no',
          'students.type',
          'students.place_name',
          'za_staff.staff_name',
          'za_staff.nick_name',
          'za_staff.staff_image',
          'students.staff_id'
      )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
      ->where('students.status', 0)
      ->where('students.id', $id);

      if ($branch_id != 0) {
          $exam_person->where('students.branch_id', $branch_id);
      }

      $exam_person = $exam_person->first();

      // Check if student exists
      if (!$exam_person) {
          return response()->json(['message' => 'Student not found'], 404);
      }

      // Process exam_status JSON
      $exams = json_decode($exam_person->exam_status, true);
      $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();
      $certificate = $exam_person->certificate_received ? json_decode($exam_person->certificate_received, true) : null;
      $exam_person->total_exam = is_array($exams) ? sprintf('%02d', count($exams)) : '00';
      $exam_person->completed_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 2)->count()) : '00';
      $exam_person->balance_exam = is_array($exams) ? sprintf('%02d', collect($exams)->where('exam_status', 0)->count()) : '00';
      $exam_person->certificate_received = is_array($certificate) ? sprintf('%02d', collect($certificate)->where('exam_certificate', 1)->count()) : '0';

      // Fetch exam list related to this student
      $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
      $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();

      // Merge both lists while keeping all records from ExamModel
      $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
          $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
          return [
              'exam_id' => $exam->sno,
              'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
              'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
              'certificate' => $exam->certificate ?? null, // Adjust field names as needed
              'device_type' => $exam_process->device_type ?? 2,
              'student_marks' => $exam_process->student_marks ?? null,
              'updated_at' => $exam_process->updated_at ?? null,
              'exam_status' => $exam_process->status ?? 1,
              'certificate_request' => $exam_process->certificate_request ?? 0,
              'student_id' => $exam_process->student_id ?? null,
          ];
      });

      return response()->json([
          'student_details' => $exam_person,
          'exam_list' => $exam_list
      ]);
  }



  // wget -qO- https://erp.elysium.academy/Cronjob_scheduled_message &> /dev/null

}
