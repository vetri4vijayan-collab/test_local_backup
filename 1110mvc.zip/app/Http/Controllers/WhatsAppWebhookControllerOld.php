<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\WhatsappContactModel;
use App\Models\WhatsappMessageModel;
use App\Events\NewMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsAppSessionManager;
use App\Models\WhatsappApiConfigureModel;
use Illuminate\Support\Facades\Auth;
use App\Models\BranchModel;
use App\Models\ManageCoursesModel;
use App\Models\LeadModel;
use App\Models\StaffModel;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\Validator;



class WhatsAppWebhookController extends Controller
{
    protected $whatsAppConfig;

    public function __construct(WhatsAppConfig $whatsAppConfig)
    {
        $this->whatsAppConfig = $whatsAppConfig;
    }

    // Display chat UI
    public function index()
    {
        $contacts = WhatsappContactModel::with('messages')->get();
        return view('content.whatsapp_chat.whatsapp_chat', compact('contacts'));
    }
    
    public function CustomerChat()
    {
        $contacts = WhatsappContactModel::with('messages')->get();
        return view('content.whatsapp_chat.whatsapp_chat_customer', compact('contacts'));
    }

    public function UnknownChat()
    {
        $contacts = WhatsappContactModel::with('messages')->get();
        return view('content.whatsapp_chat.whatsapp_chat_unknown', compact('contacts'));
    }

    public function getContactsWithLastMessage(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        // Subquery to get the latest message for each contact
       $subQuery = DB::table('za_wb_messages')
            ->select('contact_id', DB::raw('MAX(sno) as last_message_sno'))
            ->where('status',0)
            ->groupBy('contact_id');

        // Main query to get contacts with their latest message
        $contacts = WhatsappContactModel::leftJoin('za_wb_messages', function ($join) use ($subQuery) {
            $join->on('za_wb_messages.contact_id', '=', 'za_wb_contacts.sno')
                ->whereIn('za_wb_messages.sno', function($query) use ($subQuery) {
                    $query->select('last_message_sno')
                          ->fromSub($subQuery, 'sub');
                });
        })
        ->leftJoin('za_lead', DB::raw("RIGHT(za_wb_contacts.phone, 10)"), '=', 'za_lead.lead_mobile') // Match last 10 digits
        ->whereNotIn('za_lead.status',[10,4])
        ->where('za_lead.branch_id',$branch_id)
        ->where('za_wb_messages.status',0)
        ->select('za_wb_contacts.*', 'za_wb_messages.message as last_message','za_wb_messages.media_caption','za_wb_messages.type', 'za_wb_messages.message_date_time as last_message_time','za_lead.lead_name','za_lead.status as lead_status');
        
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            $contacts = $contacts->where('za_lead.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            $contacts = $contacts;
        } else {
            abort(403, 'Unauthorized');
        }
        $contacts=$contacts->orderBy('za_wb_messages.sno','desc')->get();

        return response()->json($contacts);
    }

    public function getContactsWithLastMessage_customer(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        // Subquery to get the latest message for each contact
       $subQuery = DB::table('za_wb_messages')
            ->select('contact_id', DB::raw('MAX(sno) as last_message_sno'))
            ->where('status',0)
            ->groupBy('contact_id');

        // Main query to get contacts with their latest message
        $contacts = WhatsappContactModel::leftJoin('za_wb_messages', function ($join) use ($subQuery) {
            $join->on('za_wb_messages.contact_id', '=', 'za_wb_contacts.sno')
                ->whereIn('za_wb_messages.sno', function($query) use ($subQuery) {
                    $query->select('last_message_sno')
                          ->fromSub($subQuery, 'sub');
                });
        })
        ->leftJoin('za_customer', DB::raw("RIGHT(za_wb_contacts.phone, 10)"), '=', 'za_customer.cus_mobile')
        ->join('za_lead','za_lead.sno','za_customer.lead_id')
        ->whereIn('za_lead.status',[10,4])
        ->where('za_customer.branch_id',$branch_id)
        ->select('za_wb_contacts.*', 'za_wb_messages.message as last_message','za_wb_messages.media_caption','za_wb_messages.type', 'za_wb_messages.message_date_time as last_message_time','za_customer.sno as customer_id','za_customer.cus_name','za_customer.cus_pic','za_lead.status as lead_status');

        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            $contacts = $contacts->where('za_lead.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            $contacts = $contacts;
        } else {
            abort(403, 'Unauthorized');
        }
        $contacts=$contacts->orderBy('za_wb_messages.sno','desc')->get();

        return response()->json($contacts);
    }

    
    
     public function getContactsWithLastMessage_unknown(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
    
        // Subquery to get the latest message's sno for each contact
        $subQuery = DB::table('za_wb_messages')
            ->select('contact_id', DB::raw('MAX(sno) as last_message_sno'))
            ->where('status',0)
            ->groupBy('contact_id');
    
        // Main query to get contacts with their latest message
        $contacts = WhatsappContactModel::leftJoin('za_wb_messages', function ($join) use ($subQuery) {
            $join->on('za_wb_messages.contact_id', '=', 'za_wb_contacts.sno')
                ->whereIn('za_wb_messages.sno', function($query) use ($subQuery) {
                    $query->select('last_message_sno')
                          ->fromSub($subQuery, 'sub');
                });
        })
        ->leftJoin('za_lead', DB::raw("RIGHT(za_wb_contacts.phone, 10)"), '=', 'za_lead.lead_mobile') // Match last 10 digits
        ->whereNull('za_lead.sno')
        ->select('za_wb_contacts.sno','za_wb_contacts.phone', 'za_wb_messages.message as last_message','za_wb_messages.media_caption','za_wb_messages.type', 'za_wb_messages.message_date_time as last_message_time','za_lead.lead_name','za_lead.status as lead_status');
    
        // Apply permission filters
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            $contacts = $contacts->where('za_lead.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            $contacts = $contacts;
        } else {
            abort(403, 'Unauthorized');
        }
    
        // Group the results to ensure no duplicates
        $contacts = $contacts->groupBy('za_wb_contacts.sno','za_wb_contacts.phone', 'za_wb_messages.message','za_wb_messages.media_caption','za_wb_messages.type', 'za_wb_messages.message_date_time','za_lead.lead_name','za_lead.status')
            ->orderByDesc('za_wb_messages.sno') // Order by sno to ensure the latest message
            ->get();
            
        $contacts = $branch_id ==6 || $branch_id ==1 ? $contacts :[];
    
        return response()->json($contacts);
    }
    // Send Message
    public function sendMessage(Request $request)
    {
        $request->validate([
            'phone' => 'required',
            'message' => 'required',
            'type' => 'required'
        ]);
         $user_id = $request->user()->user_id;

        // Send the message via WhatsApp Business API
        $isSent = $this->sendWhatsAppMessage($request->phone, $request->message , $request);
      
       
        // If the message was successfully sent, save it to the database
        if ($isSent->getStatusCode() == 200) {
            
            $responseData = json_decode($isSent->getBody()->getContents(), true);
            $messageId = $responseData['messages'][0]['id'] ?? null;
            
            $contact = WhatsappContactModel::firstOrCreate(['phone' => $request->phone]);

            $message = WhatsappMessageModel::create([
                'contact_id' => $contact->sno,
                'message' => $request->message,
                'message_date_time' => Carbon::now()->format('Y-m-d H:i:s'),
                'type' => $request->type,
                'from' => 1  ,
                'wama_id' => $messageId ,
                'created_by' => $user_id ,
                'updated_by' => $user_id ,
                'message_status' => 'sent',
               
            ]);

            event(new NewMessage($message));  
            

            return response()->json(['success' => true, 'data'=> $responseData, 'message' => $message]);
        } else {
            return response()->json(['success' => false,'data'=> $responseData, 'message' => 'Failed to send message'], 500);
        }
    }

    
    
     public function loadMessages($phone)
    {
        $contact = WhatsappContactModel::where('phone', $phone)->first();

        if (!$contact) {
            return response()->json([]);
        }

        $messages = DB::table('za_wb_messages')
            ->select('za_wb_messages.*', 'za_wb_contacts.phone')
            ->join('za_wb_contacts', 'za_wb_contacts.sno', '=', 'za_wb_messages.contact_id')
            ->where('za_wb_messages.contact_id', $contact->sno)
            ->where('za_wb_messages.status', 0)
            ->get();
        

        return response()->json($messages);
    }

    
    public function sendWhatsAppMessage($phone, $messageText,Request $request)
    {
        // // Replace with your actual Meta WhatsApp Business API details
        // $phoneNumberId = '437594702776125';
        // $accessToken = 'EAAFb1ehfWDIBO3IxRjM766z6Hyx00dC8MzmepCI5QZC30BjNU4z72nwDmegzVtxZBQKv1o0iyD7HduA4PUtPiA1iZBJvFAcntx2wSiJFU69VKWZBevCW3B0Dbai0RZB4gKFM6ZBycwnD5VUCKL3jTea95GTLBGgGTYm07ihWVngg750IBWeZB7nubdG6Lov4bbdnwZDZD'; // Update with a valid token
            $phoneNumberId =$this->accessData($request)->phonenumber_id;
            $accessToken = $this->accessData($request)->access_tokken;
        // text checking
        // $phoneNumberId = '557364954131846';
        // $accessToken = 'EAASwZChdZBMwUBOZBi49HuYwwn5Nol5W50dTdvOHv5Qys7sq6Jn0ZAU3jHVFdoTmycmF0f2XlQU1co2zBbWLMpgZBiGGJJsL0oEckfKdWW1lDyLKtwXvHKRjRgli2ZAZCFbkcIPaJLVxzKY8bycqrTBm0HBY5c3yp2Qj3gQ6cuZCfFxhgq4OmShon1sTNhKhjKXkonoOgiRNT8YtZBtHbO8y5jAzqNEkbR60i2mR2NE0sooMZD'; // Update with a valid token
    
        $client = new Client();
        try {
            $response = $client->post("https://graph.facebook.com/v17.0/$phoneNumberId/messages", [
                'json' => [
                    'messaging_product' => 'whatsapp',
                    'to' => '+'.$phone,
                    'text' => [
                        'body' => $messageText
                    ]
                ],
                'headers' => [
                    'Authorization' => "Bearer $accessToken",
                    'Content-Type' => 'application/json',
                ]
            ]);
    
            // Check if the response indicates success
            return $response;
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            // Log the error response
            Log::error('WhatsApp API Error: ' . $e->getMessage());
            return false; // Indicate failure to send message
        }
    }

    public function CountChange($id)
     {
        $upd_WbContact =  WhatsappContactModel::where('sno', $id)->first();
        $upd_WbContact->msg_count  = 0;
        $upd_WbContact->Update();
    
    
        return response([
          'status'    => 200,
          'message'   => 'Successfully updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }
  
  
    public function LeadContactInfo($phone,Request $request)
    {
            $branch_id = $request->user()->branch_id;
            
            $contact = WhatsappContactModel::select('za_lead.*','za_wb_contacts.phone')->where('za_wb_contacts.phone', $phone)
                ->leftJoin('za_lead', DB::raw("RIGHT(za_wb_contacts.phone, 10)"), '=', 'za_lead.lead_mobile') 
                ->whereNotIn('za_lead.status',[10,4])
                ->where('za_lead.branch_id',$branch_id)
                ->first();

        if (!$contact) {
            return response()->json([]);
        }

        return response()->json($contact);
    }
  
      public function DeleteForMe($id)
      {
        $upd_WbContact =  WhatsappMessageModel::where('sno', $id)->first();
        $upd_WbContact->status  = 2;
        $result=$upd_WbContact->save();
        if($result){
            event(new NewMessage($result));
            return response()->json(['success' => true, 'data'=> '', 'message' => $result]);
        } else {
            return response()->json(['success' => false,'data'=> '', 'message' => 'Failed to Delete message'], 500);
        }
      }
      
    public function CustomerContactInfo($phone,Request $request)
    {
            $branch_id = $request->user()->branch_id;
            
            $contact = WhatsappContactModel::select('za_customer.*','za_lead.status as lead_status','za_wb_contacts.phone')->where('za_wb_contacts.phone', $phone)
                ->join('za_customer', DB::raw("RIGHT(za_wb_contacts.phone, 10)"), '=', 'za_customer.cus_mobile') 
                ->join('za_lead','za_lead.sno','za_customer.lead_id')
                ->whereIn('za_lead.status',[10,4])
                ->where('za_customer.branch_id',$branch_id)
                ->first();

        if (!$contact) {
            return response()->json([]);
        }

        return response()->json($contact);
    }
    

    public function sendSyllabusMessage(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'lead_mobile'  => 'required',
            'course_id'  => 'required',
            // 'message' => 'required|string|max:500', // Adjust max length as needed
            
        ]);

        

        // If validation fails, return a response with errors
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        $branch_id  = $request->user()->branch_id;
        $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

        $course_id_msg=$request->course_id;
        $course_type=4;

        $courseData    = ManageCoursesModel::select('za_course.*','za_course_type.course_type_name')->join('za_course_type','za_course_type.sno','=','za_course.course_type_id')->where('za_course.status', 0)->where('za_course.sno', $course_id_msg)->first();

        $branch_name = " ";
        if ($branchData->branch_type == 1) {
            $branch_name = $branchData->branch_name;
        } elseif ($branchData->branch_type == 2) {
            $branch_name = $branchData->franchise_name;
        }

        // Extract the validated data
        $lead_mobile           = $request->lead_mobile;
       
        
        $user_id           = $request->user()->user_id;

        // return $request;
        // Find the lead based on lead_id
        $lead = LeadModel::where('lead_mobile', substr($lead_mobile, -10))
            ->first();

        // If the lead is not found, return an error response
        if (! $lead) {
            return response([
                'status'    => 404,
                'message'   => 'Lead not found',
                'error_msg' => 'The lead with the given ID does not exist',
                'data'      => null,
            ], 200);
        }


        // Send email if email flag is set to true
        $cre = StaffModel::where('sno', $branchData->cre_id)->orderBy('sno', 'desc')->first();
        if ($lead->lead_mobile) {
            $templateName ='eapl_erp_syllabus_send2';
            $hasHeader  = false; // Example flag: set based on template
            $hasBody    = false; // Example flag: set based on template
            $hasFooter  = false; // Example flag: set based on template
            $hasButton  = false;
            $components = [];
            $couponCode = "";
            $otp        = "";
            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                       // $currentHour = date('H'); // Get current hour in 24-hour format
            if ($currentHour >= 5 && $currentHour < 12) {
                $greeting = 'Good Morning';
            } elseif ($currentHour >= 12 && $currentHour < 18) {
                $greeting = 'Good Afternoon';
            } else {
                $greeting = 'Good Evening';
            }
            $documentPath = "https://erp.elysium.academy/course_attachments/".$courseData->attachment;

            if ($templateName) {
                $headerImage = $documentPath;
                $couponCode  = 'DISCOUNT20';
                $buttonIndex = 0;
                $bodyText    = [
                    [
                        'type'           => 'text',
                        'text'           => $lead->lead_name,
                        'parameter_name' => 'lead_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $courseData->course_name ?? "Java Course",
                        'parameter_name' => 'course_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $courseData->course_type_name ?? "Professional Course",
                        'parameter_name' => 'course_type',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $courseData->course_days??"45 Days",
                        'parameter_name' => 'course_duration',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->website ?? "https://elysiumacademy.org/",
                        'parameter_name' => 'insert_link',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->sales_mobile ?? "9677781155",
                        'parameter_name' => 'contact_no',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                        'parameter_name' => 'contact_email',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_name ?? 'Madurai Branch',
                        'parameter_name' => 'branch_name',
                    ],
                ];
                $hasHeader = true;
                $hasBody   = true;
            }
            // Add Header if required
            if ($hasHeader) {
                $components[] = [
                    'type'       => 'header',
                    'parameters' => [

                        [
                            "type"=> "document",
                            "document"=> [
                              "link"=> $headerImage,
                              "filename"=> $courseData->course_name
                            ]
                        ],

                    ],
                ];
            }
            // Add Body if required
            if ($hasBody) {
                $components[] = [
                    'type'       => 'body',
                    'parameters' => $bodyText,
                ];
            }
            // Add Footer if required
            if ($hasFooter) {
                $components[] = [
                    'type'       => 'footer',
                    'parameters' => [
                        [
                            'type'           => 'text',
                            'text'           => 'This is the footer text.',
                            'parameter_name' => 'footer_text',
                        ],
                    ],
                ];
            }
            // Add Button if required
            if ($hasButton) {
                if ($couponCode) {
                    $components[] = [
                        'type'       => 'button',
                        'sub_type'   => 'copy_code',
                        'index'      => $buttonIndex,
                        'parameters' => [
                            [
                                'type'        => 'coupon_code',
                                'coupon_code' => $couponCode,
                            ],
                        ],
                    ];
                } elseif ($otp) {
                    $components[] = [
                        'type'       => 'button',
                        'sub_type'   => 'url', // Change type to match API requirements
                        'index'      => $buttonIndex,
                        'parameters' => [
                            [
                                'type' => 'text',
                                'text' => $otp,
                            ],
                        ],
                    ];
                }

            }

            $dynamicParameters         = $templateParameters[$templateName] ?? [];
            $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
            $accessToken               = $this->accessData($request)->access_tokken;
            $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
            $to           = $lead->lead_mobile;
            $languageCode = 'en';

            if (strpos($to, $countryCode) !== 0) {
                $to = $countryCode . $to;
            }

            $message = 'test~message';
            if (empty($components)) {
                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to'                => $to,
                    'type'              => 'template',
                    'template'          => [
                        'name'     => $templateName,
                        'language' => [
                            'code' => $languageCode,
                        ],
                    ],
                ];
            } else {
                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to'                => $to,
                    'type'              => 'template',
                    'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                            'code' => $languageCode,
                        ],
                        'components' => $components,
                    ],
                ];
            }

            $response = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            if ($response['status'] == 200) {
                    $lead_send_upd = LeadModel::where('sno', $lead->sno)->first();
                    if ($lead_send_upd) {
                        $lead_send_upd->updated_by   = $user_id;
                        $lead_send_upd->document_send_count += 1;
                        $lead_send_upd->update();
                    }
              
                $messageId = $response['data']['messages'][0]['id'] ?? null;
                
                return response([
                    'status'         => 200,
                    'message'        => 'Message sent successfully!',
                    'data'           => $response['data'],
                    'response_data'  => json_encode($response),
                ], 200);
            } else {
                return response([
                    'status'    => 404,
                    'message'   => 'Failed to send message',
                    'error_msg' => $response['error'],
                ], 400);
            }
        }
       
        
        return response([
            'status'    => 200,
            'message'   => "Message sent successfully",
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    private function sendRequestToWhatsApp($url, $token, $data)
    {
      try {
        $client = new \GuzzleHttp\Client();
        $response = $client->post($url, [
          'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json',
          ],
          'json' => $data,
        ]);
  
        return [
          'status' => $response->getStatusCode(),
          'data' => json_decode($response->getBody(), true),
        ];
      } catch (\Exception $e) {
        return [
          'status' => 400,
          'error' => $e->getMessage(),
        ];
      }
    }

    public function accessData(Request $request){
        $branchId = $request->user()->branch_id; 
        $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 6)->first();
        return $whatsappConfig;
    }


    public function sendPayRemainderMessage(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'customer_id'  => 'required',
            'course_id'  => 'required',
            
        ]);

          // If validation fails, return a response with errors
          if ($validator->fails()) {
              return response([
                  'status'    => 401,
                  'message'   => 'Incorrect format input fields',
                  'error_msg' => $validator->messages()->get('*'),
                  'data'      => null,
              ], 200);
          }
          $branch_id  = $request->user()->branch_id;
          $user_id   = $request->user()->user_id;
          $customer_id=$request->customer_id;
          $course_id=$request->course_id;

          $branch_data = BranchModel::where('sno', $branch_id)->first();
          $branch_name = " ";
          if ($branch_data->branch_type == 1) {
              $branch_name = $branch_data->branch_name;
          } elseif ($branch_data->branch_type == 2) {
              $branch_name = $branch_data->franchise_name;
          }

           $customerData=DB::table('za_payment')->select('za_payment.*','za_customer.cus_name','za_customer.cus_mobile','za_customer.cus_email_id','za_course.course_name')->leftJoin('za_customer','za_customer.sno','=','za_payment.customer_id')->leftJoin('za_course','za_course.sno','=','za_payment.course_id')->where('za_payment.customer_id',$customer_id)->where('za_payment.course_id',$course_id)->where('za_payment.status',0)->first();

        //    return $customerData;
             //   SMS
             $customer_mobiles =isset($customerData->cus_mobile)? $customerData->cus_mobile: '';
             $customer_mails = isset($customerData->cus_email_id)?$customerData->cus_email_id: '';
             $customer_names = isset($customerData->cus_name)?$customerData->cus_name: 'Mr/Mrs';
             $cre_mobile = isset($branch_data->cre_mobile) ?$branch_data->cre_mobile:'9677781155';
             $pay_course_id=isset($customerData->course_id) ?$customerData->course_id:'0';
             $totalAmount=isset($customerData->amount) ?$customerData->amount:'0';
             $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();

             $tempdate      = $customerData->nextPayDate ?? null;
             // Whatsapp messages
             if ($customer_mobiles) {
                 $cre          = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                 $hasHeader    = false; // Example flag: set based on template
                 $hasBody      = false; // Example flag: set based on template
                 $components   = [];
                 $couponCode   = " ";
                     // Example flag: set based on template
                     $components_trans = [];
                     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                // $currentHour = date('H'); // Get current hour in 24-hour format
                     if ($currentHour >= 5 && $currentHour < 12) {
                         $greeting = 'Good Morning';
                     } elseif ($currentHour >= 12 && $currentHour < 18) {
                         $greeting = 'Good Afternoon';
                     } else {
                         $greeting = 'Good Evening';
                     }
                     $helper             = new \App\Helpers\Helpers();
                     $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                     // $paymentDate        = date($common_date_format);
                     $paymentDate        = $tempdate;
                     $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                     $paymentAmount      = $paymentAmt . ". Rs";
 
                     $templateName = 'elysium_academy_pay_reminder2';
                     $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/payment_remainder.jpg';
                     $bodyText     = [
                         [
                             'type'           => 'text',
                             'text'           => $greeting,
                             'parameter_name' => 'greet_msg',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $customer_names,
                             'parameter_name' => 'customer_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $coursename->course_name??'Course',
                             'parameter_name' => 'course_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $paymentAmount,
                             'parameter_name' => 'amount',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $paymentDate,
                             'parameter_name' => 'due_date',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->cre_mobile ?? '9677781155',
                             'parameter_name' => 'cre_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->mail??'info@elysiumacademy.org',
                             'parameter_name' => 'contact_email',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_name??'Elysium Academy',
                             'parameter_name' => 'branch_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->sales_mobile ?? '9677781155',
                             'parameter_name' => 'contact_no',
                         ],
                         
                     ];
                     $components_trans[] = [
                         'type'       => 'header',
                         'parameters' => [
                             [
                                 'type'  => 'image',
                                 'image' => [
                                     'link' => $headerImage, // Dynamically set header image
                                 ],
                             ],
                         ],
                     ];
 
                     $components_trans[] = [
                         'type'       => 'body',
                         'parameters' => $bodyText,
                     ];
                     $dynamicParameters         = $templateParameters[$templateName] ?? [];
                     $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
                     $accessToken               = $this->accessData($request)->access_tokken;
                     $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
 
                     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
 
                     $to           = $customer_mobiles;
                     $languageCode = 'en';
 
                     if (strpos($to, '+91') !== 0) {
                         $to = '+91' . $to;
                     }
 
                     $message = 'test~message';
 
                     $payload = [
                         'messaging_product' => 'whatsapp',
                         'to'                => $to,
                         'type'              => 'template',
                         'template'          => [
                             'name'       => $templateName,
                             'language'   => [
                                 'code' => $languageCode,
                             ],
                             'components' => $components_trans,
                         ],
                     ];
 
                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
 
                 
             }
           
            if ($response['status'] == 200) {
                // Include the webhook response in your API response
                return response([
                    'status'         => 200,
                    'message'        => 'Message sent successfully!',
                    'data'           => $response['data'],
                    'response_data'  => json_encode($response),
                ], 200);
            } else {
                return response([
                    'status'    => 404,
                    'message'   => 'Failed to send message',
                    'error_msg' => $response['error'],
                ], 400);
            }

        return response([
            'status'    => 200,
            'message'   => "Message sent successfully",
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }


    public function getCoursesByCustomer(Request $request)
    {
        $customer_id = $request->input('customer_id');
        
        $course_ids = DB::table('za_training')
            ->where('customer_id', $customer_id) // Use 'where' instead of 'whereIn' for a single customer
            ->pluck('course_id')
            ->toArray(); 
        //    return  $course_ids ;
        $courses = DB::table('za_course')
            ->whereIn('sno', $course_ids)
            ->where('status', 0) // Assuming 0 means "active"
            ->get();

        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }
   

    
}
