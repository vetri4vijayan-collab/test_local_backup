public function handle($request, Closure $next)
{
    $branchId = $request->session()->get('branch_id');

    if ($branchId) {
        config(['app.branch_id' => $branchId]);
        // Optionally set a global scope for Eloquent models
        \App\Models\YourModel::addGlobalScope('branch', function (Builder $builder) use ($branchId) {
            $builder->where('branch_id', $branchId);
        });
    }

    return $next($request);
}
Register the middleware in app/Http/Kernel.php:
protected $middlewareGroups = [
    'web' => [
        // Other middleware
        \App\Http\Middleware\SetBranch::class,
    ],
];
In config/app.php, add:
'branch_id' => env('BRANCH_ID', null),

In your .env file, you can set a default branch ID (if any):
BRANCH_ID=1




<form action="{{ route('setBranch') }}" method="POST">
    @csrf
    <select name="branch_id" onchange="this.form.submit()">
        @foreach($branches as $branch)
            <option value="{{ $branch->id }}" {{ $branch->id == session('branch_id') ? 'selected' : '' }}>
                {{ $branch->name }}
            </option>
        @endforeach
    </select>
</form>


public function setBranch(Request $request)
{
    $branchId = $request->input('branch_id');


    $request->session()->put('branch_id', $branchId);




    return redirect()->back();






}

same

public function handle($request, Closure $next)
{
    $branchId = $request->session()->get('branch_id', config('app.branch_id'));

    if ($branchId) {
        config(['app.branch_id' => $branchId]);
        \App\Models\YourModel::addGlobalScope('branch', function (Builder $builder) use ($branchId) {
            $builder->where('branch_id', $branchId);
        });
    }

    return $next($request);
}


<?php

if (!function_exists('formatToK')) {
    function formatToK($amount) {
        if ($amount >= 1_000_000) {
            return round($amount / 1_000_000, 1) . 'M';
        } elseif ($amount >= 1_000) {
            return round($amount / 1_000, 1) . 'k';
        } else {
            return $amount;
        }
    }
}


{{ formatToK($amount) }}


class Product extends Model
{
    // Other model methods and properties

    public function getFormattedAmountAttribute()
    {
        return formatToK($this->amount); // Use the helper function defined above
    }
}


{{ $product->formatted_amount }}
