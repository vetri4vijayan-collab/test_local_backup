<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadModel;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\CareerPathModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\ManageCouponModel;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\Mail;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class BookingController extends Controller
{
  // Get all branches
  public function getBranches()
  {
    try {
      $branches = BranchModel::where('status', 0)
        ->select('sno as id', 'branch_name', 'franchise_name', 'city_short_code', 'mobile', 'mail')
        ->get();

      return response()->json($branches);
    } catch (\Exception $e) {
      return response()->json(['error' => $e->getMessage()], 500);
    }
  }

  // Save career path
  public function saveCareerPath(Request $request)
  {
    try {
      $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
        'mobile' => 'required|string|max:15',
        'email' => 'nullable|email',
        'industry' => 'nullable|string',
        'experience' => 'nullable|string',
        'role' => 'nullable|string',
        'salary' => 'nullable|string',
        'interested' => 'nullable|string',
        'skills' => 'nullable|array',
        'roadmap' => 'nullable|array',
        'branch_name' => 'nullable|string'
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data' => null
        ], 200);
      }

      $data = $validator->validated();

      // FIX 1: Clean salary to remove ₹ symbol and extra spaces
      $salary = $data['salary'] ?? '';
      // Remove ₹ symbol and any extra whitespace
      $salary = preg_replace('/[^\d\s\-LPA]/', '', $salary);
      $salary = trim($salary);

      // Get branch
      $branch = BranchModel::where('status', 0)
        ->where(function ($q) use ($data) {
          $q->where('branch_name', $data['branch_name'])
            ->orWhere('franchise_name', $data['branch_name']);
        })
        ->first();

      $careerPath = CareerPathModel::create([
        'user_name' => $data['name'],
        'user_mobile' => $data['mobile'],
        'user_email' => $data['email'] ?? '',
        'current_industry' => $data['industry'] ?? '',
        'current_experience' => $data['experience'] ?? '',
        'selected_role' => $data['role'] ?? '',
        'expected_salary' => $salary, // FIX 1: Use cleaned salary
        'interested_in' => $data['interested'] ?? '',
        'skills' => json_encode($data['skills'] ?? []),
        'roadmap_data' => json_encode($data['roadmap'] ?? []),
        'branch_id' => $branch->sno ?? 1,
        'status' => 'new',
        'created_at' => now()
      ]);

      return response()->json([
        'success' => true,
        'message' => 'Career path saved successfully',
        'id' => $careerPath->id
      ]);
    } catch (\Exception $e) {
      Log::error('Career Path Error: ' . $e->getMessage());
      return response()->json([
        'error' => 'Failed to save: ' . $e->getMessage()
      ], 500);
    }
  }

  // Save booking (Lead + Appointment + Notifications)
  // public function saveBooking(Request $request)
  // {
  //   $validator = Validator::make($request->all(), [
  //     'lead_name' => 'required|string|max:255',
  //     'lead_mobile' => 'required|string|max:15',
  //     'lead_email' => 'nullable|email',
  //     'branch_name' => 'nullable|string',
  //     'appointment_date' => 'required|date',
  //     'appointment_time' => 'required|string',
  //     'career_path' => 'nullable|string',
  //     'coupon' => 'nullable|string'
  //   ]);

  //   if ($validator->fails()) {
  //     return response()->json([
  //       'status' => 401,
  //       'message' => 'Incorrect format input fields',
  //       'error_msg' => $validator->messages()->get('*'),
  //       'data' => null
  //     ], 200);
  //   }

  //   $data = $validator->validated();

  //   // Start Database Transaction
  //   DB::beginTransaction();

  //   try {
  //     // Get branch details
  //     $branch = BranchModel::where('status', 0)
  //       ->where(function ($q) use ($data) {
  //         $q->where('branch_name', $data['branch_name'])
  //           ->orWhere('franchise_name', $data['branch_name']);
  //       })
  //       ->first();

  //     $branch_id = $branch->sno ?? 1;
  //     $branch_code = $branch->city_short_code ?? 'VNR';
  //     $branch_name = $branch->branch_type == 1 ? $branch->branch_name : ($branch->franchise_name ?? 'Elysium Academy');
  //     $branch_cre_mobile = $branch->cre_mobile ?? '9677781155';

  //     // CHECK: Mobile number already exists in this branch
  //     $existingLead = LeadModel::where('lead_mobile', $data['lead_mobile'])
  //       ->where('status', '!=', 2)
  //       ->first();

  //     if ($existingLead) {
  //       // No need to commit or rollback as no data was inserted
  //       return response()->json([
  //         'success' => true,
  //         'message' => 'Mobile number already registered!',
  //         'data' => [
  //           'lead_id' => $existingLead->sno,
  //           'lead_id_generated' => $existingLead->lead_id,
  //           'lead_name' => $existingLead->lead_name,
  //           'lead_mobile' => $existingLead->lead_mobile,
  //           'branch_id' => $branch_id,
  //           'already_exists' => true,
  //           'coupon' => null // No coupon for existing leads
  //         ]
  //       ]);
  //     }

  //     // Generate Lead ID: 2026/VNR01/LED40743
  //     $year = date('Y');
  //     $lastLead = LeadModel::where('branch_id', $branch_id)
  //       ->where('lead_id', 'LIKE', $year . '/' . $branch_code . '%/LED%')
  //       ->orderBy('sno', 'desc')
  //       ->first();

  //     if ($lastLead) {
  //       preg_match('/LED(\d+)/', $lastLead->lead_id, $matches);
  //       $next_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
  //     } else {
  //       $next_number = 1;
  //     }
  //     $lead_number = sprintf("LED%05d", $next_number);
  //     $lead_id_generated = $year . '/' . $branch_code . '/' . $lead_number;

  //     // Generate Appointment ID: LDAP-1185/25
  //     $lastAppointment = AppointmentModel::orderBy('sno', 'desc')->first();
  //     if ($lastAppointment && $lastAppointment->lead_appointment_id) {
  //       preg_match('/LDAP-(\d+)/', $lastAppointment->lead_appointment_id, $matches);
  //       $next_appointment_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
  //     } else {
  //       $next_appointment_number = 1;
  //     }
  //     $appointment_number = sprintf("LDAP-%04d", $next_appointment_number);
  //     $appointment_id_generated = $appointment_number . '/' . date('y');

  //     // GENERATE COUPON CODE
  //     $coupon_code = null;
  //     if (empty($data['coupon'])) {
  //       // Generate unique coupon: ELY-XXXX-10
  //       $random = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
  //       $coupon_code = 'ELY-' . $random . '-10';
  //     } else {
  //       $coupon_code = $data['coupon'];
  //     }

  //     // GENERATE COUPON ID: COU-0005/25
  //     $lastCoupon = ManageCouponModel::orderBy('sno', 'desc')->first();
  //     if ($lastCoupon && $lastCoupon->coupon_id) {
  //       preg_match('/COU-(\d+)\//', $lastCoupon->coupon_id, $matches);
  //       $next_coupon_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
  //     } else {
  //       $next_coupon_number = 1;
  //     }
  //     $coupon_number = sprintf("COU-%04d", $next_coupon_number);
  //     $coupon_id_generated = $coupon_number . '/' . date('y');

  //     // Set expiry date: 30 days from now
  //     $expiry_date = date('Y-m-d', strtotime('+30 days'));

  //     // 1. Insert into za_lead
  //     $lead = LeadModel::create([
  //       'lead_name' => $data['lead_name'],
  //       'lead_id' => $lead_id_generated,
  //       'inter_calls' => 91,
  //       'lead_mobile' => $data['lead_mobile'],
  //       'lead_email_id' => $data['lead_email'] ?? '',
  //       'branch_id' => $branch_id,
  //       'country' => 101,
  //       'state' => 35,
  //       'city' => 'C4341',
  //       'lead_type_id' => 1,
  //       'lead_source_id' => 1,
  //       'lead_comments' => 'Career path: ' . ($data['career_path'] ?? '') . ' | Coupon: ' . $coupon_code,
  //       'lead_status_id' => 1,
  //       'lead_condition' => 2,
  //       'created_by' => 123,
  //       'updated_by' => 1,
  //       'status' => 0,
  //       'created_at' => now()
  //     ]);


  //     // 2. Save Coupon to za_manage_coupon
  //     $coupon = new ManageCouponModel();
  //     $coupon->coupon_code = $coupon_code;
  //     $coupon->coupon_id = $coupon_id_generated;
  //     $coupon->coupon_name = 'Career Path - ' . ($data['career_path'] ?? 'IT Career');
  //     $coupon->coupon_value = 10;
  //     $coupon->coupon_type = 'percentage';
  //     $coupon->max_usage_count = 1;
  //     $coupon->end_date = $expiry_date;
  //     $coupon->branch_id = $branch_id;
  //     $coupon->is_qr = 1;
  //     $coupon->created_by = 123;
  //     $coupon->updated_by = 1;
  //     $coupon->status = 0; // 0 = Active
  //     $coupon->created_at = now();
  //     $coupon->updated_at = now();
  //     $coupon->save();


  //     $lead_id = $lead->sno;

  //     // Convert time format from "10:00 AM" to "10:00:00"
  //     $appointment_time_24hr = date('H:i:s', strtotime($data['appointment_time']));

  //     // Combine date and time for appointment_datetime
  //     $appointment_datetime = date('Y-m-d H:i:s', strtotime($data['appointment_date'] . ' ' . $data['appointment_time']));

  //     // 2. Insert into za_lead_appointment
  //     $appointment = AppointmentModel::create([
  //       'lead_id' => $lead_id,
  //       'appointment_id' => $appointment_id_generated,
  //       'appointment_date' => $appointment_datetime,
  //       'appointment_time' => $appointment_time_24hr,
  //       'branch_id' => $branch_id,
  //       'lead_appointment_id' => $appointment_id_generated,
  //       'appointment_category' => 'Walk-in',
  //       'department_id' => 1,
  //       'status' => 0,
  //       'created_by' => 123,
  //       'updated_by' => 1,
  //       'created_at' => now(),
  //       'updated_at' => now()
  //     ]);

  //     // 3. Send SMS (Outside transaction - but we track success)
  //     $sms_sent = false;
  //     // if (!empty($data['lead_mobile'])) {
  //     //   try {
  //     //     $sms_sent = $this->sendSMS(
  //     //       $data['lead_mobile'],
  //     //       $data['lead_name'],
  //     //       $data['appointment_date'],
  //     //       $data['appointment_time'],
  //     //       $branch_cre_mobile,
  //     //       $branch,
  //     //     );
  //     //   } catch (\Exception $e) {
  //     //     Log::warning('SMS sending failed: ' . $e->getMessage());
  //     //     $sms_sent = false;
  //     //   }
  //     // }

  //     // 4. Send WhatsApp (Outside transaction - but we track success)
  //     $whatsapp_sent = false;
  //     // if (!empty($data['lead_mobile'])) {
  //     //   try {
  //     //     $whatsapp_sent = $this->sendWhatsApp(
  //     //       $data['lead_mobile'],
  //     //       $data['lead_name'],
  //     //       $data['appointment_date'],
  //     //       $data['appointment_time'],
  //     //       $branch,
  //     //       $branch_name,
  //     //     );
  //     //   } catch (\Exception $e) {
  //     //     Log::warning('WhatsApp sending failed: ' . $e->getMessage());
  //     //     $whatsapp_sent = false;
  //     //   }
  //     // }

  //     // 5. Send Email (Outside transaction - but we track success)
  //     $email_sent = false;
  //     if (!empty($data['lead_email'])) {
  //       try {
  //         $email_sent = $this->sendEmail(
  //           $data['lead_email'],
  //           $data['lead_name'],
  //           $data['appointment_date'],
  //           $data['appointment_time'],
  //           $branch,
  //           $branch_name,
  //         );
  //       } catch (\Exception $e) {
  //         Log::warning('Email sending failed: ' . $e->getMessage());
  //         $email_sent = false;
  //       }
  //     }

  //     // Commit the transaction - all database operations succeeded
  //     DB::commit();

  //     return response()->json([
  //       'success' => true,
  //       'message' => 'Booking completed successfully!',
  //       'data' => [
  //         'lead_id' => $lead_id,
  //         'lead_id_generated' => $lead_id_generated,
  //         'appointment_id' => $appointment->sno,
  //         'appointment_id_generated' => $appointment_id_generated,
  //         'branch_id' => $branch_id,
  //         'appointment_datetime' => $appointment_datetime,
  //         'appointment_time' => $appointment_time_24hr,
  //         'coupon' => $coupon_code, // RETURN COUPON TO FRONTEND
  //         'sms_sent' => $sms_sent,
  //         // 'whatsapp_sent' => $whatsapp_sent,
  //         // 'email_sent' => $email_sent,
  //         'already_exists' => false
  //       ]
  //     ]);
  //   } catch (\Exception $e) {
  //     // Rollback the transaction on any error
  //     DB::rollBack();

  //     Log::error('Booking Error: ' . $e->getMessage());
  //     Log::error('Booking Error Trace: ' . $e->getTraceAsString());

  //     return response()->json([
  //       'success' => false,
  //       'error' => 'Failed to save booking: ' . $e->getMessage(),
  //       'data' => null
  //     ]);
  //   }
  // }

  // Save booking (Lead + Appointment + Notifications)
  public function saveBooking(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|string|max:255',
      'lead_mobile' => 'required|string|max:15',
      'lead_email' => 'nullable|email',
      'branch_name' => 'nullable|string',
      'appointment_date' => 'required|date',
      'appointment_time' => 'required|string',
      'career_path' => 'nullable|string',
      'coupon' => 'nullable|string'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null
      ], 200);
    }

    $data = $validator->validated();

    // Start Database Transaction
    DB::beginTransaction();

    try {
      // Get branch details
      $branch = BranchModel::where('status', 0)
        ->where(function ($q) use ($data) {
          $q->where('branch_name', $data['branch_name'])
            ->orWhere('franchise_name', $data['branch_name']);
        })
        ->first();

      $branch_id = $branch->sno ?? 1;
      $branch_code = $branch->city_short_code ?? 'VNR';
      $branch_name = $branch->branch_type == 1 ? $branch->branch_name : ($branch->franchise_name ?? 'Elysium Academy');
      $branch_cre_mobile = $branch->cre_mobile ?? '9677781155';

      // CHECK: Mobile number already exists
      $existingLead = LeadModel::where('lead_mobile', $data['lead_mobile'])
        ->where('status', '!=', 2)
        ->first();

      $lead_id = null;
      $lead_id_generated = null;
      $coupon_code = null;
      $isExistingLead = false;

      if ($existingLead) {
        // ✅ EXISTING LEAD: Use existing lead data
        $isExistingLead = true;
        $lead_id = $existingLead->sno;
        $lead_id_generated = $existingLead->lead_id;
        $lead_name = $existingLead->lead_name;
        $lead_mobile = $existingLead->lead_mobile;

        // NO new coupon for existing leads
        $coupon_code = null;
      } else {
        // ✅ NEW LEAD: Create lead and coupon
        $isExistingLead = false;

        // Generate Lead ID: 2026/VNR01/LED40743
        $year = date('Y');
        $lastLead = LeadModel::where('branch_id', $branch_id)
          ->where('lead_id', 'LIKE', $year . '/' . $branch_code . '%/LED%')
          ->orderBy('sno', 'desc')
          ->first();

        if ($lastLead) {
          preg_match('/LED(\d+)/', $lastLead->lead_id, $matches);
          $next_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
        } else {
          $next_number = 1;
        }
        $lead_number = sprintf("LED%05d", $next_number);
        $lead_id_generated = $year . '/' . $branch_code . '/' . $lead_number;

        // GENERATE COUPON CODE for new lead
        $random = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
        $coupon_code = 'ELY-' . $random . '-10';

        // GENERATE COUPON ID: COU-0005/25
        $lastCoupon = ManageCouponModel::orderBy('sno', 'desc')->first();
        if ($lastCoupon && $lastCoupon->coupon_id) {
          preg_match('/COU-(\d+)\//', $lastCoupon->coupon_id, $matches);
          $next_coupon_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
        } else {
          $next_coupon_number = 1;
        }
        $coupon_number = sprintf("COU-%04d", $next_coupon_number);
        $coupon_id_generated = $coupon_number . '/' . date('y');

        $expiry_date = date('Y-m-d', strtotime('+30 days'));

        // 1. Insert into za_lead
        $lead = LeadModel::create([
          'lead_name' => $data['lead_name'],
          'lead_id' => $lead_id_generated,
          'inter_calls' => 91,
          'lead_mobile' => $data['lead_mobile'],
          'lead_email_id' => $data['lead_email'] ?? '',
          'branch_id' => $branch_id,
          'country' => 101,
          'state' => 35,
          'city' => 'C4341',
          'lead_type_id' => 1,
          'lead_source_id' => 1,
          'lead_comments' => 'Career path: ' . ($data['career_path'] ?? '') . ' | Coupon: ' . $coupon_code,
          'lead_status_id' => 1,
          'lead_condition' => 2,
          'created_by' => 123,
          'updated_by' => 1,
          'status' => 0,
          'created_at' => now()
        ]);

        $lead_id = $lead->sno;
        $lead_name = $data['lead_name'];
        $lead_mobile = $data['lead_mobile'];

        // 2. Save Coupon to za_manage_coupon
        $coupon = new ManageCouponModel();
        $coupon->coupon_code = $coupon_code;
        $coupon->coupon_id = $coupon_id_generated;
        $coupon->coupon_name = 'Career Path - ' . ($data['career_path'] ?? 'IT Career');
        $coupon->coupon_value = 10;
        $coupon->coupon_type = 'percentage';
        $coupon->max_usage_count = 1;
        $coupon->end_date = $expiry_date;
        $coupon->branch_id = $branch_id;
        $coupon->is_qr = 1;
        $coupon->created_by = 123;
        $coupon->updated_by = 1;
        $coupon->status = 0;
        $coupon->created_at = now();
        $coupon->updated_at = now();
        $coupon->save();
      }

      // ✅ ALWAYS CREATE APPOINTMENT (for both new and existing leads)
      // Generate Appointment ID: LDAP-1185/25
      $lastAppointment = AppointmentModel::orderBy('sno', 'desc')->first();
      if ($lastAppointment && $lastAppointment->lead_appointment_id) {
        preg_match('/LDAP-(\d+)/', $lastAppointment->lead_appointment_id, $matches);
        $next_appointment_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
      } else {
        $next_appointment_number = 1;
      }
      $appointment_number = sprintf("LDAP-%04d", $next_appointment_number);
      $appointment_id_generated = $appointment_number . '/' . date('y');

      // Convert time format from "10:00 AM" to "10:00:00"
      $appointment_time_24hr = date('H:i:s', strtotime($data['appointment_time']));
      $appointment_datetime = date('Y-m-d H:i:s', strtotime($data['appointment_date'] . ' ' . $data['appointment_time']));
      // Full datetime for reference
      $appointment_datetime = date('Y-m-d H:i:s', strtotime($data['appointment_date'] . ' ' . $data['appointment_time']));
      // Insert into za_lead_appointment
      $appointment = AppointmentModel::create([
        'lead_id' => $lead_id,
        'appointment_date' => $appointment_datetime,
        'branch_id' => $branch_id,
        'lead_appointment_id' => $appointment_id_generated,
        'appointment_category' => 'Walk-in',
        'department_id' => 1,
        'staff_id' => 123,
        'status' => 0,
        'created_by' => 123,
        'updated_by' => 1,
        'created_at' => now(),
        'updated_at' => now()
      ]);

      // Send notifications (SMS, WhatsApp, Email) - Optional
      // 3. Send SMS (Outside transaction - but we track success)
      $sms_sent = false;
      // if (!empty($data['lead_mobile'])) {
      //   try {
      //     $sms_sent = $this->sendSMS(
      //       $data['lead_mobile'],
      //       $data['lead_name'],
      //       $data['appointment_date'],
      //       $data['appointment_time'],
      //       $branch_cre_mobile,
      //       $branch,
      //     );
      //   } catch (\Exception $e) {
      //     Log::warning('SMS sending failed: ' . $e->getMessage());
      //     $sms_sent = false;
      //   }
      // }

      // 4. Send WhatsApp (Outside transaction - but we track success)
      $whatsapp_sent = false;
      // if (!empty($data['lead_mobile'])) {
      //   try {
      //     $whatsapp_sent = $this->sendWhatsApp(
      //       $data['lead_mobile'],
      //       $data['lead_name'],
      //       $data['appointment_date'],
      //       $data['appointment_time'],
      //       $branch,
      //       $branch_name,
      //     );
      //   } catch (\Exception $e) {
      //     Log::warning('WhatsApp sending failed: ' . $e->getMessage());
      //     $whatsapp_sent = false;
      //   }
      // }

      // 5. Send Email (Outside transaction - but we track success)
      $email_sent = false;
      if (!empty($data['lead_email'])) {
        try {
          $email_sent = $this->sendEmail(
            $data['lead_email'],
            $data['lead_name'],
            $data['appointment_date'],
            $data['appointment_time'],
            $branch,
            $branch_name,
          );
        } catch (\Exception $e) {
          Log::warning('Email sending failed: ' . $e->getMessage());
          $email_sent = false;
        }
      }


      // Commit the transaction
      DB::commit();

      // ✅ RESPONSE for EXISTING LEAD
      if ($isExistingLead) {
        return response()->json([
          'success' => true,
          'message' => 'Appointment booked successfully for existing lead!',
          'data' => [
            'lead_id' => $lead_id,
            'lead_id_generated' => $lead_id_generated,
            'lead_name' => $lead_name,
            'lead_mobile' => $lead_mobile,
            'appointment_id' => $appointment->sno,
            'appointment_id_generated' => $appointment_id_generated,
            'branch_id' => $branch_id,
            'appointment_datetime' => $appointment_datetime,
            'appointment_time' => $appointment_time_24hr,
            'coupon' => null, // No coupon for existing leads
            'already_exists' => true,
            'sms_sent' => $sms_sent,
          ]
        ]);
      }

      // ✅ RESPONSE for NEW LEAD
      return response()->json([
        'success' => true,
        'message' => 'Booking completed successfully!',
        'data' => [
          'lead_id' => $lead_id,
          'lead_id_generated' => $lead_id_generated,
          'lead_name' => $lead_name,
          'lead_mobile' => $lead_mobile,
          'appointment_id' => $appointment->sno,
          'appointment_id_generated' => $appointment_id_generated,
          'branch_id' => $branch_id,
          'appointment_datetime' => $appointment_datetime,
          'appointment_time' => $appointment_time_24hr,
          'coupon' => $coupon_code, // Coupon for new lead
          'already_exists' => false,
          'sms_sent' => $sms_sent,
        ]
      ]);
    } catch (\Exception $e) {
      DB::rollBack();

      Log::error('Booking Error: ' . $e->getMessage());
      Log::error('Booking Error Trace: ' . $e->getTraceAsString());

      return response()->json([
        'success' => false,
        'error' => 'Failed to save booking: ' . $e->getMessage(),
        'data' => null
      ]);
    }
  }

  // Send SMS Function
  private function sendSMS($mobile, $name, $date, $time, $cre_mobile, $branch)
  {
    try {
      $result_sms = SmsTemplateModel::where('status', 0)
        ->where('template_name', '001_ThankyouEnquiry')
        ->first();

      if (!$result_sms) {
        return false;
      }

      $authkey = $result_sms->authkey;
      $sender_id = $result_sms->sender_id;
      $template_id = $result_sms->template_id;
      $country_code = $result_sms->country_code;
      $message_content = $result_sms->sms_template_messagecontent;

      $mobile_number = $country_code . $mobile;

      // Replace placeholders
      $replacement_values = [$name, $cre_mobile];
      $message_content = preg_replace_callback(
        '/\{#var#\}/',
        function () use (&$replacement_values) {
          return array_shift($replacement_values);
        },
        $message_content
      );

      $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=default&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

      $ch = curl_init();
      curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => [
          'authkey' => $authkey,
          'mobiles' => $mobile_number,
          'message' => $message_content,
          'sender' => $sender_id,
          'route' => 'default',
        ],
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
      ]);

      $response = curl_exec($ch);
      curl_close($ch);

      return $response ? true : false;
    } catch (\Exception $e) {
      Log::error('SMS Error: ' . $e->getMessage());
      return false;
    }
  }

  // Send WhatsApp Function
  private function sendWhatsApp($mobile, $name, $date, $time, $branch, $branch_name)
  {
    try {
      $templateName = "elysium_academy_welcome_message";

      // Get greeting based on time
      date_default_timezone_set('Asia/Kolkata');
      $currentHour = (int) date('H');
      if ($currentHour >= 5 && $currentHour < 12) {
        $greeting = 'Good Morning';
      } elseif ($currentHour >= 12 && $currentHour < 18) {
        $greeting = 'Good Afternoon';
      } else {
        $greeting = 'Good Evening';
      }

      $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
      $couponCode = 'NOOFFER';
      $buttonIndex = 0;

      $bodyText = [
        [
          'type' => 'text',
          'text' => $greeting,
          'parameter_name' => 'greet_msg',
        ],
        [
          'type' => 'text',
          'text' => $name,
          'parameter_name' => 'customer_name',
        ],
        [
          'type' => 'text',
          'text' => $branch->website ?? 'https://elysiumacademy.org',
          'parameter_name' => 'web_link',
        ],
        [
          'type' => 'text',
          'text' => $branch_name,
          'parameter_name' => 'branch_name',
        ],
        [
          'type' => 'text',
          'text' => $branch->cre_mobile ?? '9677781155',
          'parameter_name' => 'contact_no',
        ],
        [
          'type' => 'text',
          'text' => $branch->mail ?? 'info@elysiumacademy.org',
          'parameter_name' => 'contact_email',
        ],
      ];

      $components = [];

      // Add Header
      $components[] = [
        'type' => 'header',
        'parameters' => [
          [
            'type' => 'image',
            'image' => ['link' => $headerImage],
          ],
        ],
      ];

      // Add Body
      $components[] = [
        'type' => 'body',
        'parameters' => $bodyText,
      ];

      // Add Button
      $components[] = [
        'type' => 'button',
        'sub_type' => 'copy_code',
        'index' => $buttonIndex,
        'parameters' => [
          [
            'type' => 'coupon_code',
            'coupon_code' => $couponCode,
          ],
        ],
      ];

      // WhatsApp API credentials (you need to set these in your .env or config)
      $accessToken = config('services.whatsapp.access_token');
      $phoneNumberId = config('services.whatsapp.phone_number_id');

      if (!$accessToken || !$phoneNumberId) {
        Log::warning('WhatsApp credentials not configured');
        return false;
      }

      $apiUri = 'https://graph.facebook.com/v21.0/' . $phoneNumberId . '/messages';

      $to = $mobile;
      if (strpos($to, '+91') !== 0) {
        $to = '+91' . $to;
      }

      $payload = [
        'messaging_product' => 'whatsapp',
        'to' => $to,
        'type' => 'template',
        'template' => [
          'name' => $templateName,
          'language' => ['code' => 'en_US'],
          'components' => $components,
        ],
      ];

      $ch = curl_init();
      curl_setopt_array($ch, [
        CURLOPT_URL => $apiUri,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
          'Authorization: Bearer ' . $accessToken,
          'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
      ]);

      $response = curl_exec($ch);
      curl_close($ch);

      return $response ? true : false;
    } catch (\Exception $e) {
      Log::error('WhatsApp Error: ' . $e->getMessage());
      return false;
    }
  }

  // Send Email Function
  private function sendEmail($email, $name, $date, $time, $branch, $branch_name)
  {
    try {
      $email_template_id = 6; // thank you template
      $emailTemplate = EmailTemplateModel::where('status', 0)
        ->where('sno', $email_template_id)
        ->first();

      if (!$emailTemplate) {
        return false;
      }

      $content = $emailTemplate->email_subject;

      // Replace placeholders
      $branchNo = $branch->mobile ?? '';
      $branchemail = $branch->mail ?? 'info@elysiumacademy.org';
      $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
      $instaLink = $branch->insta_link ?? 'https://www.instagram.com/elysiumacademy/';
      $website = $branch->website ?? 'https://elysiumacademy.org/';
      $sales_mobile = $branch->sales_mobile ?? '9677781155';
      $cre_mobile = $branch->cre_mobile ?? '9677781155';

      $content = str_replace('#name', $name, $content);
      $content = str_replace('#webLink', $website, $content);
      $content = str_replace('#salesNo', $sales_mobile, $content);
      $content = str_replace('#CRENo', $cre_mobile, $content);
      $content = str_replace('#BranchName', $branch_name, $content);
      $content = str_replace('#mail', $branchemail, $content);
      $content = str_replace('#appointment_date', $date, $content);
      $content = str_replace('#appointment_time', $time, $content);

      $mailData = [
        'url' => 'Eapl.com',
        'subject' => $emailTemplate->email_name,
        'content' => $content,
        'branchNo' => $branchNo,
        'branchemail' => $branchemail,
        'fbLink' => $fbLink,
        'instaLink' => $instaLink,
        'salesMobile' => $sales_mobile,
      ];

      $to_address = $email;
      $from_address = 'elysiumacademy@elysium.community';
      $from_name = 'Elysium Academy ' . "\xC2\xAE";

      // Log::info("Mail data: " . json_encode($mailData));
      Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

      return true;
    } catch (\Exception $e) {
      Log::error('Email Error: ' . $e->getMessage());
      return false;
    }
  }
}
