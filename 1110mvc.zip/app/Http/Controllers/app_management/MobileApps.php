<?php

namespace App\Http\Controllers\app_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MobileApps extends Controller
{
  public function index()
  {
    return view('content.app_management.classmate_app');
  }

  public function guidy_app()
  {
    return view('content.app_management.guidy_app');
  }

  public function exam_portal()
  {
    return view('content.app_management.exam_portal_app');
  }
    public function score_pilot()
  {
    return view('content.app_management.scorepilot');
  }
    public function clari_app()
  {
    return view('content.app_management.clari');
  }
    public function e_learning_portal()
  {
    return view('content.app_management.e-learning');
  }
   public function HeadHub()
  {
    return view('content.app_management.headhub');
  }
  public function Audit()
  {
    return view('content.app_management.audit');
  }
}
?>