<?php

namespace App\Http\Controllers\toolbar_calculator;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BatchModel;
use App\Models\ManageCoursesModel;
use App\Models\SlotModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ToolbarCalculator extends Controller
{

    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $course_name_fill = $request->course_name_fill_sno ?? '';
        $custom_date_fill = $request->custom_date_fill ?? '';

        // Fetch slots that are not closed
        $slot_list = SlotModel::where('status', 0)
            ->where('branch_id', $branch_id) // Order by start_time
            ->orderBy('start_time', 'asc') // Order by start_time
            ->get()
            // ->unique(function ($item) {
            //     return $item['start_time'] . '-' . $item['slot_type_id'];
            // })
            ->keyBy('sno');

        // return $slot_list;

        // Fetch staff details with active slot times aggregated
        $staff_list = StaffModel::select(
            'za_staff.sno',
            'za_staff.nick_name',
            'za_staff.staff_name',
            'za_staff.position_role',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.shift_time_id',
            'za_shift_time.shift_time_name',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_end_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_shift_time.shift_sunday',
            // 'za_free_slot.slot_id as batch_slot_id',
            DB::raw('LPAD(COUNT(DISTINCT CASE WHEN za_free_slot.status = 0 THEN za_free_slot.batch_id END), 2, "0") as slot_count'),
            DB::raw('LPAD(COUNT(DISTINCT CASE WHEN za_training.end_date > NOW() THEN za_training.customer_id END), 2, "0") as student_count'),
            DB::raw('MIN(za_slot.start_time) as active_slot_start_time'), // Aggregate to get minimum start time
            DB::raw('MAX(za_slot.end_time) as active_slot_end_time') // Aggregate to get maximum end time
        )
            ->leftJoin('za_free_slot', function ($join) {
                $join->on('za_free_slot.staff_id', '=', 'za_staff.sno')
                    ->where('za_free_slot.status', '=', 0);
            })
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_training', 'za_training.staff_id', '=', 'za_staff.sno')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->where('za_staff.status', 0)
            ->where('za_staff.branch_id', $branch_id)
            ->where('za_staff.department_id', 2);

        $staff_list = $staff_list->groupBy(
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.position_role',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.shift_time_id',
            'za_shift_time.shift_time_name',
            'za_shift_time.shift_end_time',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            // 'za_free_slot.slot_id',
            'za_shift_time.shift_sunday'
        )
            ->orderBy('za_staff.sno', 'desc');

        if ($course_name_fill) {
            $staff_list->where('za_batch.course_id', $course_name_fill);
        }
        if ($custom_date_fill) {
            $toDate = date('Y-m-d', strtotime($custom_date_fill));
            $staff_list->where(function ($q) use ($toDate) {
                $q->where('za_batch.batch_start_date', '<=', $toDate)
                    ->where('za_batch.batch_end_date', '>=', $toDate);
            });
        }
        $staff_list = $staff_list->get();
        
        // $staffFreeSlotMap = DB::table('za_free_slot')
        // ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
        // ->where('za_batch.status', 0)
        // ->whereIn('za_batch.staff_id', $staff_list->pluck('sno'))
        // ->where('za_batch.end_date', '>=', date('Y-m-d'))
        // ->select('za_batch.staff_id', 'za_free_slot.slot_id', 'za_free_slot.batch_id') // include batch_id
        // ->get()
        // ->unique('batch_id') // keep only one entry per batch_id across all records
        // ->groupBy('staff_id')
        // ->map(function ($slots) {
        //     return $slots->pluck('slot_id')->unique()->values()->toArray();
        // });

      $staffFreeSlotMap = DB::table('za_free_slot')
        ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
        ->where('za_batch.status', 0)
        ->whereIn('za_batch.staff_id', $staff_list->pluck('sno'))
        ->where('za_batch.end_date', '>=', date('Y-m-d'))
        ->select('za_batch.staff_id', 'za_batch.slot_id') 
        ->get()
        ->groupBy('staff_id')
        ->map(function ($slots) {
            return $slots->pluck('slot_id')->toArray();
        });
            
            //   $staffFreeSlotMap = DB::table('za_free_slot')
            // ->where('status', 0)
            // ->whereIn('staff_id', $staff_list->pluck('sno'))
            // ->where('batch_end_date', '>=', date('Y-m-d'))
            // ->get()
            // ->groupBy('staff_id')
            // ->map(function ($slots) {
            //     return $slots->pluck('slot_id')->toArray();
            // });
            
            // return  $staffFreeSlotMap;
    
        // Prepare shift status
        $shift_status = [];
        $active_slot_count = [];
        $lunch_slot_count = [];

        $active_days_slot_count = [];
        $active_sat_slot_count = [];
        $active_sun_slot_count = [];
        $total_day_slot_count = [];
        $total_sat_slot_count = [];

       
        
        foreach ($slot_list as $slot) {
            $slot->slot_name=$slot->slot_name;
            $shift_status[$slot->sno] = []; // Use slot sno as the key
            
            foreach ($staff_list as $staff) {
                
                // Convert times to Carbon instances for easy comparison
                $shiftStartTime = Carbon::parse($staff->shift_start_time);
                $shiftEndTime = Carbon::parse($staff->shift_end_time);
                $slotStartTime = Carbon::parse($slot->start_time);
                $slotEndTime = Carbon::parse($slot->end_time);
                $activeSlotStartTime = Carbon::parse($staff->active_slot_start_time);
                $activeSlotEndTime = Carbon::parse($staff->active_slot_end_time);

                $status = '';
                $staffActiveCount=0;
                // Determine initial slot status
                if (in_array($slot->sno, $staffFreeSlotMap[$staff->sno] ?? [])) {
                    $status = 'Active';
                    $staffActiveCount = DB::table('za_free_slot')
                        ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
                         ->where('za_batch.staff_id', $staff->sno) 
                          ->where('za_batch.status', 0)
                         ->where('za_batch.slot_id', $slot->sno)
                         ->where('za_batch.end_date', '>=', date('Y-m-d'))
                          ->distinct('za_free_slot.batch_id')
                        ->count();
                }else{
                    if ($slotStartTime->lt($shiftStartTime)) {
                        $status = 'Shift Not Yet Started';
                    } elseif ($slotStartTime->gt($shiftEndTime)) {
                        $status = 'Shift Ended';
                    } elseif ($slotStartTime->between($shiftStartTime, $shiftEndTime)) {
                            $status = 'Free Slot';
                    }

                    // Check lunch break
                    $lunchStartTime = Carbon::parse($staff->shift_lunch_start);
                    $lunchEndTime = Carbon::parse($staff->shift_lunch_end);

                    if ($slot->slot_type_id == 1) {
                        if ($slotStartTime == $lunchStartTime) {
                            $status = 'Lunch & Learning Time';
                        }
                    } elseif ($slot->slot_type_id == 2) {
                        if ($staff->shift_time_id == 16) {
                            if ($slot->start_time == "12:30:00") {
                                $status = 'Lunch & Learning Time';
                            }
                        } elseif ($staff->shift_time_id == 17) {
                            if ($slot->start_time == "13:30:00") {
                                $status = 'Lunch & Learning Time';
                            }
                        } else {
                            if ($slot->start_time == "11:30:00") {
                                $status = 'Lunch & Learning Time';
                            }
                        }
                    } elseif ($slot->slot_type_id == 3) {
                        if ($slot->start_time == "12:30:00") {
                            $status = 'Lunch & Learning Time';
                        }
                    }
                }
              

                

               

                // Count active slots
                if ($status === 'Active') {
                    if (!isset($active_slot_count[$staff->sno])) {
                        $active_slot_count[$staff->sno] = 0;
                    }
                    $active_slot_count[$staff->sno]++;

                    // Count active slots based on slot_type_id
                    switch ($slot->slot_type_id) {
                        case 1: // For active days
                            $active_days_slot_count[$staff->sno] = ($active_days_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 2: // For active Saturdays
                            $active_sat_slot_count[$staff->sno] = ($active_sat_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 3: // For active Sundays
                            $active_sun_slot_count[$staff->sno] = ($active_sun_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                    }
                }

                // Count lunchtime slots
                if ($status === 'Lunch Time') {
                    if (!isset($lunch_slot_count[$staff->sno])) {
                        $lunch_slot_count[$staff->sno] = 0;
                    }
                    $lunch_slot_count[$staff->sno]++;
                }

                if ($status === 'Active' || $status === 'Free Slot') {
                    switch ($slot->slot_type_id) {
                        case 1: // For total day slots
                            $total_day_slot_count[$staff->sno] = ($total_day_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 2: // For total Saturday slots
                            $total_sat_slot_count[$staff->sno] = ($total_sat_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 3: // For total Sundays
                            $total_sun_slot_count[$staff->sno] = ($total_sun_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                    }
                }

                 // Append status for the staff and the current slot
                 $shift_status[$slot->sno][$staff->sno] = [
                    'staff_id' => $staff->sno,
                    'active_count' => $staffActiveCount  ??0,
                    'status' => $status,
                    'activeSlotStartTime' => $activeSlotStartTime,
                    'slot_start_time' => $slot->start_time,
                    'slot_end_time' => $slot->end_time,
                    'staff_start_time' => $staff->shift_start_time,
                ];
            }
            // return $slot_list;
            // exit;
        }

        foreach ($staff_list as $staff) {

            $staffBatchCountDay = DB::table('za_free_slot')
            ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
            ->where('za_batch.status', 0)
            ->Join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->where('za_batch.staff_id', $staff->sno)
            ->where('za_slot.slot_type_id', 1)
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
            ->distinct('za_free_slot.batch_id')
            ->count();

            $staffBatchCountSat = DB::table('za_free_slot')
             ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
            ->where('za_batch.status', 0)
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->where('za_batch.staff_id', $staff->sno)
            ->where('za_slot.slot_type_id', 2)
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
             ->distinct('za_free_slot.batch_id')
            ->count();

            $staffBatchCountSun = DB::table('za_free_slot')
             ->join('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
            ->where('za_batch.status', 0)
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->where('za_batch.staff_id', $staff->sno)
            ->where('za_slot.slot_type_id', 3)
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
             ->distinct('za_free_slot.batch_id')
            ->count();

            $staff->activeBatchCountDay = $staffBatchCountDay ?? 0;
            $staff->activeBatchCountSat = $staffBatchCountSat ?? 0;
            $staff->activeBatchCountSun = $staffBatchCountSun ?? 0;
            $staff->active_slot_count = $active_slot_count[$staff->sno] ?? 0;
            $staff->lunch_slot_count = $lunch_slot_count[$staff->sno] ?? 0;
            $staff->active_days_slot_count = $active_days_slot_count[$staff->sno] ?? 0;
            $staff->active_sat_slot_count = $active_sat_slot_count[$staff->sno] ?? 0;
            $staff->active_sun_slot_count = $active_sun_slot_count[$staff->sno] ?? 0;
            $staff->total_day_slot_count = $total_day_slot_count[$staff->sno] ?? 0;
            $staff->total_sat_slot_count = $total_sat_slot_count[$staff->sno] ?? 0;
            $staff->total_sun_slot_count = $total_sun_slot_count[$staff->sno] ?? 0;
        }

        // course_List for filter dropdown
        $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();

        // batches for minimum batch

        $allocatedStudentsSubquery = DB::table('za_training')
            ->select(DB::raw('COUNT(*)'))
            ->whereRaw('za_training.batch_id = za_batch.sno');

        $batches = BatchModel::select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',
            DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
        )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', 0)
            ->where('za_batch.branch_id', $branch_id)
            ->where('za_batch.end_date', '>=', date('Y-m-d'))
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_staff.staff_name',
                 'za_staff.nick_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time'
            );
             if ($course_name_fill) {
                 $batches->where('za_batch.course_id', $course_name_fill);
                }
                if ($custom_date_fill) {
                    $toDate = date('Y-m-d', strtotime($custom_date_fill));
                     $batches->where(function ($q) use ($toDate) {
                        $q->where('za_batch.batch_start_date', '<=', $toDate)
                            ->where('za_batch.batch_end_date', '>=', $toDate);
                    });
                }
           $batches= $batches->orderBy('za_batch.sno','desc')->get();
        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();

        // Check if general settings are available
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Define days of the week
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        // Get the current day of the week
        $currentDay = Carbon::now()->format('l');

        // Map through the batches to format dates and add additional fields
        $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
            // Format dates and times
            $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
            $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
            $item->formatted_start_time = Carbon::parse($item->start_time)->format('H:i:A'); // Use 'H:i' for sorting
            $item->formatted_end_time = Carbon::parse($item->end_time)->format('H:i:A'); // Use 'H:i' for sorting

            // Convert slot_type_days from JSON to an array of day names
            $dayIndices = json_decode($item->slot_type_days);
            $dayNames = [];

            foreach ($dayIndices as $index) {
                $dayIndex = (int) $index - 1; // Convert to 0-based index
                $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
            }

            // Join day names into a comma-separated string
            $item->days = implode(', ', $dayNames);

            // Calculate available students
            $item->available_students = $item->max_students - $item->allocated_students;

            // Calculate completed days since start_date
            $startDate = Carbon::parse($item->start_date);
            $currentDate = Carbon::now();
            $completedDays = $currentDate->isSameDay($startDate) || $currentDate->isBefore($startDate) ? 0 : $currentDate->diffInDays($startDate);
            $item->completed_days = str_pad($completedDays, 2, '0', STR_PAD_LEFT);

            return $item;
        });

        // Filter batches to only include those where current day is in the days
        $filteredBatches = $formattedBatches->filter(function ($item) use ($currentDay) {
            return in_array($currentDay, explode(', ', $item->days));
        });

        // Sort batches by start time
        $sortedBatches = $filteredBatches->sortBy('formatted_start_time');
        // return $staff_list;
        return view('content.toolbar_calculator.toolbar_calculator', [
            'slot_list' => $slot_list,
            'shift_status' => $shift_status,
            'staff_list' => $staff_list,
            'course_list' => $course_list,
            'sortedBatches' => $sortedBatches,
           'course_name_fill' => $course_name_fill,
           'custom_date_fill' => $custom_date_fill,

        ]);
    }
    public function toolbar_filter(Request $request)
    {
        // return $request;

        $branch_id = $request->user()->branch_id;
        $helper = new \App\Helpers\Helpers();
        if ($branch_id) {
            $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
        } else {
            $get_branch_type = 0;
        }
        $course_name_fill = $request->course_name_fill_sno ?? '';
        $custom_date_fill = $request->custom_date_fill ?? '';

        $slot_list = SlotModel::where('status', 0)
            ->orderBy('start_time', 'asc') // Order by start_time
            ->get()
            ->unique(function ($item) {
                return $item['start_time'] . '-' . $item['slot_type_id'];
            })
            ->keyBy('sno');

        // Fetch staff details with active slot times aggregated
        $staff_list = StaffModel::select(
            'za_staff.sno',
            'za_staff.nick_name',
            'za_staff.staff_name',
            'za_staff.position_role',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.shift_time_id',
            'za_shift_time.shift_time_name',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_end_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_shift_time.shift_sunday',
            DB::raw('LPAD(COUNT(DISTINCT CASE WHEN za_free_slot.status = 0 THEN za_free_slot.batch_id END), 2, "0") as slot_count'),
            DB::raw('LPAD(COUNT(DISTINCT CASE WHEN za_training.end_date > NOW() THEN za_training.customer_id END), 2, "0") as student_count'),
            DB::raw('MIN(za_slot.start_time) as active_slot_start_time'), // Aggregate to get minimum start time
            DB::raw('MAX(za_slot.end_time) as active_slot_end_time') // Aggregate to get maximum end time
        )
            ->leftJoin('za_free_slot', function ($join) {
                $join->on('za_free_slot.staff_id', '=', 'za_staff.sno')
                    ->where('za_free_slot.status', '=', 0);
            })
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_free_slot.batch_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_training', 'za_training.staff_id', '=', 'za_staff.sno')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 2);

        if ($branch_id != 0) {
            $staff_list->where('za_staff.branch_id', $branch_id);
        }

        $staff_list = $staff_list->groupBy(
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.position_role',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.shift_time_id',
            'za_shift_time.shift_time_name',
            'za_shift_time.shift_end_time',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_shift_time.shift_sunday'
        )
            ->orderBy('za_staff.sno', 'desc');

        if ($course_name_fill) {
            $staff_list->where('za_free_slot.course_id', $course_name_fill);
        }
        if ($custom_date_fill) {
            $toDate = date('Y-m-d', strtotime($custom_date_fill));
            $staff_list->where(function ($q) use ($toDate) {
                $q->where('za_free_slot.batch_start_date', '<=', $toDate)
                    ->where('za_free_slot.batch_end_date', '>=', $toDate);
            });
        }
        $staff_list = $staff_list->get();

        $shift_status = [];
        $active_slot_count = [];
        $lunch_slot_count = [];
        $active_days_slot_count = [];
        $active_sat_slot_count = [];
        $active_sun_slot_count = [];
        $total_day_slot_count = [];
        $total_sat_slot_count = [];
        $total_sun_slot_count = [];

        foreach ($slot_list as $slot) {
            $shift_status[$slot->sno] = []; // Use slot sno as the key
            foreach ($staff_list as $staff) {
                // Convert times to Carbon instances for easy comparison
                $shiftStartTime = Carbon::parse($staff->shift_start_time);
                $shiftEndTime = Carbon::parse($staff->shift_end_time);
                $slotStartTime = Carbon::parse($slot->start_time);
                $slotEndTime = Carbon::parse($slot->end_time);
                $activeSlotStartTime = Carbon::parse($staff->active_slot_start_time);
                $activeSlotEndTime = Carbon::parse($staff->active_slot_end_time);

                $status = '';

                // Determine initial slot status
                if ($slotStartTime->lt($shiftStartTime)) {
                    $status = 'Shift Not Yet Started';
                } elseif ($slotStartTime->gt($shiftEndTime)) {
                    $status = 'Shift Ended';
                } elseif ($slotStartTime->between($shiftStartTime, $shiftEndTime)) {
                    if ($slotStartTime == $activeSlotStartTime) {
                        $status = 'Active';
                    } else {
                        $status = 'Free Slot';
                    }
                }

                // Check lunch break
                $lunchStartTime = Carbon::parse($staff->shift_lunch_start);
                $lunchEndTime = Carbon::parse($staff->shift_lunch_end);

                if ($slot->slot_type_id == 1) {
                    if ($slotStartTime == $lunchStartTime) {
                        $status = 'Lunch & Learning Time';
                    }
                } elseif ($slot->slot_type_id == 2) {
                    if ($staff->shift_time_id == 16) {
                        if ($slot->start_time == "12:30:00") {
                            $status = 'Lunch & Learning Time';
                        }
                    } elseif ($staff->shift_time_id == 17) {
                        if ($slot->start_time == "13:30:00") {
                            $status = 'Lunch & Learning Time';
                        }
                    } else {
                        if ($slot->start_time == "11:30:00") {
                            $status = 'Lunch & Learning Time';
                        }
                    }
                } elseif ($slot->slot_type_id == 3) {
                    if ($slot->start_time == "12:30:00") {
                        $status = 'Lunch & Learning Time';
                    }
                }

                // Append status for the staff and the current slot
                $shift_status[$slot->sno][$staff->sno] = [
                    'staff_id' => $staff->sno,
                    'status' => $status,
                    'activeSlotStartTime' => $activeSlotStartTime,
                    'slot_start_time' => $slot->start_time,
                    'staff_start_time' => $staff->shift_start_time,
                ];

                // Count active slots
                if ($status === 'Active') {
                    if (!isset($active_slot_count[$staff->sno])) {
                        $active_slot_count[$staff->sno] = 0;
                    }
                    $active_slot_count[$staff->sno]++;

                    // Count active slots based on slot_type_id
                    switch ($slot->slot_type_id) {
                        case 1: // For active days
                            $active_days_slot_count[$staff->sno] = ($active_days_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 2: // For active Saturdays
                            $active_sat_slot_count[$staff->sno] = ($active_sat_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 3: // For active Sundays
                            $active_sun_slot_count[$staff->sno] = ($active_sun_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                    }
                }

                // Count lunchtime slots
                if ($status === 'Lunch Time') {
                    if (!isset($lunch_slot_count[$staff->sno])) {
                        $lunch_slot_count[$staff->sno] = 0;
                    }
                    $lunch_slot_count[$staff->sno]++;
                }

                if ($status === 'Active' || $status === 'Free Slot') {
                    switch ($slot->slot_type_id) {
                        case 1: // For total day slots
                            $total_day_slot_count[$staff->sno] = ($total_day_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 2: // For total Saturday slots
                            $total_sat_slot_count[$staff->sno] = ($total_sat_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                        case 3: // For total Sundays
                            $total_sun_slot_count[$staff->sno] = ($total_sun_slot_count[$staff->sno] ?? 0) + 1;
                            break;
                    }
                }
            }
        }

        // Add the active and lunch slot counts to the staff list for the view
        foreach ($staff_list as $staff) {
            $staff->active_slot_count = $active_slot_count[$staff->sno] ?? 0;
            $staff->lunch_slot_count = $lunch_slot_count[$staff->sno] ?? 0;
            $staff->active_days_slot_count = $active_days_slot_count[$staff->sno] ?? 0;
            $staff->active_sat_slot_count = $active_sat_slot_count[$staff->sno] ?? 0;
            $staff->active_sun_slot_count = $active_sun_slot_count[$staff->sno] ?? 0;
            $staff->total_day_slot_count = $total_day_slot_count[$staff->sno] ?? 0;
            $staff->total_sat_slot_count = $total_sat_slot_count[$staff->sno] ?? 0;
            $staff->total_sun_slot_count = $total_sun_slot_count[$staff->sno] ?? 0;
        }

        $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();

        // batches for minimum batch

        $allocatedStudentsSubquery = DB::table('za_training')
            ->select(DB::raw('COUNT(*)'))
            ->whereRaw('za_training.batch_id = za_batch.sno');

        $batches = BatchModel::select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_staff.staff_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',
            DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
        )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_staff.staff_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time'
            );

        if ($course_name_fill) {
            $batches->where('za_batch.course_id', $course_name_fill);
        }
        if ($custom_date_fill) {
            $toDate = date('Y-m-d', strtotime($custom_date_fill));
            $batches->where(function ($q) use ($toDate) {
                $q->where('za_batch.start_date', '<=', $toDate)
                    ->where('za_batch.end_date', '>=', $toDate);
            });
        }
        $batches = $batches->get();

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();

        // Check if general settings are available
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Define days of the week
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        // Get the current day of the week
        $currentDay = Carbon::now()->format('l');

        // Map through the batches to format dates and add additional fields
        $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
            // Format dates and times
            $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
            $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
            $item->formatted_start_time = Carbon::parse($item->start_time)->format('H:i:A'); // Use 'H:i' for sorting
            $item->formatted_end_time = Carbon::parse($item->end_time)->format('H:i:A'); // Use 'H:i' for sorting

            // Convert slot_type_days from JSON to an array of day names
            $dayIndices = json_decode($item->slot_type_days);
            $dayNames = [];

            foreach ($dayIndices as $index) {
                $dayIndex = (int) $index - 1; // Convert to 0-based index
                $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
            }

            // Join day names into a comma-separated string
            $item->days = implode(', ', $dayNames);

            // Calculate available students
            $item->available_students = $item->max_students - $item->allocated_students;

            // Calculate completed days since start_date
            $startDate = Carbon::parse($item->start_date);
            $currentDate = Carbon::now();
            $completedDays = $currentDate->isSameDay($startDate) || $currentDate->isBefore($startDate) ? 0 : $currentDate->diffInDays($startDate);
            $item->completed_days = str_pad($completedDays, 2, '0', STR_PAD_LEFT);

            return $item;
        });

        // Filter batches to only include those where current day is in the days
        $filteredBatches = $formattedBatches->filter(function ($item) use ($currentDay) {
            return in_array($currentDay, explode(', ', $item->days));
        });

        // Sort batches by start time
        $sortedBatches = $filteredBatches->sortBy('formatted_start_time');

        return view('content.toolbar_calculator.toolbar_calculator', [
            'slot_list' => $slot_list,
            'shift_status' => $shift_status,
            'staff_list' => $staff_list,
            'course_list' => $course_list,
            'sortedBatches' => $sortedBatches,
            'course_name_fill' => $course_name_fill,

        ])->with('filter_on', true);
    }

}
