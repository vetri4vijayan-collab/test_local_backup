<?php

namespace App\Http\Controllers\courses;

use App\Http\Controllers\Controller;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use App\Models\BranchModel;
use App\Models\CostingModel;
use App\Models\Batch_staff_swap_Model;
use App\Models\CourseTypeModel;
use App\Models\FreeSlotModel;
use App\Models\ManageCertificateModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\BatchExtensionModel;
use App\Models\SyllabusUpdateModel;
use App\Models\SlotModel;
use App\Models\StaffModel;
use App\Models\TrainingModel;
use App\Models\BatchHistoryModel;
use App\Models\CustomerModel;
use App\Models\PaymentModel;
use DateTime;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageBatch extends Controller
{
    // public function index(Request $request)
    // {
    //     $branch_id = $request->user()->branch_id;

    //     $batchQuery = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status')
    //         ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
    //         ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
    //         ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
    //         ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
    //         ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
    //         ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //         ->where('za_batch.status', '!=', [2, 3]);

    //     if ($branch_id != 0) {
    //         $batchQuery->where('za_batch.branch_id', $branch_id);
    //     }

    //     $batch = $batchQuery->orderBy('sno', 'desc')->paginate(10);

    //     // Get the student count for each batch
    //     foreach ($batch as $singleBatch) {
    //         $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
    //         // Uncomment the next line if you want to filter by course_id
    //         // ->where('course_id', $singleBatch->course_id)
    //             ->count('customer_id');
    //     }
    //     // return $batch;

    //     // Prepare the course types
    //     $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();

    //     // Return the view
    //     return view('content.courses.managebatch_list', [
    //         'batch' => $batch,
    //         'course_Type_list' => $course_type,
    //         'course_type_fill' => '',
    //         'course_fill' => '',
    //         'batch_name_fill' => '',
    //         'fin_yr_fill' => '',
    //         'date_filter' => '',
    //     ])->with('filter_on', false);

    //     // return view( 'content.courses.managebatch_list' );
    // }
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $fee_unpaid_count = 0;
        // upcoming Batch details
        $dropped_fill = $request->get('dropped', $dropped ?? '');

        $upcoming_batch = BatchModel::where('status', 0)
            ->where('start_date', '>', now());
        if ($branch_id != 0) {
            $upcoming_batch->where('branch_id', $branch_id);
        }
        $upcoming_batch = $upcoming_batch->get();

        $upcoming_batch_student_count = 0;
        foreach ($upcoming_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $upcoming_batch_student_count = $upcoming_batch_student_count + $student_count;
        }
        $upcoming_batch_count = count($upcoming_batch);
        
        // dropped batch count
        $dropped_batch = BatchModel::where('status', 4);
        if ($branch_id != 0) {
            $dropped_batch->where('branch_id', $branch_id);
        }
        $dropped_batch = $dropped_batch->get();

        $dropped_batch_student_count = 0;
        foreach ($dropped_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $dropped_batch_student_count = $dropped_batch_student_count + $student_count;
        }
        $dropped_batch_count = count($dropped_batch);

        // ongoing Batch details

        $ongoing_batch = BatchModel::where('status', 0)
            ->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now());
        if ($branch_id != 0) {
            $ongoing_batch->where('branch_id', $branch_id);
        }
        $ongoing_batch = $ongoing_batch->get();
        $ongoing_batch_student_count = 0;
        foreach ($ongoing_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $ongoing_batch_student_count = $ongoing_batch_student_count + $student_count;
        }
        $ongoing_batch_count = count($ongoing_batch);
        // return $ongoing_batch_count;

        $today = Carbon::now();
        $dayTypeCondition = null;

        if ($today->isWeekday()) {
            $dayTypeCondition = 1; // Weekday (Monday to Friday)
        } elseif ($today->isSaturday()) {
            $dayTypeCondition = 2; // Saturday
        } elseif ($today->isSunday()) {
            $dayTypeCondition = 3; // Sunday
        }

        $today_running_batch = BatchModel::where('za_batch.status', 0)
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->whereDate('za_batch.start_date', '<=', $today)
            ->whereDate('za_batch.end_date', '>=', $today)
            ->where('za_slot.slot_type_id', $dayTypeCondition);
        if ($branch_id != 0) {
            $today_running_batch->where('za_batch.branch_id', $branch_id);
        }

        $today_total_batch_count = $today_running_batch->count();

        // Add the day-type condition
        $todayAttent_count = $today_running_batch->whereJsonContains('za_batch.attendance_status', ['date' => $today->toDateString()])
            ->count();

        $batchQuery = BatchModel::select(
                        'za_batch.*',
                        'za_slot.slot_name',
                        'za_course.course_name',
                        'za_course_type.course_type_name',
                        'za_class_room.class_room_name',
                        'za_slot_type.slot_type_name',
                        'za_slot.start_time',
                        'za_slot.end_time',
                        'za_staff.staff_name',
                        'za_slot.slot_type_id'
                    )
                    ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
                    ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
                    ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
                    ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
                    ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                    ->where('za_batch.status', '!=', [2, 3]);
                    

            
        // $batchQuery = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status', 'za_slot.slot_type_id')
        //     ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        //     ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        //     ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        //     ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        //     ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        //     ->leftJoin(DB::raw('za_batch_extension ON za_batch.sno = za_batch_extension.batch_id'), function($join) {
        //         $join->on(DB::raw('za_batch.sno'), '=', 'za_batch_extension.batch_id');
        //     })
        //     ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        //     ->where('za_batch.status', '!=', [2, 3]);


        if ($branch_id != 0) {
            $batchQuery->where('za_batch.branch_id', $branch_id);
        }
        
         if (!empty($dropped_fill)) {
            $batchQuery->where('za_batch.status', 4);
        }

        $batch = $batchQuery->orderBy('sno', 'desc')->paginate($perpage);
           // Step 1: Get all customers for the relevant batches in one query
            $customerData = TrainingModel::whereIn('batch_id', $batch->pluck('sno'))
                ->get()
                ->groupBy('batch_id'); // Group customers by batch_id
                // return $customerData;

        foreach ($batch as $singleBatch) {
            $attendance_status = $singleBatch->attendance_status ? json_decode($singleBatch->attendance_status, true) : [];

            if (!is_array($attendance_status)) {
                $attendance_status = [];
            }

            $today = Carbon::today()->format('Y-m-d'); // Carbon is a helper for date manipulation


            $att_date = null;
            foreach ($attendance_status as $attendance) {
                if (isset($attendance['date']) && $attendance['date'] == $today) {
                    $att_date = $today; // If found, set the attendance date to today
                    break;
                }
            }

            if ($att_date) {
                $singleBatch->att_date = $att_date;
            }

            // Count the number of students for the current batch
                $singleBatch->student_count = $customerData->get($singleBatch->sno, collect())->count();
                $batchCustomers = $customerData->get($singleBatch->sno, collect()); // Get customers for this batch
            
                if ($batchCustomers->isEmpty()) {
                    
                    $singleBatch->fee_unpaid_count = 'No Customers';
                } else{
                // Initialize unpaid fee count
                $fee_unpaid_count = 0;
        
                foreach ($batchCustomers as $customer) {
                    // Get outstanding payments for each customer
                    $outstandingPayments = PaymentModel::where('za_payment.branch_id', $singleBatch->branch_id)
                        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                        ->select('za_payment.payment_id', 'za_payment.sno as payment_sno', 'za_payment.branch_id',
                            'za_customer.customer_id', 'za_customer.sno as customer_sno', 'za_payment.initialPayDate',
                            'za_payment.nextPayDate', 'za_payment.amount', 'za_payment.paidAmount', 'za_payment.gst_amount',
                            'za_payment.balanceFee', 'za_payment.total_amount', 'za_payment.payment_mode_label', 
                            'za_payment.status as payment_status', 'za_customer.cus_name', 'za_customer.cus_pic',
                            'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_course.course_name',
                            'za_course.sno as course_sno', 'za_course.course_id')
                        ->where('za_payment.customer_id', $customer->customer_id)
                        ->where('za_payment.status', 0)  // Unpaid payments
                        ->where('za_customer.status', 0) // Active customers
                        ->whereDate('za_payment.nextPayDate', '<=', now()) // Due payments
                        ->get();
            
                    if ($outstandingPayments->isNotEmpty()) {
                        $fee_unpaid_count++; // Increment unpaid count if there are outstanding payments
                    }
                }
            
                // If no unpaid fees, mark the batch as No Overdue
                if ($fee_unpaid_count == 0) {
                    $singleBatch->fee_status = 'No Overdue';
                } else {
                    $singleBatch->fee_status = 'Unpaid: ' . $fee_unpaid_count;
                }
            
                // Attach the unpaid fee count to the batch object
                $singleBatch->fee_unpaid_count = $fee_unpaid_count;
            
                }
            $today_att = Carbon::now();
            $is_todaySlot = 0;
            $dayType = null;

            if ($today_att->isWeekday()) {
                $dayType = 1; // Weekday (Monday to Friday)
            } elseif ($today_att->isSaturday()) {
                $dayType = 2; // Saturday
            } elseif ($today_att->isSunday()) {
                $dayType = 3; // Sunday
            }
            if ($singleBatch->slot_type_id == $dayType) {
                $is_todaySlot = 1;
            }
            $singleBatch->is_todaySlot = $is_todaySlot;

        }
        $sortedBatch = $batch->getCollection()->sortByDesc(function ($singleBatch) {
            return [$singleBatch->att_date ?? Carbon::today()->addDays(1), $singleBatch->is_todaySlot];
        });

        // Replace the original collection with the sorted one
        $batch->setCollection($sortedBatch);
        // return $batch;

        $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();

        // Return the view
        return view('content.courses.managebatch_list', [
            'batch' => $batch,
            'course_Type_list' => $course_type,
            'upcoming_batch_count' => $upcoming_batch_count,
            'upcoming_batch_student_count' => $upcoming_batch_student_count,
            'ongoing_batch_count' => $ongoing_batch_count,
            'ongoing_batch_student_count' => $ongoing_batch_student_count,
            'today_total_batch_count' => $today_total_batch_count,
            'todayAttent_count' => $todayAttent_count,
            'dropped_batch_count' => $dropped_batch_count,
            'dropped_batch_student_count' => $dropped_batch_student_count,
            'course_type_fill' => '',
            'course_fill' => '',
            'batch_name_fill' => '',
            'dropped_fill' => '',
            'fin_yr_fill' => '',
            'batch_all_fill' => '',
            'perpage' => '',
            'date_filter' => '',
            'fee_unpaid_count' => $fee_unpaid_count, // Total unpaid count (if needed globally)
        ])->with('filter_on', false);

        // return view( 'content.courses.managebatch_list' );
    }

    public function list_filter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;

        // upcoming Batch details
        $dropped_fill = $request->get('dropped', $dropped ?? '');
        $upcoming_batch = BatchModel::where('status', 0)
            ->where('start_date', '>', now());
        if ($branch_id != 0) {
            $upcoming_batch->where('branch_id', $branch_id);
        }
        $upcoming_batch = $upcoming_batch->get();

        $upcoming_batch_student_count = 0;
        foreach ($upcoming_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $upcoming_batch_student_count = $upcoming_batch_student_count + $student_count;
        }
        $upcoming_batch_count = count($upcoming_batch);
        
        // dropped batch
        $dropped_batch = BatchModel::where('status', 4);
        if ($branch_id != 0) {
            $dropped_batch->where('branch_id', $branch_id);
        }
        $dropped_batch = $dropped_batch->get();

        $dropped_batch_student_count = 0;
        foreach ($dropped_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $dropped_batch_student_count = $dropped_batch_student_count + $student_count;
        }
        $dropped_batch_count = count($dropped_batch);

        // ongoing Batch details

        $ongoing_batch = BatchModel::where('status', 0)
            ->whereDate('start_date', '<=', Carbon::now())
            ->whereDate('end_date', '>=', Carbon::now());
        if ($branch_id != 0) {
            $ongoing_batch->where('branch_id', $branch_id);
        }
        $ongoing_batch = $ongoing_batch->get();
        $ongoing_batch_student_count = 0;
        foreach ($ongoing_batch as $singleBatch) {
            $student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $ongoing_batch_student_count = $ongoing_batch_student_count + $student_count;
        }
        $ongoing_batch_count = count($ongoing_batch);
        // return $ongoing_batch_count;

        $today = Carbon::now();
        $dayTypeCondition = null;

        if ($today->isWeekday()) {
            $dayTypeCondition = 1; // Weekday (Monday to Friday)
        } elseif ($today->isSaturday()) {
            $dayTypeCondition = 2; // Saturday
        } elseif ($today->isSunday()) {
            $dayTypeCondition = 3; // Sunday
        }

        $today_running_batch = BatchModel::where('za_batch.status', 0)
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->whereDate('za_batch.start_date', '<=', $today)
            ->whereDate('za_batch.end_date', '>=', $today)
            ->where('za_slot.slot_type_id', $dayTypeCondition);
        if ($branch_id != 0) {
            $today_running_batch->where('za_batch.branch_id', $branch_id);
        }

        $today_total_batch_count = $today_running_batch->count();

        // Add the day-type condition
        $todayAttent_count = $today_running_batch->whereJsonContains('za_batch.attendance_status', ['date' => $today->toDateString()])
            ->count();
        // return $request;
        // Retrieve request parameters with default values
        $course_type_fill = $request->course_type_fill ?? '';
        $course_fill = $request->course_fill ?? '';
        $batch_name_fill = $request->batch_name_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';
        $batch_all_fill = $request->batch_all_fill ?? '';

        // Initialize query with base conditions
        $query = BatchModel::where('za_batch.status', '!=', 2);
        
         $query->select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name',  'za_slot.slot_type_id')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.status', '!=', [2, 3])
            ->orderBy('za_batch.sno', 'desc');

        // Date Filtering Logic
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_batch.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_batch.end_date', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_batch.end_date', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_batch.end_date', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_batch.end_date', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_batch.end_date', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_batch.created_at', $condition['year'])
                                        ->whereMonth('za_batch.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }

        if ($course_type_fill) {
            $query->where('za_batch.course_type_id', $course_type_fill);
        }
        if ($course_fill) {
            $query->where('za_batch.course_id', $course_fill);
        }
        if ($batch_name_fill) {
            $query->where('batch_name', 'like', "%{$batch_name_fill}%");
        }
        if ($branch_id != 0) {
            $query->where('za_batch.branch_id', $branch_id);
        }
        if ($batch_all_fill != '') {
            $query->where(function ($sub_query) use ($batch_all_fill) {
                $sub_query->where('za_batch.batch_name', 'LIKE', "%{$batch_all_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$batch_all_fill}%")
                    ->orWhere('za_batch.end_date', 'LIKE', "%{$batch_all_fill}%")
                    ->orWhere('za_course.course_name', 'LIKE', "%{$batch_all_fill}%");
            });
        }

        // Fetch Branch list ordered by sno in descending order
        if (!empty($dropped_fill)) {
            $batchQuery->where('za_batch.status', 4);
        }
       
            
            

        $batch_list = $query->paginate($perpage);

        // Get the student count for each batch
        foreach ($batch_list as $singleBatch) {
            $attendance_status = $singleBatch->attendance_status ? json_decode($singleBatch->attendance_status, true) : [];

            if (!is_array($attendance_status)) {
                $attendance_status = [];
            }

            $today = Carbon::today()->format('Y-m-d'); // Carbon is a helper for date manipulation

            $att_date = null;
            foreach ($attendance_status as $attendance) {
                if (isset($attendance['date']) && $attendance['date'] == $today) {
                    $att_date = $today; // If found, set the attendance date to today
                    break;
                }
            }

            if ($att_date) {
                $singleBatch->att_date = $att_date;
            }

            $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
                ->count('customer_id');
            $today_att = Carbon::now();
            $is_todaySlot = 0;
            $dayType = null;

            if ($today_att->isWeekday()) {
                $dayType = 1; // Weekday (Monday to Friday)
            } elseif ($today_att->isSaturday()) {
                $dayType = 2; // Saturday
            } elseif ($today_att->isSunday()) {
                $dayType = 3; // Sunday
            }
            if ($singleBatch->slot_type_id == $dayType) {
                $is_todaySlot = 1;
            }
            $singleBatch->is_todaySlot = $is_todaySlot;

        }
        $sortedBatch = $batch_list->getCollection()->sortByDesc(function ($singleBatch) {
            return [$singleBatch->att_date ?? Carbon::today()->addDays(1), $singleBatch->is_todaySlot];
        });

        // Replace the original collection with the sorted one
        $batch_list->setCollection($sortedBatch);
        // return $batch;
        // return $batch_list;
        $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
        // Return the view with filter variables and session flash for filter_on
        return view('content.courses.managebatch_list', [
            'batch' => $batch_list,
            'course_Type_list' => $course_type,
            'course_type_fill' => $course_type_fill,
            'course_fill' => $course_fill,
            'batch_name_fill' => $batch_name_fill,
            'date_filter' => $date_filter,
            'fin_yr_fill' => $fin_yr_fill,
            'batch_all_fill' => $batch_all_fill,
            'dropped_fill' => $dropped_fill,
            'perpage' => $perpage,
            'upcoming_batch_count' => $upcoming_batch_count,
            'upcoming_batch_student_count' => $upcoming_batch_student_count,
            'ongoing_batch_count' => $ongoing_batch_count,
            'ongoing_batch_student_count' => $ongoing_batch_student_count,
            'today_total_batch_count' => $today_total_batch_count,
            'todayAttent_count' => $todayAttent_count,
            'dropped_batch_count' => $dropped_batch_count,
            'dropped_batch_student_count' => $dropped_batch_student_count,
        ])->with('filter_on', true);
    }

    public function getCourses(Request $request)
    {
        $courseTypeId = $request->input('course_type_id');
        // Fetch courses based on course_type_id
        // return $courseTypeId;
        $courses = ManageCoursesModel::where('course_type_id', $courseTypeId)->where('status', 0)->get();
        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }

    public function Add(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;

        if ($branch_code) {

            $shift_time_id = StaffModel::where('sno', $request->staff_id)->value('shift_time_id');

            $year = date("Y");
            $freeslt_check = FreeSlotModel::orderBy('sno', 'desc')->first();

            if (!$freeslt_check) {
                $free_slot_id = "{$year}/{$branch_code}/FRSL0001";
            } else {
                $data = $freeslt_check->free_slot_id;
                $slice = explode("/", $data);

                // Check if the slice has at least 3 elements
                if (count($slice) < 3) {
                    // Handle the error: for example, log it or set a default value
                    $free_slot_id = "{$year}/{$branch_code}/FRSL0001"; // Default value
                } else {
                    // Extract the numeric part and increment
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;

                    // Format the new training ID
                    $free_slot_id = "{$year}/{$branch_code}/" . sprintf("FRSL%04d", $next_number_cos);
                }
            }
        }
        $validator = Validator::make($request->all(), [
            'batch_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $batch_name = $request->batch_name;
            $course_type_id = $request->course_type_id;
            $course_id = $request->course_id;
            $slot_id = $request->slot_id;
            $classroom_id = $request->classroom_id;
            $max_students = $request->max_students;
            $staff_id = $request->staff_id;
            $batch_desc = $request->batch_desc;
            $course_summ = $request->course_summ;
            $end_date = date('Y-m-d', strtotime($request->end_date));
            $start_date = date('Y-m-d', strtotime($request->start_date));
            // $end_date = DateTime::createFromFormat( 'd-M-Y', $request->end_date );
            $user_id = 1;
            $chk = BatchModel::where('batch_name', ucwords($batch_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!',
                ]);
            } else {
                $category_check = BatchModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $batch_id = 'BT-0001/' . $year;
                } else {

                    $data = $category_check->batch_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('BT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $batch_id = $request . '/' . $year;
                }

                $add_category = new BatchModel();
                $add_category->batch_id = $batch_id;
                $add_category->batch_name = Ucfirst($batch_name);
                $add_category->course_type_id = $course_type_id;
                $add_category->course_id = $course_id;
                $add_category->slot_id = $slot_id;
                $add_category->start_date = $start_date;
                $add_category->end_date = $end_date;
                $add_category->classroom_id = $classroom_id;
                $add_category->max_students = $max_students;
                $add_category->staff_id = $staff_id;
                $add_category->course_summ = $course_summ;
                $add_category->branch_id = $branch_id;
                $add_category->batch_desc = $batch_desc;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                $add_category->save();

                // free slot

                $insert_free_slot = FreeSlotModel::create([
                    'free_slot_id' => $free_slot_id, // Assuming you want to use training_id here
                    'branch_id' => $branch_id,
                    'batch_id' => $add_category->sno,
                    'slot_id' => $slot_id ?? 0,
                    'course_id' => $course_id,
                    'batch_start_date' => $start_date ?? 0,
                    'batch_end_date' => $end_date ?? 0,
                    'staff_id' => $staff_id ?? 0,
                    'shift_time_id' => $shift_time_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Batch added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Batch!',
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'Batch Created successfully!');
        }
    }

    public function View($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Find the course by decrypted ID
        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

        // Check if the course is not found
        if (!$batch) {
            return redirect()->back()->with('error', 'Batch View not found');
        }

        // Generate date array for the current month
        $dates = [];
        for ($i = 1; $i <= date('t'); $i++) {
            $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
        }

        // Define the start and end of the month
        $startOfMonth = Carbon::now()->startOfMonth()->format('Y-m-d');
        $endOfMonth = Carbon::now()->endOfMonth()->format('Y-m-d');

        // Query for attendance records
        $attendance = BatchModel::select(
            'za_batch.*',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.staff_image',
            'za_user_role.role_name',
            'za_attendance.att_date'
        )
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->leftJoin('za_attendance', function ($join) {
                $join->on('za_attendance.staff_id', '=', 'za_batch.staff_id')
                    ->whereColumn('za_attendance.batch_id', 'za_batch.sno')
                    ->whereColumn('za_attendance.branch_id', 'za_batch.branch_id');
            })
            ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
            ->where('za_batch.status', '!=', 2)
            ->where('za_batch.sno', $decryptedValue) // Replace $decryptedValue with actual batch ID
            ->whereBetween('za_attendance.att_date', [$startOfMonth, $endOfMonth])
            ->get();

        $totalStudents = TrainingModel::where('za_training.batch_id', $batch->sno)
            // ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            // ->where('za_training.status', 0)
            ->distinct('za_training.customer_id') // Ensure unique customers
            ->count('za_training.customer_id'); // Count the unique customer_ids

        // return $totalStudents;

        $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
            // ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            // ->where('za_training.status', 0)
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_customer.customer_id', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();

        $batch_staff = $batch->staff_id;

        return view('content.courses.view_batch', [
            'view' => $batch,
            'stud_view' => $totalStudents,
            'dates' => $dates,
            'attendance' => $attendance,
            'batch_staff' => $batch_staff,
            'stud_list' => $lists,
        ]);

        // return $lists;
    }
    public function batch_staff_att($id = '')
    {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$batch) {
      return redirect()->back()->with('error', 'Batch View not found');
    }

    // Generate date array for the current month
    $dates = [];
    for ($i = 1; $i <= date('t'); $i++) {
      $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
    }

    // Define the start and end of the month
    $startOfMonth = Carbon::now()->startOfMonth()->format('Y-m-d');
    $endOfMonth = Carbon::now()->endOfMonth()->format('Y-m-d');

    // Query for attendance records
    $attendance = BatchModel::select(
      'za_batch.*',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_staff.staff_image',
      'za_user_role.role_name',
      'za_attendance.att_date'
    )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_attendance', function ($join) {
        $join->on('za_attendance.staff_id', '=', 'za_batch.staff_id')
          ->whereColumn('za_attendance.batch_id', 'za_batch.sno')
          ->whereColumn('za_attendance.branch_id', 'za_batch.branch_id');
      })
      ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_batch.sno', $decryptedValue) // Replace $decryptedValue with actual batch ID
      ->whereBetween('za_attendance.att_date', [$startOfMonth, $endOfMonth])
      ->get();

    $totalStudents = TrainingModel::where('za_training.batch_id', $batch->sno)
      ->where('za_training.staff_id', $batch->staff_id)
      ->where('za_training.course_id', $batch->course_id)
      ->where('za_training.status', 0)
      ->distinct('za_training.customer_id') // Ensure unique customers
      ->count('za_training.customer_id'); // Count the unique customer_ids

    // return $totalStudents;

    $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
      ->where('za_training.staff_id', $batch->staff_id)
      ->where('za_training.course_id', $batch->course_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_customer.customer_id', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();

    $batch_staff = $batch->staff_id;

    return view('content.courses.view_batch_staff_att', [
      'view' => $batch,
      'stud_view' => $totalStudents,
      'dates' => $dates,
      'attendance' => $attendance,
      'batch_staff' => $batch_staff,
      'stud_list' => $lists,
    ]);

    // return $lists;
  }

    public function viewBatchAttendance($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        
        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

        $dates = [];
        for ($i = 1; $i <= date('t'); $i++) {
            $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
        }
        
        $dates = [];
        $start_date = new DateTime($batch->start_date);
        $end_date = new DateTime($batch->end_date);
        
        while ($start_date <= $end_date) {
            $dates[] = $start_date->format('Y-m-d');
            $start_date->modify('+1 day');
        }


        

        if (!$batch) {
            return redirect()->back()->withErrors('Batch not found.');
        }

        $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
            // ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            // ->where('za_training.status', 0)
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();

        $att = TrainingModel::where('za_training.batch_id', $batch->sno)
            // -> where ('za_training.status', 0)
            ->join('za_attendance', 'za_training.batch_id', '=', 'za_attendance.batch_id')
        // ->where('za_attendance.customer_id', '=', 'za_training.customer_id')
            ->select(
                'za_attendance.batch_id',
                'za_attendance.sno',
                'za_attendance.course_id',
                'za_attendance.staff_id',
                'za_attendance.customer_id',
                'za_attendance.attendance as att',
                'za_attendance.feedback',
                'za_attendance.feedback_score',
                'za_attendance.total_duration',
                'za_attendance.att_date'
            )
            ->groupBy(
                'za_attendance.batch_id',
                'za_attendance.sno',
                'za_attendance.course_id',
                'za_attendance.staff_id',
                'za_attendance.customer_id',
                'za_attendance.attendance',
                'za_attendance.feedback',
                'za_attendance.feedback_score',
                'za_attendance.total_duration',
                'za_attendance.att_date'
            )
            ->get();

        // return $att;

        $attWithDates = [];
        foreach ($dates as $date) {
            $attWithDates[$date] = [
                'date' => $date,
                'attendance' => [],
            ];
        }

        foreach ($att as $attendance) {
            $attendanceDate = $attendance->att_date;
            if (isset($attWithDates[$attendanceDate])) {
                $attWithDates[$attendanceDate]['attendance'][] = [
                    'att' => $attendance->att,
                    'total_duration' => $attendance->total_duration,
                    'customer_id' => $attendance->customer_id,
                    'feedback_score' => $attendance->feedback_score,
                    'feedback' => $attendance->feedback,
                ];
            }   
        }

        foreach ($attWithDates as $date => $attendanceData) {
            if (empty($attendanceData['attendance'])) {
                $attWithDates[$date]['attendance'][] = [
                    'att' => 'NA',
                    'total_duration' => null,
                ];
            }
        }
        // return  array_values($attWithDates);

        return view('content.courses.view_batch_attendance', [
            'view' => $lists,
            'dates' => $dates,
            'batch' => $batch,
            'att' => array_values($attWithDates),
        ]);
    }
    public function view_batch_staff_attendance($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $dates = [];
        for ($i = 1; $i <= date('t'); $i++) {
            $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
        }

        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

        if (!$batch) {
            return redirect()->back()->withErrors('Batch not found.');
        }

        $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
            ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            ->where('za_training.status', 0)
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();

        $att = TrainingModel::where('za_training.batch_id', $batch->sno)
            ->where('za_training.status', 0)
            ->join('za_attendance', 'za_training.batch_id', '=', 'za_attendance.batch_id')
        // ->where('za_attendance.customer_id', '=', 'za_training.customer_id')
            ->select(
                'za_attendance.batch_id',
                'za_attendance.sno',
                'za_attendance.course_id',
                'za_attendance.staff_id',
                'za_attendance.customer_id',
                'za_attendance.attendance as att',
                'za_attendance.total_duration',
                'za_attendance.att_date'
            )
            ->groupBy(
                'za_attendance.batch_id',
                'za_attendance.sno',
                'za_attendance.course_id',
                'za_attendance.staff_id',
                'za_attendance.customer_id',
                'za_attendance.attendance',
                'za_attendance.total_duration',
                'za_attendance.att_date'
            )
            ->get();

        // return $att;

        $attWithDates = [];
        foreach ($dates as $date) {
            $attWithDates[$date] = [
                'date' => $date,
                'attendance' => [],
            ];
        }

        foreach ($att as $attendance) {
            $attendanceDate = $attendance->att_date;
            if (isset($attWithDates[$attendanceDate])) {
                $attWithDates[$attendanceDate]['attendance'][] = [
                    'att' => $attendance->att,
                    'total_duration' => $attendance->total_duration,
                    'customer_id' => $attendance->customer_id,
                ];
            }
        }

        foreach ($attWithDates as $date => $attendanceData) {
            if (empty($attendanceData['attendance'])) {
                $attWithDates[$date]['attendance'][] = [
                    'att' => 'NA',
                    'total_duration' => null,
                ];
            }
        }
        // return  array_values($attWithDates);

        return view('content.courses.view_batch_staff_attendance', [
            'view' => $lists,
            'dates' => $dates,
            'batch' => $batch,
            'att' => array_values($attWithDates),
        ]);
    }

    public function viewBatchSummary($id)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $dates = [];
        for ($i = 1; $i <= date('t'); $i++) {
            $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
        }

        // Find the course by decrypted ID
        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

        if (!$batch) {
            return redirect()->back()->withErrors('Batch not found.');
        }

        // Initialize arrays for chapters, sections, and topics
        $chapters = [];
        $sections = [];
        $topics = [];

        // Fetch unique chapters with their latest section based on maximum sno
        $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
            ->select('course_chapter_id', DB::raw('MAX(sno) as max_sno'))
            ->groupBy('course_chapter_id')
            ->get();

        foreach ($chapter_views as $chapter) {
            // Fetch the latest section for each chapter
            $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->where('course_chapter_id', $chapter->course_chapter_id)
                ->select('session_id', DB::raw('MAX(sno) as max_sno'))
                ->where('status', 0)
                ->groupBy('session_id')
                ->get();

            foreach ($latest_sections as $sec) {
                // Fetch the latest topics for each section
                $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                    ->where('course_chapter_id', $chapter->course_chapter_id)
                    ->where('session_id', $sec->session_id)
                    ->where('status', 0)
                    ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
                    ->groupBy('topic_id')
                    ->get();

                // Store topics under each section
                $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
            }
        }

        // return $groupedData;

        return view('content.courses.view_batch_course_summary', [
            'summary_list' => $topics,
            'batch' => $batch,
        ]);
        // return $lists;
    }
    
   // Bulk Attendence Vasanth
  public function batch_bulk_attendence($id)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $dates = [];
    for ($i = 1; $i <= date('t'); $i++) {
      $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
    }

    $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

    if (!$batch) {
      return redirect()->back()->withErrors('Batch not found.');
    }

    $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
    //   ->where('za_training.staff_id', $batch->staff_id)
      ->where('za_training.course_id', $batch->course_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();

    $att = TrainingModel::where('za_training.batch_id', $batch->sno)
      ->where('za_training.status', 0)
      ->join('za_attendance', 'za_training.batch_id', '=', 'za_attendance.batch_id')
      // ->where('za_attendance.customer_id', '=', 'za_training.customer_id')
      ->select(
        'za_attendance.batch_id',
        'za_attendance.sno',
        'za_attendance.course_id',
        'za_attendance.staff_id',
        'za_attendance.customer_id',
        'za_attendance.attendance as att',
        'za_attendance.total_duration',
        'za_attendance.att_date'
      )
      ->groupBy(
        'za_attendance.batch_id',
        'za_attendance.sno',
        'za_attendance.course_id',
        'za_attendance.staff_id',
        'za_attendance.customer_id',
        'za_attendance.attendance',
        'za_attendance.total_duration',
        'za_attendance.att_date'
      )
      ->get();

    // Parse the start and end dates
    $start_date = Carbon::parse($batch->start_date); // Start date
    $end_date = Carbon::parse($batch->end_date);     // End date

    $helper = new \App\Helpers\Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings->date_format ?? 'd-M-y';
    // Generate a date range
    $dates = [];
    for ($date = $start_date->copy(); $date->lte($end_date); $date->addDay()) {
      $dates[] = date($dateFormat, strtotime($date->toDateString()));
    }

    // return  $lists;

    return view('content.courses.batch_bulk_attendance', [
      'view' => $lists,
      'dates' => $dates,
      'batch' => $batch
    ]);
  }
  public function Bulk_atten_update(Request $request)
  {
    $attendence_data = $request->attendence;
    $batch_id = $request->batch_sno;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $batch = BatchModel::where('sno', $batch_id)->first();
    if (!$batch) {
      return response()->json(['status' => 'error', 'message' => 'Invalid batch ID'], 400);
    }

    $branch = BranchModel::find($branch_id);
    if (!$branch) {
      return response()->json(['status' => 'error', 'message' => 'Invalid branch ID'], 400);
    }
    $branch_code = $branch->city_short_code;

    $course_details = ManageCoursesModel::select(
      'za_course.*',
      'za_course_type.course_type_name',
      'za_course_subcategory.course_subcategory_name',
      'za_course_category.course_category_name',
      'za_course_type.course_days',
      'za_course_type.course_duration'
    )
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
      ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->where('za_course.sno', $batch->course_id)
      ->first();

    if (!$course_details) {
      return response()->json(['status' => 'error', 'message' => 'Course details not found'], 404);
    }

    $total_days = $course_details->course_days;
    $total_duration = $course_details->course_duration;

    foreach ($attendence_data as $date => $customers) {
      foreach ($customers as $customer_id => $attendance_status) {
        $attendance_status = $attendance_status[0]; // Extract "L" from the array

        // return $attendance_status;
        $last_attendance = AttendanceModel::orderBy('sno', 'desc')->first();
        $attendance_id = $this->generateAttendanceId($last_attendance, $branch_code);

        $reduced_duration = ($total_days > 0 && $attendance_status === 'P') ? $total_duration / $total_days : 0;

        $training = TrainingModel::where('batch_id', $batch->sno)->where('customer_id', $customer_id)->first();
        if (!$training) {
          return response()->json(['status' => 'error', 'message' => 'Training details not found for customer ID: ' . $customer_id], 404);
        }

        $per_hour_cost = $training->overall_fees / $total_duration;
        $total_cost = $per_hour_cost * $reduced_duration;

        $attendance_date = date('Y-m-d', strtotime($date));
        $attendance_record = AttendanceModel::where('batch_id', $batch->sno)
          ->where('att_date', $attendance_date)
          ->where('customer_id', $customer_id)
          ->first();

        if(isset($attendance_status)){
            if ($attendance_record) {
              // Update existing record
              $attendance_record->update([
                'attendance' => $attendance_status,
                'total_duration' => $reduced_duration,
                'per_hr_cost' => $per_hour_cost,
                'total_cost' => $total_cost,
                'branch_id' => $branch_id,
                'updated_by' => $user_id,
              ]);
            } else {
              // Insert new record
              $attendance_record =  AttendanceModel::create([
                'attendance_id' => $attendance_id,
                'att_date' => $attendance_date,
                'customer_id' => $customer_id,
                'course_id' => $batch->course_id,
                'batch_id' => $batch_id,
                'staff_id' => $batch->staff_id,
                'attendance' => $attendance_status,
                'total_duration' => $reduced_duration,
                'per_hr_cost' => $per_hour_cost,
                'total_cost' => $total_cost,
                'branch_id' => $branch_id,
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'status' => 1,
              ]);
            }
        }
      }
    }

    if ($attendance_record) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Attendance updated successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Batch!',
      ]);
    }

    return redirect()->back();
  }
  /*** Generate attendance ID***/
  private function generateAttendanceId($last_attendance, $branch_code)
  {
    $year = date('Y');
    if (!$last_attendance) {
      return $year . '/' . $branch_code . '/AT0001';
    }

    $last_id_parts = explode('/', $last_attendance->attendance_id);
    $last_number = preg_replace('/[^0-9]/', '', $last_id_parts[2]);
    $next_number = (int)$last_number + 1;

    return sprintf('%s/%s/AT%04d', $year, $branch_code, $next_number);
  }
  // Bulk Attendence Vasanth
  // Bulk Syllbus Vasanth
  public function batch_bulk_syllabus(Request $request)
  {
    $batch_id = $request->batch_sno_syll;
    $batch_update_date = date('Y-m-d', strtotime($request->batch_update_date));
    $batch_details = BatchModel::where('sno', $batch_id)->first();
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $branch = BranchModel::find($branch_id);
    if (!$branch) {
      return response()->json(['status' => 'error', 'message' => 'Invalid branch ID'], 400);
    }
    $branch_code = $branch->city_short_code;

    if ($batch_details) {
      $course_id = $batch_details->course_id;
      $staff_id = $batch_details->staff_id;
      $syllabus_details = ManageCoursesSyllabusModel::select('sno', 'course_id', 'course_chapter_id', 'session_id', 'topic_id', 'status')->where('course_id', $course_id)->where('status', 0)->get();

      foreach ($syllabus_details as $slist) {

        // return $attendance_status;
        $last_update_id = SyllabusUpdateModel::orderBy('sno', 'desc')->first();
        $syllabus_update_id = $this->generatesyllabuseId($last_update_id, $branch_code);

        $update_record = SyllabusUpdateModel::where('batch_id', $batch_details->sno)
          // ->where('date', $batch_update_date)
          ->where('course_id', $course_id)
          ->where('chapter_id', $slist->course_chapter_id)
          ->where('section_id', $slist->session_id)
          ->where('topic_id', $slist->topic_id)
          ->first();

        // return  $update_record;
        if ($update_record) {
          // Update existing record
          $update_record->update([
            'course_id' => $batch_details->course_id,
            'date' => $batch_update_date,
            'batch_id' => $batch_id,
            'staff_id' => $batch_details->staff_id,
            'chapter_id' => $slist->course_chapter_id,
            'section_id' => $slist->session_id,
            'topic_id' => $slist->topic_id,
            'branch_id' => $branch_id,
            'percentage' => 100,
            'updated_by' => $user_id,
          ]);
        } else {
          // Insert new record
          $update_record =  SyllabusUpdateModel::create([
            'syllabus_update_id' => $syllabus_update_id,
            'date' => $batch_update_date,
            'course_id' => $batch_details->course_id,
            'batch_id' => $batch_id,
            'staff_id' => $batch_details->staff_id,
            'chapter_id' => $slist->course_chapter_id,
            'section_id' => $slist->session_id,
            'topic_id' => $slist->topic_id,
            'branch_id' => $branch_id,
            'percentage' => 100,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status' => 0,
          ]);
        }
      }
    }

    if ($update_record) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Syllabus updated successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Syllabus Batch!',
      ]);
    }

    return redirect()->back();
  }
  /*** Generate attendance ID***/
  private function generatesyllabuseId($last_attendance, $branch_code)
  {
    $year = date('Y');
    if (!$last_attendance) {
      return $year . '/' . $branch_code . '/SU0001';
    }

    $last_id_parts = explode('/', $last_attendance->syllabus_update_id);
    $last_number = preg_replace('/[^0-9]/', '', $last_id_parts[2]);
    $next_number = (int)$last_number + 1;

    return sprintf('%s/%s/SU%04d', $year, $branch_code, $next_number);
  }
  // Bulk Syllbus Vasanth
  // Staff Swap Vasanth
  public function Batch_staff_swap($id = '', Request $request)
  {
    $branchId = $request->user()->branch_id;

    // Check if decryption failed
    if ($id === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course.course_version', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_batch.sno', $id)
      ->first();

    // Retrieve courses and their knowledge tags
    $courses = ManageCoursesModel::where('sno', $batch->course_id)
      ->where('status', 0)
      ->get(['sno', 'knowledge_tags']);

    // Decode JSON knowledge tags into a flat array
    $courseKnowledgeTags = $courses->pluck('knowledge_tags')
      ->filter() // Remove null or empty knowledge tags
      ->map(function ($tag) {
        return json_decode($tag, true); // Decode JSON
      })
      ->flatten() // Flatten nested arrays
      ->unique() // Ensure unique values
      ->values() // Reset array keys
      ->toArray();

    // Retrieve staff not assigned to the same slot
    $staff_dropdown = StaffModel::select(
      'za_staff.sno',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_department.department_name',
      'za_branch.branch_name',
      'za_branch.franchise_name',
      'za_shift_time.shift_sunday',
      'za_shift_time.shift_weekoff_day',
      'za_shift_time.shift_weekoff',
      'za_shift_time.shift_time_name'
    )
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
      ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.status', 0)
      ->where('za_staff.department_id',2)  
      ->where('za_staff.sno','!=',$batch->staff_id)  
    //   ->whereNotExists(function ($query) use ($batch) {
    //     $query->select(DB::raw(1))
    //       ->from('za_batch')
    //       ->whereRaw('za_batch.staff_id = za_staff.sno')
    //       ->where('za_batch.slot_id', $batch->slot_id); // Exclude staff in the same slot
    //   })
      ->where(function ($query) use ($courseKnowledgeTags) {
        foreach ($courseKnowledgeTags as $tag) {
          $query->orWhereRaw('JSON_CONTAINS(za_staff.knowledge_tag, ?)', [json_encode(['value' => $tag])]);
        }
      })
      ->get();




    // Check if the course is not found
    if (!$batch) {
      return redirect()->back()->with('error', 'Batch View not found');
    }

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $batch,
      'staff_dropdown' => $staff_dropdown,
    ], 200);
  }

  public function Batch_staff_swap_update(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'batch_id_sp' => 'required',
      'staff_id_sp' => 'required',
    ]);


    $batch_id = $request->batch_id_sp;
    $staff_id_swap = $request->staff_id_sp;
    $reason = $request->batch_sp_reason;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;



    $batch_details = BatchModel::where('sno', $batch_id)->first();
    if ($batch_details) {
      $current_staff_id =  $batch_details->staff_id;
      $swap_start_date =  $batch_details->start_date;
      $get_old_swap = Batch_staff_swap_Model::where('batch_id', $batch_id)->orderBy('sno', 'DESC')->first();
      if ($get_old_swap) {
        $swap_start_date =  $get_old_swap->swap_end_date;
      }

      $update_record =  Batch_staff_swap_Model::create([
        'branch_id' => $branch_id,
        'batch_id' => $batch_id,
        'staff_id_before' => $current_staff_id,
        'staff_id_after' => $staff_id_swap,
        'swap_start_date' => $swap_start_date,
        'swap_end_date' => date('Y-m-d'),
        'reason' => $reason,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'status' => 0,
      ]);
    }
    //
    // return $update_record;

    if ($update_record) {

      $batch_details->staff_id = $staff_id_swap;
      $batch_details->batch_staff = $staff_id_swap;
      $batch_details->updated_by = $user_id;
      $batch_details->updated_at =  date('Y-m-d H:i:s');
      $batch_details->save();

      $update_Training =  TrainingModel::where('batch_id', $batch_id)->update(['staff_id' => $staff_id_swap, 'updated_by' => $user_id, 'updated_at' => date('Y-m-d H:i:s')]);

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Batch Staff Swapped updated Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Batch Staff Swap !',
      ]);
    }

    return redirect()->back()->with('success', 'Batch updated successfully!');
  }

  public function batch_staff_history($id)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

    if (!$batch) {
      return redirect()->back()->withErrors('Batch not found.');
    }

    $history_list = Batch_staff_swap_Model::select('za_batch_staff_swap_history.*', 'before.staff_name as before_staff_name', 'after.staff_name as after_staff_name', 'before.staff_image as before_staff_image', 'after.staff_image as after_staff_image')
      ->where('za_batch_staff_swap_history.batch_id', $batch->sno)
      ->where('za_batch_staff_swap_history.status', 0)
      ->leftjoin('za_staff as before', 'before.sno', '=', 'za_batch_staff_swap_history.staff_id_before')
      ->leftjoin('za_staff as after', 'after.sno', '=', 'za_batch_staff_swap_history.staff_id_after')
      ->orderBy('za_batch_staff_swap_history.sno', 'DESC')
      ->get();

    // return $history_list;

    return view('content.courses.batch_staff_history', [
      'batch' => $batch,
      'history_list' => $history_list,
    ]);
  }

  // Staff Swap Vasanth

    public function Edit($id = '')
    {

        // Check if decryption failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Find the course by decrypted ID
        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course.course_version', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
             ->leftjoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $id)->first();

        // Check if the course is not found
        if (!$batch) {
            return redirect()->back()->with('error', 'Batch View not found');
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $batch,
        ], 200);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'batch_id' => 'required', // Ensure batch_id is present for update
            'batch_name' => 'required|max:255',
            'course_type_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $user_id = 1;
            $batch_id = $request->batch_id;

            $batch = BatchModel::where('sno', $batch_id)->first();
            if (!$batch) {
                return response([
                    'status' => 404,
                    'message' => 'Batch not found',
                    'data' => null,
                ], 404);
            }

            $batch->batch_name = ucfirst($request->batch_name);
            $batch->course_type_id = $request->course_type_id;
            $batch->course_id = $request->course_id;
            $batch->slot_id = $request->slot_id;
            $batch->start_date = date('Y-m-d', strtotime($request->start_date));
            $batch->end_date = date('Y-m-d', strtotime($request->end_date));
            $batch->classroom_id = $request->classroom_id;
            $batch->max_students = $request->max_students;
            $batch->course_summ = $request->course_summ_edit;
            $batch->staff_id = $request->staff_id;
            $batch->batch_desc = $request->batch_desc;
            $batch->updated_by = $user_id;

            $batch->save();

            // update free slot

            $shift_time_id = StaffModel::where('sno', $request->staff_id)->value('shift_time_id');

            $update_free_slot_change = FreeSlotModel::where('batch_id', $batch_id)->first();
            if ($update_free_slot_change) {
                $update_free_slot_change->slot_id = $request->slot_id;
                $update_free_slot_change->staff_id = $request->staff_id;
                $update_free_slot_change->shift_time_id = $shift_time_id;
                $update_free_slot_change->course_id = $request->course_id;
                $update_free_slot_change->batch_start_date = date('Y-m-d', strtotime($request->start_date));
                $update_free_slot_change->batch_end_date = date('Y-m-d', strtotime($request->end_date));
                $update_free_slot_change->updated_by = $user_id;
                $update_free_slot_change->update();
            }

            if ($batch) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Batch updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Batch!',
                ]);
            }

            return redirect()->back()->with('success', 'Batch updated successfully!');
        }
    }

    public function Status($id, Request $request)
    {

        $upd_ManageCoursesModel = BatchModel::where('sno', $id)->first();
        $upd_ManageCoursesModel->status = $request->input('status', 0);
        $upd_ManageCoursesModel->update();
        //update freeslot
        $freeSlot_upd = FreeSlotModel::where('batch_id', $id)->first();
        if ($freeSlot_upd) {
            $freeSlot_upd->status = $request->input('status', 0);
            $freeSlot_upd->Update();
        }
        if ($upd_ManageCoursesModel) {
            return response([
                'status' => 200,
                'message' => 'Batch Successfully Updated!',
                'error_msg' => 'Could not, update  Batch!',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'Could not update Batch!',
                'error_msg' => 'Could not, update  Batch!',
                'data' => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $BatchModel = BatchModel::where('sno', $id)->first();
        $BatchModel->status = 2;
        $BatchModel->Update();

        //update freeslot
        $freeSlot_upd = FreeSlotModel::where('batch_id', $id)->first();
        if ($freeSlot_upd) {
            $freeSlot_upd->status = 2;
            $freeSlot_upd->Update();
        }
        if ($BatchModel) {
            return response([
                'status' => 200,
                'message' => 'Batch  Successfully Deleted!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'Could not delete Batch !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }

    public function Complete($id, Request $request)
    {
        // Fetch the BatchModel and check if it exists
        $BatchModel = BatchModel::where('sno', $id)->first();
        if (!$BatchModel) {
            return response([
                'status' => 404,
                'message' => 'Batch not found!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $branch_id = $BatchModel->branch_id;
        $batch_id = $BatchModel->sno;
        $user_id = $request->user()->user_id;

        // Update batch status
        $BatchModel->status = 3;
        if (!$BatchModel->update()) {
            return response([
                'status' => 500,
                'message' => 'Could not update batch status!',
                'error_msg' => null,
                'data' => null,
            ], 500);
        }

        //update freeslot
        $freeSlot_upd = FreeSlotModel::where('batch_id', $batch_id)->first();
        if ($freeSlot_upd) {
            $freeSlot_upd->status = 3;
            $freeSlot_upd->Update();
        }

        // dd($BatchModel);

        // Fetch related customers
        $customers = CostingModel::where('batch_id', $batch_id)->get();
        if ($customers->isEmpty()) {
            return response([
                'status' => 404,
                'message' => 'No customers found for this batch!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }
        // dd($customers);

        $student_ids = [];
        foreach ($customers as $customer) {
            if ($customer->branch_id == $branch_id && $customer->batch_id == $batch_id) {
                $student_ids[] = $customer->sno;
            }
        }
        // return $student_ids;

        // Create new certificate record
        $add_certificate = new ManageCertificateModel();
        $add_certificate->branch_id = $branch_id;
        $add_certificate->batch_id = $batch_id;
        $add_certificate->batch_cmpltd_date = date('Y-m-d', strtotime($BatchModel->updated_at));
        $add_certificate->cert_status_id = 1;
        $add_certificate->student_id = json_encode($student_ids);
        $studentIdsArray = json_decode($add_certificate->student_id, true);
        if (is_array($studentIdsArray)) {
            $add_certificate->total_stud_count = count($studentIdsArray);
        } else {
            $add_certificate->total_stud_count = 0; // or handle it as needed
        }
        $add_certificate->created_by = $user_id;
        $add_certificate->updated_by = $user_id;

        if (!$add_certificate->save()) {
            return response([
                'status' => 500,
                'message' => 'Could not save certificate!',
                'error_msg' => null,
                'data' => null,
            ], 500);
        }

        return response([
            'status' => 200,
            'message' => 'Batch Successfully Completed!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    // public function filterStaff(Request $request)
    // {
    //     $slotId = $request->input('slot_id');
    //     $start_date = $request->input('start_date');

    //     // Ensure you have a valid slot ID
    //     if (!$slotId) {
    //         return response()->json(['status' => 400, 'message' => 'Slot ID is required']);
    //     }

    //     // Query to get staff allocated for the given slot ID
    //     $staffIds = BatchModel::where('slot_id', $slotId)->where('end_date','>', $start_date)->where('status', 0)
    //         ->pluck('staff_id')
    //         ->unique()
    //         ->values()
    //         ->toArray();

    //     // Get the staff data excluding the ones already allocated to the selected slot
    //     // $filteredStaff = StaffModel::whereNotIn('sno', $staffIds)->get();

    //     return response()->json(['status' => 200, 'data' => $staffIds]);
    // }
    public function filterStaff(Request $request) 
    {
        $slotId = $request->input('slot_id');
        $start_date_raw = $request->input('start_date');
    
        if (!$slotId) {
            return response()->json(['status' => 400, 'message' => 'Slot ID is required']);
        }
    
        // Convert start_date to DB compatible format (Y-m-d)
        try {
            $start_date = \Carbon\Carbon::createFromFormat('j-M-Y', $start_date_raw)->format('Y-m-d');
        } catch (\Exception $e) {
            return response()->json(['status' => 400, 'message' => 'Invalid start date format']);
        }
    
        // Fetch staff_ids where end_date is less than the provided start_date
        $staffIds = BatchModel::where('slot_id', $slotId)
            ->whereDate('end_date', '>=', $start_date) // ensure end_date is less than input
            ->where('status', 0)
            // ->where('end_date','>',date('Y-m-d'))
            ->pluck('staff_id')
            ->unique()
            ->values()
            ->toArray();
    
        return response()->json(['status' => 200, 'data' => $staffIds]);
    }

    public function getCourselist(Request $request)
    {
        $courseTypeId = $request->input('course_id');

        // Fetch courses based on course_type_id
        $courses = ManageCoursesModel::where('status', 0)->where('sno', $courseTypeId)->get();

        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }
    public function getSlotlist(Request $request)
    {
        $courseTypeId = $request->input('slot_id');

        // Fetch courses based on course_type_id
        $courses = SlotModel::where('status', 0)->where('sno', $courseTypeId)->get();

        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }
    public function filterStaffEdit(Request $request)
    {
        $slotId = $request->input('slot_id');
        $batchId = $request->input('batch_id');

        // Ensure you have a valid slot ID
        if (!$slotId) {
            return response()->json(['status' => 400, 'message' => 'Slot ID is required']);
        }

        // Get the staff ID for the given batch ID
        $staff_id = BatchModel::where('sno', $batchId)->value('staff_id');

        if ($staff_id === null) {
            return response()->json(['status' => 404, 'message' => 'Batch ID not found']);
        }

        // Get staff IDs allocated to the given slot ID excluding the staff ID from the given batch ID
        $staffIds = BatchModel::where('slot_id', $slotId)
            ->where('staff_id', '!=', $staff_id)
            ->pluck('staff_id')
            ->unique()
            ->values()
            ->toArray();

        // Get the staff data excluding the ones already allocated to the selected slot
        $filteredStaff = BatchModel::whereNotIn('staff_id', $staffIds)->get();

        return response()->json(['status' => 200, 'data' => $filteredStaff]);
    }
    public function staffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $staff = StaffModel::where('status', '!=', 2)
            ->whereIn('department_id', [2,8]);
        if ($branch_id != 0) {
            $staff->where('branch_id', $branch_id);
        }
        $staff = $staff->orderBy('staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }
    // Rajkumar
    public function BatchExtension(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'batch_id_extension' => 'required', // Ensure batch_id is present for update
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $batch_id = $request->batch_id_extension;
            $reason = $request->batch_reason_extension;
            $end_date    = date('Y-m-d', strtotime($request->batch_end_date_old_hidden));
            $change_date = date('Y-m-d', strtotime($request->end_date_extension));
            $user_id =  $request->user()->user_id;

            $add_category = new BatchExtensionModel();
            $add_category->batch_id = $batch_id;
            $add_category->end_date = $end_date;
            $add_category->change_date = $change_date;
            $add_category->branch_id = $branch_id;
            $add_category->reason = $reason;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;

            $add_category->save();
            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Batch updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Batch!',
                ]);
            }

            return redirect()->back()->with('success', 'Batch updated successfully!');
        }
    }
    public function ExtendBatchEdit($id = '')
    {
        // return $id;

        // Check if decryption failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        // Find the course by decrypted ID
        $extend_batch = BatchExtensionModel::select(
            'za_batch_extension.*',
           'za_batch_extension.change_date as change_datessss', 
            'za_batch.batch_name',
            'za_batch.max_students',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.slot_name',
            'za_course.course_name',
            'za_course_type.course_type_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_staff.staff_name',
            'za_class_room.class_room_name',
            'za_batch_extension.sno as batch_extend_sno'
        )
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        
            // ->leftJoin('za_batch_extension', 'za_batch_extension.batch_id', '=', 'za_batch.sno')
            ->where('za_batch_extension.status', '!=', 2)
            ->where('za_batch_extension.sno', $id)
            ->first();


        // dd($extend_batch);

        // Check if the course is not found
        if (!$extend_batch) {
            return redirect()->back()->with('error', 'Batch View not found');
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $extend_batch,
        ], 200);
    }


    public function ExtendBatchApprove(Request $request)
    {
        // dd($request);
        $id = $request->extend_sno;
        $batch_sno = $request->batch_id_approve;
        $status = 1;
        // return $status;
        $end_date = $request->batch_change_date_approve_hidden;
        // dd($end_date);
        $BatchModel = BatchExtensionModel::where('sno', $id)->first();
        $BatchModel->status = $status;
        $BatchModel->Update();

        // return $BatchModel;
        //update Batch
        $batch_upd = BatchModel::where('sno', $batch_sno)->first();
        if ($batch_upd) {
            $batch_upd->end_date = date('Y-m-d', strtotime($end_date));
            $batch_upd->Update();
        }
        // return $batch_upd;

        // return  $training_upd;
        if ($batch_upd) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Batch updated Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Batch!',
            ]);
        }

        return redirect()->back()->with('success', 'Batch updated successfully!');
    }
    
    // public function batchAttendance(Request $request)
    // {
    //     $branch_id = $request->user()->branch_id;
    //     $batch_name = $request->batch_name_att;
    //     $batch_id = $request->batch_id_att;
    //     $batch_sno = $request->batch_sno_att;
    //     $attendance = $request->attendance;
    //     $att_date = date('Y-m-d', strtotime($request->att_date)); 
    //     $user_id = $request->user()->user_id;
    //     $upd_batch = BatchModel::where('sno', $batch_sno)->first();
    
    //     if (!$upd_batch) {
    //         return response()->json([
    //             'type' => 'error',
    //             'message' => 'Batch not found!',
    //         ]);
    //     }
    
    //     $attendance_status = $upd_batch->attendance_status ? json_decode($upd_batch->attendance_status, true) : [];
    
    //     $existing_attendance = collect($attendance_status)->firstWhere('date', $att_date);
    
    //     if ($existing_attendance) {
    //         return response()->json([
    //             'type' => 'error',
    //             'message' => 'Attendance is already marked for ' . $att_date . '!',
    //         ]);
    //     }

    //     $attendance_status[] = [
    //         'date' => $att_date,
    //         'attendance' => $attendance, 
    //     ];
        
    //     $upd_batch->attendance_status = json_encode($attendance_status);  
    
    //     $category_check = BatchHistoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        
    //     if (!$category_check) {
    //         $year = substr(date('y'), -2);
    //         $batch_his_id = 'BTH-0001/' . $year;
    //     } else {
    //         $data = $category_check->batch_his_id;
    //         $slice = explode('/', $data);
    //         $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
    //         $next_number = (int) $result + 1;
    //         $new_batch_his_id = sprintf('BTH-%04d', $next_number);
    
    //         $year = substr(date('y'), -2);
    //         $batch_his_id = $new_batch_his_id . '/' . $year;
    //     }
    
    //     $add_category = new BatchHistoryModel();
    //     $add_category->batch_id = $batch_sno;
    //     $add_category->batch_name = ucfirst($batch_name);
    //     $add_category->att_date = $att_date;
    //     $add_category->attendance = $attendance;
    //     $add_category->batch_his_id = $batch_his_id; 
    //     $add_category->created_by = $user_id;
    //     $add_category->updated_by = $user_id;
    
    //     $add_category->save();
    
    //     if ($add_category) {
    //         session()->flash('toastr', [
    //             'type' => 'success',
    //             'message' => 'Batch Attendance updated successfully!',
    //         ]);
    //     } else {
    //         session()->flash('toastr', [
    //             'type' => 'error',
    //             'message' => 'Could not update attendance!',
    //         ]);
    //     }

    //     $upd_batch->save();
    
    //     return redirect()->back()->with('success', 'Batch Attendance updated successfully!');
    // }
    public function batchAttendance(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $batch_name = $request->batch_name_att;
        $batch_id = $request->batch_id_att;
        $batch_sno = $request->batch_sno_att;
        $attendance = $request->attendance;
        $att_date = date('Y-m-d', strtotime($request->att_date));
        $user_id = $request->user()->user_id;
        $upd_batch = BatchModel::where('sno', $batch_sno)->first();
    
        if (!$upd_batch) {
            return response()->json([
                'type' => 'error',
                'message' => 'Batch not found!',
            ]);
        }
    
        $attendance_status = $upd_batch->attendance_status ? json_decode($upd_batch->attendance_status, true) : [];
    
        // Check if attendance is already marked for the given date
        $existing_attendance = collect($attendance_status)->firstWhere('date', $att_date);
    
        if ($existing_attendance) {
            // Update the existing attendance for this date
            foreach ($attendance_status as &$attendance_record) {
                if ($attendance_record['date'] === $att_date) {
                    $attendance_record['attendance'] = $attendance;  // Update the attendance for the date
                    break;
                }
            }
            $upd_batch->attendance_status = json_encode($attendance_status);
            $message = 'Attendance for ' . $att_date . ' has been updated!';
            $upd_batch->save();
    
            // Now, update the attendance history record if it exists
            $existing_history = BatchHistoryModel::where('batch_id', $batch_sno)
                ->where('att_date', $att_date)
                ->first();
    
            if ($existing_history) {
                // If record exists, update attendance
                $existing_history->attendance = $attendance;
                $existing_history->updated_by = $user_id;
                $existing_history->save();  // Update the existing entry
            } else {
                // No need to create a new history entry if it doesn't exist
                // Just update the batch record and return the success message
                $message = 'Attendance for ' . $att_date . ' has been updated!';
            }
        } else {
            // If no existing attendance for that date, add a new record in attendance status
            $attendance_status[] = [
                'date' => $att_date,
                'attendance' => $attendance,
            ];
            $upd_batch->attendance_status = json_encode($attendance_status);
            $message = 'Attendance for ' . $att_date . ' has been saved!';
            $upd_batch->save();
    
            // Create a new history record if it doesn't exist
            $category_check = BatchHistoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    
            if (!$category_check) {
                $year = substr(date('y'), -2);
                $batch_his_id = 'BTH-0001/' . $year;
            } else {
                $data = $category_check->batch_his_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
                $next_number = (int) $result + 1;
                $new_batch_his_id = sprintf('BTH-%04d', $next_number);
    
                $year = substr(date('y'), -2);
                $batch_his_id = $new_batch_his_id . '/' . $year;
            }
    
            $add_category = new BatchHistoryModel();
            $add_category->batch_id = $batch_sno;
            $add_category->branch_id = $branch_id;
            $add_category->batch_name = ucfirst($batch_name);
            $add_category->att_date = $att_date;
            $add_category->attendance = $attendance;
            $add_category->batch_his_id = $batch_his_id;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
    
            $add_category->save();
        }
    
        session()->flash('toastr', [
            'type' => 'success',
            'message' => $message,
        ]);
    
        return redirect()->back()->with('success', $message);
    }
    
    public function unpaidList($id = '', Request $request) 
    {
        // Get the branch ID from the authenticated user
        $branchId = $request->user()->branch_id;
        
        // Check if the decryption of the ID failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $batchQuery = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.status', '!=', 2)
            ->where('za_batch.branch_id', $branchId)
            ->where('za_batch.sno', $id)->first();

        $helper = new \App\Helpers\Helpers();
        $batchQuery->completed_days = $helper->batch_completed_days($batchQuery->sno);
        
        $totalStudents = TrainingModel::where('za_training.batch_id', $batchQuery->sno)
        ->where('za_training.staff_id', $batchQuery->staff_id)
        ->where('za_training.course_id', $batchQuery->course_id)
        ->where('za_training.status', 0)
        ->distinct('za_training.customer_id') // Ensure unique customers
        ->count('za_training.customer_id'); 

        // return $batchQuery;
        $fee_unpaid_count = 0;
        $allOutstandingPayments = [];  
        $customer_data = TrainingModel::where('batch_id', $id)->get();
        
        foreach ($customer_data as $customer) {
            $outstandingPayments = PaymentModel::where('za_payment.branch_id', $branchId)
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                ->select(
                    'za_payment.payment_id',
                    'za_payment.sno as payment_sno',
                    'za_payment.branch_id',
                    'za_customer.customer_id',
                    'za_customer.sno as customer_sno',
                    'za_payment.initialPayDate',
                    'za_payment.nextPayDate',
                    'za_payment.amount',
                    'za_payment.paidAmount',
                    'za_payment.gst_amount',
                    'za_payment.balanceFee',
                    'za_payment.total_amount',
                    'za_payment.payment_mode_label',
                    'za_payment.status as payment_status',
                    'za_customer.cus_name',
                    'za_customer.cus_pic',
                    'za_customer.cus_mobile',
                    'za_customer.cus_email_id',
                    'za_course.course_name',
                    'za_course.sno as course_sno',
                    'za_course.course_id'
                )
                ->where('za_payment.customer_id', $customer->customer_id)
                ->where('za_payment.status', 0)
                ->where('za_customer.status', 0) 
                ->whereDate('za_payment.nextPayDate', '<=', now()) 
                ->get();
        
            if ($outstandingPayments->isNotEmpty()) {
                $fee_unpaid_count++;
        
                foreach ($outstandingPayments as $payment) {
                    $allOutstandingPayments[] = $payment; 
                }
            }
        }        

      // If no unpaid customers found
        if ($fee_unpaid_count === 0) {
            return response([
                'status' => 404,
                'message' => 'No unpaid customers found.',
                'error_msg' => null,
                'data' => [],
            ], 200);
        }
    
        // Return the list of unpaid customers with the remaining amount for each customer
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,    
            'batch' => $batchQuery,
            'stud' => $totalStudents,
            'fee_unpaid_count' => $fee_unpaid_count,
            'allOutstandingPayments' => $allOutstandingPayments
        ], 200);
    }
    
    public function DropBatch(Request $request)
    {
        // return $request;
        $batch_id = $request->batch_id_drop;
        $user_id = auth()->user()->user_id;
        // return $batch_id;

        $batch = BatchModel::select('*')->where('sno', $batch_id)->where('status', '!=', 2)->first();

        // return $batch;

        if($batch){
            $batch->status = 4;
            $batch->updated_by = $user_id;
            $batch->updated_at = date('Y-m-d');
            // return $batch;
            $batch->update();
        } else{
            return response()->json([
                'type' => 'error',
                'message' => 'Batch not found!',
            ]);
        }

        return redirect()->back()->with('success', 'Batch Dropped successfully!');
    }
    
     public function BatchSlotChange($id = '', Request $request)
    {
      $branch_id = $request->user()->branch_id;
  
      // Check if decryption failed
      if ($id === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }
  
      // Find the course by decrypted ID
      $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course.course_version', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name','za_slot.slot_type_id')
        ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        ->where('za_batch.status', '!=', 2)
        ->where('za_batch.sno', $id)
        ->first();

        $slot_ids = BatchModel::where('staff_id', $batch->staff_id)
        ->where('status', 0)
        ->where('sno','!=', $id)
        ->select('sno','slot_id','staff_id')
        ->where('end_date','>',date('Y-m-d'))
        ->orderBy('slot_id', 'asc')
        // ->get();
        ->pluck('slot_id')
        ->unique()
        ->values()
        ->toArray();

        // return $slot_ids;
  
        $slotList = SlotModel::select('za_slot.*', 'za_slot_type.slot_type_name', 'za_slot_type.sno as slot_type_id')
        ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->where('za_slot_type.status', 0)
        ->where('za_slot.status', 0)
        ->whereNotIn('za_slot.sno', $slot_ids)
        ->where('za_slot.slot_type_id',$batch->slot_type_id)
        ->orderBy('sno', 'asc');
        if ($branch_id != 0) {
          $slotList->where('za_slot.branch_id', $branch_id);
        }
        $slotList= $slotList->get();
  
      $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
      foreach ($slotList as $slotType) {
        $dayIndices = json_decode($slotType->slot_type_days);
        $dayNames = [];
  
        foreach ($dayIndices as $index) {
          $dayIndex = (int)$index - 1;
          $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
        }
  
        $slotType->dayNames = implode(', ', $dayNames);
      }
  
  
  
  
      // Check if the course is not found
      if (!$batch) {
        return redirect()->back()->with('error', 'Batch View not found');
      }
  
      return response([
        'status' => 200,
        'message' => null,
        'error_msg' => null,
        'data' => $batch,
        'slotList' => $slotList,
      ], 200);
    }
  
    public function BatchSlotChangeUpdate(Request $request)
    {
      $validator = Validator::make($request->all(), [
        'slot_id_slt' => 'required',
        'batch_id_slt' => 'required',
      ]);
  
  
      $batch_id = $request->batch_id_slt;
      $slot_id = $request->slot_id_slt;
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
  
  
  
      $batch_details = BatchModel::where('sno', $batch_id)->first();
      
      if ($batch_details) {
        $batch_details->slot_id = $slot_id;
        $batch_details->updated_by = $user_id;
        $batch_details->updated_at =  date('Y-m-d H:i:s');
        $batch_details->update();
        $update_Training =  TrainingModel::where('batch_id', $batch_id)->update(['slot_id' => $slot_id, 'updated_by' => $user_id, 'updated_at' => date('Y-m-d H:i:s')]);
        $update_freeSlot =  FreeSlotModel::where('batch_id', $batch_id)->update(['slot_id' => $slot_id, 'updated_by' => $user_id, 'updated_at' => date('Y-m-d H:i:s')]);
  
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Batch Slot Changed Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Batch Slot !',
        ]);
      }
  
      return redirect()->back()->with('success', 'Batch updated successfully!');
    }
    
    
  public function DeleteBatchPermanently($id)
  {
    $upd_Model =  BatchModel::where('sno', $id)->first();
    $upd_Model->Delete();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
    
}
