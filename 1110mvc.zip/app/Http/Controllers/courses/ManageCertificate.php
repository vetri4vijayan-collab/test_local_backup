<?php


namespace App\Http\Controllers\courses;

use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\CertificateAuthorityModel;
use App\Models\CertificateChecklistModel;
use App\Models\DistributeCertificateModel;
use App\Models\ManageCertificateModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\BatchChecklistModel;
use App\Models\RequestCertificateModel;
use App\Models\CourierModel;
use App\Models\Student;
use App\Models\ExamModel;
use App\Models\ExamProcessModel;
use App\Models\CustomerModel;
use App\Models\SlotModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\User;
use function Laravel\Prompts\select;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use PDF;


class ManageCertificate extends Controller
{


  public function index(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $cus_fill = $request->cus_fill ?? '';
  
      // Retrieve manage certificate details
      $manage_certificate = ManageCertificateModel::select(
          'za_manage_certificate.*',
          'za_slot.slot_name',
          'za_batch.batch_name',
          'za_batch.status as batch_status',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_batch.max_students',
          'za_course.course_name',
          'za_course.course_version',
          'za_course_type.course_type_name',
          'za_course_type.course_days',
          'za_class_room.class_room_name',
          'za_slot_type.slot_type_name',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_slot.slot_type_days',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.staff_image',
          'za_staff.nick_name',
          'za_certificate_status.certificate_status_name',
          'za_certificate_status.bg_color as cert_status_bg',
          'za_certificate_status.text_color as cert_status_text',
          'za_certificate_authority_status.certificate_authority_status_name',
          'za_certificate_authority_status.bg_color as authority_status_bg',
          'za_certificate_authority_status.text_color as authority_status_text'
      )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2) // Assuming this is correct
      ->where('za_manage_certificate.branch_id', '=', $branch_id)
      ->orderBy('za_manage_certificate.sno', 'desc');
      
      if ($cus_fill) {
        $manage_certificate->where(function ($customer) use ($cus_fill) {
          $customer->where('za_batch.batch_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_slot.slot_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_course.course_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_class_room.class_room_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_slot_type.slot_type_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere( 'za_course_type.course_type_name', 'LIKE', "%{$cus_fill}%");
        });
      }
      
      $manage_certificate= $manage_certificate->paginate($perpage);
      
      $pageConfigs = ['myLayout' => 'default'];

      $cert_status = DistributeCertificateModel::where('status', 0)->get();
      // return $cert_status;

      $checklist_batch = BatchChecklistModel::select('*')->where('status', '=', 0)->get();

      return view('content.courses.manage_certificate.list', [
          'manage_certificate' => $manage_certificate,
          'checklist_batch' => $checklist_batch,
          'pageConfigs' => $pageConfigs,
        'perpage' => $perpage,
        'cus_fill' => $cus_fill,
      ]);
  }
  

  public function List()
  {
    $cert_list = ManageCertificateModel::where('status', 0)->where('cert_status_id >=', 4)->where('cert_status_id >=', 1)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $cert_list
    ], 200);

    // dd($cert_list);
  }


  // public function RequestStatus($id, Request $request)
  // {
  //     $updt_ManageCertificateModel = ManageCertificateModel::where('sno', $id)->first();
      
  //     if (!$updt_ManageCertificateModel) {
  //         return response([
  //             'status' => 404,
  //             'message' => 'Certificate Request Not Found!',
  //             'error_msg' => 'Could not update Certificate Request Status!',
  //             'data' => null,
  //         ], 404);
  //     }
  

  //     // $updt_ManageCertificateModel->cert_status_id = $request->input('cert_status_id', 2);
  //     $updt_ManageCertificateModel->save(); // Use save() instead of update() for consistency
  
  //     return response([
  //         'status' => 200,
  //         'message' => 'Certificate Request Status Successfully Updated!',
  //         'error_msg' => '',
  //         'data' => null,
  //     ], 200);
  // }
  

  public function View($id = '', Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the Certificate  by decrypted ID
    $certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.created_at as batch_created',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text',
      'created_by_staff.staff_name as created_by_staff_name' // New staff name for created_by
      )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_staff as created_by_staff', 'created_by_staff.sno', '=', 'za_manage_certificate.updated_by') // New join for the creator's staff
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', $branch_id)->where('za_manage_certificate.sno', $decryptedValue)->first();

      $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->distinct('za_training.customer_id')  // Ensure unique customers
      ->count('za_training.customer_id');  
    
      // dd($totalStudents);
      $checklistView = CertificateChecklistModel::where('status', 0)->get();

      $lists = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();

      $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$certificate->batch_id)->where('status', 0)->first();
   
        // return $eligibleList;
    // return $checklistView;
      if (!$certificate) {
      return redirect()->back()->with('error', 'Certificate View not found');
    }

    return view('content.courses.manage_certificate.view', [
      'view' => $certificate,
      'stud_view' => $totalStudents,
      'checklist' => $checklistView,
      'stud_list' => $lists,
      'checked' => $eligibleList
    ]);
  }

  public function CertificateRequest($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;

    $certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_batch.checklist',
      'za_batch.created_at as batch_created',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text',
      'za_certificate_checklist.certificate_checklist_name',
      'za_certificate_checklist.certificate_checklist_desc',
    )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_checklist', 'za_certificate_checklist.sno', '=', 'za_manage_certificate.certificate_checklist_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', $branch_id)->where('za_manage_certificate.sno', $id)->first();

    // return $certificate;
    // Check if the course is not found
    if (!$certificate) {
      return redirect()->back()->with('error', 'Certificate Request not found');
    }

    $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
    ->count('za_training.customer_id'); 
    
    $lists = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();

    // dd($totalStudents);

    // dd($certificate);
    $checklist = CertificateChecklistModel::where('status', 0)->get();

    $stud_att = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
    ->where('za_training.status', 0)
    ->select('customer_id')
    ->get();

    $allAttendance = [];

    foreach ($stud_att as $list) {
        $attendance = AttendanceModel::where('attendance', '=', 'P')
            ->where('customer_id', $list->customer_id)
            // ->whereBetween('att_date', [$certificate->start_date, $certificate->end_date])
            ->get();

        // Merge the current attendance into the allAttendance array
        $allAttendance = array_merge($allAttendance, $attendance->toArray());
    }
    //   return $lists;

    
    return response([
              'status' => 200,
              'message' => 'Certificate Request Status Successfully Updated!',
              'error_msg' => '',
              'data' => $certificate,
              'total_stud_count' => $totalStudents,
              'checklist' => $checklist,
              'stud_list' =>$lists
          ], 200);  
   
  }

//   public function tableGet(Request $request)
//   {
//       $batch_id = $request->batch_id;
//       $branch_id = $request->user()->branch_id;
  
//       // Fetch student list
//       $lists = TrainingModel::where('za_training.batch_id', $batch_id)
//           ->where('za_training.status', 0)
//           ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
//           ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
//           ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
//           ->get();

//       // return $batch_id;
  
//       // Fetch checklist
//       $checklist = CertificateChecklistModel::where('status', 0)->get();

//       $request_cert = RequestCertificateModel::where('batch_id', $batch_id)->first();
//       return $request_cert;
  
//       // Fetch student attendance
//       $stud_att = TrainingModel::where('za_training.batch_id', $batch_id)
//           ->where('za_training.status', 0)
//           ->select('customer_id', 'course_id')
//           ->get();
  
//           $allAttendance = []; // Initialize the array to hold all attendance records
//           $paymentCustomerIds = [];
//           $courseSyllabus = [];
          
//           foreach ($stud_att as $list) {
//               // Get attendance records
//               $attendance = AttendanceModel::where('attendance', 'P')
//                   ->where('customer_id', $list->customer_id)
//                   // ->whereBetween('att_date', [$certificate->start_date, $certificate->end_date])
//                   ->get();
          
//               $allAttendance = array_merge($allAttendance, $attendance->toArray());
          
//               $payment = TrainingModel::where('batch_id', $batch_id)
//                   ->where('customer_id', $list->customer_id)
//                   // ->where('total_amount', '=', 'paid_amount')
//                   ->get();
          
//               foreach ($payment as $pay) {
//                   $paymentCustomerIds[] = $pay->customer_id;
//               }

//               $course = ManageCoursesSyllabusModel::where('course_id', $list->course_id )->count('topic_id');
//             // return $course;
//               $syllabus = SyllabusUpdateModel::where('batch_id', $batch_id)->where('course_id', $list->course_id)->count('topic_id');
            
//           }
//         $attendanceMap = [];
//         foreach ($allAttendance as $attendance) {
//             $attendanceMap[$attendance['customer_id']] = true; 
//         }
       
//         // Start building the table
//         $tableHeader = '<thead>
//                             <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
//                                 <th class="min-w-200px">Students</th>';

//         foreach ($checklist as $list) {
//             $tableHeader .= '<th class="min-w-50px text-center">
//                                 <label>' . htmlspecialchars($list->certificate_checklist_name) . '</label>
//                                 <div class="fs-7 d-block text-center">(' . htmlspecialchars($list->certificate_checklist_desc) . ')</div>
//                                 <div class="d-block checkbox-container">
//                                     <input class="form-check-input fs-6 eligible check_all" type="checkbox" id="select_all_' . $list->sno . '" onclick="toggleAllCheckboxes(\'column_' . $list->sno . '\')" />
//                                 </div>
//                             </th>';
//         }

//         $tableHeader .= '<th class="min-w-50px text-center">
//                             <label>Certificate Eligible</label>
//                             <div class="d-block checkbox-container">
//                                 <input class="form-check-input fs-6" id="eligible_all" name="eligible_all" type="checkbox" onclick="toggleAllEligibleCheckboxes()" />
//                             </div>
//                         </th>
//                         <th class="min-w-150px"><label>Reason</label></th>
//                     </tr>
//                 </thead>';


//             $tableBody = '<tbody>';

//             foreach ($lists as $s_list) {
                
//                 $tableBody .= '<tr>
//                                     <td>
//                                         <input type="hidden" name="eligible_stud_id[]" value="' . $s_list->sno . '">
//                                         <div class="d-flex align-items-center justify-center">
//                                             <div class="symbol symbol-35px me-2">
//                                                 <div class="avatar">
//                                                     <img src="' . ($s_list->cus_pic ? asset('staff_images/' . $s_list->cus_pic) : asset('assets/eapl_images/user_1.png')) . '" alt="user image" class="w-px-40 h-auto rounded-circle">
//                                                 </div>
//                                             </div>
//                                             <div class="ms-2 d-block">
//                                                 <label class="d-flex align-items-center">
//                                                     <span class="fs-7 fw-semibold text-truncate max-w-80px me-2">' . htmlspecialchars($s_list->cus_name) . '</span>
//                                                     <span><i class="mdi mdi-face-woman text-danger"></i></span>
//                                                 </label>
//                                                 <span class="fs-8">' . htmlspecialchars($s_list->customer_id) . '</span>
//                                             </div>
//                                         </div>
//                                     </td>';

//                 // Now loop through the checklist
//                 foreach ($checklist as $list) {
//                     // Determine if the checkbox should be checked
//                     $checked = ($list->sno == 4 && isset($attendanceMap[$s_list->sno])) ? 'checked' : '';
//                     $checkedPay = ($list->sno == 5 && in_array($s_list->sno, $paymentCustomerIds)) ? 'checked' : '';
//                     $checkedCourse = ($list->sno == 3 && $course == $syllabus) ? 'checked' : '';

//                     $checkedAttr = $checked . ' ' . $checkedPay . ' ' . $checkedCourse;

//                     $tableBody .= '<td class="text-center">
//                                     <label class="checkbox-container">
//                                         <input class="form-check-input fs-6 eligible ms-3 row_chk' . $list->sno . '" name="checklist[' . $list->sno . ']" type="checkbox" value="1" onchange="updateSelectAllCheckbox(\'column_' . $list->sno . '\'); toggleCheckboxBg(this)" ' . $checkedAttr . ' />
//                                     </label>
//                                 </td>';
//                 }

//                 $tableBody .= '<td class="text-center">
//                         <label class="checkbox-container">
//                             <input class="form-check-input fs-6 ms-3 eligible" 
//                                 id="chk_all_'.$s_list->sno.'" 
//                                 name="chk_all_'.$s_list->sno.'" 
//                                 type="checkbox" 
//                                 value="1" 
//                                 onclick="selectEligibleCheck('.$list->sno.')" />
//                         </label>
//                     </td>
//                     <td>
//                         <label>
//                             <textarea class="form-control" name="reason[]" rows="1" placeholder="Enter Reason"></textarea>
//                         </label>
//                     </td>
//                 </tr>';
//             }

//             $tableBody .= '</tbody>';

//         // Combine header and body
//         $tableHtml = $tableHeader . $tableBody;

//         // return $tableHtml;
          
//       // Return the HTML table as JSON response
//       return response()->json(['data' => $tableHtml]);
//   }

    public function tableGet(Request $request)
    {
        $batch_id = $request->batch_id;
        $branch_id = $request->user()->branch_id;

        // Fetch student list
        $lists = TrainingModel::where('za_training.batch_id', $batch_id)
            ->where('za_training.status', 0)
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
            ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();

        // Fetch checklist
        $checklist = CertificateChecklistModel::where('status', 0)->get();

        // Fetch existing request certificate data
        $requested_cert = RequestCertificateModel::where('batch_id', $batch_id)->first();
        // return $requested_cert;

        if ($requested_cert) {
            // If data exists, return it directly as needed
            return response()->json([
                'data' => $this->generateTableHtml($batch_id, $lists, $checklist, $requested_cert)
            ]);
        }

        // Otherwise, build the usual table
        return response()->json([
            'data' => $this->generateTableHtml($batch_id, $lists, $checklist)
        ]);
    }

    private function generateTableHtml($batch_id, $lists, $checklist, $requested_cert = null)
    {
        // Fetch student attendance
        $stud_att = TrainingModel::where('za_training.batch_id', $batch_id)
            ->where('za_training.status', 0)
            ->select('customer_id', 'course_id')
            ->get();
    
        $allAttendance = []; // Initialize the array to hold all attendance records
        $paymentCustomerIds = [];
        $courseSyllabus = [];
        // return $requested_cert;

        $requestedCertData = [];
        if ($requested_cert) {
            $requestedCertData = json_decode($requested_cert->student_id, true);
        }
        $eligibleIds = [];
        
        if (is_array($requestedCertData)) {
            foreach ($requestedCertData as $item) {
                // Check if the item is eligible
                if (isset($item['eligible']) && $item['eligible'] == 1) {
                    $eligibleIds[] = $item['Id'];
                }
            }
        } else {
            $eligibleIds = [];
        }
        
        // Return the eligible IDs
        // return $eligibleIds;
    
        foreach ($stud_att as $list) {
            // Get attendance records
            $attendance = AttendanceModel::where('attendance', 'P')
                ->where('customer_id', $list->customer_id)
                ->get();
    
            $allAttendance = array_merge($allAttendance, $attendance->toArray());
    
            $payment = TrainingModel::select('balance_amount', 'customer_id')->where('batch_id', $batch_id)
                ->where('customer_id', $list->customer_id)
                ->get();
    
            foreach ($payment as $pay) {
                if ($pay->balance_amount == 0) {
                    $paymentCustomerIds[] = $pay->customer_id;
                }
            }
    
            $course = ManageCoursesSyllabusModel::where('course_id', $list->course_id)->count('topic_id');
            $syllabus = SyllabusUpdateModel::where('batch_id', $batch_id)
                ->where('course_id', $list->course_id)
                ->count('topic_id');
    
            if ($syllabus > 0) {
                $courseSyllabus[$list->customer_id] = true;
            }
        }
    
        $attendanceMap = [];
        foreach ($allAttendance as $attendance) {
            $attendanceMap[$attendance['customer_id']] = true; 
        }
    
        $paymentMap = [];
        foreach ($paymentCustomerIds as $customerId) {
            $paymentMap[$customerId] = true;
        }
    
        // Start building the table
        $tableHeader = '<thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-200px">Students</th>';
    
        foreach ($checklist as $list) {
            $tableHeader .= '<th class="min-w-50px text-center">
                                <label>' . htmlspecialchars($list->certificate_checklist_name) . '</label>
                                <div class="fs-7 d-block text-center">(' . htmlspecialchars($list->certificate_checklist_desc) . ')</div>
                                <div class="d-block checkbox-container">
                                    <input class="form-check-input fs-6 eligible check_all" type="checkbox" id="select_all_' . $list->sno . '" onclick="toggleAllCheckboxes(\'column_' . $list->sno . '\')" />
                                </div>
                            </th>';
        }
    
        $tableHeader .= '<th class="min-w-50px text-center">
                            <label>Certificate Eligible</label>
                            <div class="d-block checkbox-container">
                                <input class="form-check-input fs-6" id="eligible_all" name="eligible_all" type="checkbox" onclick="toggleAllEligibleCheckboxes()" />
                            </div>
                        </th>
                        <th class="min-w-150px"><label>Reason</label></th>
                    </tr>
                </thead>';
    
        $tableBody = '<tbody>';
    
        foreach ($lists as $s_list) {
            $tableBody .= '<tr>
                                <td>
                                    <input type="hidden" name="eligible_stud_id[]" value="' . $s_list->sno . '">
                                    <div class="d-flex align-items-center justify-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="avatar">
                                                <img src="' . ($s_list->cus_pic ? asset('staff_images/' . $s_list->cus_pic) : asset('assets/eapl_images/user_1.png')) . '" alt="user image" class="w-px-40 h-auto rounded-circle">
                                            </div>
                                        </div>
                                        <div class="ms-2 d-block">
                                            <label class="d-flex align-items-center">
                                                <span class="fs-7 fw-semibold text-truncate max-w-80px me-2">' . htmlspecialchars($s_list->cus_name) . '</span>
                                                <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                            </label>
                                            <span class="fs-8">' . htmlspecialchars($s_list->customer_id) . '</span>
                                        </div>
                                    </div>
                                </td>';

            if (in_array($s_list->sno, $eligibleIds)) {
                $tableBody .= '<input type="hidden" name="eligible_ids[]" value="' . $s_list->sno . '">';
            }
        
            // Loop through the checklist and prefill checkboxes based on the student's eligibility
            foreach ($checklist as $list) {
                $checked = ($list->sno == 4 && isset($attendanceMap[$s_list->sno])) ? 'checked' : '';
                $checkedPay = ($list->sno == 5 && in_array($s_list->sno, $paymentCustomerIds)) ? 'checked' : '';
                $checkedCourse = ($list->sno == 3 && $course == $syllabus) ? 'checked' : '';

                $checkedAttr = $checked . ' ' . $checkedPay . ' ' . $checkedCourse;
                $checkedAll = '';
                // Check if the student is eligible based on the decoded data
                $disabled = in_array($s_list->sno, $eligibleIds) ? 'disabled' : '';
                $checkedAll .= in_array($s_list->sno, $eligibleIds) ? ' checked' : '';
        
                $tableBody .= '<td class="text-center">
                                <label class="checkbox-container">
                                    <input class="form-check-input fs-6 eligible ms-3 row_chk' . $list->sno . '" 
                                           name="checklist[' . $list->sno . ']" 
                                           type="checkbox" 
                                           value="1" 
                                           onchange="updateSelectAllCheckbox(\'column_' . $list->sno . '\'); toggleCheckboxBg(this)" 
                                           ' . $checkedAll . ' ' . $disabled . ''. $checkedAttr .' />
                                </label>
                            </td>';
            }
        
            // Set the Certificate Eligible checkbox based on attendance, payment, and syllabus
            $tableBody .= '<td class="text-center">
                    <label class="checkbox-container">
                        <input class="form-check-input fs-6 ms-3 eligible" 
                            id="chk_all_'.$s_list->sno.'" 
                            name="chk_all_'.$s_list->sno.'" 
                            type="checkbox" 
                            value="1" 
                            onclick="selectEligibleCheck('.$s_list->sno.')" ' . ($checkedAttr ? 'checked' : '') . ' ' . $disabled . ' />
                    </label>
                </td>
                <td>
                    <label>
                        <textarea class="form-control" name="reason[]" rows="1" placeholder="Enter Reason"></textarea>
                    </label>
                </td>
            </tr>';
        }
        
        $tableBody .= '</tbody>';
    
        // Combine header and body
        return $tableHeader . $tableBody;
    }


    public function AddRequest(Request $request)
    {
        // Return the request for debugging
        // return $request;
    
        $branch_id = $request->user()->branch_id;
        $checklistData = $request->input('checklist', []);
        $reason = $request->input('reason', []);
        $cleanedReasons = array_filter($reason, function ($reason) {
            return !is_null($reason);
        });
        if (empty($cleanedReasons)) {
            $cleanedReasons = null; // Or you can use an empty array []
        }
        
        $batch_id = $request->input('batch_id_req_table');
        $eligibleStudIds = $request->input('eligible_stud_id', []); // List of student IDs
        $eligibleId = $request->input('eligible_ids', []); // This should contain ["12", "34"]
    
        // Initialize an array to store the eligible students' data
        $studentEligible = [];
    
        // Loop through the eligible students' IDs
        foreach ($eligibleStudIds as $index => $studentId) {
            $chkAllKey = 'chk_all_' . $studentId; // The key for each student in the form, e.g., chk_all_46
        
            // Get the value of the checkbox for the current student
            $eligibleAll = $request->input($chkAllKey); 
        
            // Check if the current student has a corresponding 'chk_all_*' value of 1
            if ($eligibleAll == '1') {
                // Only add the student to the eligible array if chk_all_* is set to 1
                $studentEligible[] = [
                    'Id' => $studentId,
                    'eligible' => 1
                ];
            }
        }
        
        
        // Add the IDs 12 and 34 to the eligible array if they are not already included
        foreach ($eligibleId as $id) {
            if (!in_array($id, array_column($studentEligible, 'Id'))) {
                $studentEligible[] = [
                    'Id' => $id,
                    'eligible' => 1 // Assuming you want to mark them as eligible
                ];
            }
        }
        // return $studentEligible;
    
        // Format checklist data
        $formattedChecklistData = [];
        foreach ($checklistData as $sno => $value) {
            $formattedChecklistData[] = [
                'sno' => $sno,
                'value' => $value
            ];
        }
    
        // Check if the batch_id already exists in the RequestCertificateModel
        $certificateRequest = RequestCertificateModel::where('batch_id', $batch_id)->first();
    
        if(!$certificateRequest) {
            // Create a new certificate request if it doesn't exist
            $certificateRequest = new RequestCertificateModel();
            $certificateRequest->branch_id = $branch_id;
            $certificateRequest->batch_id = $batch_id;
            $certificateRequest->student_id = json_encode($studentEligible); // Only those with chk_all == 1
            $certificateRequest->certificate_checklist_id = json_encode($formattedChecklistData);
            $certificateRequest->eligibility = !empty($studentEligible) ? 1 : 0; // Update eligibility based on studentEligible
            $certificateRequest->reason = !empty($cleanedReasons) && count($cleanedReasons) > 0 ? json_encode($cleanedReasons) : null;
            $certificateRequest->created_at = now();
            $certificateRequest->created_by = $request->user()->user_id;
            $certificateRequest->updated_at = now();
            $certificateRequest->updated_by = $request->user()->user_id;
            $certificateRequest->status = 0;
            $certificateRequest->save();
        } else {
            // Update the existing certificate request if it exists
            $certificateRequest->student_id = json_encode($studentEligible); // Only those with chk_all == 1
            $certificateRequest->certificate_checklist_id = json_encode($formattedChecklistData);
            $certificateRequest->eligibility = !empty($studentEligible) ? 1 : 0; // Update eligibility based on studentEligible
            $certificateRequest->reason = !empty($cleanedReasons) && count($cleanedReasons) > 0 ? json_encode($cleanedReasons) : null;
            $certificateRequest->updated_at = now();
            $certificateRequest->updated_by = $request->user()->user_id;
            // return $certificateRequest;
            $certificateRequest->save(); // Using save instead of update to ensure the model is saved
        }
    
        // Additional logic for updating certificate status if needed
        if ($certificateRequest) {
            $manageCertificate = ManageCertificateModel::where('batch_id', $certificateRequest->batch_id)->first();
            if ($manageCertificate) {
                $manageCertificate->cert_status_id = 2;
                $manageCertificate->certificate_authority_status_id = 0;
                $manageCertificate->req_cert_date = $certificateRequest->updated_at;
                $eligibleCount = count($studentEligible); // Count the number of eligible students
                $manageCertificate->req_stud_count = $eligibleCount;
                $manageCertificate->save();
            }
        }
    
        return redirect()->route('production-manage-certificate');
    }

  
  public function DistributionChecklist($id, Request $request)
  {
    // return $id;

    $branch_id = $request->user()->branch_id;
    $certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_batch.checklist',
      'za_batch.created_at as batch_created',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text',
      'za_certificate_checklist.certificate_checklist_name',
      'za_certificate_checklist.certificate_checklist_desc',
    )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_checklist', 'za_certificate_checklist.sno', '=', 'za_manage_certificate.certificate_checklist_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', $branch_id)->where('za_manage_certificate.sno', $id)->first();

    //   return $certificate;
      $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->count('za_training.customer_id'); 

      $requestedStudents = $certificate->req_stud_count;
      $confirmedStudents = $certificate->confirm_stud_count;

      $arrayOfStudentIds = CertificateAuthorityModel::select('za_certificate_authority.approve_stud')->where('status', 0)->get();

      $stud_cert_dist = DistributeCertificateModel::select('student_status')->where('batch_id', $certificate->batch_id)->where('status', 0)->first();
    // return $stud_cert_dist;

        $courier_list = CourierModel::select('*')->where('status', '!=', 2)->get();
        // return $courier_list;

      $lists = CertificateAuthorityModel::where('za_certificate_authority.batch_id', $certificate->batch_id)
      ->where('za_certificate_authority.status', 0)
      ->join('za_training', 'za_certificate_authority.batch_id', '=', 'za_training.batch_id')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->select(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_certificate_authority.approve_stud',
          'za_training.customer_id as training_customer_id'
      )
      ->whereIn('za_certificate_authority.approve_stud', $arrayOfStudentIds) 
      ->distinct('za_training.customer_id')
      ->get();

    $filteredLists = $lists->filter(function ($item) {
        $studentIds = json_decode($item->approve_stud, true);
        
        return in_array($item->training_customer_id, $studentIds);
    });

    return response([
      'status' => 200,
      'message' => 'Certificate Request Status Successfully Updated!',
      'error_msg' => '',
      'data' => $certificate,
      'total_stud_count' => $totalStudents,
      'req_stud_count' => $requestedStudents,
      'confirmed_count' => $confirmedStudents,
      'stud_list' =>$filteredLists,
      'stud_cert_dist' => $stud_cert_dist,
      'courier_list' => $courier_list
    ], 200);
  }

  public function Distribute(Request $request)
  {
    // return $request;
      $batch_id = $request->input('batch_id_iss_cert');
      $branch_id = $request->user()->branch_id;
      $eligibleStudIds = $request->input('eligible_stud_id', []);
  
      $studentData = [];
  
      foreach ($eligibleStudIds as $studentId) {
          $status = $request->input('status' . $studentId, []);
          $courier_name = $request->input('courier_name' . $studentId, '');
          $courier_id = $request->input('courier_id' . $studentId, '');
          $courier_add = $request->input('courier_add' . $studentId, '');
  
          $studentData[$studentId] = [
              'eligible_stud_id' => $studentId,
              'status' => !empty($status) ? $status[0] : '',
              'courier_id' => $courier_id,
              'courier_add' => $courier_add,
              'courier_name' => $courier_name
          ];
      }

    //   return $request;
  
      // Try to get the certificate request from the database
      $certificateRequest = DistributeCertificateModel::where('batch_id', $batch_id)->first();
  
      // If no certificate request is found, create a new one
      if (!$certificateRequest) {
          $certificateRequest = new DistributeCertificateModel();
          $certificateRequest->branch_id = $branch_id;
          $certificateRequest->batch_id = $batch_id;
          $certificateRequest->created_at = now();
          $certificateRequest->created_by = $request->user()->user_id;
          $certificateRequest->updated_at = now();
          $certificateRequest->updated_by = $request->user()->user_id;
        //   return $certificateRequest;
          $certificateRequest->status = 0;
      }
  
      // Update student status data
      $certificateRequest->student_status = json_encode($studentData);

        // return $certificateRequest;
      $certificateRequest->save(); // Save the updated or new record
  
      // Process the students' status and update their records
      $pendingCount = 0;
      $collectedCount = 0;
  
      foreach ($studentData as $student) {
          if ($student['status'] === 'collected' || $student['status'] === 'couriered') {
              $collectedCount++;
          } else {
              $pendingCount++;
          }
      }
  
      foreach ($studentData as $student) {
        if ($student['status'] === 'collected' || $student['status'] === 'couriered') {
            // Update TrainingModel for current batch_id
            $cert_issue = TrainingModel::where('customer_id', $student['eligible_stud_id'])
                ->where('branch_id', $branch_id)
                ->where('batch_id', $batch_id)
                ->first();
    
            if ($cert_issue) {
                $cert_issue->certificate_status = 1;
                $cert_issue->update();
            }
            
            // Now check if the customer has certificate_status = 1 for all batches
            $all_certificates_collected = TrainingModel::where('customer_id', $student['eligible_stud_id'])
                ->where('branch_id', $branch_id) // Optional, remove if you want to check across all branches
                ->get();
    
            // Check if all certificates for the customer are collected (certificate_status = 1)
            $allCollected = $all_certificates_collected->every(function ($cert) {
                return $cert->certificate_status === 1;
            });
    
            // If all batches have certificate_status = 1, update the status in CustomerModel
            if ($allCollected) {
                $customer = CustomerModel::where('customer_id', $student['eligible_stud_id'])
                    ->where('branch_id', $branch_id) // Optional, remove if you want to check across all branches
                    ->first();
    
                if ($customer) {
                    $customer->status = 4;
                    $customer->completed_date = date('Y-m-d');
                    $customer->update();
                }
            }
        }
    }    
  
      // Update Certificate Authority and Manage Certificate based on the counts
      $cert_auth = CertificateAuthorityModel::where('batch_id', $batch_id)->first();
      $manage_cert_schedule = ManageCertificateModel::where('batch_id', $batch_id)->first();
  
      if ($cert_auth) {
          $cert_auth->pending_stud_count = $pendingCount;
          $cert_auth->distr_stud_count = $collectedCount;
          $cert_auth->cert_status_id = 4;
          $cert_auth->cert_sent_date = date('Y-m-d');
          if ($pendingCount === 0) {
              $cert_auth->cert_status_id = 5;
              $cert_auth->distr_stud_count = $collectedCount;
              $cert_auth->pending_stud_count = 0;
              $cert_auth->cert_sent_date = date('Y-m-d');
          }
          $cert_auth->update();
      }
  
      if ($manage_cert_schedule) {
          $manage_cert_schedule->pending_stud_count = $pendingCount;
          $manage_cert_schedule->distr_stud_count = $collectedCount;
          $manage_cert_schedule->cert_status_id = 4;
          $manage_cert_schedule->cert_sent_date = date('Y-m-d');
          if ($pendingCount === 0) {
              $manage_cert_schedule->distr_stud_count = $collectedCount;
              $manage_cert_schedule->cert_status_id = 5;
              $manage_cert_schedule->pending_stud_count = 0;
              $manage_cert_schedule->cert_sent_date = date('Y-m-d');
          }
          $manage_cert_schedule->update();
      }
  
      return redirect()->route('production-manage-certificate');
  }
  

//   public function PrintCertiifcate($id, Request $request)
//   {
    
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
//     // return $decryptedValue;

//     list($batch_id, $cus_id) = explode('~', $decryptedValue);
//     // return $cus_id;

//     $customerDetails = TrainingModel::select('za_training.*','za_customer.*', 'za_branch.branch_name', 'za_branch.franchise_name','za_branch.branch_head_name','za_branch.branch_head_sign','za_branch.cert_auth_name','za_branch.cert_auth_sign', 'za_course.course_name', 'za_course.sno as course_sno', 'za_batch.start_date', 'za_batch.end_date', 'za_batch.sno as batch_sno')
//         ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
//         ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
//         ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
//         ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
//         ->where('za_training.customer_id', $cus_id)
//         ->where('za_training.batch_id', $batch_id)
//         ->where('za_customer.status', 0)
//         ->first();

//     $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$batch_id)->where('status', 0)->first();
//     //  return $eligibleList;

//     $scoreList = json_decode($eligibleList->student_id);
//     // return $scoreList;
//     // Initialize score and grade variables
//     $score = 0;
//     $grade = '';

//     // Find the matching student by Id
//     foreach ($scoreList as $student) {
//         if ($student->Id == $cus_id) {
//             // If a match is found, assign score and grade
//             $score = $student->score;
//             $grade = $student->grade;
//             break; // Exit the loop once the student is found
//         }
//     }

//     // Store the score and grade in the customer details object
//     if ($customerDetails) {
//         $customerDetails->score = $score;
//         $customerDetails->grade = $grade;
//     }

//     // return $customerDetails;

    
//     return view('content.courses.manage_certificate.course_completed_certificate', [
//         'customerDetails' => $customerDetails
//     ]);
//   }
  
//   public function cusScoreDetails($id, Request $request)
//   {
//       $cus_id = $id;
//       $batch_id = $request->input('batch_id');

//       $branch_id = $request->user()->branch_id;

//       $customerDetails = TrainingModel::select('za_training.branch_id','za_training.batch_id', 'za_training.course_id', 'za_staff.gender',
//         'za_training.staff_id','za_staff.staff_name','za_staff.mobile_no','za_staff.staff_image', 
//         'za_staff.nick_name', 'za_customer.sno as cus_sno',
//         'za_training.customer_id','za_customer.cus_name', 'za_course.course_type_id',
//         'za_customer.customer_id', 'za_course.course_name','za_course_type.course_type_name',
//         'za_batch.start_date', 'za_batch.end_date', 'za_batch.batch_name')
//       ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
//       ->leftJoin('za_staff', 'za_training.staff_id', '=', 'za_staff.sno')
//       ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
//       ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
//       ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->where('za_training.customer_id', $cus_id)
//       ->where('za_training.batch_id', $batch_id)
//       ->where('za_customer.status', 0)
//       ->first();

      
//         // return $eligibleList;
    
//         $attendance = AttendanceModel::select('*')
//         ->whereBetween('att_date', [$customerDetails->start_date, $customerDetails->end_date])
//         ->where('batch_id', $batch_id)
//         ->where('customer_id', $cus_id)
//         ->get();

//         $startDate = Carbon::parse($customerDetails->start_date);
//         $endDate = Carbon::parse($customerDetails->end_date);
//         $totalDays = $startDate->diffInDays($endDate) + 1; // +1 to include the start date
//         // return $totalDays;

//         $presentDays = $attendance->where('attendance', 'P')->count();

//         $attendancePercentage = ($totalDays > 0) ? ($presentDays / $totalDays) * 100 : 0;

//         $attendancePercentage = round($attendancePercentage);
//         // return $attendancePercentage;

//         $course = ManageCoursesSyllabusModel::where('course_id', $customerDetails->course_id)->count('topic_id');

//         // Step 2: Get the number of topics covered in the batch
//         $syllabus = SyllabusUpdateModel::where('batch_id', $batch_id)
//             ->where('course_id', $customerDetails->course_id)
//             ->count('topic_id');
        
//         // Step 3: Calculate the percentage
//         $percentage = 0;
        
//         if ($course > 0) {
//             if ($course == $syllabus) {
//                 $percentage = 100; // If both counts are the same, it's 100%
//             } else {
//                 $percentage = ($syllabus / $course) * 100; // Calculate percentage
//             }
//         }

//         $percentage = round($percentage);

//         // return $percentage;

//         $payment = TrainingModel::select('*')
//         ->where('batch_id', $batch_id)
//         ->where('customer_id', $cus_id)
//         ->get();
    
//         // Step 2: Initialize payment percentage
//         $paymentPercentage = 0;
        
//         foreach ($payment as $p) {
//             // Step 3: Check if balance_amount is 0 (fully paid)
//             if ($p->balance_amount == 0) {
//                 $paymentPercentage = 100; // Fully paid
//             } else {
//                 // Step 4: Calculate payment percentage based on paid_amount and total_amount
//                 $paymentPercentage = ($p->paid_amount / $p->total_amount) * 100;
//             }
//         }
//         $paymentPercentage = round($paymentPercentage); 

//         // return $paymentPercentage;

//         $exam_person = Student::select(
//                     'students.id',
//                     'students.exam_status',
//                     'students.branch_id',
//                     'students.user_name',
//                     'students.email_id',
//                     'students.phone_no',
//                     'students.type',
//                     'students.place_name',
//                     'za_staff.staff_name',
//                     'za_staff.nick_name',
//                     'za_staff.staff_image',
//                     'students.staff_id'
//                 )
//                 ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
//                 ->where('students.status', 0)
//                 ->where('students.id', $cus_id)
//                 ->first();

//         // Process exam_status JSON
//         if ($exam_person) {
//         $exams = json_decode($exam_person->exam_status, true);
//         }else{
//             $exams = [];
//         }
//         $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();

//         // Calculate the number of exams
//         if ($exam_person) {
//             $total_exams = is_array($exams) ? count($exams) : 0;
//             $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
//             $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;
        
//             // Add the counts to $exam_person
//             $exam_person->total_exam = sprintf('%02d', $total_exams);
//             $exam_person->completed_exam = sprintf('%02d', $completed_exams);
//             $exam_person->balance_exam = sprintf('%02d', $balance_exams);
//         } 
//             // $total_exams = is_array($exams) ? count($exams) : 0;
//             // $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
//             // $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;
        
//             // Add the counts to $exam_person
//             // $exam_person->total_exam = sprintf('%02d', $total_exams);
//             // $exam_person->completed_exam = sprintf('%02d', $completed_exams);
//             // $exam_person->balance_exam = sprintf('%02d', $balance_exams);
//         if($exam_person){
//             // Fetch exam list related to this student
//             $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
//             $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();
        
//             // Merge both lists while keeping all records from ExamModel
//             $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
//                 // Get the corresponding process entry for this exam
//                 $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
//                 return [
//                     'exam_id' => $exam->sno,
//                     'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
//                     'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
//                     'certificate' => $exam->certificate ?? null, // Adjust field names as needed
//                     'device_type' => $exam_process->device_type ?? 2,
//                     'student_marks' => $exam_process->student_marks ?? null,
//                     'updated_at' => $exam_process->updated_at ?? null,
//                     'exam_status' => $exam_process->status ?? 1,
//                     'student_id' => $exam_process->student_id ?? null,
//                 ];
//             });
        

//             // Calculate total marks and student marks for exams that are completed (exam_status == 2)
//             $total_marks = 0;
//             $total_student_marks = 0;
//             if($exam_list){
//                 foreach ($exam_list as $exam) {
//                     if ($exam['exam_status'] == 2) {  // Only include exams that are completed
//                         $total_marks += $exam['total_marks'];
//                         $total_student_marks += $exam['student_marks'] ?? 0;
//                     }
//                 }
//             }
        
//             // Calculate the percentage
//             $examPercentage = 0;
//             if ($total_marks > 0) {
//                 $examPercentage = ($total_student_marks / $total_marks) * 100;
//                 $examPercentage = round($examPercentage);
//             }
//         } else{
//             $examPercentage = 0;
//         }
        
//         // Prepare the result
//         // $response = [
//         //     'exam_person' => $exam_person,
//         //     'exam_list' => $exam_list,  // Exam list with all details
//         //     'total_marks' => $total_marks,
//         //     'total_student_marks' => $total_student_marks,
//         //     'balance_exam' => $balance_exams,
//         //     'examPercentage' => $examPercentage,
//         // ];

//         // return $percentage;
    
//         // Fetch the checklist items
//         $checklist = CertificateChecklistModel::where('status', 0)->get();
    
//         // Map the percentage values to the corresponding checklist
//         $checklistWithPercentages = $checklist->map(function ($item) use ($attendancePercentage, $percentage, $paymentPercentage, $examPercentage) {
//             switch ($item->sno) {
//                 case 4:
//                     $item->percentage = $attendancePercentage;
//                     break;
//                 case 3:
//                     $item->percentage = $percentage;
//                     break;
//                 case 5:
//                     $item->percentage = $paymentPercentage;
//                     break;
//                 case 1:
//                     $item->percentage = 100;
//                     break;
//                 default:
//                     $item->percentage = 0;
//                     break;
//             }
//             return $item;
//         });

//         //  return $checklistWithPercentages;

//         // $checked = ($list->sno == 4 && isset($attendanceMap[$s_list->sno])) ? 'checked' : '';
//         // $checkedPay = ($list->sno == 5 && in_array($s_list->sno, $paymentCustomerIds)) ? 'checked' : '';
//         // $checkedCourse = ($list->sno == 3 && $course == $syllabus) ? 'checked' : '';

//       // You can process the data here and return a response
//       return response()->json([
//           'message' => 'Data received successfully',
//           'cus_id' => $cus_id,
//           'batch_id' => $batch_id,
//           'cus_details' => $customerDetails,
//           'attendance_percentage' => $attendancePercentage,
//           'syllabus_percentage' => $percentage,
//           'payment_percentage' => $paymentPercentage,
//           'exam_Percentage' => $examPercentage,
//           'checklistPercentage' => $checklistWithPercentages,
//       ]);
//   }
   
    
//     public function AddScore(Request $request)
//     {
//         // return $request;

//         $certificateRequest = RequestCertificateModel::where('batch_id', $request->batch_id_score)->first();
//         $studentEligible = json_decode($certificateRequest->student_id, true); // Assumes this is an array

//         $additionalData = [
//             'score' => $request->customer_score, // Assuming you get score in the request
//             'grade' => $request->grade_hidden,   // Assuming you get grade in the request
//         ];
    
//         // Loop through the students and only update the relevant one
//         foreach ($studentEligible as &$student) {
//             // Check if the student ID matches the one you want to update
//             if ($student['Id'] == $request->cus_sno_score) {
//                 // Merge the score and grade with the specific student
//                 $student = array_merge($student, $additionalData);
//                 break; // Exit the loop once the correct student is found and updated
//             }
//         }
//         // return $studentEligible;
//         $studentEligibleJson = json_encode($studentEligible);
    
//         if (!$certificateRequest) {
//             // Create a new certificate request if it doesn't exist
//             $certificateRequest = new RequestCertificateModel();
//             $certificateRequest->branch_id = $request->branch_id;
//             $certificateRequest->batch_id = $request->batch_id_score;
//             $certificateRequest->student_id = $studentEligibleJson; // Store the updated student data
//             $certificateRequest->created_at = now();
//             $certificateRequest->created_by = $request->user()->user_id;
//             $certificateRequest->updated_at = now();
//             $certificateRequest->updated_by = $request->user()->user_id;
//             $certificateRequest->status = 0;
           
//             $certificateRequest->save();
//         } else {
//             // Update the existing certificate request if it exists
//             $certificateRequest->student_id = $studentEligibleJson; // Store the updated student da
//             $certificateRequest->updated_at = now();
//             $certificateRequest->updated_by = $request->user()->user_id;
//             // return $certificateRequest;
    
//             $certificateRequest->save(); // Using save instead of update to ensure the model is saved
//         }
    
//         // Flash success or failure message
//         if ($certificateRequest) {
//             session()->flash('toastr', [
//                 'type' => 'success',
//                 'message' => 'Score Added Successfully!',
//             ]);
//         } else {
//             session()->flash('toastr', [
//                 'type' => 'error',
//                 'message' => 'Could not add the score!',
//             ]);
//         }
    
//         return redirect()->back()->with('success', 'Score Added successfully!');
//     }

//     // public function generatePDF()
//     // {
//     //     $data = ['title' => 'Welcome to Laravel PDF'];
//     //     $pdf = PDF::loadView('pdf.document', $data);
//     //     return $pdf->download('document.pdf');
//     // }

    
//     // public function generateCertificatePdf($id, Request $request)
//     // {
//     //     $helper = new \App\Helpers\Helpers();
//     //     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
//     //     list($batch_id, $cus_id) = explode('~', $decryptedValue);
    
//     //     // Fetch Customer & Training Details
//     //     $customerDetails = TrainingModel::select(
//     //         'za_training.*', 'za_customer.*', 
//     //         'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_head_name',
//     //         'za_branch.branch_head_sign', 'za_branch.cert_auth_name', 'za_branch.cert_auth_sign', 
//     //         'za_course.course_name', 'za_batch.start_date', 'za_batch.end_date'
//     //     )
//     //     ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
//     //     ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
//     //     ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
//     //     ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
//     //     ->where('za_training.customer_id', $cus_id)
//     //     ->where('za_training.batch_id', $batch_id)
//     //     ->where('za_customer.status', 0)
//     //     ->first();
    
//     //     // Fetch Eligible Students for Certificate
//     //     $eligibleList = RequestCertificateModel::where('batch_id', $batch_id)->where('status', 0)->first();
    
//     //     if (!$eligibleList) {
//     //         return back()->with('error', 'No certificate request found for this batch.');
//     //     }
    
//     //     // ✅ Decode as associative array to avoid stdClass error
//     //     $scoreList = json_decode($eligibleList->student_id, true);  
    
//     //     $score = 0;
//     //     $grade = '';
    
//     //     foreach ($scoreList as $student) {
//     //         if (isset($student['Id']) && $student['Id'] == $cus_id) {  
//     //             $score = $student['score'] ?? 0;  // Prevent undefined index error
//     //             $grade = $student['grade'] ?? ''; 
//     //             break;
//     //         }
//     //     }
    
//     //     if ($customerDetails) {
//     //         $customerDetails->score = $score;
//     //         $customerDetails->grade = $grade;
//     //     }
    
//     //     // Generate PDF
//     //     $pdf = PDF::loadView('content.courses.manage_certificate.course_completed_certificate', [
//     //         'customerDetails' => $customerDetails
//     //     ]);
    
//     //     // Save PDF to storage
//     //     $fileName = 'certificate_' . $cus_id . '.pdf';
//     //     $filePath = storage_path('app/public/certificates/' . $fileName);
//     //     $pdf->save($filePath);
    
//     //     // Update Certificate Request
//     //     $certificateRequest = RequestCertificateModel::where('batch_id', $batch_id)->first();
    
//     //     if ($certificateRequest) {
//     //         $studentEligible = json_decode($certificateRequest->student_id, true);
            
//     //         foreach ($studentEligible as &$student) {
//     //             if (isset($student['Id']) && $student['Id'] == $cus_id) {
//     //                 $student['certificate_pdf'] = $fileName;
//     //             }
//     //         }
    
//     //         $certificateRequest->student_id = json_encode($studentEligible);
//     //         $certificateRequest->updated_at = now();
//     //         $certificateRequest->updated_by = $request->user()->user_id;
//     //         $certificateRequest->save();
//     //     }
    
//     //     session()->flash('toastr', [
//     //         'type' => 'success',
//     //         'message' => 'Certificate Generated Successfully!',
//     //     ]);
    
//     //     return $pdf->download($fileName);
//     // }
    
//     //Vasanth
//     public function QrCertiifcate($id, Request $request)
//     {
        
//         // return $id;
//         $helper = new \App\Helpers\Helpers();
//         $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
//         // return $decryptedValue;
    
//         if (!$decryptedValue || strpos($decryptedValue, '~') === false) {
//             abort(404, 'Invalid decrypted value');
//         }
    
//         list($batch_id, $cus_id ) = explode('~', $decryptedValue);
//         // return $cus_id;
    
//         $customerDetails = TrainingModel::select(
//                 'za_training.*', 'za_customer.*', 'za_customer.sno AS cus_sno', 'za_customer.customer_id AS cus_id',
//                 'za_branch.branch_name', 'za_branch.franchise_name', 
//                 'za_branch.branch_head_name', 'za_branch.branch_head_sign', 
//                 'za_branch.cert_auth_name', 'za_branch.cert_auth_sign', 
//                 'za_course.course_name', 'za_course.course_days', 
//                 'za_batch.slot_id', 'za_batch.start_date', 'za_batch.end_date'
//             )
//             ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
//             ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
//             ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
//             ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
//             ->where('za_training.customer_id', $cus_id)
//             ->where('za_training.batch_id', $batch_id)
//             ->where('za_customer.status', 0)
//             ->first();
        
//         if (!$customerDetails) {
//             abort(404, 'Customer details not found.');
//         }
        
//         // Convert start_date and end_date to Carbon objects
//         $batchStartDate = Carbon::parse($customerDetails->start_date);
//         $batchEndDate   = Carbon::parse($customerDetails->end_date);
//         $currentDate    = $batchStartDate->copy();
        
//         // Get the slot type details
//         $slot = SlotModel::find($customerDetails->slot_id);
//         $slotDays = json_decode($slot->slot_type_days, true) ?? []; // Ensure it's an array
        
//         $totalWorkingDays = 0;
//         while ($currentDate->lte($batchEndDate)) {
//             if (in_array($currentDate->dayOfWeek, $slotDays)) {
//                 $totalWorkingDays++;
//             }
//             $currentDate->addDay();
//         }
        
//         // Generate date list for the batch period
//         $dates = [];
//         $tempDate = $batchStartDate->copy();
//         while ($tempDate->lte($batchEndDate)) {
//             $dates[] = $tempDate->toDateString();
//             $tempDate->addDay();
//         }
        
//         // Fetch attendance data for the customer in this batch
//         $attendanceRecords = AttendanceModel::where('customer_id', $customerDetails->cus_sno)
//             ->where('batch_id', $batch_id)
//             ->get()
//             ->groupBy('att_date');
        
//         // Initialize attendance data
//         $attendanceData = [];
//         foreach ($dates as $date) {
//             $attendanceData[$date] = optional(optional($attendanceRecords->get($date))->first())->attendance ?? '0';
//         }
        
//         // return $attendanceData;
//         // Count attendance types
//         $attendanceCount = array_count_values($attendanceData);
//         $total_P = $attendanceCount['P'] ?? 0; // Present
//         $total_L = $attendanceCount['L'] ?? 0; // Leave
//         $total_A = $attendanceCount['A'] ?? 0; // Absent
//         $total_H = $attendanceCount['H'] ?? 0; // Holiday
        
//         // Calculate Attendance Percentage
//         $total_Attended = $total_P; // Only 'P' is considered attended
//         $total_UnAttended = $total_L + $total_A; // Only 'P' is considered attended
//         $PresentattendancePercentage = ($totalWorkingDays > 0) ? round(($total_Attended / $totalWorkingDays) * 100, 2) : 0;
//         $AbsentattendancePercentage  = ($totalWorkingDays > 0) ? round(($total_UnAttended / $totalWorkingDays) * 100, 2) : 0;
        
        
        
//         $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$batch_id)->where('status', 0)->first();
        
//         if (!$eligibleList) {
//             abort(404, 'Certificate details not found.');
//         }
        
//         $scoreList = json_decode($eligibleList->student_id);
//         // return $scoreList;
//         // Initialize score and grade variables
//         $score = 0;
//         $grade = '';
    
//         // Find the matching student by Id
//         foreach ($scoreList as $student) {
//             if ($student->Id == $cus_id) {
//                 // If a match is found, assign score and grade
//                 $score = $student->score;
//                 $grade = $student->grade;
//                 break; // Exit the loop once the student is found
//             }
//         }

//         $exam_person = Student::select(
//             'students.id',
//             'students.exam_status',
//             'students.branch_id',
//             'students.user_name',
//             'students.email_id',
//             'students.phone_no',
//             'students.type',
//             'students.place_name',
//             'za_staff.staff_name',
//             'za_staff.nick_name',
//             'za_staff.staff_image',
//             'students.staff_id'
//         )
//         ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
//         ->where('students.status', 0)
//         ->where('students.id', $cus_id)
//         ->first();

//         // return $exam_person;

//         // Process exam_status JSON
//         if ($exam_person) {
//             $exams = json_decode($exam_person->exam_status, true);
//         }else{
//             $exams = [];
//         }

//         $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();

//         // return $exam_ids;
//         $exam_list = [];
//         // Calculate the number of exams
//         if ($exam_person) {
           
//             $total_exams = is_array($exams) ? count($exams) : 0;
//             $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
//             $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;

//             // Add the counts to $exam_person
//             $exam_person->total_exam = sprintf('%02d', $total_exams);
//             $exam_person->completed_exam = sprintf('%02d', $completed_exams);
//             $exam_person->balance_exam = sprintf('%02d', $balance_exams);
            
//             // Fetch exam list related to this student
//             $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
//             // return $exam_list_exam;
//             $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();

//             // Merge both lists while keeping all records from ExamModel
//             $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
//                 // Get the corresponding process entry for this exam
//                 $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
//                 return [
//                     'exam_id' => $exam->sno,
//                     'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
//                     'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
//                     'certificate' => $exam->certificate ?? null, // Adjust field names as needed
//                     'device_type' => $exam_process->device_type ?? 2,
//                     'student_marks' => $exam_process->student_marks ?? null,
//                     'updated_at' => $exam_process->updated_at ?? null,
//                     'exam_status' => $exam_process->status ?? 1,
//                     'student_id' => $exam_process->student_id ?? null,
//                     'attended_date' => $exam_process->created_at ?? null
//                 ];
//             });
//             // return 'Exam List:' .$exam_list;

//             // Calculate total marks and student marks for exams that are completed (exam_status == 2)
//             $total_marks = 0;
//             $total_student_marks = 0;
//             if($exam_list){
//                 foreach ($exam_list as $exam) {
//                     if ($exam['exam_status'] == 2) {  // Only include exams that are completed
//                         $total_marks += $exam['total_marks'];
//                         $total_student_marks += $exam['student_marks'] ?? 0;
//                     }
//                 }
//             }
//         }

//         // return $exam_person;
//         // return $exam_list;
    
//         // Store the score and grade in the customer details object
//         if ($customerDetails) {
//             $customerDetails->score = $score;
//             $customerDetails->grade = $grade;
//             $customerDetails->total_P = $total_P;
//             $customerDetails->total_L = $total_L;
//             $customerDetails->total_A = $total_A;
//             $customerDetails->total_H = $total_H;
//             $customerDetails->total_working_days = $totalWorkingDays;
//             $customerDetails->PresentattendancePercentage = $PresentattendancePercentage . '%';
//             $customerDetails->AbsentattendancePercentage = $AbsentattendancePercentage . '%';
            
//         }
    
//         // return $customerDetails;
    
        
//         return view('content.courses.manage_certificate.qr_customer_certificate_view', [
//             'customerDetails' => $customerDetails,
//             'exam_list' =>  $exam_list,
//             'exam_person' =>  $exam_person
//         ]);
//     }
    
}