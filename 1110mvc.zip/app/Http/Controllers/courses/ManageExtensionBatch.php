<?php

namespace App\Http\Controllers\courses;

use App\Http\Controllers\Controller;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\CourseTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchCancelReasonModel;
use App\Models\SlotModel;
use App\Models\StaffModel;
use App\Models\TrainingModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ManageExtensionBatch extends Controller
{

    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $batchQuery = BatchExtensionModel::select('za_batch_extension.*', 'za_batch_extension.end_date as ext_end_date', 'za_batch.batch_name', 'za_batch.max_students', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_course.course_name', 'za_batch_extension.status AS exten_status', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.nick_name', 'za_staff.gender', 'za_staff.staff_image')
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
            ->leftjoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftjoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.branch_id', $branch_id);

        $batch = $batchQuery->orderBy('za_batch_extension.status', 'asc')->paginate(25);

        // // Get the student count for each batch
        // foreach ($batch as $singleBatch) {
        //     $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
        //     // Uncomment the next line if you want to filter by course_id
        //     // ->where('course_id', $singleBatch->course_id)
        //         ->count('customer_id');
        // }
        // return $batch;

        // Prepare the course types
        $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
        $reasonList = BatchCancelReasonModel::select('*')
        ->where('status', 0)
        ->orderBy('sno', 'desc')->get();  

        // return $batch;
        // Return the view
        return view('content.courses.manage_extend_batch_list', [
            'batch' => $batch,
            'course_Type_list' => $course_type,
            'reasonList' => $reasonList,
            // 'course_type_fill' => '',
            // 'course_fill' => '',
            // 'batch_name_fill' => '',
            // 'fin_yr_fill' => '',
            // 'date_filter' => '',
        ]);
        // ->with('filter_on', false);

        // return view( 'content.courses.managebatch_list' );
    }

    public function View($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Find the course by decrypted ID
        $batch = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_slot.slot_type_days', 'za_course.course_name', 'za_course.course_version', 'za_course.course_days', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_class_room.location', 'za_class_room.class_room_type', 'za_class_room.facility_id', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_staff.staff_image', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_customer.cus_pic')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftjoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftjoin('za_customer', 'za_customer.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)->where('za_batch.sno', $decryptedValue)->first();

        // Check if the course is not found
        if (!$batch) {
            return redirect()->back()->with('error', 'Batch View not found');
        }

        // Generate date array for the current month
        $dates = [];
        for ($i = 1; $i <= date('t'); $i++) {
            $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
        }

        // Define the start and end of the month
        $startOfMonth = Carbon::now()->startOfMonth()->format('Y-m-d');
        $endOfMonth = Carbon::now()->endOfMonth()->format('Y-m-d');

        // Query for attendance records
        $attendance = BatchModel::select(
            'za_batch.*',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.staff_image',
            'za_user_role.role_name',
            'za_attendance.att_date'
        )
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->leftJoin('za_attendance', function ($join) {
                $join->on('za_attendance.staff_id', '=', 'za_batch.staff_id')
                    ->whereColumn('za_attendance.batch_id', 'za_batch.sno')
                    ->whereColumn('za_attendance.branch_id', 'za_batch.branch_id');
            })
            ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
            ->where('za_batch.status', '!=', 2)
            ->where('za_batch.sno', $decryptedValue) // Replace $decryptedValue with actual batch ID
            ->whereBetween('za_attendance.att_date', [$startOfMonth, $endOfMonth])
            ->get();

        $totalStudents = TrainingModel::where('za_training.batch_id', $batch->sno)
            ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            ->where('za_training.status', 0)
            ->distinct('za_training.customer_id') // Ensure unique customers
            ->count('za_training.customer_id'); // Count the unique customer_ids

        // return $totalStudents;

        $lists = TrainingModel::where('za_training.batch_id', $batch->sno)
            ->where('za_training.staff_id', $batch->staff_id)
            ->where('za_training.course_id', $batch->course_id)
            ->where('za_training.status', 0)
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_customer.customer_id', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();

        $batch_staff = $batch->staff_id;

        return view('content.courses.view_batch', [
            'view' => $batch,
            'stud_view' => $totalStudents,
            'dates' => $dates,
            'attendance' => $attendance,
            'batch_staff' => $batch_staff,
            'stud_list' => $lists,
        ]);

        // return $lists;
    }

    public function filterStaff(Request $request)
    {
        $slotId = $request->input('slot_id');

        // Ensure you have a valid slot ID
        if (!$slotId) {
            return response()->json(['status' => 400, 'message' => 'Slot ID is required']);
        }

        // Query to get staff allocated for the given slot ID
        $staffIds = BatchModel::where('slot_id', $slotId)->where('status', 0)
            ->pluck('staff_id')
            ->unique()
            ->values()
            ->toArray();

        // Get the staff data excluding the ones already allocated to the selected slot
        // $filteredStaff = StaffModel::whereNotIn('sno', $staffIds)->get();

        return response()->json(['status' => 200, 'data' => $staffIds]);
    }
    public function getCourselist(Request $request)
    {
        $courseTypeId = $request->input('course_id');

        // Fetch courses based on course_type_id
        $courses = ManageCoursesModel::where('status', 0)->where('sno', $courseTypeId)->get();

        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }
    public function getSlotlist(Request $request)
    {
        $courseTypeId = $request->input('slot_id');

        // Fetch courses based on course_type_id
        $courses = SlotModel::where('status', 0)->where('sno', $courseTypeId)->get();

        return response()->json([
            'status' => 200,
            'data' => $courses,
        ]);
    }
    public function filterStaffEdit(Request $request)
    {
        $slotId = $request->input('slot_id');
        $batchId = $request->input('batch_id');

        // Ensure you have a valid slot ID
        if (!$slotId) {
            return response()->json(['status' => 400, 'message' => 'Slot ID is required']);
        }

        // Get the staff ID for the given batch ID
        $staff_id = BatchModel::where('sno', $batchId)->value('staff_id');

        if ($staff_id === null) {
            return response()->json(['status' => 404, 'message' => 'Batch ID not found']);
        }

        // Get staff IDs allocated to the given slot ID excluding the staff ID from the given batch ID
        $staffIds = BatchModel::where('slot_id', $slotId)
            ->where('staff_id', '!=', $staff_id)
            ->pluck('staff_id')
            ->unique()
            ->values()
            ->toArray();

        // Get the staff data excluding the ones already allocated to the selected slot
        $filteredStaff = BatchModel::whereNotIn('staff_id', $staffIds)->get();

        return response()->json(['status' => 200, 'data' => $filteredStaff]);
    }
    public function staffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $staff = StaffModel::where('status', '!=', 2)
            ->where('department_id', 2);
        if ($branch_id != 0) {
            $staff->where('branch_id', $branch_id);
        }
        $staff = $staff->orderBy('staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }

    public function BatchExtension(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'batch_id_extension' => 'required', // Ensure batch_id is present for update
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $batch_id = $request->batch_id_extension;
            $reason = $request->batch_reason_extension;
            $end_date = date('Y-m-d', strtotime($request->batch_end_date_old_hidden));
            $change_date = date('Y-m-d', strtotime($request->end_date_extension));
            $user_id = $request->user()->user_id;

            $add_category = new BatchExtensionModel();
            $add_category->batch_id = $batch_id;
            $add_category->end_date = $end_date;
            $add_category->change_date = $change_date;
            $add_category->branch_id = $branch_id;
            $add_category->reason = $reason;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;

            $add_category->save();
            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Batch updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Batch!',
                ]);
            }

            return redirect()->back()->with('success', 'Batch updated successfully!');
        }
    }

    public function ExtendBatchEdit($id = '')
    {
        // return $id;

        // Check if decryption failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        // Find the course by decrypted ID
        $extend_batch = BatchExtensionModel::select(
            'za_batch_extension.*',
            'za_batch_extension.change_date as change_datessss',
            'za_batch.batch_name',
            'za_batch.sno as batch_extend_sno',
            'za_batch.max_students',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.slot_name',
            'za_course.course_name',
            'za_course_type.course_type_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_staff.staff_name',
            'za_class_room.class_room_name'
        )
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')

        // ->leftJoin('za_batch_extension', 'za_batch_extension.batch_id', '=', 'za_batch.sno')
            ->where('za_batch_extension.status', '!=', 2)
            ->where('za_batch_extension.sno', $id)
            ->first();

        // dd($extend_batch);

        // Check if the course is not found
        if (!$extend_batch) {
            return redirect()->back()->with('error', 'Batch View not found');
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $extend_batch,
        ], 200);
    }

    public function ExtendBatchApprove(Request $request)
    {
        // return $request;
        // Get the values from the request
        $id = $request->extend_sno;
        $batch_sno = $request->batch_id_approve;
        $status = 1; // Status to approve the batch extension
        $end_date = $request->batch_change_date_approve_hidden; // The new end date for the batch

        // Find the Batch Extension model by sno
        $BatchModel = BatchExtensionModel::where('sno', $id)->first();
        if ($BatchModel) {
            $BatchModel->status = 1; // Update the status
            $BatchModel->save(); // Save the updated model
        }

        // return $BatchModel;
        // Update the Batch model
        $batch_upd = BatchModel::where('sno', $batch_sno)->first();
        if ($batch_upd) {
            // Update the batch's end date
            $batch_upd->end_date = date('Y-m-d', strtotime($end_date)); // Assuming the end_date is being passed in the correct format
            $batch_upd->save(); // Save the updated batch model
            //  return $batch_upd;
            
            // Get all trainings under this batch
            $training_batch = TrainingModel::where('batch_id', $batch_upd->sno)->get();
        
            // Loop through each training and update the end_date
            foreach ($training_batch as $training) {
                $training->end_date = date('Y-m-d', strtotime($end_date));
                $training->save();
            }
            
            // return $training_batch;
            // Flash success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Batch updated Successfully!',
            ]);
        } else {
            // Flash error message if batch is not found
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Batch!',
            ]);
        }

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Batch updated successfully!');
    }
    
    public function ExtendBatchCancel(Request $request)
    {
        // return $request;

        $id = $request->extend_sno_cancel;
        $batch_sno = $request->batch_id_cancel;
        // $status = 2; // Status to approve the batch extension
        $end_date = $request->batch_change_date_cancel_hidden; // The new end date for the batch

        // Find the Batch Extension model by sno
        $BatchModel = BatchExtensionModel::where('sno', $id)->first();
        if ($BatchModel) {
            $BatchModel->status = 2; // Update the status
            if($request->cancel_reason == 1){
                $BatchModel->cancel_reason = $request->cancel_reason;
                $BatchModel->other_reason = $request->reason_text;
            }else {
                $BatchModel->cancel_reason = $request->cancel_reason;
            }
            $BatchModel->cancel_comments = $request->cancel_comments ??  null;
            $BatchModel->updated_by = $request->user()->user_id;
            // return $BatchModel;
            $BatchModel->save(); // Save the updated model
        }

        // return $BatchModel;
        // // Update the Batch model
        // $batch_upd = BatchModel::where('sno', $batch_sno)->first();
        // if ($batch_upd) {
        //     // Update the batch's end date
        //     $batch_upd->end_date = date('Y-m-d', strtotime($end_date)); // Assuming the end_date is being passed in the correct format
        //     $batch_upd->save(); // Save the updated batch model
        //     //  return $batch_upd;
        //     // Flash success message
        //     session()->flash('toastr', [
        //         'type' => 'success',
        //         'message' => 'Batch updated Successfully!',
        //     ]);
        // } else {
        //     // Flash error message if batch is not found
        //     session()->flash('toastr', [
        //         'type' => 'error',
        //         'message' => 'Could not update the Batch!',
        //     ]);
        // }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Batch updated Successfully!',
        ]);

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Batch updated successfully!');
    }

}
