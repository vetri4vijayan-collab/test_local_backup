<?php
// Developed by Vasanth
namespace App\Http\Controllers\courses;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\CourseActionModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\MaterialTypeModel;
use App\Models\LanguageModel;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;

class ManageCoursesMaterial extends Controller
{


  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    
     $role_id   = $request->user()->role_id;


    /* ----------------------------
        FILTER INPUTS
      -----------------------------*/
    $filters = $request->only([
      'course_fill',
      'course_category_fill',
      'course_subcategory_fill',
      'course_type_fill',
      'min_price_fill',
      'max_price_fill',
    ]);

    /* ----------------------------
        BASE QUERY
      -----------------------------*/
    $query = ManageCoursesModel::select(
      'za_course.*',
      'za_course_type.course_type_name',
      'za_course_type.sno as category_id'
    )
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
      ->where('za_course.status', '!=', 2)
      ->where('za_batch.status', 0)
      ->where('za_batch.staff_id', $user_id)
      ->where('za_batch.branch_id', $branch_id)
      ->orderBy('za_course.sno', 'desc');

        if ($role_id == [33, 22, 30]) {
      $query->where('za_batch.staff_id', $user_id);
    }
    /* ----------------------------
        APPLY FILTERS
      -----------------------------*/
    if (!empty($filters['course_fill'])) {
      $query->where('za_course.course_name', 'LIKE', "%{$filters['course_fill']}%");
    }

    if (!empty($filters['course_category_fill'])) {
      $query->where('za_course.course_category_id', $filters['course_category_fill']);
    }

    if (!empty($filters['course_subcategory_fill'])) {
      $query->where('za_course.course_subcategory_id', $filters['course_subcategory_fill']);
    }

    if (!empty($filters['course_type_fill'])) {
      $query->where('za_course.course_type_id', $filters['course_type_fill']);
    }

    if (!empty($filters['min_price_fill'])) {
      $query->where('za_course.course_min_price', '>=', $filters['min_price_fill']);
    }

    if (!empty($filters['max_price_fill'])) {
      $query->where('za_course.course_max_price', '<=', $filters['max_price_fill']);
    }

    /* ----------------------------
        PAGINATE
      -----------------------------*/
    $managecourses_list = $query->paginate(25);

    /* ----------------------------
        ATTACH MATERIAL COUNTS
      -----------------------------*/
    $managecourses_list->getCollection()->transform(function ($course) {

      $materials = json_decode($course->materials, true) ?? [];

      // LOCAL ARRAY (important)
      $materialCounts = [];

      // Initialize document types 1–6
      for ($i = 1; $i <= 6; $i++) {
        $materialCounts[$i] = [
          'exists' => false,
          'count'  => 0
        ];
      }

      // Count materials
      foreach ($materials as $material) {
        $type = (int) ($material['document_type_id'] ?? 0);

        if ($type >= 1 && $type <= 6) {
          $materialCounts[$type]['exists'] = true;
          $materialCounts[$type]['count']++;
        }
      }

      // ✅ ASSIGN ONCE
      $course->material_counts = $materialCounts;

      return $course;
    });



    /* ----------------------------
        DROPDOWNS
      -----------------------------*/
    $course_type = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory = CourseCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return view('content.courses.managecoursesmaterial_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'CourseCategory' => $CourseCategory,
      'pageConfigs' => ['myLayout' => 'default'],
      'filters' => $filters
    ])->with('filter_on', !empty(array_filter($filters)));
  }
}
