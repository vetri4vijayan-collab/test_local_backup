<?php
// Developed by Vasanth
namespace App\Http\Controllers\courses;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\CourseActionModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\StaffModel;
use App\Models\BranchModel;
use App\Models\MaterialTypeModel;
use App\Models\LanguageModel;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;

class ManageCoursesMaterial extends Controller
{


//   public function index(Request $request)
//   {
//     $branch_id = $request->user()->branch_id;
//     $user_id   = $request->user()->user_id;
//     $role_id   = $request->user()->role_id;
//     $depat  = StaffModel::where('sno', $user_id)->where('department_id', 2)->first();

//     /* ----------------------------
//         FILTER INPUTS
//       -----------------------------*/
//     $filters = $request->only([
//       'course_fill',
//       'course_category_fill',
//       'course_subcategory_fill',
//       'course_type_fill',
//       'min_price_fill',
//       'max_price_fill',
//     ]);

//     /* ----------------------------
//         BASE QUERY
//       -----------------------------*/
//     $query = ManageCoursesModel::select(
//       'za_course.*',
//       'za_course_type.course_type_name',
//       'za_course_type.sno as category_id'
//     )
//       ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->where('za_course.status', '!=', 2)
//       ->orderBy('za_course.sno', 'desc');

//     if ($depat) {
//       $query->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')->where('za_batch.branch_id', $branch_id)->where('za_batch.staff_id', $user_id)->where('za_batch.status', 0);
//     }
//     /* ----------------------------
//         APPLY FILTERS
//       -----------------------------*/
//     if (!empty($filters['course_fill'])) {
//       $query->where('za_course.course_name', 'LIKE', "%{$filters['course_fill']}%");
//     }

//     if (!empty($filters['course_category_fill'])) {
//       $query->where('za_course.course_category_id', $filters['course_category_fill']);
//     }

//     if (!empty($filters['course_subcategory_fill'])) {
//       $query->where('za_course.course_subcategory_id', $filters['course_subcategory_fill']);
//     }

//     if (!empty($filters['course_type_fill'])) {
//       $query->where('za_course.course_type_id', $filters['course_type_fill']);
//     }

//     if (!empty($filters['min_price_fill'])) {
//       $query->where('za_course.course_min_price', '>=', $filters['min_price_fill']);
//     }

//     if (!empty($filters['max_price_fill'])) {
//       $query->where('za_course.course_max_price', '<=', $filters['max_price_fill']);
//     }

//     /* ----------------------------
//         PAGINATE
//       -----------------------------*/
//     $managecourses_list = $query->paginate(25);

//     /* ----------------------------
//         ATTACH MATERIAL COUNTS
//       -----------------------------*/
//     $managecourses_list->getCollection()->transform(function ($course) {

//       $materials = json_decode($course->materials, true) ?? [];

//       // LOCAL ARRAY (important)
//       $materialCounts = [];

//       // Initialize document types 1–6
//       for ($i = 1; $i <= 6; $i++) {
//         $materialCounts[$i] = [
//           'exists' => false,
//           'count'  => 0
//         ];
//       }

//       // Count materials
//       foreach ($materials as $material) {
//         $type = (int) ($material['document_type_id'] ?? 0);

//         if ($type >= 1 && $type <= 6) {
//           $materialCounts[$type]['exists'] = true;
//           $materialCounts[$type]['count']++;
//         }
//       }

//       // ✅ ASSIGN ONCE
//       $course->material_counts = $materialCounts;

//       return $course;
//     });



//     /* ----------------------------
//         DROPDOWNS
//       -----------------------------*/
//     $course_type = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $CourseCategory = CourseCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

//     $branch = BranchModel::where('sno', $branch_id)->first();
//     $staff  = StaffModel::where('sno', $user_id)->where('department_id', 2)->first();
 
//     $record = \DB::table('za_course_material')->where('sno', 1)->first();
//     $data   = $record ? json_decode($record->course_materials, true) : [];
 
//     if ($staff || $branch && $branch->branch_type == 2) {
 
//       if ($branch && $branch->branch_type == 2) {
//         // Franchise user
//         $permissions = $data['franchise'] ?? [];
//       } else {
//         // Faculty staff user
//         $permissions = $data['faculty_staffs'] ?? [];
//       }
//     } else {
//       // Admin or other users → full access
//       $permissions = ['Document', 'PPT', 'PDF', 'Lab Code', 'Audio', 'Video'];
//     }
 
//     // return $permissions;
//     return view('content.courses.managecoursesmaterial_list', [
//       'permissions' => $permissions,
//       'managecourses_list' => $managecourses_list,
//       'course_type_fill_list' => $course_type,
//       'CourseCategory' => $CourseCategory,
//       'pageConfigs' => ['myLayout' => 'default'],
//       'filters' => $filters
//     ])->with('filter_on', !empty(array_filter($filters)));
//   }

public function index(Request $request)
{
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $role_id   = $request->user()->role_id;
 
    $depat  = StaffModel::where('sno', $user_id)->where('department_id', 2)->first();
 
    /* ----------------------------
        FILTER INPUTS
      -----------------------------*/
    $filters = $request->only([
        'course_fill',
        'course_category_fill',
        'course_subcategory_fill',
        'course_type_fill',
        'min_price_fill',
        'max_price_fill',
    ]);
 
    /* ----------------------------
        BASE QUERY
      -----------------------------*/
    $query = ManageCoursesModel::select(
        'za_course.*',
        'za_course_type.course_type_name',
        'za_course_type.sno as category_id'
    )
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_course.status', '!=', 2)
        ->orderBy('za_course.sno', 'desc');
 
    if ($depat) {
        $query->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
              ->where('za_batch.branch_id', $branch_id)
              ->where('za_batch.staff_id', $user_id)
              ->where('za_batch.status', 0);
    }
   
    /* ----------------------------
        APPLY FILTERS
      -----------------------------*/
    if (!empty($filters['course_fill'])) {
        $query->where('za_course.course_name', 'LIKE', "%{$filters['course_fill']}%");
    }
 
    if (!empty($filters['course_category_fill'])) {
        $query->where('za_course.course_category_id', $filters['course_category_fill']);
    }
 
    if (!empty($filters['course_subcategory_fill'])) {
        $query->where('za_course.course_subcategory_id', $filters['course_subcategory_fill']);
    }
 
    if (!empty($filters['course_type_fill'])) {
        $query->where('za_course.course_type_id', $filters['course_type_fill']);
    }
 
    if (!empty($filters['min_price_fill'])) {
        $query->where('za_course.course_min_price', '>=', $filters['min_price_fill']);
    }
 
    if (!empty($filters['max_price_fill'])) {
        $query->where('za_course.course_max_price', '<=', $filters['max_price_fill']);
    }
 
    /* ----------------------------
        PAGINATE
      -----------------------------*/
    $managecourses_list = $query->paginate(25);
 
    /* ----------------------------
        ATTACH MATERIAL COUNTS (FIXED FOR TESBO)
      -----------------------------*/
    $managecourses_list->getCollection()->transform(function ($course) {
       
        // Check if it's a Tesbo course (course_type_id = 2)
        if ($course->course_type_id == 2 && !empty($course->tesbo_cousre_id)) {
            // Decode the tesbo_cousre_id JSON array
            $tesboCourseIds = json_decode($course->tesbo_cousre_id, true);
           
            if (is_array($tesboCourseIds) && count($tesboCourseIds) > 0) {
                // Fetch all materials from the individual Tesbo courses
                $allMaterials = [];
               
                // Get materials from each Tesbo course
                $tesboCourses = ManageCoursesModel::whereIn('sno', $tesboCourseIds)
                                                  ->where('status', '!=', 2)
                                                  ->get();
               
                foreach ($tesboCourses as $tesboCourse) {
                    $materials = json_decode($tesboCourse->materials, true) ?? [];
                    $allMaterials = array_merge($allMaterials, $materials);
                }
               
                // Process materials from all combined courses
                $materialCounts = $this->countMaterials($allMaterials);
                $course->material_counts = $materialCounts;
               
                return $course;
            }
        }
       
        // Regular course (non-Tesbo)
        $materials = json_decode($course->materials, true) ?? [];
        $materialCounts = $this->countMaterials($materials);
        $course->material_counts = $materialCounts;
       
        return $course;
    });
 
    /* ----------------------------
        DROPDOWNS
      -----------------------------*/
    $course_type = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory = CourseCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();
 
    $branch = BranchModel::where('sno', $branch_id)->first();
    $staff  = StaffModel::where('sno', $user_id)->where('department_id', 2)->first();
 
    $record = \DB::table('za_course_material')->where('sno', 1)->first();
    $data   = $record ? json_decode($record->course_materials, true) : [];
 
    if ($staff || $branch && $branch->branch_type == 2) {
 
        if ($branch && $branch->branch_type == 2) {
            // Franchise user
            $permissions = $data['franchise'] ?? [];
        } else {
            // Faculty staff user
            $permissions = $data['faculty_staffs'] ?? [];
        }
    } else {
        // Admin or other users → full access
        $permissions = ['Document', 'PPT', 'PDF', 'Lab Code', 'Audio', 'Video'];
    }
 
    return view('content.courses.managecoursesmaterial_list', [
        'permissions' => $permissions,
        'managecourses_list' => $managecourses_list,
        'course_type_fill_list' => $course_type,
        'CourseCategory' => $CourseCategory,
        'pageConfigs' => ['myLayout' => 'default'],
        'filters' => $filters
    ])->with('filter_on', !empty(array_filter($filters)));
}
 
/**
 * Helper method to count materials by document type
 */
private function countMaterials($materials)
{
    // Initialize document types 1–6
    $materialCounts = [];
    for ($i = 1; $i <= 6; $i++) {
        $materialCounts[$i] = [
            'exists' => false,
            'count'  => 0
        ];
    }
 
    // Count materials
    foreach ($materials as $material) {
        $type = (int) ($material['document_type_id'] ?? 0);
 
        if ($type >= 1 && $type <= 6) {
            $materialCounts[$type]['exists'] = true;
            $materialCounts[$type]['count']++;
        }
    }
 
    return $materialCounts;
}

}
