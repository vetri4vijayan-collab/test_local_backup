<?php
// Developed by Vasanth
namespace App\Http\Controllers\courses;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\CourseActionModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\StaffModel;
use App\Models\BranchModel;
use App\Models\MaterialTypeModel;
use App\Models\LanguageModel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
class ManageCourses extends Controller
{
  // Pubic Function end
  // Index Function
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    // Fetch course types
    $course_type = CourseTypeModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    // Fetch course categories
    $CourseCategory = CourseCategoryModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    $pageConfigs = ['myLayout' => 'default'];

    // Initialize an empty array for filtered courses
    $managecourses_list = [];

    // Case 1: If branch_id is 0, fetch all courses
    if ($branch_id == 6 ||$branch_id == 1) {
      // Fetch all courses
      $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_course.status', '!=', 2)
        ->where('za_course_type.combined_course', 0)
        ->orderBy('za_course.sno', 'desc')
        ->paginate(25); // Paginate results
    } else {
      // Case 2: If branch_id is not 0, fetch courses specific to the branch
      $branch_course = CourseAssigne_model::select('*')
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->first();

      if ($branch_course) {
        // Decode the JSON of course_ids
        $course_ids = json_decode($branch_course->course_id, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($course_ids)) {
          // Ensure course_ids is an array of integers
          $integer_course_ids = array_map('intval', $course_ids);

          // Fetch filtered courses based on course_ids
          $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->whereIn('za_course.sno', $integer_course_ids) // Use whereIn for multiple IDs
            ->where('za_course.status', '!=', 2) // Ensure status is not 2
            ->where('za_course_type.combined_course', 0)
            ->orderBy('za_course.sno', 'desc')
            ->paginate(25); // Paginate results
            //  return $managecourses_list;
        }
      } else {
        // Fetch filtered courses based on course_ids
        $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->where('za_course.status', '50') // Ensure status is not 2
          ->where('za_course_type.combined_course', 0)
          ->orderBy('za_course.sno', 'desc')
          ->paginate(25); // Paginate results
         
      }
    }

    // Return the view with the filtered or all courses
    return view('content.courses.managecourses_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'CourseCategory' => $CourseCategory,
      'course_fill' => '',
      'course_category_fill' => '',
      'course_subcategory_fill' => '',
      'course_type_fill' => '',
      'min_price_fill' => '',
      'max_price_fill' => '',
      'pageConfigs' => $pageConfigs
    ])->with('filter_on', false);
  }
  public function Combined_course_list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    // Fetch course types
    $course_type = CourseTypeModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();
    // Fetch course categories
    $CourseCategory = CourseCategoryModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();
    $pageConfigs = ['myLayout' => 'default'];
    // Initialize an empty array for filtered courses
    $managecourses_list = [];
    // Case 1: If branch_id is 0, fetch all courses
    if ($branch_id == 6 ||$branch_id == 1) {
      // Fetch all courses
      $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_course.status', '!=', 2)
        ->where('za_course_type.combined_course', 1)
        ->orderBy('za_course.sno', 'desc')
        ->paginate(25); // Paginate results
    } else {
      // Case 2: If branch_id is not 0, fetch courses specific to the branch
      $branch_course = CourseAssigne_model::select('*')
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->first();

      if ($branch_course) {
        // Decode the JSON of course_ids
        $course_ids = json_decode($branch_course->course_id, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($course_ids)) {
          // Ensure course_ids is an array of integers
          $integer_course_ids = array_map('intval', $course_ids);

          // Fetch filtered courses based on course_ids
          $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->whereIn('za_course.sno', $integer_course_ids) // Use whereIn for multiple IDs
            ->where('za_course.status', '!=', 2) // Ensure status is not 2
            ->where('za_course.course_type_id', 2)
            ->orderBy('za_course.sno', 'desc')
            ->paginate(25); // Paginate results
        }
      } else {
        // Fetch filtered courses based on course_ids
        $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->where('za_course.status', '50') // Ensure status is not 2
          ->where('za_course.course_type_id', 2)
          ->orderBy('za_course.sno', 'desc')
          ->paginate(25); // Paginate results
      }
    }

    // Return the view with the filtered or all courses
    return view('content.courses.manage_combained_courses_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'CourseCategory' => $CourseCategory,
      'course_fill' => '',
      'course_category_fill' => '',
      'course_subcategory_fill' => '',
      'course_type_fill' => '',
      'min_price_fill' => '',
      'max_price_fill' => '',
      'pageConfigs' => $pageConfigs
    ])->with('filter_on', false);
  }
  // Filter List Function
  public function list_filter(Request $request)
  {
    // Get filter inputs from the request
    $course_fill = $request->course_fill ?? '';
    $course_category_fill = $request->course_category_fill ?? '';
    $course_subcategory_fill = $request->course_subcategory_fill ?? '';
    $course_type_fill = $request->course_type_fill ?? '';
    $min_price_fill = $request->min_price_fill ?? '';
    $max_price_fill = $request->max_price_fill ?? '';

    // Get branch ID from the logged-in user
    $branch_id = $request->user()->branch_id;

    // Initialize the query
    $managecourses_list = [];

    // Case 1: If branch_id is 0, fetch all courses and apply filters
    if ($branch_id == 6 ||$branch_id == 1) {
      // Fetch all courses and apply filters
      $query = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_course.status', '!=', 2)
        ->where('za_course_type.combined_course', 0)
        ->orderBy('za_course.sno', 'desc');

      // Apply filters dynamically
      if ($course_fill) {
        $query->where('za_course.course_name', 'LIKE', "%{$course_fill}%");
      }
      if ($course_category_fill) {
        $query->where('za_course.course_category_id', 'LIKE', "%{$course_category_fill}%");
      }
      if ($course_subcategory_fill) {
        $query->where('za_course.course_subcategory_id', 'LIKE', "%{$course_subcategory_fill}%");
      }
      if ($course_type_fill) {
        $query->where('za_course.course_type_id', $course_type_fill);
      }
      if ($min_price_fill) {
        $query->where('za_course.course_min_price', 'LIKE', "%{$min_price_fill}%");
      }
      if ($max_price_fill) {
        $query->where('za_course.course_max_price', 'LIKE', "%{$max_price_fill}%");
      }

      // Fetch the filtered and ordered results
      $managecourses_list = $query->paginate(25);
    } else {
      // Case 2: If branch_id is not 0, fetch courses specific to the branch
      $branch_course = CourseAssigne_model::select('*')
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->first();

      if ($branch_course) {
        // Decode the JSON of course_ids
        $course_ids = json_decode($branch_course->course_id, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($course_ids)) {
          // Ensure course_ids is an array of integers
          $integer_course_ids = array_map('intval', $course_ids);

          // Fetch filtered courses based on course_ids
          $query = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->whereIn('za_course.sno', $integer_course_ids) // Use whereIn for multiple IDs
            ->where('za_course.status', '!=', 2) // Ensure status is not 2
            ->where('za_course_type.combined_course', 0)
            ->orderBy('za_course.sno', 'desc');

          // Apply filters dynamically
          if ($course_fill) {
            $query->where('za_course.course_name', 'LIKE', "%{$course_fill}%");
          }
          if ($course_category_fill) {
            $query->where('za_course.course_category_id', 'LIKE', "%{$course_category_fill}%");
          }
          if ($course_subcategory_fill) {
            $query->where('za_course.course_subcategory_id', 'LIKE', "%{$course_subcategory_fill}%");
          }
          if ($course_type_fill) {
            $query->where('za_course.course_type_id', $course_type_fill);
          }
          if ($min_price_fill) {
            $query->where('za_course.course_min_price', 'LIKE', "%{$min_price_fill}%");
          }
          if ($max_price_fill) {
            $query->where('za_course.course_max_price', 'LIKE', "%{$max_price_fill}%");
          }

          // Fetch the filtered and ordered results
          $managecourses_list = $query->paginate(25);
        }
      } else {
        // Fetch filtered courses based on course_ids
        $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->where('za_course.status', '50') // Ensure status is not 2
          ->where('za_course_type.combined_course', 0)
          ->orderBy('za_course.sno', 'desc')
          ->paginate(25); // Paginate results
      }
    }

    // Fetch course types for filter options
    $course_type = CourseTypeModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    // Fetch course categories for filter options
    $CourseCategory = CourseCategoryModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    $pageConfigs = ['myLayout' => 'default'];

    // Return view with data
    return view('content.courses.managecourses_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'CourseCategory' => $CourseCategory,
      'course_fill' => $course_fill,
      'course_category_fill' => $course_category_fill,
      'course_subcategory_fill' => $course_subcategory_fill,
      'course_type_fill' => $course_type_fill,
      'min_price_fill' => $min_price_fill,
      'max_price_fill' => $max_price_fill,
      'pageConfigs' => $pageConfigs
    ])->with('filter_on', true);
  }
  // Course Dropdown Function
  public function List()
  {
    $lead = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', 0)
      ->orderBy('za_course.sno', 'desc')
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }
   public function ListCustomer(Request $request)
  {
    $categoryId = $request->get('course_type_id');
    $lead = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', 0)
      ->where('za_course.course_type_id',$categoryId)
      ->orderBy('za_course.sno', 'desc')
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }
  public function Tesbo_List()
  {
    $lead = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', 0)
      ->where('za_course.course_type_id', '!=', 2)
      ->orderBy('za_course.sno', 'desc')
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }
  // Course Add Insert
  public function Add(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'course_category_id' => 'required',
      'course_subcategory_id' => 'required',
      'course_type_id' => 'required',
      'course_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }
    $combined_course_chk = $request->combined_course_chk ?? 0;
    $course_category_id = $request->course_category_id;
    $course_subcategory_id = $request->course_subcategory_id;
    $course_type_id = $request->course_type_id;
    $tesbo_cousre_id = json_encode($request->input('tcourse_id', []));
    $course_name = ucfirst($request->course_name);
    $course_version = $request->course_version;
    $course_sr_code = $request->course_sr_code;
    $course_code = $request->course_code;
    $course_days = $request->course_days;
    $course_duration = $request->course_duration;
    $course_partical_hours = $request->course_partical_hours;
    $course_theory_hours = $request->course_theory_hours;
    $brand_id = $request->brand_id;
    $group_id = $request->group_id;
    $job_roll_id = $request->job_roll_id;
    $pre_skill_set_id = $request->pre_skill_set_id;
    $course_min_price = $request->course_min_price;
    $course_max_price = $request->course_max_price;
    $thumbnail_image = $request->file('thumbnail_image');
    $attachment = $request->file('attachment');
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $Know_tag = is_array($request->course_KnowledgeTag) ? json_encode($request->course_KnowledgeTag) : $request->course_KnowledgeTag;
    $course_type = CourseTypeModel::Where('sno', $course_type_id)->first();
    $course_check = ManageCoursesModel::orderBy('sno', 'desc')->first();
    if (!$course_check) {
      // No previous course ID, so start with 'C-0001'
      $year = date('y');
      $course_id = 'C-0001/' . $year;
    } else {
      $data = $course_check->course_id;
      // Split the course_id by '/'
      $slice = explode('/', $data);
      // Extract the numeric part from 'C-xxxx'
      $result = preg_replace('/[^0-9]/', '', $slice[0]);
      // Increment the number part
      $next_number = (int)$result + 1;
      // Format the new course ID with 4 digits
      $requestId = sprintf('C-%04d', $next_number);
      // Get the current year
      $year = date('y');
      // Generate the new course ID
      $course_id = $requestId . '/' . $year;
    }

    // Upload thumbnail image
    $thumbnail = '';
    if ($thumbnail_image) {
      $imageName = idate('B') . rand(1, 50) . '.' . $thumbnail_image->extension();
      $destinationPath = public_path('course_thumbnail_image');
      $thumbnail_image->move($destinationPath, $imageName);
      $thumbnail = $imageName;
    }

    // Upload attachment
    $attachmentFile = '';
    if ($attachment) {
      $attachmentName = idate('B') . rand(1, 50) . '.' . $attachment->extension();
      $attachmentDestination = public_path('course_attachments');
      $attachment->move($attachmentDestination, $attachmentName);
      $attachmentFile = $attachmentName;
    }
    $course = new ManageCoursesModel();
    // Assuming 'Course' is your model
    $course->course_category_id = $course_category_id;
    $course->course_id = $course_id;
    $course->branch_id = $branch_id;
    $course->course_subcategory_id = $course_subcategory_id;
    $course->course_type_id = $course_type_id;
    $course->tesbo_cousre_id = $tesbo_cousre_id;
    $course->course_name = $course_name;
    $course->course_version = $course_version;
    $course->course_sr_code = $course_sr_code;
    $course->course_code = $course_code;
    $course->course_days = $course_days;
    $course->course_duration = $course_duration;
    $course->last_fees_duration_days = $course_type->last_fees_duration_days;
    $course->fees_schedule = $course_type->fees_schedule;
    $course->course_partical_hours = $course_partical_hours;
    $course->course_theory_hours = $course_theory_hours;
    $course->knowledge_tags = $Know_tag;
    $course->brand_id = $brand_id;
    $course->group_id = $group_id;
    $course->job_roll_id = json_encode($job_roll_id);
    $course->pre_skill_set_id = json_encode($pre_skill_set_id);
    $course->course_min_price = $course_min_price;
    $course->course_max_price = $course_max_price;
    $course->course_desc = $request->course_desc;
    $course->course_goals = $request->course_goals;
    $course->course_future_scope = $request->course_future_scope;
    $course->thumbnail = $thumbnail;
    $course->attachment = $attachmentFile;
    $course->created_by = $user_id;
    $course->updated_by = $user_id;

    // Save the course
    $saved = $course->save();

    if ($combined_course_chk == 1) {
      // Optionally, you can flash a success message
      if ($saved) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Combined Course added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Combined Course !'
        ]);
      }
      // Redirect to a success page or any other page as needed
      return redirect('courses/combined_course');
    } else {

      if ($saved) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Course added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Course !'
        ]);
      }
      // Redirect to a success page or any other page as needed
      return redirect('courses/manage_courses');
    }
  }
  // Course Edit Data fetch
  public function edit($id)
  {
    $data = ManageCoursesModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  // Course Update Function
  public function update(Request $request)
  {

    // return $request;
    $validator = Validator::make($request->all(), [
      'course_category_id_edit' => 'required',
      'course_subcategory_id_edit' => 'required',
      'course_type_id_edit' => 'required',
      'course_name_edit' => 'required|max:255',
      'course_version_edit' => 'required|max:255',
      'course_sr_code_edit' => 'required|max:255',
      'course_code_edit' => 'required|max:255',
      'course_days_edit' => 'required|numeric',
      'course_duration_edit' => 'required|numeric',
      'course_partical_hours_edit' => 'required|numeric',
      'course_theory_hours_edit' => 'required|numeric',
      'brand_id_edit' => 'required',
      'group_id_edit' => 'required',
      'job_roll_id_edit' => 'required',
      'pre_skill_set_id_edit' => 'required',
      'course_min_price_edit' => 'required|numeric',
      'course_max_price_edit' => 'required|numeric',
      // 'thumbnail_image_edit' => 'required|mimes:jpeg, png|max:1000',
      // 'attachment' => 'required|mimes:pdf|max:1000',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back()->withErrors($validator)->withInput();
    }

    $courseData = ManageCoursesModel::find($request->course_sno_hidden);

    if (!$courseData) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Course not found!'
      ]);
      return redirect()->back();
    }
    $combined_course_chk_edit = $request->combined_course_chk_edit ?? 0;
    // return $combined_course_chk_edit;
    $course_type = CourseTypeModel::Where('sno', $request->course_type_id_edit)->first();
    $Know_tag = is_array($request->course_KnowledgeTag_edit) ? json_encode($request->course_KnowledgeTag_edit) : $request->course_KnowledgeTag_edit;

    $courseData->course_category_id = $request->course_category_id_edit;
    $courseData->course_subcategory_id = $request->course_subcategory_id_edit;
    $courseData->course_type_id = $request->course_type_id_edit;
    $courseData->knowledge_tags = $Know_tag;
    $courseData->course_name = ucfirst($request->course_name_edit);
    $courseData->course_version = $request->course_version_edit;
    $courseData->course_sr_code = $request->course_sr_code_edit;
    $courseData->course_code = $request->course_code_edit;
    $courseData->course_days = $request->course_days_edit;
    $courseData->course_duration = $request->course_duration_edit;
    $courseData->last_fees_duration_days = $course_type->last_fees_duration_days;
    $courseData->fees_schedule = $course_type->fees_schedule;
    $courseData->course_partical_hours = $request->course_partical_hours_edit;
    $courseData->course_theory_hours = $request->course_theory_hours_edit;
    $courseData->brand_id = $request->brand_id_edit;
    $courseData->group_id = $request->group_id_edit;
    $courseData->job_roll_id      = json_encode($request->job_roll_id_edit);
    $courseData->tesbo_cousre_id  = json_encode($request->input('tcourse_id_edit', []));
    $courseData->pre_skill_set_id = json_encode($request->pre_skill_set_id_edit);
    $courseData->course_min_price = $request->course_min_price_edit;
    $courseData->course_max_price = $request->course_max_price_edit;
    $courseData->course_desc = $request->course_desc_edit;
    $courseData->course_goals = $request->course_goals_edit;
    $courseData->course_future_scope = $request->course_future_scope_edit;
    $courseData->updated_by = $request->user()->user_id;


    if ($request->hasFile('thumbnail_image_edit')) {
      $courseData->thumbnail = $this->uploadFile($request->file('thumbnail_image_edit'), 'course_thumbnail_image');
    } else {
      $courseData->thumbnail = $request->thumbnail_hidden;
    }
    if ($request->hasFile('attachment_edit')) {
      $courseData->attachment = $this->uploadFile($request->file('attachment_edit'), 'course_attachments');
    } else {
      $courseData->attachment = $request->attachment_hidden;
    }
    $saved = $courseData->save();

    if ($combined_course_chk_edit == 1) {
      $message = $saved ? 'Combined Course updated successfully!' : 'Could not update the Combined course!';
      $type = $saved ? 'success' : 'error';

      return redirect('courses/combined_course')->with('toastr', [
        'type' => $type,
        'message' => $message
      ]);
    } else {
      $message = $saved ? 'Course updated successfully!' : 'Could not update the course!';
      $type = $saved ? 'success' : 'error';

      return redirect('courses/manage_courses')->with('toastr', [
        'type' => $type,
        'message' => $message
      ]);
    }
  }
  //Course View
  public function course_view($id = '',Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageCoursesModel::where('sno', $decryptedValue)->where('status', 0)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    // ✅ Decode materials
    $materials = [];
    if (!empty($view->materials)) {
        $materials = json_decode($view->materials, true);
    }
    // Initialize arrays for chapters, sections, and topics
    $chapters = [];
    $sections = [];
    $topics = [];

    // Fetch unique chapters with their latest section based on maximum sno
    $chapter_views = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
      ->select('course_chapter_id', DB::raw('MAX(sno) as max_sno'))
      ->where('status', 0)
      ->groupBy('course_chapter_id')
      ->get();
      
   $languages = LanguageModel::pluck('name', 'iso_639_1')->toArray();
   foreach ($chapter_views as $chapter) {
    // Fetch the latest section for each chapter
    $latest_sections = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
        ->where('course_chapter_id', $chapter->course_chapter_id)
        ->select('session_id', DB::raw('MAX(sno) as max_sno'))
        ->where('status', 0)
        ->groupBy('session_id')
        ->get();
    
     foreach ($latest_sections as $sec) {
        // Fetch the latest topics for each section
        $latest_topics = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
            ->where('course_chapter_id', $chapter->course_chapter_id)
            ->where('session_id', $sec->session_id)
            ->where('status', 0)
            ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
            ->groupBy('topic_id')
            ->get();

        // ✅ Store topics under each section (only one place)
        $topics[$chapter->course_chapter_id]['sections'][$sec->session_id] = $latest_topics;
    }

        // ✅ Attach materials grouped by document_type_id
        $chapterMaterials = array_filter($materials, function ($mat) use ($chapter) {
            return $mat['chapter_id'] == $chapter->course_chapter_id;
        });
        if (!empty($chapterMaterials)) {
            $grouped = [];
            $count_type_5 = 0;
            $count_type_3 = 0;
        
            foreach ($chapterMaterials as $mat) {
                
                $mat['language_name'] = $languages[$mat['code_language']] ?? strtoupper($mat['code_language']);
                // Group by document_type_id
                $grouped[$mat['document_type_id']][] = $mat;
        
                // Count specific document types
                if ($mat['document_type_id'] == 5 && isset($mat['group_index'])) {
                    $count_type_5++;
                }
                if ($mat['document_type_id'] == 3 && isset($mat['block_index'])) {
                    $count_type_3++;
                }
            }
        
            // Attach to topic array
            $topics[$chapter->course_chapter_id]['count_type_5'] = $count_type_5;
            $topics[$chapter->course_chapter_id]['count_type_3'] = $count_type_3;
            $topics[$chapter->course_chapter_id]['materials'] = $grouped;
        }
    }

    // return $topics;
     $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $branch = BranchModel::where('sno', $branch_id)->first();
    $staff  = StaffModel::where('sno', $user_id)->where('department_id', 2)->first();
 
    $record = \DB::table('za_course_material')->where('sno', 1)->first();
    $data   = $record ? json_decode($record->course_materials, true) : [];
 
    if ($staff || $branch && $branch->branch_type == 2) {
 
      if ($branch && $branch->branch_type == 2) {
        // Franchise user
        $permissions = $data['franchise'] ?? [];
      } else {
        // Faculty staff user
        $permissions = $data['faculty_staffs'] ?? [];
      }
    } else {
      // Admin or other users → full access
      $permissions = ['Document', 'PPT', 'PDF', 'Lab Code', 'Audio', 'Video'];
    }
    // return $topics;
    return view('content.courses.course_view', [
      'view' => $view,
      'permissions' => $permissions,
      'topics' => $topics,
    ]);
  }
  // Combined Course List
  public function Combined_course_view($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageCoursesModel::where('sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    // Decode the JSON course IDs
    $course_ids = json_decode($view->tesbo_cousre_id, true);

    // Decode the JSON course IDs
    $course_ids = json_decode($view->tesbo_cousre_id, true);

    // Ensure it's an array and sort in ascending order
    if (is_array($course_ids)) {
      sort($course_ids); // Sorts the array in ascending order
    }

    // Initialize arrays for chapters, sections, and topics
    $topics = [];

    foreach ($course_ids as $course_id) {
      // Fetch unique chapters for each course ID
      $chapter_views = ManageCoursesSyllabusModel::where('course_id', $course_id)
        ->select('course_chapter_id', DB::raw('MAX(sno) as max_sno'))
        ->groupBy('course_chapter_id')
        ->get();

      foreach ($chapter_views as $chapter) {
        // Fetch the latest sections for each chapter
        $latest_sections = ManageCoursesSyllabusModel::where('course_id', $course_id)
          ->where('course_chapter_id', $chapter->course_chapter_id)
          ->select('session_id', DB::raw('MAX(sno) as max_sno'))
          ->where('status', 0)
          ->groupBy('session_id')
          ->get();

        foreach ($latest_sections as $sec) {
          // Fetch the latest topics for each section
          $latest_topics = ManageCoursesSyllabusModel::where('course_id', $course_id)
            ->where('course_chapter_id', $chapter->course_chapter_id)
            ->where('session_id', $sec->session_id)
            ->where('status', 0)
            ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
            ->groupBy('topic_id')
            ->get();

          // Store topics under each course ID, chapter, and section
          $topics[$course_id][$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
        }
      }
    }

    // return $topics;
    return view('content.courses.combained_course_view', [
      'view' => $view,
      'topics' => $topics,
    ]);
  }


  // Get Course Action Type Datas
  public function course_action_type_data($id = '')
  {
    // Assuming 'sno' is the primary key column name in za_course_action table
    $data = CourseActionModel::select(
      'za_course_action.*',
      'za_course_action_type.course_action_type_name',
      'za_course_action_type.category_file_upload',
      'za_course_action_type.category_text_field',
      'za_course_action_type.category_text_area',
      'za_course_action_type.category_text_link',
      'za_course_action_type.category AS cat_type',
      'za_course_action_type.sno as course_action_type_id'
    )
      ->join('za_course_action_type', 'za_course_action_type.sno', '=', 'za_course_action.course_action_type_id')
      ->where('za_course_action.sno', $id) // Corrected to use the correct table alias for 'sno'
      ->first();

    // Check if the course action is not found
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Course action not found.',
        'error_msg' => 'Course action with ID ' . $id . ' not found.',
        'data' => null
      ], 404);
    }

    // Return success response with data
    return response([
      'status' => 200,
      'message' => 'Course action found successfully.',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
  // Syllabus Add UI Page
  public function syllabus_add($id = '')
  {
    // return view( 'content.courses.syllabus_add' );
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageCoursesModel::where('sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    return view('content.courses.syllabus_add', [
      'view' => $view
    ]);
  }
  // Syllabus Add Insert
  public function Add_syllabus(Request $request)
  {
    //   return $request;
    $chapter_array = $request->chapter_name;
    $all_saved = true;
    foreach ($chapter_array as $key => $cha_list) {
      $course_chapter_id = $this->generateUniqueId_chapter('course_chapter_id', 'CCH');

      $course_sno = $request->course_sno;
      $chapter_name = $request->chapter_name[$key];
      $chapter_duration = $request->chapter_duration[$key];
      $knowledge_level_id = $request->knowledge_level_id[$key];
      $practical_hours = $request->practical_hours[$key];
      $course_chapter_theory_hours = $request->theory_hours[$key];

      // Handle sections within the chapter

      $sections = $request->section_name[$key];
      foreach ($sections as $skey => $section_name) {
        $session_id = $this->generateUniqueId_section('session_id', 'CS');
        $section_name = $request->section_name[$key][$skey];

        // Handle topics within the section
        foreach ($request->topic_name[$key][$skey] as $tkey => $topic_name) {
          $topic_name = $request->topic_name[$key][$skey][$tkey];
          $topic_desc = $request->topic_desc[$key][$skey][$tkey];

          $course_action_id = $request->course_action_id[$key][$skey][$tkey] ?? 0;
          $ca_type = $request->ca_type_hidden_[$key][$skey][$tkey] ?? '';
          $ca_desc = $request->ca_desc[$key][$skey][$tkey] ?? '';

          $ca_text_field = '';
          $ca_text_area = '';
          $ca_file_upload = '';
          $ca_text_link = '';
          switch ($ca_type) {
            case 1:
              // Text
              $ca_text_field = $request->action_type_text[$key][$skey][$tkey] ?? '';
              break;
            case 2:
              // Textarea
              $ca_text_area = $request->action_type_text[$key][$skey][$tkey] ?? '';
              break;
            case 3:
              // File Upload
              $attachment = $request->file('course_action_upload')[$key][$skey][$tkey] ?? null;

              if ($attachment) {
                $attachmentName = uniqid('CT') . '.' . $attachment->extension();
                $attachmentDestination = public_path('course_action_chapter_attachments');
                $attachment->move($attachmentDestination, $attachmentName);
                $ca_file_upload = $attachmentName;
              }
              break;
            case 4:
              // Link
              $ca_text_link = $request->action_type_link[$key][$skey][$tkey] ?? '';
              break;
            default:
              break;
          }

          // Create and save syllabus record
          $topic_id = $this->generateUniqueId_add('topic_id', 'CT');

          $syllabus = new ManageCoursesSyllabusModel;
          $syllabus->course_id = $course_sno;
          $syllabus->course_chapter_id = $course_chapter_id;
          $syllabus->course_chapter_name = ucfirst($chapter_name);
          $syllabus->course_chapter_duration = $chapter_duration;
          $syllabus->course_chapter_practical_hours = $practical_hours;
          $syllabus->course_chapter_theory_hours = $course_chapter_theory_hours;
          $syllabus->knowledge_level_id = $knowledge_level_id;
          $syllabus->session_id = $session_id;
          $syllabus->topic_id = $topic_id;
          $syllabus->course_chapter_description = $topic_desc;
          $syllabus->session_name = ucfirst($section_name);
          $syllabus->topic_name = ucfirst($topic_name);
          $syllabus->course_action_id = $course_action_id;
          $syllabus->ca_file_upload = $ca_file_upload;
          $syllabus->ca_text_field = $ca_text_field;
          $syllabus->ca_text_area = $ca_text_area;
          $syllabus->ca_text_link = $ca_text_link;
          $syllabus->ca_desc = $ca_desc;
          $syllabus->created_by = $request->user()->user_id;
          $syllabus->updated_by = $request->user()->user_id;
          $syllabus->branch_id = $request->user()->branch_id;
          // return $syllabus;
          // Save the syllabus record
          if (!$syllabus->save()) {
            $all_saved = false;
          }
        }
      }
    }

    if ($all_saved) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Course Chapter added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Course Chapter !'
      ]);
    }
    // return $syllabus;
    // return redirect()->back();
    return redirect('courses/manage_courses');
  }
  // Syllabus edit UI Page
  public function syllabus_edit($id = '')
  {
    // Initialize helper class for encryption/decryption
    $helper = new \App\Helpers\Helpers();

    // Decrypt the ID
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $course = ManageCoursesModel::where('sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$course) {
      return redirect()->back()->with('error', 'Course View not found');
    }

    // Initialize arrays for chapters, sections, and topics
    $chapters = [];
    $sections = [];
    $topics = [];

    // Fetch unique chapters with their latest section based on maximum sno
    $chapter_views = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
      ->select('course_chapter_id', DB::raw('MAX(sno) as max_sno'))
      ->groupBy('course_chapter_id')
      ->orderBy('sno','ASC')
      ->get();

    foreach ($chapter_views as $chapter) {
      // Fetch the latest section for each chapter
     $latest_sections = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
        ->where('course_chapter_id', $chapter->course_chapter_id)
        ->select('session_id', DB::raw('MAX(sno) as max_sno'))
        ->where('status', 0)
        ->groupBy('session_id')
        ->orderBy('sno','ASC')
        ->get();

      foreach ($latest_sections as $sec) {
        // Fetch the latest topics for each section
        $latest_topics = ManageCoursesSyllabusModel::where('course_id', $decryptedValue)
          ->where('course_chapter_id', $chapter->course_chapter_id)
          ->where('session_id', $sec->session_id)
          ->where('status', 0)
          ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
          ->groupBy('topic_id')
          ->orderBy('sno','ASC')
          ->get();

        // Store topics under each section
        $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
      }
    }

    return view('content.courses.syllabus_edit', [
      'view' => $course,
      'chapters' => $topics,
    ]);
  }
  // Syllabus Update
  public function Update_syllabus(Request $request)
  {

    //   return $request;
    $chapter_array = $request->chapter_name;
    $all_saved = true;
    $all_updated = true;
    
    foreach ($chapter_array as $key => $chapter_name) {
      $course_sno = $request->course_sno;
      $chapter_id_hidden = $request->chapter_id_hidden[$key];
      $chapter_name = $request->chapter_name[$key];
      $chapter_duration = $request->chapter_duration[$key];
      $knowledge_level_id = $request->knowledge_level_id[$key];
      $practical_hours = $request->practical_hours[$key];
      $course_chapter_theory_hours = $request->theory_hours[$key];

      if ($chapter_id_hidden != '') {
        $course_chapter_id = $chapter_id_hidden;
      } else {
        $course_chapter_id = $this->generateUniqueId_chapter('course_chapter_id', 'CCH');
      }



      $sections = $request->section_name[$key];

      foreach ($sections as $skey => $section_name) {
        $section_name = $request->section_name[$key][$skey];
        $section_section_id_hidden = $request->section_id_hidden[$key][$skey];

        if ($section_section_id_hidden != '') {
          $session_id = $section_section_id_hidden;
        } else {
          $session_id = $this->generateUniqueId_section('session_id', 'CS');
          
        //   return $session_id;
        }
        
        
        
        
        

        foreach ($request->topic_name[$key][$skey] as $tkey => $topic_name) {
          $topic_name = $request->topic_name[$key][$skey][$tkey];
          $topic_desc = $request->topic_desc[$key][$skey][$tkey];
          $course_action_id = $request->course_action_id[$key][$skey][$tkey] ?? 0;
          $ca_type = $request->ca_type_hidden_[$key][$skey][$tkey] ?? '';
          $ca_desc = $request->ca_desc[$key][$skey][$tkey] ?? '';

          // Initialize action type variables
          $ca_text_field = '';
          $ca_text_area = '';
          $ca_file_upload = '';
          $ca_text_link = '';

          switch ($ca_type) {
            case 1:
              $ca_text_field = $request->action_type_text[$key][$skey][$tkey] ?? '';
              break;
            case 2:
              $ca_text_area = $request->action_type_text[$key][$skey][$tkey] ?? '';
              break;
            case 3:
              $attachment = $request->file('course_action_upload')[$key][$skey][$tkey] ?? null;
              $course_action_upload_hidden = $request->course_action_upload_hidden[$key][$skey][$tkey] ?? '';

              if ($attachment) {
                $attachmentName = uniqid('CT') . '.' . $attachment->extension();
                $attachmentDestination = public_path('course_action_chapter_attachments');
                $attachment->move($attachmentDestination, $attachmentName);
                $ca_file_upload = $attachmentName;
              } else {
                $ca_file_upload = $course_action_upload_hidden;
              }
              break;
            case 4:
              $ca_text_link = $request->action_type_link[$key][$skey][$tkey] ?? '';
              break;
            default:
              break;
          }

          $edit_id = $request->edit_id[$key][$skey][$tkey];

          if ($edit_id != '') {
            // Update syllabus record
            $syllabus_update = ManageCoursesSyllabusModel::where('sno', $edit_id)
              ->where('course_id', $course_sno)
              ->first();

            if ($syllabus_update) {
              $syllabus_update->course_chapter_name = ucfirst($chapter_name);
              //   $syllabus_update->course_chapter_id = $course_chapter_id;
              //   $syllabus_update->session_id = $session_id;
              $syllabus_update->course_chapter_duration = $chapter_duration;
              $syllabus_update->course_chapter_practical_hours = $practical_hours;
              $syllabus_update->course_chapter_theory_hours = $course_chapter_theory_hours;
              $syllabus_update->knowledge_level_id = $knowledge_level_id;
              $syllabus_update->course_chapter_description = $topic_desc;
              $syllabus_update->session_name = ucfirst($section_name);
              $syllabus_update->topic_name = ucfirst($topic_name);
              $syllabus_update->course_action_id = $course_action_id;
              $syllabus_update->ca_file_upload = $ca_file_upload;
              $syllabus_update->ca_text_field = $ca_text_field;
              $syllabus_update->ca_text_area = $ca_text_area;
              $syllabus_update->ca_text_link = $ca_text_link;
              $syllabus_update->ca_desc = $ca_desc;
              $syllabus_update->updated_by = $request->user()->user_id;

              // dd($syllabus_update);
              if (!$syllabus_update->save()) {
                $all_updated = false;
              }
            } else {
              $all_updated = false;
            }
          } else {
            // Create new syllabus record
            $syllabus = new ManageCoursesSyllabusModel;
            $syllabus->course_id = $course_sno;
            $syllabus->course_chapter_id = $course_chapter_id;
            $syllabus->course_chapter_name = ucfirst($chapter_name);
            $syllabus->course_chapter_duration = $chapter_duration;
            $syllabus->course_chapter_practical_hours = $practical_hours;
            $syllabus->course_chapter_theory_hours = $course_chapter_theory_hours;
            $syllabus->knowledge_level_id = $knowledge_level_id;
            $syllabus->topic_id = $this->generateUniqueId('topic_id', 'CT');
            $syllabus->course_chapter_description = $topic_desc;
            $syllabus->session_id = $session_id;
            $syllabus->session_name = ucfirst($section_name);
            $syllabus->topic_name = ucfirst($topic_name);
            $syllabus->course_action_id = $course_action_id;
            $syllabus->ca_file_upload = $ca_file_upload;
            $syllabus->ca_text_field = $ca_text_field;
            $syllabus->ca_text_area = $ca_text_area;
            $syllabus->ca_text_link = $ca_text_link;
            $syllabus->ca_desc = $ca_desc;
            $syllabus->created_by = $request->user()->user_id;
            $syllabus->updated_by = $request->user()->user_id;
            $syllabus->branch_id = $request->user()->branch_id;

            if (!$syllabus->save()) {
              $all_saved = false;
            }
          }
        }
      }
    }
    // return  $syllabus;
    if ($all_saved || $all_updated) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Course Chapter updated successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Failed to update Course Chapter.'
      ]);
    }

    return redirect('courses/manage_courses');
  }
  //Course Status Change
  public function Status($id, Request $request)
  {

    $upd_ManageCoursesModel =  ManageCoursesModel::where('sno', $id)->first();
    $upd_ManageCoursesModel->status = $request->input('status', 0);
    $upd_ManageCoursesModel->update();
    if ($upd_ManageCoursesModel) {
      return response([
        'status'    => 200,
        'message'   => 'Course  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Course  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Course  Status!',
        'error_msg' => 'Could not, update  Course  Status!',
        'data'      => null,
      ], 200);
    }
  }
  //Course Delete
  public function Delete($id)
  {
    $upd_ManageCoursesModel =  ManageCoursesModel::where('sno', $id)->first();
    $upd_ManageCoursesModel->status  = 2;
    $upd_ManageCoursesModel->Update();
    if ($upd_ManageCoursesModel) {
      return response([
        'status'    => 200,
        'message'   => 'Course  Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Course !',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  //Course Chapter Delete
  public function Chapter_Delete($id)
  {
    // Fetch the course chapter ID based on the provided ID
    $dataGet = ManageCoursesSyllabusModel::select('course_chapter_id')->where('sno', $id)->first();
    $courseChapterId = $dataGet->course_chapter_id ?? null;

    // If no course chapter ID found, return an error response
    if (!$courseChapterId) {
      return response()->json([
        'status' => 404,
        'message' => 'Course Chapter not found!',
        'error_msg' => null,
        'data' => null,
      ], 404);
    }

    // Update all records with the same course chapter ID
    $updatedCount = ManageCoursesSyllabusModel::where('course_chapter_id', $courseChapterId)
      ->update(['status' => 2]);

    // Check if any records were updated
    if ($updatedCount > 0) {
      return response()->json([
        'status' => 200,
        'message' => 'Course Chapter(s) successfully deleted!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Could not delete any Course Chapters!',
        'error_msg' => null,
        'data' => null,
      ], 404);
    }
  }
  //Course Section Delete
  public function Section_Delete($id)
  {
    // Fetch the specific record to get the session_id
    $data_get = ManageCoursesSyllabusModel::select('*')->where('sno', $id)->first();

    // Check if the record exists
    if (!$data_get) {
      return response([
        'status'    => 404,
        'message'   => 'Course Chapter not found!',
        'error_msg' => null,
        'data'      => null,
      ], 404);
    }

    // Get the session_id from the fetched record
    $ses = $data_get->session_id;

    // Update the status of all records with the same session_id to 2
    $updatedRows = ManageCoursesSyllabusModel::where('session_id', $ses)->update(['status' => 2]);

    // Check if any rows were updated
    if ($updatedRows > 0) {
      return response([
        'status'    => 200,
        'message'   => 'All Course Chapters for the session have been successfully ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 404,
        'message'   => 'No Course Chapters found for the specified session!',
        'error_msg' => null,
        'data'      => null,
      ], 404);
    }
  }
  // Course Topic Delete
  public function Topic_Delete($id)
  {
    $data_get = ManageCoursesSyllabusModel::select('topic_id')->where('sno', $id)->first();
    $cha = $data_get->topic_id ?? '';
    $upd_ManageCoursesModel =  ManageCoursesSyllabusModel::where('topic_id', $cha)->first();
    $upd_ManageCoursesModel->status  = 2;
    $upd_ManageCoursesModel->Update();
    if ($upd_ManageCoursesModel) {
      return response([
        'status'    => 200,
        'message'   => 'Course Chapter Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 404,
        'message'   => 'Could not delete Course Chapter!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  // GET COURSE KEY TAGS
  public function getCourse_keytag($id)
  {
    $data = ManageCoursesModel::where('sno', $id)->first();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

  // Pubic Function end
  // private Function Start
  private function generateUniqueId_chapter($column, $prefix)
  {
    // Fetch the last entry for the given column
    // $lastEntry = ManageCoursesSyllabusModel::where($column, 'LIKE', "{$prefix}-%")->orderBy($column, 'desc')->first();
    // $lastEntry = ManageCoursesSyllabusModel::where($column, 'LIKE', "{$prefix}-%")
    //   ->orderByRaw("CAST(SUBSTRING_INDEX($column, '-', -1) AS UNSIGNED) DESC")
    //   ->first();
      
      $lastEntry = ManageCoursesSyllabusModel::select(
        $column,
        DB::raw("CAST(SUBSTRING_INDEX($column, '-', -1) AS UNSIGNED) AS course_number"),
        DB::raw("SUBSTRING_INDEX($column, '/', -1) AS year")
    )
    ->where($column, 'LIKE', "{$prefix}-%")
    ->orderByRaw("CAST(SUBSTRING_INDEX($column, '/', -1) AS UNSIGNED) DESC")  // Order by year
    ->orderByRaw("CAST(SUBSTRING_INDEX($column, '-', -1) AS UNSIGNED) DESC")  // If you want to tie-break with course number
    ->first();

    // Get the current year in two-digit format
    $year = date('y');

    // If no entry exists, generate the first ID
    if (!$lastEntry) {
      return "{$prefix}-0001/{$year}";
    }

    // Extract the last course_chapter_id from the table
    $lastId = $lastEntry->$column;

    // Split the ID into parts (e.g., 'CCH-0070/24' -> ['CCH-0070', '24'])
    $parts = explode('/', $lastId);

    // Ensure the year part is correct
    if (isset($parts[1]) && $parts[1] == $year) {
      // Extract the numeric part from the lastId (e.g., 'CCH-0070' -> '0070')
      $number = preg_replace('/[^0-9]/', '', $parts[0]);

      // Increment the numeric part
      $nextNumber = (int)$number + 1;

      // Format the new number to be 4 digits (e.g., 0071)
      $formattedNumber = sprintf('%04d', $nextNumber);

      // Return the new ID with the prefix and current year
      return "{$prefix}-{$formattedNumber}/{$year}";
    } else {
      // If the year has changed or parts are invalid, start from 0001 for the new year
      return "{$prefix}-0001/{$year}";
    }
  }
 private function generateUniqueId_section($column, $prefix)
{
    $year = date('y'); // Current 2-digit year

    $lastEntry = ManageCoursesSyllabusModel::select(
        $column,
        DB::raw("CAST(SUBSTRING_INDEX(SUBSTRING_INDEX($column, '/', 1), '-', -1) AS UNSIGNED) AS course_number"),
        DB::raw("CAST(SUBSTRING_INDEX($column, '/', -1) AS UNSIGNED) AS year_part")
    )
    ->where($column, 'LIKE', "{$prefix}-%")
    ->orderByRaw("year_part DESC")
    ->orderByRaw("course_number DESC")
    ->first();

    if (!$lastEntry) {
        return "{$prefix}-0001/{$year}";
    }

    // Extract existing year from the last entry
    $existingYear = $lastEntry->year_part;

    if ($existingYear == $year) {
        $nextNumber = $lastEntry->course_number + 1;
        $formattedNumber = sprintf('%04d', $nextNumber);
        return "{$prefix}-{$formattedNumber}/{$year}";
    } else {
        // Reset numbering for new year
        return "{$prefix}-0001/{$year}";
    }
}

  private function generateUniqueId_add($column, $prefix)
  {
    $lastEntry = ManageCoursesSyllabusModel::orderBy('sno', 'desc')->first();


    $year = date('y');
    if (!$lastEntry) {
      return "{$prefix}-0001/{$year}";
    }

    $lastId = $lastEntry->$column;
    $parts = explode('/', $lastId);
    $number = preg_replace('/[^0-9]/', '', $parts[0]);
    $nextNumber = (int)$number + 1;
    $formattedNumber = sprintf('%04d', $nextNumber);

    return "{$prefix}-{$formattedNumber}/{$year}";
  }
  private function generateUniqueId($column, $prefix)
  {
    $lastEntry = ManageCoursesSyllabusModel::orderBy('sno', 'desc')->first();
    $year = date('y');

    if (!$lastEntry) {
      return "{$prefix}-0001/{$year}";
    }

    $lastId = $lastEntry->$column;
    $parts = explode('/', $lastId);
    $number = preg_replace('/[^0-9]/', '', $parts[0]);
    $nextNumber = (int)$number + 1;
    $formattedNumber = sprintf('%04d', $nextNumber);

    return "{$prefix}-{$formattedNumber}/{$year}";
  }
  private function uploadFile($file, $destination)
  {
    if ($file) {
      $fileName = idate('B') . rand(1, 50) . '.' . $file->extension();
      $destinationPath = public_path($destination);
      $file->move($destinationPath, $fileName);
      return $fileName;
    }
    return '';
  }
public function courseChapter($id)
{
    $chapters = ManageCoursesSyllabusModel::select('course_chapter_id', 'course_chapter_name')
        ->where('course_id', $id)
        ->where('status', 0) // fixed typo: 'staus' → 'status'
        ->groupBy('course_chapter_id', 'course_chapter_name')
        ->get();

    if ($chapters->count() > 0) {
        return response()->json([
            'status' => 200,
            'data' => $chapters
        ]);
    } else {
        return response()->json([
            'status' => 404,
            'data' => []
        ]);
    }
}


//  public function uploadMaterial(Request $request)
// {
//     try {
//         $validated = $request->validate([
//             'file_upload'       => 'required',
//             'upload_course_id'  => 'required|integer',
//             'chapter_id'        => 'required|string',
//         ]);
//     } catch (ValidationException $e) {
//         return response()->json([
//             'success' => false,
//             'message' => $e->errors()
//         ], 422);
//     }

//     $courseId       = $validated['upload_course_id'];
//     $chapterId      = $validated['chapter_id'];
//     $documentTypeId = $validated['document_type_id'];

//     // Fetch course name if needed
//     $course_name = DB::table('za_course')->where('sno', $courseId)->value('course_name');

//     $baseDirectory     = public_path("course_materials/{$courseId}");
//     $materialDirectory = "{$baseDirectory}/{$documentTypeId}";

//     if (!file_exists($materialDirectory)) {
//         mkdir($materialDirectory, 0755, true);
//     }

//     $files = $request->file('file_upload');
//     $storedFiles = [];

//     // Get existing JSON data from DB
//     $existingMaterials = DB::table('za_course')->where('sno', $courseId)->value('materials');
//     $existingMaterials = $existingMaterials ? json_decode($existingMaterials, true) : [];

//     foreach ($files as $file) {
//         $originalName = $file->getClientOriginalName();
//         $newFilename  = uniqid('material_') . "." . $file->getClientOriginalExtension();

//         $file->move($materialDirectory, $newFilename);

//         // Build JSON entry for this material
//         $newMaterial = [
//             'course_id'        => $courseId,
//             'chapter_id'       => $chapterId,
//             'document_type_id' => $documentTypeId, 
//             'material_name'    => $newFilename,  // maybe labcode file not come text ,language ,title 
//             'original_name'    => $originalName
//         ];
//         // here we neeed to add newly for title,language,textfor lab code

//         // Check if same course+chapter+document_type already exists → update it
//         $updated = false;
//         foreach ($existingMaterials as $key => $material) {
//             if (
//                 $material['course_id'] == $courseId &&
//                 $material['chapter_id'] == $chapterId &&
//                 $material['document_type_id'] == $documentTypeId
//             ) {
//                 // Delete old file from public folder if exists
//                 $oldFilePath = $materialDirectory . '/' . $material['material_name'];
//                 if (file_exists($oldFilePath)) {
//                     unlink($oldFilePath);
//                 }
        
//                 // Replace with new file
//                 $existingMaterials[$key] = $newMaterial;
//                 $updated = true;
//                 break;
//             }
//         }
//         // If not found → push as new
//         if (!$updated) {
//             $existingMaterials[] = $newMaterial;
//         }

//         $storedFiles[] = $newMaterial;
//     }

//     // Save back to DB
//     $successUpload = DB::table('za_course')
//         ->where('sno', $courseId)
//         ->update(['materials' => json_encode($existingMaterials)]);

//     if ($successUpload) {
//         return response()->json([
//             'success' => true,
//             'message' => 'Files uploaded successfully.',
//             'stored_files' => $storedFiles
//         ]);
//     } else {
//         return response()->json([
//             'success' => false,
//             'message' => 'Files uploading failed.'
//         ]);
//     }
// }


// public function uploadMaterial(Request $request)
// {
//     $materialType = $request->input('document_type_id');

//     try {
//         if ($materialType == 3) { // Lab Code
//             $validated = $request->validate([
//                 'upload_course_id'  => 'required|integer',
//                 'chapter_id'        => 'required|string',
//                 'code_title'        => 'required|string|max:255',
//                 'code_language'     => 'required|string|max:100',
//                 'code_content'      => 'required|string',
//             ]);
//         } else { // File-based
//             $validated = $request->validate([
//                 'file_upload'       => 'required',
//                 'upload_course_id'  => 'required|integer',
//                 'chapter_id'        => 'required|string',
//             ]);
//         }
//     } catch (ValidationException $e) {
//         return response()->json([
//             'success' => false,
//             'message' => $e->errors()
//         ], 422);
//     }

//     $courseId       = $validated['upload_course_id'];
//     $chapterId      = $validated['chapter_id'];
//     $documentTypeId = $request->input('document_type_id');

//     // Load existing
//     $existingMaterials = DB::table('za_course')->where('sno', $courseId)->value('materials');
//     $existingMaterials = $existingMaterials ? json_decode($existingMaterials, true) : [];

//     // Helper function: replace or add
//     $replaceOrAdd = function (&$materials, $newMaterial) use ($chapterId, $documentTypeId) {
//         $found = false;
//         foreach ($materials as $key => $mat) {
//             if (
//                 isset($mat['chapter_id'], $mat['document_type_id']) &&
//                 $mat['chapter_id'] == $chapterId &&
//                 $mat['document_type_id'] == $documentTypeId
//             ) {
//                 $materials[$key] = $newMaterial;
//                 $found = true;
//                 break;
//             }
//         }
//         if (!$found) {
//             $materials[] = $newMaterial;
//         }
//     };

//     if ($materialType == 3) {
//         // Lab Code Entry
//         $newMaterial = [
//             'course_id'        => $courseId,
//             'chapter_id'       => $chapterId,
//             'document_type_id' => $documentTypeId,
//             'material_name'    => '', // empty for code
//             'original_name'    => '', // empty for code
//             'code_title'       => $validated['code_title'],
//             'code_language'    => $validated['code_language'],
//             'code_content'     => $validated['code_content'],
//         ];

//         $replaceOrAdd($existingMaterials, $newMaterial);

//     } else {
//         // File Uploads
//         $files = (array) $request->file('file_upload'); // cast safe

//         foreach ($files as $file) {
//             $originalName = $file->getClientOriginalName();
//             $newFilename  = uniqid('material_') . "." . $file->getClientOriginalExtension();

//             $baseDirectory     = public_path("course_materials/{$courseId}");
//             $materialDirectory = "{$baseDirectory}/{$documentTypeId}";
//             if (!file_exists($materialDirectory)) {
//                 mkdir($materialDirectory, 0755, true);
//             }
//             $file->move($materialDirectory, $newFilename);

//             $newMaterial = [
//                 'course_id'        => $courseId,
//                 'chapter_id'       => $chapterId,
//                 'document_type_id' => $documentTypeId,
//                 'material_name'    => $newFilename,
//                 'original_name'    => $originalName,
//                 'code_title'       => '', // empty for file
//                 'code_language'    => '',
//                 'code_content'     => '',
//             ];

//             $replaceOrAdd($existingMaterials, $newMaterial);
//         }
//     }

//     // Save
//     $successUpload = DB::table('za_course')
//         ->where('sno', $courseId)
//         ->update(['materials' => json_encode($existingMaterials)]);

//     return response()->json([
//         'success' => (bool)$successUpload,
//         'message' => $successUpload ? 'Uploaded successfully.' : 'Failed to upload.'
//     ]);
// }


//deep funtion
public function uploadMaterial(Request $request)
{
    $materialType = $request->input('document_type_id');

    try {
        // Common validation for all types
        $commonRules = [
            'upload_course_id'  => 'required|integer',
            'chapter_id'        => 'required|string',
        ];

        switch ($materialType) {
           case '3': // Lab Code
                $validated = $request->validate(array_merge($commonRules, [
                    'code_title'     => 'required|array|min:1',
                    'code_title.*'   => 'required|string|max:255',
                    'code_language'  => 'required|array|min:1',
                    'code_language.*'=> 'required|string|max:100',
                    'code_content'   => 'required|array|min:1',
                    'code_content.*' => 'required|string',
                ]));
                break;

            case '5': // Audio
                $validated = $request->validate(array_merge($commonRules, [
                    'audio_languages' => 'required|array|min:1',
                    'audio_languages.*' => 'required|string|max:10',
                    'audio_files'     => 'required|array|min:1',
                    'audio_files.*'   => 'required|array|min:1',
                    'audio_files.*.*' => 'required|file', // 10MB max
                ]));
                break;

            default: // File-based (Document, Presentation, PDF, Video)
                $validated = $request->validate(array_merge($commonRules, [
                    'file_upload'     => 'required|array|min:1',
                    'file_upload.*'   => 'required|file', // 20MB max
                ]));
                
                // Additional validation for specific file types
                if ($materialType == '6') { // Video
                    $request->validate([
                        'file_upload.*' => 'mimes:mp4,avi,mov,wmv'
                    ]);
                } elseif ($materialType == '4') { // PDF
                    $request->validate([
                        'file_upload.*' => 'mimes:pdf'
                    ]);
                }
                break;
        }
    } catch (ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => $e->errors()
        ], 422);
    }

    $courseId       = $validated['upload_course_id'];
    $chapterId      = $validated['chapter_id'];
    $documentTypeId = $request->input('document_type_id');

    // Load existing materials
    $existingMaterials = DB::table('za_course')->where('sno', $courseId)->value('materials');
    $existingMaterials = $existingMaterials ? json_decode($existingMaterials, true) : [];

    // Remove existing materials of the same type for this chapter
    $existingMaterials = array_filter($existingMaterials, function($material) use ($chapterId, $documentTypeId) {
        return !(isset($material['chapter_id'], $material['document_type_id']) && 
                $material['chapter_id'] == $chapterId && 
                $material['document_type_id'] == $documentTypeId);
    });

    $newMaterials = [];

    switch ($materialType) {
       case '3': // Lab Code - Multiple blocks
        $titles = $request->input('code_title', []);    // Changed from code_titles
        $languages = $request->input('code_language', []); // Changed from code_languages  
        $contents = $request->input('code_content', []);   // Changed from code_contents
    
        foreach ($titles as $index => $title) {
            if (isset($languages[$index]) && isset($contents[$index])) {
                $newMaterials[] = [
                    'course_id'        => $courseId,
                    'chapter_id'       => $chapterId,
                    'document_type_id' => $documentTypeId,
                    'material_name'    => '', // empty for code
                    'original_name'    => '', // empty for code
                    'code_title'       => $title,
                    'code_language'    => $languages[$index],
                    'code_content'     => $contents[$index],
                    'created_at'       => now()->toDateTimeString(),
                    'block_index'      => $index, // To maintain order
                ];
            }
        }
        break;

        case '5': // Audio - Multiple groups with multiple files
            $audioLanguages = $request->input('audio_languages', []);
            $audioFiles = $request->files->get('audio_files', []);

            foreach ($audioLanguages as $groupIndex => $language) {
                if (isset($audioFiles[$groupIndex])) {
                    foreach ($audioFiles[$groupIndex] as $fileIndex => $file) {
                        $originalName = $file->getClientOriginalName();
                        $newFilename  = uniqid('audio_') . "." . $file->getClientOriginalExtension();

                        $baseDirectory     = public_path("course_materials/{$courseId}");
                        $materialDirectory = "{$baseDirectory}/{$documentTypeId}";
                        if (!file_exists($materialDirectory)) {
                            mkdir($materialDirectory, 0755, true);
                        }
                        $file->move($materialDirectory, $newFilename);

                        $newMaterials[] = [
                            'course_id'        => $courseId,
                            'chapter_id'       => $chapterId,
                            'document_type_id' => $documentTypeId,
                            'material_name'    => $newFilename,
                            'original_name'    => $originalName,
                            'code_title'       => '', // empty for audio
                            'code_language'    => $language,
                            'code_content'     => '', // empty for audio
                            'created_at'       => now()->toDateTimeString(),
                            'group_index'      => $groupIndex, // To group by language
                            'file_index'       => $fileIndex, // To maintain order within group
                        ];
                    }
                }
            }
            break;

        default: // File-based - Multiple files
            $files = $request->file('file_upload', []);

            foreach ($files as $index => $file) {
                $originalName = $file->getClientOriginalName();
                $newFilename  = uniqid('material_') . "." . $file->getClientOriginalExtension();

                $baseDirectory     = public_path("course_materials/{$courseId}");
                $materialDirectory = "{$baseDirectory}/{$documentTypeId}";
                if (!file_exists($materialDirectory)) {
                    mkdir($materialDirectory, 0755, true);
                }
                $file->move($materialDirectory, $newFilename);

                $newMaterials[] = [
                    'course_id'        => $courseId,
                    'chapter_id'       => $chapterId,
                    'document_type_id' => $documentTypeId,
                    'material_name'    => $newFilename,
                    'original_name'    => $originalName,
                    'code_title'       => '', // empty for file
                    'code_language'    => '', // empty for file
                    'code_content'     => '', // empty for file
                    'created_at'       => now()->toDateTimeString(),
                    'file_index'       => $index,
                ];
            }
            break;
    }

    // Merge new materials with existing ones
    $allMaterials = array_merge($existingMaterials, $newMaterials);

    // Save to database
    $successUpload = DB::table('za_course')
        ->where('sno', $courseId)
        ->update(['materials' => json_encode($allMaterials)]);

    return response()->json([
        'success' => (bool)$successUpload,
        'message' => $successUpload ? 'Uploaded successfully.' : 'Failed to upload.',
        'count'   => count($newMaterials),
        'materials' => $newMaterials
    ]);
}


// public function viewFile($encrypted)
//   {
//     try {
//       $data = Crypt::decrypt($encrypted);
//     } catch (\Exception $e) {
//       abort(404, 'Invalid file');
//     }
 
//     $fileUrl = url("course_materials/{$data['course_id']}/{$data['doc_type']}/{$data['file_name']}");
//     $type = strtolower($data['type']);
 
//     if ($type === 'pdf') {
//       $viewerUrl = asset("pdfjs/web/viewer.html") . "?file=" . urlencode($fileUrl) . "#toolbar=0&download=false&print=false";
//       return view('content.courses.course_file_viewr', [
//         'viewerUrl' => $viewerUrl,
//         'title' => strtoupper($type) . ' Viewer'
//       ]);
//     } elseif (in_array($type, ['doc'])) {
//       $viewerUrl = urlencode($fileUrl);
//       return view('content.courses.course_file_doc', [
//         'viewerUrl' => $viewerUrl,
//         'title' => strtoupper($type) . ' Viewer'
//       ]);
//     } elseif (in_array($type, ['ppt'])) {
//       $viewerUrl = "https://view.officeapps.live.com/op/embed.aspx?src=" . urlencode($fileUrl);
//       return view('content.courses.course_file_ppt_doc', [
//         'viewerUrl' => $viewerUrl,
//         'title' => strtoupper($type) . ' Viewer'
//       ]);
//     } else {
//       abort(404, 'File type not supported');
//     }
//   }

    public function viewFile($encrypted)
  {
    try {
      $data = Crypt::decrypt($encrypted);
    } catch (\Exception $e) {
      abort(404, 'Invalid file');
    }

    $courseId = $data['course_id'];
    $docType = $data['doc_type'];
    $fileName = $data['file_name'];
    $type = strtolower($data['type']);

    // Wasabi object path
    $wasabiPath = "course_materials/{$courseId}/{$docType}/{$fileName}";

    // Check file exists in Wasabi
    if (!Storage::disk('wasabi')->exists($wasabiPath)) {
      abort(404, 'File not found in Wasabi');
    }

    // Temporary URL - valid for 30 minutes
    $fileUrl = Storage::disk('wasabi')->temporaryUrl(
      $wasabiPath,
      now()->addMinutes(30)
    );

      if ($type === 'pdf') {
          $wasabiPath = "course_materials/{$courseId}/{$docType}/{$fileName}";

          if (!Storage::disk('wasabi')->exists($wasabiPath)) {
              abort(404, 'File not found');
          }

          $fileUrl = Storage::disk('wasabi')->temporaryUrl($wasabiPath, now()->addHours(6));

          $viewerUrl = "https://docs.google.com/viewer?url=" . urlencode($fileUrl) . "&embedded=true";

          return view('content.courses.course_file_ppt_doc', [
              'viewerUrl' => $viewerUrl,
              'title'     => 'PDF Viewer',
          ]);
      } elseif (in_array($type, ['doc', 'docx'])) {
        


      $viewerUrl = urlencode($fileUrl);

      return view('content.courses.course_file_doc', [
        'viewerUrl' => $viewerUrl,
        'title' => strtoupper($type) . ' Viewer'
      ]);
    } elseif (in_array($type, ['ppt', 'pptx'])) {

      $viewerUrl =
        "https://view.officeapps.live.com/op/embed.aspx?src="
        . urlencode($fileUrl);

      return view('content.courses.course_file_ppt_doc', [
        'viewerUrl' => $viewerUrl,
        'title' => strtoupper($type) . ' Viewer'
      ]);
    } else {
      abort(404, 'File type not supported');
    }
  }
  
 public function streamPdf($encrypted)
{
    try {
        $data = Crypt::decrypt($encrypted);
    } catch (\Exception $e) {
        abort(404, 'Invalid file');
    }

    $courseId = $data['course_id'];
    $docType  = $data['doc_type'];
    $fileName = $data['file_name'];

    $wasabiPath = "course_materials/{$courseId}/{$docType}/{$fileName}";

    if (!Storage::disk('wasabi')->exists($wasabiPath)) {
        abort(404, 'File not found');
    }

    // Stream file through Laravel (bypasses CORS)
    return response()->streamDownload(function () use ($wasabiPath) {
        $stream = Storage::disk('wasabi')->readStream($wasabiPath);
        fpassthru($stream);
        if (is_resource($stream)) {
            fclose($stream);
        }
    }, null, [
        'Content-Type'        => 'application/pdf',
        'Content-Disposition' => 'inline',
        'Accept-Ranges'       => 'bytes',
        'Cache-Control'       => 'private, max-age=3600',
    ]);
}

public function streamAudio($courseId, $fileName)
{
    $wasabiPath = "course_materials/{$courseId}/5/{$fileName}";

    if (!Storage::disk('wasabi')->exists($wasabiPath)) {
        abort(404, 'Audio file not found: ' . $wasabiPath);
    }

    return redirect(Storage::disk('wasabi')->temporaryUrl(
        $wasabiPath,
        now()->addMinutes(30)
    ));
}

  
public function viewLab($encrypted)
{
    try {
        $data = Crypt::decrypt($encrypted);
    } catch (\Exception $e) {
        abort(404, 'Invalid File');
    }
    
    $type = $data['type'] ?? 'file';
    
    if ($type === 'code') {
        // Lab code: no file_name
        $courseId = $data['course_id'] ?? null;
        $chapterId = $data['chapter_id'] ?? null;
        $documentTypeId = $data['doc_type'] ?? ($data['document_type_id'] ?? null);
    
        $materialsJson = DB::table('za_course')->where('sno', $courseId)->value('materials');
        $materials = $materialsJson ? json_decode($materialsJson, true) : [];
        
        // DEBUG: Log all materials and filter criteria
        \Log::info('All materials count: ' . count($materials));
        \Log::info('Filter criteria - chapterId: ' . $chapterId . ', documentTypeId: ' . $documentTypeId);
        
        // Filter only lab codes
        $labCodes = array_filter($materials, function ($mat) use ($chapterId, $documentTypeId) {
            $isMatch = isset($mat['chapter_id'], $mat['document_type_id'], $mat['code_content']) &&
                       (string)$mat['chapter_id'] === (string)$chapterId &&
                       (string)$mat['document_type_id'] === (string)$documentTypeId &&
                       !empty($mat['code_content']);
            
            if ($isMatch) {
                \Log::info('Found matching lab code:', [
                    'chapter_id' => $mat['chapter_id'],
                    'document_type_id' => $mat['document_type_id'],
                    'code_title' => $mat['code_title'] ?? 'No title',
                    'code_content_length' => strlen($mat['code_content'] ?? '')
                ]);
            }
            
            return $isMatch;
        });
        
        // DEBUG: Log filtered results
        \Log::info('Filtered lab codes count: ' . count($labCodes));
        \Log::info('Filtered lab codes keys: ' . implode(', ', array_keys($labCodes)));

        // Reset array keys to ensure sequential 0,1,2... indexing
        $labCodes = array_values($labCodes);
        \Log::info('After array_values - lab codes keys: ' . implode(', ', array_keys($labCodes)));

        if (empty($labCodes)) {
            abort(404, 'Lab code not found.');
        }

        // Default to first lab code
        $defaultCode = $labCodes[0];

        return view('content.courses.course_lab_viewer', [
            'fileName' => $defaultCode['code_title'] ?? 'Lab Code',
            'codeContent' => $defaultCode['code_content'],
            'language' => $defaultCode['code_language'] ?? 'none',
            'languageName' => $defaultCode['code_title'] ?? 'Lab Code',
            'labCodes' => $labCodes, // pass all lab codes for dropdown
        ]);
    } else {
        // ... rest of your file-based code
    }
}



// public function course_view_material($id = '')
// {
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

//     // Check if decryption failed
//     if ($decryptedValue === false) {
//         return redirect()->back()->with('error', 'Invalid Entry');
//     }

//     // Find the course by decrypted ID
//     $view = ManageCoursesModel::where('sno', $decryptedValue)->where('status', 0)->first();

//     if (!$view) {
//         return redirect()->back()->with('error', 'Course View not found');
//     }

//     $materials = [];

//     if (!empty($view->materials)) {
//         $decoded = json_decode($view->materials, true);

//         // Handle JSON decode error
//         if (json_last_error() !== JSON_ERROR_NONE) {
//             return redirect()->back()->with('error', 'Failed to load course materials');
//         }

//         // Enrich each material with document type name
//         foreach ($decoded as $material) {
//             $docType = MaterialTypeModel::where('sno', $material['document_type_id'])
//                         ->where('status', 0)
//                         ->value('material_type_name');

//             $materials[] = [
//                 'course_id'        => $material['course_id'],
//                 'chapter_id'       => $material['chapter_id'],
//                 'document_type_id' => $material['document_type_id'],
//                 'document_type'    => $docType ?? 'Unknown',
//                 'material_name'    => $material['material_name'],
//                 'original_name'    => $material['original_name'] ?? null,
//             ];
//         }
//     }

//     return view('content.courses.view_materials', [
//         'view'      => $view,
//         'materials' => $materials,
//     ]);
// }

public function course_view_material($id = '')
{
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the course by decrypted ID
    $view = ManageCoursesModel::where('sno', $decryptedValue)->where('status', 0)->first();

    if (!$view) {
        return redirect()->back()->with('error', 'Course View not found');
    }

    $materials = [];

    if (!empty($view->materials)) {
        $decoded = json_decode($view->materials, true);

        // Handle JSON decode error
        if (json_last_error() !== JSON_ERROR_NONE) {
            return redirect()->back()->with('error', 'Failed to load course materials');
        }

        // Enrich each material with document type name
        foreach ($decoded as $material) {
            $docType = MaterialTypeModel::where('sno', $material['document_type_id'])
                        ->where('status', 0)
                        ->value('material_type_name');

            $materials[] = [
                'course_id'        => $material['course_id'],
                'chapter_id'       => $material['chapter_id'],
                'document_type_id' => $material['document_type_id'],
                'document_type'    => $docType ?? 'Unknown',
                'material_name'    => $material['material_name'],
                'original_name'    => $material['original_name'] ?? null,
            ];
        }
    }

    return view('content.courses.view_materials', [
        'view'      => $view,
        'materials' => $materials,
    ]);
}

public function updateDocument(Request $request)
  {
    $request->validate([
      'course_id'        => 'required',
      'chapter_id'       => 'required',
      'document_type_id' => 'required',
      'old_file_name'    => 'required|string',
      'file'             => 'nullable|file',
    ]);

    $courseId       = $request->course_id;
    $chapterId      = $request->chapter_id;
    $documentTypeId = $request->document_type_id;
    $oldFileName    = $request->old_file_name;

    $course = ManageCoursesModel::where('sno', $courseId)->first();

    if (!$course) {
      return response()->json([
        'success' => false,
        'message' => 'Course not found.'
      ]);
    }

    $materials = json_decode($course->materials, true);

    if (!is_array($materials)) {
      return response()->json([
        'success' => false,
        'message' => 'Invalid materials data.'
      ]);
    }

    $updated = false;
    $newFileUploaded = false;
    $newFileName = $oldFileName;
    $newOriginalName = null;
    $newWasabiPath = null;

    /*
      |--------------------------------------------------------------------------
      | Find material first
      |--------------------------------------------------------------------------
      */
    foreach ($materials as $key => $mat) {
      if (
        isset(
          $mat['chapter_id'],
          $mat['document_type_id'],
          $mat['material_name']
        ) &&
        trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
        (string) $mat['document_type_id'] === (string) $documentTypeId &&
        trim((string) $mat['material_name']) === trim((string) $oldFileName)
      ) {
        $updated = true;
        break;
      }
    }

    if (!$updated) {
      return response()->json([
        'success' => false,
        'message' => 'Material not found for this chapter/type.'
      ]);
    }

    try {

      /*
          |--------------------------------------------------------------------------
          | Upload new file to Wasabi
          |--------------------------------------------------------------------------
          */
      if ($request->hasFile('file')) {

        $file = $request->file('file');

        $newFileName = 'doc_' .
          uniqid() .
          '.' .
          $file->getClientOriginalExtension();

        $newWasabiPath = $this->uploadCourseMaterialToWasabi(
          $file,
          $courseId,
          $documentTypeId,
          $newFileName
        );

        $newFileUploaded = true;
        $newOriginalName = $file->getClientOriginalName();
        $newFileName = basename($newWasabiPath);
      }

      /*
          |--------------------------------------------------------------------------
          | Update JSON
          |--------------------------------------------------------------------------
          */
      foreach ($materials as &$mat) {

        if (
          isset(
            $mat['chapter_id'],
            $mat['document_type_id'],
            $mat['material_name']
          ) &&
          trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
          (string) $mat['document_type_id'] === (string) $documentTypeId &&
          trim((string) $mat['material_name']) === trim((string) $oldFileName)
        ) {

          $mat['material_name'] = $newFileName;

          if ($newOriginalName !== null) {
            $mat['original_name'] = $newOriginalName;
          }

          $mat['updated_at'] = now()->toDateTimeString();

          break;
        }
      }

      unset($mat);

      /*
          |--------------------------------------------------------------------------
          | Save DB
          |--------------------------------------------------------------------------
          */
      $course->materials = json_encode(
        array_values($materials),
        JSON_UNESCAPED_SLASHES
      );

      $course->save();

      /*
          |--------------------------------------------------------------------------
          | DB successful -> delete old Wasabi file
          |--------------------------------------------------------------------------
          */
      if (
        $newFileUploaded &&
        !empty($oldFileName) &&
        $oldFileName !== $newFileName
      ) {
        $this->deleteCourseMaterialFromWasabi(
          $courseId,
          $documentTypeId,
          $oldFileName
        );
      }

      return response()->json([
        'success' => true,
        'message' => 'Document updated successfully.'
      ]);
    } catch (\Exception $e) {

      /*
          |--------------------------------------------------------------------------
          | DB/upload failed -> delete newly uploaded Wasabi file
          |--------------------------------------------------------------------------
          */
      if ($newFileUploaded && $newWasabiPath) {
        if (Storage::disk('wasabi')->exists($newWasabiPath)) {
          Storage::disk('wasabi')->delete($newWasabiPath);
        }
      }

      Log::error('Document update failed', [
        'course_id'        => $courseId,
        'chapter_id'       => $chapterId,
        'document_type_id' => $documentTypeId,
        'old_file_name'    => $oldFileName,
        'error'             => $e->getMessage(),
      ]);

      return response()->json([
        'success' => false,
        'message' => 'Failed to update document: ' . $e->getMessage()
      ], 500);
    }
  }


  public function updatePPT(Request $request)
  {
    $request->validate([
      'course_id'        => 'required',
      'chapter_id'       => 'required',
      'document_type_id' => 'required',
      'old_file_name'    => 'required|string',
      'file'             => 'nullable|file',
    ]);

    $courseId       = $request->course_id;
    $chapterId      = $request->chapter_id;
    $documentTypeId = $request->document_type_id;
    $oldFileName    = $request->old_file_name;

    $course = ManageCoursesModel::where('sno', $courseId)->first();

    if (!$course) {
      return response()->json([
        'success' => false,
        'message' => 'Course not found.'
      ]);
    }

    $materials = json_decode($course->materials, true);

    if (!is_array($materials)) {
      return response()->json([
        'success' => false,
        'message' => 'Invalid materials data.'
      ]);
    }

    $updated = false;
    $newFileUploaded = false;
    $newFileName = $oldFileName;
    $newOriginalName = null;
    $newWasabiPath = null;

    /*
      |--------------------------------------------------------------------------
      | Check material exists
      |--------------------------------------------------------------------------
      */
    foreach ($materials as $mat) {

      if (
        isset(
          $mat['chapter_id'],
          $mat['document_type_id'],
          $mat['material_name']
        ) &&
        trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
        (string) $mat['document_type_id'] === (string) $documentTypeId &&
        trim((string) $mat['material_name']) === trim((string) $oldFileName)
      ) {
        $updated = true;
        break;
      }
    }

    if (!$updated) {
      return response()->json([
        'success' => false,
        'message' => 'Material not found for this chapter/type.'
      ]);
    }

    try {

      /*
          |--------------------------------------------------------------------------
          | Upload new PPT to Wasabi
          |--------------------------------------------------------------------------
          */
      if ($request->hasFile('file')) {

        $file = $request->file('file');

        $generatedFileName = 'doc_' .
          uniqid() .
          '.' .
          $file->getClientOriginalExtension();

        $newWasabiPath = $this->uploadCourseMaterialToWasabi(
          $file,
          $courseId,
          $documentTypeId,
          $generatedFileName
        );

        $newFileUploaded = true;
        $newFileName = basename($newWasabiPath);
        $newOriginalName = $file->getClientOriginalName();
      }

      /*
          |--------------------------------------------------------------------------
          | Update JSON
          |--------------------------------------------------------------------------
          */
      foreach ($materials as &$mat) {

        if (
          isset(
            $mat['chapter_id'],
            $mat['document_type_id'],
            $mat['material_name']
          ) &&
          trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
          (string) $mat['document_type_id'] === (string) $documentTypeId &&
          trim((string) $mat['material_name']) === trim((string) $oldFileName)
        ) {

          $mat['material_name'] = $newFileName;

          if ($newOriginalName !== null) {
            $mat['original_name'] = $newOriginalName;
          }

          $mat['updated_at'] = now()->toDateTimeString();

          break;
        }
      }

      unset($mat);

      $course->materials = json_encode(
        array_values($materials),
        JSON_UNESCAPED_SLASHES
      );

      $course->save();

      /*
          |--------------------------------------------------------------------------
          | Delete old PPT from Wasabi
          |--------------------------------------------------------------------------
          */
      if (
        $newFileUploaded &&
        !empty($oldFileName) &&
        $oldFileName !== $newFileName
      ) {
        $this->deleteCourseMaterialFromWasabi(
          $courseId,
          $documentTypeId,
          $oldFileName
        );
      }

      return response()->json([
        'success' => true,
        'message' => 'PPT updated successfully.'
      ]);
    } catch (\Exception $e) {

      if ($newFileUploaded && $newWasabiPath) {

        if (Storage::disk('wasabi')->exists($newWasabiPath)) {
          Storage::disk('wasabi')->delete($newWasabiPath);
        }
      }

      Log::error('PPT update failed', [
        'course_id'        => $courseId,
        'chapter_id'       => $chapterId,
        'document_type_id' => $documentTypeId,
        'old_file_name'    => $oldFileName,
        'error'             => $e->getMessage(),
      ]);

      return response()->json([
        'success' => false,
        'message' => 'Failed to update PPT: ' . $e->getMessage()
      ], 500);
    }
  }
  
  public function updatePDF(Request $request)
  {
    $request->validate([
      'course_id'        => 'required|integer',
      'chapter_id'       => 'required|string',
      'document_type_id' => 'required',
      'old_file_name'    => 'required|string',
      'file'             => 'nullable|file|mimes:pdf',
    ]);

    $courseId       = $request->course_id;
    $chapterId      = $request->chapter_id;
    $documentTypeId = $request->document_type_id;
    $oldFileName    = $request->old_file_name;

    $course = ManageCoursesModel::where('sno', $courseId)->first();

    if (!$course) {
      return response()->json([
        'success' => false,
        'message' => 'Course not found.'
      ]);
    }

    $materials = json_decode($course->materials, true);

    if (!is_array($materials)) {
      return response()->json([
        'success' => false,
        'message' => 'Invalid materials data.'
      ]);
    }

    $updated = false;
    $newFileUploaded = false;
    $newFileName = $oldFileName;
    $newOriginalName = null;
    $newWasabiPath = null;

    /*
      |--------------------------------------------------------------------------
      | Check material exists
      |--------------------------------------------------------------------------
      */
    foreach ($materials as $mat) {

      if (
        isset(
          $mat['chapter_id'],
          $mat['document_type_id'],
          $mat['material_name']
        ) &&
        trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
        (string) $mat['document_type_id'] === (string) $documentTypeId &&
        trim((string) $mat['material_name']) === trim((string) $oldFileName)
      ) {
        $updated = true;
        break;
      }
    }

    if (!$updated) {
      return response()->json([
        'success' => false,
        'message' => 'Material not found.'
      ]);
    }

    try {

      /*
          |--------------------------------------------------------------------------
          | Upload new PDF to Wasabi
          |--------------------------------------------------------------------------
          */
      if ($request->hasFile('file')) {

        $file = $request->file('file');

        $generatedFileName = 'doc_' .
          uniqid() .
          '.' .
          $file->getClientOriginalExtension();

        $newWasabiPath = $this->uploadCourseMaterialToWasabi(
          $file,
          $courseId,
          $documentTypeId,
          $generatedFileName
        );

        $newFileUploaded = true;
        $newFileName = basename($newWasabiPath);
        $newOriginalName = $file->getClientOriginalName();
      }

      /*
          |--------------------------------------------------------------------------
          | Update JSON
          |--------------------------------------------------------------------------
          */
      foreach ($materials as &$mat) {

        if (
          isset(
            $mat['chapter_id'],
            $mat['document_type_id'],
            $mat['material_name']
          ) &&
          trim((string) $mat['chapter_id']) === trim((string) $chapterId) &&
          (string) $mat['document_type_id'] === (string) $documentTypeId &&
          trim((string) $mat['material_name']) === trim((string) $oldFileName)
        ) {

          $mat['material_name'] = $newFileName;

          if ($newOriginalName !== null) {
            $mat['original_name'] = $newOriginalName;
          }

          $mat['updated_at'] = now()->toDateTimeString();

          break;
        }
      }

      unset($mat);

      $course->materials = json_encode(
        array_values($materials),
        JSON_UNESCAPED_SLASHES
      );

      $course->save();

      /*
          |--------------------------------------------------------------------------
          | Delete old PDF from Wasabi
          |--------------------------------------------------------------------------
          */
      if (
        $newFileUploaded &&
        !empty($oldFileName) &&
        $oldFileName !== $newFileName
      ) {
        $this->deleteCourseMaterialFromWasabi(
          $courseId,
          $documentTypeId,
          $oldFileName
        );
      }

      return response()->json([
        'success' => true,
        'message' => 'PDF updated successfully.'
      ]);
    } catch (\Exception $e) {

      if ($newFileUploaded && $newWasabiPath) {

        if (Storage::disk('wasabi')->exists($newWasabiPath)) {
          Storage::disk('wasabi')->delete($newWasabiPath);
        }
      }

      Log::error('PDF update failed', [
        'course_id'        => $courseId,
        'chapter_id'       => $chapterId,
        'document_type_id' => $documentTypeId,
        'old_file_name'    => $oldFileName,
        'error'             => $e->getMessage(),
      ]);

      return response()->json([
        'success' => false,
        'message' => 'Failed to update PDF: ' . $e->getMessage()
      ], 500);
    }
  }



  public function downloadFile(Request $request)
  {
    try {
 
      // STEP 1: Check encrypted value
      if (!$request->filled('encrypted')) {
        return response()->json([
          'step' => 1,
          'error' => 'encrypted parameter is missing'
        ], 400);
      }
 
      // STEP 2: Decrypt
      try {
        $data = Crypt::decrypt($request->encrypted);
      } catch (\Exception $e) {
        return response()->json([
          'step' => 2,
          'error' => 'Decryption failed',
          'message' => $e->getMessage(),
          'encrypted' => $request->encrypted
        ], 400);
      }
 
      // STEP 3: Show decrypted data
      if (
        empty($data['course_id']) ||
        empty($data['doc_type']) ||
        empty($data['file_name'])
      ) {
        return response()->json([
          'step' => 3,
          'error' => 'Required encrypted data missing',
          'data' => $data
        ], 400);
      }
 
      $courseId = $data['course_id'];
      $documentTypeId = $data['doc_type'];
      $fileName = $data['file_name'];
 
      // STEP 4: Find course
      $course = ManageCoursesModel::where('sno', $courseId)->first();
 
      if (!$course) {
        return response()->json([
          'step' => 4,
          'error' => 'Course not found',
          'course_id' => $courseId
        ], 404);
      }
 
      // STEP 5: Decode materials
      $materials = json_decode($course->materials, true);
 
      if (!is_array($materials)) {
        return response()->json([
          'step' => 5,
          'error' => 'Materials JSON is invalid',
          'materials' => $course->materials
        ], 400);
      }
 
      // STEP 6: Find material
      $material = collect($materials)->first(function ($mat) use (
        $fileName,
        $documentTypeId
      ) {
        return isset(
          $mat['document_type_id'],
          $mat['material_name']
        )
          && (string) $mat['document_type_id'] === (string) $documentTypeId
          && trim((string) $mat['material_name']) === trim((string) $fileName);
      });
 
      if (!$material) {
        return response()->json([
          'step' => 6,
          'error' => 'Material not found',
          'course_id' => $courseId,
          'document_type_id' => $documentTypeId,
          'file_name' => $fileName,
          'materials' => $materials
        ], 404);
      }
 
      // STEP 7: Physical file path
      $filePath = public_path(
        "course_materials/{$courseId}/{$documentTypeId}/{$fileName}"
      );
 
      if (!file_exists($filePath)) {
        return response()->json([
          'step' => 7,
          'error' => 'Physical PDF file does not exist',
          'file_path' => $filePath,
          'course_id' => $courseId,
          'document_type_id' => $documentTypeId,
          'file_name' => $fileName
        ], 404);
      }
 
      // STEP 8: Download
      $downloadName = !empty($material['original_name'])
        ? $material['original_name']
        : $fileName;
 
      return response()->download(
        $filePath,
        $downloadName,
        [
          'Content-Type' => 'application/pdf',
        ]
      );
    } catch (\Exception $e) {
 
      return response()->json([
        'step' => 'exception',
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
      ], 500);
    }
  }
  
public function updateLabCodeMaterial(Request $request)
{
    try {
        DB::beginTransaction();

        // More flexible validation that accepts both field naming conventions
        $validated = $request->validate([
            'course_id' => 'required',
            'chapter_id' => 'required',
            'doc_type' => 'required',
            'labcode_title' => 'required|string',
            'labcode_language' => 'required|string', 
            'labcode_content' => 'required|string',
            // Also accept the alternative field names as fallback
            'code_title' => 'sometimes|string',
            'code_language' => 'sometimes|string',
            'code_content' => 'sometimes|string',
        ]);

        $courseId   = $request->course_id;
        $chapterId  = $request->chapter_id;
        $docType    = $request->doc_type;
        
        $course = ManageCoursesModel::find($courseId);
        if (!$course) {
            return response()->json(['success' => false, 'message' => 'Course not found.'], 404);
        }

        // Use the correct field names (prefer labcode_* fields, fallback to code_*)
        $mainTitle = $request->labcode_title ?: $request->code_title;
        $mainLanguage = $request->labcode_language ?: $request->code_language;
        $mainContent = $request->labcode_content ?: $request->code_content;

        // Validate that we have the required main fields
        if (!$mainTitle || !$mainLanguage || !$mainContent) {
            return response()->json([
                'success' => false, 
                'message' => 'Main code title, language, and content are required.'
            ], 422);
        }

        // Decode existing materials
        $materials = json_decode($course->materials, true) ?? [];

        // Remove only old lab-code blocks for this chapter
        $materials = array_filter($materials, function ($item) use ($chapterId, $docType) {
            return !(
                $item['chapter_id'] === $chapterId &&
                isset($item['document_type_id']) &&
                $item['document_type_id'] == $docType
            );
        });

        // Build new lab code entries
        $newLabCodes = [];

        // Main code block
        $newLabCodes[] = [
            'course_id'         => $courseId,
            'chapter_id'        => $chapterId,
            'document_type_id'  => $docType,
            'material_name'     => '',
            'original_name'     => '',
            'code_title'        => $mainTitle,
            'code_language'     => $mainLanguage,
            'code_content'      => $mainContent,
            'created_at'        => now(),
            'block_index'       => 0,
        ];

        // Additional blocks
        $extraTitles    = $request->input('extra_code_title', []);
        $extraLangs     = $request->input('extra_code_language', []);
        $extraContents  = $request->input('extra_code_content', []);

        foreach ($extraTitles as $i => $title) {
            if (!empty($title) && !empty($extraLangs[$i]) && !empty($extraContents[$i])) {
                $newLabCodes[] = [
                    'course_id'         => $courseId,
                    'chapter_id'        => $chapterId,
                    'document_type_id'  => $docType,
                    'material_name'     => '',
                    'original_name'     => '',
                    'code_title'        => $title,
                    'code_language'     => $extraLangs[$i],
                    'code_content'      => $extraContents[$i],
                    'created_at'        => now(),
                    'block_index'       => $i + 1,
                ];
            }
        }

        // Merge back with remaining materials
        $finalMaterials = array_values(array_merge($materials, $newLabCodes));

        // Save
        $course->materials = json_encode($finalMaterials, JSON_UNESCAPED_SLASHES);
        $course->save();

        DB::commit();

        return response()->json([
            'success' => true,
            'message' => 'Lab Code updated successfully!'
        ]);

    } catch (\Illuminate\Validation\ValidationException $e) {
        DB::rollBack();
        return response()->json([
            'success' => false,
            'message' => 'Validation failed: ' . implode(' ', $e->errors())
        ], 422);
    } catch (\Exception $e) {
        DB::rollBack();
        \Log::error('Lab Code update failed', ['error' => $e->getMessage()]);
        return response()->json([
            'success' => false,
            'message' => 'Failed to update Lab Code: ' . $e->getMessage()
        ], 500);
    }
}

// Helper function to get file extension based on language
private function getFileExtension($language)
{
    $extensions = [
        'html' => '.html',
        'css' => '.css',
        'javascript' => '.js',
        'typescript' => '.ts',
        'php' => '.php',
        'laravel' => '.php',
        'python' => '.py',
        'java' => '.java',
        'csharp' => '.cs',
        'ruby' => '.rb',
        'go' => '.go',
        'rust' => '.rs',
        'c' => '.c',
        'cpp' => '.cpp',
        'sql' => '.sql',
        'json' => '.json',
        'yaml' => '.yaml',
        'xml' => '.xml',
        'bash' => '.sh',
        'powershell' => '.ps1',
        'markdown' => '.md',
        'docker' => 'Dockerfile',
        'none' => '.txt',
    ];

    return $extensions[$language] ?? '.txt';
}


  public function updateAudioMaterial(Request $request)
  {
    $courseId = $request->course_id;
    $chapterId = $request->chapter_id;
    $docType = $request->document_type_id;

    $newWasabiFiles = [];
    $oldWasabiFiles = [];

    try {

      $validator = Validator::make($request->all(), [
        'course_id' => 'required',
        'chapter_id' => 'required',
        'document_type_id' => 'required',
        'audio_languages' => 'required|array',
        'audio_languages.*' => 'required',
        'audio_files' => 'sometimes|array',
        'audio_files.*' => 'sometimes|array',
        'audio_files.*.*' => 'sometimes|file'
      ]);

      if ($validator->fails()) {
        return response()->json([
          'success' => false,
          'message' => 'Validation failed',
          'errors' => $validator->errors()
        ], 422);
      }

      /*
          |--------------------------------------------------------------------------
          | Get course
          |--------------------------------------------------------------------------
          */
      $course = ManageCoursesModel::where('sno', $courseId)->first();

      if (!$course) {
        return response()->json([
          'success' => false,
          'message' => 'Course not found.'
        ]);
      }

      /*
          |--------------------------------------------------------------------------
          | Decode existing materials
          |--------------------------------------------------------------------------
          */
      $materials = json_decode($course->materials, true) ?? [];

      if (!is_array($materials)) {
        $materials = [];
      }

      $languages = $request->audio_languages;
      $audioFiles = $request->file('audio_files', []);

      /*
          |--------------------------------------------------------------------------
          | Process audio files
          |--------------------------------------------------------------------------
          */
      foreach ($languages as $index => $languageCode) {

        $groupIndex = $index;

        if (
          isset($audioFiles[$groupIndex]) &&
          !empty($audioFiles[$groupIndex])
        ) {

          $files = $audioFiles[$groupIndex];

          foreach ($files as $fileIndex => $file) {

            if (!$file || !$file->isValid()) {
              continue;
            }

            /*
                      |--------------------------------------------------------------------------
                      | Generate filename
                      |--------------------------------------------------------------------------
                      */
            $filename = 'audio_' .
              uniqid() .
              '.' .
              $file->getClientOriginalExtension();

            /*
                      |--------------------------------------------------------------------------
                      | Upload NEW file directly to Wasabi
                      |--------------------------------------------------------------------------
                      */
            $wasabiPath = $this->uploadCourseMaterialToWasabi(
              $file,
              $courseId,
              $docType,
              $filename
            );

            $newWasabiFiles[] = $wasabiPath;

            /*
                      |--------------------------------------------------------------------------
                      | Find existing audio material
                      |--------------------------------------------------------------------------
                      */
            $existingMaterialKey = $this->findAudioMaterial(
              $materials,
              $courseId,
              $chapterId,
              $docType,
              $languageCode,
              $groupIndex,
              $fileIndex
            );

            if ($existingMaterialKey !== null) {

              /*
                          |--------------------------------------------------------------------------
                          | Save old filename for deletion AFTER DB save
                          |--------------------------------------------------------------------------
                          */
              $oldFilename =
                $materials[$existingMaterialKey]['material_name'] ?? '';

              if (!empty($oldFilename)) {
                $oldWasabiFiles[] = $oldFilename;
              }

              /*
                          |--------------------------------------------------------------------------
                          | Update existing JSON entry
                          |--------------------------------------------------------------------------
                          */
              $materials[$existingMaterialKey]['material_name'] =
                $filename;

              $materials[$existingMaterialKey]['original_name'] =
                $file->getClientOriginalName();

              $materials[$existingMaterialKey]['updated_at'] =
                now()->toDateTimeString();
            } else {

              /*
                          |--------------------------------------------------------------------------
                          | Create new JSON entry
                          |--------------------------------------------------------------------------
                          */
              $newMaterial = [
                'course_id' => $courseId,
                'chapter_id' => $chapterId,
                'document_type_id' => $docType,
                'material_name' => $filename,
                'original_name' => $file->getClientOriginalName(),
                'code_language' => $languageCode,
                'code_title' => '',
                'code_content' => '',
                'group_index' => $groupIndex,
                'file_index' => $fileIndex,
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
              ];

              $materials[] = $newMaterial;
            }
          }
        } else {

          /*
                  |--------------------------------------------------------------------------
                  | No new file for this language
                  |--------------------------------------------------------------------------
                  */
          $existingMaterialKey = $this->findAudioMaterial(
            $materials,
            $courseId,
            $chapterId,
            $docType,
            $languageCode,
            $groupIndex,
            0
          );

          if ($existingMaterialKey === null) {

            /*
                      |--------------------------------------------------------------------------
                      | Create placeholder
                      |--------------------------------------------------------------------------
                      */
            $placeholderMaterial = [
              'course_id' => $courseId,
              'chapter_id' => $chapterId,
              'document_type_id' => $docType,
              'material_name' => '',
              'original_name' => '',
              'code_language' => $languageCode,
              'code_title' => '',
              'code_content' => '',
              'group_index' => $groupIndex,
              'file_index' => 0,
              'created_at' => now()->toDateTimeString(),
              'updated_at' => now()->toDateTimeString()
            ];

            $materials[] = $placeholderMaterial;
          }
        }
      }

      /*
          |--------------------------------------------------------------------------
          | Save DB
          |--------------------------------------------------------------------------
          */
      $course->materials = json_encode(
        $materials,
        JSON_UNESCAPED_SLASHES
      );

      $course->save();

      /*
          |--------------------------------------------------------------------------
          | DB successful -> delete OLD Wasabi files
          |--------------------------------------------------------------------------
          */
      foreach ($oldWasabiFiles as $oldFileName) {

        if (!empty($oldFileName)) {

          $this->deleteCourseMaterialFromWasabi(
            $courseId,
            $docType,
            $oldFileName
          );
        }
      }

      return response()->json([
        'success' => true,
        'message' => 'Audio materials updated successfully!'
      ]);
    } catch (\Exception $e) {

      /*
          |--------------------------------------------------------------------------
          | DB failed -> delete NEW Wasabi files
          |--------------------------------------------------------------------------
          */
      foreach ($newWasabiFiles as $newWasabiPath) {

        if (
          !empty($newWasabiPath) &&
          Storage::disk('wasabi')->exists($newWasabiPath)
        ) {
          Storage::disk('wasabi')->delete($newWasabiPath);
        }
      }

      Log::error('Audio update failed', [
        'course_id'        => $courseId,
        'chapter_id'       => $chapterId,
        'document_type_id' => $docType,
        'error'             => $e->getMessage(),
      ]);

      return response()->json([
        'success' => false,
        'message' => 'Failed to update audio materials: ' .
          $e->getMessage()
      ], 500);
    }
  }
  

/**
 * Find audio material in the materials array
 */
  private function findAudioMaterial(
    $materials,
    $courseId,
    $chapterId,
    $docType,
    $languageCode,
    $groupIndex,
    $fileIndex
  ) {
    foreach ($materials as $key => $material) {
      if (
        isset($material['course_id']) &&
        $material['course_id'] == $courseId &&

        isset($material['chapter_id']) &&
        $material['chapter_id'] == $chapterId &&

        isset($material['document_type_id']) &&
        $material['document_type_id'] == $docType &&

        isset($material['code_language']) &&
        $material['code_language'] == $languageCode &&

        isset($material['group_index']) &&
        $material['group_index'] == $groupIndex &&

        isset($material['file_index']) &&
        $material['file_index'] == $fileIndex
      ) {
        return $key;
      }
    }

    return null;
  }
 
 
 private function uploadCourseMaterialToWasabi(
    $file,
    $courseId,
    $documentTypeId,
    $fileName
  ) {
    $path = "course_materials/{$courseId}/{$documentTypeId}";

    $storedPath = Storage::disk('wasabi')->putFileAs(
      $path,
      $file,
      $fileName
    );

    if (!$storedPath) {
      throw new \Exception('Failed to upload file to Wasabi.');
    }

    return $storedPath;
  }

  private function deleteCourseMaterialFromWasabi(
    $courseId,
    $documentTypeId,
    $fileName
  ) {
    if (!$fileName) {
      return;
    }

    $path = "course_materials/{$courseId}/{$documentTypeId}/{$fileName}";

    if (Storage::disk('wasabi')->exists($path)) {
      Storage::disk('wasabi')->delete($path);
    }
  }
  

public function updateVideo(Request $request)
{
    $request->validate([
        'course_id' => 'required',
        'chapter_id' => 'required',
        'document_type_id' => 'required',
        'old_file_name' => 'required'
    ]);

    // Start with old file name
    $fileName = $request->old_file_name;
    $originalName = $request->old_file_name; // Default to old name

    // Handle new file upload
    if ($request->hasFile('file')) {
        $file = $request->file('file');
        
        // ✅ Validate video file type
        $allowedTypes = ['mp4', 'avi', 'mov', 'mkv', 'webm'];
        $extension = $file->getClientOriginalExtension();
        
        if (!in_array(strtolower($extension), $allowedTypes)) {
            return response()->json([
                'success' => false, 
                'message' => 'Invalid file type. Please upload video files only.'
            ]);
        }

        $newName = 'video_' . uniqid() . '.' . $file->getClientOriginalExtension();
        $path = public_path('course_materials/' . $request->course_id . '/' . $request->document_type_id);
        
        if (!file_exists($path)) {
            mkdir($path, 0755, true);
        }
        
        $file->move($path, $newName);
        $fileName = $newName;
        $originalName = $file->getClientOriginalName();

        // Delete old file if it exists and is different from new file
        $oldFilePath = $path . '/' . $request->old_file_name;
        if (file_exists($oldFilePath) && $request->old_file_name !== $newName) {
            @unlink($oldFilePath);
        }
    }

    // Fetch course
    $course = ManageCoursesModel::where('sno', $request->course_id)->first();
    if (!$course) {
        return response()->json(['success' => false, 'message' => 'Course not found.']);
    }

    $materials = json_decode($course->materials, true) ?? [];
    $updated = false;

    foreach ($materials as &$mat) {
        if (
            isset($mat['chapter_id']) && 
            $mat['chapter_id'] == $request->chapter_id &&
            isset($mat['document_type_id']) && 
            $mat['document_type_id'] == $request->document_type_id &&
            isset($mat['material_name']) && 
            $mat['material_name'] === $request->old_file_name
        ) {
            // Update the material
            $mat['material_name'] = $fileName;
            $mat['original_name'] = $originalName;
            $updated = true;
            break;
        }
    }

    if (!$updated) {
        return response()->json(['success' => false, 'message' => 'Video material not found for this chapter/type.']);
    }

    $course->materials = json_encode($materials);
    $course->save();

    return response()->json([
        'success' => true, 
        'message' => 'Video updated successfully.',
        'file_name' => $fileName
    ]);
}

public function saveCourseMaterial(Request $request)
  {
    $user_id = $request->user()->user_id;
    $data = [
      'course_material' => $request->input('course_material', []),
      'faculty_staffs' => $request->input('faculty_staffs', []),
      'students' => $request->input('students', []),
      'franchise' => $request->input('franchise', []),
    ];
 
    // Update if exists sno = 1, else insert
    \DB::table('za_course_material')->updateOrInsert(
      ['sno' => 1],
      [
        'course_materials' => json_encode($data),
        'created_by' => $user_id,
        'updated_by' => $user_id,
      ]
    );
 
    return redirect()->back()->with('success', 'Course material saved successfully!');
  }
 
  public function getCourseMaterial($id)
  {
    $record = \DB::table('za_course_material')->where('sno', 1)->first();
    $materials = $record ? json_decode($record->course_materials, true) : [];
    return response()->json($materials);
  }
  
  public function syllbusPrompt(Request $request)
  {
    $courseId = $request->course_id;
    $chapterId = $request->chapter_id;
 
    // Fetch course data
    $course = ManageCoursesModel::where('sno', $courseId)->where('status', 0)->first();
 
    // Fetch chapter data
    $chapter = ManageCoursesSyllabusModel::where('sno', $chapterId)
      ->where('course_id', $courseId)
      ->where('status', 0)
      ->first();
 
    if (!$course || !$chapter) {
      return response()->json(['error' => 'Course or Chapter not found'], 404);
    }
 
    // Fetch all topics for this chapter
    $topics = ManageCoursesSyllabusModel::where('course_id', $courseId)
      ->where('course_chapter_id', $chapter->course_chapter_id)
      ->where('status', 0)
      ->whereNotNull('topic_id')
      ->select('topic_id', 'topic_name', 'course_action_id', 'session_id')
      ->groupBy('topic_id', 'topic_name', 'course_action_id', 'session_id')
      ->get();
 
    // Format topics for display
    $topicList = [];
    foreach ($topics as $topic) {
      $actionName = \DB::table('za_course_action')
        ->where('sno', $topic->course_action_id)
        ->value('course_action_name') ?? '';
 
      $topicList[] = "· " . $topic->topic_name . " ";
    }
 
    // If no topics found, use default ones
    if (empty($topicList)) {
      $topicList = [
        "· Capstone Project: Full Branding & Motion Campaign",
        "· Portfolio Presentation (Behance, Dribbble, LinkedIn)",
        "· Resume & Freelance Profile Creation",
        "· Client Brief Handling & Design Handoff Workflow",
        "· Theme Example: Design a Brand for a Tech Startup"
      ];
    }
 
    // Generate Document Prompt
    $docPrompt = "Course Name: \"" . $course->course_name . "\" Course Package: \"Professional Training Course\"\n\n";
    $docPrompt .= "Chapter " . $chapter->course_chapter_id . ": " . $chapter->course_chapter_name;
    $docPrompt .= " (Chapter Practical Hours: " . ($chapter->course_chapter_practical_hours ?? '0') . "Hrs, Theory hours: " . ($chapter->course_chapter_duration ?? '0') . " Hrs)\n\n";
    $docPrompt .= implode("\n", $topicList) . "\n\n";
    $docPrompt .= "Note: Output Must Create separate word document and PDF document";
 
    // Generate Presentation Prompt
    $presPrompt = "Create Training Presentation for \"Elysium Academy®\". ";
    $presPrompt .= "Course Name \"" . $course->course_name . "\". ";
    $presPrompt .= "CHAPTER " . $chapter->course_chapter_id . " : " . $chapter->course_chapter_name;
    $presPrompt .= "\n\n(Number of Slides: " . max(20, count($topicList) * 2) . ")";
 
    return response()->json([
      'document_prompt' => $docPrompt,
      'presentation_prompt' => $presPrompt
    ]);
  }
  
  
 //Course View
//  public function course_view_material($id = '')
//  {
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

//     // Check if decryption failed
//     if ($decryptedValue === false) {
//       return redirect()->back()->with('error', 'Invalid Entry');
//     }

//     // Find the course by decrypted ID
//     $view = ManageCoursesModel::where('sno', $decryptedValue)->where('status', 0)->first();

//     // Check if the course is not found
//     if (!$view) {
//       return redirect()->back()->with('error', 'Course View not found');
//     }

//     // Initialize arrays for chapters, sections, and topics

//     $materials = [];
//     $files=[];
//     if (!empty($view->materials)) {
//       $materials = json_decode($view->materials, true); // Decode JSON to an array

//       foreach ($materials as $key => $material) {
//         $material_name = MaterialTypeModel::where('sno', $key)->where('status', 0)->first();
//         if ($material_name) {
//           // Add a new key to the array
//           $key = $material_name->material_type_name;
//       } else {
//           $key = $key; // Set to null if not found
//       }
//     }

//       // Handle the case where JSON decoding fails
//       if (json_last_error() !== JSON_ERROR_NONE) {
//           return redirect()->back()->with('error', 'Failed to load course materials');
//       }
//   }
//   // return $materials;
//     return view('content.courses.view_materials', [
//       'view' => $view,
//       'materials' => $materials,
//     ]);
// }
  // Private Function End
}
