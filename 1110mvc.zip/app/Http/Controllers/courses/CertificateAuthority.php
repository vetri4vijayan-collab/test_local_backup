<?php

namespace App\Http\Controllers\courses;


use App\Http\Controllers\Controller;
use App\Models\CertificateAuthorityModel;
use App\Models\CertificateChecklistModel;
use App\Models\TrainingModel;
use App\Models\BatchChecklistModel;
use App\Models\CourierModel;
use App\Models\DistributeCertificateModel;
use App\Models\ManageCertificateModel;
use App\Models\RequestCertificateModel;
use App\Models\Student;
use App\Models\ExamModel;
use App\Models\ExamProcessModel;
use App\Models\CustomerModel;
use App\Models\AttendanceModel;
use App\Models\User;
use function Laravel\Prompts\select;
use Illuminate\Http\Request;
use App\Models\SlotModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use PDF;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\SyllabusUpdateModel;


class CertificateAuthority extends Controller
{

  public function index(Request $request)
  {
      // Retrieve certificate list
      $branch_id = $request->user()->branch_id;
      $cert_list = ManageCertificateModel::getCertificateList();
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $cus_fill = $request->cus_fill ?? '';
      
      foreach ($cert_list as $cert) {
          $existingRecord = CertificateAuthorityModel::where([
              'batch_id' => $cert->batch_id,
              'branch_id' => $cert->branch_id,
              'manage_cert_id' => $cert->sno
          ])->first();
          
          if ($existingRecord) {
              $existingRecord->update([
                  'cert_status_id' => $cert->cert_status_id,
                  'certificate_authority_status_id' => $cert->certificate_authority_status_id,
                  'created_by' => $cert->created_by,
                  'updated_by' => $cert->updated_by,
              ]);
          } else {
              CertificateAuthorityModel::create([
                  'batch_id' => $cert->batch_id,
                  'branch_id' => $cert->branch_id,
                  'cert_status_id' => $cert->cert_status_id,
                  'certificate_authority_status_id' => $cert->certificate_authority_status_id,
                  'manage_cert_id' => $cert->sno,
                  'created_by' => $cert->created_by,
                  'updated_by' => $cert->updated_by,
              ]);
          }
      }
  
      $certificate_authority = CertificateAuthorityModel::select(
          'za_certificate_authority.*', 
          'za_slot.slot_name',
          'za_batch.batch_name',
          'za_batch.status as batch_status',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_batch.max_students',
          'za_course.course_name',
          'za_course.course_version',
          'za_course_type.course_type_name',
          'za_course_type.course_days',
          'za_class_room.class_room_name',
          'za_slot_type.slot_type_name',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_slot.slot_type_days',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.staff_image',
          'za_staff.nick_name',
          'za_certificate_status.certificate_status_name',
          'za_certificate_status.bg_color as cert_status_bg',
          'za_certificate_status.text_color as cert_status_text',
          'za_certificate_authority_status.certificate_authority_status_name',
          'za_certificate_authority_status.bg_color as authority_status_bg',
          'za_certificate_authority_status.text_color as authority_status_text',
          'za_manage_certificate.batch_cmpltd_date',
          'za_manage_certificate.branch_id',
          'za_manage_certificate.batch_id',
          'za_manage_certificate.req_cert_date',
          'za_manage_certificate.req_accpt_date',
          'za_manage_certificate.cert_genr_date',
          'za_manage_certificate.cert_sent_date',
          'za_manage_certificate.cert_receive_date',
          'za_manage_certificate.total_stud_count',
          'za_manage_certificate.req_stud_count',
          'za_manage_certificate.confirm_stud_count',
          'za_manage_certificate.distr_stud_count',
          'za_manage_certificate.pending_stud_count',
          'za_manage_certificate.student_id',
          'za_manage_certificate.cert_status_id',
          'za_manage_certificate.certificate_authority_status_id'
      )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_certificate_authority.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_certificate_authority.cert_status_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_certificate_authority.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_manage_certificate', 'za_manage_certificate.sno', '=', 'za_certificate_authority.manage_cert_id')
      ->where('za_certificate_authority.status', '!=', 2)
      ->where('za_certificate_authority.branch_id', '=', $branch_id)
      ->orderBy('za_certificate_authority.sno', 'desc');
      
       if ($cus_fill) {
        $certificate_authority->where(function ($customer) use ($cus_fill) {
          $customer->where( 'za_batch.batch_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_staff.staff_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_slot.slot_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_course.course_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_course.course_version', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_class_room.class_room_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_certificate_authority_status.certificate_authority_status_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_course_type.course_type_name', 'LIKE', "%{$cus_fill}%");
          
        });
      }
      $certificate_authority= $certificate_authority->paginate($perpage);

      $pageConfigs = ['myLayout' => 'default'];
      
    //   return $certificate_authority;    

    $checklist_batch = BatchChecklistModel::select('*')->where('status', '=', 0)->get();
  
      // Return the view with the necessary data
      return view('content.courses.certificate_authority.list', [
          'cert_list' => $cert_list,
          'full_list' => $certificate_authority,
          'checklist_batch' => $checklist_batch,
          'pageConfigs' => $pageConfigs,
        'perpage' => $perpage,
        'cus_fill' => $cus_fill,
      ]);
  }

  public function AddSchedule(Request $request)
  {
    // return $request;
      // Retrieve data from the request
      $schedule_date = $request->schedule_start;
      $schedule_time = $request->schedule_time;
      $schedule_desc = $request->schedule_desc;
      $batch_id = $request->batch_id_apprv;
      $eligible_all = $request->eligible_all;
      $eligible_stud_id = $request->input('eligible_stud_id', []);
      $reason = $request->input('reason', []);
  
      $studentEligible = [];
      $studentIds = [];
  
      // Loop through the eligible students' IDs and check if they are eligible
      foreach ($eligible_stud_id as $index => $studentId) {
          $chkAllKey = 'chk_all_' . $studentId;  // The key for each student in the form, e.g., chk_all_46
          
          // Get the value of the checkbox for the current student
          $eligibleAll = $request->input($chkAllKey);
          
          // If eligibleAll is set to 1, add to eligible students
          if ($eligibleAll == '1') {
              $studentEligible[] = [
                  'Id' => $studentId,
                  'eligible' => 1
              ];
  
              // Store only the student IDs for approve_stud
              $studentIds[] = $studentId;
          }
      }
  
      // Update the CertificateAuthorityModel
      $cert_schedule = CertificateAuthorityModel::where('batch_id', $batch_id)->first();
      
      if ($cert_schedule) {
          // Set the schedule data
          $cert_schedule->schedule_date = date('Y-m-d', strtotime($schedule_date)); // Convert string to timestamp
          $cert_schedule->schedule_time = date('H:i:s', strtotime($schedule_time)); // Convert string to timestamp          
          $cert_schedule->schedule_desc = $schedule_desc;
          $cert_schedule->approve_all = $eligible_all ?? 0;
  
          // Approve students: ["46", "47"]
          $cert_schedule->approve_stud = json_encode($studentIds);
  
          // Approve check: [{"Id": "46", "eligible": 1}, {"Id": "47", "eligible": 1}]
          $cert_schedule->approve_chk = json_encode($studentEligible);
  
          // Set the reason if provided
          $cert_schedule->approve_reason = empty($reason) ? null : json_encode($reason);
          $cert_schedule->cert_status_id = 3;
          $cert_schedule->cert_receive_date = date('Y-m-d');
  
          // Calculate the count of eligible students
          $confirm_stud_count = count($studentIds); // Confirm count will be based on the student IDs in approve_stud
          $cert_schedule->confirm_stud_count = $confirm_stud_count;
  
          // Return the cert_schedule for debugging (optional)
        //   return $cert_schedule;
  
          // Update the cert schedule in the database
          if ($cert_schedule->update()) {
              $manage_cert_schedule = ManageCertificateModel::where('batch_id', $batch_id)->first();
              if ($manage_cert_schedule) {
                  // Update ManageCertificateModel
                  $manage_cert_schedule->cert_status_id = 3;
                  $manage_cert_schedule->cert_receive_date = date('Y-m-d');
                  $manage_cert_schedule->confirm_stud_count = $confirm_stud_count;
  
                  // Check if update was successful
                  if ($manage_cert_schedule->update()) {
                      session()->flash('toastr', [
                          'type' => 'success',
                          'message' => 'Schedule Time and status updated successfully!'
                      ]);
                  } else {
                      session()->flash('toastr', [
                          'type' => 'error',
                          'message' => 'Failed to update status in ManageCertificateModel!'
                      ]);
                  }
              }
          } else {
              session()->flash('toastr', [
                  'type' => 'error',
                  'message' => 'Could not update the Schedule time in CertificateAuthorityModel!'
              ]);
          }
      }
  
      return redirect()->back();
  }
  

    public function View($id = '', Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // dd($decryptedValue);


        // Find the Certificate  by decrypted ID
        $certificate = ManageCertificateModel::select(
            'za_manage_certificate.*',
            'za_slot.slot_name',
            'za_batch.batch_name',
            'za_batch.created_at as batch_created',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_batch.max_students',
            'za_course.course_name',
            'za_course.course_version',
            'za_course_type.course_type_name',
            'za_course_type.course_days',
            'za_class_room.class_room_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_certificate_status.certificate_status_name',
            'za_certificate_status.bg_color as cert_status_bg',
            'za_certificate_status.text_color as cert_status_text',
            'za_certificate_authority_status.certificate_authority_status_name',
            'za_certificate_authority_status.bg_color as authority_status_bg',
            'za_certificate_authority_status.text_color as authority_status_text',
            'created_by_staff.staff_name as created_by_staff_name' // New staff name for created_by
            )
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
            ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
            ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_staff as created_by_staff', 'created_by_staff.sno', '=', 'za_manage_certificate.updated_by')
            ->where('za_manage_certificate.status', '!=', 2)
            ->where('za_manage_certificate.branch_id',$branch_id)
            ->where('za_manage_certificate.batch_id', $decryptedValue)
            ->first();

            // Check if certificate was found
            if (!$certificate) {
                return redirect()->back()->with('error', 'Certificate View not found');
        }

        $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
            ->where('za_training.status', 0)
            ->distinct('customer_id') 
        ->count('customer_id'); 

       // First, retrieve all eligible student IDs from the JSON
        $eligibleIds = DB::table('za_certificate_authority')
        ->select('approve_stud')
        ->get()
        ->pluck('approve_stud')
        ->map(function ($json) {
            // Decode the JSON string
            return json_decode($json, true);
        })
        ->flatten() // Flatten the array of arrays into a single array
        ->unique() // Remove duplicates if necessary
        ->toArray();

        // Then, query the costing details
        $costingDetails = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
        ->where('za_training.status', 0)
        ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->whereIn('za_training.customer_id', $eligibleIds)
        ->select(
            'za_training.batch_id',
            'za_training.customer_id',
            'za_customer.sno as customer_sno',
            'za_customer.cus_name',
            'za_customer.cus_pic',
            'za_customer.cus_gender',
            'za_customer.customer_id as cus_id',
        )
        ->get();

        
        $courier_list = CourierModel::select('*')->where('status', '!=', 2)->get();

        // return $courier_list;
        // Enhance costing details with student status information
        $costingDetailsWithStatus = $costingDetails->map(function ($costingDetail) use ($courier_list) {
            $studentStatuses = DB::table('za_certificate_authority')
                ->select('approve_stud')
                ->get()
                ->pluck('approve_stud')
                ->map(function ($json) {
                    // Decode the JSON string
                    return json_decode($json, true);
                })
                ->flatten() // Flatten the array of arrays into a single array
                ->unique() // Remove duplicates if necessary
                ->toArray();

                // return $studentStatuses;

                $studentStatus = DB::table('za_certificate_distribution')
                ->select('student_status')
                ->get()
                ->pluck('student_status')
                ->map(function ($json) {
                    return json_decode($json, true);
                })
                ->flatten(1) // Flatten the JSON array
                ->filter(function ($status) use ($costingDetail) {
                    // Check if eligible_stud_id matches customer_id
                    return isset($status['eligible_stud_id']) && $status['eligible_stud_id'] == $costingDetail->customer_id;
                })
                ->unique('eligible_stud_id'); // Ensure unique student records


            // Attach the first matching student status
            $firstStatus = $studentStatus->first();

            if ($firstStatus) {
                $costingDetail->student_status = $firstStatus;
                $costingDetail->student_status = $firstStatus['status'] ?? null;
                $costingDetail->courier_id = $firstStatus['courier_id'] ?? null;
                $costingDetail->courier_add = $firstStatus['courier_add'] ?? null;

                // Now, get the courier name by matching courier_id
                $courier = $courier_list->firstWhere('sno', $firstStatus['courier_name']);

                if ($courier) {
                    $costingDetail->courier_name = $courier->courier_name; // Set the courier name from the list
                } else {
                    $costingDetail->courier_name = '-'; // Set to null if no matching courier is found
                }
            }

            return $costingDetail;
        });

        // return $costingDetailsWithStatus;

        $collectedDate = DB::table('za_certificate_distribution')->select('*')->first();

        $lists = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
        ->where('za_training.status', 0)
        ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
        ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
        ->get();

        // return $costingDetailsWithStatus;

        $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$certificate->batch_id)->where('status', 0)->first();

        return view('content.courses.certificate_authority.view', [
            'view' => $certificate,
            'stud_view' => $totalStudents,
            'status' => $costingDetailsWithStatus,
            'collected_date' => $collectedDate,
            'stud_list' => $lists,
            'checked' => $eligibleList
        ]);
    }

    public function approveCert($id, Request $request) 
    {
        $branch_id = $request->user()->branch_id;
        // return $id;

        $certificate = CertificateAuthorityModel::select(
            'za_certificate_authority.*',
            'za_slot.slot_name',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_batch.max_students',
            'za_batch.checklist',
            'za_batch.created_at as batch_created',
            'za_course.course_name',
            'za_course.course_version',
            'za_course_type.course_type_name',
            'za_course_type.course_days',
            'za_class_room.class_room_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_certificate_status.certificate_status_name',
            'za_certificate_status.bg_color as cert_status_bg',
            'za_certificate_status.text_color as cert_status_text',
            'za_certificate_authority_status.certificate_authority_status_name',
            'za_certificate_authority_status.bg_color as authority_status_bg',
            'za_certificate_authority_status.text_color as authority_status_text',
            'za_manage_certificate.req_stud_count',
            'za_manage_certificate.batch_cmpltd_date',
            'za_manage_certificate.req_cert_date',
            )
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_certificate_authority.batch_id')
            ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_certificate_authority.cert_status_id')
            ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_certificate_authority.certificate_authority_status_id')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftJoin('za_manage_certificate', 'za_manage_certificate.sno', '=', 'za_certificate_authority.manage_cert_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_certificate_authority.status', '!=', 2)
            ->where('za_certificate_authority.branch_id', '=', $branch_id)->where('za_certificate_authority.batch_id', $id)->first();

        if (!$certificate) {
            return redirect()->back()->with('error', 'Certificate Request not found');
        }
        // return $certificate;
      
        $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
        ->count('za_training.customer_id'); 

        $requestedStudents = $certificate->req_stud_count;

        $arrayOfStudentIds = RequestCertificateModel::select('za_request_certificate.student_id')
            ->where('status', 0)
            ->get()
            ->pluck('student_id');  // Extracting student IDs as an array
        
        // return $arrayOfStudentIds;
        
        // Check if there are no student IDs in the array
        if ($arrayOfStudentIds->isEmpty()) {
            // Return 0 or any other response you prefer
            return response()->json(['status' => 0, 'message' => 'No students found']);
        }
        
        // Proceed with fetching the list of students based on the student IDs
        $lists = RequestCertificateModel::where('za_request_certificate.batch_id', $certificate->batch_id)
            ->where('za_request_certificate.status', 0)
            ->join('za_training', 'za_request_certificate.batch_id', '=', 'za_training.batch_id')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->select(
                'za_customer.sno',
                'za_customer.cus_name',
                'za_customer.cus_pic',
                'za_customer.customer_id',
                'za_customer.cus_gender',
                'za_request_certificate.student_id',
                'za_training.customer_id as training_customer_id'
            )
            ->whereIn('za_request_certificate.student_id', $arrayOfStudentIds) // Filter by student IDs
            ->distinct('za_training.customer_id')
            ->get();

        // return $lists;
        
        // If no records are found after the query, return 0
        if ($lists->isEmpty()) {
            return response()->json(['status' => 0, 'message' => 'No records found for the selected students']);
        }
        
        // Filter the list based on student eligibility and matching Id
        $filteredLists = $lists->filter(function ($item) {
            // Decode the JSON string of student_id into an array
            $studentIds = is_string($item->student_id) ? json_decode($item->student_id, true) : $item->student_id;
        
            // Ensure $studentIds is an array and process the check for eligible students
            if (is_array($studentIds)) {
                // Look for a matching student ID with "eligible" value as 1
                foreach ($studentIds as $student) {
                    if (isset($student['Id']) && isset($student['eligible']) && $student['eligible'] == '1') {
                        // If the student is eligible and the Id matches, filter it in
                        if ($student['Id'] == $item->training_customer_id) {
                            return true;
                        }
                    }
                }
            }
            return false;  // If no match or eligibility condition fails, exclude this item
        });
        
        // return $filteredLists;
    
        return response([
            'status' => 200,
            'message' => 'Certificate Approved Status Successfully Updated!',
            'error_msg' => '',
            'data' => $certificate,
            'total_stud_count' => $totalStudents,
            'req_stud_count' => $requestedStudents,
            'stud_list' =>$filteredLists->toArray()
        ], 200);
    }

    public function PrintCertiifcate($id, Request $request)
    {
      
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      // return $decryptedValue;
  
      list($batch_id, $cus_id) = explode('~', $decryptedValue);
      // return $cus_id;
  
      $customerDetails = TrainingModel::select('za_training.*','za_customer.*', 'za_branch.branch_name', 'za_branch.franchise_name','za_branch.branch_head_name','za_branch.branch_head_sign','za_branch.cert_auth_name','za_branch.cert_auth_sign', 'za_course.course_name', 'za_course.sno as course_sno', 'za_batch.start_date', 'za_batch.end_date', 'za_batch.sno as batch_sno')
          ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
          ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
          ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
          ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
          ->where('za_training.customer_id', $cus_id)
          ->where('za_training.batch_id', $batch_id)
          ->where('za_customer.status', 0)
          ->first();
  
      $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$batch_id)->where('status', 0)->first();
      //  return $eligibleList;
  
      $scoreList = json_decode($eligibleList->student_id);
      // return $scoreList;
      // Initialize score and grade variables
      $score = 0;
      $grade = '';
  
      // Find the matching student by Id
      foreach ($scoreList as $student) {
          if ($student->Id == $cus_id) {
              // If a match is found, assign score and grade
              $score = $student->score;
              $grade = $student->grade;
              break; // Exit the loop once the student is found
          }
      }
  
      // Store the score and grade in the customer details object
      if ($customerDetails) {
          $customerDetails->score = $score;
          $customerDetails->grade = $grade;
      }
  
      // return $customerDetails;
  
      
      return view('content.courses.manage_certificate.course_completed_certificate', [
          'customerDetails' => $customerDetails
      ]);
    }
    
    public function cusScoreDetails($id, Request $request)
    {
        $cus_id = $id;
        $batch_id = $request->input('batch_id');
  
        $branch_id = $request->user()->branch_id;
  
        $customerDetails = TrainingModel::select('za_training.branch_id','za_training.batch_id', 'za_training.course_id', 'za_staff.gender',
          'za_training.staff_id','za_staff.staff_name','za_staff.mobile_no','za_staff.staff_image', 
          'za_staff.nick_name', 'za_customer.sno as cus_sno',
          'za_training.customer_id','za_customer.cus_name', 'za_course.course_type_id',
          'za_customer.customer_id', 'za_course.course_name','za_course_type.course_type_name',
          'za_batch.start_date', 'za_batch.end_date', 'za_batch.batch_name')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_staff', 'za_training.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
        ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_training.customer_id', $cus_id)
        ->where('za_training.batch_id', $batch_id)
        ->where('za_customer.status', 0)
        ->first();
  
        
          // return $eligibleList;
      
          $attendance = AttendanceModel::select('*')
          ->whereBetween('att_date', [$customerDetails->start_date, $customerDetails->end_date])
          ->where('batch_id', $batch_id)
          ->where('customer_id', $cus_id)
          ->get();
  
        //   $startDate = Carbon::parse($customerDetails->start_date);
        //   $endDate = Carbon::parse($customerDetails->end_date);
        //   $totalDays = $startDate->diffInDays($endDate) + 1; // +1 to include the start date
          // return $totalDays;
          
           $totalDays = $attendance->count();
           
          $presentDays = $attendance->whereIn('attendance', ['P', 'HD'])->count();
  
          $attendancePercentage = ($totalDays > 0) ? ($presentDays / $totalDays) * 100 : 0;
  
          $attendancePercentage = round($attendancePercentage);
          // return $attendancePercentage;
  
        //   $course = ManageCoursesSyllabusModel::where('course_id', $customerDetails->course_id)->count('topic_id');
  
        //   // Step 2: Get the number of topics covered in the batch
        //   $syllabus = SyllabusUpdateModel::where('batch_id', $batch_id)
        //       ->where('course_id', $customerDetails->course_id)
        //       ->count('topic_id');
          
        //   // Step 3: Calculate the percentage
        //   $percentage = 0;
          
        //   if ($course > 0) {
        //       if ($course == $syllabus) {
        //           $percentage = 100; // If both counts are the same, it's 100%
        //       } else {
        //           $percentage = ($syllabus / $course) * 100; // Calculate percentage
        //       }
        //   }
  
        //   $percentage = round($percentage);
  
  
          $course = ManageCoursesSyllabusModel::where('course_id', $customerDetails->course_id)
            ->count('topic_id');
        // Get the number of topics covered in the batch
        $syllabus = SyllabusUpdateModel::where('batch_id', $batch_id)
            ->where('course_id', $customerDetails->course_id)
            ->count('topic_id');
        $percentage = 0;
        if ($course > 0) {
            $percentage = ($syllabus / $course) * 100;
        }
        // Round and ensure it never exceeds 100
        $percentage = min(100, round($percentage));
          // return $percentage;
  
          $payment = TrainingModel::select('*')
          ->where('batch_id', $batch_id)
          ->where('customer_id', $cus_id)
          ->get();
      
          // Step 2: Initialize payment percentage
          $paymentPercentage = 0;
          
          foreach ($payment as $p) {
              // Step 3: Check if balance_amount is 0 (fully paid)
              if ($p->balance_amount == 0) {
                  $paymentPercentage = 100; // Fully paid
              } else {
                  // Step 4: Calculate payment percentage based on paid_amount and total_amount
                  $paymentPercentage = ($p->paid_amount / $p->total_amount) * 100;
              }
          }
          $paymentPercentage = round($paymentPercentage); 
  
          // return $paymentPercentage;
  
          $exam_person = Student::select(
                      'students.id',
                      'students.exam_status',
                      'students.branch_id',
                      'students.user_name',
                      'students.email_id',
                      'students.phone_no',
                      'students.type',
                      'students.place_name',
                      'za_staff.staff_name',
                      'za_staff.nick_name',
                      'za_staff.staff_image',
                      'students.staff_id'
                  )
                  ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
                  ->where('students.status', 0)
                  ->where('students.id', $cus_id)
                  ->first();
  
          // Process exam_status JSON
          if ($exam_person) {
          $exams = json_decode($exam_person->exam_status, true);
          }else{
              $exams = [];
          }
          $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();
  
          // Calculate the number of exams
          if ($exam_person) {
              $total_exams = is_array($exams) ? count($exams) : 0;
              $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
              $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;
          
              // Add the counts to $exam_person
              $exam_person->total_exam = sprintf('%02d', $total_exams);
              $exam_person->completed_exam = sprintf('%02d', $completed_exams);
              $exam_person->balance_exam = sprintf('%02d', $balance_exams);
          } 
              // $total_exams = is_array($exams) ? count($exams) : 0;
              // $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
              // $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;
          
              // Add the counts to $exam_person
              // $exam_person->total_exam = sprintf('%02d', $total_exams);
              // $exam_person->completed_exam = sprintf('%02d', $completed_exams);
              // $exam_person->balance_exam = sprintf('%02d', $balance_exams);
          if($exam_person){
              // Fetch exam list related to this student
              $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
              $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();
          
              // Merge both lists while keeping all records from ExamModel
              $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
                  // Get the corresponding process entry for this exam
                  $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
                  return [
                      'exam_id' => $exam->sno,
                      'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
                      'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
                      'certificate' => $exam->certificate ?? null, // Adjust field names as needed
                      'device_type' => $exam_process->device_type ?? 2,
                      'student_marks' => $exam_process->student_marks ?? null,
                      'updated_at' => $exam_process->updated_at ?? null,
                      'exam_status' => $exam_process->status ?? 1,
                      'student_id' => $exam_process->student_id ?? null,
                  ];
              });
          
  
              // Calculate total marks and student marks for exams that are completed (exam_status == 2)
              $total_marks = 0;
              $total_student_marks = 0;
              if($exam_list){
                  foreach ($exam_list as $exam) {
                      if ($exam['exam_status'] == 2) {  // Only include exams that are completed
                          $total_marks += $exam['total_marks'];
                          $total_student_marks += $exam['student_marks'] ?? 0;
                      }
                  }
              }
          
              // Calculate the percentage
              $examPercentage = 0;
              if ($total_marks > 0) {
                  $examPercentage = ($total_student_marks / $total_marks) * 100;
                  $examPercentage = round($examPercentage);
              }
          } else{
              $examPercentage = 0;
          }
          
          // Prepare the result
          // $response = [
          //     'exam_person' => $exam_person,
          //     'exam_list' => $exam_list,  // Exam list with all details
          //     'total_marks' => $total_marks,
          //     'total_student_marks' => $total_student_marks,
          //     'balance_exam' => $balance_exams,
          //     'examPercentage' => $examPercentage,
          // ];
  
          // return $percentage;
      
          // Fetch the checklist items
          $checklist = CertificateChecklistModel::where('status', 0)->get();
      
          // Map the percentage values to the corresponding checklist
          $checklistWithPercentages = $checklist->map(function ($item) use ($attendancePercentage, $percentage, $paymentPercentage, $examPercentage) {
              switch ($item->sno) {
                  case 4:
                      $item->percentage = $attendancePercentage;
                      break;
                  case 3:
                      $item->percentage = $percentage;
                      break;
                  case 5:
                      $item->percentage = $paymentPercentage;
                      break;
                  case 1:
                      $item->percentage = 100;
                      break;
                  default:
                      $item->percentage = 0;
                      break;
              }
              return $item;
          });
  
          //  return $checklistWithPercentages;
  
          // $checked = ($list->sno == 4 && isset($attendanceMap[$s_list->sno])) ? 'checked' : '';
          // $checkedPay = ($list->sno == 5 && in_array($s_list->sno, $paymentCustomerIds)) ? 'checked' : '';
          // $checkedCourse = ($list->sno == 3 && $course == $syllabus) ? 'checked' : '';
  
        //   return $cus_id;
        // You can process the data here and return a response
        return response()->json([
            'message' => 'Data received successfully',
            'cus_id' => $cus_id,
            'batch_id' => $batch_id,
            'cus_details' => $customerDetails,
            'attendance_percentage' => $attendancePercentage,
            'syllabus_percentage' => $percentage,
            'payment_percentage' => $paymentPercentage,
            'exam_Percentage' => $examPercentage,
            'checklistPercentage' => $checklistWithPercentages,
        ]);
    }
     
      
      public function AddScore(Request $request)
    {
        $certificateRequest = RequestCertificateModel::where('batch_id', $request->batch_id_score)->first();
        $studentEligible = json_decode($certificateRequest->student_id, true); // Assumes this is an array
        $certificate_no_list = isset($certificateRequest->certificate_no) && !empty($certificateRequest->certificate_no) ? json_decode($certificateRequest->certificate_no, true) : []; // Assumes this is an array

        $additionalData = [
            'score' => $request->customer_score, // Assuming you get score in the request
            'grade' => $request->grade_hidden,   // Assuming you get grade in the request
        ];

        // Loop through the students and only update the relevant one
        foreach ($studentEligible as &$student) {

            // Check if the student ID matches the one you want to update
            if ((int) $student['Id'] == (int) $request->cus_sno_score) {

                $certificate_no = $this->generateCertificateNo('za_request_certificate', 3, 5);

                $certificate_no_list[] = ['student_id' => $student['Id'], 'certificate_no' => $certificate_no];

                // Merge the score and grade with the specific student
                $student = array_merge($student, $additionalData);
                break; // Exit the loop once the correct student is found and updated
            }

        }

        // return $studentEligible;
        $studentEligibleJson = json_encode($studentEligible);
        $certificate_detailsJson = !empty($certificate_no_list) ? json_encode($certificate_no_list) : NULL;

        if (!$certificateRequest) {
            // Create a new certificate request if it doesn't exist
            $certificateRequest = new RequestCertificateModel();
            $certificateRequest->branch_id = $request->branch_id;
            $certificateRequest->batch_id = $request->batch_id_score;
            $certificateRequest->student_id = $studentEligibleJson; // Store the updated student data
            $certificateRequest->certificate_no = $certificate_detailsJson; // Store the updated student data
            $certificateRequest->created_at = now();
            $certificateRequest->created_by = $request->user()->user_id;
            $certificateRequest->updated_at = now();
            $certificateRequest->updated_by = $request->user()->user_id;
            $certificateRequest->status = 0;

            $certificateRequest->save();
        } else {
            // Update the existing certificate request if it exists
            $certificateRequest->student_id = $studentEligibleJson; // Store the updated student da
            $certificateRequest->certificate_no = $certificate_detailsJson; // Store the updated student data
            $certificateRequest->updated_at = now();
            $certificateRequest->updated_by = $request->user()->user_id;

            $certificateRequest->save(); // Using save instead of update to ensure the model is saved
        }

        // Flash success or failure message
        if ($certificateRequest) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Score Added Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the score!',
            ]);
        }

        return redirect()->back()->with('success', 'Score Added successfully!');
    }

      // public function generatePDF()
      // {
      //     $data = ['title' => 'Welcome to Laravel PDF'];
      //     $pdf = PDF::loadView('pdf.document', $data);
      //     return $pdf->download('document.pdf');
      // }
  
      
    public function generateCertificatePdf($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
        list($batch_id, $cus_id) = explode('~', $decryptedValue);

        // return $cus_id;
    
        // Fetch Customer & Training Details
        $customerDetails = TrainingModel::select(
            'za_training.*', 'za_customer.*', 'za_branch.branch_type',
            'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_head_name',
            'za_branch.branch_head_sign', 'za_branch.cert_auth_name', 'za_branch.cert_auth_sign', 
            'za_course.course_name', 'za_batch.start_date', 'za_batch.end_date'
        )
        ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
        ->where('za_training.customer_id', $cus_id)
        ->where('za_training.batch_id', $batch_id)
        ->where('za_customer.status', 0)
        ->first();

            //    return $customerDetails;
    
        // Fetch Eligible Students for Certificate
        $eligibleList = RequestCertificateModel::where('batch_id', $batch_id)->where('status', 0)->first();
    
        if (!$eligibleList) {
            return back()->with('error', 'No certificate request found for this batch.');
        }
    
        // ✅ Decode as associative array to avoid stdClass error
        $scoreList = json_decode($eligibleList->student_id, true);  
    
        $score = 0;
        $grade = '';
    
        foreach ($scoreList as $student) {
            if (isset($student['Id']) && $student['Id'] == $cus_id) {  
                $score = $student['score'] ?? 0;  // Prevent undefined index error
                $grade = $student['grade'] ?? ''; 
                break;
            }
        }
    
         // Decode certificate_no JSON as associative array
        $certList = !empty($eligibleList->certificate_no)
            ? json_decode($eligibleList->certificate_no, true)
            : [];
 
        // Default
        $certificateNo = null;
 
        // Loop & extract certificate_no
        foreach ($certList as $cert) {
            if (isset($cert['certificate_no'])) {
                $certificateNo = $cert['certificate_no'];
                break; // first match only
            }
        }
        if ($customerDetails) {
            $customerDetails->score = $score;
            $customerDetails->grade = $grade;
            $customerDetails->certificateID = $certificateNo;
        }

        if ($customerDetails) {
            $batch_id = $batch_id;
            $customer_id = $cus_id;

            // Combine with ~
            $qr_id = $batch_id . '~' . $customer_id;

            // Encrypt the combined string
            $encryptedValue = $helper->encrypt_decrypt($qr_id, 'encrypt');

            // Prepare the full URL
            $baseUrl = "https://erp.elysium.academy";// Update this with your actual domain
            $qrContent = $baseUrl . "/verified/" . urlencode($encryptedValue);
            
        
            // $qrContent = "Batch Id         : {$batch_id}\n"
            //           . "Customer Id   : {$customer_id}\n"
            //           . "Certificate  : Verified";

            /// Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
            
            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?
            
            // RECOMMENDED: Use API from https://api.qrserver.com/
            
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
            
            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }


        //   return view('content.courses.manage_certificate.course_completed_certificate_download',[
        //         'customerDetails' => $customerDetails,
        //         'qrBase64' => $qrBase64
        //         ]);
        
         $pdf = PDF::loadView('content.courses.manage_certificate.course_completed_certificate_download', [
                'customerDetails' => $customerDetails,
                'qrBase64' => $qrBase64 
            ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)  
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
            // return $pdf;  
             return $pdf->download('certificate.pdf');  

        
            // Now for saving the certificate PDF
            $fileDir = public_path('assets/eapl_images/certificates');  // Directory where the certificate will be saved

            // Check if the directory exists; if not, create it
            if (!file_exists($fileDir)) {
                mkdir($fileDir, 0755, true);  // Create the directory if it does not exist
            }

            // Define the certificate file name
            $fileName = 'test_certificate.pdf';  // Replace $cus_id with the customer ID or your dynamic identifier
            $filePath = $fileDir . '/' . $fileName;

            // Save the generated PDF to the file path
            $pdf->save($filePath);
            
                // Update the certificate request in the database
                $certificateRequest = RequestCertificateModel::where('batch_id', $batch_id)->first();

                if ($certificateRequest) {
                    $studentEligible = json_decode($certificateRequest->student_id, true);
                    
                    foreach ($studentEligible as &$student) {
                        if (isset($student['Id']) && $student['Id'] == $cus_id) {
                            $student['certificate_pdf'] = $fileName;  // Save the certificate filename
                        }
                    }

                    $certificateRequest->student_id = json_encode($studentEligible);
                    $certificateRequest->updated_at = now();
                    $certificateRequest->updated_by = $request->user()->user_id;
                    $certificateRequest->save();
                // }

                // Optional: Flash message to confirm success
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Certificate Generated Successfully!',
                ]);

            // Return the PDF download link
                return $pdf->download('certificate.pdf');  
                    
            }
    }
        //   public function generatePDF()
        //   {
        //       $data = ['title' => 'domPDF in Laravel 10'];
        //       $pdf = PDF::loadView('content.courses.manage_certificate.document', $data);
        //       return $pdf->download('document.pdf');
        //   }
        
        
    //     public function CertificatePrint($id, Request $request)

    //  {

    //     $helper = new \App\Helpers\Helpers();
    //     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
    //     // return $decryptedValue;
    
     
    
    //     list($batch_id, $cus_id) = explode('~', $decryptedValue);
    
     
    
    //     // Fetch Customer & Training Details
    
    //     $customerDetails = TrainingModel::select(
    
    //       'za_training.*',
    
    //       'za_customer.*',
    
    //       'za_branch.branch_type',
    
    //       'za_branch.branch_name',
    
    //       'za_branch.franchise_name',
    
    //       'za_branch.branch_head_name',
    
    //       'za_branch.branch_head_sign',
    
    //       'za_branch.cert_auth_name',
    
    //       'za_branch.cert_auth_sign',
    
    //       'za_course.course_name',
    
    //       'za_batch.start_date',
    
    //       'za_batch.end_date'
    
    //     )
    
    //       ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
    
    //       ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
    
    //       ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
    
    //       ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
    
    //       ->where('za_training.customer_id', $cus_id)
    
    //       ->where('za_training.batch_id', $batch_id)
    
    //       ->where('za_customer.status', 0)
    
    //       ->first();
    
     
    
    //     //    return $customerDetails;
    
     
    
    //     // Fetch Eligible Students for Certificate
    
    //     $eligibleList = RequestCertificateModel::where('batch_id', $batch_id)->where('status', 0)->first();
    
     
    
    //     if (!$eligibleList) {
    
    //       return back()->with('error', 'No certificate request found for this batch.');
    
    //     }
    
     
    
    //     // ✅ Decode as associative array to avoid stdClass error
    
    //     $scoreList = json_decode($eligibleList->student_id, true);
    
     
    
    //     $score = 0;
    
    //     $grade = '';
    
     
    
    //     foreach ($scoreList as $student) {
    
    //       if (isset($student['Id']) && $student['Id'] == $cus_id) {
    
    //         $score = $student['score'] ?? 0;  // Prevent undefined index error
    
    //         $grade = $student['grade'] ?? '';
    
    //         break;
    
    //       }
    
    //     }
    
    //     // Decode certificate_no JSON as associative array
    
    //     $certList = !empty($eligibleList->certificate_no)
    
    //       ? json_decode($eligibleList->certificate_no, true)
    
    //       : [];
    
     
    
    //     // Default
    
    //     $certificateNo = null;
    
     
    
    //     // Loop & extract certificate_no
    
    //     foreach ($certList as $cert) {
    
    //       if (isset($cert['certificate_no'])) {
    
    //         $certificateNo = $cert['certificate_no'];
    
    //         break; // first match only
    
    //       }
    
    //     }
    
    //     if ($customerDetails) {
    
    //       $customerDetails->score = $score;
    
    //       $customerDetails->grade = $grade;
    
    //       $customerDetails->certificateID = $certificateNo;
    
    //     }
    
     
    
    //     if ($customerDetails) {
    
    //       $batch_id = $batch_id;
    //       $customer_id = $cus_id;
    
    //       // Combine with ~
    
    //       $qr_id = $batch_id . '~' . $customer_id;
    
     
    
    //       // Encrypt the combined string
    //       $encryptedValue = $helper->encrypt_decrypt($qr_id, 'encrypt');
    
    //       // Prepare the full URL
    //       $baseUrl = "https://erp.elysium.academy"; // Update this with your actual domain
    
    //       $qrContent = $baseUrl . "/verified/" . urlencode($encryptedValue);
    
     
    
    //       /// Create QR using PHP without installation
    
    //       $qrImage = imagecreate(200, 200);
    
    //       $white = imagecolorallocate($qrImage, 255, 255, 255);
    
    //       $black = imagecolorallocate($qrImage, 0, 0, 0);
    
    //       imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
    
     
    
    //       // Just a placeholder pattern (real QR not generated like this)
    
    //       // Since you don't want to install any package and can't rely on Google API,
    
    //       // we're forced to ask: are you open to use a **small local script** or CDN?
    
     
    
    //       // RECOMMENDED: Use API from https://api.qrserver.com/
    
    //       $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
    
     
    
    //       // Convert to base64
    //       $qrImageData = @file_get_contents($qrServerUrl);
    //       $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
    
    //     }
    
    
    //     return view('content.courses.certificate_authority.certificate_print', [
    //       'customerDetails' => $customerDetails,
    //       'qrBase64' => $qrBase64
    //     ]);

    // }
    
    public function CertificatePrint($id, Request $request)
  {
 
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
 
    list($batch_id, $cus_id) = explode('~', $decryptedValue);
 
    // Fetch Customer & Training Details
    $customerDetails = TrainingModel::select(
      'za_training.*',
      'za_customer.*',
      'za_branch.branch_type',
      'za_branch.branch_name',
      'za_branch.franchise_name',
      'za_branch.branch_head_name',
      'za_branch.branch_head_sign',
      'za_branch.cert_auth_name',
      'za_branch.cert_auth_sign',
      'za_course.course_name',
      'za_batch.start_date',
      'za_batch.end_date'
    )
      ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->where('za_training.customer_id', $cus_id)
      ->where('za_training.batch_id', $batch_id)
      ->where('za_customer.status', 0)
      ->first();
 
    //    return $customerDetails;
 
    // Fetch Eligible Students for Certificate
    $eligibleList = RequestCertificateModel::where('batch_id', $batch_id)->where('status', 0)->first();
 
    if (!$eligibleList) {
      return back()->with('error', 'No certificate request found for this batch.');
    }
 
    // ✅ Decode as associative array to avoid stdClass error
    $scoreList = json_decode($eligibleList->student_id, true);
 
    $score = 0;
    $grade = '';
 
    foreach ($scoreList as $student) {
      if (isset($student['Id']) && $student['Id'] == $cus_id) {
        $score = $student['score'] ?? 0;  // Prevent undefined index error
        $grade = $student['grade'] ?? '';
        break;
      }
    }
    // Decode certificate_no JSON as associative array
    $certList = !empty($eligibleList->certificate_no)
      ? json_decode($eligibleList->certificate_no, true)
      : [];
 
    // Default
    $certificateNo = null;
 
    // Loop & extract certificate_no
    foreach ($certList as $cert) {
      if (isset($cert['certificate_no'])) {
        $certificateNo = $cert['certificate_no'];
        break; // first match only
      }
    }
    if ($customerDetails) {
      $customerDetails->score = $score;
      $customerDetails->grade = $grade;
      $customerDetails->certificateID = $certificateNo;
    }
 
    if ($customerDetails) {
      $batch_id = $batch_id;
      $customer_id = $cus_id;
 
      // Combine with ~
      $qr_id = $batch_id . '~' . $customer_id;
 
      // Encrypt the combined string
      $encryptedValue = $helper->encrypt_decrypt($qr_id, 'encrypt');
 
      // Prepare the full URL
      $baseUrl = "https://erp.elysium.academy"; // Update this with your actual domain
      $qrContent = $baseUrl . "/verified/" . urlencode($encryptedValue);
 
 
      // $qrContent = "Batch Id         : {$batch_id}\n"
      //           . "Customer Id   : {$customer_id}\n"
      //           . "Certificate  : Verified";
 
      /// Create QR using PHP without installation
      $qrImage = imagecreate(200, 200);
      $white = imagecolorallocate($qrImage, 255, 255, 255);
      $black = imagecolorallocate($qrImage, 0, 0, 0);
      imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
 
      // Just a placeholder pattern (real QR not generated like this)
      // Since you don't want to install any package and can't rely on Google API,
      // we're forced to ask: are you open to use a **small local script** or CDN?
 
      // RECOMMENDED: Use API from https://api.qrserver.com/
 
      $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
 
      // Convert to base64
      $qrImageData = @file_get_contents($qrServerUrl);
      $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
    }
 
        DB::table('za_certificate_logs')->updateOrInsert(
 
            [
                'cus_id'   => $cus_id,
                'batch_id' => $batch_id,
            ],
 
            [
                'updated_at' => Carbon::now('Asia/Kolkata')
            ]
        );
 
        DB::table('za_certificate_logs')
            ->where('cus_id', $cus_id)
            ->where('batch_id', $batch_id)
            ->increment('download_count');
 
 
    return view('content.courses.certificate_authority.certificate_print', [
      'customerDetails' => $customerDetails,
      'qrBase64' => $qrBase64
    ]);
  }




        
      //Vasanth
      public function QrCertiifcate($id, Request $request)
      {
          
          // return $id;
          $helper = new \App\Helpers\Helpers();
          $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
          // return $decryptedValue;
      
          if (!$decryptedValue || strpos($decryptedValue, '~') === false) {
              abort(404, 'Invalid decrypted value');
          }
      
          list($batch_id, $cus_id ) = explode('~', $decryptedValue);
          // return $cus_id;
      
          $customerDetails = TrainingModel::select(
                  'za_training.*', 'za_customer.*', 'za_customer.sno AS cus_sno', 'za_customer.customer_id AS cus_id',
                  'za_branch.branch_name', 'za_branch.franchise_name', 
                  'za_branch.branch_head_name', 'za_branch.branch_head_sign', 
                  'za_branch.cert_auth_name', 'za_branch.cert_auth_sign', 
                  'za_course.course_name', 'za_course.course_days', 
                  'za_batch.slot_id', 'za_batch.start_date', 'za_batch.end_date'
              )
              ->leftJoin('za_branch', 'za_training.branch_id', '=', 'za_branch.sno')
              ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
              ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
              ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
              ->where('za_training.customer_id', $cus_id)
              ->where('za_training.batch_id', $batch_id)
              ->where('za_customer.status', 0)
              ->first();
          
          if (!$customerDetails) {
              abort(404, 'Customer details not found.');
          }
          
          // Convert start_date and end_date to Carbon objects
          $batchStartDate = Carbon::parse($customerDetails->start_date);
          $batchEndDate   = Carbon::parse($customerDetails->end_date);
          $currentDate    = $batchStartDate->copy();
          
          // Get the slot type details
          $slot = SlotModel::find($customerDetails->slot_id);
          $slotDays = json_decode($slot->slot_type_days, true) ?? []; // Ensure it's an array
          
          $totalWorkingDays = 0;
          while ($currentDate->lte($batchEndDate)) {
              if (in_array($currentDate->dayOfWeek, $slotDays)) {
                  $totalWorkingDays++;
              }
              $currentDate->addDay();
          }
          
          // Generate date list for the batch period
          $dates = [];
          $tempDate = $batchStartDate->copy();
          while ($tempDate->lte($batchEndDate)) {
              $dates[] = $tempDate->toDateString();
              $tempDate->addDay();
          }
          
          // Fetch attendance data for the customer in this batch
          $attendanceRecords = AttendanceModel::where('customer_id', $customerDetails->cus_sno)
              ->where('batch_id', $batch_id)
              ->get()
              ->groupBy('att_date');
          
          // Initialize attendance data
          $attendanceData = [];
          foreach ($dates as $date) {
              $attendanceData[$date] = optional(optional($attendanceRecords->get($date))->first())->attendance ?? '0';
          }
          
          // return $attendanceData;
          // Count attendance types
          $attendanceCount = array_count_values($attendanceData);
          $total_P = $attendanceCount['P'] ?? 0; // Present
          $total_L = $attendanceCount['L'] ?? 0; // Leave
          $total_A = $attendanceCount['A'] ?? 0; // Absent
          $total_H = $attendanceCount['H'] ?? 0; // Holiday
          
          // Calculate Attendance Percentage
          $total_Attended = $total_P; // Only 'P' is considered attended
          $total_UnAttended = $total_L + $total_A; // Only 'P' is considered attended
          $PresentattendancePercentage = ($totalWorkingDays > 0) ? round(($total_Attended / $totalWorkingDays) * 100, 2) : 0;
          $AbsentattendancePercentage  = ($totalWorkingDays > 0) ? round(($total_UnAttended / $totalWorkingDays) * 100, 2) : 0;
          
          
          
          $eligibleList = RequestCertificateModel::select('*')->where('za_request_certificate.batch_id',$batch_id)->where('status', 0)->first();
          
          if (!$eligibleList) {
              abort(404, 'Certificate details not found.');
          }
          
          $scoreList = json_decode($eligibleList->student_id);
          // return $scoreList;
          // Initialize score and grade variables
          $score = 0;
          $grade = '';
      
          // Find the matching student by Id
          foreach ($scoreList as $student) {
              if ($student->Id == $cus_id) {
                  // If a match is found, assign score and grade
                  $score = $student->score ?? 0;
                  $grade = $student->grade ?? '-'; 
                  break; // Exit the loop once the student is found
              }
          }
  
          $exam_person = Student::select(
              'students.id',
              'students.exam_status',
              'students.branch_id',
              'students.user_name',
              'students.email_id',
              'students.phone_no',
              'students.type',
              'students.place_name',
              'za_staff.staff_name',
              'za_staff.nick_name',
              'za_staff.staff_image',
              'students.staff_id'
          )
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'students.staff_id')
          ->where('students.status', 0)
          ->where('students.id', $cus_id)
          ->first();
  
          // return $exam_person;
  
          // Process exam_status JSON
          if ($exam_person) {
              $exams = json_decode($exam_person->exam_status, true);
          }else{
              $exams = [];
          }
  
          $exam_ids = collect($exams)->pluck('exam_id')->unique()->toArray();
  
          // return $exam_ids;
          $exam_list = [];
          // Calculate the number of exams
          if ($exam_person) {
             
              $total_exams = is_array($exams) ? count($exams) : 0;
              $completed_exams = is_array($exams) ? collect($exams)->where('exam_status', 2)->count() : 0;
              $balance_exams = is_array($exams) ? collect($exams)->where('exam_status', 0)->count() : 0;
  
              // Add the counts to $exam_person
              $exam_person->total_exam = sprintf('%02d', $total_exams);
              $exam_person->completed_exam = sprintf('%02d', $completed_exams);
              $exam_person->balance_exam = sprintf('%02d', $balance_exams);
              
              // Fetch exam list related to this student
              $exam_list_exam = ExamModel::whereIn('za_exam.sno', $exam_ids)->get();
              // return $exam_list_exam;
              $exam_list_process = ExamProcessModel::where('za_exam_process.student_id', $exam_person->id)->get();
  
              // Merge both lists while keeping all records from ExamModel
              $exam_list = $exam_list_exam->map(function ($exam) use ($exam_list_process) {
                  // Get the corresponding process entry for this exam
                  $exam_process = $exam_list_process->where('exam_id', $exam->sno)->first();
                  return [
                      'exam_id' => $exam->sno,
                      'exam_name' => $exam->exam_name ?? null, // Adjust field names as needed
                      'total_marks' => $exam->total_marks ?? 0, // Adjust field names as needed
                      'certificate' => $exam->certificate ?? null, // Adjust field names as needed
                      'device_type' => $exam_process->device_type ?? 2,
                      'student_marks' => $exam_process->student_marks ?? null,
                      'updated_at' => $exam_process->updated_at ?? null,
                      'exam_status' => $exam_process->status ?? 1,
                      'student_id' => $exam_process->student_id ?? null,
                      'attended_date' => $exam_process->created_at ?? null
                  ];
              });
              // return 'Exam List:' .$exam_list;
  
              // Calculate total marks and student marks for exams that are completed (exam_status == 2)
              $total_marks = 0;
              $total_student_marks = 0;
              if($exam_list){
                  foreach ($exam_list as $exam) {
                      if ($exam['exam_status'] == 2) {  // Only include exams that are completed
                          $total_marks += $exam['total_marks'];
                          $total_student_marks += $exam['student_marks'] ?? 0;
                      }
                  }
              }
          }
  
          // return $exam_person;
          // return $exam_list;
      
          // Store the score and grade in the customer details object
          if ($customerDetails) {
              $customerDetails->score = $score;
              $customerDetails->grade = $grade;
              $customerDetails->total_P = $total_P;
              $customerDetails->total_L = $total_L;
              $customerDetails->total_A = $total_A;
              $customerDetails->total_H = $total_H;
              $customerDetails->total_working_days = $totalWorkingDays;
              $customerDetails->PresentattendancePercentage = $PresentattendancePercentage . '%';
              $customerDetails->AbsentattendancePercentage = $AbsentattendancePercentage . '%';
              
          }
      
          // return $customerDetails;
      
          
          return view('content.courses.manage_certificate.qr_customer_certificate_view', [
              'customerDetails' => $customerDetails,
              'exam_list' =>  $exam_list,
              'exam_person' =>  $exam_person
          ]);
      }
      
      private function generateCertificateNo($table, $str_length, $num_length)
    {
        // Step 1: Get latest record
        $latestRecord = DB::table($table)->select('certificate_no')->orderByDesc('updated_at')->first();

        $maxNo = 0;

        if ($latestRecord && !empty($latestRecord->certificate_no)) {
            // Step 2: Decode JSON column
            $certificateArray = json_decode($latestRecord->certificate_no, true);

            if (is_array($certificateArray)) {
                foreach ($certificateArray as $cert) {
                    if (!empty($cert['certificate_no'])) {
                        // Extract numeric part
                        $numeric = preg_replace('/[^0-9]/', '', $cert['certificate_no']);
                        $maxNo = max($maxNo, intval($numeric));
                    }
                }
            }
        }

        // Step 3: Start from 1000 if no previous numbers
        if ($maxNo < 1000) {
            $maxNo = 999; // So that next = 1000
        }

        $nextNo = $maxNo + 1;

        // Step 4: Random prefix (A–Z)
        $prefix = '';
        for ($i = 0; $i < $str_length; $i++) {
            $prefix .= chr(rand(65, 90));
        }

        // Step 5: Format number
        $formattedNo = str_pad($nextNo, $num_length, '0', STR_PAD_LEFT);

        // Step 6: Combine prefix + number
        return $prefix . $formattedNo;
    }

public function QrCertiifcateVerify(Request $request)
  {
    return 'working';
  }
  
}