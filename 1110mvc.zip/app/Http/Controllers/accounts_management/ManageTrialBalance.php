<?php

namespace App\Http\Controllers\accounts_management;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\LedgerModel;
use App\Models\TransactionModel;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ManageTrialBalance extends Controller
{
    public function index(Request $request)
    {

        $branch_id = $request->user()->branch_id;
        
        $ledger_list = LedgerModel::where('status', 0)->where('sno', '>', 1)->orderBy('sno', 'desc')->get();
        
        $trans_list = TransactionModel::where('za_transaction.branch_id', $branch_id)
            ->select('za_transaction.*', 'za_ledger.ledger_name', 'za_ledger.sno as ledger_sno', 'za_subledger.subledger_name')
            ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
            ->leftJoin('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
            ->orderBy('za_transaction.sno', 'desc')
            ->where('za_ledger.status', 0)->where('za_ledger.sno', '>', 1)
            ->get();


        $sum_credit = TransactionModel::selectRaw('SUM(credit) AS total_credit')
            ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
            ->where('za_ledger.status', 0)->where('za_ledger.sno', '>', 1)->where('za_ledger.transection_type', 1)
            ->where('za_transaction.branch_id', $branch_id)
            ->first();

        $sum_debit = TransactionModel::selectRaw('SUM(debit) AS total_debit')
            ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
            ->where('za_transaction.branch_id', $branch_id)
            ->where('za_ledger.status', 0)->where('za_ledger.sno', '>', 1)->where('za_ledger.transection_type', 2)
            ->first();

        return view('content.accounts_management.manage_trial_balance.list', [
            'trans_list' => $trans_list,
            'sum_credit' => $sum_credit,
            'sum_debit' => $sum_debit,
        ]);
    }

    public function view_trial_balance(Request $request)
    {
        $trans_id = $request->input('trans_id'); // Get trans_id from the request

        // Fetch transaction details based on trans_id and branch_id
        $trans_list = TransactionModel::where('za_transaction.sno', $trans_id)
            ->select('za_transaction.*', 'za_ledger.ledger_name', 'za_ledger.sno as ledger_sno', 'za_subledger.subledger_name')
            ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
            ->leftJoin('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
            ->first();

        if ($trans_list) {

            $helper = new Helpers();
            $generalSettings = $helper->general_setting_data();
            $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

            // Format the transaction date if it's not empty
            if ($trans_list->transaction_date) {
                $trans_list->transaction_date = Carbon::parse($trans_list->transaction_date)->format($dateFormat);
            }

            return response()->json([
                'status' => 200,
                'message' => 'Transaction details fetched successfully.',
                'error_msg' => null,
                'data' => $trans_list,
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Transaction not found.',
                'error_msg' => 'No transaction found with the given ID.',
                'data' => null,
            ], 404);
        }
    }
}
