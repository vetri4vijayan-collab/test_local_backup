<?php

namespace App\Http\Controllers\accounts_management;

use App\Http\Controllers\Controller;
use App\Models\TransactionModel;
use App\Models\SubLedgerModel;
use App\Models\LedgerModel;
use App\Models\CustomerModel;
use App\Models\BranchModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class ManageDailyAccounts extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $ledger_fill = $request->ledger_fill ?? '';
    $sub_ledger_fill = $request->sub_ledger_fill ?? '';
    $ledger_acc_fill = $request->ledger_acc_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $filter_on = $request->filter_on ?? false;

    // Latest payment per customer
    $firstTrans = DB::table('za_transaction as t')
        ->select('t.trans_source_id as customer_id', DB::raw('MIN(t.sno) as first_sno'))
        ->where('t.branch_id', $branch_id)
        ->groupBy('t.trans_source_id');

    $trans_list = TransactionModel::where('za_transaction.branch_id', $branch_id)->select(
        'za_transaction.*',
        'za_ledger.ledger_name',
        'za_subledger.subledger_name',
        'za_customer.sno as customer_sno',
        DB::raw("
            CASE
                WHEN za_transaction.sno = first_trans.first_sno THEN 'New Paid'
                ELSE 'Harvesting Paid'
            END as payment_flag
        ")
    )
    ->leftjoin('za_customer', 'za_customer.customer_id', '=', 'za_transaction.trans_source_id')
    ->leftJoin('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
    ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_subledger.ledger_id')
    ->leftJoinSub($firstTrans, 'first_trans', function ($join) {
        $join->on('first_trans.customer_id', '=', 'za_transaction.trans_source_id');
    });

    // Branch filter
    if ($branch_id != 0) {
        $trans_list->where('za_transaction.branch_id', $branch_id);
    }

    // Date filtering logic
    if ($date_filter == "today") {

        $todayDate = date("Y-m-d");
        $trans_list->whereDate('za_transaction.created_at', $todayDate);

    } elseif ($date_filter == "week") {

        $today = date('l');
        if ($today == "Sunday") {
            $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
            $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $trans_list->whereBetween('za_transaction.created_at', [$weekFromDate, $weekToDate]);

    } elseif ($date_filter == "monthly") {

        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $trans_list->whereBetween('za_transaction.created_at', [$firstDayOfMonth, $lastDayOfMonth]);

    } elseif ($date_filter == "custom_date") {

        if ($from_date_filter && $to_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $trans_list->whereBetween('za_transaction.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $trans_list->where('za_transaction.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $trans_list->where('za_transaction.created_at', '<=', $toDate);
        }
    }

    // Other filters
    if ($ledger_fill) {
      $trans_list->where('za_transaction.ledger_id', $ledger_fill);
      return $trans_list;
    }

    if ($sub_ledger_fill) {
        $trans_list->where('za_transaction.subledger_id', $sub_ledger_fill);
    }

    if ($ledger_acc_fill) {
        $trans_list->where('za_transaction.transaction_name', $ledger_acc_fill);
    }

    $trans_list = $trans_list->orderBy('za_transaction.sno', 'desc')->get();

    $ledger_list = LedgerModel::where('status', 0)
        ->where('sno', '>', 1)
        ->orderBy('sno', 'desc')
        ->get();

    $sum_credit = TransactionModel::where('branch_id', $branch_id)->sum('credit');
    $sum_debit = TransactionModel::where('branch_id', $branch_id)->sum('debit');
    $sum_tax = TransactionModel::where('branch_id', $branch_id)->sum('tax');

    // return $request;
    return view('content.accounts_management.manage_daily_accounts.list', compact(
        'trans_list',
        'ledger_list',
        'sum_debit',
        'sum_credit',
        'sum_tax',
        'ledger_fill',
        'sub_ledger_fill',
        'ledger_acc_fill',
        'date_filter'
    ))->with('filter_on', true);
  }

  public function filter_account(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $ledger_fill = $request->ledger_fill ?? '';
    $sub_ledger_fill = $request->sub_ledger_fill ?? '';
    $ledger_acc_fill = $request->ledger_acc_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;

    // Subquery: latest paid payment per customer
    $latestPayment = DB::table('za_payment as p')
        ->select('p.customer_id', DB::raw('MAX(p.initialPayDate) as initialPayDate'))
        ->where('p.status', 1)
        ->groupBy('p.customer_id');

    $trans_list = TransactionModel::select(
            'za_transaction.*',
            'za_ledger.ledger_name',
            'za_subledger.subledger_name',
            'za_customer.sno as customer_sno',
            DB::raw("
                CASE
                    WHEN za_transaction.transaction_date <= latest_payment.initialPayDate THEN 'New Paid'
                    WHEN za_transaction.transaction_date > latest_payment.initialPayDate THEN 'Harvesting Paid'
                    ELSE 'Pending'
                END as payment_flag
            ")
        )
        ->leftjoin('za_customer', 'za_customer.customer_id', '=', 'za_transaction.trans_source_id')
        ->join('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
        ->join('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
        ->leftJoinSub($latestPayment, 'latest_payment', function($join){
            $join->on('latest_payment.customer_id', '=', 'za_customer.sno');
        })
        ->where('za_transaction.status', 1);

    // Branch filter
    if ($branch_id != 0) {
      $trans_list->where('za_transaction.branch_id', $branch_id);
    }

    // Date filtering logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $trans_list->whereDate('za_transaction.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $trans_list->whereBetween('za_transaction.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $trans_list->whereBetween('za_transaction.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $trans_list->whereBetween('za_transaction.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $trans_list->where('za_transaction.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $trans_list->where('za_transaction.created_at', '<=', $toDate);
      }
    }

    // Other filters
    if ($ledger_fill) {
      $trans_list->where('za_transaction.ledger_id', $ledger_fill);
    }
    if ($sub_ledger_fill) {
      $trans_list->where('za_transaction.subledger_id', $sub_ledger_fill);
    }
    if ($ledger_acc_fill) {
      $trans_list->where('za_transaction.transaction_name', $ledger_acc_fill);
    }

    $trans_list = $trans_list->orderBy('za_transaction.sno', 'desc')->get();

    $ledger_list = LedgerModel::where('status', 0)->orderBy('sno', 'desc')->get();

    $sum_credit = TransactionModel::where('branch_id', $branch_id)->where('status', 1)->sum('credit');
    $sum_debit = TransactionModel::where('branch_id', $branch_id)->where('status', 1)->sum('debit');

    return view('content.accounts_management.manage_daily_accounts.list', compact(
      'trans_list', 'ledger_list', 'sum_debit', 'sum_credit', 'ledger_fill', 'sub_ledger_fill', 'ledger_acc_fill', 'date_filter'
    ))->with('filter_on', true);
  }

  public function sub_ledger_List()
  {
    $id = $_GET['id'] ?? '';
    $sub_led_list = SubLedgerModel::where('status', 0)->where('ledger_id', $id)->where('ledger_id', '>', 1)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sub_led_list
    ], 200);
  }

  public function autocomplete(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $search = $request->get('term');
    // Use a closure to properly group the orWhere condition
    $results = CustomerModel::where(function ($query) use ($search) {
      $query->where('cus_name', 'LIKE', '%' . $search . '%')
        ->orWhere('customer_id', 'LIKE', '%' . $search . '%');
    })
      ->where('branch_id', $branch_id)
      ->get();

    return response()->json($results);
  }

  public function Add(Request $request)
  {

    // return $request;
    
    // Validate input
    $validator = Validator::make($request->all(), [
      'trans_source_id' => 'required',
      'cr_dr' => 'required',
      'ledger_amount_add' => 'required|numeric|min:0',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }

    // Process the transaction source ID
    $transaction_name = $request->trans_source_id;
    // $exp = explode('-', $trans_source_id);
    // $transaction_name = str_replace(' ', '', $exp[0] ?? '');
    // $trans_source_id = str_replace(' ', '', $exp[1] ?? '');

    // Fetch other details from the request
    $transaction_type = $request->cr_dr;
    $ledger_id = $request->ledger_id_add;
    $subledger_id = $request->subledger_id_add;
    $amount = $request->ledger_amount_add;
    $daily_desc = $request->daily_desc ?? '';
    $user = $request->user(); // Fetch user details only once
    $user_id = $user->user_id;
    $branch_id = $user->branch_id;
    $credit = 0;
    $debit = 0;
    if ($transaction_type == 'Credit') {
      $incr = 'CR';
      $credit = $amount;
    }
    if ($transaction_type == 'Debit') {
      $incr = 'DR';
      $debit = $amount;
    }
    // Fetch branch code
    $branch_check = BranchModel::find($branch_id);
    if (!$branch_check) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid Branch ID'
      ]);
      return redirect()->back();
    }
    $branch_code = $branch_check->city_short_code;

    // Check the last transaction and generate a new transaction ID
    $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
    if (!$tr_check) {
      $transaction_id = date("Y") . '/' . $branch_code . '/' . $incr . "0001";
    } else {
      $data = $tr_check->sno;
      $next_number = sprintf("%04d", (int)preg_replace('/[^0-9]/', '', $data) + 1);
      $transaction_id = date("Y") . '/' . $branch_code . '/' . $incr . $next_number;
    }

    // Check if the customer exists with the same branch and customer ID
    // $customer_check = CustomerModel::where('branch_id', $branch_id)
    //   ->where('customer_id', $trans_source_id)
    //   ->first();

    // if ($customer_check) {
      // Create new Transaction
      $transaction = new TransactionModel();
      $transaction->ledger_id = $ledger_id;
      $transaction->subledger_id = $subledger_id;
      $transaction->transaction_id = $transaction_id;
      $transaction->transaction_name = ucfirst($transaction_name);
      $transaction->trans_source_id = $transaction_id;
      $transaction->credit = $credit;
      $transaction->debit  = $debit;
      $transaction->total_amount = $amount;
      $transaction->tax = $amount * 0.18;
      $transaction->transaction_type = $transaction_type;
      $transaction->trans_desc = $daily_desc;
      $transaction->status = 1;
      $transaction->branch_id = $branch_id;
      $transaction->created_by = $user_id;
      $transaction->updated_by = $user_id;
      $transaction->daily_acc_chk =1;

      // Save and handle success/failure
      if ($transaction->save()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Daily Accounts added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Daily Accounts!'
        ]);
      }
    // } else {
    //   session()->flash('toastr', [
    //     'type' => 'error',
    //     'message' => 'Invalid Ledger Account!'
    //   ]);
    // }
    return redirect()->back();
  }

  public function edit($id)
  {

    $data = TransactionModel::select('za_transaction.*', 'za_ledger.ledger_name', 'za_subledger.subledger_name')
      ->join('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
      ->join('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
      ->where('za_transaction.sno', $id)
      ->first();

    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $data
    ], 200);
  }


  public function Update(Request $request)
  {

    // Validate input
    $validator = Validator::make($request->all(), [
      'trans_source_id_edit' => 'required',
      'cr_dr_edit' => 'required',
      'ledger_amount_edit' => 'required|numeric|min:0'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }
    $id = $request->edit_id;

    // Fetch existing transaction
    $transaction = TransactionModel::where('sno', $id)->first();

    if (!$transaction) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Transaction not found!'
      ]);
      // return redirect()->back();
    }

    // Process the transaction source ID
    $transaction_name = $request->trans_source_id_edit;
    // $exp = explode('-', $trans_source_id);
    // $transaction_name = str_replace(' ', '', $exp[0] ?? '');
    // $trans_source_id  = str_replace(' ', '', $exp[1] ?? '');

    // Fetch other details from the request
    $transaction_type = $request->cr_dr_edit;
    $ledger_id = $request->ledger_id_edit;
    $subledger_id = $request->subledger_id_edit;
    $amount = $request->ledger_amount_edit;
    $daily_desc = $request->daily_desc_edit ?? '';
    $user = $request->user();
    $user_id = $user->user_id;
    $branch_id = $user->branch_id;
    $daily_acc_chk = 1;
    $credit = 0;
    $debit = 0;
    if ($transaction_type == 'Credit') {
      $credit = $amount;
    }
    if ($transaction_type == 'Debit') {
      $debit = $amount;
    }

    // Check if the customer exists with the same branch and customer ID
    // $customer_check = CustomerModel::where('branch_id', $branch_id)
    //   ->where('customer_id', $trans_source_id)
    //   ->first();

    // if ($customer_check) {
      // Update Transaction
      $transaction->ledger_id = $ledger_id;
      $transaction->subledger_id = $subledger_id;
      $transaction->transaction_name = ucfirst($transaction_name);
      // $transaction->trans_source_id = $trans_source_id;
      $transaction->credit = $credit;
      $transaction->debit  = $debit;
      $transaction->total_amount = $amount;
      $transaction->tax = $amount * 0.18;
      $transaction->transaction_type = $transaction_type;
      $transaction->trans_desc = $daily_desc;
      $transaction->status = 1;
      $transaction->updated_by = $user_id;

      // Save and handle success/failure
      if ($transaction->save()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Daily Accounts updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Daily Accounts!'
        ]);
      }
    // } else {
    //   session()->flash('toastr', [
    //     'type' => 'error',
    //     'message' => 'Invalid Ledger Account!'
    //   ]);
    // }
    // return $customer_check;
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_TransactionModel = TransactionModel::where('sno', $id)->first();
    $upd_TransactionModel->status = 2;
    $upd_TransactionModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

}
