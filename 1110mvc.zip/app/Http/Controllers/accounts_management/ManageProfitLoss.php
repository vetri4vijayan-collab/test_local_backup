<?php

namespace App\Http\Controllers\accounts_management;

use App\Http\Controllers\Controller;
use App\Models\LedgerModel;
use App\Models\TransactionModel;
use Illuminate\Http\Request;

class ManageProfitLoss extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $transaction_details = [
            'income_list' => [],
            'expense_list' => [],
        ];

        $credit_debit_ledger_count = 0;

        // Get all credit/debit ledgers
        $credit_debit_ledger_list = LedgerModel::where('status', 0)
            ->where('sno', '>', 1)
            ->whereIn('transection_type', [1, 2])
            ->orderBy('sno', 'desc')
            ->get();

        if ($credit_debit_ledger_list->isNotEmpty()) {
            foreach ($credit_debit_ledger_list as $ledger) {

                $transaction_type = (int) ($ledger->transection_type ?? 1);
                $ledger_sno = (int) ($ledger->sno ?? 0);

                if ($transaction_type === 2) {
                    // Debit (Expense)
                    $trans_details = TransactionModel::selectRaw('SUM(debit) AS total_debit')
                        ->where('ledger_id', $ledger_sno)
                        ->where('branch_id', $branch_id)
                        ->first();

                    $amount = (int) ($trans_details->total_debit ?? 0);

                    $ledger->trans_type = 'Debit';
                    $ledger->amount = $amount;

                    $transaction_details['expense_list'][] = $ledger;
                    $credit_debit_ledger_count++;

                } elseif ($transaction_type === 1) {
                    // Credit (Income)
                    $trans_details = TransactionModel::selectRaw('SUM(credit) AS total_credit')
                        ->where('ledger_id', $ledger_sno)
                        ->where('branch_id', $branch_id)
                        ->first();

                    $amount = (int) ($trans_details->total_credit ?? 0);

                    $ledger->trans_type = 'Credit';
                    $ledger->amount = $amount;

                    $transaction_details['income_list'][] = $ledger;
                    $credit_debit_ledger_count++;
                }
            }
        }

        return view('content.accounts_management.manage_profit_loss.list', [
            'transaction_details' => $transaction_details,
            'credit_debit_ledger_count' => $credit_debit_ledger_count,
            'ledger_list' => [],
        ]);
    }
}
