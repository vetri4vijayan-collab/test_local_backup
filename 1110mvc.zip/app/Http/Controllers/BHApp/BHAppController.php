<?php
namespace App\Http\Controllers\BHApp;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CostingModel;
use App\Models\ExamModel;
use App\Models\CustomerModel;
use App\Models\PaymentModel;
use App\Models\CugManagementModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\ManageQuestionModel;
use App\Models\OtpModel;
use App\Models\StaffExamProcessModel;
use App\Models\StaffModel;
use App\Models\StaffAttendanceModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use Carbon\Carbon;
use function PHPUnit\Framework\isEmpty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;use App\Models\SmsTemplateModel;
use App\Models\ManageTargetModel;

class BHAppController extends Controller
{

    public function bhLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $key       = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {

             $staffuser = CugManagementModel::where('staff_mobile', $mobile_no)->where('status', 0)->first();
            
            // $user = StaffModel::where('mobile_no', $mobile_no)
            // ->whereIn('role_id',[18,21,20,9])
            // ->where('status', 0)->first();
            // return $user;
            if ($staffuser) {  
                
                $user = StaffModel::where('sno', $staffuser->staff_id)->where('status', 0)->first();
   
                if ($user) {
                    $user->updated_at = Carbon::now('Asia/Kolkata');
                    $user->save();
                }
                
                  if( $mobile_no == "9790464324"){
                    $otp_value  = 1234; // Random 6-digit OTP
                }else{
                   $otp_value = rand(1000, 9999); // Random 6-digit OTP
                }
                
                 // Random 6-digit OTP

                // Save OTP to Database
                $otp = new OtpModel();

                $otp->user_id    = $user->sno;
                $otp->mobile_no =  $mobile_no;
                $otp->otp_number = $otp_value;
                $otp->created_by = $user->sno;
                $otp->updated_by = $user->sno;
                $otp->save();
                
                 if( $mobile_no != "9790464324"){
                    if ($otp_value) {
    
                        $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey         = $result_sms ? $result_sms->authkey : '';
                        $sender_id       = $result_sms ? $result_sms->sender_id : '';
                        $template_id     = $result_sms ? $result_sms->template_id : '';
                        $country_code    = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number   = $country_code . $mobile_no;
    
                        $app_name = "HeadHub";
                        // $app_link = 'https://elysiumacademy.org/';
                        $app_code = "c1/M2WKZ7y%2B";
    
                        // Replace placeholders with actual values
                        $replacement_values = [$user->staff_name, $app_name, $otp_value,$app_code];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
    
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                 }
                $usertable = User::where('user_id', $user->sno)->first();
                $token     = $usertable->createToken('authToken')->accessToken;
                $roleId    = UserRoleModel::where('status', 0)->where('sno', $user->role_id)->first();
                $check     = UserRoleModel::where('status', 0)->get();
                $underRole = $check->contains('user_role_id', $roleId->sno) ? 'Yes' : 'No';
                $branch_check    = BranchModel::where('sno', $usertable->branch_id)->orderBy('sno', 'desc')->first();

                $branch_name=$branch_check->branch_type ==1 ? $branch_check->branch_name :  $branch_check->franchise_name;

                // $check = UserRoleModel::where('status', 0)->first();
                // $underRole = $check && $check->sno == $roleId->sno ? 'Yes' : 'No';
                $baseUrl = 'https://erp.elysium.academy/staff_images/';
                // return $roleId;
                return response()->json([
                    'otp'         => $otp_value,
                    'status'      => strval($user->status),
                    'staff_id'    => $user->sno,
                    'Gender'      => $user->gender,
                    'branch_id'      => $usertable->branch_id,
                    'branch_name'      => $branch_name,
                    'staff_name'  => $user->staff_name,
                    'nick_name'  => $user->nick_name,
                    'staff_image' => $baseUrl . $user->staff_image ?? null,
                    'message'     => 'Successfully',
                   
                ], 200);
            } else {
                $response = [
                    'status'    => "2",
                    'message'   => 'User does not exist',
                    "error_msg" => null,
                    'data'      => null,
                ];
                return response($response, 200);
            }
        }
    }
    public function verifyOtp(Request $request)
  {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        // $expiryTime = $createdAt->copy()->addMinutes(2);
        // $currentTime = Carbon::now('UTC');
    
        // if ($currentTime->greaterThan($expiryTime)) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'OTP expired. Please request a new one.'
        //     ], 410);
        // }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }
    public function bhBranchList(Request $request)
    {
    $user_id = $request->user_id;
    $user = StaffModel::where('sno', $user_id)->first();

    // Columns to select
    $selectFields = [
        'sno as branch_id',
        'branch_name',
        'franchise_name',
        'branch_type'
    ];

    // If user is BH (sno == 124)
    if ($user && $user->sno == 124) {
        $branches = BranchModel::select($selectFields)
            ->whereNotIn('sno', [1, 11])
            ->where('status', 0)
            ->where('branch_type', 1)
            ->get();

        $franchises = BranchModel::select($selectFields)
            ->where('status', 0)
            ->where('branch_type', 2)
            ->get();

        return response()->json([
            'status'     => 200,
            'message'    => 'Data Retrieved Successfully',
            'branches'   => $branches,
            'franchises' => $franchises
        ]);
    }

    // If user has multi-branch access
    if ($user && !empty($user->multi_branch_access)) {
        $accessibleBranches = json_decode($user->multi_branch_access, true);

        if (is_array($accessibleBranches) && count($accessibleBranches) > 0) {
            $branches = BranchModel::select($selectFields)
                ->whereIn('sno', $accessibleBranches)
                ->where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::select($selectFields)
                ->whereIn('sno', $accessibleBranches)
                ->where('status', 0)
                ->where('branch_type', 2)
                ->get();

            return response()->json([
                'status'     => 200,
                'message'    => 'Data Retrieved Successfully',
                'branches'   => $branches,
                'franchises' => $franchises
            ]);
        }
    }

    // No access case
    return response()->json([
        'status'     => 200,
        'message'    => 'No access assigned to this user',
        'branches'   => [],
        'franchises' => []
    ]);
}
    public function bhChangeBranch(Request $request)
    {
        // Validate the input
        $validated = $request->validate([
            'user_id'   => 'required',
            'branch_id' => 'required',
        ]);
    
        // Fetch the user by user_id from request
        $user = User::where('user_id', $validated['user_id'])->first();
    
        if ($user) {
            $user->branch_id = $validated['branch_id'];
            $user->save();
    
            return response()->json(['success' => true, 'message' => 'Branch updated successfully.']);
        }
    
        return response()->json(['success' => false, 'message' => 'User not found.'], 404);
    }
    
    public function bhgetTargets(Request $request)
    {
        // $monthNumber = date('m', strtotime("1 " . $request->month));
        $monthNumber = $request->month;
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
        $today = Carbon::today();
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
    
        // Old payments
        $totalPaidAmountOld = DB::table('za_old_payments')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->where('za_old_customer.branch_id', $request->branch_id)
            ->where('za_old_payments.status', '!=', 2)
            ->whereIn('za_old_customer.status', [1, 4])
            ->where('za_old_payments.amount', '>', 0)
            ->whereYear('za_old_payments.created_at', $year)
            ->whereMonth('za_old_payments.created_at', $month)
            ->sum('za_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $request->branch_id)
            ->where('za_payment.status', 1)
            ->where('za_customer.status', 0)
            ->where('za_payment.amount', '>', 0)
            ->whereYear('za_payment.initialPayDate', $year)
            ->whereMonth('za_payment.initialPayDate', $month)
            ->sum('za_payment.paidAmount');
    
             $transaction = DB::table('za_transaction')
                     ->where('za_transaction.branch_id', $request->branch_id)
                      ->whereYear('za_transaction.transaction_date', $year)
                    ->whereMonth('za_transaction.transaction_date', $month)
                     ->sum('za_transaction.credit');
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $transaction;
    
        // Post-sale & pre-sale actuals (count only)
        // $postSaleActual = CustomerModel::whereIn('status', [0, 6])
        //     ->where('post_sale_check', 1)
        //     ->where('branch_id', $request->branch_id)
        //     ->whereYear('created_at', $year)
        //     ->whereMonth('created_at', $month)
        //     ->count();
        $postSaleActual = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->whereIn('za_customer.status', [0, 6])
            ->where('za_customer.post_sale_check', 1)
            ->where('za_training.post_sale_check', 1)
            ->where('za_training.branch_id', $request->branch_id)
            ->whereYear('za_training.created_at', $year)
            ->whereMonth('za_training.created_at', $month)
            ->distinct('za_training.sno')
            ->count('za_training.sno');
    
        $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            ->where('post_sale_check', 0)
            ->where('branch_id', $request->branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
            
        $transactiontoday = DB::table('za_transaction')
            ->where('branch_id', $request->branch_id)
            ->whereDate('transaction_date', $today)
            ->sum('credit');
            
       $convertedtoday = CustomerModel::whereIn('status', [0, 6]) 
            ->where('branch_id', $request->branch_id)
            ->whereDate('created_at', $today)
            ->count();
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
            ],
            'todays' => [
                'today_collection' => $transactiontoday,
                'today_converted' => $convertedtoday,
            ]
        ]);
    }

    public function bhDashBoard(Request $request)
    {
        $staff_id = $request->staff_id; 
        $branch_id = $request->branch_id; 
        $month = $request->month; // Retrieve staff ID (02)
        $year = $request->year; // Retrieve staff ID (2025)
        
        $staff = StaffModel::select('staff_name','staff_image','staff_id')->where('sno', $staff_id)->where('status', 0)->first();
        
         $baseUrl = 'https://erp.elysium.academy/staff_images/';
         $staff_profile = $staff->staff_image ? $baseUrl . $staff->staff_image : 'https://erp.elysium.academy/assets/eapl_images/user_2.png';
      
         // Date range calculation
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
                    ? $currentDate 
                    : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        // Team Goalset
        $goalteam = GoalSetTeamModel::select('*')->where('department_id', 1)
            ->where('branch_id', $branch_id)
            ->where('team_goal_month', $month)
            ->where('team_goal_year', $year)
            ->first();
            
        // $target_conversion_count= $goalteam->conversion_over_all ?? "0";
        $target_conversion_rate=$goalteam->cr_over_all?? "0";
        $target_abv=$goalteam->abv_over_all?? "0";
        $target_acv=$goalteam->acv_over_all?? "0";
        $target_avg_outgoing_call=$goalteam->avg_call_out_over_all?? "0";
        $target_no_of_walkin=$goalteam->no_of_walk_over_all?? "0";
        
      
            
        $actualMonthLeadCount = DB::table('za_lead')
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2,6])
            ->where('za_lead.internal_status',0)
            ->where('za_lead.spam_verified',0)
            ->count();
          
            
        $actualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', $year)
            ->where('za_staff.department_id', 1)
            ->whereMonth('za_customer.created_at', $month)
            ->count();
      
        
         if ($actualConversionCount > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
                    ->where('za_staff.department_id', 1)
                    ->where('za_customer.branch_id', $branch_id)
                    ->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', $month)
                    ->get();
                    
                $total_payment =0;
                $total_paid_payment =0;
                    
                if ($currentMonthCustomer->isNotEmpty()) {
                      foreach ($currentMonthCustomer as $customer) {
    
                        $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                      ->where('za_training.customer_id', $customer->sno)
                                      ->where('za_training.tesbo_check', 0)
                                      ->sum('za_training.overall_fees');
                        
                        $total_payment += $payment;
                        
                        
                        $latestTraining = DB::table('za_training')
                            ->where('customer_id', $customer->sno)
                            ->where('tesbo_check', 2)
                            ->orderByDesc('sno') 
                            ->first();
                    
                        if ($latestTraining) {
                            $total_payment += $latestTraining->overall_fees;
                        }
                        
                        $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                          ->where('za_training.customer_id', $customer->sno)
                                          ->sum('za_training.paid_amount');
                        
                        $total_paid_payment += $paid_payment;
                          
                      }
                  }
                $averageBusinessValue =0;
                $averageCollectionValue =0;
                // average 
                $averageBusinessValue   = $actualConversionCount > 0 ? $total_payment / $actualConversionCount : 0;
                $averageCollectionValue = $actualConversionCount > 0 ? $total_paid_payment / $actualConversionCount : 0;
                
                

               
            }
        
        // return $actualConversionRate;
        
        $outgoing_count = DB::table('za_call_tracker')
                ->select('za_call_tracker.branch_staff_id')
                ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
                ->whereYear('za_call_tracker.call_start_date', $year)
                ->whereMonth('za_call_tracker.call_start_date', $month)
                ->where('za_staff.branch_id', $branch_id)
                ->where('za_staff.status', 0)
                ->where('za_staff.department_id', 1)
                ->where('za_call_tracker.call_status',0)
                ->count();
        
        $avg_outgoing_call_rate = $dayCount > 0 ? round($outgoing_count / $dayCount) : 0;
        // return $avg_outgoing_call_rate;
        // $avg_outgoing_call_rate = $outgoing_count;
        
         $completedWalkinCount = DB::table('za_lead_appointment')
             ->where('za_lead_appointment.appointment_status', "2")
             ->where('za_lead_appointment.branch_id', $branch_id)
             ->whereMonth('za_lead_appointment.appointment_date', $month)
             ->whereYear('za_lead_appointment.appointment_date', $year)
             ->where('za_lead_appointment.appointment_category', 'walk-in')
            ->count();

           
            $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.branch_id', $branch_id)
              ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.internal_status',0)
              ->count();
            $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.branch_id', $branch_id)
             ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2,6])
            ->where('za_lead.spam_verified',0)
            ->where('za_lead.drop_verified', 0)
            ->where('za_lead.internal_status',0)
            ->count();
          

            $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.branch_id', $branch_id)
             ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.status',0)
            ->where('za_lead.internal_status',0)
            ->count();

            $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.branch_id', $branch_id)
             ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2,6])
            ->where('za_lead.lead_status_id',3)
            ->where('za_lead.spam_verified',0)
            ->where('za_lead.internal_status',0)
            ->count();

            $customerConvertCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branch_id)
                ->whereYear('za_customer.created_at', $year)
                ->whereMonth('za_customer.created_at', $month)
                ->count();

            $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.spam_verified',1)
            ->where('za_lead.branch_id', $branch_id)
            ->where('za_lead.status', 7)->count();

                 
                  $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
                ->whereYear('za_lead.registered_date', $year)
                ->whereMonth('za_lead.registered_date', $month)
                ->where('za_lead.drop_verified', 1)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 5)->count();

            // Spam Ratio 
            $active_lead_ratio = $allLeadCount > 0 ? ($monthLeadCount / $allLeadCount) * 100 : 0;
            $active_lead_ratio = number_format($active_lead_ratio, 2);

            // Spam Ratio 
            $spam_lead_ratio = $allLeadCount > 0 ? ($spamLeadCount / $allLeadCount) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            // Dead ratio
            $dead_lead_ratio      = $allLeadCount > 0 ? ($deadLeadCount / $allLeadCount) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

            // customer ratio
            $convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);
            
                  
        $actualConversionRate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $actualConversionRate = round($actualConversionRate);
        

            //acr
            $averager_convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
            $averager_convertion_rate = number_format($averager_convertion_rate, 2);
          
          $harvesting_collection_value=0;
          $total_collection_value=0;
          $outstanding_value=0;
           
            $harvesting_collection_value = DB::table('za_payment')
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->where('za_customer.branch_id', $branch_id)
                ->where('za_customer.status', 0)
                ->whereYear('za_payment.nextPayDate', $year)
                ->whereMonth('za_payment.nextPayDate', $month)
                ->where('za_payment.branch_id', $branch_id)
                ->sum('za_payment.amount');
      
            
             $total_collection_value = DB::table('za_transaction')
                     ->where('za_transaction.branch_id', $branch_id)
                      ->whereYear('za_transaction.transaction_date', $year)
                    ->whereMonth('za_transaction.transaction_date', $month)
                     ->sum('za_transaction.credit');
            
             $outstanding_value = DB::table('za_payment')
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->where('za_customer.branch_id', $branch_id)
                ->where('za_payment.status', 0) // not paid amount
                ->where('za_customer.status', 0)
                ->whereYear('za_payment.nextPayDate', $year)
                ->whereMonth('za_payment.nextPayDate', $month)
                ->where('za_payment.branch_id', $branch_id)
                ->sum('za_payment.amount');
             $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                     ->whereYear('branch_target.date', $year)
                     ->whereMonth('branch_target.date', $month)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();

        $targetsconve = $targets?$targets->no_of_registrations:0;

        return response()->json([
            'status'            => 200,
            'message'           => 'Data Retrieved Successfully',
            'error_msg'         => null,
            'staff_name'     => $staff->staff_name ?? '',   
            'staff_id'     =>  $staff->staff_id ?? '',   
            'staff_profile'     => $staff_profile,   
            'target_conversion_count'     => $targetsconve,   
            'actual_conversion_count'     => $actualConversionCount,   
            'target_conversion_rate'     => $target_conversion_rate,   
            'actual_conversion_rate'     => number_format($actualConversionRate,1),
            'target_abv'     => $target_abv,   
            'actual_abv'     => number_format($averageBusinessValue ?? 0,2,'.',''),   
            'target_acv'     => $target_acv,   
            'actual_acv'     => number_format($averageCollectionValue ?? 0,2,'.',''),   
            'target_avg_outgoing_call'     => $target_avg_outgoing_call,   
            'actual_avg_outgoing_call'     => $avg_outgoing_call_rate,   
            'target_no_of_walkin'     => $target_no_of_walkin,   
            'actual_no_of_walkin'     => $completedWalkinCount,   
            'no_of_lead_count'     => $allLeadCount,   
            'active_lead_count'     => $monthLeadCount,   
            'dead_lead_count' => $deadLeadCount,
            'spam_lead_count' => $spamLeadCount,
            'active_lead_ratio' => number_format($active_lead_ratio,1),
            'dead_lead_ratio' => number_format($dead_lead_ratio,1),
            'spam_lead_ratio' => number_format($spam_lead_ratio,1),
            'no_of_conversion' => $actualConversionCount,
            'conversion_ratio' => number_format($actualConversionRate,1),
            'no_of_customer_count' => $actualConversionCount,
            'average_business_value' =>number_format($averageBusinessValue ?? 0 ,2,'.',''),
            'average_collection_value' => number_format($averageCollectionValue ?? 0,2,'.',''),
            'harvesting_collection_value' => number_format($harvesting_collection_value,2,'.',''),
            'total_collection_value' => number_format($total_collection_value,2,'.',''),
            'outstanding_value' => number_format($outstanding_value,2,'.',''),
        ], 200);
    }

    public function bhDepartmentList(Request $request)
    {

        $department = DB::table('za_department')->select('za_department.sno as department_id','za_department.department_name')
            ->where('za_department.status',0)
            ->groupBy(
                'za_department.sno',
                'za_department.department_name'
                )
            ->orderBy('za_department.sno', 'asc')
            ->get();

            $department->prepend([
                'department_id'   => 0,
                'department_name' => 'All'
            ]);

        if ($department) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'departments'      => $department,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'department'      => [],
            ], 200);
        }
    }

    public function bhPositionList(Request $request)
    {
        $branch_id = $request->branch_id;
        $dept_id = $request->department_id;
        
        $position = DB::table('za_job_position')->select('za_job_position.sno as position_id','za_job_position.job_position_name as position_name')
            ->leftJoin('za_staff', 'za_job_position.sno', "=", "za_staff.position_role")
            ->where('za_job_position.status',0)
            ->where('za_job_position.department_id',$dept_id)
            ->where('za_staff.branch_id',$branch_id)
            ->groupBy(
                'za_job_position.sno',
                'za_job_position.job_position_name'
                )
            ->orderBy('za_job_position.sno', 'asc')
            ->get();

        $position->prepend([
            'position_id'   => 0,
            'position_name' => 'All'
        ]);

        if ($position) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'positions'      => $position,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'position'      => [],
            ], 200);
        }
    }

    // public function bhstaffList(Request $request)
    // {

    //     $dept_id = $request->department_id;
    //     $position_id = $request->position_id;
    //     $branch_id = $request->branch_id;

    //     $staff = StaffModel::select(
    //             'za_staff.sno as staff_sno',
    //             'za_staff.staff_id',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.staff_image',
    //             'za_staff.avaiable_points',
    //             'za_job_position.job_position_name as position_name',
    //             'za_department.department_name',
    //             'za_department.sno as department_id',
    //             'za_job_position.sno as position_id'
    //         )
    //         ->join('za_department', 'za_department.sno', "=", "za_staff.department_id")
    //         ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
    //         ->where('za_staff.status', '!=', 2)
    //         ->where('za_staff.branch_id',$branch_id);
    //         if($dept_id !=""){
    //             $staff->where('za_staff.department_id',$dept_id);
    //         }if($position_id !=""){
    //             $staff->where('za_staff.position_role', $position_id);
    //         }
    //         $staff= $staff->get();

    //     // return $students;

       
    //     $helper          = new Helpers();
    //     $generalSettings = $helper->general_setting_data();
    //     $dateFormat      = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    //     // Map through the batches to format dates and add additional fields
    //     $formattedStaff = $staff->map(function ($item) use ($dateFormat) {
    //         // Format dates and times
    //         $baseUrl       = 'https://erp.elysium.academy/staff_images/';
    //         $staff_profile="";
    //         if($item->staff_image){
    //             $staff_profile=$baseUrl.$item->staff_image;
    //         }else{
    //             $staff_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
    //         }
    //         $item->staff_profile = $staff_profile;

    //         $item->actual_score = "35";
    //         $item->target_score = "100";

    //         return $item;
    //     });

    //     return response()->json([
    //         'status'       => 200,
    //         'message'      => 'Data Retrieved Successfully',
    //         'error_msg'    => null,
    //         'staff_list' => $formattedStaff,
    //     ], 200);
    // }

    // public function bhStaffDetails(Request $request)
    // {
    //     $staff_id = $request->staff_id;
    //      $month = $request->month;
    //     $year = $request->year;
            
    //     $startDate = Carbon::create($year, $month, 1);
    //     $currentDate = Carbon::now();
    //     $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
    //                 ? $currentDate 
    //                 : $startDate->copy()->endOfMonth();
        
    //     $dayCount = 0;
        
    //     for ($date = $startDate->copy(); $date->lte($endDate); $date->addDay()) {
    //         if ($date->dayOfWeek !== Carbon::SUNDAY) {
    //             $dayCount++;
    //         }
    //     }

        
              


    //     // Fetch batch data with necessary joins
    //     $staff = StaffModel::select(
    //             'za_staff.sno as staff_sno',
    //             'za_staff.staff_id',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.email_id',
    //             'za_staff.mobile_no',
    //             'za_staff.staff_image',
    //             'za_staff.basic_salary as salary',
    //             'za_staff.avaiable_points',
    //             'za_job_position.job_position_name as position_name',
    //             'za_staff.date_of_joining',
    //             'za_department.department_name',
    //             'za_department.sno as department_id',
    //             'za_job_position.sno as position_id'
    //         )
    //         ->join('za_department', 'za_department.sno', "=", "za_staff.department_id")
    //         ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
    //         ->where('za_staff.status', '!=', 2)
    //         ->where('za_staff.sno',$staff_id)
    //         ->first();

    //         if (!$staff) {
    //             return response()->json([
    //                 'status'    => 404,
    //                 'message'   => 'Staff not found',
    //                 'error_msg' => 'Invalid staff ID',
    //                 'staff_list' => null,
    //             ], 404);
    //         }
        
    //         $helper = new Helpers();
    //         $generalSettings = $helper->general_setting_data();
    //         $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default format
        
    //         $staff->date_of_joining = \Carbon\Carbon::parse($staff->date_of_joining)->format($dateFormat);
    //         // Processing staff data
    //         $baseUrl = 'https://erp.elysium.academy/staff_images/';
    //         $staff->staff_profile = $staff->staff_image
    //             ? $baseUrl . $staff->staff_image
    //             : 'https://erp.elysium.academy/assets/eapl_images/user_2.png';
        
    //         $staff->actual_score = "35";
    //         $staff->target_score = "100";
    //         $staff->heart_rate = "25";
    //         $staff->battery_rate = "60";
            
    //          $attendanceRecordsCurrentmonth = StaffAttendanceModel::select('date', 'attendance')
    //             ->whereMonth('date', date('m'))
    //             ->whereYear('date',date('Y'))
    //             ->where('staff_id',$staff_id)
    //             ->orderBy('date','asc')
    //             ->get();

    //         $attendanceRecords = StaffAttendanceModel::select('date', 'attendance')
    //             ->whereMonth('date', $month)
    //             ->whereYear('date',$year)
    //             ->where('staff_id',$staff_id)
    //             ->orderBy('date','asc')
    //             ->get();
            
    //         $today_attendance="";
    //         $persent_count=0;
    //         foreach($attendanceRecordsCurrentmonth as $record){
    //             if($record->date == date('Y-m-d')){
    //                 $today_attendance=$record->attendance;
    //             }
    //             if($record->attendance == "P" || $record->attendance == "OD"){
    //                 $persent_count +=1;
    //             }
    //         }
    //         $staff->Today_attendance = $today_attendance;
    //         $staff->month_attendance=$attendanceRecords;
            
            
    //         $presentPercentage = $dayCount > 0 ? ($persent_count / $dayCount)*100 : 0;
    //         $staff->present_percentage=number_format($presentPercentage, 2, '.', '');
        
    //         return response()->json([
    //             'status'      => 200,
    //             'message'     => 'Data Retrieved Successfully',
    //             'error_msg'   => null,
    //             'staff_Details'  => $staff,
    //         ], 200);
    // }
    
    
    public function bhstaffList(Request $request)
    {

        $dept_id = $request->department_id;
        $position_id = $request->position_id;
        $branch_id = $request->branch_id;

        $month =date('m');
        $year =date('Y');

        $staff = StaffModel::select(
                'za_staff.sno as staff_sno',
                'za_staff.staff_id',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.staff_image',
                'za_staff.avaiable_points',
                'za_job_position.job_position_name as position_name',
                'za_department.department_name',
                'za_department.sno as department_id',
                'za_job_position.sno as position_id'
            )
            ->join('za_department', 'za_department.sno', "=", "za_staff.department_id")
            ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
            ->where('za_staff.status', 0)
            ->where('za_staff.branch_id',$branch_id);
            if($dept_id !=""){
                $staff->where('za_staff.department_id',$dept_id);
            }if($position_id !=""){
                $staff->where('za_staff.position_role', $position_id);
            }
            $staff= $staff->get();

        // return $students;

       
        $helper          = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat      = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Map through the batches to format dates and add additional fields
        $formattedStaff = $staff->map(function ($item) use ($dateFormat,$month,$year) {
            // Format dates and times
            $baseUrl       = 'https://erp.elysium.academy/staff_images/';
            $staff_profile="";
            if($item->staff_image){
                $staff_profile=$baseUrl.$item->staff_image;
            }else{
                $staff_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
            }
            $item->staff_profile = $staff_profile;

            $goalsetRecord = GoalSetStaffModel::where('za_goal_set_staff.staff_id', $item->staff_sno)
            ->whereMonth('za_goal_set_staff.goal_date', $month)
            ->whereYear('za_goal_set_staff.goal_date', $year)
            ->first();

   
        $customerConvertCount = 0;
        $customerConvertCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->whereYear('za_customer.created_at', $year)
                ->where('za_lead.created_by', $item->staff_sno)
                ->whereMonth('za_customer.created_at', $month)
                ->count();

                $std_count = 0;
                $current_date = date('Y-m-d'); // Define the current date
                $std_count = TrainingModel::where('za_training.status', 0)
                    ->where('za_batch.status', 0)
                    ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
                    ->where('za_training.staff_id', $item->staff_sno)
                    ->where('za_batch.start_date', '<=', $current_date)
                    ->where('za_batch.end_date', '>=', $current_date)
                    ->count();

                if ($goalsetRecord && $goalsetRecord->goal_completed == 1) {
                    $customerConvertCount = $goalsetRecord->conversion_actual ?? 0;
                    $std_count = $goalsetRecord->min_no_of_students_actual ?? 0;
                }
                $targetScore = 0;
                $actualScore=0;
                if($item->department_id ==1 ){
                    $targetScore=$goalsetRecord->conversion ?? 0;
                    $actualScore=$customerConvertCount ?? 0;
                }elseif($item->department_id ==2){
                    $targetScore=$goalsetRecord->min_no_of_students ?? 0;
                    $actualScore=$std_count ?? 0;
                }

             $item->actual_score = strval($actualScore);
            $item->target_score = strval($targetScore);

            return $item;
        });

        return response()->json([
            'status'       => 200,
            'message'      => 'Data Retrieved Successfully',
            'error_msg'    => null,
            'staff_list' => $formattedStaff,
        ], 200);
    }

    public function bhStaffDetails(Request $request)
    {
        $staff_id = $request->staff_id;
         $month = $request->month ?? date('m');
        $year = $request->year ?? date('Y');
            // return $request;
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
                    ? $currentDate 
                    : $startDate->copy()->endOfMonth();
        
        $dayCount = 0;
        
        for ($date = $startDate->copy(); $date->lte($endDate); $date->addDay()) {
            if ($date->dayOfWeek !== Carbon::SUNDAY) {
                $dayCount++;
            }
        }

        
              


        // Fetch batch data with necessary joins
        $staff = StaffModel::select(
                'za_staff.sno as staff_sno',
                'za_staff.staff_id',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.email_id',
                'za_staff.mobile_no',
                'za_staff.branch_id',
                'za_staff.staff_image',
                'za_staff.basic_salary as salary',
                'za_staff.avaiable_points',
                'za_job_position.job_position_name as position_name',
                'za_staff.date_of_joining',
                'za_department.department_name',
                'za_department.sno as department_id',
                'za_job_position.sno as position_id'
            )
            ->join('za_department', 'za_department.sno', "=", "za_staff.department_id")
            ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.sno',$staff_id)
            ->first();

            if (!$staff) {
                return response()->json([
                    'status'    => 404,
                    'message'   => 'Staff not found',
                    'error_msg' => 'Invalid staff ID',
                    'staff_list' => null,
                ], 404);
            }
        
            $helper = new Helpers();
            $generalSettings = $helper->general_setting_data();
            $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default format
        
            $staff->date_of_joining = \Carbon\Carbon::parse($staff->date_of_joining)->format($dateFormat);
            // Processing staff data
            $baseUrl = 'https://erp.elysium.academy/staff_images/';
            $staff->staff_profile = $staff->staff_image
                ? $baseUrl . $staff->staff_image
                : 'https://erp.elysium.academy/assets/eapl_images/user_2.png';
            

           $goalsetRecord = GoalSetStaffModel::where('za_goal_set_staff.staff_id', $staff_id)
            ->whereMonth('za_goal_set_staff.goal_date', $month)
            ->whereYear('za_goal_set_staff.goal_date', $year)
            ->first();

   
        $customerConvertCount = 0;
        $customerConvertCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->whereYear('za_customer.created_at', $year)
                ->where('za_lead.created_by', $staff_id)
                ->whereMonth('za_customer.created_at', $month)
                ->count();

        $std_count = 0;
        $current_date = date('Y-m-d'); // Define the current date
        $std_count = TrainingModel::where('za_training.status', 0)
            ->where('za_batch.status', 0)
            ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
            ->where('za_training.staff_id', $staff_id)
            ->where('za_batch.start_date', '<=', $current_date)
            ->where('za_batch.end_date', '>=', $current_date)
            ->count();

        if ($goalsetRecord && $goalsetRecord->goal_completed == 1) {
            $customerConvertCount = $goalsetRecord->conversion_actual ?? 0;
            $std_count = $goalsetRecord->min_no_of_students_actual ?? 0;
        }
        $targetScore = 0;
        $actualScore=0;
        if($staff->department_id ==1 ){
            $targetScore=$goalsetRecord->conversion ?? 0;
            $actualScore=$customerConvertCount ?? 0;
        }elseif($staff->department_id ==2){
            $targetScore=$goalsetRecord->min_no_of_students ?? 0;
            $actualScore=$std_count ?? 0;
        }

            $startDate = Carbon::create($year, $month, 1);
            $currentDate = Carbon::now();
            $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
            $dayCount = $startDate->diffInDays($endDate) + 1;
            $presentDaysCOUNT = StaffAttendanceModel::where('staff_id', $staff_id)
            ->where('attendance', 'P')
            ->whereMonth('date', $month)
            ->whereYear('date', $year)
            ->count();

            $presentDays =  $dayCount > 0 ? ($presentDaysCOUNT / $dayCount) * 100 : 0;

           $presentDays= number_format($presentDays, 1, '.', '');
        
            $goalset_ratio = $helper->getStaffGoal_progress_bar($staff_id,$staff->department_id,$month,$year,$staff->branch_id);
            
            $staff->actual_score = strval($actualScore);
            $staff->target_score = strval($targetScore);
            $staff->heart_rate = strval(round($presentDays));
           $staff->battery_rate = strval(min(round($goalset_ratio), 100));
            
             $attendanceRecordsCurrentmonth = StaffAttendanceModel::select('date', 'attendance')
                ->whereMonth('date', date('m'))
                ->whereYear('date',date('Y'))
                ->where('staff_id',$staff_id)
                ->orderBy('date','asc')
                ->get();

            $attendanceRecords = StaffAttendanceModel::select('date', 'attendance')
                ->whereMonth('date', $month)
                ->whereYear('date',$year)
                ->where('staff_id',$staff_id)
                ->orderBy('date','asc')
                ->get();
            
            $today_attendance="";
            $persent_count=0;
            foreach($attendanceRecordsCurrentmonth as $record){
                if($record->date == date('Y-m-d')){
                    $today_attendance=$record->attendance;
                }
                if($record->attendance == "P" || $record->attendance == "OD"){
                    $persent_count +=1;
                }
            }
            $staff->Today_attendance = $today_attendance;
            $staff->month_attendance=$attendanceRecords;
            
            
            $presentPercentage = $dayCount > 0 ? ($persent_count / $dayCount)*100 : 0;
            $staff->present_percentage=number_format($presentPercentage, 2, '.', '');
        
            return response()->json([
                'status'      => 200,
                'message'     => 'Data Retrieved Successfully',
                'error_msg'   => null,
                'staff_Details'  => $staff,
            ], 200);
    }

    public function bhCourseTypeList(Request $request)
    {

        $branch_id=$request->branch_id;

        $branch_course_type = DB::table('za_branch_course')
        ->where('branch_id', $branch_id)
        ->first();
        $branch_course_type_ids = $branch_course_type ? array_map('intval', json_decode($branch_course_type->course_type_id, true)) : [];
        

        $Courses = DB::table('za_course_type')
            ->select(
                'za_course_type.sno as course_type_id',
                'za_course_type.course_type_name',
                'za_course_type.course_days',
                'za_course_type.course_duration'
            )
            ->where('za_course_type.status', 0)
            ->whereIn('za_course_type.sno', $branch_course_type_ids)
            ->orderBy('za_course_type.sno', 'asc')
            ->get();

        $Courses->prepend([
            'course_type_id'   => 0,
            'course_type_name' => 'All'
        ]);

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'course_type_list' => $Courses,
        ], 200);
    }

    public function bhCourseList(Request $request)
    {

        $course_type_id=$request->course_type_id;
        $branch_id=$request->branch_id;

        $branch_course = DB::table('za_branch_course')
        ->where('branch_id', $branch_id)
        ->first();
        $branch_course_ids = $branch_course ? array_map('intval', json_decode($branch_course->course_id, true)) : [];
        

        $allCourseData = [];

        $Courses = ManageCoursesModel::select(
            'za_course.sno',
            'za_course.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course.course_min_price',
            'za_course.course_max_price',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            DB::raw("DATE_FORMAT(za_course.created_at, '%d-%m-%Y') as created_date")
            // DB::raw('DATE(za_course.created_at) as created_date')

        )
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_course.status', 0)
            ->whereIn('za_course.sno', $branch_course_ids);
            if( $course_type_id != ""){
                $Courses->where('za_course.course_type_id', $course_type_id);
            }
            
            $Courses=$Courses->groupBy(
                'za_course.sno',
                'za_course.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_course.course_duration',
                'za_course.course_days',
                'za_course.course_min_price',
                'za_course.course_max_price',
                'za_course_type.course_type_name',
                'za_course.attachment',
                'za_course.thumbnail',
                'za_course.course_desc',
                'za_course.course_goals',
                'za_course.course_future_scope',
                'created_date'
            )
            ->orderBy('za_course.sno', 'desc')
            ->get();
        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';
        // return $Courses;
        // Add base URLs to the attachments and thumbnails
        $Courses->transform(function ($course) use ($attachmentBaseUrl, $thumbnailBaseUrl) {
            $course->attachment = $attachmentBaseUrl . $course->attachment;
            $course->thumbnail  = $thumbnailBaseUrl . $course->thumbnail;
            return $course;
        });


        $allCourseData[] = [
            'coursesDetails' => $Courses,
            // 'chapters' => $chapters,
        ];
        if ($allCourseData) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        }
    }

    public function bhCourseDetails(Request $request)
    {
        $course_id = $request->course_id;

        $Courses = ManageCoursesModel::select(
            'za_course.sno',
            'za_course.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course.course_min_price',
            'za_course.course_max_price',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            DB::raw("DATE_FORMAT(za_course.created_at, '%d-%m-%Y') as created_date")
        )
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
        ->where('za_course.status', 0)
        ->where('za_course.sno', $course_id)
        ->groupBy(
            'za_course.sno',
            'za_course.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course.course_min_price',
            'za_course.course_max_price',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            'created_date'
        )
        ->first();

        // If course not found, return 404
        if (!$Courses) {
            return response()->json([
                'status'    => 404,
                'message'   => 'Course not found',
                'error_msg' => 'No course found for the given ID',
                'courseDetails' => null,
            ], 404);
        }

        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';

        // Modify the object directly
        $Courses->attachment = $attachmentBaseUrl . $Courses->attachment;
        $Courses->thumbnail  = $thumbnailBaseUrl . $Courses->thumbnail;

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'courseDetails' => $Courses,
        ], 200);
    }


    public function bhActiveList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $lead_fill = $request->search;
        $perPage = 30; // Default pagination limit
        $page = $request->input('page', 1); 


        $activeLeadList = DB::table('za_lead')
            ->select(
                'za_lead.sno',
                'za_lead.lead_name',
                'za_lead.lead_mobile',
                'za_lead.outgoing_count',
                'za_staff.staff_name as sales_person'
            )
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.branch_id', $branch_id)
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_lead.internal_status', '!=', 1)
            ->where('za_lead.status', 0);

            if ($lead_fill != '') {
                $activeLeadList->where(function ($query) use ($lead_fill) {
                    $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_name', 'LIKE', "%{$lead_fill}%");
                });
            }
           
            $activeLeadList=$activeLeadList->paginate($perPage);
            // $activeLeadList=$activeLeadList->get();

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'active_Lead_list' => $activeLeadList,
        ]);
    }


    public function bhSpamList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $lead_fill = $request->search;
        $perPage = 30; // Default pagination limit
        $page = $request->input('page', 1); 


        $spamLeadList = DB::table('za_lead')
            ->select(
                'za_lead.sno',
                'za_lead.lead_name',
                'za_lead.lead_mobile',
                'za_lead.outgoing_count',
                'za_lead.spam_reason',
                'za_lead.spam_comments',
                'za_staff.staff_name as sales_person'
            )
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.branch_id', $branch_id)
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_lead.status', 7);

            if ($lead_fill != '') {
                $spamLeadList->where(function ($query) use ($lead_fill) {
                    $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_name', 'LIKE', "%{$lead_fill}%");
                });
            }
           
            $spamLeadList=$spamLeadList->paginate($perPage);
            // $spamLeadList=$spamLeadList->get();

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'spam_lead_list' => $spamLeadList,
        ]);
    }


    public function bhDeadList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $lead_fill = $request->search;
        $perPage = 30; // Default pagination limit
        $page = $request->input('page', 1); 


        $deadLeadList = DB::table('za_lead')
            ->select(
                'za_lead.sno',
                'za_lead.lead_name',
                'za_lead.lead_mobile',
                'za_lead.outgoing_count',
                'za_lead.drop_reason',
                'za_staff.staff_name as sales_person'
            )
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.branch_id', $branch_id)
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_lead.status', 5);

            if ($lead_fill != '') {
                $deadLeadList->where(function ($query) use ($lead_fill) {
                    $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                        ->orWhere('za_lead.lead_name', 'LIKE', "%{$lead_fill}%");
                });
            }
           
            $deadLeadList=$deadLeadList->paginate($perPage);
            // $deadLeadList=$deadLeadList->get();

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'dead_lead_list' => $deadLeadList,
        ]);
    }

    public function bhHarvestingList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $customer_fill = $request->search;
        $perPage = 30; 
        $page = $request->input('page', 1); 

        $totalscheduleamount = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->whereYear('za_payment.nextPayDate', $year)
            ->whereMonth('za_payment.nextPayDate', $month)
            ->where('za_payment.branch_id', $branch_id)
            ->sum('za_payment.amount');


        $HistoryPayment = DB::table('za_payment')->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
            ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
            ->where('za_payment.branch_id', $branch_id)
            ->whereYear('za_payment.initialPayDate', $year)
            ->whereMonth('za_payment.initialPayDate', $month)
            ->select(
                'za_payment.payment_id',
                'za_payment.nextPayDate as payment_date',
                'za_payment.status AS payment_status',
                'za_payment.amount AS payment_amount',
                'za_payment.gst_amount AS payment_gst_amount',
                DB::raw('(za_payment.paidAmount + za_payment.gst_amount) as payment_paid_amt'),
                'za_customer.sno as customer_sno',
                DB::raw('IFNULL(za_customer.customer_id, "") as customer_id'),
                'za_customer.cus_name',
                DB::raw("IFNULL(za_customer.cus_pic, '') as cus_pic"),
                'za_customer.cus_mobile',
                'za_customer.cus_gender',
                'za_course.course_name'
            )
            ->groupBy('za_payment.payment_id', 'za_customer.sno', 'za_customer.customer_id','za_payment.initialPayDate', 'za_customer.cus_name', 
                    'za_customer.cus_pic', 'za_customer.cus_mobile',  
                    'za_customer.cus_gender', 'za_course.course_name', 
                    'za_payment.nextPayDate', 'za_payment.status', 'za_payment.amount', 'za_payment.paidAmount', 
                    'za_payment.gst_amount', 'za_payment.balanceFee');
                    
                if (!empty($customer_fill)) {
                    $HistoryPayment->where(function ($query) use ($customer_fill) {
                        $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.customer_id', 'LIKE', "%{$customer_fill}%");
                    });
                }
            
                if (!empty($balance_payment)) {
                $HistoryPayment
                //   ->whereDate('za_payment.nextPayDate', '<', $currentDate)
                                ->where('za_payment.status',0);
                }
        $HistoryPayment = $HistoryPayment->orderBy('za_payment.nextPayDate', 'ASC')->paginate($perPage); 
        
        foreach ($HistoryPayment as $payment) {
            $payment->payment_amount = number_format($payment->payment_amount, 2, '.', '');
            $payment->payment_paid_amt = number_format($payment->payment_paid_amt, 2, '.', '');
            $payment->payment_gst_amount = number_format($payment->payment_gst_amount, 2, '.', '');
        }


        $helper          = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat      = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Map through the batches to format dates and add additional fields
        $formattedHistory = $HistoryPayment->map(function ($item) use ($dateFormat) {
            // Format dates and times
            $baseUrl       = 'https://erp.elysium.academy/cus_pics/';
            $student_profile="";    
            if($item->cus_pic){
                $student_profile=$baseUrl.$item->cus_pic;
            }else{
                if($item->cus_gender == 1){
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_1.png';
                }else{
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
                }
            }

            $currentdate = date('Y-m-d');
            $nextPayDate = \Carbon\Carbon::parse($item->payment_date); // Convert nextPayDate to Carbon instance
            $extendays = $nextPayDate->diffInDays($currentdate, false); // Get the difference in days
            $registeredDate = $nextPayDate;
            $diff = $registeredDate->diff($currentdate); // Use diff() instead of diffInDays()
            
            $months = $diff->m;
            $days = $diff->d;
            // If the difference in months is 0, just show the days count.
            if ($months == 0) {
                $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
            } else {
                $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') .  " and {$days} day" . ($days != 1 ? 's' : '');
            }

            $payment_sts = ''; 
            if ($item->payment_status == 0) {
                $payment_sts = 'to be Paid';
                // If next payment date is in the future, override color to red
                if ($nextPayDate < $currentdate) {
                    $payment_sts = 'Unpaid';
                }
            } else {
                // If status is not 0, check payment amount conditions
                if ($item->payment_paid_amt < $item->payment_amount) {
                    $payment_sts = 'Partial Paid'; // Partial payment
                } elseif ($item->payment_paid_amt >= $item->payment_amount) {
                    $payment_sts = 'Fully Paid'; // Fully paid
                }
            }

            $item->student_profile = $student_profile;
            $item->payment_color_status = $payment_sts;
            $item->extended_days = $formattedDifference ;
    

            return $item;
        });

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'total_amount' => number_format($totalscheduleamount,2, '.', ''),
            'harvesting_list' => $formattedHistory,
        ]);
    }
    
     public function bhcollectionList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $customer_fill = $request->search;
        $perPage = 30; 
        $page = $request->input('page', 1); 

        $drop_ids = DB::table('za_drop_refund')
            ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
            ->where('za_drop_refund.bh_status', 1)
            ->pluck('za_training.payment_id');
    
        // Get the current date
        $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

        $totalPaidAmount = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_payment.status', 1) 
            ->where('za_customer.status', 0)
            ->whereYear('za_payment.initialPayDate', $year)
            ->whereMonth('za_payment.initialPayDate', $month)
            ->sum('za_payment.paidAmount');
            


            $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->select(
                'za_payment.payment_id',
                'za_customer.sno as customer_sno',
                'za_payment.initialPayDate',
                'za_payment.paidAmount as payment_paid_amt',
                'za_payment.gst_amount as payment_gst_amount',
                 DB::raw("CONCAT(za_payment.paidAmount + za_payment.gst_amount, '') as payment_paid_amts"),
                'za_customer.cus_name',
                DB::raw("IFNULL(za_customer.cus_pic, '') as cus_pic"),
                'za_customer.cus_gender',
                'za_customer.cus_mobile',
                'za_course.course_name',
                'za_course.sno as course_sno'
                )
                ->distinct()
                ->where('za_payment.status', 1)
                ->where('za_customer.status', 0)
                ->whereYear('za_payment.initialPayDate', $year)
                ->whereMonth('za_payment.initialPayDate', $month)
                ->orderBy('za_payment.initialPayDate', 'DESC');
                 if (!empty($customer_fill)) {
                    $OutstandingPayment->where(function ($query) use ($customer_fill) {
                        $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.customer_id', 'LIKE', "%{$customer_fill}%");
                    });
                }
               $OutstandingPayment= $OutstandingPayment ->paginate($perPage);
        
        foreach ($OutstandingPayment as $payment) {
            $payment->payment_paid_amt = number_format($payment->payment_paid_amt, 2, '.', '');
            $payment->payment_gst_amount = number_format($payment->payment_gst_amount, 2, '.', '');
        }


        $helper          = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat      = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Map through the batches to format dates and add additional fields
        $formattedHistory = $OutstandingPayment->map(function ($item) use ($dateFormat) {
            // Format dates and times
            $baseUrl       = 'https://erp.elysium.academy/cus_pics/';
            $student_profile="";    
            if($item->cus_pic){
                $student_profile=$baseUrl.$item->cus_pic;
            }else{
                if($item->cus_gender == 1){
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_1.png';
                }else{
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
                }
            }

            $currentdate = date('Y-m-d');
            $nextPayDate = \Carbon\Carbon::parse($item->payment_date); // Convert nextPayDate to Carbon instance
            $extendays = $nextPayDate->diffInDays($currentdate, false); // Get the difference in days
            $registeredDate = $nextPayDate;
            $diff = $registeredDate->diff($currentdate); // Use diff() instead of diffInDays()
            
            $months = $diff->m;
            $days = $diff->d;
            // If the difference in months is 0, just show the days count.
            if ($months == 0) {
                $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
            } else {
                $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') .  " and {$days} day" . ($days != 1 ? 's' : '');
            }

            $payment_sts = ''; 
            if ($item->payment_status == 0) {
                $payment_sts = 'to be Paid';
                // If next payment date is in the future, override color to red
                if ($nextPayDate < $currentdate) {
                    $payment_sts = 'Unpaid';
                }
            } else {
                // If status is not 0, check payment amount conditions
                if ($item->payment_paid_amt < $item->payment_amount) {
                    $payment_sts = 'Partial Paid'; // Partial payment
                } elseif ($item->payment_paid_amt >= $item->payment_amount) {
                    $payment_sts = 'Fully Paid'; // Fully paid
                }
            }

            $item->student_profile = $student_profile;
          
           
    

            return $item;
        });

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'collection_amount' => number_format($totalPaidAmount,2, '.', ''),
            'collection_list' => $formattedHistory,
        ]);
    }


    public function bhOutstandingList(Request $request)
    {

        $month = $request->month;
        $year = $request->year;
        $branch_id = $request->branch_id;
        $customer_fill = $request->search;
        $perPage = 30; 
        $page = $request->input('page', 1); 

        $drop_ids = DB::table('za_drop_refund')
            ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
            ->where('za_drop_refund.bh_status', 1)
            ->pluck('za_training.payment_id');
    
        // Get the current date
        $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

        $outstanding_value = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_payment.status', 0) // not paid amount
            ->where('za_customer.status', 0)
            ->whereYear('za_payment.nextPayDate', $year)
            ->whereMonth('za_payment.nextPayDate', $month)
            ->where('za_payment.branch_id', $branch_id)
            ->sum('za_payment.amount');
  


            $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->select(
                'za_payment.payment_id',
               
                'za_payment.sno as payment_sno',
                'za_customer.sno as customer_sno',
                'za_payment.nextPayDate',
                'za_payment.amount as payment_amount',
                'za_payment.gst_amount as payment_gst_amount',
                 DB::raw("CONCAT(za_payment.paidAmount + za_payment.gst_amount, '') as payment_paid_amts"),
                'za_customer.cus_name',
                 DB::raw("IFNULL(za_customer.cus_pic, '') as cus_pic"),
                'za_customer.cus_gender',
                'za_customer.cus_mobile',
                DB::raw("IFNULL(za_customer.cus_email_id, '') as cus_email_id"),
                'za_course.course_name',
                'za_course.sno as course_sno'
                )
                ->whereNotIn('za_payment.payment_id', $drop_ids)
                ->distinct()
                ->where('za_payment.status', 0)
                ->where('za_customer.status', 0)
                ->whereYear('za_payment.initialPayDate', $year)
                ->whereMonth('za_payment.initialPayDate', $month)
                ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
                ->orderBy('za_payment.nextPayDate', 'DESC');
                 if (!empty($customer_fill)) {
                    $OutstandingPayment->where(function ($query) use ($customer_fill) {
                        $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                            ->orWhere('za_customer.customer_id', 'LIKE', "%{$customer_fill}%");
                    });
                }
               $OutstandingPayment= $OutstandingPayment->paginate($perPage);
        
        foreach ($OutstandingPayment as $payment) {
            $payment->payment_amount = number_format($payment->payment_amount, 2, '.', '');
            $payment->payment_gst_amount = number_format($payment->payment_gst_amount, 2, '.', '');
        }


        $helper          = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat      = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        // Map through the batches to format dates and add additional fields
        $formattedHistory = $OutstandingPayment->map(function ($item) use ($dateFormat) {
            // Format dates and times
            $baseUrl       = 'https://erp.elysium.academy/cus_pics/';
            $student_profile="";    
            if($item->cus_pic){
                $student_profile=$baseUrl.$item->cus_pic;
            }else{
                if($item->cus_gender == 1){
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_1.png';
                }else{
                    $student_profile='https://erp.elysium.academy/assets/eapl_images/user_2.png';
                }
            }

            $currentdate = date('Y-m-d');
            $nextPayDate = \Carbon\Carbon::parse($item->nextPayDate); // Convert nextPayDate to Carbon instance
            $extendays = $nextPayDate->diffInDays($currentdate, false); // Get the difference in days
            $registeredDate = $nextPayDate;
            $diff = $registeredDate->diff($currentdate); // Use diff() instead of diffInDays()
            
            $months = $diff->m;
            $days = $diff->d;
            // If the difference in months is 0, just show the days count.
            if ($months == 0) {
                $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
            } else {
                $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') .  " and {$days} day" . ($days != 1 ? 's' : '');
            }

            $payment_sts = ''; 
            if ($item->payment_status == 0) {
                $payment_sts = 'to be Paid';
                // If next payment date is in the future, override color to red
                if ($nextPayDate < $currentdate) {
                    $payment_sts = 'Unpaid';
                }
            } else {
                // If status is not 0, check payment amount conditions
                if ($item->payment_paid_amt < $item->payment_amount) {
                    $payment_sts = 'Partial Paid'; // Partial payment
                } elseif ($item->payment_paid_amt >= $item->payment_amount) {
                    $payment_sts = 'Fully Paid'; // Fully paid
                }
            }

            $item->student_profile = $student_profile;
              $item->extended_days = $formattedDifference ;
           
    

            return $item;
        });

        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'Outstanding_amount' => number_format($outstanding_value,2, '.', ''),
            'outstanding_list' => $formattedHistory,
        ]);
    }


}
