<?php

namespace App\Http\Controllers\ExamApp;


use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\CustomerModel;
use App\Models\ManageCoursesSyllabusModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\BranchModel;
use App\Models\ExamProcessModel;
use App\Models\Student;
use App\Models\ExamModel;
use App\Models\Exam_guidelinesModel;
use App\Models\ManageQuestionModel;
use DateTime;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use App\Models\OtpModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
class ExamAppController extends Controller
{

    public function ExamLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $user_name = $request->user_name;
        $password = $request->password;
        $type = $request->type;
        $key      = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'type' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {


            if($type == 'student'){
                $user = Student::where('phone_no', $mobile_no)->where('status', 0)->first();
                // return $user;
                if ($user) {
                     // Generate OTP
                    if( $mobile_no == "9790464324"){
                        $otp_value  = 123456; // Random 6-digit OTP
                    }else{
                        $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                    } // Random 6-digit OTP
    
                    // Save OTP to Database
                    $otp = new OtpModel();
    
                    $otp->user_id                  = $user->id;
                    $otp->mobile_no                =  $mobile_no;
                    $otp->otp_number               = $otp_value;
                    $otp->created_by               = $user->id;
                    $otp->updated_by               = $user->id;
                    $otp->save();
                    // sms otp
                     if( $mobile_no != "9790464324"){
                        if ($otp_value) {
    
                        $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey         = $result_sms ? $result_sms->authkey : '';
                        $sender_id       = $result_sms ? $result_sms->sender_id : '';
                        $template_id     = $result_sms ? $result_sms->template_id : '';
                        $country_code    = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number   = $country_code . $mobile_no;
    
                        $app_name = "ScorePilot";
                        // $app_link = 'https://elysiumacademy.org/';
                        $app_code = "DqA0TSg83dz";
                        // Replace placeholders with actual values
                        $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
    
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                     }
                    $usertable = Student::where('id', $user->id)->first();
                    // $token = $usertable->createToken('authToken')->accessToken;
                    //   return $usertable;
                    $baseUrl = 'https://erp.elysium.academy/cus_images/';
                    // return $roleId;
                    return response()->json([
                        'status'             => "1",
                        'otp'                => $otp_value,
                        //  'otp'                => 123456,
                        'user_name'          => $usertable->user_name,
                        'customer_id'        => $usertable->id,
                        'exam_id'            => $usertable->exam_id,
                        'phone_no'           => $usertable->phone_no,
                        'email_id'           => $usertable->email_id,
                        
                        'message'            => 'Successfully Login',
                        "error_msg"          => null,
                        'data'               => null,
                        // 'api_token'          => $token,
                    ], 200);
                } else {
                    $response = [
                        'status' => "2",
                        'message' => 'Student does not exist',
                        "error_msg" => null,
                        'data' => null
                    ];
                    return response($response, 200);
                }
            }else{
                $user = StaffModel::where('user_name', $user_name)->where('password', $password)->where('status', 0)->first();
                if ($user) {
                    
                    $usertable = StaffModel::where('sno', $user->sno)->first();
                    $user = Student::where('staff_id', $usertable->sno)->where('type', 1)->first();
                    // $token = $usertable->createToken('authToken')->accessToken;
                    //   return $usertable;
                    $baseUrl = 'https://erp.elysium.academy/cus_images/';
                    // return $roleId;
                    return response()->json([
                        'status'             => "1",
                        'user_name'          => $usertable->staff_name,
                        'customer_id'        => $user->id,
                        'exam_id'            => $usertable->exam_id,
                        'phone_no'           => $usertable->phone_no,
                        'email_id'           => $usertable->email_id,
                        'message'            => 'Successfully Login',
                        "error_msg"          => null,
                        'data'               => null,
                        // 'api_token'          => $token,
                    ], 200);
                } else {
                    $response = [
                        'status' => "2",
                        'message' => 'Staff does not exist',
                        "error_msg" => null,
                        'data' => null
                    ];
                    return response($response, 200);
                }
            }
            
        }
    }

    public function verifyOtp(Request $request)
     {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        $expiryTime = $createdAt->copy()->addMinutes(2);
        $currentTime = Carbon::now('UTC');
    
        // if ($currentTime->greaterThan($expiryTime)) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'OTP expired. Please request a new one.'
        //     ], 410);
        // }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }
    // studend app
    public function StudentExamList(Request $request)
    {
        $customer_id = $request->customer_id;

        // Fetch batch data with necessary joins
        $stud_syllabus = CustomerModel::select(
            'za_training.customer_id',
            'za_training.course_id',
            'za_training.batch_id',
            'za_course.course_name'
        )
            ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
            ->where('za_training.customer_id', $customer_id)
            ->get();

        $allBatchesData = [];

        foreach ($stud_syllabus as $batch) {
            // Calculate exam_count based on topic_id and percentage
            $exam_count_query = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->whereNotNull('ca_text_link')
                ->where('ca_text_link', '!=', '')
                ->whereIn('topic_id', function ($query) use ($batch) {
                    $query->select('topic_id')
                        ->from('za_syllabus_update')
                        ->where('za_syllabus_update.course_id', $batch->course_id)
                        ->whereRaw('CAST(za_syllabus_update.percentage AS DECIMAL(10,2)) = 100.00'); // Precise match for percentage
                });

            $exam_count = $exam_count_query->count();

            // Get the exam ca_text_link with matching conditions
            $exam_ids_query = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->whereNotNull('ca_text_link')
                ->where('ca_text_link', '!=', '')
                ->whereIn('topic_id', function ($query) use ($batch) {
                    $query->select('topic_id')
                        ->from('za_syllabus_update')
                        ->where('za_syllabus_update.course_id', $batch->course_id)
                        ->whereRaw('CAST(za_syllabus_update.percentage AS DECIMAL(10,2)) = 100.00'); // Precise match for percentage
                });

            // Get the ca_text_link values (which are encrypted)
            $exam_ids = $exam_ids_query->pluck('ca_text_link'); // Retrieve only ca_text_link

            // Initialize the helper
            $helper = new \App\Helpers\Helpers();

            // Decrypt the ca_text_link values before returning them
            $decrypted_exam_ids = $exam_ids->map(function ($encryptedId) use ($helper) {
                if (!empty($encryptedId)) {
                    // Decrypt the value using your helper method
                    $decrypted = $helper->encrypt_decrypt($encryptedId, 'decrypt');
                    return $decrypted;
                }
                return null;
            });

            // Append data for each batch with decrypted exam IDs
            $allBatchesData[] = [
                'customer_id' => $batch->customer_id,
                'course_id' => $batch->course_id,
                'batch_id' => $batch->batch_id,
                'course_name' => $batch->course_name,
                'exam_count' => $exam_count,
                'exam_ids' => $decrypted_exam_ids // Return the decrypted IDs
            ];
        }


        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);
    }


    public function StudentExamTopicList(Request $request)
    {
        $customer_id = $request->customer_id; // Retrieve customer ID
        $exam_ids = $request->exam_ids; // Retrieve the array of exam IDs

        // Get the student information
        $student = CustomerModel::where('sno', $customer_id)->first();

        if (!$student) {
            return response()->json([
                'status' => 404,
                'message' => 'Student not found',
                'error_msg' => 'Invalid customer ID',
                'data' => null,
            ], 404);
        }

        // Fetch the exam topic list based on the provided exam IDs
        $exam_topic_query = ExamModel::whereIn('sno', $exam_ids) // Filter exams by the provided IDs
            ->where('za_exam.status', 0); // Check for exams with active status (assuming 0 means active)

        // If the student has a specific branch, filter exams by the branch_id
        if ($student->branch_id != 0) {
            $exam_topic_query->where('za_exam.branch_id', $student->branch_id);
        }

        // Execute the query to get the exam list
        $exam_list = $exam_topic_query->get();

        // Process the exams and decode question IDs
        $exam_data = [];
        foreach ($exam_list as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedQuestions = json_decode($exam->exam_question_ids, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            $questionIds = $decodedQuestions ? array_column($decodedQuestions, 'question_id') : [];

            // Prepare exam data
            $exam_data[] = [
                'exam_id' => $exam->exam_id,
                'sno' => $exam->sno,
                'is_group' => $exam->is_group,
                'question_bank_id' => $exam->question_bank_id,
                'exam_type' => $exam->exam_type,
                'exam_duration' => $exam->exam_duration,
                'exam_name' => $exam->exam_name,
                'exam_start_date' => $exam->exam_start_date,
                'exam_end_date' => $exam->exam_end_date,
                'no_of_attempt' => $exam->no_of_attempt,
                'positive_mark_per_quest' => $exam->positive_mark_per_quest,
                'negative_mark_per_quest' => $exam->negative_mark_per_quest,
                'exam_attempt' => $exam->exam_attempt,
                'question_ids' => $questionIds,
                'no_of_questions' => $exam->no_of_questions,
                'total_marks' => $exam->total_marks,
                'exam_hint' => $exam->exam_hint,
                'hint_text' => $exam->hint_text,
                'exam_explanation' => $exam->exam_explanation,
                'explanation_text' => $exam->explanation_text,
                'display_total_score' => $exam->display_total_score,
                'certificate' => $exam->certificate,
                'exam_mode' => $exam->exam_mode,
                'exam_mode_amount' => $exam->exam_mode_amount,
                'exam_mode_points' => $exam->exam_mode_points,
                'exam_description' => $exam->exam_description,
                'thumbnail_image' => $exam->thumbnail_image,
                'status' => $exam->status,


            ];
        }

        // Return the exam data as a response
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $exam_data, // Return processed exam data
        ], 200);
    }

    // //exam app
    public function ExamList(Request $request)
    {
        $customer_id = $request->customer_id;

        $student = Student::where('status',0)->find($customer_id);

        // Validate if student exists
        if (!$student) {
            return response()->json([
                'status' => 404,
                'message' => 'Student not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
            ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
            ->where('za_exam.status', '!=', 2);

        // Filter by student's branch if applicable
        if ($student->branch_id != 0) {
            $exam_list->where('za_exam.branch_id', $student->branch_id);
        }

        // Retrieve specific exam linked to the student’s exam ID
        $exam_list = $exam_list->where('za_exam.sno', $student->exam_id)->first();

        if (!$exam_list) {
            return response()->json([
                'status' => 200,
                'message' => 'No exam data available',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        // Initialize the response data
        $exam_data = [];

        // Handle group exam details
        if ($exam_list->is_group == 1) {
            $multi_exam_details = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
                ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
                ->where('za_exam.status', '!=', 2);

            if ($student->branch_id != 0) {
                $multi_exam_details->where('za_exam.branch_id', $student->branch_id);
            }

            // Fetch the details of multiple exams using the `multi_exam_ids` field
            $multi_exam_details = $multi_exam_details
                ->whereIn('za_exam.sno', json_decode($exam_list->multi_exam_ids, true))
                ->get();
             // Decode the JSON in the `exam_status` field
             $examDats = json_decode($student->exam_status, true);
            //  return $examDats;
            foreach ($multi_exam_details as $exam) {
                // Decode the exam_question_ids JSON string
                $decodedQuestions = json_decode($exam->exam_question_ids, true) ?? [];

                // Extract the question IDs
                $questionIds = array_column($decodedQuestions, 'question_id');
                  // Find the exam_status based on exam_id
                 
                    $examStatus = [];
                    
                    foreach ($examDats as $statusData) {
                        if ($statusData['exam_id'] == $exam->sno) {
                         $examStatus = $statusData['exam_status'];
                        }
                    }



                // Prepare exam data
                $exam_data[] = [
                    'exam_id' => $exam->exam_id,
                    'sno' => $exam->sno,
                    'is_group' => $exam->is_group,
                    'question_bank_id' => $exam->question_bank_id,
                    'exam_type' => $exam->exam_type,
                    'exam_duration' => $exam->exam_duration,
                    'exam_name' => $exam->exam_name,
                    'exam_start_date' => $exam->exam_start_date,
                    'exam_end_date' => $exam->exam_end_date,
                    'no_of_attempt' => $exam->no_of_attempt,
                    'positive_mark_per_quest' => $exam->positive_mark_per_quest,
                    'negative_mark_per_quest' => $exam->negative_mark_per_quest,
                    'exam_attempt' => $exam->exam_attempt,
                    'question_ids' => $questionIds,
                    'no_of_questions' => $exam->no_of_questions,
                    'total_marks' => $exam->total_marks,
                    'exam_hint' => $exam->exam_hint,
                    'hint_text' => $exam->hint_text,
                    'exam_explanation' => $exam->exam_explanation,
                    'explanation_text' => $exam->explanation_text,
                    'display_total_score' => $exam->display_total_score,
                    'certificate' => $exam->certificate,
                    'exam_mode' => $exam->exam_mode,
                    'exam_status' => $examStatus,
                    'exam_mode_amount' => $exam->exam_mode_amount,
                    'exam_mode_points' => $exam->exam_mode_points,
                    'exam_description' => $exam->exam_description,
                    'thumbnail_image' => $exam->thumbnail_image,
                    'status' => $exam->status,
                ];
            }
        } else {
            // Decode question IDs from single exam details
            $decodedQuestions = json_decode($exam_list->exam_question_ids ?? '[]', true) ?? [];
            $questionIds = array_column($decodedQuestions, 'question_id');

            // Prepare single exam data with the same structure
            $exam_data[] = [
                'exam_id' => $exam_list->exam_id,
                'sno' => $exam_list->sno,
                'is_group' => $exam_list->is_group,
                'question_bank_id' => $exam_list->question_bank_id,
                'exam_type' => $exam_list->exam_type,
                'exam_duration' => $exam_list->exam_duration,
                'exam_name' => $exam_list->exam_name,
                'exam_start_date' => $exam_list->exam_start_date,
                'exam_end_date' => $exam_list->exam_end_date,
                'no_of_attempt' => $exam_list->no_of_attempt,
                'positive_mark_per_quest' => $exam_list->positive_mark_per_quest,
                'negative_mark_per_quest' => $exam_list->negative_mark_per_quest,
                'exam_attempt' => $exam_list->exam_attempt,
                'question_ids' => $questionIds,
                'no_of_questions' => $exam_list->no_of_questions,
                'total_marks' => $exam_list->total_marks,
                'exam_hint' => $exam_list->exam_hint,
                'hint_text' => $exam_list->hint_text,
                'exam_explanation' => $exam_list->exam_explanation,
                'explanation_text' => $exam_list->explanation_text,
                'display_total_score' => $exam_list->display_total_score,
                'certificate' => $exam_list->certificate,
                'exam_mode' => $exam_list->exam_mode,
                'exam_mode_amount' => $exam_list->exam_mode_amount,
                'exam_mode_points' => $exam_list->exam_mode_points,
                'exam_description' => $exam_list->exam_description,
                'thumbnail_image' => $exam_list->thumbnail_image,
                'status' => $exam_list->status,
            ];
        }


        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $exam_data,
        ], 200);
    }

    public function ExamGuidelines()
    {
        $exam_guidelines = Exam_guidelinesModel::where('status', 0)
            ->where('sno', 1)->orderBy('sno', 'desc')->first();


        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $exam_guidelines,
        ], 200);
    }


    public function ExamQuestions(Request $request)
    {
        $customer_id = $request->customer_id; // Retrieve customer ID
        $exam_id = $request->exam_id;

        // Get the student information
        $student = Student::where('id', $customer_id)->first();

        $exam_question = ExamModel::where('za_exam.sno', $exam_id)->select('za_exam.*', 'za_exam_question_bank.question_bank_name') // Filter exams by the provided IDs
            ->where('za_exam.status', 0)
            ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id');  // Check for exams with active status (assuming 0 means active)

        // If the student has a specific branch, filter exams by the branch_id
        if ($student->branch_id != 0) {
            $exam_question->where('za_exam.branch_id', $student->branch_id);
        }

        // Get the exam that matches the student's exam ID
        $exam_list = $exam_question->first();
        $exams = $exam_list;
        if ($exams) {
            // Decode exam_question_ids if it's a JSON string
            if (isset($exams->exam_question_ids) && is_string($exams->exam_question_ids)) {
                $exams->exam_question_ids = json_decode($exams->exam_question_ids, true);
            }
        }

        // Handle cases where decoding fails or returns unexpected results
        if (!isset($exams->exam_question_ids) || !is_array($exams->exam_question_ids)) {
            $exams->exam_question_ids = [];
        }

        // Decode question IDs from exam details
        $examQuestionIds = collect($exam_list->exam_question_ids ?? '[]')
            ->pluck('question_id')->toArray();

        // Fetch questions with hints, explanations, and options
        $examQuestions = ManageQuestionModel::select('za_exam_question.*')
            ->whereIn('za_exam_question.sno', $examQuestionIds)
            ->where('za_exam_question.status', 0)
            ->get();

        // Process the exams and decode question IDs
        $exam_data = [];
        foreach ($examQuestions as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedOption = json_decode($exam->question_option, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            // $questionIds = $decodedOption ? array_column($decodedOption, 'question_id') : [];

            // Prepare exam data
            $exam_data[] = [
                'question_id' => $exam->sno,
                'branch_id' => $exam->branch_id,
                'question_bank_id' => $exam->question_bank_id,
                'question_name' => $exam->question_name,
                'question_type' => $exam->question_type,
                'exam_name' => $exam->exam_name,
                 'exam_level' => $exam->exam_level,
                'question_id_auto' => $exam->question_id,
                'question_option' => $decodedOption,
                'answer' => $exam->answer,
                'question_hint' => $exam->question_hint,
                'question_explanation' => $exam->negative_mark_per_quest,
                'hint_text' => $exam->hint_text,
                'explanation_text' => $exam->explanation_text,
                'question_snippet' => $exam->question_snippet,
                'snippet_content' => $exam->snippet_content,
                'status' => $exam->status,


            ];
        }
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'Exam Details' => $exams,
            'Exam Questions' => $exam_data,
        ], 200);
    }


    public function saveAnswer(Request $request)
    {
        $examModel = ExamModel::where('sno', $request->exam_id)->first();
        if (!$examModel) {
            return response()->json(['error' => 'Invalid exam ID'], 400);
        }

        $answerData = $request->input('answer_data', []);
        $answer = $answerData['answer'] ?? null;
        $timeSpent = $answerData['time_spent'] ?? 0;

        // if (is_null($answer)) {
        //     return response()->json(['error' => 'Answer data is missing'], 400);
        // }

        $examProcess = ExamProcessModel::firstOrCreate(
            ['exam_id' => $request->exam_id, 'student_id' => $request->customer_id],
            [
                'exam_process_id' => uniqid(),
                'branch_id' => $examModel->branch_id,
                'total_marks' => $examModel->total_marks ?? 0,
                'student_marks' => $examModel->total_marks ?? 0,
                'attempted_not_count' => 0,
                'total_attended_duration' => 0,
                'status' => 1,
                'exam_question_answers_datas' => [],
                'created_by' => $request->customer_id,
                'updated_by' => $request->customer_id,
            ]
        );

        $answers = $examProcess->exam_question_answers_datas ?? [];
        $index = array_search($request->question_id, array_column($answers, 'question_id'));

        if ($index === false) {
            $answers[] = [
                'question_id' => $request->question_id,
                'answer' => $answer,
                'time_spent' => $timeSpent,
                'correctness' => $this->checkAnswer($request->question_id, $answer),
            ];
        } else {
            $answers[$index]['answer'] = $answer;
            $answers[$index]['time_spent'] = $timeSpent;
            $answers[$index]['correctness'] = $this->checkAnswer($request->question_id, $answer);
        }

        // Additional calculations
        $skipcount = 0;
        $correctcount = 0;
        foreach ($answers as $ans) {
            if (empty($ans['answer'])) {
                $skipcount++;
            }
            if ($ans['correctness'] === 'correct') {
                $correctcount++;
            }
        }

        $examProcess->student_marks = $correctcount * $examModel->positive_mark_per_quest;
        $notattempt = $examModel->no_of_questions - count($answers);
        $examProcess->attempted_not_count = $notattempt + $skipcount;
        $examProcess->total_attended_duration = array_reduce($answers, fn($carry, $item) => $carry + $item['time_spent'], 0);

        if (count($answers) == $examModel->no_of_questions) {
            $examProcess->status = 2;
            $examProcess->save();

            $student = Student::find($request->customer_id);
            if ($student) {
                $examStatuses = json_decode($student->exam_status, true) ?? [];
                foreach ($examStatuses as &$exam) {
                    if ($exam['exam_id'] == $request->exam_id) {
                        $exam['exam_status'] = 2;
                        break;
                    }
                }
                $student->exam_status = json_encode($examStatuses);
                $student->save();
            }
        }

        $examProcess->exam_question_answers_datas = $answers;
        $examProcess->save();

        return response()->json(['message' => 'Answer and time saved successfully']);
    }

    public function checkAnswer($questionId, $answer)
    {
        // Logic to check if the answer is correct (you'll need to modify this)
        $question = ManageQuestionModel::find($questionId);
        if ($question->answer == $answer) {
            return 'correct';
        }
        return 'incorrect';
    }

    public function examResult(Request $request)
    {
        $customer_id = $request->customer_id;
        $exam_id = $request->exam_id;
        // Retrieve the authenticated student
        $student = Student::where('id', $customer_id)->first();

        // Fetch exam details associated with the student
        $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
            ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
            ->where('za_exam.status', '!=', 2);

        // Filter by student's branch if applicable
        if ($student->branch_id != 0) {
            $exam_list->where('za_exam.branch_id', $student->branch_id);
        }

        // Retrieve specific exam linked to the student’s exam ID
        $exam_list = $exam_list->where('za_exam.sno', $exam_id)->first();
        $decodedQuestions = json_decode($exam_list->exam_question_ids ?? '[]', true) ?? [];
        $questionIds = array_column($decodedQuestions, 'question_id');

        // Prepare single exam data with the same structure
        $exam_data_list[] = [
            'exam_id' => $exam_list->exam_id,
            'sno' => $exam_list->sno,
            'is_group' => $exam_list->is_group,
            'question_bank_id' => $exam_list->question_bank_id,
            'exam_type' => $exam_list->exam_type,
            'exam_duration' => $exam_list->exam_duration,
            'exam_name' => $exam_list->exam_name,
            'exam_start_date' => $exam_list->exam_start_date,
            'exam_end_date' => $exam_list->exam_end_date,
            'no_of_attempt' => $exam_list->no_of_attempt,
            'positive_mark_per_quest' => $exam_list->positive_mark_per_quest,
            'negative_mark_per_quest' => $exam_list->negative_mark_per_quest,
            'exam_attempt' => $exam_list->exam_attempt,
            'question_ids' => $questionIds,
            'no_of_questions' => $exam_list->no_of_questions,
            'total_marks' => $exam_list->total_marks,
            'exam_hint' => $exam_list->exam_hint,
            'hint_text' => $exam_list->hint_text,
            'exam_explanation' => $exam_list->exam_explanation,
            'explanation_text' => $exam_list->explanation_text,
            'display_total_score' => $exam_list->display_total_score,
            'certificate' => $exam_list->certificate,
            'exam_mode' => $exam_list->exam_mode,
            'exam_mode_amount' => $exam_list->exam_mode_amount,
            'exam_mode_points' => $exam_list->exam_mode_points,
            'exam_description' => $exam_list->exam_description,
            'thumbnail_image' => $exam_list->thumbnail_image,
            'status' => $exam_list->status,
        ];

        // Decode question IDs from exam details
        $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
            ->pluck('question_id')->toArray();

        // Fetch questions with hints, explanations, and options
        $examQuestions = ManageQuestionModel::select('za_exam_question.*')
            ->whereIn('za_exam_question.sno', $examQuestionIds)
            ->where('za_exam_question.status', 0)
            ->get();
        $exam_data_question = [];
        foreach ($examQuestions as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedOption = json_decode($exam->question_option, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            // $questionIds = $decodedOption ? array_column($decodedOption, 'question_id') : [];

            // Prepare exam data
            $exam_data_question[] = [
                'question_id' => $exam->sno,
                'branch_id' => $exam->branch_id,
                'question_bank_id' => $exam->question_bank_id,
                'question_name' => $exam->question_name,
                'question_type' => $exam->question_type,
                'exam_name' => $exam->exam_name,
                'question_id_auto' => $exam->question_id,
                'question_option' => $decodedOption,
                'answer' => $exam->answer,
                'question_hint' => $exam->question_hint,
                'question_explanation' => $exam->negative_mark_per_quest,
                'hint_text' => $exam->hint_text,
                'explanation_text' => $exam->explanation_text,
                'question_snippet' => $exam->question_snippet,
                'snippet_content' => $exam->snippet_content,
                'status' => $exam->status,


            ];
        }

        $examProcess = ExamProcessModel::where('exam_id', $exam_id)
            ->where('student_id', $student->id)
            ->where('branch_id', $student->branch_id)
            ->first();

        $examProcess2 = ExamProcessModel::where('exam_id', $exam_id)
            ->where('student_id', $student->id)
            ->where('branch_id', $student->branch_id)
            ->first();

            $percentage_mark=0;
          if($examProcess2->total_marks >0){
            $percentage_mark = ($examProcess2->student_marks / $examProcess2->total_marks)*100;
          }
          $percentage_mark = number_format($percentage_mark, 1);

        $examdata2[] = [
            'exam_process_id' => $examProcess2->exam_process_id,
            'sno' => $examProcess2->sno,
            'branch_id' => $examProcess2->branch_id,
            'exam_id' => $examProcess2->exam_id,
            'student_id' => $examProcess2->student_id,
            'total_marks' => $examProcess2->total_marks,
            'student_marks' => $examProcess2->student_marks,
            "percentage"=>$percentage_mark,
            'attempted_not_count' => $examProcess2->attempted_not_count,
            'total_attended_duration' => $examProcess2->total_attended_duration,
            'display_answers' => $exam_list->display_answers,
            'exam_level' => $exam_list->exam_level,
            'status' => $examProcess2->status
        ];
        // return $examProcess;

        // Check if $examProcess is not null before accessing its property
        if ($examProcess && isset($examProcess->exam_question_answers_datas)) {
            // If the field is already an array, use it directly
            $savedAnswers = is_array($examProcess->exam_question_answers_datas)
                ? $examProcess->exam_question_answers_datas
                : [];
        } else {
            // Handle the case where no exam process is found or the field is empty
            $savedAnswers = [];
        }

        $totalCorrect = 0;
        $totalIncorrect = 0;

        foreach ($savedAnswers as $answer) {
            // Assuming $question->answer holds the correct answer and $answer['answer'] is the student's answer
            if (isset($answer['answer'])) {
                $isCorrect = ($answer['correctness'] === 'correct');
                if ($isCorrect) {
                    $totalCorrect++;
                } else {
                    $totalIncorrect++;
                }
            }
        }
        $examProcess = $examProcess;
        $examQuestions = $exam_data_question;

        $mergedQuestions = [];

        foreach ($examQuestions as $question) {
            $questionId = $question['question_id'];

            // Find the matching answer from exam process data
            $answerData = collect($examProcess['exam_question_answers_datas'])
                ->firstWhere('question_id', (string) $questionId);

            $mergedQuestions[] = [
                'question_id' => $question['question_id'],
                'question_name' => $question['question_name'],
                'question_type' => $question['question_type'],
                'question_options' => $question['question_option'],
                'correct_answer' => $question['answer'],
                'hint_text' => $question['hint_text'],
                'explanation_text' => $question['explanation_text'],
                'student_answer' => $answerData['answer'] ?? null,
                'time_spent' => $answerData['time_spent'] ?? null,
                'correctness' => $answerData['correctness'] ?? 'not attempted',
            ];
        }

        // Return or use $mergedQuestions as needed
        // return response()->json(['merged_questions' => $mergedQuestions]);

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'merged_questions' => $mergedQuestions,
            'Exam Process' => $examdata2, // Total exams
            // 'Exam Questions' => $exam_data_question, // Finished exams
            'Exam list' => $exam_data_list, // Finished exams
        ], 200);
    }
    
    public function ExamDash(Request $request)
    {
        $customer_id = $request->customer_id; // Retrieve customer ID

        // Fetch student data including the `exam_status` field
        $student = Student::select('id', 'exam_status')->where('id', $customer_id)->first();

        if (!$student) {
            return response()->json([
                'status' => 404,
                'message' => 'Student not found',
                'error_msg' => null,
            ], 404);
        }

        // Decode the JSON in the `exam_status` field
        $examData = json_decode($student->exam_status, true);

        // Ensure $examData is an array
        if (!is_array($examData)) {
            $examData = []; // Default to an empty array if decoding fails
        }

        // Total number of exams
        $totalCount = count($examData);

        // Count exams where `exam_status` is 2 (finished exams)
        $finishedCount = collect($examData)->filter(function ($exam) {
            return isset($exam['exam_status']) && $exam['exam_status'] == 2;
        })->count();

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'Total Exam' => $totalCount, // Total exams
            'Finished Exam' => $finishedCount, // Finished exams
            'Remaining Exam' => $totalCount - $finishedCount, // Finished exams
        ], 200);
    }

    public function ExamCompleteList(Request $request)
    {
    $customer_id = $request->customer_id;

    // Fetch the student record
    $student = Student::find($customer_id);

    // Validate if student exists
    if (!$student) {
        return response()->json([
            'status' => 404,
            'message' => 'Student not found',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }

    // Decode the `exam_id` JSON data safely
    $examData = json_decode($student->exam_status, true);

    // Ensure `$examData` is an array
    if (!is_array($examData)) {
        return response()->json([
            'status' => 200,
            'message' => 'No valid exam data found',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    // Filter for completed exams (exam_status = 2)
    $completedExams = array_filter($examData, function ($exam) {
        return isset($exam['exam_status']) && $exam['exam_status'] == 2;
    });

    if (empty($completedExams)) {
        return response()->json([
            'status' => 200,
            'message' => 'No completed exams found',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    // Extract the `exam_id`s of the completed exams
    $completedExamIds = array_column($completedExams, 'exam_id');

    // Fetch details of the completed exams from the `za_exam` table
    $examDetails = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
        ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
        ->whereIn('za_exam.sno', $completedExamIds)
        ->get();

    // Prepare the response data
    $examData = $examDetails->map(function ($exam) {
        $decodedQuestions = json_decode($exam->exam_question_ids, true) ?? [];
        $questionIds = array_column($decodedQuestions, 'question_id');

        return [
            'exam_id' => $exam->exam_id,
            'sno' => $exam->sno,
            'is_group' => $exam->is_group,
            'question_bank_id' => $exam->question_bank_id,
            'exam_type' => $exam->exam_type,
            'exam_duration' => $exam->exam_duration,
            'exam_name' => $exam->exam_name,
            'exam_start_date' => $exam->exam_start_date,
            'exam_end_date' => $exam->exam_end_date,
            'no_of_attempt' => $exam->no_of_attempt,
            'positive_mark_per_quest' => $exam->positive_mark_per_quest,
            'negative_mark_per_quest' => $exam->negative_mark_per_quest,
            'exam_attempt' => $exam->exam_attempt,
            'question_ids' => $questionIds,
            'no_of_questions' => $exam->no_of_questions,
            'total_marks' => $exam->total_marks,
            'exam_hint' => $exam->exam_hint,
            'hint_text' => $exam->hint_text,
            'exam_explanation' => $exam->exam_explanation,
            'explanation_text' => $exam->explanation_text,
            'display_total_score' => $exam->display_total_score,
            'certificate' => $exam->certificate,
            'exam_mode' => $exam->exam_mode,
            'exam_mode_amount' => $exam->exam_mode_amount,
            'exam_mode_points' => $exam->exam_mode_points,
            'exam_description' => $exam->exam_description,
            'thumbnail_image' => $exam->thumbnail_image,
            'status' => $exam->status,
        ];
    });

    // Return the response
    return response()->json([
        'status' => 200,
        'message' => 'Completed Exams Retrieved Successfully',
        'error_msg' => null,
        'data' => $examData,
    ], 200);
}


    public function StudentLogout(Request $request)
    {
        try {
            $user = $request->user()->token()->revoke();
            if ($user) {
                $response = [
                    'status' => 200,
                    'message' => 'You have been successfully logged out!',
                    'error_msg' => null,
                    'data' => null
                ];
                return response($response, 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'User Not Found',
                    'error_msg' => null,
                    'data' => null
                ], 500);
            }
        } catch (\Throwable $th) {
            return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
        }
    }
}