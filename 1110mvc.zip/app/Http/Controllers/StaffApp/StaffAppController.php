<?php

namespace App\Http\Controllers\StaffApp;


use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\settings\counsellor\SelfAssessment;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\StaffModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\AttendanceModel;
use App\Models\TrainingModel;
use App\Helpers\Helpers;
use App\Models\Student;
use App\Models\SyllabusUpdateModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\UserRoleModel;
use App\Models\OtpModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Auth;
use App\Models\ManageQuestionModel;
use App\Models\ExamModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffExamProcessModel;
use App\Models\CugManagementModel;
use function PHPUnit\Framework\isEmpty;
class StaffAppController extends Controller
{

    public function StaffLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $key      = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {

            // $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();
            $staffuser = CugManagementModel::where('staff_mobile', $mobile_no)->where('status', 0)->first();
            
            // return $staffuser;
            if ($staffuser) {
                $user = StaffModel::where('sno', $staffuser->staff_id)->where('status', 0)->first();
                // // Attempt to log in the user
                // if (Auth::attempt(['user_id' => $user->user_id, 'password' => $password])) {
                //     // Authentication successful, check role
                //     if (Auth::check() && Auth::user()->hasRole('counsellor')) {
                //         // User is authenticated and has the 'counsellor' role
                //         return response()->json(['message' => 'Login successful']);
                //     } else {
                //         // User does not have the 'counsellor' role
                //         Auth::logout();
                //         return response()->json(['error' => 'Unauthorized'], 403);
                //     }
                // } else {
                //     // Authentication failed
                //     return response()->json(['error' => 'Invalid credentials'], 401);
                // }
                  if( $mobile_no == "9790464324"){
                        $otp_value  = 123456; // Random 6-digit OTP
                    }else{
                        $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                    } // Random 6-digit OTP

                // Save OTP to Database
                
                $otp = new OtpModel();

                $otp->user_id                  = $user->sno;
                $otp->mobile_no                =  $mobile_no;
                $otp->otp_number               = $otp_value;
                $otp->created_by               = $user->sno;
                $otp->updated_by               = $user->sno;
                $otp->save();
                // sms otp 
                 if( $mobile_no != "9790464324"){
                    if ($otp_value) {

                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $mobile_no;

                    $app_name = "Clari";
                    // $app_link = 'https://elysiumacademy.org/';
                    $app_code = "s4SLEIYvbc5";
                    // Replace placeholders with actual values
                    $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);

                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
                }
                 }
                $usertable = User::where('user_id', $user->sno)->first();
                $token     = $usertable->createToken('authToken')->accessToken;
                $roleId    = UserRoleModel::where('status', 0)->where('sno', $user->role_id)->first();
                $check     = UserRoleModel::where('status', 0)->get();
                // $underRole = $check->contains('user_role_id', $roleId->sno) ? 'Yes' : 'No';
                $underRole =  'Yes';
                // $check = UserRoleModel::where('status', 0)->first();
                // $underRole = $check && $check->sno == $roleId->sno ? 'Yes' : 'No';
                $baseUrl = 'https://erp.elysium.academy/staff_images/';
                // return $roleId;
                return response()->json([
                     'otp'        => $otp_value,
                    'status'     => strval($user->status),
                    'staff_id'   => $user->sno,
                    'Gender'   => $user->gender,
                    'UnderRole'  => $underRole,
                    'staff_name'   => $user->staff_name,
                    'staff_image'       => $baseUrl . $user->staff_image ?? null,
                    'message'    => 'Successfully',
                    "error_msg"  => null,
                    'data'       => null,
                    'api_token'  => $token,
                ], 200);
            } else {
                $response = [
                    'status' => "2",
                    'message' => 'User does not exist',
                    "error_msg" => null,
                    'data' => null
                ];
                return response($response, 200);
            }
        }
    }
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        // $expiryTime = $createdAt->copy()->addMinutes(2);
        // $currentTime = Carbon::now('UTC');
    
        // if ($currentTime->greaterThan($expiryTime)) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'OTP expired. Please request a new one.'
        //     ], 410);
        // }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }
    // public function staffUnderlist(Request $request)
    // {
    //     $staff_id = $request->staff_id;

    //     // Fetch the role of the staff member based on the staff ID
    //     $roleId = StaffModel::where('status', 0)->where('sno', $staff_id)->first();
    //     //  i want get staff list under this staff how foreach or new method

    //     $check = UserRoleModel::where('status', 0)->where('user_role_id', $roleId->role_id)->first();
    //     $check1 = UserRoleModel::where('status', 0)->where('user_role_id', $check->sno)->first();
    //     $check2 = UserRoleModel::where('status', 0)->where('user_role_id', $check1->sno)->first();
    //     $check3 = UserRoleModel::where('status', 0)->where('user_role_id', $check2->sno)->first();
    //     return  $check3;
    //     // $check4 = UserRoleModel::where('status', 0)->where('user_role_id', $check3->sno)->first();
    //     // return  $check4;
    //     // Initialize an empty array to store the under roles
    //     $underRole = [];

    //     // Loop through the roles and check if any role's user_role_id matches the roleId's sno
    //     foreach ($check as $role) {
    //         if ($role->user_role_id == $roleId->sno) {
    //             $underRole[] = $role->sno;
    //         }
    //     }
    //     // $check based get all satff
    //     // Fetch the staff list
    //     $Staff_list = StaffModel::where('status', 0)->get();

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Staff List Retrieved Successfully',
    //         'error_msg' => null,
    //         // 'data' => $Staff_list,
    //         'under_role' => $underRole,  // Include the under roles in the response
    //     ], 200);
    // }
    // public function staffUnderlist(Request $request)
    // {
    //     $staff_id = $request->staff_id;

    //     // Fetch the role of the staff member based on the staff ID
    //     $roleId = StaffModel::where('status', 0)->where('sno', $staff_id)->first();

    //     // Initialize an array to store all role IDs under the current staff member's role
    //     $underRoleIds = [];

    //     // Function to recursively find all roles under the given role
    //     $currentRoleId = $roleId->role_id;
    //   // return $currentRoleId;
    //     while ($currentRoleId) {
    //         // Find the next role in the hierarchy
    //         $nextRole = UserRoleModel::where('status', 0)->where('user_role_id', $currentRoleId)->first();

    //         if ($nextRole) {
    //             // Add the role ID to the array
    //             $underRoleIds[] = $nextRole->sno;
    //             // Move to the next role in the hierarchy
    //             $currentRoleId = $nextRole->sno;
    //         } else {
    //             // Stop if no more roles are found
    //             $currentRoleId = null;
    //         }
    //     }

    //     // Fetch the staff members who are under these roles
    //     $Staff_list = StaffModel::where('status', 0)
    //         ->whereIn('role_id', $underRoleIds)
    //         ->select('staff_name', 'sno as staff_id')
    //         ->get();

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Staff List Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => $Staff_list, // Return the staff list
    //         'under_role' => $underRoleIds, // Include the under roles in the response
    //     ], 200);
    // }
    // public function staffUnderlist(Request $request)
    // {
    //     $staff_id = $request->staff_id;
    
    //     // Validate the staff ID input
    //     if (!$staff_id) {
    //         return response()->json([
    //             'status' => 400,
    //             'message' => 'Staff ID is required',
    //             'error_msg' => 'Invalid or missing staff ID',
    //             'data' => null,
    //         ], 400);
    //     }
    //     $roleId       = StaffModel::where('status', 0)->where('sno', $staff_id)->first();
    //     $branch_check = BranchModel::where('sno', $roleId->branch_id)->orderBy('sno', 'desc')->first();
        
    //     // Fetch the role of the staff member based on the staff ID
    //     $role = StaffModel::where('status', 0)->where('sno', $staff_id)->where('branch_id', $branch_check->sno)->first();
    
    //     if (!$role) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Staff not found',
    //             'error_msg' => 'No staff member found with the given ID',
    //             'data' => null,
    //         ], 404);
    //     }
    
    //     // Initialize an array to store all role IDs under the current staff member's role
        
    //     $currentRoleId = $role->role_id;
    //      // Fetch all roles with status = 0 in one go
    //     $allRoles = UserRoleModel::where('status', 0)->where('user_role_id', $currentRoleId)
    //         ->pluck('sno')
    //         ->toArray();
    //     // return $role;
    //     // Initialize an array to store all role IDs under the current staff member's role
    //     $underRoleIds = [];
    //     $queue = $allRoles;
    //     //   return  $queue;
    //     // Use a queue to fetch all roles recursively
    //     while (!empty($queue)) {
    //         $roleId = array_shift($queue);
        
    //         // Add the role ID to the list if not already added
    //         if (!in_array($roleId, $underRoleIds)) {
    //             $underRoleIds[] = $roleId;
        
    //             // Find the roles related to the current role ID
    //             $nextRoles = array_filter($allRoles, function ($roles) use ($roleId) {
    //                 return $roles !== $roleId; // Exclude the current role ID
    //             });
        
    //             // Add these roles to the queue for further processing
    //             $queue = array_merge($queue, $nextRoles);
    //         }
    //     }
    //     // Fetch the staff members who are under these roles
    //     $staffList = StaffModel::where('status', 0)
    //         ->whereIn('role_id', $underRoleIds)->where('branch_id', $branch_check->sno)
    //         ->select('staff_name', 'sno as staff_id')
    //         ->get();
    
    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Staff List Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => $staffList, // Return the staff list
    //         'under_role' => $underRoleIds, // Include the under roles in the response
    //     ], 200);
    // }

   public function staffUnderlist(Request $request)
{
    $staff_id = $request->staff_id;

    // Validate the staff ID input
    if (!$staff_id) {
        return response()->json([
            'status' => 400,
            'message' => 'Staff ID is required',
            'error_msg' => 'Invalid or missing staff ID',
            'data' => null,
        ], 400);
    }

    // Retrieve staff details
    $branchId = StaffModel::where('status', 0)->where('sno', $staff_id)->first();

    if (!$branchId) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Invalid staff ID',
            'data' => null,
        ], 404);
    }

    // Retrieve branch details
    $branch_check = BranchModel::where('sno', $branchId->branch_id)->orderBy('sno', 'desc')->first();

    if (!$branch_check) {
        return response()->json([
            'status' => 404,
            'message' => 'Branch not found',
            'error_msg' => 'Staff is not assigned to a valid branch',
            'data' => null,
        ], 404);
    }

    // Fetch staff list
    $staffList = StaffModel::where('status', 0)
        ->where('role_id', 22) // Changed whereIn to where, since single value
        ->where('branch_id', $branch_check->sno)
        ->select('staff_name', 'sno as staff_id')
        ->get();

    // Ensure $underRoleIds is defined (set it to an empty array if it's not used)
    $underRoleIds = []; // Define or modify as needed

    return response()->json([
        'status' => 200,
        'message' => 'Staff List Retrieved Successfully',
        'error_msg' => null,
        'data' => $staffList,
        'under_role' => $underRoleIds,
    ], 200);
}





    public function staffBatch(Request $request)
    {
        $id = $request->staff_id;
        $topics = [];
        $allBatchesData = []; // To store data for each batch

        // Subquery to calculate allocated students
        $allocatedStudentsSubquery = DB::table('za_training')
            ->select(DB::raw('COUNT(*)'))
            ->whereRaw('za_training.batch_id = za_batch.sno');

        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.staff_id', $id)
            ->select(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time as slot_start_time',
                'za_slot.end_time as slot_end_time',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image',
                DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
            )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->get();

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        foreach ($batches as $batch) {
            // Format dates and times
            $batch->formatted_created = Carbon::parse($batch->created_at)->format($dateFormat);
            $batch->formatted_start_date = Carbon::parse($batch->start_date)->format($dateFormat);
            $batch->formatted_end_date = Carbon::parse($batch->end_date)->format($dateFormat);
            $batch->formatted_start_time = Carbon::parse($batch->start_time)->format('H:i:A');
            $batch->formatted_end_time = Carbon::parse($batch->end_time)->format('H:i:A');

            // Convert slot_type_days from JSON to an array of day names
            $dayIndices = json_decode($batch->slot_type_days);
            $dayNames = [];
            foreach ($dayIndices as $index) {
                $dayIndex = (int)$index - 1; // Convert to 0-based index
                $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
            }
            $batch->days = implode(', ', $dayNames);

            // Calculate available students
            $batch->available_students = $batch->max_students - $batch->allocated_students;

            // Fetch students for the batch
            $students = TrainingModel::where('za_training.batch_id', $batch->sno)
                ->where('za_training.course_id', $batch->course_id)
                ->where('za_training.status', 0)
                ->select('za_customer.sno as customer_id', 'za_customer.cus_pic', 'za_customer.cus_name', 'za_customer.cus_gender', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
                ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
                ->get();

            // Fetch the course view
            $view = ManageCoursesModel::where('sno', $batch->course_id)->first();
            if (!$view) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Batch Not Found',
                    'error_msg' => null,
                    'data' => null
                ], 404);
            }

            // Fetch chapters, sections, and topics
            $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->select('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours as practical_hours', 'course_chapter_theory_hours as theory_hours', DB::raw('MAX(sno) as max_sno'))
                ->groupBy('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours', 'course_chapter_theory_hours')
                ->get();
            // $sql = $chapter_views->toSql();
            // dd($chapter_views);

            foreach ($chapter_views as $chapter) {
                $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                    ->where('course_chapter_id', $chapter->course_chapter_id)
                    ->select('session_id', DB::raw('MAX(sno) as max_sno'))
                    ->where('status', 0)
                    ->groupBy('session_id')
                    ->get();

                $section[$chapter->course_chapter_id] = $latest_sections;

                foreach ($latest_sections as $sec) {
                    $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                        ->where('course_chapter_id', $chapter->course_chapter_id)
                        ->where('session_id', $sec->session_id)
                        ->where('status', 0)
                        ->select('topic_id', 'topic_name', DB::raw('MAX(sno) as max_sno'))
                        ->groupBy('topic_id', 'topic_name')
                        ->get();

                    $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
                }
            }

            // Store batch-specific data
            $allBatchesData[] = [
                'batch'    => $batch,
                'students' => $students,
                'chapter'  => $topics,
                'chapter Details'  => $chapter_views,

            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);
    }



    public function staffBatchDetails(Request $request)
    {
        $id = $request->staff_id;
        $date = $request->date;

        // Subquery to calculate allocated students
        $allocatedStudentsSubquery = DB::table('za_training')
            ->selectRaw('COUNT(*)')
            ->whereColumn('za_training.batch_id', 'za_batch.sno');

        $batches = BatchModel::query()
            ->select(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time as slot_start_time',
                'za_slot.end_time as slot_end_time',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image',
                DB::raw("({$allocatedStudentsSubquery->toSql()}) as allocated_students")
            )
            ->mergeBindings($allocatedStudentsSubquery)
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->where('za_batch.staff_id', $id)
            ->whereDate('za_batch.end_date', '>=', now()->toDateString())
            ->whereDate('za_batch.start_date', '<=', $date)
            ->whereDate('za_batch.end_date', '>=', $date)
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)

            // OR condition: EITHER attendance NOT created OR syllabus NOT created
            ->where(function ($query) use ($date) {
                $query->whereNotExists(function ($q) use ($date) {
                    $q->select(DB::raw(1))
                        ->from('za_attendance')
                        ->whereColumn('za_attendance.batch_id', 'za_batch.sno')
                        ->whereDate('za_attendance.att_date', $date)
                        ->where('za_attendance.status', 1);
                })
                ->orWhereNotExists(function ($q) use ($date) {
                    $q->select(DB::raw(1))
                        ->from('za_syllabus_update')
                        ->whereColumn('za_syllabus_update.batch_id', 'za_batch.sno')
                        ->whereDate('za_syllabus_update.date', $date)
                        ->where('za_syllabus_update.status', 0);
                });
            })

            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->get();

        foreach ($batches as $singleBatch) {
            $today = $date ?? Carbon::today()->format('Y-m-d');
            $attendance = AttendanceModel::whereDate('att_date', $today)
                ->where('batch_id', $singleBatch->sno)
                ->first();
            $singleBatch->att_status = $attendance ? 1 : 0;
        }

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

        $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        $currentDay = Carbon::now()->format('D');

        // Map through the batches to format dates and add additional fields
        $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
            $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
            $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
            $item->formatted_start_time = Carbon::parse($item->start_time)->format('H:i A');
            $item->formatted_end_time = Carbon::parse($item->end_time)->format('H:i A');

            $dayIndices = json_decode($item->slot_type_days);
            $dayNames = [];
            $item->slot_type_days = $dayIndices;
            foreach ($dayIndices as $index) {
                $dayIndex = (int)$index - 1;
                $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
            }

            $item->days = implode(', ', $dayNames);
            $item->available_students = $item->max_students - $item->allocated_students;

            return $item;
        });

        // Filter batches to only include those where the current day is in the days
        $filteredBatches = $formattedBatches->filter(function ($item) use ($currentDay) {
            return in_array($currentDay, explode(', ', $item->days));
        })->values();

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'batches' => $filteredBatches,
        ], 200);
    }
 
    public function staffBatchStudent(Request $request)
    {
        $id = $request->staff_id;
        $batch_id = $request->batch_id;
        $topics = [];
        $allBatchesData = []; // To store data for each batch

        // Subquery to calculate allocated students
        $allocatedStudentsSubquery = DB::table('za_training')
            ->select(DB::raw('COUNT(*)'))
            ->whereRaw('za_training.batch_id = za_batch.sno');

        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.staff_id', $id)
            ->select(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time as slot_start_time',
                'za_slot.end_time as slot_end_time',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image',
                DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
            )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->where('za_batch.sno', $batch_id)

            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->get();
        // return  $batches;

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        foreach ($batches as $batch) {
            // Format dates and times
            $batch->formatted_created = Carbon::parse($batch->created_at)->format($dateFormat);
            $batch->formatted_start_date = Carbon::parse($batch->start_date)->format($dateFormat);
            $batch->formatted_end_date = Carbon::parse($batch->end_date)->format($dateFormat);
            $batch->formatted_start_time = Carbon::parse($batch->start_time)->format('H:i:A');
            $batch->formatted_end_time = Carbon::parse($batch->end_time)->format('H:i:A');

            // Convert slot_type_days from JSON to an array of day names
            $dayIndices = json_decode($batch->slot_type_days);
            $dayNames = [];
            foreach ($dayIndices as $index) {
                $dayIndex = (int)$index - 1; // Convert to 0-based index
                $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
            }
            $batch->days = implode(', ', $dayNames);

            // Calculate available students
            $batch->available_students = $batch->max_students - $batch->allocated_students;

            // Fetch students for the batch
            $students = TrainingModel::where('za_training.batch_id', $batch->sno)
                ->where('za_training.course_id', $batch->course_id)
                ->where('za_training.status', 0)
                ->select('za_customer.sno as student_id', 'za_customer.cus_pic', 'za_customer.cus_name','za_customer.cus_mobile', 'za_customer.cus_gender', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
                ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
                ->get();

            // Fetch the course view
            $view = ManageCoursesModel::where('sno', $batch->course_id)->first();
            if (!$view) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Batch Not Found',
                    'error_msg' => null,
                    'data' => null
                ], 404);
            }

            // Fetch chapters, sections, and topics
            $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->select('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours as practical_hours', 'course_chapter_theory_hours as theory_hours', DB::raw('MAX(sno) as max_sno'))
                ->groupBy('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours', 'course_chapter_theory_hours')
                ->get();
            // $sql = $chapter_views->toSql();
            // dd($chapter_views);
            // return $chapter_views;

            foreach ($chapter_views as $chapter) {
                $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                    ->where('course_chapter_id', $chapter->course_chapter_id)
                    ->select('session_id', DB::raw('MAX(sno) as max_sno'))
                    ->where('status', 0)
                    ->groupBy('session_id')
                    ->get();

                $section[$chapter->course_chapter_id] = $latest_sections;

                foreach ($latest_sections as $sec) {
                    $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                        ->where('course_chapter_id', $chapter->course_chapter_id)
                        ->where('session_id', $sec->session_id)
                        ->where('status', 0)
                        ->select('topic_id', 'topic_name', DB::raw('MAX(sno) as max_sno'))
                        ->groupBy('topic_id', 'topic_name')
                        ->get();

                    $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
                }
            }

            // Store batch-specific data
            $allBatchesData[] = [
                'students' => $students

            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);
    }


    
    public function staffBatchCourse(Request $request)
    {
        $id = $request->staff_id;

        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.staff_id', $id)
            ->select(
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_duration',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_course.attachment',
                'za_course.thumbnail',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'

            )
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_batch.status', '!=', 2)
            ->groupBy(
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_duration',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_code',
                'za_course.course_duration',
                'za_course_subcategory.course_subcategory_name',
                'za_course.attachment',
                'za_course.thumbnail',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->get();
        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl = 'https://erp.elysium.academy/course_thumbnail_image/';

        // Add base URLs to the attachments and thumbnails only if they are not empty
        $batches->transform(function ($batch) use ($attachmentBaseUrl, $thumbnailBaseUrl) {
            // Append base URL if the attachment is not null or empty
            if (!empty($batch->attachment)) {
                $batch->attachment = $attachmentBaseUrl . $batch->attachment;
            } else {
                $batch->attachment = null; // Don't send link if empty
            }

            // Append base URL if the thumbnail is not null or empty
            if (!empty($batch->thumbnail)) {
                $batch->thumbnail = $thumbnailBaseUrl . $batch->thumbnail;
            } else {
                $batch->thumbnail = null; // Don't send link if empty
            }

            return $batch;
        });

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $batches,
        ], 200);
    }

    public function staffCourseView(Request $request)
    {
        $id = $request->staff_id;
        $course_id = $request->course_id;
        $allBatchesData = []; // To store data for each batch

        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.staff_id', $id)
            ->where('za_batch.course_id', $course_id)
            ->select(
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_duration',
                 'za_course.attachment',
                'za_course.thumbnail',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_batch.status', '!=', 2)
            ->groupBy(
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_duration',
                 'za_course.attachment',
                'za_course.thumbnail',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->get();
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl = 'https://erp.elysium.academy/course_thumbnail_image/';

        // Add base URLs to the attachments and thumbnails
        $batches->transform(function ($batch) use ($attachmentBaseUrl, $thumbnailBaseUrl) {
            $batch->attachment = $attachmentBaseUrl . $batch->attachment;
            $batch->thumbnail = $thumbnailBaseUrl . $batch->thumbnail;
            return $batch;
        });

        foreach ($batches as $batch) {
            // Format dates and times
            // $batch->formatted_created = Carbon::parse($batch->created_at)->format('d-M-Y');
            // $batch->formatted_start_date = Carbon::parse($batch->start_date)->format('d-M-Y');
            // $batch->formatted_end_date = Carbon::parse($batch->end_date)->format('d-M-Y');
            // $batch->formatted_start_time = Carbon::parse($batch->start_time)->format('h:i:A');
            // $batch->formatted_end_time = Carbon::parse($batch->end_time)->format('h:i:A');

            // Calculate available students
            // $batch->available_students = $batch->max_students - $batch->allocated_students;

            // Fetch chapters, sections, and topics
            $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
                ->groupBy('course_chapter_id', 'course_chapter_name')
                ->get();

            $chapters = [];

            foreach ($chapter_views as $chapter) {
                // Fetch sections for each chapter
                $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                    ->where('course_chapter_id', $chapter->course_chapter_id)
                    ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
                    ->groupBy('session_id', 'session_name')
                    ->get();

                $sections = [];

                foreach ($latest_sections as $sec) {
                    // Fetch topics for each section
                    $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
                        ->where('course_chapter_id', $chapter->course_chapter_id)
                        ->where('session_id', $sec->session_id)
                        ->select('topic_id', 'topic_name', DB::raw('MAX(sno) as max_sno'))
                        ->groupBy('topic_id', 'topic_name')
                        ->get();

                    $topics = [];

                    foreach ($latest_topics as $topic) {
                        $topics[] = [
                            'topic_id' => $topic->topic_id,
                            'topic_name' => $topic->topic_name,
                            'max_sno' => $topic->max_sno
                        ];
                    }

                    $sections[] = [
                        'section_id' => $sec->session_id,
                        'section_name' => $sec->session_name,
                        'max_sno' => $sec->max_sno,
                        'topics' => $topics
                    ];
                }

                $chapters[] = [
                    'chapter_id' => $chapter->course_chapter_id,
                    'chapter_name' => $chapter->course_chapter_name,
                    'max_sno' => $chapter->max_sno,
                    'sections' => $sections
                ];
            }

            // Store batch-specific data
            $allBatchesData[] = [
                'coursesDetails' => $batches,
                'chapters' => $chapters
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);
    }

    public function StaffAttendance(Request $request)
    {
        $validator = Validator::make($request->all(), [
        'batch_id'         => 'required',
        'date'             => 'required',
        'student_ids'      => 'required|array',
        'student_ids.*'    => 'required|integer',
        'attendance'       => 'required|array',
        'attendance.*'     => 'required|string',
        'staff_id'         => 'required|integer',
        'current_duration' => 'nullable'
        ]);

        if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
        }

        $currentDate      = now()->format('Y-m-d');
        $date             = $request->date;
        $batch_id         = $request->batch_id;
        $student_ids      = $request->student_ids;
        $attendance       = $request->attendance;
        $current_duration = $request->current_duration;
        $user_id          = $request->staff_id;

        // Check if staff exists
        $roleId = StaffModel::where('status', 0)->where('sno', $user_id)->first();
        if (!$roleId) {
        return response([
            'status'    => 401,
            'message'   => 'Staff not found',
            'data'      => null,
        ], 200);
        }

        // Check if batch exists
        $batch = BatchModel::where('sno', $batch_id)->first();
        if (!$batch) {
        return response([
            'status'    => 401,
            'message'   => 'Batch not found',
            'data'      => null,
        ], 200);
        }

        // Check if branch exists
        $branch_check = BranchModel::where('sno', $roleId->branch_id)->orderBy('sno', 'desc')->first();
        if (!$branch_check) {
        return response([
            'status'    => 401,
            'message'   => 'Branch not found',
            'data'      => null,
        ], 200);
        }

        $branch_code = $branch_check->city_short_code;
        $course = ManageCoursesModel::where('sno', $batch->course_id)->first();

        if (!$course) {
        return response([
            'status'    => 401,
            'message'   => 'Course not found',
            'data'      => null,
        ], 200);
        }

        $total_days = $course->course_days;
        $total_durations = $course->course_duration;

        // Ensure that the arrays have the same length
        if (count($student_ids) !== count($attendance)) {
        return response([
            'status'    => 401,
            'message'   => 'Mismatch in array lengths',
            'data'      => null,
        ], 200);
        }

        $success_count = 0;
        $error_count = 0;

        // Save attendance records
        foreach ($student_ids as $index => $student_id) {
        try {
            // Check if attendance already exists for this student on this date
            $existingAttendance = AttendanceModel::where('customer_id', $student_id)
            ->where('att_date', $date)
            ->where('batch_id', $batch_id)
            ->first();

            if ($existingAttendance) {
            // Update existing attendance
            $attendanceRecord = $existingAttendance;
            $attendanceRecord->attendance = $attendance[$index];
            $attendanceRecord->updated_by = $user_id;
            } else {
            // Create new attendance record
            // Generate attendance ID
            $cos_check = AttendanceModel::orderBy('sno', 'desc')->first();
            if (!$cos_check) {
                $year = date("Y");
                $attendance_id = $year . '/' . $branch_code . '/AT0001';
            } else {
                $data = $cos_check->attendance_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cos + 1;
                $request_cos = sprintf("AT%04d", $next_number_cos);
                $year = date("Y");
                $attendance_id = $year . '/' . $branch_code . '/' . $request_cos;
            }

            $attendanceRecord = new AttendanceModel();
            $attendanceRecord->attendance_id = $attendance_id;
            $attendanceRecord->created_by = $user_id;
            }

            // Calculate duration if present
            $minusDuration = ($total_days > 0 && $attendance[$index] == 'P') ? $total_durations / $total_days : 0;

            // Set common fields
            $attendanceRecord->att_date    = $date;
            $attendanceRecord->customer_id = $student_id;
            $attendanceRecord->course_id   = $batch->course_id;
            $attendanceRecord->batch_id    = $batch_id;
            $attendanceRecord->staff_id    = $user_id;
            $attendanceRecord->attendance  = $attendance[$index];
            $attendanceRecord->total_duration = $minusDuration;
            $attendanceRecord->branch_id   = $branch_check->sno;
            $attendanceRecord->updated_by  = $user_id;
            $attendanceRecord->status      = 1;

            // Save the record
            if ($attendanceRecord->save()) {
            $success_count++;
            } else {
            $error_count++;
            }
        } catch (\Exception $e) {
            $error_count++;
            // Log error for debugging
            \Log::error('Attendance save error: ' . $e->getMessage());
        }
        }

        if ($success_count > 0) {
        return response([
            'status'    => 200,
            'message'   => 'Attendance added successfully for ' . $success_count . ' students!',
            'error_msg' => $error_count > 0 ? $error_count . ' records failed to save' : null,
            'data'      => null,
        ], 200);
        } else {
        return response([
            'status'    => 401,
            'message'   => 'Attendance not added!',
            'error_msg' => 'Failed to save attendance records',
            'data'      => null,
        ], 401);
        }
    }


    // public function staffSyllubusListOld(Request $request)
    // {
    //     $id = $request->staff_id;
    //     $course_id = $request->course_id;
    //     $batch_id = $request->batch_id;
    //     $allBatchesData = []; // To store data for each batch

    //     // Fetch batch data with necessary joins
    //     $batches = BatchModel::where('za_batch.sno', $batch_id)
    //         ->where('za_batch.course_id', $course_id)
    //         ->where('za_batch.staff_id', $id)
    //         ->select(
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_duration',
    //             'za_course.course_code',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image'
    //         )
    //         ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
    //         ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //         ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
    //         ->where('za_batch.status', '!=', 2)
    //         ->groupBy(
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_duration',
    //             'za_course.course_code',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image'
    //         )
    //         ->get();

    //     foreach ($batches as $batch) {
    //         // Fetch chapters, sections, and topics
    //         $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
    //             ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
    //             ->groupBy('course_chapter_id', 'course_chapter_name')
    //             ->get();

    //         $chapters = [];

    //         foreach ($chapter_views as $chapter) {
    //             // Fetch sections for each chapter
    //             $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
    //                 ->where('course_chapter_id', $chapter->course_chapter_id)
    //                 ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
    //                 ->groupBy('session_id', 'session_name')
    //                 ->get();

    //             $sections = [];

    //             foreach ($latest_sections as $sec) {
    //                 // FIX: Get the max sno for each topic and then filter to get only the latest records
    //                 $latest_topics = ManageCoursesSyllabusModel::from('za_course_chapter')
    //                     ->where('za_course_chapter.course_id', $batch->course_id)
    //                     ->where('za_course_chapter.course_chapter_id', $chapter->course_chapter_id)
    //                     ->where('za_course_chapter.session_id', $sec->session_id)
    //                     ->where('za_course_chapter.status', 0)
    //                     ->leftJoin('za_syllabus_update', function ($join) {
    //                         $join->on('za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
    //                             ->on('za_syllabus_update.section_id', '=', 'za_course_chapter.session_id')
    //                             ->on('za_syllabus_update.chapter_id', '=', 'za_course_chapter.course_chapter_id');
    //                     })
    //                     ->select(
    //                         'za_course_chapter.topic_id', 
    //                         'za_course_chapter.session_id', 
    //                         'za_course_chapter.course_chapter_id', 
    //                         'za_course_chapter.topic_name', 
    //                         'za_course_chapter.session_name', 
    //                         'za_course_chapter.course_chapter_name',
    //                         'za_course_chapter.sno as max_sno',
    //                         'za_syllabus_update.percentage', 
    //                         'za_syllabus_update.reason', 
    //                         'za_syllabus_update.date'
    //                     )
    //                     // SUBQUERY to get only the latest record for each topic
    //                     ->whereIn('za_course_chapter.sno', function($query) use ($batch, $chapter, $sec) {
    //                         $query->select(DB::raw('MAX(sno)'))
    //                             ->from('za_course_chapter')
    //                             ->where('course_id', $batch->course_id)
    //                             ->where('course_chapter_id', $chapter->course_chapter_id)
    //                             ->where('session_id', $sec->session_id)
    //                             ->where('status', 0)
    //                             ->groupBy('topic_id');
    //                     })
    //                     ->get();

    //                 $topics = [];

    //                 foreach ($latest_topics as $topic) {
    //                     $topics[] = [
    //                         'topic_id'   => $topic->topic_id,
    //                         'topic_name' => $topic->topic_name,
    //                         'percentage' => $topic->percentage ?? 0,
    //                         'max_sno'    => $topic->max_sno
    //                     ];
    //                 }

    //                 $sections[] = [
    //                     'section_id' => $sec->session_id,
    //                     'section_name' => $sec->session_name,
    //                     'max_sno' => $sec->max_sno,
    //                     'topics' => $topics
    //                 ];
    //             }

    //             $chapters[] = [
    //                 'chapter_id' => $chapter->course_chapter_id,
    //                 'chapter_name' => $chapter->course_chapter_name,
    //                 'max_sno' => $chapter->max_sno,
    //                 'sections' => $sections
    //             ];
    //         }

    //         // Store batch-specific data
    //         $allBatchesData[] = [
    //             'coursesDetails' => $batches,
    //             'chapters'       => $chapters
    //         ];
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Data Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => $allBatchesData,
    //     ], 200);
    // }

    // public function staffSyllubusList(Request $request)
    // {
    //     $id = $request->staff_id;
    //     $course_id = $request->course_id;
    //     $batch_id = $request->batch_id;
    //     $allBatchesData = [];

    //     // Fetch batch data with necessary joins
    //     $batches = BatchModel::where('za_batch.sno', $batch_id)
    //         ->where('za_batch.course_id', $course_id)
    //         ->where('za_batch.staff_id', $id)
    //         ->select(
    //             'za_batch.sno as batch_sno',
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_duration',
    //             'za_course.course_code',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image'
    //         )
    //         ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
    //         ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //         ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
    //         ->where('za_batch.status', '!=', 2)
    //         ->groupBy(
    //             'za_batch.sno',
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_duration',
    //             'za_course.course_code',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image'
    //         )
    //         ->first();

    //     if (!$batches) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Batch not found',
    //             'error_msg' => null,
    //             'data' => null,
    //         ], 200);
    //     }

    //     // Get the batch object with sno
    //     $batchObj = BatchModel::where('sno', $batch_id)->first();
        
    //     // Fetch chapters, sections, and topics with syllabus update status
    //     $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batches->course_id)
    //         ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
    //         ->groupBy('course_chapter_id', 'course_chapter_name')
    //         ->get();

    //     $chapters = [];

    //     foreach ($chapter_views as $chapter) {
    //         // Fetch sections for each chapter
    //         $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batches->course_id)
    //             ->where('course_chapter_id', $chapter->course_chapter_id)
    //             ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
    //             ->groupBy('session_id', 'session_name')
    //             ->get();

    //         $sections = [];

    //         foreach ($latest_sections as $sec) {
    //             // Fetch topics with syllabus update status - CORRECTED JOIN
    //             $latest_topics = ManageCoursesSyllabusModel::from('za_course_chapter')
    //                 ->where('za_course_chapter.course_id', $batches->course_id)
    //                 ->where('za_course_chapter.course_chapter_id', $chapter->course_chapter_id)
    //                 ->where('za_course_chapter.session_id', $sec->session_id)
    //                 ->where('za_course_chapter.status', 0)
    //                 ->leftJoin('za_syllabus_update', function ($join) use ($batchObj, $id) {
    //                     $join->on('za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
    //                         ->on('za_syllabus_update.section_id', '=', 'za_course_chapter.session_id')
    //                         ->on('za_syllabus_update.chapter_id', '=', 'za_course_chapter.course_chapter_id')
    //                         ->where('za_syllabus_update.batch_id', '=', $batchObj->sno)
    //                         ->where('za_syllabus_update.staff_id', '=', $id)
    //                         ->where('za_syllabus_update.status', '=', 0); // Only active updates
    //                 })
    //                 ->select(
    //                     'za_course_chapter.topic_id',
    //                     'za_course_chapter.session_id',
    //                     'za_course_chapter.course_chapter_id',
    //                     'za_course_chapter.topic_name',
    //                     'za_course_chapter.session_name',
    //                     'za_course_chapter.course_chapter_name',
    //                     'za_course_chapter.sno as max_sno',
    //                     DB::raw('COALESCE(za_syllabus_update.percentage, 0) as percentage'),
    //                     'za_syllabus_update.reason',
    //                     'za_syllabus_update.date as update_date',
    //                     'za_syllabus_update.sno as syllabus_update_sno',
    //                     DB::raw('CASE WHEN za_syllabus_update.sno IS NOT NULL THEN 1 ELSE 0 END as has_update')
    //                 )
    //                 // SUBQUERY to get only the latest record for each topic
    //                 ->whereIn('za_course_chapter.sno', function($query) use ($batches, $chapter, $sec) {
    //                     $query->select(DB::raw('MAX(sno)'))
    //                         ->from('za_course_chapter')
    //                         ->where('course_id', $batches->course_id)
    //                         ->where('course_chapter_id', $chapter->course_chapter_id)
    //                         ->where('session_id', $sec->session_id)
    //                         ->where('status', 0)
    //                         ->groupBy('topic_id');
    //                 })
    //                 ->orderBy('za_course_chapter.sno', 'asc')
    //                 ->get();

    //             $topics = [];

    //             foreach ($latest_topics as $topic) {
    //                 // Only include percentage if it has an update, otherwise show 0
    //                 $percentage = $topic->has_update ? (int)$topic->percentage : 0;
                    
    //                 $topicData = [
    //                     'topic_id' => $topic->topic_id,
    //                     'topic_name' => $topic->topic_name,
    //                     'percentage' => $percentage,
    //                     'max_sno' => $topic->max_sno
    //                 ];

    //                 // Only add these fields if there's an update
    //                 if ($topic->has_update) {
    //                     $topicData['reason'] = $topic->reason;
    //                     $topicData['update_date'] = $topic->update_date;
    //                     $topicData['syllabus_update_sno'] = $topic->syllabus_update_sno;
    //                 }

    //                 $topics[] = $topicData;
    //             }

    //             $sections[] = [
    //                 'section_id' => $sec->session_id,
    //                 'section_name' => $sec->session_name,
    //                 'max_sno' => $sec->max_sno,
    //                 'topics' => $topics
    //             ];
    //         }

    //         $chapters[] = [
    //             'chapter_id' => $chapter->course_chapter_id,
    //             'chapter_name' => $chapter->course_chapter_name,
    //             'max_sno' => $chapter->max_sno,
    //             'sections' => $sections
    //         ];
    //     }

    //     // Calculate overall progress for this batch
    //     $totalTopics = 0;
    //     $completedTopics = 0;
    //     $totalPercentage = 0;
        
    //     foreach ($chapters as $chapter) {
    //         foreach ($chapter['sections'] as $section) {
    //             foreach ($section['topics'] as $topic) {
    //                 $totalTopics++;
    //                 if ($topic['percentage'] > 0) {
    //                     $completedTopics++;
    //                     $totalPercentage += $topic['percentage'];
    //                 }
    //             }
    //         }
    //     }
        
    //     $overallProgress = $totalTopics > 0 ? round(($completedTopics / $totalTopics) * 100, 2) : 0;
    //     $averagePercentage = $totalTopics > 0 ? round($totalPercentage / $totalTopics, 2) : 0;

    //     // Store batch-specific data
    //     $allBatchesData[] = [
    //         'batch_id' => $batch_id,
    //         'courseDetails' => $batches,
    //         'chapters' => $chapters,
    //         'summary' => [
    //             'total_topics' => $totalTopics,
    //             'completed_topics' => $completedTopics,
    //             'overall_progress' => $overallProgress,
    //             'average_percentage' => $averagePercentage,
    //             'pending_topics' => $totalTopics - $completedTopics
    //         ]
    //     ];

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Data Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => $allBatchesData,
    //     ], 200);
    // }
    public function staffSyllubusList(Request $request)
    {
        $id = $request->staff_id;
        $course_id = $request->course_id;
        $batch_id = $request->batch_id;
        $allBatchesData = [];

        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.sno', $batch_id)
            ->where('za_batch.course_id', $course_id)
            ->where('za_batch.staff_id', $id)
            ->select(
                'za_batch.sno as batch_sno',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_duration',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_batch.status', '!=', 2)
            ->groupBy(
                'za_batch.sno',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_duration',
                'za_course.course_code',
                'za_course_subcategory.course_subcategory_name',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image'
            )
            ->first();

        if (!$batches) {
            return response()->json([
                'status' => 404,
                'message' => 'Batch not found',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        // Get the batch object with sno
        $batchObj = BatchModel::where('sno', $batch_id)->first();
        
        // Fetch chapters, sections, and topics with syllabus update status
        $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batches->course_id)
            ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
            ->groupBy('course_chapter_id', 'course_chapter_name')
            ->get();

        $chapters = [];

        foreach ($chapter_views as $chapter) {
            // Fetch sections for each chapter
            $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batches->course_id)
                ->where('course_chapter_id', $chapter->course_chapter_id)
                ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
                ->groupBy('session_id', 'session_name')
                ->get();

            $sections = [];

            foreach ($latest_sections as $sec) {
                // Fetch topics with syllabus update status
                $latest_topics = ManageCoursesSyllabusModel::from('za_course_chapter')
                    ->where('za_course_chapter.course_id', $batches->course_id)
                    ->where('za_course_chapter.course_chapter_id', $chapter->course_chapter_id)
                    ->where('za_course_chapter.session_id', $sec->session_id)
                    ->where('za_course_chapter.status', 0)
                    ->leftJoin('za_syllabus_update', function ($join) use ($batchObj, $id) {
                        $join->on('za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
                            ->on('za_syllabus_update.section_id', '=', 'za_course_chapter.session_id')
                            ->on('za_syllabus_update.chapter_id', '=', 'za_course_chapter.course_chapter_id')
                            ->where('za_syllabus_update.batch_id', '=', $batchObj->sno)
                            ->where('za_syllabus_update.staff_id', '=', $id)
                            ->where('za_syllabus_update.status', '=', 0);
                    })
                    ->select(
                        'za_course_chapter.topic_id',
                        'za_course_chapter.session_id',
                        'za_course_chapter.course_chapter_id',
                        'za_course_chapter.topic_name',
                        'za_course_chapter.session_name',
                        'za_course_chapter.course_chapter_name',
                        'za_course_chapter.sno as max_sno',
                        DB::raw('COALESCE(za_syllabus_update.percentage, 0) as percentage'),
                        'za_syllabus_update.reason',
                        'za_syllabus_update.date as update_date',
                        'za_syllabus_update.sno as syllabus_update_sno',
                        DB::raw('CASE WHEN za_syllabus_update.sno IS NOT NULL THEN 1 ELSE 0 END as has_update')
                    )
                    // SUBQUERY to get only the latest record for each topic
                    ->whereIn('za_course_chapter.sno', function($query) use ($batches, $chapter, $sec) {
                        $query->select(DB::raw('MAX(sno)'))
                            ->from('za_course_chapter')
                            ->where('course_id', $batches->course_id)
                            ->where('course_chapter_id', $chapter->course_chapter_id)
                            ->where('session_id', $sec->session_id)
                            ->where('status', 0)
                            ->groupBy('topic_id');
                    })
                    ->orderBy('za_course_chapter.sno', 'asc')
                    ->get();

                $topics = [];

                foreach ($latest_topics as $topic) {
                    // Get percentage
                    $percentage = $topic->has_update ? (int)$topic->percentage : 0;
                    
                    // SKIP topics that have 100% completion
                    if ($percentage == 100) {
                        continue; // This will skip the topic entirely
                    }
                    
                    $topicData = [
                        'topic_id' => $topic->topic_id,
                        'topic_name' => $topic->topic_name,
                        'percentage' => $percentage,
                        'max_sno' => $topic->max_sno
                    ];

                    // Only add these fields if there's an update
                    if ($topic->has_update) {
                        $topicData['reason'] = $topic->reason;
                        $topicData['update_date'] = $topic->update_date;
                        $topicData['syllabus_update_sno'] = $topic->syllabus_update_sno;
                    }

                    $topics[] = $topicData;
                }

                // Only add section if it has topics (after filtering 100% completed ones)
                if (!empty($topics)) {
                    $sections[] = [
                        'section_id' => $sec->session_id,
                        'section_name' => $sec->session_name,
                        'max_sno' => $sec->max_sno,
                        'topics' => $topics
                    ];
                }
            }

            // Only add chapter if it has sections (after filtering empty ones)
            if (!empty($sections)) {
                $chapters[] = [
                    'chapter_id' => $chapter->course_chapter_id,
                    'chapter_name' => $chapter->course_chapter_name,
                    'max_sno' => $chapter->max_sno,
                    'sections' => $sections
                ];
            }
        }

        // Calculate overall progress for this batch (based on remaining topics)
        $totalTopics = 0;
        $completedTopics = 0;
        $totalPercentage = 0;
        
        foreach ($chapters as $chapter) {
            foreach ($chapter['sections'] as $section) {
                foreach ($section['topics'] as $topic) {
                    $totalTopics++;
                    if ($topic['percentage'] > 0) {
                        $completedTopics++;
                        $totalPercentage += $topic['percentage'];
                    }
                }
            }
        }
        
        // Also count completed topics (100% completed ones that were skipped)
        // Get total topics including completed ones for accurate statistics
        $totalAllTopics = 0;
        $completedAllTopics = 0;
        
        // Re-fetch all topics count (including completed ones)
        $allTopicsCount = ManageCoursesSyllabusModel::where('course_id', $batches->course_id)
            ->where('status', 0)
            ->count();
        
        $completedTopicsCount = SyllabusUpdateModel::where('batch_id', $batch_id)
            ->where('staff_id', $id)
            ->where('percentage', 100)
            ->where('status', 0)
            ->count();
        
        $overallProgress = $allTopicsCount > 0 ? round((($allTopicsCount - $completedTopicsCount) / $allTopicsCount) * 100, 2) : 0;
        $averagePercentage = $totalTopics > 0 ? round($totalPercentage / $totalTopics, 2) : 0;

        // Store batch-specific data
        $allBatchesData[] = [
            'batch_id' => $batch_id,
            'courseDetails' => $batches,
            'chapters' => $chapters,
            'summary' => [
                'total_topics' => $allTopicsCount,
                'completed_topics' => $completedTopicsCount,
                'remaining_topics' => $allTopicsCount - $completedTopicsCount,
                'overall_progress' => $overallProgress,
                'average_percentage' => $averagePercentage
            ]
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);
    }


    public function staffSyllabusUpdate(Request $request)
    {

        // Validate request inputs
        $validator = Validator::make($request->all(), [
            'date'     => 'required',
            'batch_id'     => 'required',
            'chapter_id'   => 'required',
            'section_id'   => 'required',
            'topic_id'     => 'required',
            'staff_id'     => 'required',
            'percentage'   => 'required|numeric|min:0|max:100',
            'reason'       => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Validation errors',
                'error_msg' => $validator->errors(),
                'data'      => null,
            ], 200);
        }
        // return $request;
        $date        = $request->date ?? now()->format('Y-m-d');
        $batch_id    = $request->batch_id;
        $chapter_id  = $request->chapter_id;
        $section_id  = $request->section_id;
        $topic_id    = $request->topic_id;
        $reason      = $request->reason;
        $percentage  = $request->percentage;
        $user_id     = $request->staff_id;
        // $branch_id   = $request->user()->branch_id;

        // Fetch the batch and branch
        $batch       = BatchModel::where('sno', $batch_id)->first();
        // $branch_code = BranchModel::where('sno', $branch_id)->value('city_short_code');
        $roleId       = StaffModel::where('status', 0)->where('sno', $user_id)->first();
        $branch_check = BranchModel::where('sno', $roleId->branch_id)->orderBy('sno', 'desc')->first();
        $branch_code  = $branch_check->city_short_code;
        // Update existing syllabus entry
        $upd_check = SyllabusUpdateModel::where([
            ['branch_id', $branch_check->sno],
            ['batch_id', $batch_id],
            ['chapter_id', $chapter_id],
            ['section_id', $section_id],
            ['topic_id', $topic_id],
            ['staff_id', $user_id]
        ])->latest('sno')->first();

        if ($upd_check) {
            $upd_check->update([
                'date'       => $date,
                'staff_id'   => $user_id,
                'course_id'  => $batch->course_id,
                'percentage' => $percentage,
                'reason'     => $reason,
                'branch_id'  => $branch_check->sno,
                'created_by' => $user_id,
                'updated_by' => $user_id
            ]);

            return response([
                'status'    => 200,
                'message'   => 'Syllabus updated successfully!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }

        // Generate new syllabus update ID
        $latest = SyllabusUpdateModel::latest('sno')->first();
        $year = date("Y");
        $latest_id_parts = $latest ? explode("/", $latest->syllabus_update_id) : null;
        $latest_number = $latest_id_parts && isset($latest_id_parts[2])
            ? (int)preg_replace('/[^0-9]/', '', $latest_id_parts[2])
            : 0;

        $syllabus_update_id = $year . '/' . $branch_code . '/SU' . sprintf('%04d', $latest_number + 1);


        // Create new syllabus entry
        $add_category = SyllabusUpdateModel::create([
            'syllabus_update_id' => $syllabus_update_id,
            'date'       => $date,
            'staff_id'   => $user_id,
            'course_id'  => $batch->course_id,
            'batch_id'   => $batch_id,
            'chapter_id' => $chapter_id,
            'section_id' => $section_id,
            'topic_id'   => $topic_id,
            'percentage' => $percentage,
            'reason'     => $reason,
            'branch_id'  => $branch_check->sno,
            'created_by' => $user_id,
            'updated_by' => $user_id
        ]);

        if ($add_category) {
            return response([
                'status' => 200,
                'message' => 'Syllabus added successfully!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 401,
            'message' => 'Failed to add syllabus!',
            'error_msg' => 'An error occurred while adding the syllabus',
            'data' => null,
        ], 401);
    }

    public function staffDasboard(Request $request)
    {
        // Validate request inputs
        $validator = Validator::make($request->all(), [
        'staff_id' => 'required',
        ]);

        if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Validation errors',
            'error_msg' => $validator->errors(),
            'data'      => null,
        ], 200);
        }

        $date    = now()->format('Y-m-d');
        $user_id = $request->staff_id;
        $startTime = microtime(true);

        // Retrieve the role and branch information for the staff
        $staff = StaffModel::where('status', 0)->where('sno', $user_id)->first();
        if (!$staff) {
        return response([
            'status'    => 404,
            'message'   => 'Staff not found',
            'error_msg' => 'Invalid staff ID',
            'data'      => null,
        ], 200);
        }

        $branch = BranchModel::where('sno', $staff->branch_id)->orderBy('sno', 'desc')->first();
        if (!$branch) {
        return response([
            'status'    => 404,
            'message'   => 'Branch not found',
            'error_msg' => 'Invalid branch ID',
            'data'      => null,
        ], 200);
        }

        // Count batches for the staff in the branch
        $count_batch = BatchModel::where('branch_id', $branch->sno)
        ->whereDate('za_batch.end_date', '>=', now()->toDateString())
        ->whereDate('za_batch.start_date', '<=', $date)
        ->whereDate('za_batch.end_date', '>=', $date)->where('staff_id', $user_id)->count();

        $count_exam = Student::where('branch_id', $branch->sno)
        ->where('staff_id', $user_id) // Ensure staff_id is not NULL and matches the user
        ->get()
        ->sum(function ($student) {
            $examStatuses = json_decode($student->exam_status, true); // Decode JSON
            if (is_array($examStatuses)) {
            return collect($examStatuses)->where('exam_status', 2)->count(); // Count all exam_status = 2
            }
            return 0;
        });


        // Get matched customer IDs
        $getingmatched = TrainingModel::where('branch_id', $branch->sno)
        ->where('staff_id', $staff->sno)
        ->whereDate('end_date', '>=', now()->toDateString())
        ->whereDate('start_date', '<=', $date)
        ->whereDate('end_date', '>=', $date)
        ->pluck('customer_id')
        ->unique();

        // Get matched customer IDs (students allocated to this staff for current date)
        $getingmatched = TrainingModel::where('branch_id', $branch->sno)
        ->where('staff_id', $staff->sno)
        ->whereDate('end_date', '>=', now()->toDateString())
        ->whereDate('start_date', '<=', $date)
        ->whereDate('end_date', '>=', $date)
        ->pluck('customer_id')
        ->unique();

        // Count attendance records with 'P' status for the current date (ACTUAL)
        $attendance_actual = AttendanceModel::whereIn('customer_id', $getingmatched)
        ->where('staff_id', $staff->sno)
        ->whereDate('att_date', Carbon::today())
        ->where('attendance', 'P')
        ->count();

        // Count TOTAL students expected (TARGET) - all allocated students
        $attendance_target = $getingmatched->count();


        // Get the batches first, then count students based on the retrieved batch IDs
        $batches = BatchModel::where('branch_id', $branch->sno)->where('staff_id', $user_id)->get(['sno', 'course_id']);
        $batch_ids = $batches->pluck('sno');

        // Count the number of students in those batches
        $count_student = TrainingModel::where('branch_id', $branch->sno)
        ->where('staff_id', $staff->sno)
        ->whereDate('end_date', '>=', now()->toDateString())
        ->whereDate('start_date', '<=', $date)
        ->whereDate('end_date', '>=', $date)
        ->pluck('customer_id')
        ->unique()->count();

        // Get unique course count for the staff's batches
        $count_course = $batches->pluck('course_id')->unique()->count();

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
        $profile_image = asset('staff_images/' . $staff->staff_image);

        $currentTime = Carbon::now('Asia/Kolkata')->format('H:i:s');
        // Subquery to calculate allocated students
        $allocatedStudentsSubquery = DB::table('za_training')
        ->selectRaw('COUNT(*)')
        ->whereColumn('za_training.batch_id', 'za_batch.sno');

        $batches = BatchModel::query()
        ->select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_days',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image',
            DB::raw("({$allocatedStudentsSubquery->toSql()}) as allocated_students")
        )
        ->mergeBindings($allocatedStudentsSubquery)

        ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')

        ->where('za_batch.staff_id', $request->staff_id)
        ->whereDate('za_batch.end_date', '>=', now()->toDateString())
        ->whereDate('za_batch.start_date', '<=', $date)
        ->whereDate('za_batch.end_date', '>=', $date)


        ->whereTime('za_slot.start_time', '>=', $currentTime)
        ->where('za_batch.status', '!=', 2)
        ->where('za_slot.status', '!=', 2)
        ->where('za_slot_type.status', '!=', 2)

        // Attendance not created
        ->whereNotExists(function ($q) use ($date) {
            $q->select(DB::raw(1))
            ->from('za_attendance')
            ->whereColumn('za_attendance.batch_id', 'za_batch.sno')
            ->whereDate('za_attendance.att_date', $date)
            ->where('za_attendance.status', 0);
        })

        // Syllabus not created
        ->whereNotExists(function ($q) use ($date) {
            $q->select(DB::raw(1))
            ->from('za_syllabus_update')
            ->whereColumn('za_syllabus_update.batch_id', 'za_batch.sno')
            ->whereDate('za_syllabus_update.date', $date)
            ->where('za_syllabus_update.status', 0);
        })

        ->groupBy(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_days',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image'
        )
        ->get();

        foreach ($batches as $singleBatch) {
        $today = $date ?? Carbon::today()->format('Y-m-d');
        $attendance = AttendanceModel::whereDate('att_date', $today)
            ->where('batch_id', $singleBatch->sno)
            ->first();
        $singleBatch->att_status = $attendance ? 1 : 0;
        }


        // return $batches;

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

        $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        // $currentDay = Carbon::now()->format('l');
        $currentDay = Carbon::now()->format('D');

        // Map through the batches to format dates and add additional fields
        $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
        // Format dates and times
        $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
        $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
        $item->formatted_start_time = Carbon::parse($item->start_time)->format('H:i A');
        $item->formatted_end_time = Carbon::parse($item->end_time)->format('H:i A');

        // Convert slot_type_days from JSON to an array of day names
        $dayIndices = json_decode($item->slot_type_days);
        $dayNames = [];
        $item->slot_type_days = $dayIndices;
        foreach ($dayIndices as $index) {
            $dayIndex = (int)$index - 1; // Convert to 0-based index
            $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
        }

        // Join day names into a comma-separated string
        $item->days = implode(', ', $dayNames);

        // Calculate available students
        $item->available_students = $item->max_students - $item->allocated_students;

        return $item;
        });

        // Filter batches to only include those where the current day is in the days
        $upcomingListBatch = $formattedBatches->filter(function ($item) use ($currentDay) {
        return in_array($currentDay, explode(', ', $item->days));
        })->values();

        // Return the response
        return response([
        'status'            => 200,
        'staff_name'       => $staff->staff_name,
        'gender'           => $staff->gender,
        'profile_image'    => $profile_image ?? null,
        'message'           => "Dashboard List",
        'error_msg'          => null,
        'course_count'       => $count_course,
        'student_count'      => $count_student,
        'batch_count'        => $count_batch,
        'attendance_actual'  => $attendance_actual,
        'attendance_target'  => $attendance_target,
        'batch_list'         => $upcomingListBatch,
        'exam_count'         =>  $count_exam,
        'battery_status'        =>  "65.0",
        'heart_status'        =>  "43.3",
        'execution_time'    => $executionTime . ' seconds'
        ], 200);
    }
    public function staffBatteryHeart(Request $request)
    {
        // Validate request inputs
        $validator = Validator::make($request->all(), [
            'staff_id' => 'required', // Ensures staff_id exists in the staff table
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Validation errors',
                'error_msg' => $validator->errors(),
                'data'      => null,
            ], 200);
        }

        // Fetch the staff's data
        $staff = StaffModel::where('status', 0)->where('sno', $request->staff_id)->first(); // Ensure to use first() to fetch a single record

        if (!$staff) {
            return response([
                'status'    => 404,
                'message'   => 'Staff not found',
                'data'      => null,
            ], 200);
        }

        // Fetch attendance data for the current month
        $attendanceData = \DB::table('za_staff_attendance')
            ->where('staff_id', $request->staff_id)
            ->whereMonth('date', now()->month) // Assuming 'attendance date' is the date field in the table
            ->get();

        // Initialize variables to calculate the attendance score
        $attendanceScore = 0;
        $totalDays = 0;

        // Loop through attendance records and calculate the score based on attendance type
        foreach ($attendanceData as $attendance) {
            if ($attendance->status == 'P') { // Present
                $attendanceScore += 1; // Good
            } elseif ($attendance->status == 'A') { // Absent
                $attendanceScore -= 1; // Bad
            } elseif ($attendance->status == 'L') { // Leave
                $attendanceScore += 0; // Neutral (could also adjust this based on your requirements)
            }
            $totalDays++; // Count total attendance entries for the current month
        }

        // Calculate a rating (example: total attendance score out of 5)
        $rating = $totalDays > 0 ? round(($attendanceScore / $totalDays) * 5, 2) : 0;

        // For the sake of this example, we're using static values for battery and heart scores
        $batteryScore = '3'; // Static example for battery score
        $heartScore = '2';   // Static example for heart score

        // Respond with the necessary data for the mobile app
        return response([
            'status'    => 200,
            'message'   => 'Success',
            'data'      => [
                'battery_score'  => $batteryScore ?? 2,
                'heart_score'    => $heartScore ?? 2,
                'attendance_rating' => $rating // Include calculated attendance rating
            ],
        ], 200);
    }

    // public function staffCourseView(Request $request)
    // {
    //     $id = $request->staff_id;
    //     $topics = [];
    //     $allBatchesData = []; // To store data for each batch

    //     // Subquery to calculate allocated students
    //     $allocatedStudentsSubquery = DB::table('za_training')
    //         ->select(DB::raw('COUNT(*)'))
    //         ->whereRaw('za_training.batch_id = za_batch.sno');

    //     // Fetch batch data with necessary joins
    //     $batches = BatchModel::where('za_batch.staff_id', $id)
    //         ->select(
    //             'za_batch.sno',
    //             'za_batch.batch_id',
    //             'za_batch.batch_name',
    //             'za_batch.start_date',
    //             'za_batch.end_date',
    //             'za_slot.start_time',
    //             'za_slot.end_time',
    //             'za_slot.slot_type_days',
    //             'za_batch.max_students',
    //             'za_batch.classroom_id',
    //             'za_class_room.class_room_name',
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_batch.slot_id',
    //             'za_slot.slot_name',
    //             'za_slot_type.slot_type_name',
    //             'za_slot.start_time as slot_start_time',
    //             'za_slot.end_time as slot_end_time',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image',
    //             DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
    //         )
    //         ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
    //         ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
    //         ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
    //         ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
    //         ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //         ->where('za_batch.status', '!=', 2)
    //         ->where('za_slot_type.status', '!=', 2)
    //         ->where('za_slot.status', '!=', 2)
    //         ->groupBy(
    //             'za_batch.sno',
    //             'za_batch.batch_id',
    //             'za_batch.batch_name',
    //             'za_batch.start_date',
    //             'za_batch.end_date',
    //             'za_slot.start_time',
    //             'za_slot.end_time',
    //             'za_slot.slot_type_days',
    //             'za_batch.max_students',
    //             'za_batch.classroom_id',
    //             'za_class_room.class_room_name',
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_batch.slot_id',
    //             'za_slot.slot_name',
    //             'za_slot_type.slot_type_name',
    //             'za_slot.start_time',
    //             'za_slot.end_time',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image'
    //         )
    //         ->get();

    //     // Fetch general settings
    //     $helper = new Helpers();
    //     $generalSettings = $helper->general_setting_data();
    //     $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    //     $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    //     foreach ($batches as $batch) {
    //         // Format dates and times
    //         $batch->formatted_created = Carbon::parse($batch->created_at)->format($dateFormat);
    //         $batch->formatted_start_date = Carbon::parse($batch->start_date)->format($dateFormat);
    //         $batch->formatted_end_date = Carbon::parse($batch->end_date)->format($dateFormat);
    //         $batch->formatted_start_time = Carbon::parse($batch->start_time)->format('H:i:A');
    //         $batch->formatted_end_time = Carbon::parse($batch->end_time)->format('H:i:A');

    //         // Convert slot_type_days from JSON to an array of day names
    //         $dayIndices = json_decode($batch->slot_type_days);
    //         $dayNames = [];
    //         foreach ($dayIndices as $index) {
    //             $dayIndex = (int)$index - 1; // Convert to 0-based index
    //             $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
    //         }
    //         $batch->days = implode(', ', $dayNames);

    //         // Calculate available students
    //         $batch->available_students = $batch->max_students - $batch->allocated_students;

    //         // Fetch students for the batch
    //         $students = TrainingModel::where('za_training.batch_id', $batch->sno)
    //             ->where('za_training.course_id', $batch->course_id)
    //             ->where('za_training.status', 0)
    //             ->select('za_customer.sno as customer_id', 'za_customer.cus_pic', 'za_customer.cus_name', 'za_customer.cus_gender', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
    //             ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
    //             ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
    //             ->get();

    //         // Fetch the course view
    //         $view = ManageCoursesModel::where('sno', $batch->course_id)->first();
    //         if (!$view) {
    //             return response()->json([
    //                 'status' => 404,
    //                 'message' => 'Batch Not Found',
    //                 'error_msg' => null,
    //                 'data' => null
    //             ], 404);
    //         }

    //         // Fetch chapters, sections, and topics
    //         $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
    //             ->select('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours as practical_hours', 'course_chapter_theory_hours as theory_hours', DB::raw('MAX(sno) as max_sno'))
    //             ->groupBy('course_chapter_id', 'course_chapter_name', 'course_chapter_practical_hours', 'course_chapter_theory_hours')
    //             ->get();
    //         // $sql = $chapter_views->toSql();
    //         // dd($chapter_views);

    //         foreach ($chapter_views as $chapter) {
    //             $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
    //                 ->where('course_chapter_id', $chapter->course_chapter_id)
    //                 ->select('session_id', DB::raw('MAX(sno) as max_sno'))
    //                 ->where('status', 0)
    //                 ->groupBy('session_id')
    //                 ->get();

    //             $section[$chapter->course_chapter_id] = $latest_sections;

    //             foreach ($latest_sections as $sec) {
    //                 $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
    //                     ->where('course_chapter_id', $chapter->course_chapter_id)
    //                     ->where('session_id', $sec->session_id)
    //                     ->where('status', 0)
    //                     ->select('topic_id', 'topic_name', DB::raw('MAX(sno) as max_sno'))
    //                     ->groupBy('topic_id', 'topic_name')
    //                     ->get();

    //                 $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
    //             }
    //         }

    //         // Store batch-specific data
    //         $allBatchesData[] = [
    //             'batch'    => $batch,
    //             'students' => $students,
    //             'chapter'  => $topics,
    //             'chapter Details'  => $chapter_views,

    //         ];
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Data Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => $allBatchesData,
    //     ], 200);
    // }
    
     /////////////////////////////////////////  Exam   /////////////////////////////////////////

    public function StaffCourseList(Request $request)
    {
        // $page = $request->input('page', 1);
        // $perPage = $request->input('count', 10);

        $course = ManageCoursesModel::where('status', 0)->get();

        $allBatchesData = [];

        foreach ($course as $batch) {
            // Calculate exam_count based on topic_id and percentage

            $test = ManageCoursesSyllabusModel::where('course_id', $batch->sno)
                ->whereNotNull('ca_text_link')->get();

            // print_r($batch->sno);

            // return $test;

            $exam_count_query = ManageCoursesSyllabusModel::where('course_id', $batch->sno)
                ->whereNotNull('ca_text_link')
                ->where('ca_text_link', '!=', '')
                ->whereIn('topic_id', function ($query) use ($batch) {
                    $query->select('topic_id')
                        ->from('za_syllabus_update')
                        ->where('za_syllabus_update.course_id', $batch->sno)
                        ->whereRaw('CAST(za_syllabus_update.percentage AS DECIMAL(10,2)) = 100.00'); // Precise match for percentage
                });

            $exam_count = $exam_count_query->count();

            // Get the exam ca_text_link with matching conditions
            $exam_ids_query = ManageCoursesSyllabusModel::where('course_id', $batch->sno)
                ->whereNotNull('ca_text_link')
                ->where('ca_text_link', '!=', '')
                ->whereIn('topic_id', function ($query) use ($batch) {
                    $query->select('topic_id')
                        ->from('za_syllabus_update')
                        ->where('za_syllabus_update.course_id', $batch->sno)
                        ->whereRaw('CAST(za_syllabus_update.percentage AS DECIMAL(10,2)) = 100.00'); // Precise match for percentage
                });

            // Get the ca_text_link values (which are encrypted)
            $exam_ids = $exam_ids_query->pluck('ca_text_link'); // Retrieve only ca_text_link

            // Initialize the helper
            $helper = new \App\Helpers\Helpers();

            // Decrypt the ca_text_link values before returning them
            $decrypted_exam_ids = $exam_ids->map(function ($encryptedId) use ($helper) {
                if (!empty($encryptedId)) {
                    // Decrypt the value using your helper method
                    $decrypted = $helper->encrypt_decrypt($encryptedId, 'decrypt');
                    return $decrypted;
                }
                return null;
            });

            // Append data for each batch with decrypted exam IDs
            $allBatchesData[] = [
                'customer_id' => $batch->customer_id,
                'course_id' => $batch->course_id,
                'batch_id' => $batch->batch_id,
                'course_name' => $batch->course_name,
                'sno' => $batch->sno,
                'exam_count' => $exam_count,
                'exam_ids' => $decrypted_exam_ids // Return the decrypted IDs
            ];
        }


        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $allBatchesData,
        ], 200);

        // return $course;
    }

    public function StaffExamTopicList(Request $request)
    {
        $exam_ids = $request->exam_ids;

        // Fetch the exam topic list based on the provided exam IDs
        $exam_list = ExamModel::whereIn('sno', $exam_ids) // Filter exams by the provided IDs
            ->where('za_exam.status', 0)->get(); // Check for exams with active status (assuming 0 means active)

        // Process the exams and decode question IDs
        $exam_data = [];
        foreach ($exam_list as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedQuestions = json_decode($exam->exam_question_ids, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            $questionIds = $decodedQuestions ? array_column($decodedQuestions, 'question_id') : [];

            // Prepare exam data
            $exam_data[] = [
                'exam_id' => $exam->exam_id,
                'sno' => $exam->sno,
                'is_group' => $exam->is_group,
                'question_bank_id' => $exam->question_bank_id,
                'exam_type' => $exam->exam_type,
                'exam_duration' => $exam->exam_duration,
                'exam_name' => $exam->exam_name,
                'exam_start_date' => $exam->exam_start_date,
                'exam_end_date' => $exam->exam_end_date,
                'no_of_attempt' => $exam->no_of_attempt,
                'positive_mark_per_quest' => $exam->positive_mark_per_quest,
                'negative_mark_per_quest' => $exam->negative_mark_per_quest,
                'exam_attempt' => $exam->exam_attempt,
                'question_ids' => $questionIds,
                'no_of_questions' => $exam->no_of_questions,
                'total_marks' => $exam->total_marks,
                'exam_hint' => $exam->exam_hint,
                'hint_text' => $exam->hint_text,
                'exam_explanation' => $exam->exam_explanation,
                'explanation_text' => $exam->explanation_text,
                'display_total_score' => $exam->display_total_score,
                'certificate' => $exam->certificate,
                'exam_mode' => $exam->exam_mode,
                'exam_mode_amount' => $exam->exam_mode_amount,
                'exam_mode_points' => $exam->exam_mode_points,
                'exam_description' => $exam->exam_description,
                'thumbnail_image' => $exam->thumbnail_image,
                'status' => $exam->status,


            ];
        }

        // Return the exam data as a response
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $exam_data, // Return processed exam data
        ], 200);
    }

    public function StaffExamList(Request $request)
    {
        $customer_id = $request->customer_id;

        // Fetch batch data with necessary joins
        // $stud_syllabus = StaffModel::select(
        //     'za_staff.staff_id',
        //     'za_staff.course_id',
        //     'za_staff.batch_id',
        //     'za_course.course_name'
        // )
        //     ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        //     ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
        //     // ->where('za_training.customer_id', $customer_id)
        //     ->get();

        $staff_exam = ExamModel::where("exam_category", 1)->where("status", 0)->get();

        $exam_data = [];
        foreach ($staff_exam as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedQuestions = json_decode($exam->exam_question_ids, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            $questionIds = $decodedQuestions ? array_column($decodedQuestions, 'question_id') : [];

            // Prepare exam data
            $exam_data[] = [
                'exam_id' => $exam->exam_id,
                'sno' => $exam->sno,
                'is_group' => $exam->is_group,
                'question_bank_id' => $exam->question_bank_id,
                'exam_type' => $exam->exam_type,
                'exam_duration' => $exam->exam_duration,
                'exam_name' => $exam->exam_name,
                'exam_start_date' => $exam->exam_start_date,
                'exam_end_date' => $exam->exam_end_date,
                'no_of_attempt' => $exam->no_of_attempt,
                'positive_mark_per_quest' => $exam->positive_mark_per_quest,
                'negative_mark_per_quest' => $exam->negative_mark_per_quest,
                'exam_attempt' => $exam->exam_attempt,
                'question_ids' => $questionIds,
                'no_of_questions' => $exam->no_of_questions,
                'total_marks' => $exam->total_marks,
                'exam_hint' => $exam->exam_hint,
                'hint_text' => $exam->hint_text,
                'exam_explanation' => $exam->exam_explanation,
                'explanation_text' => $exam->explanation_text,
                'display_total_score' => $exam->display_total_score,
                'certificate' => $exam->certificate,
                'exam_mode' => $exam->exam_mode,
                'exam_mode_amount' => $exam->exam_mode_amount,
                'exam_mode_points' => $exam->exam_mode_points,
                'exam_description' => $exam->exam_description,
                'thumbnail_image' => $exam->thumbnail_image,
                'status' => $exam->status,


            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => $exam_data,
        ], 200);
    }

    public function ExamQuestions(Request $request)
    {
        $exam_id = $request->exam_id;

        $exam_question = ExamModel::where('za_exam.sno', $exam_id)->select('za_exam.*', 'za_exam_question_bank.question_bank_name') // Filter exams by the provided IDs
            ->where('za_exam.status', 0)
            ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id');  // Check for exams with active status (assuming 0 means active)

        // Get the exam that matches the student's exam ID
        $exam_list = $exam_question->first();
        $exams = $exam_list;
        if ($exams) {
            // Decode exam_question_ids if it's a JSON string
            if (isset($exams->exam_question_ids) && is_string($exams->exam_question_ids)) {
                $exams->exam_question_ids = json_decode($exams->exam_question_ids, true);
            }
        }

        // Handle cases where decoding fails or returns unexpected results
        if (!isset($exams->exam_question_ids) || !is_array($exams->exam_question_ids)) {
            $exams->exam_question_ids = [];
        }

        // Decode question IDs from exam details
        $examQuestionIds = collect($exam_list->exam_question_ids ?? '[]')
            ->pluck('question_id')->toArray();

        // Fetch questions with hints, explanations, and options
        $examQuestions = ManageQuestionModel::select('za_exam_question.*')
            ->whereIn('za_exam_question.sno', $examQuestionIds)
            ->where('za_exam_question.status', 0)
            ->get();

        // Process the exams and decode question IDs
        $exam_data = [];
        foreach ($examQuestions as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedOption = json_decode($exam->question_option, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            // $questionIds = $decodedOption ? array_column($decodedOption, 'question_id') : [];

            // Prepare exam data
            $exam_data[] = [
                'question_id' => $exam->sno,
                'branch_id' => $exam->branch_id,
                'question_bank_id' => $exam->question_bank_id,
                'question_name' => $exam->question_name,
                'question_type' => $exam->question_type,
                'exam_name' => $exam->exam_name,
                   'exam_level' => $exam->exam_level,
                'question_id_auto' => $exam->question_id,
                'question_option' => $decodedOption,
                'answer' => $exam->answer,
                'question_hint' => $exam->question_hint,
                'question_explanation' => $exam->negative_mark_per_quest,
                'hint_text' => $exam->hint_text,
                'explanation_text' => $exam->explanation_text,
                'question_snippet' => $exam->question_snippet,
                'snippet_content' => $exam->snippet_content,
                'status' => $exam->status,


            ];
        }
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'Exam Details' => $exams,
            'Exam Questions' => $exam_data,
        ], 200);
    }

    public function saveAnswer(Request $request)
    {
        $examModel = ExamModel::where('sno', $request->exam_id)->first();
        if (!$examModel) {
            return response()->json(['error' => 'Invalid exam ID'], 400);
        }

        $answerData = $request->input('answer_data', []);

        $answer = $answerData['answer'] ?? null;

        $timeSpent = $answerData['time_spent'] ?? 0;

        // if (is_null($answer)) {
        //     return response()->json(['error' => 'Answer data is missing'], 400);
        // }

        $examProcess = StaffExamProcessModel::firstOrCreate(
            ['exam_id' => $request->exam_id, 'staff_id' => $request->staff_id],
            [
                'exam_process_id' => uniqid(),
                'branch_id'   => $examModel->branch_id,
                'total_marks' => $examModel->total_marks ?? 0,
                'staff_marks' => $examModel->total_marks ?? 0,
                'attempted_not_count' => 0,
                'total_attended_duration' => 0,
                'status' => 1,
                'exam_question_answers_datas' => [],
                'created_by' => $request->staff_id,
                'updated_by' => $request->staff_id,
            ]
        );

        // return $examProcess;

        // $answers = $examProcess->exam_question_answers_datas ?? [];
        $answers = is_array($examProcess->exam_question_answers_datas) ? $examProcess->exam_question_answers_datas : json_decode($examProcess->exam_question_answers_datas, true) ?? [];

        // return $answers;
        $index = array_search($request->question_id, array_column($answers, 'question_id'));

        if ($index === false) {
            $answers[] = [
                'question_id' => $request->question_id,
                'answer' => $answer,
                'time_spent' => $timeSpent,
                'correctness' => $this->checkAnswer($request->question_id, $answer),
            ];
        } else {
            $answers[$index]['answer'] = $answer;
            $answers[$index]['time_spent'] = $timeSpent;
            $answers[$index]['correctness'] = $this->checkAnswer($request->question_id, $answer);
        }

        // Additional calculations
        $skipcount = 0;
        $correctcount = 0;
        foreach ($answers as $ans) {
            if (empty($ans['answer'])) {
                $skipcount++;
            }
            if ($ans['correctness'] === 'correct') {
                $correctcount++;
            }
        }

        $examProcess->staff_marks = $correctcount * $examModel->positive_mark_per_quest;

        $notattempt = $examModel->no_of_questions - count($answers);
        $examProcess->attempted_not_count = $notattempt + $skipcount;
        $examProcess->total_attended_duration = array_reduce($answers, fn($carry, $item) => $carry + $item['time_spent'], 0);

        if (count($answers) == $examModel->no_of_questions) {
            $examProcess->status = 2;
            $examProcess->save();
        }

        $examProcess->exam_question_answers_datas = $answers;

        $examProcess->save();

        return response()->json(['message' => 'Answer and time saved successfully']);
    }

    public function checkAnswer($questionId, $answer)
    {
        // Logic to check if the answer is correct (you'll need to modify this)
        $question = ManageQuestionModel::find($questionId);
        if ($question->answer == $answer) {
            return 'correct';
        }
        return 'incorrect';
    }

    public function ExamCompleteList(Request $request)
    {
        $staff_id = $request->staff_id;

        // Fetch the student record
        $staffs = StaffExamProcessModel::where('staff_id', $staff_id)->where('status', 2)->get();

        // return $staff;

        // Validate if student exists
        if ($staffs->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $examData = [];

        // Extract the `exam_id`s of the completed exams
        foreach ($staffs as $staff) {
            $completedExamIds = [$staff->exam_id];

            // Fetch details of the completed exams from the `za_exam` table
            $examDetails = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
                ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
                ->whereIn('za_exam.sno', $completedExamIds)
                ->get();

            // Prepare the response data
            $examData = $examDetails->map(function ($exam) {
                $decodedQuestions = json_decode($exam->exam_question_ids, true) ?? [];
                $questionIds = array_column($decodedQuestions, 'question_id');

                return [
                    'exam_id' => $exam->exam_id,
                    'sno' => $exam->sno,
                    'is_group' => $exam->is_group,
                    'question_bank_id' => $exam->question_bank_id,
                    'exam_type' => $exam->exam_type,
                    'exam_duration' => $exam->exam_duration,
                    'exam_name' => $exam->exam_name,
                    'exam_start_date' => $exam->exam_start_date,
                    'exam_end_date' => $exam->exam_end_date,
                    'no_of_attempt' => $exam->no_of_attempt,
                    'positive_mark_per_quest' => $exam->positive_mark_per_quest,
                    'negative_mark_per_quest' => $exam->negative_mark_per_quest,
                    'exam_attempt' => $exam->exam_attempt,
                    'question_ids' => $questionIds,
                    'no_of_questions' => $exam->no_of_questions,
                    'total_marks' => $exam->total_marks,
                    'exam_hint' => $exam->exam_hint,
                    'hint_text' => $exam->hint_text,
                    'exam_explanation' => $exam->exam_explanation,
                    'explanation_text' => $exam->explanation_text,
                    'display_total_score' => $exam->display_total_score,
                    'certificate' => $exam->certificate,
                    'exam_mode' => $exam->exam_mode,
                    'exam_mode_amount' => $exam->exam_mode_amount,
                    'exam_mode_points' => $exam->exam_mode_points,
                    'exam_description' => $exam->exam_description,
                    'thumbnail_image' => $exam->thumbnail_image,
                    'status' => $exam->status,
                ];
            });
        };

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Completed Exams Retrieved Successfully',
            'error_msg' => null,
            'data' => $examData,
        ], 200);
    }

    public function ExamResult(Request $request)
    {
        $staff_id = $request->staff_id;
        $exam_id = $request->exam_id;

        // Fetch the student record
        $staff = StaffExamProcessModel::where('staff_id', $staff_id)->where('exam_id', $exam_id)->where('status', 2)->get();

        // return $staff;

        // Validate if student exists
        if ($staff->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        // Extract the `exam_id`s of the completed exams
        $completedExamIds = $staff[0]->exam_id;

        // Fetch details of the completed exams from the `za_exam` table
        $exam_list = ExamModel::select('za_exam.*', 'za_exam_question_bank.question_bank_name')
            ->leftJoin('za_exam_question_bank', 'za_exam_question_bank.sno', '=', 'za_exam.question_bank_id')
            ->where('za_exam.status', '!=', 2);

        // Prepare the response data
        $exam_list = $exam_list->where('za_exam.sno', $exam_id)->first();
        $decodedQuestions = json_decode($exam_list->exam_question_ids ?? '[]', true) ?? [];
        $questionIds = array_column($decodedQuestions, 'question_id');

        $exam_data_list[] = [
            'exam_id' => $exam_list->exam_id,
            'sno' => $exam_list->sno,
            'is_group' => $exam_list->is_group,
            'question_bank_id' => $exam_list->question_bank_id,
            'exam_type' => $exam_list->exam_type,
            'exam_duration' => $exam_list->exam_duration,
            'exam_name' => $exam_list->exam_name,
            'exam_start_date' => $exam_list->exam_start_date,
            'exam_end_date' => $exam_list->exam_end_date,
            'no_of_attempt' => $exam_list->no_of_attempt,
            'positive_mark_per_quest' => $exam_list->positive_mark_per_quest,
            'negative_mark_per_quest' => $exam_list->negative_mark_per_quest,
            'exam_attempt' => $exam_list->exam_attempt,
            'question_ids' => $questionIds,
            'no_of_questions' => $exam_list->no_of_questions,
            'total_marks' => $exam_list->total_marks,
            'exam_hint' => $exam_list->exam_hint,
            'hint_text' => $exam_list->hint_text,
            'exam_explanation' => $exam_list->exam_explanation,
            'explanation_text' => $exam_list->explanation_text,
            'display_total_score' => $exam_list->display_total_score,
            'certificate' => $exam_list->certificate,
            'exam_mode' => $exam_list->exam_mode,
            'exam_mode_amount' => $exam_list->exam_mode_amount,
            'exam_mode_points' => $exam_list->exam_mode_points,
            'exam_description' => $exam_list->exam_description,
            'thumbnail_image' => $exam_list->thumbnail_image,
            'status' => $exam_list->status,
        ];

        // Decode question IDs from exam details
        $examQuestionIds = collect(json_decode($exam_list->exam_question_ids ?? '[]'))
            ->pluck('question_id')->toArray();

        // Fetch questions with hints, explanations, and options
        $examQuestions = ManageQuestionModel::select('za_exam_question.*')
            ->whereIn('za_exam_question.sno', $examQuestionIds)
            ->where('za_exam_question.status', 0)
            ->get();
        $exam_data_question = [];

        foreach ($examQuestions as $exam) {
            // Decode the exam_question_ids JSON string
            $decodedOption = json_decode($exam->question_option, true); // Convert to associative array

            // Extract the question IDs or handle decoding failure
            // $questionIds = $decodedOption ? array_column($decodedOption, 'question_id') : [];

            // Prepare exam data
            $exam_data_question[] = [
                'question_id' => $exam->sno,
                'branch_id' => $exam->branch_id,
                'question_bank_id' => $exam->question_bank_id,
                'question_name' => $exam->question_name,
                'question_type' => $exam->question_type,
                'exam_name' => $exam->exam_name,
                'question_id_auto' => $exam->question_id,
                'question_option' => $decodedOption,
                'answer' => $exam->answer,
                'question_hint' => $exam->question_hint,
                'question_explanation' => $exam->negative_mark_per_quest,
                'hint_text' => $exam->hint_text,
                'explanation_text' => $exam->explanation_text,
                'question_snippet' => $exam->question_snippet,
                'snippet_content' => $exam->snippet_content,
                'status' => $exam->status,


            ];
        }

        $examProcess = StaffExamProcessModel::where('exam_id', $exam_id)
            ->where('staff_id', $staff_id)
            ->first();
        $examProcess2 = StaffExamProcessModel::where('exam_id', $exam_id)
            ->where('staff_id', $staff_id)
            ->first();

        $examdata2[] = [
            'exam_process_id' => $examProcess2->exam_process_id,
            'sno' => $examProcess2->sno,
            'branch_id' => $examProcess2->branch_id,
            'exam_id' => $examProcess2->exam_id,
            'student_id' => $examProcess2->student_id,
            'total_marks' => $examProcess2->total_marks,
            'student_marks' => $examProcess2->student_marks,
            'attempted_not_count' => $examProcess2->attempted_not_count,
            'total_attended_duration' => $examProcess2->total_attended_duration,
            'status' => $examProcess2->status
        ];

        // Check if $examProcess is not null before accessing its property
        if ($examProcess && isset($examProcess->exam_question_answers_datas)) {
            // If the field is already an array, use it directly
            $savedAnswers = is_array($examProcess->exam_question_answers_datas)
                ? $examProcess->exam_question_answers_datas
                : [];
        } else {
            // Handle the case where no exam process is found or the field is empty
            $savedAnswers = [];
        }

        $totalCorrect = 0;
        $totalIncorrect = 0;

        foreach ($savedAnswers as $answer) {
            // Assuming $question->answer holds the correct answer and $answer['answer'] is the student's answer
            if (isset($answer['answer'])) {
                $isCorrect = ($answer['correctness'] === 'correct');
                if ($isCorrect) {
                    $totalCorrect++;
                } else {
                    $totalIncorrect++;
                }
            }
        }

        $examProcess = $examProcess;
        $examQuestions = $exam_data_question;

        $mergedQuestions = [];

        foreach ($examQuestions as $question) {
            $questionId = $question['question_id'];

            // Find the matching answer from exam process data
            $answerData = collect($examProcess['exam_question_answers_datas'])
                ->firstWhere('question_id', (string) $questionId);

            $mergedQuestions[] = [
                'question_id' => $question['question_id'],
                'question_name' => $question['question_name'],
                'question_type' => $question['question_type'],
                'question_options' => $question['question_option'],
                'correct_answer' => $question['answer'],
                'hint_text' => $question['hint_text'],
                'explanation_text' => $question['explanation_text'],
                'student_answer' => $answerData['answer'] ?? null,
                'time_spent' => $answerData['time_spent'] ?? null,
                'correctness' => $answerData['correctness'] ?? 'not attempted',
            ];
        }

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'merged_questions' => $mergedQuestions,
            'Exam Process' => $examdata2, // Total exams
            // 'Exam Questions' => $exam_data_question, // Finished exams
            'Exam list' => $exam_data_list, // Finished exams
        ], 200);
    }
    
    public function StaffExamDash(Request $request)
    {
        $staff_id = $request->staff_id; // Retrieve customer ID

        // Fetch student data including the exam_status field
        $exams=ExamModel::where("status", 0)->get();
        $staff=StaffExamProcessModel::where('staff_id', $staff_id)->where('status', 2)->get();
        $totalCount=count($exams);
        $finishedCount=count($staff);
        $average_complete=0;
        if($totalCount >0){
          $average_complete = ($finishedCount / $totalCount)*100;
        }
        $average_complete = number_format($average_complete, 1);


        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'Total Exam' => $totalCount, // Total exams
            'Finished Exam' => $finishedCount, // Finished exams
            'Average completed' => $average_complete, // Average exams
        ], 200);
    }
    
    // public function CourseMaterial(Request $request)
    // {
    //     $staff_id = $request->input('staff_id');

    //     // Fetch batch data with necessary joins
    //     $batches = BatchModel::select(
    //         'za_batch.course_id',
    //         'za_course.course_name',
    //         'za_course.course_days',
    //         'za_course.course_version',
    //         'za_course.course_partical_hours',
    //         'za_course.course_theory_hours',
    //         'za_course.course_duration',
    //         'za_course.course_code',
    //         'za_course.materials',
    //         'za_course_subcategory.course_subcategory_name',
    //         'za_course.attachment',
    //         'za_course.thumbnail',
    //         'za_batch.course_type_id',
    //         'za_course_type.course_type_name',
    //         'za_staff.staff_name',
    //         'za_staff.nick_name',
    //         'za_staff.gender',
    //         'za_staff.staff_image',
    //     )
    //         ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
    //         ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //         ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
    //         ->where('za_batch.staff_id', '=', $staff_id)
    //         ->where('za_batch.status', '!=', 2)
    //         ->groupBy(
    //             'za_batch.course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_duration',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_code',
    //             'za_course.materials',
    //             'za_course.course_duration',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_course.attachment',
    //             'za_course.thumbnail',
    //             'za_batch.course_type_id',
    //             'za_course_type.course_type_name',
    //             'za_staff.staff_name',
    //             'za_staff.nick_name',
    //             'za_staff.gender',
    //             'za_staff.staff_image',
    //         )
    //         ->get();

    //     // Decode materials and append URLs dynamically
    //     $batches->transform(function ($batch) {
    //         $batch->course_materials = $batch->materials ? json_decode($batch->materials, true) : [];

    //         // Fetch material type names
    //         $material_types = DB::table('za_material_type')
    //             ->select('sno', 'material_type_name as folder_name')
    //             ->where('status', 0)
    //             ->get()
    //             ->toArray(); // Convert to an array for further processing

    //         $batch->material_names = $material_types; // Retain material names list as required

    //         $courseId        = $batch->course_id;
    //         $materialBaseUrl = 'https://erp.elysium.academy/course_materials';

    //         // Initialize an array for storing material URLs grouped by folder_name
    //         $materialUrls = [];

    //         // Add all material types to ensure the output contains empty arrays for missing types
    //         foreach ($material_types as $materialType) {
    //             $folderName                = $materialType->folder_name;
    //             $materialUrls[$folderName] = []; // Ensure keys exist in the desired order
    //         }

    //         // Populate material URLs based on course_materials
    //         foreach ($batch->course_materials as $materialTypeId => $files) {
    //             $materialType = array_filter($material_types, function ($type) use ($materialTypeId) {
    //                 return $type->sno == $materialTypeId;
    //             });

    //             if (! empty($materialType)) {
    //                 $folderName = reset($materialType)->folder_name; // Get the folder name
    //                 foreach ($files as $file) {
    //                     $materialUrls[$folderName][] = [
    //                         'name' => $file,
    //                         'url'  => "{$materialBaseUrl}/{$courseId}/{$materialTypeId}/{$file}",
    //                     ];
    //                 }
    //             }
    //         }

    //         // Convert the associative array to an indexed array with folder names as keys
    //         $batch->course_materials = array_map(function ($folderName) use ($materialUrls) {
    //             return [$folderName => $materialUrls[$folderName]];
    //         }, array_keys($materialUrls));

    //         // Append base URLs for attachments and thumbnails
    //         $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
    //         $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';

    //         $batch->attachment = $batch->attachment ? $attachmentBaseUrl . $batch->attachment : null;
    //         $batch->thumbnail  = $batch->thumbnail ? $thumbnailBaseUrl . $batch->thumbnail : null;

    //         return $batch;
    //     });

    //     return response()->json([
    //         'status'    => 200,
    //         'message'   => 'Data Retrieved Successfully',
    //         'error_msg' => null,
    //         'data'      => $batches,
    //     ], 200);
    // }

      public function CourseMaterial(Request $request)
    {
        // Get staff_id from request (as in old code)
        $staff_id = $request->input('staff_id');

        if (empty($staff_id)) {
        return response()->json([
            'status' => 400,
            'message' => 'Staff ID is required',
            'error_msg' => 'Missing staff_id parameter',
            'data' => null
        ], 400);
        }

        // Fetch staff details to get branch_id
        $staff = StaffModel::where('sno', $staff_id)
        ->where('department_id', 2)
        ->first();

        if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Invalid staff_id',
            'data' => null
        ], 404);
        }

        $branch_id = $staff->branch_id ?? null;

        // Base query - combining old structure with new web logic
        $query = ManageCoursesModel::select(
        'za_course.sno as course_id',
        'za_course.course_name',
        'za_course.course_days',
        'za_course.course_version',
        'za_course.course_partical_hours',
        'za_course.course_theory_hours',
        'za_course.course_duration',
        'za_course.course_code',
        'za_course.materials',
        'za_course.course_subcategory_id',
        'za_course.attachment',
        'za_course.thumbnail',
        'za_course_type.sno as course_type_id',
        'za_course_type.course_type_name',
        'za_course_subcategory.course_subcategory_name',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image'
        )
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
        ->join('za_staff', 'za_staff.sno', '=', DB::raw($staff_id))
        ->join('za_batch', function ($join) use ($staff_id, $branch_id) {
            $join->on('za_batch.course_id', '=', 'za_course.sno')
            ->where('za_batch.staff_id', '=', $staff_id)
            ->where('za_batch.status', '=', 0); // Active batches only
            if ($branch_id) {
            $join->where('za_batch.branch_id', '=', $branch_id);
            }
        })
        ->where('za_course.status', '!=', 2)
        ->orderBy('za_course.sno', 'desc');

        // Apply filters (optional - can be passed as request parameters)
        $filters = $request->only([
        'course_fill',
        'course_category_fill',
        'course_subcategory_fill',
        'course_type_fill'
        ]);

        if (!empty($filters['course_fill'])) {
        $query->where('za_course.course_name', 'LIKE', "%{$filters['course_fill']}%");
        }

        if (!empty($filters['course_category_fill'])) {
        $query->where('za_course.course_category_id', $filters['course_category_fill']);
        }

        if (!empty($filters['course_subcategory_fill'])) {
        $query->where('za_course.course_subcategory_id', $filters['course_subcategory_fill']);
        }

        if (!empty($filters['course_type_fill'])) {
        $query->where('za_course.course_type_id', $filters['course_type_fill']);
        }

        // Get results (with pagination or without - based on mobile needs)
        $per_page = $request->input('per_page', 25);
        $courses = $query->paginate($per_page);

        // Transform data to match old structure format
        $courses->getCollection()->transform(function ($course) {
        // Decode materials
        $course_materials = json_decode($course->materials, true) ?? [];

        // Get material type names
        $material_types = DB::table('za_material_type')
            ->select('sno', 'material_type_name as folder_name')
            ->where('status', 0)
            ->get();

        $courseId = $course->course_id;
        $materialBaseUrl = 'https://erp.elysium.academy/course_materials';

        // Initialize material URLs grouped by folder name
        $materialUrls = [];
        foreach ($material_types as $materialType) {
            $folderName = $materialType->folder_name;
            $materialUrls[$folderName] = [];
        }

        // Process materials from the course
        foreach ($course_materials as $material) {
            $materialTypeId = $material['document_type_id'] ?? null;
            $file = $material['file_name'] ?? null;

            if ($materialTypeId && $file) {
            $materialType = $material_types->firstWhere('sno', $materialTypeId);
            if ($materialType) {
                $folderName = $materialType->folder_name;
                $materialUrls[$folderName][] = [
                'name' => $file,
                'url' => "{$materialBaseUrl}/{$courseId}/{$materialTypeId}/{$file}"
                ];
            }
            }
        }

        // Convert to indexed array format (matching old structure)
        $course->course_materials = array_map(function ($folderName) use ($materialUrls) {
            return [$folderName => $materialUrls[$folderName]];
        }, array_keys($materialUrls));

        // Get material counts (from web version)
        $materialCounts = [];
        for ($i = 1; $i <= 6; $i++) {
            $materialCounts[$i] = [
            'exists' => false,
            'count' => 0
            ];
        }

        foreach ($course_materials as $material) {
            $type = (int) ($material['document_type_id'] ?? 0);
            if ($type >= 1 && $type <= 6) {
            $materialCounts[$type]['exists'] = true;
            $materialCounts[$type]['count']++;
            }
        }
        $course->material_counts = $materialCounts;

        // Append base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl = 'https://erp.elysium.academy/course_thumbnail_image/';

        $course->attachment = $course->attachment ? $attachmentBaseUrl . $course->attachment : null;
        $course->thumbnail = $course->thumbnail ? $thumbnailBaseUrl . $course->thumbnail : null;

        // Remove the raw materials field from response
        unset($course->materials);

        return $course;
        });

        return response()->json([
        'status' => 200,
        'message' => 'Data Retrieved Successfully',
        'error_msg' => null,
        'data' => $courses,
        'pagination' => [
            'total' => $courses->total(),
            'per_page' => $courses->perPage(),
            'current_page' => $courses->currentPage(),
            'last_page' => $courses->lastPage(),
        ]
        ], 200);
    }

    // public function CourseMaterialByTypeId(Request $request)
    // {
    //     $staff_id = $request->input('staff_id');
    //     $course_id = $request->input('course_id');
    //     $material_type_id = $request->input('material_type_id');

    //     // Validate staff exists and is faculty
    //     $staff = StaffModel::where('sno', $staff_id)
    //         ->where('department_id', 2)
    //         ->first();

    //     if (!$staff) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Staff not found',
    //             'error_msg' => 'Invalid staff ID or staff is not faculty',
    //             'data' => null,
    //         ], 404);
    //     }

    //     // Verify staff is assigned to this course
    //     $batch = BatchModel::where('staff_id', $staff_id)
    //         ->where('course_id', $course_id)
    //         ->where('status', 0)
    //         ->first();

    //     if (!$batch) {
    //         return response()->json([
    //             'status' => 403,
    //             'message' => 'Access denied',
    //             'error_msg' => 'You are not assigned to this course',
    //             'data' => null,
    //         ], 403);
    //     }

    //     // Fetch course data
    //     $course = DB::table('za_course')
    //         ->select(
    //             'za_course.sno as course_id',
    //             'za_course.course_name',
    //             'za_course.course_days',
    //             'za_course.course_version',
    //             'za_course.course_partical_hours',
    //             'za_course.course_theory_hours',
    //             'za_course.course_duration',
    //             'za_course.course_code',
    //             'za_course.materials',
    //             'za_course_subcategory.course_subcategory_name',
    //             'za_course.attachment',
    //             'za_course.thumbnail',
    //             'za_course_type.course_type_name'
    //         )
    //         ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
    //         ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
    //         ->where('za_course.sno', '=', $course_id)
    //         ->where('za_course.status', '!=', 2)
    //         ->first();

    //     if (!$course) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Course not found',
    //             'error_msg' => 'Invalid course ID',
    //             'data' => null,
    //         ], 404);
    //     }

    //     // Decode materials JSON
    //     $materials = $course->materials ? json_decode($course->materials, true) : [];
    //     $materialBaseUrl = 'https://erp.elysium.academy/course_materials';
    //     $filteredMaterials = [];

    //     // Get material type name
    //     $material_type = DB::table('za_material_type')
    //         ->select('sno', 'material_type_name as folder_name')
    //         ->where('status', 0)
    //         ->where('sno', $material_type_id)
    //         ->first();

    //     // Check for materials matching the material_type_id
    //     if ($material_type && isset($materials[$material_type_id])) {
    //         foreach ($materials[$material_type_id] as $file) {
    //             $filteredMaterials[] = [
    //                 'name' => $file,
    //                 'url' => "{$materialBaseUrl}/{$course_id}/{$material_type_id}/{$file}",
    //                 'type' => $material_type->folder_name
    //             ];
    //         }
    //     }

    //     // Get additional material types for the course (counts)
    //     $material_counts = [];
    //     for ($i = 1; $i <= 6; $i++) {
    //         $count = isset($materials[$i]) ? count($materials[$i]) : 0;
    //         $material_counts[$i] = [
    //             'type_id' => $i,
    //             'count' => $count,
    //             'exists' => $count > 0
    //         ];
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Data Retrieved Successfully',
    //         'error_msg' => null,
    //         'data' => [
    //             'course_id' => $course->course_id,
    //             'course_name' => $course->course_name,
    //             'course_code' => $course->course_code,
    //             'folder_name' => $material_type ? $material_type->folder_name : null,
    //             'material_type_id' => $material_type_id,
    //             'course_materials' => $filteredMaterials,
    //             'total_count' => count($filteredMaterials),
    //             'material_counts' => $material_counts
    //         ],
    //     ], 200);
    // }

    public function CourseMaterialByTypeId(Request $request)
    {
        $staff_id = $request->input('staff_id');
        $course_id = $request->input('course_id');

        // Validate staff exists and is faculty
        $staff = StaffModel::where('sno', $staff_id)
            ->where('department_id', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Invalid staff ID or staff is not faculty',
            ], 404);
        }

        // Verify staff is assigned to this course
        $batch = BatchModel::where('staff_id', $staff_id)
            ->where('course_id', $course_id)
            ->where('status', 0)
            ->first();

        if (!$batch) {
            return response()->json([
                'status' => 403,
                'message' => 'Access denied',
                'error_msg' => 'You are not assigned to this course',
            ], 403);
        }

        // Get course details
        $course = ManageCoursesModel::where('sno', $course_id)
            ->where('status', 0)
            ->first();

        if (!$course) {
            return response()->json([
                'status' => 404,
                'message' => 'Course not found',
                'error_msg' => 'Course not found',
            ], 404);
        }

        // Decode materials JSON
        $materials = [];
        if (!empty($course->materials)) {
            $materials = json_decode($course->materials, true);
        }

        // Get all chapters
        $chapter_views = ManageCoursesSyllabusModel::where('course_id', $course_id)
            ->where('status', 0)
            ->select(
                'course_chapter_id',
                'course_chapter_name',
                'course_chapter_practical_hours',
                'course_chapter_theory_hours',
                DB::raw('MAX(sno) as max_sno')
            )
            ->groupBy(
                'course_chapter_id',
                'course_chapter_name',
                'course_chapter_theory_hours',
                'course_chapter_practical_hours'
            )
            ->get();

        $chapters = [];

        foreach ($chapter_views as $chapter) {
            $chapter_id = $chapter->course_chapter_id;

            // Filter materials for this chapter
            $chapterMaterials = collect($materials)->filter(function ($m) use ($chapter_id) {
                if (!isset($m['chapter_id'])) return false;
                return trim(str_replace('\/', '/', $m['chapter_id'])) ===
                    trim(str_replace('\/', '/', $chapter_id));
            });

            // Counts by document type
            $study_doc_count = $chapterMaterials->where('document_type_id', 1)->count();
            $ppt_count = $chapterMaterials->where('document_type_id', 2)->count();
            $lab_code_count = $chapterMaterials->where('document_type_id', 3)->count();
            $pdf_count = $chapterMaterials->where('document_type_id', 4)->count();
            $audio_count = $chapterMaterials->where('document_type_id', 5)->count();
            $video_count = $chapterMaterials->where('document_type_id', 6)->count();

            // Flags
            $has_study_doc = $study_doc_count > 0;
            $has_ppt = $ppt_count > 0;
            $has_lab_code = $lab_code_count > 0;
            $has_pdf = $pdf_count > 0;
            $has_audio = $audio_count > 0;
            $has_video = $video_count > 0;

            // Generate links for each type (for staff, include all materials)
            $study_doc_links = $chapterMaterials
                ->where('document_type_id', 1)
                ->map(fn($m) => [
                    'name' => $m['material_name'] ?? null,
                    'url' => url("course_materials/{$m['course_id']}/1/{$m['material_name']}")
                ])
                ->values();

            $ppt_links = $chapterMaterials
                ->where('document_type_id', 2)
                ->map(fn($m) => [
                    'name' => $m['material_name'] ?? null,
                    'url' => url("course_materials/{$m['course_id']}/2/{$m['material_name']}")
                ])
                ->values();

            $pdf_links = $chapterMaterials
                ->where('document_type_id', 4)
                ->map(fn($m) => [
                    'name' => $m['material_name'] ?? null,
                    'url' => url("course_materials/{$m['course_id']}/4/{$m['material_name']}")
                ])
                ->values();

            $audio_links = $chapterMaterials
                ->where('document_type_id', 5)
                ->map(fn($m) => [
                    'name' => $m['material_name'] ?? null,
                    'url' => url("course_materials/{$m['course_id']}/5/{$m['material_name']}")
                ])
                ->values();

            $video_links = $chapterMaterials
                ->where('document_type_id', 6)
                ->map(fn($m) => [
                    'name' => $m['material_name'] ?? null,
                    'url' => url("course_materials/{$m['course_id']}/6/{$m['material_name']}")
                ])
                ->values();

            // Lab codes with full details
            $lab_codes = $chapterMaterials
                ->where('document_type_id', 3)
                ->map(function ($m) {
                    return [
                        'code_title' => $m['code_title'] ?? null,
                        'code_language' => $m['code_language'] ?? null,
                        'code_content' => $m['code_content'] ?? null,
                        'block_index' => $m['block_index'] ?? null,
                        'material_name' => $m['material_name'] ?? null,
                    ];
                })
                ->values();

            $chapters[] = [
                'chapter_code' => $chapter_id,
                'chapter_name' => $chapter->course_chapter_name,
                'chapter_theory_hours' => round($chapter->course_chapter_theory_hours, 2),
                'chapter_practical_hours' => round($chapter->course_chapter_practical_hours, 2),
                'chapter_id' => $chapter->max_sno,
                
                // Total materials count for this chapter
                'total_materials' => $chapterMaterials->count(),

                // Flags
                'has_study_doc' => $has_study_doc,
                'has_ppt' => $has_ppt,
                'has_lab_code' => $has_lab_code,
                'has_pdf' => $has_pdf,
                'has_audio' => $has_audio,
                'has_video' => $has_video,

                // Counts
                'study_doc_count' => $study_doc_count,
                'ppt_count' => $ppt_count,
                'lab_code_count' => $lab_code_count,
                'pdf_count' => $pdf_count,
                'audio_count' => $audio_count,
                'video_count' => $video_count,

                // Links (with metadata)
                'study_doc_links' => $study_doc_links,
                'ppt_links' => $ppt_links,
                'pdf_links' => $pdf_links,
                'audio_links' => $audio_links,
                'video_links' => $video_links,

                // Lab codes
                'lab_codes' => $lab_codes,
            ];
        }

        // Get chapter status helper (if needed for staff)
        // For staff, you might want to show progress or completion status
        $helper = new \App\Helpers\Helpers();
        foreach ($chapters as &$chapter) {
            // You can add staff-specific status logic here
            // For example, if you track which materials staff has uploaded or reviewed
            $chapter['chapter_status'] = 'available'; // Default status for staff
        }

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data' => [
                'course_id' => $course_id,
                'course_name' => $course->course_name,
                'course_code' => $course->course_code,
                'total_chapters' => count($chapters),
                'staff_id' => $staff_id,
                'staff_name' => $staff->staff_name,
                'chapters' => $chapters,
            ],
        ], 200);
    }

    public function staffStudentList(Request $request)
    {
        $id = $request->staff_id;

        // Fetch batch data with necessary joins
        $students = TrainingModel::where('za_training.staff_id', $id)
            ->select(
                'za_customer.sno as customer_sno',
                'za_customer.customer_id',
                'za_customer.cus_name',
                'za_batch.batch_name',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_code',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_batch.start_date',
                'za_batch.end_date'
            )
            ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id')
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_training.batch_id')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
            ->leftJoin('za_staff', 'za_training.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.status', '!=', 2)
            ->where('za_staff.status', '!=', 2)
            ->where('za_customer.status', '!=', 2)
            ->whereDate('za_batch.start_date', '<=', Carbon::now())
            ->whereDate('za_batch.end_date', '>=', Carbon::now())
            ->get();

        // Fetch general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

        // Map through the batches to format dates and add additional fields
        $formattedStudent = $students->map(function ($item) use ($dateFormat) {
            // Format dates
            $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
            $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);

            $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            $slotDays = json_decode($item->slot_type_days);

            // Check if slotDays is valid and is an array
            if ($slotDays && is_array($slotDays)) {
                // Filter out invalid days (must be between 1 and 7)
                $validDays = array_filter($slotDays, function ($day) {
                    // Check if day is numeric and between 1 and 7
                    return is_numeric($day) && $day >= 1 && $day <= 7;
                });

                // Convert numeric days to day names
                $item->slot_type_days = array_map(function ($day) use ($days) {
                    // Ensure day is within valid range before accessing array
                    $index = (int)$day - 1;
                    return isset($days[$index]) ? $days[$index] : null;
                }, $validDays);

                // Remove any null values (if any day was out of range)
                $item->slot_type_days = array_filter($item->slot_type_days);
            } else {
                $item->slot_type_days = [];
            }

            return $item;
        });

        return response()->json([
            'status' => 200,
            'message' => 'Data Retrieved Successfully',
            'error_msg' => null,
            'student_list' => $formattedStudent,
        ], 200);
    }


    public function StaffLogout(Request $request)
    {
        try {
            $user = $request->user()->token()->revoke();
            if ($user) {
                $response = [
                    'status' => 200,
                    'message' => 'You have been successfully logged out!',
                    'error_msg' => null,
                    'data' => null
                ];
                return response($response, 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'User Not Found',
                    'error_msg' => null,
                    'data' => null
                ], 500);
            }
        } catch (\Throwable $th) {
            return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
        }
    }
    
     public function appUpdateCheck(Request $request)
  {
    return response()->json([
      'status' => 200,
      'message' => 'Data Retrieved Successfully',
      'data' => [
        'app_name'       => 'Clari',
        'play_store_id'  => 'com.eapl.clari',
        'apple_id'       => 'id6744373765',
        'android'        => '2.0.5+7',
        'android_build'  => 24,
        'ios'            => '1.0.13',
        'ios_build'      => 27,
      ]
    ], 200);
  }
  

}