<?php

namespace App\Http\Controllers\user_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ManageUsers extends Controller
{
//   public function index()
//   {
//     $userpermission = UserRolePermissionModel::where('za_user_role_permission.status', '!=', 2)
//       ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
//       ->select(
//         'za_user_role_permission.sno',
//         'za_user_role.sno as role_id',
//         'za_user_role.role_name',
//         'za_user_role_permission.status'
//       )
//       ->get();
//     return view('content.user_management.manage_users.list', compact('userpermission'));
//   }
// public function index()
// {
//     $userpermission = UserRolePermissionModel::query()
//         ->from('za_user_role_permission')
//         ->where('za_user_role_permission.status', '!=', 2)
//         ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
//         ->leftJoin('za_staff', 'za_staff.role_id', '=', 'za_user_role.sno')
//         ->select([
//             'za_user_role_permission.sno',
//             'za_user_role.sno as role_id',
//             'za_user_role.role_name',
//             'za_user_role_permission.status as permission_status',

//             // Count distinct staff to avoid double counts due to joins
//             \DB::raw('COUNT(DISTINCT za_staff.sno) AS staff_count'),

//             // 1 if ANY staff in this role is active, else 0
//             \DB::raw('COALESCE(MAX(CASE WHEN za_staff.status = 0 THEN 1 ELSE 0 END), 0) AS role_status'),
//         ])
//         ->groupBy([
//             'za_user_role_permission.sno',
//             'za_user_role.sno',
//             'za_user_role.role_name',
//             'za_user_role_permission.status',
//         ])
//         ->get();

//     return view('content.user_management.manage_users.list', compact('userpermission'));
// }

public function index()
  {
   $userpermission = UserRolePermissionModel::query()
        ->from('za_user_role_permission')
        ->where('za_user_role_permission.status', '!=', 2)
        ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
        ->leftJoin('za_staff', 'za_staff.role_id', '=', 'za_user_role.sno')
        ->join('za_branch', 'za_staff.branch_id', '=', 'za_branch.sno')
        ->where('za_branch.status', 0)
        ->select([
            'za_user_role_permission.sno',
            'za_user_role.sno as role_id',
            'za_user_role.role_name',
            'za_user_role_permission.status as permission_status',

            // Count distinct staff to avoid double counts due to joins
            \DB::raw('COUNT(DISTINCT za_staff.sno) AS staff_count'),

            // 1 if ANY staff in this role is active, else 0
            \DB::raw('COALESCE(MAX(CASE WHEN za_staff.status = 0 THEN 1 ELSE 0 END), 0) AS role_status'),
        ])
        ->groupBy([
            'za_user_role_permission.sno',
            'za_user_role.sno',
            'za_user_role.role_name',
            'za_user_role_permission.status',
        ])
        ->get();

    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $roles = UserRolePermissionModel::where('za_user_role_permission.status', 0)
      ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
      ->select(
        'za_user_role_permission.*',
        'za_user_role.role_name'
      )
      ->get();

    $rolesWithPermissions = [];

    foreach ($roles as $role) {
      $rolePermissions = json_decode($role->permissions, true);
      if (is_string($rolePermissions)) {
        $rolePermissions = json_decode($rolePermissions, true);
      }
      $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

      $flattenedPermissions = [];

      foreach ($rolePermissions as $menuItem) {
        $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
        $menuChecked = $menuItem['menuChecked'] ?? 0;

        if (isset($menuItem['submenu'])) {
          foreach ($menuItem['submenu'] as $submenuItem) {
            $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
            $submenuChecked = $submenuItem['submenuChecked'] ?? 0;

            if (isset($submenuItem['actions'])) {
              foreach ($submenuItem['actions'] as $actionItem) {
                $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
                $actionChecked = $actionItem['actionChecked'];

                $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                  'actionName' => $actionName,
                  'actionChecked' => $actionChecked
                ];
              }
            }

            $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
          }
        }

        $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
      }

      $rolesWithPermissions[] = [
        'role' => $role,
        'permissions' => $flattenedPermissions
      ];
    }


    return view('content.user_management.manage_users.list', compact('userpermission', 'menu', 'rolesWithPermissions'));
  }


  public function users_add()
  {

    // Path to the JSON file
    $path = resource_path('menu/verticalMenu.json');

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    // dd($menu);
    // Pass the menu data to the view
    return view('content.user_management.manage_users.add', compact('menu'));
  }



  public function users_edit($id)
  {


    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');


    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    // $id = Crypt::decrypt($id);
    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $role = UserRolePermissionModel::where('sno', $id)->first();
    if (!$role) {
      abort(404, 'Role not found');
    }

    // Decode the JSON permissions string into an array
    $rolePermissions = json_decode($role->permissions, true);

    // Check if rolePermissions is a JSON string
    if (is_string($rolePermissions)) {
      $rolePermissions = json_decode($rolePermissions, true);
    }
    // Ensure rolePermissions is an array
    $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

    // Initialize flattenedPermissions array
    $flattenedPermissions = [];

    // Process role permissions
    foreach ($rolePermissions as $menuItem) {
      $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
      $menuChecked = isset($menuItem['menuChecked']) ? $menuItem['menuChecked'] : 0;

      if (isset($menuItem['submenu'])) {
        foreach ($menuItem['submenu'] as $submenuItem) {
          $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
          $submenuChecked = isset($submenuItem['submenuChecked']) ? $submenuItem['submenuChecked'] : 0;

          if (isset($submenuItem['actions'])) {
            foreach ($submenuItem['actions'] as $actionItem) {
              $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
              $actionChecked = $actionItem['actionChecked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                'actionName' => $actionName,
                'actionChecked' => $actionChecked
              ];
            }
          }

          if (isset($submenuItem['radios'])) {
            foreach ($submenuItem['radios'] as $radioItem) {
              $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
              $radioValue = $radioItem['radioValue'];
              $checked = $radioItem['checked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['radios'][] = [
                'radioName' => $radioName,
                'radioValue' => $radioValue,
                'checked' => $checked
              ];
            }
          }

          $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
        }
      }

      if (isset($menuItem['actions'])) {
        foreach ($menuItem['actions'] as $actionItem) {
          $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
          $actionChecked = $actionItem['actionChecked'];

          $flattenedPermissions[$menuName]['actions'][] = [
            'actionName' => $actionName,
            'actionChecked' => $actionChecked
          ];
        }
      }

      if (isset($menuItem['radios'])) {
        foreach ($menuItem['radios'] as $radioItem) {
          $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
          $radioValue = $radioItem['radioValue'];
          $checked = $radioItem['checked'];

          $flattenedPermissions[$menuName]['radios'][] = [
            'radioName' => $radioName,
            'radioValue' => $radioValue,
            'checked' => $checked
          ];
        }
      }

      $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
    }
    // dd($flattenedPermissions['SalesManagement']['submenu']); // or dd($submenuItem);
    // dd($flattenedPermissions);

    // Pass the menu and permissions data to the view
    return view('content.user_management.manage_users.edit', compact('menu', 'rolePermissions', 'flattenedPermissions', 'role'));
  }



  public function users_view($id)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');


    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;

    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $role = UserRolePermissionModel::where('sno', $id)->first();
    if (!$role) {
      abort(404, 'Role not found');
    }
    $role_name = UserRolePermissionModel::where('za_user_role_permission.sno', $id)
      ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
      ->select(
        'za_user_role_permission.sno',
        'za_user_role.sno as role_id',
        'za_user_role.role_name',
        'za_user_role_permission.status',
      )->first();
    if (!$role) {
      abort(404, 'Role not found');
    }
    // Decode the JSON permissions string into an array
    $rolePermissions = json_decode($role->permissions, true);

    // Check if rolePermissions is a JSON string
    if (is_string($rolePermissions)) {
      $rolePermissions = json_decode($rolePermissions, true);
    }
    // Ensure rolePermissions is an array
    $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

    // Initialize flattenedPermissions array
    $flattenedPermissions = [];

    // Process role permissions
    foreach ($rolePermissions as $menuItem) {
      $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
      $menuChecked = isset($menuItem['menuChecked']) ? $menuItem['menuChecked'] : 0;

      if (isset($menuItem['submenu'])) {
        foreach ($menuItem['submenu'] as $submenuItem) {
          $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
          $submenuChecked = isset($submenuItem['submenuChecked']) ? $submenuItem['submenuChecked'] : 0;

          if (isset($submenuItem['actions'])) {
            foreach ($submenuItem['actions'] as $actionItem) {
              $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
              $actionChecked = $actionItem['actionChecked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                'actionName' => $actionName,
                'actionChecked' => $actionChecked
              ];
            }
          }

          if (isset($submenuItem['radios'])) {
            foreach ($submenuItem['radios'] as $radioItem) {
              $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
              $radioValue = $radioItem['radioValue'];
              $checked = $radioItem['checked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['radios'][] = [
                'radioName' => $radioName,
                'radioValue' => $radioValue,
                'checked' => $checked
              ];
            }
          }

          $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
        }
      }

      if (isset($menuItem['actions'])) {
        foreach ($menuItem['actions'] as $actionItem) {
          $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
          $actionChecked = $actionItem['actionChecked'];

          $flattenedPermissions[$menuName]['actions'][] = [
            'actionName' => $actionName,
            'actionChecked' => $actionChecked
          ];
        }
      }

      if (isset($menuItem['radios'])) {
        foreach ($menuItem['radios'] as $radioItem) {
          $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
          $radioValue = $radioItem['radioValue'];
          $checked = $radioItem['checked'];

          $flattenedPermissions[$menuName]['radios'][] = [
            'radioName' => $radioName,
            'radioValue' => $radioValue,
            'checked' => $checked
          ];
        }
      }

      $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
    }

    // Pass the menu and permissions data to the view
    return view('content.user_management.manage_users.view', compact('menu', 'rolePermissions', 'flattenedPermissions', 'role', 'role_name'));
  }


  public function Add(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'role' => 'required|integer',
      'manage_branch' => 'required',
      'permissions' => 'required',
      'permissions.*.menu' => 'required|string',
      'permissions.*.submenu' => 'nullable',
      'permissions.*.submenu.*.name' => 'nullable|string',
      'permissions.*.submenu.*.actions' => 'nullable',
      'permissions.*.submenu.*.actions.*' => 'nullable|string',
      'permissions.*.actions' => 'nullable',
      'permissions.*.actions.*' => 'nullable|string',
    ]);

    if ($validator->fails()) {
      $errors = $validator->errors()->all();
      $firstError = $validator->errors()->first();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => $firstError . ' | Detailed errors: ' . implode(', ', $errors)
      ]);

      return redirect()->back()->withInput();
    }

    try {
      $permissionsJson = json_encode($request->permissions);
      if (json_last_error() !== JSON_ERROR_NONE) {
        throw new \Exception('Invalid JSON data');
      }

      $add_user_role_permission = new UserRolePermissionModel();
      $add_user_role_permission->role_id = $request->role;
      $add_user_role_permission->manage_branch = $request->manage_branch;
      if ($add_user_role_permission->manage_branch == 2) {
        $add_user_role_permission->access_head      = $request->access_head;
      } else {
        $add_user_role_permission->access_head      = null;
      }
      $add_user_role_permission->permissions = $permissionsJson;
      $add_user_role_permission->created_by = $request->user()->user_id;
      $add_user_role_permission->updated_by = $request->user()->user_id;

      $add_user_role_permission->save();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'User Role Permissions added Successfully!'
      ]);
    } catch (\Exception $e) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the User Role Permissions! ' . $e->getMessage()
      ]);
    }

    return redirect()->route('users-manage-users-list');
  }


  public function Edit($id)
  {
    $role = UserRolePermissionModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }

  public function update(Request $request, $id)
  {
    $validator = Validator::make($request->all(), [
      'role' => 'required|integer',
      'permissions' => 'required',
      'permissions.*.menu' => 'required|string',
      'permissions.*.submenu' => 'nullable',
      'permissions.*.submenu.*.name' => 'nullable|string',
      'permissions.*.submenu.*.actions' => 'nullable',
      'permissions.*.submenu.*.actions.*' => 'nullable|string',
      'permissions.*.actions' => 'nullable',
      'permissions.*.actions.*' => 'nullable|string',
    ]);

    if ($validator->fails()) {
      $errors = $validator->errors()->all();
      $firstError = $validator->errors()->first();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => $firstError . ' | Detailed errors: ' . implode(', ', $errors)
      ]);
    }

    $rolePermission = UserRolePermissionModel::where('sno', $id)->first();
    try {
      $permissionsJson = json_encode($request->permissions);
      if (json_last_error() !== JSON_ERROR_NONE) {
      }


      $rolePermission->role_id          = $request->role;
      $rolePermission->manage_branch    = $request->manage_branch;
      if ($rolePermission->manage_branch == 2) {
        $rolePermission->access_head      = $request->access_head;
      } else {
        $rolePermission->access_head      = null;
      }

      $rolePermission->permissions      = $permissionsJson;
      $rolePermission->updated_by       = $request->user()->user_id;
      $rolePermission->update();


      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'User Role Permissions Updated Successfully!'
      ]);
    } catch (\Exception $e) {

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Updated the User Role Permissions!'
      ]);
    }

    return redirect()->route('users-manage-users-list');
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRolePermissionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRolePermissionModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->status;
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  


// public function role_based_staff_details($id, Request $request)
//   {

//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

//     // Check if decryption failed
//     if ($decryptedValue === false) {
//       return response()->json([
//         'status' => 400,
//         'message' => 'Invalid Entry',
//       ]);
//     }

//     $id = $decryptedValue;

//     $userpermission = UserRolePermissionModel::query()
//     ->from('za_user_role_permission')
//     ->where('za_user_role_permission.status', '!=', 2)
//     ->where('za_user_role_permission.sno', $id)
//     ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
//     ->join('za_staff', 'za_staff.role_id', '=', 'za_user_role.sno')
//     ->select([
//         'za_user_role_permission.sno',
//         'za_user_role.sno as role_id',
//         'za_user_role.role_name',
//         'za_user_role_permission.status as permission_status',

//         // Staff count
//         \DB::raw('COUNT(DISTINCT za_staff.sno) AS staff_count'),

//         // Role active if ANY staff active
//         \DB::raw('COALESCE(MAX(CASE WHEN za_staff.status = 0 THEN 1 ELSE 0 END), 0) AS role_status'),
//     ])
//     ->groupBy(
//         'za_user_role_permission.sno',
//         'za_user_role.sno',
//         'za_user_role.role_name',
//         'za_user_role_permission.status'
//     )
//     ->first();

//     $current_date = date('Y-m-d');

//     if ($userpermission) {

//       $userpermission_role_id = isset($userpermission->role_id) && !empty($userpermission->role_id) ? $userpermission->role_id : null;

//       $staffList = \DB::table('za_staff')
//         ->where('za_staff.role_id', $userpermission_role_id)
//         // ->where('status', 0) // optional: ignore deleted staff
//         ->select('za_staff.*')
//         ->orderBy('za_staff.staff_name')
//         ->get();
        
//         $image_path = 'staff_images/';

//         $requirements_staff_details = [];

//         foreach ($staffList as $staff) {

//           $image_full_path = $image_path && isset($staff->staff_image) ? $image_path . $staff->staff_image : null;

//           $staff_staff_status = isset($staff->status) ? (int) $staff->status : null;

//           $userData = \DB::table('users')->where('user_id', ($staff->sno ?? null))->first(['branch_id']);
          
//           $users_branch_id = isset($userData->branch_id) && !empty($userData->branch_id) ? $helper->branch_franchise($userData->branch_id) : (isset($staff->branch_id) && !empty($staff->branch_id) ? $helper->branch_franchise($staff->branch_id) : null);

//           $staff_status_html = null;

//           if ($staff_staff_status !== null) {
//             switch ($staff_staff_status) {
//               case 0:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-success text-success">Active</div>';
//                 break;
//               case 2:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-blue text-blue">Inactive</div>';
//                 break;
//               case 1:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-blue text-blue">Inactive</div>';
//                 break;

//               case 4:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-warning text-warning">NOTICE<br>PERIOD</div>';
//                 break;

//               case 5:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-info text-info">Relieved</div>';
//                 break;

//               case 6:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-secondary text-secondary">Abscond</div>';
//                 break;

//               case 7:
//                 $staff_status_html = '<div class="staff_status_badge badge bg-label-danger text-danger">Terminated</div>';
//                 break;
//             }
//           }

//           $staff_staff_backgrounds = '';
//           $staff_staff_bg_color = '';
//           $staff_staff_bg_text_color = '';

//           if(!$image_full_path || !file_exists(public_path($image_full_path))){
//             $staff_staff_backgrounds = isset($staff->sno) ? $this->generateAvatarColors($staff->sno) : null;
//             $staff_staff_bg_color = isset($staff_staff_backgrounds['bg']) ? $staff_staff_backgrounds['bg'] : null;
//             $staff_staff_bg_text_color = isset($staff_staff_backgrounds['text']) ? $staff_staff_backgrounds['text'] : null;
//           }

//           $requirements_staff_details[] = [
//             'staff_sno' => $staff->sno ?? null,
//             'staff_name' => $staff->staff_name ?? null,
//             'staff_mobile_no' => $staff->mobile_no ?? null,
//             'staff_email_id' => $staff->email_id ?? null,
//             'staff_image' => $staff->staff_image ?? null,
//             'staff_image_path' => $image_full_path,
//             'users_branch_name' => $users_branch_id,
//             'staff_img_html' => $image_full_path && file_exists(public_path($image_full_path))
//               ? '<div class="image-input image-input-circle me-1" data-kt-image-input="true">
//                   <img src="' . asset($image_full_path) . '" alt="avatar" class="rounded-circle image-input-wrapper w-150px h-150px"/>
//                 </div>'
//               : '<div class="avatar  me-2">
//                   <span class="avatar-initial rounded-circle" style="background-color:'.$staff_staff_bg_color.' !important;color:'.$staff_staff_bg_text_color.' !important">'.(isset($staff->staff_name) && !empty($staff->staff_name) ? strtoupper(substr(($staff->staff_name ?? 'UN'), 0, 1)) : 'UN').'</span>
//                 </div>',
//             'staff_status_html' => $staff_status_html ?? $staff_staff_status,
//             'staff_staff_backgrounds' => $staff_staff_backgrounds ?? null,
//           ];
//         }

//       $userpermission->staff_details = $requirements_staff_details;

//       return response()->json([
//         'status' => 200,
//         'data' => $userpermission,
//       ]);
//     } else {
//       return response()->json([
//         'status' => 404,
//         'message' => 'Corporate & Campus not found',
//       ]);
//     }
//   }

public function role_based_staff_details($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return response()->json([
        'status' => 400,
        'message' => 'Invalid Entry',
      ]);
    }

    $id = $decryptedValue;

    $userpermission = UserRolePermissionModel::query()
    ->from('za_user_role_permission')
    ->join('za_user_role', 'za_user_role_permission.role_id', '=', 'za_user_role.sno')
    ->join('za_staff', 'za_staff.role_id', '=', 'za_user_role.sno')
    ->join('za_branch', 'za_staff.branch_id', '=', 'za_branch.sno')
    ->where('za_user_role_permission.status', '!=', 2)
    ->where('za_user_role_permission.sno', $id)
    ->where('za_branch.status', 0)
    ->select([
        'za_user_role_permission.sno',
        'za_user_role.sno as role_id',
        'za_user_role.role_name',
        'za_user_role_permission.status as permission_status',

        // Staff count
        \DB::raw('COUNT(DISTINCT za_staff.sno) AS staff_count'),

        // Role active if ANY staff active
        \DB::raw('COALESCE(MAX(CASE WHEN za_staff.status = 0 THEN 1 ELSE 0 END), 0) AS role_status'),
    ])
    ->groupBy(
        'za_user_role_permission.sno',
        'za_user_role.sno',
        'za_user_role.role_name',
        'za_user_role_permission.status'
    )
    ->first();

    $current_date = date('Y-m-d');

    if ($userpermission) {

      $userpermission_role_id = isset($userpermission->role_id) && !empty($userpermission->role_id) ? $userpermission->role_id : null;

      $staffList = \DB::table('za_staff')
        ->where('za_staff.role_id', $userpermission_role_id)
        ->join('za_branch', 'za_staff.branch_id', '=', 'za_branch.sno')
        // ->where('status', 0) // optional: ignore deleted staff
        ->select('za_staff.*')
        ->where('za_branch.status', 0)
        ->orderBy('za_staff.staff_name')
        ->get();
        
        $image_path = 'staff_images/';

        $requirements_staff_details = [];

        foreach ($staffList as $staff) {

          $image_full_path = $image_path && isset($staff->staff_image) ? $image_path . $staff->staff_image : null;

          $staff_staff_status = isset($staff->status) ? (int) $staff->status : null;

          $userData = \DB::table('users')
          ->join('za_branch', 'users.branch_id', '=', 'za_branch.sno')
          ->where('users.user_id', $staff->sno ?? null)
          ->where('za_branch.status', 0)
          ->first(['users.branch_id']);
          
          $users_branch_id = isset($userData->branch_id) && !empty($userData->branch_id) ? $helper->branch_franchise($userData->branch_id) : (isset($staff->branch_id) && !empty($staff->branch_id) ? $helper->branch_franchise($staff->branch_id) : null);

          $staff_status_html = null;

          if ($staff_staff_status !== null) {
            switch ($staff_staff_status) {
              case 0:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-success text-success">Active</div>';
                break;
              case 2:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-blue text-blue">Inactive</div>';
                break;
              case 1:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-blue text-blue">Inactive</div>';
                break;

              case 4:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-warning text-warning">NOTICE<br>PERIOD</div>';
                break;

              case 5:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-info text-info">Relieved</div>';
                break;

              case 6:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-secondary text-secondary">Abscond</div>';
                break;

              case 7:
                $staff_status_html = '<div class="staff_status_badge badge bg-label-danger text-danger">Terminated</div>';
                break;
            }
          }

          $staff_staff_backgrounds = '';
          $staff_staff_bg_color = '';
          $staff_staff_bg_text_color = '';

          if(!$image_full_path || !file_exists(public_path($image_full_path))){
            $staff_staff_backgrounds = isset($staff->sno) ? $this->generateAvatarColors($staff->sno) : null;
            $staff_staff_bg_color = isset($staff_staff_backgrounds['bg']) ? $staff_staff_backgrounds['bg'] : null;
            $staff_staff_bg_text_color = isset($staff_staff_backgrounds['text']) ? $staff_staff_backgrounds['text'] : null;
          }

          $requirements_staff_details[] = [
            'staff_sno' => $staff->sno ?? null,
            'staff_name' => $staff->staff_name ?? null,
            'staff_mobile_no' => $staff->mobile_no ?? null,
            'staff_email_id' => $staff->email_id ?? null,
            'staff_image' => $staff->staff_image ?? null,
            'staff_image_path' => $image_full_path,
            'users_branch_name' => $users_branch_id,
            'staff_img_html' => $image_full_path && file_exists(public_path($image_full_path))
              ? '<div class="image-input image-input-circle me-1" data-kt-image-input="true">
                  <img src="' . asset($image_full_path) . '" alt="avatar" class="rounded-circle image-input-wrapper w-150px h-150px"/>
                </div>'
              : '<div class="avatar  me-2">
                  <span class="avatar-initial rounded-circle" style="background-color:'.$staff_staff_bg_color.' !important;color:'.$staff_staff_bg_text_color.' !important">'.(isset($staff->staff_name) && !empty($staff->staff_name) ? strtoupper(substr(($staff->staff_name ?? 'UN'), 0, 1)) : 'UN').'</span>
                </div>',
            'staff_status_html' => $staff_status_html ?? $staff_staff_status,
            'staff_staff_backgrounds' => $staff_staff_backgrounds ?? null,
          ];
        }

      $userpermission->staff_details = $requirements_staff_details;

      return response()->json([
        'status' => 200,
        'data' => $userpermission,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Corporate & Campus not found',
      ]);
    }
  }
 
  private function generateAvatarColors(int $id = 0): array
  {
    $palette = [
      ['bg' => '#B7DEFA', 'text' => '#0D47A1'], // blue
      ['bg' => '#F8DCB0', 'text' => '#E65100'], // orange
      ['bg' => '#C4FAC9', 'text' => '#1B5E20'], // green
      ['bg' => '#F7CDFD', 'text' => '#4A148C'], // purple
      ['bg' => '#C9FAF7', 'text' => '#004D40'], // teal
      ['bg' => '#FFB5AD', 'text' => '#BF360C'], // red
      ['bg' => '#FCC8D9', 'text' => '#880E4F'], // pink
      ['bg' => '#B0D9F5', 'text' => '#263238'], // steel
      ['bg' => '#FFF1B6', 'text' => '#F57F17'], // yellow
      ['bg' => '#D1C4E9', 'text' => '#311B92'], // indigo
      ['bg' => '#B2EBF2', 'text' => '#006064'], // cyan
      ['bg' => '#DCEDC8', 'text' => '#33691E'], // lime
    ];
 
    return $palette[$id % count($palette)];
  }
  
}