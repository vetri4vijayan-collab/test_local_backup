<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Http\Controllers\user_management\ManageUsers;
use App\Http\Controllers\user_management\UserRole;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Services\DoubletickService;
use App\Mail\EAPLMail;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use App\Models\AppointmentModel;
use App\Models\Batch_staff_swap_Model;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\Schedule_message_model;
use App\Models\Communication_config_Model;
use App\Models\PaymentModel;
use App\Models\AttendanceModel;
use App\Models\WebsiteleadModel;
use App\Models\DropRefundModel;
use App\Models\SlotModel;
use App\Models\TransactionModel;
use App\Models\ManageCoursesModel;
use App\Models\IpConfigModel;
use App\Models\IssueNoteModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffAttendanceTodayModel;
use App\Models\StaffModel;
use App\Models\StaffRescheduleModel;
use App\Models\SyllabusUpdateModel;
use App\Models\GoalSetTeamModel;
use App\Models\GoalSetStaffModel;
use App\Models\TrainingModel;
use App\Models\GeneralSettingsModel;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Http;
class Login extends Controller
{
  public function index(Request $request)
  {

    $ipAddress = $request->ip();
    return view('content.dashboard.login', compact('ipAddress'));
    // return view('content.dashboard.login');
  }
  public function get_staff()
  {
    return view('content.dashboard.get_staff');
  }
  public function forgot_password()
  {
    return view('content.dashboard.forgot_password');
  }
  public function new_password()
  {
    return view('content.dashboard.new_password');
  }
  
  public function downloadLoginReport()
{
    $today = Carbon::today();

    // Fetch users who logged in today (via token)
    $userIds = DB::table('personal_access_tokens')
        ->whereDate('created_at', $today)
        ->distinct()
        ->pluck('tokenable_id');

    $users = DB::table('users')
        ->whereIn('id', $userIds)
        ->get(['id', 'name', 'email']);

    // Prepare content
    $content = "Logged In Users - " . now()->format('d-m-Y') . "\n\n";
    foreach ($users as $user) {
        $content .= "ID: {$user->id} | Name: {$user->name} | Email: {$user->email}\n";
    }

    // Download as .txt file
    return Response::make($content, 200, [
        'Content-Type' => 'text/plain',
        'Content-Disposition' => 'attachment; filename="login_users_' . now()->format('Ymd') . '.txt"',
    ]);
}
  public function updateProfile(Request $request)
  {
    $user = Auth::user(); // Get authenticated user

    // Validate request
    $request->validate([
      'staff_password' => 'nullable|min:6', // Password is optional, must be at least 6 characters if provided
      'staff_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Image validation
    ]);

    // Update password in user table if provided
    if ($request->filled('staff_password')) {
      $user->password = Hash::make($request->staff_password); // Hash and update password
      $user->save();
    }

    // Update password in staff table if exists
    $staff = $user->staff;
    if ($staff) {
      if ($request->filled('staff_password')) {
        $staff->password = $request->staff_password; // Hash and update password
      }

      // Handle profile image upload
      if ($request->hasFile('staff_image')) {
        $image = $request->file('staff_image');
        $staff_imageName = 'staff_' . $staff->sno . '.' . $image->extension();
        $image->move(public_path('staff_images'), $staff_imageName);
        $staff->staff_image = $staff_imageName;
      }

      $staff->save(); // Save staff record after updating password and/or image
    }

    return back()->with('success', 'Profile updated successfully.');
  }
  public function dashboards(Request $request)
  {
    // Initialize variables
    $branch_common = null;
    $role_user = null;
    $role_permission = null;
    $user = Auth::user();
    
    // if($user->user_id != 55){
    //     return view('content.working_on_progress');
    // }
    if ($user) {
      $branch_common   = BranchModel::where('sno', $user->branch_id)->first();
      $role_user       = UserRoleModel::where('sno', $user->role_id)->first();
      $role_permission = UserRolePermissionModel::where('role_id', $user->role_id)->first();
    }
    $user_details_dashboard = StaffModel::where('sno', $user->user_id)->first();
    // return $user->role_id;
    // 22 Faculty
    if ($user->role_id == 22) {

      $staffId  = $user->user_id;
      $branchId = $user->branch_id;
      $currentMonth = date('m');
      $currentYear = date('Y');

      // Get the total present days (attendance = 'P')

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      $presentDaysCOUNT = StaffAttendanceModel::where('staff_id', $staffId)
        ->where('branch_id', $branchId)
        ->where('attendance', 'P')
        ->whereMonth('date', $currentMonth)
        ->whereYear('date', $currentYear)
        ->count();

      $presentDays =  $dayCount > 0 ? ($presentDaysCOUNT / $dayCount) * 100 : 0;
      //   return $presentDays;
      $user_details_dashboard = StaffModel::where('za_staff.sno', $user->user_id)
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->select('za_job_position.job_position_name', 'za_staff.*')
        ->first();
      // dd($user_details_dashboard);

      $total_completed_batch = BatchModel::where('za_batch.staff_id', $user->user_id)
        ->where('za_batch.status', 3)->count();

      $total_completed_students = TrainingModel::leftJoin('za_batch', 'za_batch.sno', '=', 'za_training.batch_id')
        ->where('za_batch.staff_id', $user->user_id)
        ->where('za_training.status', 0)
        ->where('za_batch.status', 3)
        ->count();



      $daysMap = [
        'Monday' => 1,
        'Tuesday' => 2,
        'Wednesday' => 3,
        'Thursday' => 4,
        'Friday' => 5,
        'Saturday' => 6,
        'Sunday' => 0,
      ];

      // Get the current day name
      $currentDay = date('l'); // e.g., "Monday"

      // Map to custom order
      $currentDayNumber = $daysMap[$currentDay];

      // Today's schedule
      $user_batch = BatchModel::select("za_batch.*", "za_course.course_name", "za_slot.start_time", "za_slot.end_time", "za_slot.slot_type_days")
        ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.staff_id', $user->user_id)
        ->where('za_batch.status', 0)
        ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
        ->orderBy('za_slot.start_time')
        ->orderBy('za_slot.end_time')
        ->get();
      // return  $user_batch;

      // Find the next upcoming class (not started yet)
      $next_upcoming_class = BatchModel::select("za_batch.*", "za_course.course_name", "za_course.thumbnail", "za_slot.start_time", "za_slot.end_time", "za_slot.slot_type_days")
        ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.staff_id', $user->user_id)
        ->where('za_batch.status', 0)
        ->where('za_slot.start_time', '>', now())
        ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
        ->orderBy('za_slot.start_time')
        ->first();

      $user_batch_attendence = BatchModel::select(
        'za_batch.batch_name',
        'za_batch.sno',
        'za_batch.branch_id',
        'za_batch.batch_id',
        DB::raw("COUNT(CASE WHEN za_attendance.attendance = 'P' THEN 1 END) as present_count"),
        DB::raw("COUNT(CASE WHEN za_attendance.attendance = 'A' THEN 1 END) as absent_count"),
        DB::raw("COUNT(CASE WHEN za_attendance.attendance = 'L' THEN 1 END) as leave_count"),
        DB::raw('(
              SELECT COUNT(DISTINCT za_training.customer_id)
              FROM za_training 
              WHERE za_training.batch_id = za_batch.sno 
              AND za_training.branch_id = za_batch.branch_id 
              AND za_training.status = 0 
          ) as total_customer_present_in_batch_count'),
        DB::raw(
          '
              CASE 
                  WHEN (
                      SELECT COUNT(DISTINCT za_training.customer_id)
                      FROM za_training 
                      WHERE za_training.batch_id = za_batch.sno 
                      AND za_training.branch_id = za_batch.branch_id 
                      AND za_training.status = 0
                  ) > 0 
                  THEN ROUND((COUNT(CASE WHEN za_attendance.attendance = "P" THEN 1 END) / 
                              (
                                  SELECT COUNT(DISTINCT za_training.customer_id)
                                  FROM za_training 
                                  WHERE za_training.batch_id = za_batch.sno 
                                  AND za_training.branch_id = za_batch.branch_id 
                                  AND za_training.status = 0
                              )) * 100, 2)
                  ELSE 0
              END as present_percentage'
        )
      )
        ->leftJoin('za_attendance', 'za_attendance.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.staff_id', $user->user_id)
        ->where('za_attendance.customer_id', '=', DB::raw('za_training.customer_id'))
        ->where('za_batch.status', 0)
        ->whereDate('za_attendance.att_date', '=', now())
        ->groupBy(
          'za_batch.batch_name',
          'za_batch.sno',
          'za_batch.branch_id',
          'za_batch.batch_id'
        )
        ->get();

      $user_batch_course_completions = BatchModel::select(
        'za_batch.batch_name',
        'za_batch.sno as batch_sno', // Renaming for clarity
        'za_batch.branch_id',
        'za_batch.batch_id',
        'za_course.course_name',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_batch.course_id'  // Added course_id to access in the loop
      )
        ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.staff_id', $user->user_id)
        ->where('za_batch.status', 0)
        ->orderBy('za_slot.start_time')
        ->orderBy('za_slot.end_time')
        ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
        ->get();
      // return $user_batch_course_completions;

      // Loop through each batch to calculate the completed topics and course completion percentage
      foreach ($user_batch_course_completions as $batch) {
        // Get the total number of topics for the course
        $total_course_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)->count('topic_id');
        // Get the count of completed topics for the batch
        $completed_topics = SyllabusUpdateModel::where('batch_id', $batch->batch_sno)
          ->where('course_id', $batch->course_id) // Corrected to use course_id here
          ->count('topic_id');
        // return $completed_topics;  
        // Calculate the completion percentage for this batch
        $completion_percentage = $total_course_topics > 0 ? ($completed_topics / $total_course_topics) * 100 : 0;
        // Add the completion percentage to the batch data
        $batch->course_completion_percentage = round($completion_percentage, 2); // Rounded to 2 decimal places 
      }

      return view('content.dashboard.production_dashboard', compact('branch_common', 'total_completed_students', 'role_user', 'role_permission', 'user_details_dashboard', 'presentDays', 'user_batch', 'next_upcoming_class', 'user_batch_attendence', 'user_batch_course_completions', 'total_completed_batch'));
    }
    // PC 15
    else if ($user->role_id == 15) {
      $staffId  = $user->user_id;
      $branchId = $user->branch_id;
      $currentMonth = date('m');
      $currentYear = date('Y');
      $currentDate = date('Y-m-d');
      $month = date('m');
      $year = date('Y');


      // Get the total present days (attendance = 'P')

      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      $presentDays = StaffAttendanceModel::where('staff_id', $staffId)
        ->where('branch_id', $branchId)
        ->where('attendance', 'P')
        ->whereMonth('date', $currentMonth)
        ->whereYear('date', $currentYear)
        ->count();
      $presentDays =  $dayCount > 0 ? round(($presentDays / $dayCount) * 100) : 0;

      $general_details = StaffModel::select('za_staff.*', 'za_user_role.role_name')
        ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
        ->where('za_staff.sno', $user->user_id)
        ->where('za_staff.branch_id', $user->branch_id)
        ->first();

      // return $general_details;
      $currentMonthStart = Carbon::now()->startOfMonth()->toDateString();
      $currentMonthEnd = Carbon::now()->endOfMonth()->toDateString();
      $mini_batch_count_for_current_month = BatchModel::where('za_batch.branch_id', $user->branch_id)
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->where('za_training.status', 0)
        ->where('za_course.status', 0)
        ->where('za_batch.status', 0)
        ->whereMonth('za_batch.end_date', '>=', $month)
        ->whereYear('za_batch.end_date', '>=', $year)
        ->whereMonth('za_batch.start_date', '<=', $month)
        ->whereDate('za_batch.start_date', '>=', $year)
        ->select(
          'za_batch.sno',
          'za_batch.batch_name',
          'za_batch.course_id',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course.course_name',
          'za_training.batch_id',
          \DB::raw('count(za_training.customer_id) as customer_count')
        )
        ->groupBy(
          'za_batch.sno',
          'za_batch.batch_name',
          'za_batch.course_id',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course.course_name',
          'za_training.batch_id'
        )
        ->havingRaw('customer_count < ?', [3]) // Filter batches with customer_count < 3
        ->get();

      $ongoingbatch_list = DB::table('za_batch')
        ->where('branch_id', $branchId)
        ->whereMonth('end_date', '>=', $month)
        ->whereYear('end_date', '>=', $year)
        ->whereMonth('start_date', '<=', $month)
        ->whereYear('start_date', '<=', $year)
        ->where('status', 0)
        ->pluck('sno');
      $present_batches = DB::table('za_attendance as a')
        ->select('a.batch_id')
        ->whereIn('a.batch_id', $ongoingbatch_list)
        ->whereDate('a.att_date', Carbon::today())
        ->groupBy('a.batch_id')
        ->pluck('a.batch_id');
      $atten_pending_batches = DB::table('za_batch')
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
        ->where('za_training.status', 0)
        ->where('za_batch.status', 0)
        ->whereIn('za_batch.sno', $ongoingbatch_list)
        ->whereNotIn('za_batch.sno', $present_batches)
        ->select(
          'za_batch.sno',
          'za_batch.batch_name',
          'za_batch.course_id',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course.course_name',
          'za_training.batch_id',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_staff.staff_name',
          'za_staff.staff_image',
          'za_staff.gender'
        )
        ->orderBy('za_slot.start_time', 'ASC')
        ->distinct('za_batch.sno')
        ->get();

      $present_summary = DB::table('za_syllabus_update as a')
        ->select('a.batch_id')
        ->whereIn('a.batch_id', $ongoingbatch_list)
        ->whereDate('a.date', Carbon::today())
        ->groupBy('a.batch_id')
        ->pluck('a.batch_id');

      $present_summary2 = DB::table('za_batch_summary as a')
        ->select('a.batch_id')
        ->whereIn('a.batch_id', $ongoingbatch_list)
        ->whereDate('a.summary_date', Carbon::today())
        ->groupBy('a.batch_id')
        ->pluck('a.batch_id');

      $summary_pending_batches = DB::table('za_batch')
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
        ->where('za_training.status', 0)
        ->where('za_batch.status', 0)
        ->whereIn('za_batch.sno', $ongoingbatch_list)
        ->whereNotIn('za_batch.sno', $present_summary)
        ->whereNotIn('za_batch.sno', $present_summary2)
        ->select(
          'za_batch.sno',
          'za_batch.batch_name',
          'za_batch.course_id',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course.course_name',
          'za_training.batch_id',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_staff.staff_name',
          'za_staff.staff_image',
          'za_staff.gender'
        )
        ->orderBy('za_slot.start_time', 'ASC')
        ->distinct('za_batch.sno')
        ->get();

      $currentDate = Carbon::today()->toDateString();

      $attendance_count_for_today = StaffAttendanceModel::select(
        DB::raw("DATE(date) as date"),
        DB::raw("COUNT(CASE WHEN attendance = 'P' THEN 1 END) as present_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'A' THEN 1 END) as absent_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'OD' THEN 1 END) as onduty_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'Pr' THEN 1 END) as permision_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'L' THEN 1 END) as leave_count")
      )
        ->where('branch_id', $user->branch_id)
        ->whereDate('date', Carbon::today())
        ->where('status', 0)
        ->groupBy(DB::raw('DATE(date)'))
        ->first();


      $total_staff_branch = DB::table('za_staff')
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->count();

      $top_5_Production_staff = StaffModel::select(
        'za_staff.sno',
        'za_staff.branch_id',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image',
        DB::raw('COUNT(za_training.customer_id) as customer_count')
      )
        ->leftJoin('za_training', 'za_training.staff_id', '=', 'za_staff.sno')
        ->where('za_staff.branch_id', $user->branch_id)
        ->where('za_staff.status', 0)
        ->groupBy('za_staff.staff_name', 'za_staff.staff_image', 'za_staff.nick_name', 'za_staff.gender','za_staff.sno','za_staff.branch_id')
        ->orderBy('customer_count', 'desc')
        ->take(5)
        ->get();

      $currentMonthStart = Carbon::now()->startOfMonth()->toDateString();
      $currentMonthEnd = Carbon::now()->endOfMonth()->toDateString();

      $staff_attendance = StaffAttendanceModel::select(
        DB::raw("DATE(date) as date"),
        DB::raw("COUNT(CASE WHEN attendance = 'P' THEN 1 END) as present_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'A' THEN 1 END) as absent_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'OD' THEN 1 END) as onduty_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'Pr' THEN 1 END) as permision_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'L' THEN 1 END) as leave_count")
      )
        ->where('branch_id', $user->branch_id)
        ->where('status', 0)
        ->whereBetween('date', [$currentMonthStart, $currentMonthEnd]) // Filter for the current month
        ->groupBy(DB::raw('DATE(date)')) // Group by each date in the current month
        ->get();
      $branch_id = $user->branch_id;

      $staffproduction = StaffModel::select(
        'za_staff.sno',
        'za_staff.staff_id',
        'za_staff.staff_name',
        'za_staff.gender',
        'za_staff.dob',
        'za_staff.mobile_no',
        'za_staff.email_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_job_position.job_position_name',
        'za_staff.knowledge_tag',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_staff.avaiable_points',
        'za_staff.status AS staff_status'
      )
        ->where('za_staff.status', '=', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->groupBy(
          'za_staff.sno',
          'za_staff.staff_id',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.dob',
          'za_staff.mobile_no',
          'za_job_position.job_position_name',
          'za_staff.email_id',
          'za_staff.staff_image',
          'za_staff.avaiable_points',
          'za_staff.nick_name',
          'za_staff.knowledge_tag',
          'za_staff.per_hour_cost',
          'za_staff.basic_salary',
          'za_staff.status'
        )
        ->orderBy('za_staff.staff_name', 'ASC')
        ->get();

      $staffproduction = $staffproduction->unique('staff_id');
      $total_batch = 0;
      $total_student = 0;
      $total_free_batch = 0;
      $total_staff = 0;
      $overall_earned = 0;
      $overall_earned_per = 0;
      $success_staff_count = 0;


      foreach ($staffproduction as $slotType) {

        $slotType->earned_amount = 0;
        $slotType->batch_count = 0;
        $slotType->student_count = 0;
        $slotType->present_count = 0;
        $slotType->course_count = 0;
        $slotType->slotDetails = [];
        $slotType->avg_amnt = 0;
        $slotType->salary = 0;


        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
          ? $currentDate
          : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $presentDays = StaffAttendanceModel::where('staff_id', $slotType->sno)
          ->where('branch_id', $branchId)
          ->where('attendance', 'P')
          ->whereMonth('date', $currentMonth)
          ->whereYear('date', $currentYear)
          ->count();
        $presentDays =  $dayCount > 0 ? ($presentDays / $dayCount) * 100 : 0;

        $slotType->attendance_radio =  sprintf('%02d', $presentDays);

        $user_batch = BatchModel::select("za_batch.*", "za_course.course_name", "za_slot.start_time", "za_slot.end_time", "za_slot.slot_type_days")
          ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->where('za_batch.branch_id', $branch_id)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('za_batch.status', 0)
          // ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
          ->orderBy('za_slot.start_time')
          ->orderBy('za_slot.end_time')
          ->count();

        $slotType->user_batch =  sprintf('%02d', $user_batch);

        $ongoingBatch = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year)
          ->whereMonth('start_date', '<=', $month)
          ->whereDate('start_date', '>=', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 0)
          ->count();


        $slotType->ongoingBatch =  sprintf('%02d', $ongoingBatch);

        $ongoingstudent = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year)
          ->whereMonth('start_date', '<=', $month)
          ->whereDate('start_date', '>=', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 0)
          ->pluck('sno'); // Get an array of sno values

        $student_count = DB::table('za_training')
          ->whereIn('batch_id', $ongoingstudent) // Filter using batch_id
          ->distinct('customer_id') // Ensure uniqueness before counting
          ->count('customer_id');

        $slotType->ongoingstudent = sprintf('%02d', $student_count ?? 0); // Handle null case


        $completedstudent = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', $month)
          ->whereYear('end_date', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 3)
          ->pluck('sno'); // Get an array of sno values

        $student_countcompletedstudent = DB::table('za_training')
          ->whereIn('batch_id', $completedstudent) // Filter using batch_id
          ->distinct('customer_id') // Ensure uniqueness before counting
          ->count('customer_id');

        $slotType->completedstudent = sprintf('%02d', $student_countcompletedstudent ?? 0); // Handle null case



        $completedBatch = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 3)
          ->whereMonth('end_date', $month)
          ->whereYear('end_date', $year)
          ->count();
        $slotType->completedBatch =  sprintf('%02d', $completedBatch);



        $batchIds = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->distinct()
          ->pluck('batch_id')
          ->toArray();

        $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array

        $slotType->batch_ids = $batchIds; // Save batch IDs

        // return $slotType;

        foreach ($slotType->batch_ids as $batchId) {
          // Fetch the slot details for the slot type
          $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->pluck('batch_id'))
            ->where('za_batch.status', 0)
            ->get();

          // Fetch the batch details
          $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->find($batchId);

          if ($batch) {
            // Calculate the duration between start_time and end_time for the specific batch
            $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
            $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance

            $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
            $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
            // return $batchDurationInHours;
            // Get attendance records for the current batch

            $attendanceRecords = AttendanceModel::select('*')
              ->where('batch_id', $batch->sno)
              ->where('staff_id', $slotType->sno)
              ->where('attendance', 'P')
              ->whereMonth('att_date', '=', $month)
              ->whereYear('att_date', '=', $year)
              ->get();


            // Loop through the attendance records and calculate the earned amount
            foreach ($attendanceRecords as $attendance) {
              // Multiply the per_hr_cost by the batch duration (instead of slotType duration)
              $earnedAmountForAttendance = $attendance->per_hr_cost * $batchDurationInHours; // Use batch duration here
              $slotType->earned_amount += $earnedAmountForAttendance;  // Add to the total earned amount
            }
          }
        }


        // return $slotType;

        $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('customer_id')
          ->count('customer_id');

        $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('course_id')
          ->count('course_id');

        $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('batch_id')
          ->count('batch_id');


        $slotType->salary = $slotType->basic_salary * 10;

        if ($slotType->salary != 0) {
          $slotType->avg_amnt = ($slotType->earned_amount / $slotType->salary) * 100;
        } else {
          $slotType->avg_amnt = 0;  // or any other value you want in case of division by zero
        }


        $total_free_batch += 8 - $slotType->batch_count;
        $overall_earned += $slotType->earned_amount;

        $overall_earned_per += $slotType->avg_amnt;

        if ($slotType->salary < $slotType->earned_amount) {
          $success_staff_count++;  // Increment staff count who meet the condition
        }
        // return $slotType;    
      }

      // return $staffproduction;
      return view('content.dashboard.pc_dashboard', compact('branch_common', 'total_staff_branch', 'summary_pending_batches', 'staffproduction', 'atten_pending_batches', 'role_user', 'presentDays', 'role_permission',    'general_details', 'mini_batch_count_for_current_month', 'attendance_count_for_today', 'top_5_Production_staff'));
    }

    // Get sales tl self and team
    else if ($user->role_id == 12) {
      // Get the selected month from request, default to the current month
      $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name')
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where('za_staff.sno', $user->user_id)->first();
      $branch_id = $user->branch_id;
      $currentDate = Carbon::today()->toDateString(); // Get current date in YYYY-MM-DD format
      //  return $user_details_dashboard;
      [$year, $month] = explode('-', $selectedMonth);

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;
      $totalamountoriginal = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      $totalamountold = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereYear('za_old_payments.schedule_date', $year)
        ->whereMonth('za_old_payments.schedule_date', $month)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      $totalamount = $totalamountoriginal + $totalamountold;

      $collectamount = TransactionModel::where('branch_id', $branch_id)
        ->whereMonth('created_at', $month)
        ->whereYear('created_at', $year) // Added a comma after 'created_at'
        ->sum('credit');


      $outstandingAmount = $totalamount - $collectamount;

      // Daily Reports Status
      $staffcount = StaffModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $staffAttendanceDetails = StaffAttendanceModel::where('branch_id', $branch_id)->whereDate('date', $currentDate)->get();

      $studentcount = CustomerModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $stundentAttendanceDetails = AttendanceModel::where('branch_id', $branch_id)->whereDate('att_date', $currentDate)->get();

      $current_month_total_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        // ->where('status', 0)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_solved_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        ->where('status', 2)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_pending_queries = $current_month_total_queries - $current_month_solved_queries;

      $totalamountoriginaldaily = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereDate('za_payment.nextPayDate', $currentDate)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      $totalamountolddaily = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereDate('za_old_payments.schedule_date', $currentDate)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      $totalamountdaily = $totalamountoriginaldaily + $totalamountolddaily;

      $collectamountdaily = TransactionModel::where('branch_id', $branch_id)
        ->whereDate('created_at', $currentDate)
        ->sum('credit');


      // $outstandingAmount = $outstandingAmountoriginal + $outstandingAmountold;
      $outstandingAmountdaily = $totalamountdaily - $collectamountdaily;

      //top cr,cc,abv abc values

      $actualMonthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.department_id', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.internal_status', 0)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->count();


      $actualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $year)
        ->where('za_staff.department_id', 1)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereMonth('za_customer.created_at', $month)
        ->count();

      $actualConversionCountdaily = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $year)
        ->where('za_staff.department_id', 1)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereMonth('za_customer.created_at', $month)
        ->whereDate('za_customer.created_at', $currentDate)
        ->count();

      $actualConversionCountold = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $lastMonthYear)
        ->where('za_staff.department_id', 1)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereMonth('za_customer.created_at', $lastMonth)
        ->count();

      $actualdayLeadCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereDate('za_customer.created_at', $currentDate)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->where('za_staff.department_id', 1)
        ->count();

      $actualConversionRate = $actualMonthLeadCount > 0 ? ($actualConversionCount / $actualMonthLeadCount) * 100 : 0;
      $actualConversionRate = number_format($actualConversionRate, 2);


      if ($actualConversionCount > 0) {
        $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.department_id', 1)
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->get();

        $total_payment = 0;
        $total_paid_payment = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {

            $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.overall_fees');

            $total_payment += $payment;

            $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.paid_amount');

            $total_paid_payment += $paid_payment;
          }
        }

        $averageBusinessValue = 0;
        $averageCollectionValue = 0;
        // average
        $averageBusinessValue   = $actualConversionCount > 0 ? $total_payment / $actualConversionCount : 0;
        $averageCollectionValue = $actualConversionCount > 0 ? $total_paid_payment / $actualConversionCount : 0;
      }

      // Date range calculation
      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;

      // Approval Reports Status

      $batchextensionCount = DB::table('za_batch_extension')
        ->where('status', 0)
        ->where('branch_id', $branch_id)
        ->count();

      $spamleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.status', 5)->count();

      $dropcourseapproval = DB::table('za_drop_refund')
        ->where('type', 0)
        ->whereYear('bh_status_date', $year)
        ->whereMonth('bh_status_date', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 1)
        ->where('bh_status', 0)->count();

      $refundapproval = DB::table('za_drop_refund')
        ->where('za_drop_refund.type', 1)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 0)->count();

      // Lead Details


      $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $monthLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadcurrentCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadCount = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $lastMonthYear)
        ->whereMonth('registered_date', $lastMonth)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('internal_status', 0)
        ->count();

      // Calculate the percentage change
      if ($lastmonthLeadCount > 0) {
        $percentagelastlead = (($lastmonthLeadcurrentCount - $lastmonthLeadCount) / $lastmonthLeadCount) * 100;
      } else {
        $percentagelastlead = 0; // Avoid division by zero
      }

      $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->count();

      $activeLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->count();

      $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();


      $spamLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();


      $deadLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();

      //lead_appointment

      $dayAppointmentList = DB::table('za_lead_appointment')
        ->select(
          'za_lead_appointment.sno',
          'za_lead.lead_name',
          DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%d-%b-%Y') as appointment_date"),
          DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%h:%i %p') as appointment_time"),
          'za_lead_appointment.appointment_category',
          'za_lead_appointment.appointment_status',
          'za_lead.lead_gender'
        )
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)  // for self
        ->get();

      $dailyWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->where('za_lead_appointment.appointment_category', 'Walk-in')
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
        ->count();


      //   $dailyWalkinCount=0;
      //     foreach($dayAppointmentList as $appointment){
      //           $walkin_status=0;
      //         if($appointment->appointment_category == 'walk-in'){
      //           $dailyWalkinCount++;
      //           $walkin_status=1;
      //         }else{
      //           $walkin_status=0;
      //         }
      //         $appointment->walkin_status=$walkin_status;
      //     }


      $dailyFollowup = DB::table('za_appointment')->select('za_lead.lead_name', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status', 'za_appointment.progressed', 'za_lead.lead_gender')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_appointment.created_by', $user_details_dashboard->sno)
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        // ->whereDay('za_appointment.appointment_date', date('d'))
        ->get();

      $dailyFollowupCount = count($dailyFollowup);
      foreach ($dailyFollowup as $appointment) {
        if ($appointment->status == '1' && $appointment->progressed == '2') {
          $followup_status = 'Reschedule';
        } else if ($appointment->status == '4') {
          $followup_status = 'Completed';
        }
        $appointment->followup_status = $followup_status ?? "";
      }
      // Get branch details
      $branch = BranchModel::where('sno', $branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
      // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.created_by')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->select(
          'za_customer.customer_id',
          'za_payment.course_id',
          'za_customer.sno as customer_sno',
          'za_course.sno as course_sno',
          'za_customer.cus_name',
          'za_customer.cus_gender',
          'za_customer.cus_pic',
          'za_customer.cus_mobile',
          'za_customer.cus_email_id',
          'za_course.course_name',
          'za_training.training_id',
          'za_training.payment_id',
          DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
          DB::raw('SUM(za_payment.balanceFee) as total_balance_fee'),
          DB::raw('SUM(za_payment.amount) as total_amount'),
          DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
          DB::raw('DATEDIFF(za_payment.nextPayDate, CURDATE()) as days_left'), // Calculate days left
          'za_payment.payment_mode_label',
          'za_payment.nextPayDate'
        )
        ->where('za_payment.branch_id', $branch_id)
        ->where('za_lead.created_by', $user_details_dashboard->sno)
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.status', 0)
        // ->where('za_lead.created_by', $user_details_dashboard->sno)
        ->groupBy(
          'za_customer.customer_id', // Group by customer_id to ensure uniqueness
          'za_customer.sno',
          'za_course.sno',
          'za_customer.cus_name',
          'za_customer.cus_mobile',
          'za_customer.cus_pic',
          'za_customer.cus_gender',
          'za_customer.cus_email_id',
          'za_course.course_name',
          'za_training.training_id',
          'za_training.payment_id',
          'za_payment.payment_mode_label',
          'za_payment.nextPayDate',
          'za_payment.course_id'

        )
        ->orderByDesc('za_payment.sno')
        ->get();

      // Filter the results for customers with unpaid or insufficient amounts (below min_required)

      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
        return $payment->total_paid_amount < ($branch?->min_prd_cost ?? 8000);
      });

      $finalResult = collect(); // Initialize as an empty collection to prevent undefined errors

      if (!$result->isEmpty()) {
        $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          $payment = $payments->first();

          $filteredPayments = $payments->filter(function ($payment) {
            return $payment->total_paid_amount > 0;
          });

          if ($filteredPayments->isEmpty()) {
            return null;
          }

          return [
            'customer_name' => $payment->cus_name,
            'cus_pic' => $payment->cus_pic,
            'customer_sno' => $payment->customer_sno,
            'total_paid' => $payment->total_paid_amount,
            'min_required' => $branch->min_prd_cost,
            'status' => 'Pending',
            'payments' => $filteredPayments->map(function ($payment) {
              return [
                'course_name' => $payment->course_name,
                'cus_gender' => $payment->cus_gender,
                'cus_pic' => $payment->cus_pic,
                'training_id' => $payment->training_id,
                'payment_id' => $payment->customer_id,
                'cus_name' => $payment->cus_name,
                'cus_mobile' => $payment->cus_mobile,
                'amount' => $payment->total_amount,
                'paidAmount' => $payment->total_paid_amount,
                'balanceFee' => $payment->total_balance_fee,
                'gst_amount' => $payment->total_gst_amount,
                'nextPayDate' => $payment->nextPayDate,
                'days_left' => $payment->days_left, // Include days left
                'payment_mode_label' => $payment->payment_mode_label,
              ];
            })->values(),
          ];
        })->filter();
      }

      $finalResultcount = $finalResult->count();


      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $lastMonthCrn = Carbon::createFromDate($lastMonthYear, $lastMonth, 1);
      $lstMnthStartDate = $lastMonthCrn->copy()->startOfMonth();
      $lstMnthEndDate = $lastMonthCrn->copy()->endOfMonth();
      $lastMonthDayCount = $lstMnthStartDate->diffInDays($lstMnthEndDate) + 1;

      // average Appointment
      $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      $avg_appointment = $dayCount > 0 ? round($monthAppointmentCount / $dayCount) : 0;

      // Average Followup
      $monthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_appointment.created_by', $user_details_dashboard->sno)
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        ->count();

      $avg_folllowup = $dayCount > 0 ? round($monthFollowupCount / $dayCount) : 0;

      // average Walkin
      $monthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->where('za_lead_appointment.appointment_category', 'Walk-in')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      $avg_walkin = $dayCount > 0 ? round($monthWalkinCount / $dayCount) : 0;

      // Average Outgoing Call
      $monthOutgoingCallCount = DB::table('za_call_tracker')
        ->select('za_call_tracker.branch_staff_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->where('za_staff.department_id', 1)
        ->where('za_call_tracker.call_status', 0)
        ->count();

      $avg_outgoing_call = $dayCount > 0 ? round($monthOutgoingCallCount / $dayCount) : 0;


      // last average Appointment
      $lastMonthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_appointment = $lastMonthDayCount > 0 ? round($lastMonthAppointmentCount / $lastMonthDayCount) : 0;

      // last Average Followup
      $lastMonthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_appointment.created_by', $user_details_dashboard->sno)
        ->whereYear('za_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_folllowup = $lastMonthDayCount > 0 ? round($lastMonthFollowupCount / $lastMonthDayCount) : 0;

      //last average Walkin
      $lastMonthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->where('za_lead_appointment.appointment_category', 'Walk-in')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_walkin = $lastMonthDayCount > 0 ? round($lastMonthWalkinCount / $lastMonthDayCount) : 0;

      // Average Outgoing Call
      $lastMonthOutgoingCallCount = DB::table('za_call_tracker')
        ->select('za_call_tracker.branch_staff_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->whereYear('za_call_tracker.call_start_date', $lastMonthYear)
        ->whereMonth('za_call_tracker.call_start_date', $lastMonth)
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_staff.sno', $user_details_dashboard->sno)
        ->where('za_staff.department_id', 1)
        ->where('za_call_tracker.call_status', 0)
        ->count();

      $avg_last_outgoing_call = $lastMonthDayCount > 0 ? round($lastMonthOutgoingCallCount / $lastMonthDayCount) : 0;


      $presentDays = StaffAttendanceModel::where('staff_id', $user_details_dashboard->sno)
        ->where('branch_id', $branch_id)
        ->where('attendance', 'P')
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();

      $presentDays =  $dayCount > 0 ? round(($presentDays / $dayCount) * 100) : 0;

      // Fetch all lead sources
      $leadSources = DB::table('za_lead_source')->get();

      // Get total lead count for the year
      $totalLeads = DB::table('za_lead')
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('internal_status', '!=', 1)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('created_by', '>', 0)
        ->count();

      // Get lead count per source
      $leadData = DB::table('za_lead')
        ->select('za_lead_source.lead_source_name', DB::raw('COUNT(za_lead.lead_source_id) as lead_count'))
        ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.internal_status', '!=', 1)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.created_by', '>', 0)
        ->groupBy('za_lead_source.lead_source_name')
        ->get();

      // Add percentage calculation
      foreach ($leadData as $lead) {
        $lead->percentage = ($totalLeads > 0) ? round(($lead->lead_count / $totalLeads) * 100) : 0;
      }

      // Ensure $results is a collection
      $leadDatacount = count($leadData);
      $helper = new \App\Helpers\Helpers();
      $goal_progress =  $helper->getStaffGoal_progress_bar($user_details_dashboard->sno, 1, $month, $year, $user_details_dashboard->branch_id) ?? 0;

      $reports = [

        'presentDays' => str_pad((string) ($presentDays ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualdayLeadCount' => str_pad((string) ($actualdayLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualConversionCount' => $actualConversionCount,
        'actualConversionCountdaily' => $actualConversionCountdaily,
        'actualConversionCountold' => $actualConversionCountold,
        'actualConversionRate' => round($actualConversionRate),

        'monthLeadCount'     => str_pad((string) ($monthLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
        'percentagelastlead' => round($percentagelastlead),
        'activeLeadCount'    => $activeLeadCount,
        'spamLeadCount'      => $spamLeadCount,
        'deadLeadCount'      => $deadLeadCount,

        'monthLeadCountlast'     => str_pad((string) ($monthLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'activeLeadCountlast'    => str_pad((string) ($activeLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'spamLeadCountlast'      => str_pad((string) ($spamLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'deadLeadCountlast'      => str_pad((string) ($deadLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualConversionCountlast'      => str_pad((string) ($actualConversionCountold ?? '0'), 2, '0', STR_PAD_LEFT),

        'avg_appointment' => str_pad((string) ($avg_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_folllowup' => str_pad((string) ($avg_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_walkin' => str_pad((string) ($avg_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_outgoing_call' => str_pad((string) ($avg_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

        'avg_last_appointment' => str_pad((string) ($avg_last_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_folllowup' => str_pad((string) ($avg_last_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_walkin' => str_pad((string) ($avg_last_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_outgoing_call' => str_pad((string) ($avg_last_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

        'dayAppointmentList'   => $dayAppointmentList,
        'dailyWalkinCount' => str_pad((string) ($dailyWalkinCount ?? '0'), 2, '0', STR_PAD_LEFT),

        'dailyFollowup'   => $dailyFollowup,
        'dailyFollowupCount' => str_pad((string) ($dailyFollowupCount ?? '0'), 2, '0', STR_PAD_LEFT),


        'finalResult'   => $finalResult,
        'finalResultcount'   => str_pad((string) ($finalResultcount ?? '0'), 2, '0', STR_PAD_LEFT),

        'leadData'   => $leadData,
        'goalset_ratio'   => $goal_progress,
        'leadDatacount' => str_pad((string) ($leadDatacount ?? '0'), 2, '0', STR_PAD_LEFT),
      ];




      // Check if it's an AJAX request
      if ($request->ajax()) {
        return response()->json([
          'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
          'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
          'reports' => $reports
        ]);
      }
      
       $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $user_details_dashboard->department_id)->where('za_goal_set_staff.branch_id', $branch_id)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->get();

      $goalsetData = [];

      foreach ($goalsetRecords as $goal) {
          $goalsetData[$user_details_dashboard->sno] = $goal;
      }

      $goalsetData = $goalsetData[$user_details_dashboard->sno] ?? null;

      if(isset($goalsetData[$user_details_dashboard->sno]->goal_completed)){     
          if($goalsetData[$user_details_dashboard->sno]->goal_completed == 1){
              $customerConvertCount = $goalsetData[$user_details_dashboard->sno]->conversion_actual ?? 0;
              $convertion_rate = $goalsetData[$user_details_dashboard->sno]->CR_actual ?? 0;
              $averageBusinessValue = $goalsetData[$user_details_dashboard->sno]->ABV_actual ?? 0;
              $averageCollectionValue = $goalsetData[$user_details_dashboard->sno]->ACV_actual ?? 0;
              $monthcall_out = $goalsetData[$user_details_dashboard->sno]->avg_call_out_actual ?? 0;
              $monthwalkincount = $goalsetData[$user_details_dashboard->sno]->no_of_walk_actual ?? 0;
              $monthFollowupCount = $goalsetData[$user_details_dashboard->sno]->no_of_followup_actual ?? 0;
              $std_count = $goalsetData[$user_details_dashboard->sno]->min_no_of_students_actual ?? 0;
              $costing_amount = $goalsetData[$user_details_dashboard->sno]->production_costing_actual ?? 0;
              $review_count = $goalsetData[$user_details_dashboard->sno]->no_of_reviews_actual ?? 0;
              $placement_count = $goalsetData[$user_details_dashboard->sno]->no_of_placements_actual ?? 0;
              $mou_count = $goalsetData[$user_details_dashboard->sno]->mou_actual ?? 0;
              $totalcosting_amount = $goalsetData[$user_details_dashboard->sno]->productions_actual ?? 0;
              $hacAmount = $goalsetData[$user_details_dashboard->sno]->hac_actual ?? 0;
              $post_sale_count = $goalsetData[$user_details_dashboard->sno]->no_of_post_sale_actual ?? 0;
              $OutstandingPayment_count = $goalsetData[$user_details_dashboard->sno]->no_of_outstanding_actual ?? 0;
              $refferal_count = $goalsetData[$user_details_dashboard->sno]->reference_sales_actual ?? 0;
          }
      }

      $goalsetRecordsLastMonth = GoalSetStaffModel::where('za_goal_set_staff.department_id', $user_details_dashboard->department_id)->where('za_goal_set_staff.branch_id', $branch_id)
      ->whereMonth('za_goal_set_staff.goal_date', $lastMonthYear)
      ->whereYear('za_goal_set_staff.goal_date', $lastMonth)
      ->get();

      $goalsetDataLastMonth = [];

      foreach ($goalsetRecords as $goal) {
          $goalsetDataLastMonth[$user_details_dashboard->sno] = $goal;
      }

      $goalsetDataLastMonth = $goalsetDataLastMonth[$user_details_dashboard->sno] ?? null;

      if(isset($goalsetDataLastMonth[$user_details_dashboard->sno]->goal_completed)){     
          if($goalsetDataLastMonth[$user_details_dashboard->sno]->goal_completed == 1){
              $customerConvertCount = $goalsetDataLastMonth[$user_details_dashboard->sno]->conversion_actual ?? 0;
              $convertion_rate = $goalsetDataLastMonth[$user_details_dashboard->sno]->CR_actual ?? 0;
              $averageBusinessValue = $goalsetDataLastMonth[$user_details_dashboard->sno]->ABV_actual ?? 0;
              $averageCollectionValue = $goalsetDataLastMonth[$user_details_dashboard->sno]->ACV_actual ?? 0;
              $monthcall_out = $goalsetDataLastMonth[$user_details_dashboard->sno]->avg_call_out_actual ?? 0;
              $monthwalkincount = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_walk_actual ?? 0;
              $monthFollowupCount = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_followup_actual ?? 0;
              $std_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->min_no_of_students_actual ?? 0;
              $costing_amount = $goalsetDataLastMonth[$user_details_dashboard->sno]->production_costing_actual ?? 0;
              $review_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_reviews_actual ?? 0;
              $placement_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_placements_actual ?? 0;
              $mou_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->mou_actual ?? 0;
              $totalcosting_amount = $goalsetDataLastMonth[$user_details_dashboard->sno]->productions_actual ?? 0;
              $hacAmount = $goalsetDataLastMonth[$user_details_dashboard->sno]->hac_actual ?? 0;
              $post_sale_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_post_sale_actual ?? 0;
              $OutstandingPayment_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_outstanding_actual ?? 0;
              $refferal_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->reference_sales_actual ?? 0;
          }
      }



      return view('content.dashboard.sales_tl_self_dashboard', compact('branch_common', 'role_user', 'role_permission', 'user_details_dashboard', 'selectedMonth', 'reports','goalsetData', 'goalsetDataLastMonth'));
    }

    // Get sales excutive and team
    else if ($user->role_id == 11 ) {
      
        // Get the selected month from request, default to the current month

      $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));

      // $selectedMonth = '2025-08';

      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.sno', $user->user_id)->first();
      $branch_id = $user->branch_id;
      $currentDate = Carbon::today()->toDateString(); // Get current date in YYYY-MM-DD format
      //  return $user_details_dashboard;
        [$year, $month] = explode('-', $selectedMonth);

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $totalamountoriginal = DB::table('za_payment')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->where('za_customer.branch_id', $branch_id)
          ->whereIn('za_customer.status',[0,6])
          ->whereYear('za_payment.nextPayDate', $year)
          ->whereMonth('za_payment.nextPayDate', $month)
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.amount');

      $totalamountold = DB::table('za_old_payments')
          ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
          ->where('za_old_customer.branch_id', $branch_id)
          ->where('za_old_customer.status', 0)
          ->whereYear('za_old_payments.schedule_date', $year)
          ->whereMonth('za_old_payments.schedule_date', $month)
          ->where('za_old_payments.branch_id', $branch_id)
          ->sum('za_old_payments.amount');

      $totalamount = $totalamountoriginal + $totalamountold;

      $collectamount = TransactionModel::where('branch_id', $branch_id)
          ->whereMonth('created_at', $month)
          ->whereYear('created_at', $year)// Added a comma after 'created_at'
          ->sum('credit');


      $outstandingAmount = $totalamount - $collectamount;

      // Daily Reports Status
      $staffcount = StaffModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $staffAttendanceDetails = StaffAttendanceModel::where('branch_id', $branch_id)->whereDate('date', $currentDate)->get();

      $studentcount = CustomerModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $stundentAttendanceDetails = AttendanceModel::where('branch_id', $branch_id)->whereDate('att_date', $currentDate)->get();

      $current_month_total_queries = IssueNoteModel::select('*')
          ->where('branch_id', $user->branch_id)
          // ->where('status', 0)
          ->whereMonth('created_at', date('m'))
          ->whereYear('created_at', date('Y'))
          ->count();

        $current_month_solved_queries = IssueNoteModel::select('*')
          ->where('branch_id', $user->branch_id)
          ->where('status', 2)
          ->whereMonth('created_at', date('m'))
          ->whereYear('created_at', date('Y'))
          ->count();

      $current_month_pending_queries = $current_month_total_queries - $current_month_solved_queries;

      $totalamountoriginaldaily = DB::table('za_payment')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->where('za_customer.branch_id', $branch_id)
          ->whereIn('za_customer.status',[0,6])
          ->whereDate('za_payment.nextPayDate', $currentDate)
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.amount');

      $totalamountolddaily = DB::table('za_old_payments')
          ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
          ->where('za_old_customer.branch_id', $branch_id)
          ->where('za_old_customer.status', 0)
          ->whereDate('za_old_payments.schedule_date', $currentDate)
          ->where('za_old_payments.branch_id', $branch_id)
          ->sum('za_old_payments.amount');

      $totalamountdaily = $totalamountoriginaldaily + $totalamountolddaily;

      $collectamountdaily = TransactionModel::where('branch_id', $branch_id)
          ->whereDate('created_at', $currentDate)
          ->sum('credit');


      // $outstandingAmount = $outstandingAmountoriginal + $outstandingAmountold;
      $outstandingAmountdaily = $totalamountdaily - $collectamountdaily;

      //top cr,cc,abv abc values

       $actualMonthLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.department_id', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status',[2,6])
          ->where('za_lead.internal_status',0)
          ->where('za_staff.sno', $user_details_dashboard->sno)
          ->where('za_lead.spam_verified',0)
          ->where('za_lead.drop_verified', 0)
          ->count();

          // return $actualMonthLeadCount;
        $promisecount = DB::table('za_sales_promise')
            ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
            ->where('za_staff.department_id', 1)
            ->where('za_sales_promise.branch_id', $branch_id)
            ->whereYear('za_sales_promise.promise_date', $year)
            ->whereMonth('za_sales_promise.promise_date', $month)
            ->where('za_sales_promise.status', 0)
            ->where('za_staff.sno', $user_details_dashboard->sno)
            ->sum('za_sales_promise.promise_count');

        $successcount = DB::table('za_sales_promise')
            ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
            ->where('za_staff.department_id', 1)
            ->where('za_sales_promise.branch_id', $branch_id)
            ->whereYear('za_sales_promise.promise_date', $year)
            ->whereMonth('za_sales_promise.promise_date', $month)
            ->where('za_sales_promise.status', 1)
            ->where('za_staff.sno', $user_details_dashboard->sno)
            ->sum('za_sales_promise.promise_count');

        // Avoid division by zero
        $totalpromisesuccess = 0;

        if ($promisecount > 0) {
            $rawScore = ($successcount / $promisecount) * 10;
            $totalpromisesuccess = round(min($rawScore, 10), 2); // cap at 10
        }

      $actualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->where('za_staff.department_id', 1)
          ->where('za_lead.created_by', $user_details_dashboard->sno)
          ->whereMonth('za_customer.created_at', $month)
          ->count();
      $OnactualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->where('za_staff.department_id', 1)
          ->where('za_lead.created_by', $user_details_dashboard->sno)
          ->whereMonth('za_customer.created_at', $month)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->count();
          
      $actualConversionCountdaily = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->where('za_staff.department_id', 1)
          ->where('za_staff.sno', $user_details_dashboard->sno)
          ->whereMonth('za_customer.created_at', $month)
          ->whereDate('za_customer.created_at', $currentDate)
          ->count();

        $actualConversionCountold = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $lastMonthYear)
          ->where('za_staff.department_id', 1)
          ->where('za_staff.sno', $user_details_dashboard->sno)
          ->whereMonth('za_customer.created_at', $lastMonth)
          ->count();

          $actualdayLeadCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
              ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
              ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
              ->where('za_customer.branch_id', $branch_id)
              ->whereDate('za_customer.created_at', $currentDate)
              ->where('za_staff.sno', $user_details_dashboard->sno)
              ->where('za_staff.department_id', 1)
              ->count();

          $actualConversionRate = $actualMonthLeadCount > 0 ? ($actualConversionCount / $actualMonthLeadCount) * 100 : 0;
          $actualConversionRate = number_format($actualConversionRate, 2);
          // return $actualConversionCount;
          $total_payment =0;
          $total_paid_payment =0;
          $averageBusinessValue =0;
          $averageCollectionValue =0;

            if ($actualConversionCount > 0) {
              $currentMonthCustomer = CustomerModel::select('za_customer.course_id','za_customer.sno')->whereIn('za_customer.status',[0,6])
                  ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                  ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
                  ->where('za_staff.department_id', 1)
                  ->where('za_customer.branch_id', $branch_id)
                  ->where('za_lead.created_by', $user_details_dashboard->sno)
                  ->whereYear('za_customer.created_at', $year)
                  ->whereMonth('za_customer.created_at', $month)
                  ->get();

              if ($currentMonthCustomer->isNotEmpty()) {
                  foreach ($currentMonthCustomer as $customer) {

                      $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                  ->where('za_training.customer_id', $customer->sno)
                                  ->sum('za_training.overall_fees');

                    $total_payment += $payment;

                    $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
                                      ->where('za_training.customer_id', $customer->sno)
                                      ->sum('za_training.paid_amount');

                    $total_paid_payment += $paid_payment;
                  }
              }

              $averageBusinessValue   = $actualConversionCount > 0 ? $total_payment / $actualConversionCount : 0;
              $averageCollectionValue = $actualConversionCount > 0 ? $total_paid_payment / $actualConversionCount : 0;
            }


            // return $averageBusinessValue;
          // Date range calculation
          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month)
                      ? $currentDate
                      : $startDate->copy()->endOfMonth();
          $dayCount = $startDate->diffInDays($endDate) + 1;

          // Approval Reports Status

          $batchextensionCount = DB::table('za_batch_extension')
          ->where('status', 0)
          ->where('branch_id', $branch_id)
          ->count();

          $spamleadapproval = DB::table('za_lead')->select('za_lead.sno')
              ->whereYear('za_lead.registered_date', $year)
              ->whereMonth('za_lead.registered_date', $month)
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.branch_id', $branch_id)
              ->where('za_lead.status', 7)->count();

          $deadleadapproval = DB::table('za_lead')->select('za_lead.sno')
                ->whereYear('za_lead.registered_date', $year)
               ->whereMonth('za_lead.registered_date', $month)
               ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.drop_verified',0)
               ->where('za_lead.status', 5)->count();

          $dropcourseapproval = DB::table('za_drop_refund')
              ->where('type', 0)
              ->whereYear('bh_status_date', $year)
              ->whereMonth('bh_status_date', $month)
              ->where('branch_id', $branch_id)
               ->where('bh_status', 1)
               ->where('bh_status', 0)->count();

          $refundapproval = DB::table('za_drop_refund')
                ->where('za_drop_refund.type', 1)
                 ->whereYear('created_at', $year)
              ->whereMonth('created_at', $month)
                 ->where('branch_id', $branch_id)
               ->where('bh_status', 0)->count();

           // Lead Details


           $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.branch_id', $branch_id)
               ->whereYear('za_lead.registered_date', $year)
              ->whereMonth('za_lead.registered_date', $month)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status',0)
              ->count();

            $monthLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.branch_id', $branch_id)
               ->whereYear('za_lead.registered_date', $lastMonthYear)
              ->whereMonth('za_lead.registered_date', $lastMonth)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status',0)
              ->count();

            $lastmonthLeadcurrentCount = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.branch_id', $branch_id)
               ->whereYear('za_lead.registered_date', $lastMonthYear)
              ->whereMonth('za_lead.registered_date', $lastMonth)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status',0)
              ->count();

           $lastmonthLeadCount = DB::table('za_lead')
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $lastMonthYear)
              ->whereMonth('registered_date', $lastMonth)
              ->whereNotIn('status', [2, 6])
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->where('internal_status', 0)
              ->count();

              // Calculate the percentage change
              if ($lastmonthLeadCount > 0) {
                  $percentagelastlead = (($lastmonthLeadcurrentCount - $lastmonthLeadCount) / $lastmonthLeadCount) * 100;
              } else {
                  $percentagelastlead = 0; // Avoid division by zero
              }

          $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_lead.branch_id', $branch_id)
              ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.status',0)
            ->where('za_lead.internal_status',0)
            ->where('za_staff.sno', $user_details_dashboard->sno)
            ->count();

            // return $activeLeadCount;

          $activeLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
            ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
              ->where('za_lead.branch_id', $branch_id)
                ->whereYear('za_lead.registered_date', $lastMonthYear)
              ->whereMonth('za_lead.registered_date', $lastMonth)
              ->where('za_lead.status',0)
              ->where('za_lead.internal_status',0)
              ->where('za_staff.sno', $user_details_dashboard->sno)
              ->count();

          $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.sno', $user_details_dashboard->sno)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.spam_verified',1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();


          $spamLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
          ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.sno', $user_details_dashboard->sno)
          ->whereYear('za_lead.registered_date', $lastMonthYear)
          ->whereMonth('za_lead.registered_date', $lastMonth)
          ->where('za_lead.spam_verified',1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();

          $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
              ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
              ->where('za_staff.sno', $user_details_dashboard->sno)
               ->whereYear('za_lead.registered_date', $year)
               ->whereMonth('za_lead.registered_date', $month)
               ->where('za_lead.branch_id', $branch_id)
               ->where('za_lead.drop_verified',1)
               ->where('za_lead.status', 5)->count();


          $deadLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
              ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
              ->where('za_staff.sno', $user_details_dashboard->sno)
               ->whereYear('za_lead.registered_date', $lastMonthYear)
               ->whereMonth('za_lead.registered_date', $lastMonth)
               ->where('za_lead.branch_id', $branch_id)
               ->where('za_lead.drop_verified',1)
               ->where('za_lead.status', 5)->count();

            //lead_appointment

            $dayAppointmentList = DB::table('za_lead_appointment')
              ->select(
                  'za_lead_appointment.sno',
                  'za_lead.lead_name',
                  DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%d-%b-%Y') as appointment_date"),
                  DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%h:%i %p') as appointment_time"),
                  'za_lead_appointment.appointment_category',
                  'za_lead_appointment.appointment_status',
                  'za_lead.lead_gender'
              )
              ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
              ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
              ->where('za_lead_appointment.status', 0)
              ->where('za_lead_appointment.appointment_status', '!=',2)
              ->whereIn('za_lead.status', [0, 4])
              ->where('za_lead_appointment.branch_id', $branch_id)
              ->whereYear('za_lead_appointment.appointment_date', $year)
              ->whereMonth('za_lead_appointment.appointment_date', $month)
              ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)  // for self
              ->get();


        //   $dailyWalkinCount=0;
        //     foreach($dayAppointmentList as $appointment){
        //       $walkin_status=0;
        //     if($appointment->appointment_category == 'walk-in'){
        //       $dailyWalkinCount++;
        //       $walkin_status=1;
        //     }else{
        //       $walkin_status=0;
        //     }
        //     $appointment->walkin_status=$walkin_status;
        //   }

            $dailyWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
              ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
              ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
              ->where('za_lead_appointment.status', 0)
              ->whereIn('za_lead.status', [0,4])
              ->where('za_lead_appointment.branch_id', $branch_id)
              ->where('za_lead_appointment.appointment_category', 'Walk-in')
              ->whereYear('za_lead_appointment.appointment_date', $year)
              ->whereMonth('za_lead_appointment.appointment_date', $month)
              ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
              ->count();

            $dailyincomWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
              ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
              ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
              ->where('za_lead_appointment.status', 0)
              ->whereIn('za_lead.status', [0,4])
              ->where('za_lead_appointment.branch_id', $branch_id)
              ->where('za_lead_appointment.appointment_category', 'Walk-in')
              ->where('za_lead_appointment.appointment_status', '!=',2)
              ->whereYear('za_lead_appointment.appointment_date', $year)
              ->whereMonth('za_lead_appointment.appointment_date', $month)
              ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
              ->count();

            // return $dailyWalkinCount;


          $dailyFollowup = DB::table('za_appointment')->select('za_lead.lead_name','za_appointment.appointment_date','za_appointment.appointment_time','za_appointment.status','za_appointment.progressed','za_lead.lead_gender')
          ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
          ->whereIn('za_lead.status', [0, 4])
          ->where('za_lead.status', [0, 4])
          ->where('za_appointment.status','!=',4)
          ->whereYear('za_appointment.appointment_date', $year)
          ->whereMonth('za_appointment.appointment_date', $month)
          // ->whereDay('za_appointment.appointment_date', date('d'))
          ->get();

          $dailyFollowupCount= count($dailyFollowup);
          foreach($dailyFollowup as $appointment){
            if($appointment->status == '1' && $appointment->progressed == '2'){
              $followup_status='Reschedule';
            }else if($appointment->status == '4'){
              $followup_status='Completed';
            }
            $appointment->followup_status=$followup_status ?? "";
          }
          // Get branch details
            $branch = BranchModel::where('sno', $branch_id)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();
            // Retrieve payments for the given branch and group by customer and course with aggregation
            $PaidUnderPayment = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.created_by')
            ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
            ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
            ->select(
              'za_customer.customer_id',
              'za_payment.course_id',
              'za_customer.sno as customer_sno',
              'za_course.sno as course_sno',
              'za_customer.cus_name',
              'za_customer.cus_gender',
              'za_customer.cus_pic',
              'za_customer.cus_mobile',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
              DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
              DB::raw('SUM(za_payment.balanceFee) as total_balance_fee'),
              DB::raw('SUM(za_payment.amount) as total_amount'),
              DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
              DB::raw('DATEDIFF(za_payment.nextPayDate, CURDATE()) as days_left'), // Calculate days left
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate'
          )
          ->where('za_payment.branch_id', $branch_id)
          ->whereYear('za_payment.nextPayDate', $year)
          ->whereMonth('za_payment.nextPayDate', $month)
          ->where('za_payment.status', 0)
           ->where('za_lead.created_by', $user_details_dashboard->sno)
          ->groupBy(
              'za_customer.customer_id', // Group by customer_id to ensure uniqueness
              'za_customer.sno',
              'za_course.sno',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_pic',
              'za_customer.cus_gender',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate',
              'za_payment.course_id'

          )
          ->orderByDesc('za_payment.sno')
          ->get();

          // Filter the results for customers with unpaid or insufficient amounts (below min_required)

          $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
              return $payment->total_paid_amount < ($branch?->min_prd_cost ?? 8000);
          });

          $finalResult = collect(); // Initialize as an empty collection to prevent undefined errors

          if (!$result->isEmpty()) {
              $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
                  $payment = $payments->first();

                  $filteredPayments = $payments->filter(function ($payment) {
                      return $payment->total_paid_amount > 0;
                  });

                  if ($filteredPayments->isEmpty()) {
                      return null;
                  }

                  return [
                      'customer_name' => $payment->cus_name,
                      'cus_pic' => $payment->cus_pic,
                      'customer_sno' => $payment->customer_sno,
                      'total_paid' => $payment->total_paid_amount,
                      'min_required' => $branch->min_prd_cost,
                      'status' => 'Pending',
                      'payments' => $filteredPayments->map(function ($payment) {
                          return [
                              'course_name' => $payment->course_name,
                              'cus_gender' => $payment->cus_gender,
                              'cus_pic' => $payment->cus_pic,
                              'training_id' => $payment->training_id,
                              'payment_id' => $payment->customer_id,
                              'cus_name' => $payment->cus_name,
                              'cus_mobile' => $payment->cus_mobile,
                              'amount' => $payment->total_amount,
                              'paidAmount' => $payment->total_paid_amount,
                              'balanceFee' => $payment->total_balance_fee,
                              'gst_amount' => $payment->total_gst_amount,
                              'nextPayDate' => $payment->nextPayDate,
                              'days_left' => $payment->days_left, // Include days left
                              'payment_mode_label' => $payment->payment_mode_label,
                          ];
                      })->values(),
                  ];
              })->filter();
          }

          $finalResultcount = $finalResult->count();


          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month)
                      ? $currentDate
                      : $startDate->copy()->endOfMonth();
          $dayCount = $startDate->diffInDays($endDate) + 1;

          // return $dayCount;

          // Get the last month's values
          $lastMonthYear = ($month == 1) ? $year - 1 : $year;
          $lastMonth = ($month == 1) ? 12 : $month - 1;

          $lastMonthCrn = Carbon::createFromDate($lastMonthYear, $lastMonth, 1);
          $lstMnthStartDate = $lastMonthCrn->copy()->startOfMonth();
          $lstMnthEndDate = $lastMonthCrn->copy()->endOfMonth();
          $lastMonthDayCount = $lstMnthStartDate->diffInDays($lstMnthEndDate) + 1;

          // average Appointment
          $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
            ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->where('za_lead_appointment.status', 0)
            ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                  ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->count();

          $avg_appointment = $dayCount > 0 ? round($monthAppointmentCount / $dayCount) : 0;

          // Average Followup
          $monthFollowupCount = DB::table('za_appointment')
            ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
            ->whereIn('za_lead.status', [0, 4])
            ->where('za_appointment.created_by', $user_details_dashboard->sno)
            ->whereYear('za_appointment.appointment_date', $year)
            ->whereMonth('za_appointment.appointment_date', $month)
            ->count();

          $avg_folllowup = $dayCount > 0 ? round($monthFollowupCount / $dayCount) : 0;

          // average Walkin
          $monthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.status', 0)
                ->where('za_lead_appointment.appointment_category', 'Walk-in')
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                  ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
                ->whereYear('za_lead_appointment.appointment_date', $year)
                ->whereMonth('za_lead_appointment.appointment_date', $month)
                ->count();

            // return $monthWalkinCount;

          $avg_walkin = $dayCount > 0 ? round($monthWalkinCount / $dayCount) : 0;

          // Average Outgoing Call
          $monthOutgoingCallCount = DB::table('za_call_tracker')
                    ->select('za_call_tracker.branch_staff_id',
                    DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"))
                    ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
                    ->whereYear('za_call_tracker.call_start_date', $year)
                    ->whereMonth('za_call_tracker.call_start_date', $month)
                    ->where('za_staff.branch_id', $branch_id)
                    ->where('za_staff.sno', $user_details_dashboard->sno)
                    ->where('za_staff.department_id', 1)
                    ->where('za_call_tracker.call_status',0)
                    ->count();

            // return $monthOutgoingCallCount;

          $avg_outgoing_call = $dayCount > 0 ? round($monthOutgoingCallCount / $dayCount) : 0;

          // return $avg_outgoing_call;
          // last average Appointment
          $lastMonthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
              ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
              ->where('za_lead_appointment.status', 0)
              ->whereIn('za_lead.status', [0,4])
              ->where('za_lead_appointment.branch_id', $branch_id)
                ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
              ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
              ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
              ->count();

           $avg_last_appointment = $lastMonthDayCount > 0 ? round($lastMonthAppointmentCount / $lastMonthDayCount) : 0;

          // last Average Followup
          $lastMonthFollowupCount = DB::table('za_appointment')
              ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
              ->whereIn('za_lead.status', [0, 4])
              ->where('za_appointment.created_by', $user_details_dashboard->sno)
              ->whereYear('za_appointment.appointment_date', $lastMonthYear)
              ->whereMonth('za_appointment.appointment_date', $lastMonth)
              ->count();

          $avg_last_folllowup = $lastMonthDayCount > 0 ? round($lastMonthFollowupCount / $lastMonthDayCount) : 0;

            //last average Walkin
            $lastMonthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
                ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
                ->where('za_lead_appointment.status', 0)
                ->where('za_lead_appointment.appointment_category', 'Walk-in')
                ->whereIn('za_lead.status', [0,4])
                ->where('za_lead_appointment.branch_id', $branch_id)
                  ->where('za_lead_appointment.staff_id', $user_details_dashboard->sno)
                ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
                ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
                ->count();

                // return $lastMonthWalkinCount;
            $avg_last_walkin = $lastMonthDayCount > 0 ? round($lastMonthWalkinCount / $lastMonthDayCount) : 0;

            // Average Outgoing Call
            $lastMonthOutgoingCallCount = DB::table('za_call_tracker')
                    ->select('za_call_tracker.branch_staff_id')
                    ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
                    ->whereYear('za_call_tracker.call_start_date', $lastMonthYear)
                    ->whereMonth('za_call_tracker.call_start_date', $lastMonth)
                    ->where('za_staff.branch_id', $branch_id)
                    ->where('za_staff.sno', $user_details_dashboard->sno)
                    ->where('za_staff.department_id', 1)
                    ->where('za_call_tracker.call_status',0)
                    ->count();

          $avg_last_outgoing_call = $lastMonthDayCount > 0 ? round($lastMonthOutgoingCallCount / $lastMonthDayCount) : 0;


          $presentDays = StaffAttendanceModel::where('staff_id', $user_details_dashboard->sno)
                ->where('branch_id', $branch_id)
                ->where('attendance', 'P')
                ->whereMonth('date', $month)
                ->whereYear('date', $year)
                ->count();

          $presentDays =  $dayCount > 0 ? round(($presentDays/$dayCount)*100):0;

          // Fetch all lead sources
          $leadSources = DB::table('za_lead_source')->get();

          // Get total lead count for the year
          $totalLeads = DB::table('za_lead')
              ->whereYear('registered_date', $year)
               ->whereMonth('registered_date', $month)
              ->where('internal_status', '!=', 1)
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->where('created_by', '>', 0)
              ->count();

          // Get lead count per source
          $leadData = DB::table('za_lead')
              ->select('za_lead_source.lead_source_name', DB::raw('COUNT(za_lead.lead_source_id) as lead_count'))
              ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
              ->whereYear('za_lead.registered_date', $year)
                ->whereMonth('za_lead.registered_date', $month)
              ->where('za_lead.internal_status', '!=', 1)
              ->where('za_lead.spam_verified', 0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.created_by', '>', 0)
              ->groupBy('za_lead_source.lead_source_name')
              ->get();

          // Add percentage calculation
          foreach ($leadData as $lead) {
              $lead->percentage = ($totalLeads > 0) ? round(($lead->lead_count / $totalLeads) * 100) : 0;
          }

          // Ensure $results is a collection
          $leadDatacount = count($leadData);

          $helper = new \App\Helpers\Helpers();
          $goal_progress =  $helper->getStaffGoal_progress_bar($user_details_dashboard->sno, 1, $month, $year, $user_details_dashboard->branch_id) ?? 0;

          $reports = [
              'totalpromisesuccess' =>str_pad((string) ($totalpromisesuccess ?? '0'), 2, '0', STR_PAD_LEFT),
                'goalset_ratio'   => $goal_progress,
              'presentDays' => str_pad((string) ($presentDays ?? '0'), 2, '0', STR_PAD_LEFT),
              'actualdayLeadCount' => str_pad((string) ($actualdayLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
              'actualConversionCount' => $actualConversionCount,
              'actualConversionCountdaily' => $actualConversionCountdaily,
              'OnactualConversionCount' => $OnactualConversionCount,
              'actualConversionCountold' => $actualConversionCountold,
              'actualConversionRate' => round($actualConversionRate),
              'averageBusinessValue' => $averageBusinessValue,
              'averageCollectionValue' => $averageCollectionValue,
              'monthLeadCount'     => str_pad((string) ($monthLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
              'percentagelastlead' => round($percentagelastlead),
              'activeLeadCount'    => $activeLeadCount,
              'spamLeadCount'      => $spamLeadCount,
              'deadLeadCount'      => $deadLeadCount,

              'monthLeadCountlast'     => str_pad((string) ($monthLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
              'activeLeadCountlast'    => str_pad((string) ($activeLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
              'spamLeadCountlast'      => str_pad((string) ($spamLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
              'deadLeadCountlast'      => str_pad((string) ($deadLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
              'actualConversionCountlast'      => str_pad((string) ($actualConversionCountold ?? '0'), 2, '0', STR_PAD_LEFT),
                
              'avg_appointment' => str_pad((string) ($avg_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_folllowup' => str_pad((string) ($avg_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_walkin' => str_pad((string) ($avg_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_outgoing_call' => str_pad((string) ($avg_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

              'avg_last_appointment' => str_pad((string) ($avg_last_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_last_folllowup' => str_pad((string) ($avg_last_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_last_walkin' => str_pad((string) ($avg_last_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
              'avg_last_outgoing_call' => str_pad((string) ($avg_last_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

              'dayAppointmentList'   => $dayAppointmentList,
              'dailyWalkinCount' => str_pad((string) ($dailyWalkinCount ?? '0'), 2, '0', STR_PAD_LEFT),
              'dailyincomWalkinCount' => str_pad((string) ($dailyincomWalkinCount ?? '0'), 2, '0', STR_PAD_LEFT),
              'lastMonthWalkinCount' => $lastMonthWalkinCount,
              'dailyFollowup'   => $dailyFollowup,
              'dailyFollowupCount' => str_pad((string) ($dailyFollowupCount ?? '0'), 2, '0', STR_PAD_LEFT),


              'finalResult'   => $finalResult,
              'finalResultcount'   => str_pad((string) ($finalResultcount ?? '0'), 2, '0', STR_PAD_LEFT),

              'leadData'   => $leadData,
              'leadDatacount' => str_pad((string) ($leadDatacount ?? '0'), 2, '0', STR_PAD_LEFT),
          ];




                  // Get goal records for the selected department and month
        $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $user_details_dashboard->department_id)->where('za_goal_set_staff.branch_id', $branch_id)
        ->whereMonth('za_goal_set_staff.goal_date', $month)->where('za_goal_set_staff.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_goal_set_staff.goal_date', $year)
        ->get();
        // return $goalsetRecords;
        // Convert goalsetRecords to an associative array for easy lookup
        $goalsetData = [];
        foreach ($goalsetRecords as $goal) {
            $goalsetData[$user_details_dashboard->sno] = $goal;
        }

        // Extract single user's goal data (flattened)
        $goalsetData = $goalsetData[$user_details_dashboard->sno] ?? null;

        if(isset($goalsetData[$user_details_dashboard->sno]->goal_completed)){
            if($goalsetData[$user_details_dashboard->sno]->goal_completed == 1){
                $customerConvertCount = $goalsetData[$user_details_dashboard->sno]->conversion_actual ?? 0;
                $convertion_rate = $goalsetData[$user_details_dashboard->sno]->CR_actual ?? 0;
                $averageBusinessValue = $goalsetData[$user_details_dashboard->sno]->ABV_actual ?? 0;
                $averageCollectionValue = $goalsetData[$user_details_dashboard->sno]->ACV_actual ?? 0;
                $monthcall_out = $goalsetData[$user_details_dashboard->sno]->avg_call_out_actual ?? 0;
                $monthwalkincount = $goalsetData[$user_details_dashboard->sno]->no_of_walk_actual ?? 0;
                $monthFollowupCount = $goalsetData[$user_details_dashboard->sno]->no_of_followup_actual ?? 0;
                $std_count = $goalsetData[$user_details_dashboard->sno]->min_no_of_students_actual ?? 0;
                $costing_amount = $goalsetData[$user_details_dashboard->sno]->production_costing_actual ?? 0;
                $review_count = $goalsetData[$user_details_dashboard->sno]->no_of_reviews_actual ?? 0;
                $placement_count = $goalsetData[$user_details_dashboard->sno]->no_of_placements_actual ?? 0;
                $mou_count = $goalsetData[$user_details_dashboard->sno]->mou_actual ?? 0;
                $totalcosting_amount = $goalsetData[$user_details_dashboard->sno]->productions_actual ?? 0;
                $hacAmount = $goalsetData[$user_details_dashboard->sno]->hac_actual ?? 0;
                $post_sale_count = $goalsetData[$user_details_dashboard->sno]->no_of_post_sale_actual ?? 0;
                $OutstandingPayment_count = $goalsetData[$user_details_dashboard->sno]->no_of_outstanding_actual ?? 0;
                $refferal_count = $goalsetData[$user_details_dashboard->sno]->reference_sales_actual ?? 0;
            }
        }
        // return $goalsetData;

        $goalsetRecordsLastMonth = GoalSetStaffModel::where('za_goal_set_staff.department_id', $user_details_dashboard->department_id)->where('za_goal_set_staff.branch_id', $branch_id)
        ->whereMonth('za_goal_set_staff.goal_date', $lastMonthYear)->where('za_goal_set_staff.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_goal_set_staff.goal_date', $lastMonth)
        ->get();

        $goalsetDataLastMonth = [];
        foreach ($goalsetRecords as $goal) {
            $goalsetDataLastMonth[$user_details_dashboard->sno] = $goal;
        }

        // Extract single user's goal data (flattened)
        $goalsetDataLastMonth = $goalsetDataLastMonth[$user_details_dashboard->sno] ?? null;

        if(isset($goalsetDataLastMonth[$user_details_dashboard->sno]->goal_completed)){
            if($goalsetDataLastMonth[$user_details_dashboard->sno]->goal_completed == 1){
                $customerConvertCount = $goalsetDataLastMonth[$user_details_dashboard->sno]->conversion_actual ?? 0;
                $convertion_rate = $goalsetDataLastMonth[$user_details_dashboard->sno]->CR_actual ?? 0;
                $averageBusinessValue = $goalsetDataLastMonth[$user_details_dashboard->sno]->ABV_actual ?? 0;
                $averageCollectionValue = $goalsetDataLastMonth[$user_details_dashboard->sno]->ACV_actual ?? 0;
                $monthcall_out = $goalsetDataLastMonth[$user_details_dashboard->sno]->avg_call_out_actual ?? 0;
                $monthwalkincount = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_walk_actual ?? 0;
                $monthFollowupCount = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_followup_actual ?? 0;
                $std_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->min_no_of_students_actual ?? 0;
                $costing_amount = $goalsetDataLastMonth[$user_details_dashboard->sno]->production_costing_actual ?? 0;
                $review_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_reviews_actual ?? 0;
                $placement_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_placements_actual ?? 0;
                $mou_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->mou_actual ?? 0;
                $totalcosting_amount = $goalsetDataLastMonth[$user_details_dashboard->sno]->productions_actual ?? 0;
                $hacAmount = $goalsetDataLastMonth[$user_details_dashboard->sno]->hac_actual ?? 0;
                $post_sale_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_post_sale_actual ?? 0;
                $OutstandingPayment_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->no_of_outstanding_actual ?? 0;
                $refferal_count = $goalsetDataLastMonth[$user_details_dashboard->sno]->reference_sales_actual ?? 0;
            }
        }

        // Check if it's an AJAX request
        if ($request->ajax()) {
          return response()->json([
            'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
            'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
            'reports' => $reports,
            'goalsetData' => $goalsetData,
            'goalsetDataLastMonth' => $goalsetDataLastMonth,
            'user_details_dashboard' => $user_details_dashboard
          ]);
        }

      return view('content.dashboard.sales_executive_dashboard', compact('branch_common', 'role_user', 'role_permission','user_details_dashboard','selectedMonth','reports', 'goalsetData', 'goalsetDataLastMonth'));
    }
    // Sales By role $user->role_id == 11 || $user->role_id == 12 || $user->role_id == 13 || $user->role_id == 14
    else if ($user_details_dashboard->sub_department_id == 1 || $user_details_dashboard->sub_department_id == 2 || $user_details_dashboard->sub_department_id == 3) {
        return view('content.dashboard.dashboards-analytics', compact('branch_common', 'role_user', 'role_permission'));
        
        
      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name', 'za_job_position.sno')->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')->where('za_staff.sno', $user->user_id)->first();

      // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
      $totalLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6])->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $totalLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCount = $totalLeadCountQuery->count();
      // return $totalLeadCount;

      $currentMonthLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6])->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $currentMonthLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $branch_id = $user->branch_id;
      $lastMonth = date('m', strtotime('first day of last month'));
      // current month customer
      $currentMonthCustomerCount = CustomerModel::whereIn('za_customer.status',[0,6])
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->when($user->branch_id != 0, function ($query) use ($branch_id) {
          return $query->where('za_customer.branch_id', $branch_id);
        })
        ->whereYear('za_customer.created_at', date('Y'))
        ->whereMonth('za_customer.created_at', date('m'))
        ->count();

      // get all lead courses
      $allCourses_ids = LeadModel::whereNotIn('status', [3, 2])
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->pluck('course_id');
      $allCourses_ids = collect($allCourses_ids)->flatMap(function ($item) {
        return json_decode($item);
      })->values()->all();

      // get all payments
      $payments = [];
      foreach ($allCourses_ids as $id) {
        $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');
        // return  $payment;
        if ($payment !== null) {
          $payments[] = $payment[0];
        } else {
          $payments[] = 0;
        }
      }

      // sum total course amount
      $total_business_value = array_sum($payments);

      $average_business_value = 0;
      // formula for average business
      if ($currentMonthLeadCount > 0) {
        $average_business_value = $total_business_value / $currentMonthLeadCount;
      }
      // return $average_business_value;

      // calculation for average collection value
      $allCourses_cus = CustomerModel::where('status', 0)->whereYear('created_at', date('Y'))
        ->where('created_by', $user->user_id)
        ->whereMonth('created_at', date('m'))->pluck('course_id');
      $allCourses_cus = collect($allCourses_cus)->flatMap(function ($item) {
        return json_decode($item);
      })->values()->all();

      // get all payments
      $payments_cus = [];
      foreach ($allCourses_cus as $id) {
        $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');

        if ($payment !== null) {
          $payments_cus[] = $payment[0];
        } else {
          $payments_cus[] = 0;
        }
      }

      // sum total collection course amount
      $total_collection_value = array_sum($payments_cus);

      // formula for average collection
      $average_collection_value = 0;
      if ($currentMonthCustomerCount > 0) {
        $average_collection_value = $total_collection_value / $currentMonthCustomerCount;
      }

      // return $average_collection_value;

      $lastMonthLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6])->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $lastMonthLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }

      $lastMonthLeadCount = $lastMonthLeadCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();

      $percentageChange = $lastMonthLeadCount > 0
        ? round((($currentMonthLeadCount - $lastMonthLeadCount) / $lastMonthLeadCount) * 100)
        : ($lastMonthLeadCount === 0 && $currentMonthLeadCount > 0
          ? 100 : 0);
      $percentageChange .= '%';
      $isIncreasedLead = $currentMonthLeadCount > $lastMonthLeadCount;
      // return $percentageChange;

      // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
      $totalLeadCountQueryActive = LeadModel::where('status', 0)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $totalLeadCountQueryActive->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCountActive = $totalLeadCountQueryActive->count();
      // return $totalLeadCountActive;

      $currentMonthLeadCountQueryActive = LeadModel::where('status', 0)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $currentMonthLeadCountQueryActive->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthLeadCountActive = $currentMonthLeadCountQueryActive->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $lastMonthLeadCountQueryActive = LeadModel::where('status', 0)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $lastMonthLeadCountQueryActive->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonthLeadCountActive = $lastMonthLeadCountQueryActive->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();

      $percentageChangeActive = $lastMonthLeadCountActive > 0
        ? round((($currentMonthLeadCountActive - $lastMonthLeadCountActive) / $lastMonthLeadCountActive) * 100)
        : ($lastMonthLeadCountActive === 0 && $currentMonthLeadCountActive > 0
          ? 100 : 0);

      // Format the result as a percentage
      $percentageChangeActive .= '%';

      $isIncreasedLeadActive = $currentMonthLeadCountActive > $lastMonthLeadCountActive;

      $totalCustomerCountQuery = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $totalCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $totalCustomerCount = $totalCustomerCountQuery->count();
      // return $totalCustomerCount;

      $currentMonthCustomerCountQuery = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $currentMonthCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthCustomerCount = $currentMonthCustomerCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $lastMonthCustomerCountQuery = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $lastMonthCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonthCustomerCount = $lastMonthCustomerCountQuery->whereYear('created_at', date('Y', strtotime('-1 month')))
        ->whereMonth('created_at', date('m', strtotime('-1 month')))
        ->count();

      // Calculate percentages
      $percentageover = $totalLeadCount > 0 ? round(($totalCustomerCount / $totalLeadCount) * 100) . '%' : '0%';
      $percentagecurrentmonth = $currentMonthLeadCount > 0 ? round(($currentMonthCustomerCount / $currentMonthLeadCount) * 100) . '%' : '0%';
      $percentagelastmonth = $lastMonthLeadCount > 0 ? round(($lastMonthCustomerCount / $lastMonthLeadCount) * 100) . '%' : '0%';

      $percentageConversion = $lastMonthCustomerCount > 0
        ? round((($currentMonthCustomerCount - $lastMonthCustomerCount) / $lastMonthCustomerCount) * 100)
        : ($lastMonthCustomerCount === 0 && $currentMonthCustomerCount > 0
          ? 100 : 0);

      $percentageConversion .= '%';
      $isIncreasedConversion = $percentagecurrentmonth > $percentagelastmonth;

      $totalCustomerCountQueryToday = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id)->where('created_at', date('d-M-Y'));
      if ($user->branch_id != 0) {
        $totalCustomerCountQueryToday->where('za_lead.branch_id', $user->branch_id);
      }
      $totalCustomerCountToday = $totalCustomerCountQueryToday->count();
      // return $totalCustomerCountToday;

      $totalLeadCountQueryToday = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id)->where('created_at', date('d-M-Y'));
      if ($user->branch_id != 0) {
        $totalLeadCountQueryToday->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCountToday = $totalLeadCountQueryToday->count();

      $YesterdayCustomerCountQuery = LeadModel::where('status', 4)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $YesterdayCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $YesterdayCustomerCount = $YesterdayCustomerCountQuery->whereYear('created_at', date('Y', strtotime('-1 month')))
        ->whereMonth('created_at', date('m', strtotime('-1 month')))
        ->where('created_at', date('d-M-Y', strtotime('-1 date')))
        ->count();
      // return $YesterdayCustomerCount;
      $percentagecurrentdate = $totalLeadCountToday > 0 ? round(($totalCustomerCountToday / $totalLeadCountToday) * 100) . '%' : '0%';

      $percentageConversionToday = $YesterdayCustomerCount > 0
        ? round((($totalCustomerCountToday - $YesterdayCustomerCount) / $YesterdayCustomerCount) * 100)
        : ($YesterdayCustomerCount === 0 && $totalCustomerCountToday > 0
          ? 100 : 0);

      $percentageConversionToday .= '%';
      $isIncreasedConversionToday = $totalCustomerCountToday > $YesterdayCustomerCount;

      $totalLeadCountQueryDrop = LeadModel::where('status', 5)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $totalLeadCountQueryDrop->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCountDrop = $totalLeadCountQueryDrop->count();
      // return $totalLeadCountDrop;

      $currentMonthLeadCountQueryDrop = LeadModel::where('status', 5)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $currentMonthLeadCountQueryDrop->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthLeadCountDrop = $currentMonthLeadCountQueryDrop->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $lastMonthLeadCountQueryDrop = LeadModel::where('status', 5)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $lastMonthLeadCountQueryDrop->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonthLeadCountDrop = $lastMonthLeadCountQueryDrop->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();

      // return $lastMonthLeadCountDrop;

      $percentageChangeDrop = $lastMonthLeadCountDrop > 0
        ? round((($currentMonthLeadCountDrop - $lastMonthLeadCountDrop) / $lastMonthLeadCountDrop) * 100)
        : ($lastMonthLeadCountDrop === 0 && $currentMonthLeadCountDrop > 0
          ? 100 : 0);

      // Format the result as a percentage
      $percentageChangeDrop .= '%';

      $isIncreasedLeadDrop = $currentMonthLeadCountDrop > $lastMonthLeadCountDrop;
      // return $percentageChangeDrop;

      $totalLeadCountQuerySpam = LeadModel::where('status', 7)->where('lead_status_id', 6)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $totalLeadCountQuerySpam->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCountSpam = $totalLeadCountQuerySpam->count();
      // return $totalLeadCountSpam;

      $currentMonthLeadCountQuerySpam = LeadModel::where('status', 7)->where('lead_status_id', 6)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $currentMonthLeadCountQuerySpam->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthLeadCountSpam = $currentMonthLeadCountQuerySpam->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $lastMonthLeadCountQuerySpam = LeadModel::where('status', 7)->where('lead_status_id', 6)->where('za_lead.created_by', $user->user_id);
      if ($user->branch_id != 0) {
        $lastMonthLeadCountQuerySpam->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonthLeadCountSpam = $lastMonthLeadCountQuerySpam->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();

      // return $lastMonthLeadCountSpam;

      $percentageChangeSpam = $lastMonthLeadCountSpam > 0
        ? round((($currentMonthLeadCountSpam - $lastMonthLeadCountSpam) / $lastMonthLeadCountSpam) * 100)
        : ($lastMonthLeadCountSpam = 0 && $currentMonthLeadCountSpam > 0
          ? 100 : 0);

      // Format the result as a percentage
      $percentageChangeSpam .= '%';

      $isIncreasedLeadSpam = $currentMonthLeadCountSpam > $lastMonthLeadCountSpam;
      // return $percentageChangeSpam;

      // return $user_details_data;
      // Calculate the total leads first
      $totalLeadCount_source = DB::table('za_lead')
        ->where('za_lead.branch_id', $user->branch_id)
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->count();

      // Now retrieve the top 5 lead sources
      $leadtop_5source = LeadSourceModel::select(
        'za_lead_source.lead_source_name',
        DB::raw("COUNT(za_lead.sno) as total_lead")
      )
        ->leftJoin('za_lead', 'za_lead_source.sno', '=', 'za_lead.lead_source_id')
        ->where('za_lead_source.status', 0)
        ->where('za_lead.branch_id', $user->branch_id)
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->groupBy('za_lead_source.lead_source_name')
        ->orderBy('total_lead', 'desc')
        ->limit(5)
        ->get();

      // Calculate the percentage for each lead source and round it off
      foreach ($leadtop_5source as $leadSource) {
        $leadSource->leadSourcePercentage = $totalLeadCount_source > 0
          ? round(($leadSource->total_lead / $totalLeadCount_source) * 100)
          : 0;
      }

      // return $leadtop_5source;
      $lead_5_sales_person = LeadModel::select(
        'za_staff.nick_name',
        'za_staff.staff_image',
        'za_staff.staff_name',
        'za_job_position.job_position_name',
        DB::raw("COUNT(za_lead.created_by) as total_lead")
      )
        ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
        ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->whereIn('za_staff.sub_department_id', [1, 2, 3])
        ->where('za_lead.branch_id', $user->branch_id)
        ->groupBy('za_staff.nick_name', 'za_staff.staff_name', 'za_staff.staff_image', 'za_job_position.job_position_name')
        ->orderBy('total_lead', 'desc')
        ->limit(5)
        ->get();

      //  return $lead_5_sales_person;

      // $rank_position = DB::table(DB::raw("(
      //     SELECT
      //         za_staff.sno,
      //         COUNT(za_lead.created_by) as total_lead,
      //         RANK() OVER (ORDER BY COUNT(za_lead.created_by) DESC) as rank_position
      //     FROM za_lead
      //     LEFT JOIN za_staff ON za_lead.created_by = za_staff.sno
      //     WHERE MONTH(za_lead.created_at) = ?
      //       AND YEAR(za_lead.created_at) = ?
      //       AND za_lead.branch_id = ?
      //       AND (za_staff.sub_department_id = ?
      //            OR za_staff.sub_department_id = ?
      //            OR za_staff.sub_department_id = ?)
      //     GROUP BY za_staff.sno
      // ) AS ranked_leads"))
      //   ->select('total_lead', 'rank_position')
      //   ->where('sno', $user->user_id)
      //   ->setBindings([date('m'), date('Y'), $user->branch_id, 1, 2, 3, $user->user_id]) // Added $user->user_id
      //   ->first();
      // return $rank_position;

      $top5Courses = LeadModel::select(
        'za_course.course_name',
        DB::raw('COUNT(za_lead.course_id) as total_course_count')
      )
        ->leftJoin(
          'za_course',
          DB::raw('JSON_CONTAINS(za_lead.course_id, JSON_QUOTE(CAST(za_course.sno AS CHAR)))'),
          '=',
          DB::raw('1')
        )
        ->where('za_lead.branch_id', $user->branch_id)
        ->whereRaw('JSON_VALID(za_lead.course_id) = 1')
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->groupBy('za_course.course_name')
        ->orderByDesc('total_course_count')
        ->limit(5)
        ->get();

      // return $top5Courses;

      // Get monthly lead count for the current month in the current year
      $dateLeadCounts = LeadModel::select(
        DB::raw('DATE(created_at) as date'),
        DB::raw('COUNT(*) as lead_count')
      )
        ->whereNotIn('status', [3, 2, 6])
        ->where('za_lead.created_by', $user->user_id)
        ->when($user->branch_id != 0, function ($query) use ($user) {
          $query->where('za_lead.branch_id', $user->branch_id);
        })
        ->whereYear('created_at', date('Y'))  // Filter by the current year
        ->whereMonth('created_at', date('m')) // Filter by the current month
        ->groupBy(DB::raw('DATE(created_at)'))
        ->orderBy(DB::raw('DATE(created_at)'))
        ->get();

      $dateLeadDropCounts = LeadModel::select(
        DB::raw('DATE(created_at) as date'),
        DB::raw('COUNT(*) as lead_count')
      )
        ->where('status', 5)
        ->where('za_lead.created_by', $user->user_id)
        ->when($user->branch_id != 0, function ($query) use ($user) {
          $query->where('za_lead.branch_id', $user->branch_id);
        })
        ->whereYear('created_at', date('Y'))  // Filter by the current year
        ->whereMonth('created_at', date('m')) // Filter by the current month
        ->groupBy(DB::raw('DATE(created_at)'))
        ->orderBy(DB::raw('DATE(created_at)'))
        ->get();

      $dateCustomerCounts = LeadModel::select(
        DB::raw('DATE(created_at) as date'),
        DB::raw('COUNT(*) as lead_count')
      )
        ->where('status', 4)
        ->where('za_lead.created_by', $user->user_id)
        ->when($user->branch_id != 0, function ($query) use ($user) {
          $query->where('za_lead.branch_id', $user->branch_id);
        })
        ->whereYear('created_at', date('Y'))  // Filter by the current year
        ->whereMonth('created_at', date('m')) // Filter by the current month
        ->groupBy(DB::raw('DATE(created_at)'))
        ->orderBy(DB::raw('DATE(created_at)'))
        ->get();

      $dateData_garph = [];

      foreach (range(1, 31) as $date) {
        $lead = $dateLeadCounts->firstWhere('date', date('Y-m') . '-' . str_pad($date, 2, '0', STR_PAD_LEFT));
        $customer = $dateCustomerCounts->firstWhere('date', date('Y-m') . '-' . str_pad($date, 2, '0', STR_PAD_LEFT));
        $dropLead = $dateLeadDropCounts->firstWhere('date', date('Y-m') . '-' . str_pad($date, 2, '0', STR_PAD_LEFT));

        $dateData_garph[] = [
          'date' => str_pad($date, 2, '0', STR_PAD_LEFT),  // Correct format for day
          'lead_count' => $lead ? $lead->lead_count : 0,
          'customer_count' => $customer ? $customer->lead_count : 0,  // Fixed to match the correct key (`lead_count`)
          'drop_count' => $dropLead ? $dropLead->lead_count : 0,  // Fixed to match the correct key (`lead_count`)
        ];
      }

      // return $dateData_garph;


      // $monday = strtotime("last sunday");
      // $monday = date('w', $monday) == date('w') ? $monday + 7 * 86400 : $monday;
      // $sunday = strtotime(date("d-m-Y", $monday) . " +6 days");
      // $this_week_start = date("Y-m-d", $monday); // Using 'Y-m-d' format for date filtering
      // $this_week_end = date("Y-m-d", $sunday);

      // // Initialize an array for all days of the week with 0 leads and all statuses
      // $all_days_leads = [];
      // $lead_status_colors = []; // To store colors for each lead status

      // // Fetch all distinct lead statuses with their colors
      // $lead_statuses = LeadStatusModel::select('lead_status_name', 'lead_bg_color')->get();

      // foreach ($lead_statuses as $status) {
      //   $lead_status_colors[$status->lead_status_name] = $status->lead_bg_color; // Map colors to statuses
      // }

      // // Initialize the all_days_leads array for each status for all days of the week
      // for ($i = 0; $i < 7; $i++) {
      //   $date = date("Y-m-d", strtotime("+$i days", $monday)); // Get each day of the week
      //   foreach ($lead_status_colors as $status => $color) {
      //     $all_days_leads[$date][$status] = [
      //       'count' => 0,  // Initialize count to 0
      //       'color' => $color // Set the color
      //     ];
      //   }
      // }

      // // Fetch lead status counts for the week
      // $lead_status_graph = LeadStatusModel::select(
      //   'za_lead_status.lead_status_name',
      //   'za_lead_status.lead_bg_color',
      //   'za_lead.created_at',
      //   DB::raw("COUNT(za_lead.lead_status_id) as total_lead")
      // )
      //   ->leftJoin('za_lead', function ($join) use ($user) {
      //     $join->on('za_lead_status.sno', '=', 'za_lead.lead_status_id')
      //       ->where('za_lead.branch_id', '=', $user->branch_id)
      //       ->where('za_lead.created_by', '=', $user->user_id);
      //   })
      //   ->where('za_lead_status.status', 0)
      //   ->whereBetween('za_lead.created_at', [$this_week_start, $this_week_end])
      //   ->groupBy('za_lead_status.lead_status_name', 'za_lead_status.lead_bg_color', 'za_lead.created_at')
      //   ->orderBy('total_lead', 'desc')
      //   ->get();

      // // Merge results with all_days_leads
      // foreach ($lead_status_graph as $lead_status) {
      //   $date = date("Y-m-d", strtotime($lead_status->created_at));
      //   if (isset($all_days_leads[$date][$lead_status->lead_status_name])) {
      //     $all_days_leads[$date][$lead_status->lead_status_name]['count'] = $lead_status->total_lead; // Update count
      //   }
      // }

      // // Prepare the final results array grouped by date
      // $week_lead_status_graph = [];
      // foreach ($all_days_leads as $date => $statuses) {
      //   $formatted_statuses = [];
      //   foreach ($statuses as $status => $data) {
      //     $formatted_statuses[] = [
      //       'status' => $status,
      //       'count' => $data['count'],
      //       'color' => $data['color']
      //     ];
      //   }

      //   $week_lead_status_graph[] = [
      //     'date' => $date,
      //     'statuses' => $formatted_statuses
      //   ];
      // }


      $today_followup = AppointmentModel::select('za_appointment.*', 'za_lead.lead_name', 'za_lead.lead_gender', 'za_appointment.status as appointment_status')
        ->join('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->whereDate('za_appointment.appointment_date', today())
        ->where('za_appointment.created_by', $user->user_id)
        ->get();
      // return $today_followup;

      $today_followup_count = AppointmentModel::select('za_appointment.*', 'za_lead.lead_name', 'za_lead.lead_gender')
        ->join('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->whereDate('za_appointment.appointment_date', today())
        ->where('za_appointment.created_by', $user->user_id)
        ->count();
      // return $today_followup_count;

      // return $user_details_dashboard;
      return view('content.dashboard.dashboards_sales', compact(
        'branch_common',
        'today_followup',
        'totalLeadCountSpam',
        'isIncreasedLeadSpam',
        'percentageChangeSpam',
        'isIncreasedLeadDrop',
        'totalLeadCountDrop',
        'percentageChangeDrop',
        'percentageConversionToday',
        'isIncreasedConversionToday',
        'totalCustomerCountToday',
        'percentagecurrentdate',
        'percentagecurrentmonth',
        'isIncreasedConversion',
        'percentageConversion',
        'isIncreasedLeadActive',
        'percentageChangeActive',
        'totalLeadCountActive',
        'isIncreasedLead',
        'percentageChange',
        'average_collection_value',
        'role_user',
        'role_permission',
        'user_details_dashboard',
        'leadtop_5source',
        'lead_5_sales_person',
        'top5Courses',
        'dateData_garph',
        'today_followup_count',
        'totalLeadCount',
        'average_business_value',
        'totalCustomerCount'
      ));
    }

    // 16 CRE
    else  if ($user->role_id == 16) {
      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name')->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')->where('za_staff.sno', $user->user_id)->first();
      // return $user_details_dashboard;

      $staffId  = $user->user_id;
      $branchId = $user->branch_id;
      $currentMonth = date('m');
      $currentYear = date('Y');
      $currentDate = date('Y-m-d');
      $month = date('m');
      $year = date('Y');


      // Get the total present days (attendance = 'P')
      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      $presentDays = StaffAttendanceModel::where('staff_id', $staffId)
        ->where('branch_id', $branchId)
        ->where('attendance', 'P')
        ->whereMonth('date', $currentMonth)
        ->whereYear('date', $currentYear)
        ->count();

      $presentDays =  $dayCount > 0 ? round(($presentDays / $dayCount) * 100) : 0;


      $current_month_total_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        // ->where('status', 0)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_solved_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        ->where('status', 2)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      // Daily Reports Status
      $staffcount = StaffModel::where('branch_id', $branchId)->where('status', 0)->count();

      $staffAttendanceDetails = StaffAttendanceModel::where('branch_id', $branchId)->whereDate('date', date('Y-m-d'))->get();

      $studentcount = CustomerModel::where('branch_id', $branchId)->where('status', 0)->count();

      $studentAttendanceDetails = AttendanceModel::where('branch_id', $branchId)->whereDate('att_date', date('Y-m-d'))->get();

      $ongoingBatch = DB::table('za_batch')
        ->whereMonth('start_date', '>=', $month)
        ->whereYear('start_date', '>=', $year)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->count();

      $completedBatch = DB::table('za_batch')
        ->whereMonth('end_date', $month)
        ->whereYear('end_date', $year)
        ->where('branch_id', $branchId)
        ->where('status', 3)
        ->count();

      $upcomingBatch = DB::table('za_batch')
        ->whereMonth('start_date', '>=', $month)
        ->whereYear('start_date', '>=', $year)
        ->whereDate('start_date', '>', $currentDate)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->count();

      $batchextenCount = DB::table('za_batch_extension')
        ->where('status', 1)
        ->where('branch_id', $branchId)
        ->whereMonth('end_date', $month)
        ->whereYear('end_date', $year)
        ->count();

      $totalamountoriginal = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branchId)
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branchId)
        ->sum('za_payment.amount');

      $totalamountold = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branchId)
        ->where('za_old_customer.status', 0)
        ->whereYear('za_old_payments.schedule_date', $year)
        ->whereMonth('za_old_payments.schedule_date', $month)
        ->where('za_old_payments.branch_id', $branchId)
        ->sum('za_old_payments.amount');

      $totalamount = $totalamountoriginal + $totalamountold;

      $collectamount = TransactionModel::where('branch_id', $branchId)
        ->whereMonth('created_at', $month)
        ->whereYear('created_at', $year) // Added a comma after 'created_at'
        ->sum('credit');


      //   $outstandingAmount = $totalamount - $collectamount;


      $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_drop_refund.branch_id', $branchId)
        ->pluck('za_training.payment_id');

      // Get the current date
      $currentDate = now()->toDateString();

      $OutstandingPayment = DB::table('za_payment')->where('za_payment.branch_id', $branchId)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount', '>', 0)
        ->whereIn('za_customer.status',[0,6])
        ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
        ->orderBy('za_payment.sno', 'asc')
        ->count();

      $outstandingAmount = $OutstandingPayment;

      $request_certificate = DB::table('za_manage_certificate')
        ->whereMonth('req_cert_date',  $month)
        ->whereYear('req_cert_date', $year)
        ->where('branch_id', $branchId)
        ->where('cert_status_id', 2)
        ->count();

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $drop_count_this_month = DB::table('za_drop_refund')
        ->whereMonth('bh_status_date', $month)
        ->whereYear('bh_status_date', $year)
        ->where('branch_id', $branchId)
        ->where('type', 0)
        ->where('bh_status', 1)
        ->count();

      $drop_count_last_month = DB::table('za_drop_refund')
        ->whereMonth('bh_status_date', $lastMonth)
        ->whereYear('bh_status_date', $lastMonthYear)
        ->where('branch_id', $branchId)
        ->where('type', 0)
        ->where('bh_status', 1)
        ->count();

      $comp_cus_this_month = DB::table('za_customer')
        ->whereMonth('completed_date', $month)
        ->whereYear('completed_date', $year)
        ->where('branch_id', $branchId)
        ->where('status', 4)
        ->count();

      $comp_cus_last_month = DB::table('za_customer')
        ->whereMonth('completed_date', $lastMonth)
        ->whereYear('completed_date', $lastMonthYear)
        ->where('branch_id', $branchId)
        ->where('status', 4)
        ->count();

      $review_this_month = DB::table('za_review')
        ->whereMonth('created_at', $month)
        ->whereYear('created_at', $year)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->count();

      $review_last_month = DB::table('za_review')
        ->whereMonth('created_at', $lastMonth)
        ->whereYear('created_at', $lastMonthYear)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->count();

      // Active this month
      $active_this_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->where('za_training.branch_id', $branchId)
        ->where('za_training.status', 0)
        ->where('za_training.batch_id', '>', 1)
        ->whereMonth('za_training.end_date', '=', $month)
        ->whereYear('za_training.end_date', '=', $year)
        ->groupBy('za_training.customer_id')
        ->count();

      // Active last month
      $active_last_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->where('za_training.branch_id', $branchId)
        ->where('za_training.status', 0)
        ->where('za_training.batch_id', '>', 1)
        ->whereMonth('za_training.end_date', '=', $lastMonth)
        ->whereYear('za_training.end_date', '=', $lastMonthYear)
        ->groupBy('za_training.customer_id')
        ->count();

      // Batch not assigned this month
      $batch_not_assign_this_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->where('za_training.branch_id', $branchId)
        ->where('za_training.status', 0)
        ->where('za_training.batch_id', '<', 1)
        ->whereMonth('za_training.start_date', '=', $month)
        ->whereYear('za_training.start_date', '=', $year)
        ->groupBy('za_training.customer_id')
        ->count();

      // Batch not assigned last month
      $batch_not_assign_last_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->where('za_training.branch_id', $branchId)
        ->where('za_training.status', 0)
        ->where('za_training.batch_id', '<', 1)
        ->whereMonth('za_training.start_date', '=', $lastMonth)
        ->whereYear('za_training.start_date', '=', $lastMonthYear)
        ->groupBy('za_training.customer_id')
        ->count();

      $upcoming_this_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_training.branch_id', $branchId)
        ->whereMonth('za_batch.start_date', '>', $lastMonth)
        ->whereYear('za_batch.start_date', '>', $lastMonthYear)
        ->where('za_training.status', 0)
        ->groupBy('za_training.customer_id')
        ->count();

      $upcoming_last_month = TrainingModel::select('za_training.customer_id')
        ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_training.branch_id', $branchId)
        ->whereMonth('za_batch.start_date', '>', $month)
        ->whereYear('za_batch.start_date', '>', $year)
        ->where('za_training.status', 0)
        ->groupBy('za_training.customer_id')
        ->count();

      $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
        ->where('za_training.branch_id', $branchId)
        ->whereIn('za_customer.status',[0,6])
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

      $dropCount = 0;
      $activeCount = 0;
      $notYetStartedCount = 0;
      $scheduleCount = 0;

      $processed_drop_customers = [];
      $processed_active_customers = [];
      $processed_not_started_customers = [];

      foreach ($batch_Data as $singledata) {
        if (in_array($singledata->customer_id, $processed_drop_customers)) {
          continue;
        }
        if ($singledata->status == "2") {
          $dropCount++;
          $processed_drop_customers[] = $singledata->customer_id;
        }
      }

      foreach ($batch_Data as $singledata) {
        if (!in_array($singledata->customer_id, $processed_drop_customers)) {
          if (in_array($singledata->customer_id, $processed_active_customers)) {
            continue;
          }
          if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
            $activeCount++;
            $processed_active_customers[] = $singledata->customer_id;
          }
        }
      }


      $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id', $branchId)
        ->whereIn('za_customer.status',[0,6])
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

      // return  $processed_active_customers;
      foreach ($batch_Data_old as $singledata) {

        if (!in_array($singledata->customer_id, $processed_drop_customers)) {
          if (!in_array($singledata->customer_id, $processed_active_customers)) {
            if (in_array($singledata->customer_id, $processed_not_started_customers)) {
              continue;
            }
            if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
              $scheduleCount++;
              $processed_not_started_customers[] = $singledata->customer_id;
            } elseif ($singledata->start_date === null) {
              $notYetStartedCount++;
              $processed_not_started_customers[] = $singledata->customer_id;
            }
          }
        }
      }

      $active_this_month = $activeCount;
      $batch_not_assign_this_month = $notYetStartedCount;
      $upcoming_this_month = $scheduleCount;

      $reports = [
        'staffcount'   => str_pad($staffcount, 2, '0', STR_PAD_LEFT),
        'studentcount' => str_pad($studentcount, 2, '0', STR_PAD_LEFT),
        'P'  => str_pad($staffAttendanceDetails->where('attendance', 'P')->count(), 2, '0', STR_PAD_LEFT),
        'A'  => str_pad($staffAttendanceDetails->where('attendance', 'A')->count(), 2, '0', STR_PAD_LEFT),
        'L'  => str_pad($staffAttendanceDetails->where('attendance', 'L')->count(), 2, '0', STR_PAD_LEFT),
        'OD' => str_pad($staffAttendanceDetails->where('attendance', 'OD')->count(), 2, '0', STR_PAD_LEFT),
        'PM' => str_pad($staffAttendanceDetails->where('attendance', 'PM')->count(), 2, '0', STR_PAD_LEFT),
        'SP' => str_pad($studentAttendanceDetails->where('attendance', 'P')->count(), 2, '0', STR_PAD_LEFT),
        'SA' => str_pad($studentAttendanceDetails->where('attendance', 'A')->count(), 2, '0', STR_PAD_LEFT),
        'SL' => str_pad($studentAttendanceDetails->where('attendance', 'L')->count(), 2, '0', STR_PAD_LEFT),
        'SH' => str_pad($studentAttendanceDetails->where('attendance', 'H')->count(), 2, '0', STR_PAD_LEFT),
        'ongoingBatch' => str_pad($ongoingBatch, 2, '0', STR_PAD_LEFT),
        'completedBatch' => str_pad($completedBatch, 2, '0', STR_PAD_LEFT),
        'upcomingBatch' => str_pad($upcomingBatch, 2, '0', STR_PAD_LEFT),
        'completedBatch' => str_pad($completedBatch, 2, '0', STR_PAD_LEFT),
        'batchextenCount' => str_pad($batchextenCount, 2, '0', STR_PAD_LEFT),
        'outstandingamount' => str_pad($outstandingAmount, 2, '0', STR_PAD_LEFT),
        'request_certificate' => str_pad(round($request_certificate), 2, '0', STR_PAD_LEFT),
        'drop_count_this_month' => str_pad(round($drop_count_this_month), 2, '0', STR_PAD_LEFT),
        'drop_count_last_month' => str_pad(round($drop_count_last_month), 2, '0', STR_PAD_LEFT),
        'comp_cus_this_month' => str_pad(round($comp_cus_this_month), 2, '0', STR_PAD_LEFT),
        'comp_cus_last_month' => str_pad(round($comp_cus_last_month), 2, '0', STR_PAD_LEFT),
        'review_this_month' => str_pad(round($review_this_month), 2, '0', STR_PAD_LEFT),
        'review_last_month' => str_pad(round($review_last_month), 2, '0', STR_PAD_LEFT),
        'active_this_month' => str_pad(round($active_this_month), 2, '0', STR_PAD_LEFT),
        'active_last_month' => str_pad(round($active_last_month), 2, '0', STR_PAD_LEFT),
        'batch_not_assign_this_month' => str_pad(round($batch_not_assign_this_month), 2, '0', STR_PAD_LEFT),
        'batch_not_assign_last_month' => str_pad(round($batch_not_assign_last_month), 2, '0', STR_PAD_LEFT),
        'upcoming_this_month' => str_pad(round($upcoming_this_month), 2, '0', STR_PAD_LEFT),
        'upcoming_last_month' => str_pad(round($upcoming_last_month), 2, '0', STR_PAD_LEFT),
      ];


      return view('content.dashboard.cre_dashboard', compact('user_details_dashboard', 'reports', 'branch_common', 'role_user', 'role_permission', 'presentDays', 'current_month_total_queries', 'current_month_solved_queries'));
    }
    // Center Head
    else if ($user->role_id == 0) {


      $user_details_dashboard = StaffModel::where('sno', $user->user_id)->first();

      // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
      $totalLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6])->whereDate('created_at', today());
      if ($user->branch_id != 0) {
        $totalLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $totalLeadCount = $totalLeadCountQuery->count();

      $currentMonthLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($user->branch_id != 0) {
        $currentMonthLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();
      $lastMonth = date('m', strtotime('first day of last month'));
      // return $lastMonth;
      $lastMonthLeadCountQuery = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($user->branch_id != 0) {
        $lastMonthLeadCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonthLeadCount = $lastMonthLeadCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();


      // return date('m', strtotime('-1 month'));

      $totalCustomerCountQuery = LeadModel::where('status', 4);
      if ($user->branch_id != 0) {
        $totalCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $totalCustomerCount = $totalCustomerCountQuery->count();

      $currentMonthCustomerCountQuery = LeadModel::where('status', 4);
      if ($user->branch_id != 0) {
        $currentMonthCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $currentMonthCustomerCount = $currentMonthCustomerCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();

      $lastMonthCustomerCountQuery = LeadModel::where('status', 4);
      if ($user->branch_id != 0) {
        $lastMonthCustomerCountQuery->where('za_lead.branch_id', $user->branch_id);
      }
      $lastMonth = date('m', strtotime('first day of last month'));
      $lastMonthCustomerCount = $lastMonthCustomerCountQuery->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', $lastMonth)
        ->count();

      // Calculate percentages
      $percentageover = $totalLeadCount > 0 ? round(($totalCustomerCount / $totalLeadCount) * 100) . '%' : '0%';
      $percentagecurrentmonth = $currentMonthLeadCount > 0 ? round(($currentMonthCustomerCount / $currentMonthLeadCount) * 100) . '%' : '0%';
      $percentagelastmonth = $lastMonthLeadCount > 0 ? round(($lastMonthCustomerCount / $lastMonthLeadCount) * 100) . '%' : '0%';

      // Consolidate results into a single array
      $user_details_data = [
        'total_lead_count' => str_pad($totalLeadCount ?? 0, 2, '0', STR_PAD_LEFT),
        'current_month_lead_count' => str_pad($currentMonthLeadCount ?? 0, 2, '0', STR_PAD_LEFT),
        'last_month_lead_count' => str_pad($lastMonthLeadCount ?? 0, 2, '0', STR_PAD_LEFT),
        'total_customer_count' => str_pad($totalCustomerCount ?? 0, 2, '0', STR_PAD_LEFT),
        'current_month_customer_count' => str_pad($currentMonthCustomerCount ?? 0, 2, '0', STR_PAD_LEFT),
        'last_month_customer_count' => str_pad($lastMonthCustomerCount ?? 0, 2, '0', STR_PAD_LEFT),
        'percentage_overall' => $percentageover,
        'percentage_current_month' => $percentagecurrentmonth,
        'percentage_last_month' => $percentagelastmonth,
      ];
      $lead_5_sales_person = LeadModel::select(
        'za_staff.nick_name',
        'za_staff.staff_image',
        'za_staff.gender',
        'za_job_position.job_position_name',
        DB::raw("COUNT(za_lead.created_by) as total_lead")
      )
        ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
        ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->whereIn('za_staff.sub_department_id', [1, 2, 3])
        ->where('za_lead.branch_id', $user->branch_id)
        ->groupBy('za_staff.nick_name', 'za_staff.gender', 'za_staff.staff_image', 'za_job_position.job_position_name')
        ->orderBy('total_lead', 'desc')
        ->limit(5)
        ->get();
      // return $rank_position;

      $top3Courses = LeadModel::select(
        'za_course.course_name',
        DB::raw('COUNT(za_lead.course_id) as total_course_count')
      )
        ->leftJoin(
          'za_course',
          DB::raw('JSON_CONTAINS(za_lead.course_id, JSON_QUOTE(CAST(za_course.sno AS CHAR)))'),
          '=',
          DB::raw('1')
        )
        ->where('za_lead.branch_id', $user->branch_id)
        ->whereRaw('JSON_VALID(za_lead.course_id) = 1')
        ->whereMonth('za_lead.created_at', date('m'))
        ->whereYear('za_lead.created_at', date('Y'))
        ->groupBy('za_course.course_name')
        ->orderByDesc('total_course_count')
        ->limit(5)
        ->get();


      $top5batch = BatchModel::select(
        'za_batch.batch_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_batch.max_students',
        DB::raw('COUNT(za_training.sno) AS present_students')
      )
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.status', 0)
        ->whereMonth('za_batch.created_at', date('m'))
        ->whereYear('za_batch.created_at', date('Y'))
        ->groupBy('za_batch.batch_name', 'za_batch.max_students', 'za_slot.slot_name', 'za_course.course_name') // Group by only relevant fields
        ->orderByRaw('COUNT(za_training.sno) DESC') // Sort by present students if top 3 is based on count
        ->limit(5)
        ->get();

      $top_5_faculty = StaffModel::select(
        'za_staff.nick_name',
        'za_staff.staff_image',
        'za_staff.gender',
        DB::raw('COUNT(DISTINCT za_batch.sno) AS total_batch'),
        DB::raw('COUNT(DISTINCT za_training.sno) AS total_students')
      )
        ->leftJoin('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_batch.branch_id', $user->branch_id)
        ->where('za_batch.status', 0)
        ->whereMonth('za_batch.created_at', date('m'))
        ->whereYear('za_batch.created_at', date('Y'))
        ->groupBy('za_staff.nick_name', 'za_staff.staff_image', 'za_staff.gender')
        ->orderByRaw('COUNT(DISTINCT za_training.sno) DESC')
        ->limit(5)
        ->get();

      // return  $top_5_faculty;

      // Get monthly lead count for the current year
      $monthlyLeadCounts = LeadModel::select(
        DB::raw('MONTH(created_at) as month'),
        DB::raw('COUNT(*) as lead_count')
      )
        ->whereNotIn('status', [3, 2, 6])
        ->where('za_lead.created_by', $user->user_id)
        ->when($user->branch_id != 0, function ($query) use ($user) {
          $query->where('za_lead.branch_id', $user->branch_id);
        })
        ->whereYear('created_at', date('Y'))
        ->groupBy(DB::raw('MONTH(created_at)'))
        ->orderBy(DB::raw('MONTH(created_at)'))
        ->get();

      // Get monthly customer count for the current year
      $monthlyCustomerCounts = LeadModel::select(
        DB::raw('MONTH(created_at) as month'),
        DB::raw('COUNT(*) as customer_count')
      )
        ->where('status', 4)
        ->where('za_lead.created_by', $user->user_id)
        ->when($user->branch_id != 0, function ($query) use ($user) {
          $query->where('za_lead.branch_id', $user->branch_id);
        })
        ->whereYear('created_at', date('Y'))
        ->groupBy(DB::raw('MONTH(created_at)'))
        ->orderBy(DB::raw('MONTH(created_at)'))
        ->get();

      // Combine both lead and customer counts into one dataset
      $monthlyData_garph = [];

      foreach (range(1, 12) as $month) {
        $lead = $monthlyLeadCounts->firstWhere('month', $month);
        $customer = $monthlyCustomerCounts->firstWhere('month', $month);

        $monthlyData_garph[] = [
          'month' => Carbon::createFromDate(null, $month, 1)->format('M'), // Converts numeric month to "Jan", "Feb", etc.
          'lead_count' => $lead ? $lead->lead_count : 0,
          'customer_count' => $customer ? $customer->customer_count : 0,
        ];
      }


      $monday = strtotime("last sunday");
      $monday = date('w', $monday) == date('w') ? $monday + 7 * 86400 : $monday;
      $sunday = strtotime(date("d-m-Y", $monday) . " +6 days");
      $this_week_start = date("Y-m-d", $monday); // Using 'Y-m-d' format for date filtering
      $this_week_end = date("Y-m-d", $sunday);

      // Initialize an array for all days of the week with 0 leads and all statuses
      $all_days_leads = [];
      $lead_status_colors = []; // To store colors for each lead status

      // Fetch all distinct lead statuses with their colors
      $lead_statuses = LeadStatusModel::select('lead_status_name', 'lead_bg_color')->get();

      foreach ($lead_statuses as $status) {
        $lead_status_colors[$status->lead_status_name] = $status->lead_bg_color; // Map colors to statuses
      }

      // Initialize the all_days_leads array for each status for all days of the week
      for ($i = 0; $i < 7; $i++) {
        $date = date("Y-m-d", strtotime("+$i days", $monday)); // Get each day of the week
        foreach ($lead_status_colors as $status => $color) {
          $all_days_leads[$date][$status] = [
            'count' => 0,  // Initialize count to 0
            'color' => $color // Set the color
          ];
        }
      }

      // Fetch lead status counts for the week
      $lead_status_graph = LeadStatusModel::select(
        'za_lead_status.lead_status_name',
        'za_lead_status.lead_bg_color',
        'za_lead.created_at',
        DB::raw("COUNT(za_lead.lead_status_id) as total_lead")
      )
        ->leftJoin('za_lead', function ($join) use ($user) {
          $join->on('za_lead_status.sno', '=', 'za_lead.lead_status_id')
            ->where('za_lead.branch_id', '=', $user->branch_id)
            ->where('za_lead.created_by', '=', $user->user_id);
        })
        ->where('za_lead_status.status', 0)
        ->whereBetween('za_lead.created_at', [$this_week_start, $this_week_end])
        ->groupBy('za_lead_status.lead_status_name', 'za_lead_status.lead_bg_color', 'za_lead.created_at')
        ->orderBy('total_lead', 'desc')
        ->get();

      // Merge results with all_days_leads
      foreach ($lead_status_graph as $lead_status) {
        $date = date("Y-m-d", strtotime($lead_status->created_at));
        if (isset($all_days_leads[$date][$lead_status->lead_status_name])) {
          $all_days_leads[$date][$lead_status->lead_status_name]['count'] = $lead_status->total_lead; // Update count
        }
      }

      // Prepare the final results array grouped by date
      $week_lead_status_graph = [];
      foreach ($all_days_leads as $date => $statuses) {
        $formatted_statuses = [];
        foreach ($statuses as $status => $data) {
          $formatted_statuses[] = [
            'status' => $status,
            'count' => $data['count'],
            'color' => $data['color']
          ];
        }

        $week_lead_status_graph[] = [
          'date' => $date,
          'statuses' => $formatted_statuses
        ];
      }


      $today_followup_count = AppointmentModel::whereDate('appointment_date', today())
        ->leftJoin('za_lead', function ($join) use ($user) {
          $join->on('za_lead.sno', '=', 'za_appointment.lead_id')
            ->where('za_lead.branch_id', '=', $user->branch_id);
        })
        ->where('progressed', null)
        ->count();
      // return $today_followup_count;
      $today_followup_count_com = AppointmentModel::whereDate('appointment_date', today())
        ->where('created_by', $user->user_id)
        ->where('progressed', '!=', null)
        ->count();

      $today_active_lead = LeadModel::whereDate('created_at', today())
        ->where('created_by', $user->user_id)
        ->where('status', 0)
        ->count();

      $currentMonthStart = Carbon::now()->startOfMonth()->toDateString();
      $currentMonthEnd = Carbon::now()->endOfMonth()->toDateString();

      $staff_attendance = StaffAttendanceModel::select(
        DB::raw("DATE(date) as date"),
        DB::raw("COUNT(CASE WHEN attendance = 'P' THEN 1 END) as present_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'A' THEN 1 END) as absent_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'OD' THEN 1 END) as onduty_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'Pr' THEN 1 END) as permision_count"),
        DB::raw("COUNT(CASE WHEN attendance = 'L' THEN 1 END) as leave_count")
      )
        ->where('branch_id', $user->branch_id)
        ->where('status', 0)
        ->whereBetween('date', [$currentMonthStart, $currentMonthEnd]) // Filter for the current month
        ->groupBy(DB::raw('DATE(date)')) // Group by each date in the current month
        ->get();

      // Generate an array with default values for missing dates
      $attendanceData = collect();
      $allDates = Carbon::now()->startOfMonth()->daysUntil(Carbon::now()->endOfMonth());
      foreach ($allDates as $date) {
        $attendanceData[$date->toDateString()] = [
          'present_count' => 0,
          'absent_count' => 0,
          'leave_count' => 0,
          'permision_count' => 0,
          'onduty_count' => 0,

        ];
      }

      // Merge query results into the default attendance data
      foreach ($staff_attendance as $record) {
        $attendanceData[$record->date] = [
          'present_count' => str_pad($record->present_count, 2, '0', STR_PAD_LEFT),
          'absent_count' => str_pad($record->absent_count, 2, '0', STR_PAD_LEFT),
          'leave_count' => str_pad($record->leave_count, 2, '0', STR_PAD_LEFT),
          'permision_count' => str_pad($record->permision_count, 2, '0', STR_PAD_LEFT),
          'onduty_count' => str_pad($record->onduty_count, 2, '0', STR_PAD_LEFT),
        ];
      }

      // Convert to an array or JSON as needed
      $attendanceData_staff = $attendanceData->toArray();

      // return $today_active_lead;
      return view('content.dashboard.dashboards_center_head', compact('branch_common', 'role_user', 'role_permission', 'user_details_dashboard', 'today_followup_count_com', 'attendanceData_staff', 'top5batch', 'top_5_faculty', 'lead_5_sales_person', 'user_details_data', 'top3Courses', 'monthlyData_garph', 'week_lead_status_graph', 'today_followup_count', 'today_active_lead'));
    }
    // developer role
    else if ($user->role_id == 1 || $user->role_id == 9 || $user->role_id == 27 || $user->role_id == 25 || $user->role_id == 28 || $user->role_id == 35) {
      return view('content.dashboard.ceo_dashboard', compact('branch_common', 'role_user', 'role_permission'));
    }
    // BH Center Frans
    else if ($user->role_id == 18 || $user->role_id == 20 || $user->role_id == 21 || $user->role_id == 31 || $user->role_id == 30) {

      // Get the selected month from request, default to the current month
      $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
      $user_details_dashboard = StaffModel::where('sno', $user->user_id)->first();
      $branch_id = $user->branch_id;
      $currentDate = Carbon::today()->toDateString(); // Get current date in YYYY-MM-DD format
      //  return $user_details_dashboard;
      [$year, $month] = explode('-', $selectedMonth);

   
     // Start date for the given month/year
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    
    // Determine end date (if current month/year, use today; else end of the month)
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
    
    // Count working days (excluding Sundays)
    $dayCounts = 0;
    $dateIterate = $startDate->copy();
    
    while ($dateIterate->lte($endDate)) {
        if (!$dateIterate->isSunday()) {
            $dayCounts++;
        }
        $dateIterate->addDay();
    }
    
    // Get present days from attendance
    $presentDays = StaffAttendanceModel::where('staff_id', $user_details_dashboard->sno)
        ->where('branch_id', $branch_id)
        ->whereIn('attendance', ['P', 'PR', 'HD'])
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();
        // return $dayCount;
    
    // Calculate attendance percentage
    // $user_details_dashboard->presentDays = $dayCount > 0
    //     ? round(($presentDays / $dayCount) * 100)
    //     : 0;
         $user_details_dashboard->presentDays = $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

      $totalamountoriginal = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');



      $totalamountold = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereYear('za_old_payments.schedule_date', $year)
        ->whereMonth('za_old_payments.schedule_date', $month)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      // $totalamount = $totalamountoriginal + $totalamountold;

      $notpaidamount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_payment.status', 0) // paid amount
        ->whereIn('za_customer.status',[0,6])
        ->where('za_payment.amount', '>', 0)
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      // $collectamount = TransactionModel::where('branch_id', $branch_id)
      //     ->whereMonth('created_at', $month)
      //     ->whereYear('created_at', $year)// Added a comma after 'created_at'
      //     ->sum('credit');

      $totalcollectedAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_payment.status', 1) // paid amount
        ->whereIn('za_customer.status',[0,6])
        ->where('za_payment.amount', '>', 0)
        ->whereYear('za_payment.initialPayDate', $year)
        ->whereMonth('za_payment.initialPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.paidAmount');

      $totalPaidAmountold = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_payments.status', '!=', 2) // paid amount
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.amount', '>', 0)
        ->whereYear('za_old_payments.created_at', $year)
        ->whereMonth('za_old_payments.created_at', $month)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.paidAmount');

      $collectamount = $totalPaidAmountold + $totalcollectedAmount;

      $outstandingAmount = $notpaidamount;
      $totalamount       = $notpaidamount + $collectamount;

      // Daily Reports Status
      $staffcount = StaffModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $staffAttendanceDetails = StaffAttendanceModel::where('branch_id', $branch_id)->whereDate('date', $currentDate)->get();

      $studentcount = CustomerModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $stundentAttendanceDetails = AttendanceModel::where('branch_id', $branch_id)->whereDate('att_date', $currentDate)->get();

      $current_month_total_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        // ->where('status', 0)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_solved_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        ->where('status', 2)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_pending_queries = $current_month_total_queries - $current_month_solved_queries;

      $totalamountoriginaldaily = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereDate('za_payment.nextPayDate', $currentDate)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      $totalamountolddaily = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereDate('za_old_payments.schedule_date', $currentDate)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      $totalamountdaily = $totalamountoriginaldaily + $totalamountolddaily;

      $collectamountdaily = TransactionModel::where('branch_id', $branch_id)
        ->whereDate('created_at', $currentDate)
        ->sum('credit');


      // $outstandingAmount = $outstandingAmountoriginal + $outstandingAmountold;
      $outstandingAmountdaily = $totalamountdaily - $collectamountdaily;

      //top cr,cc,abv abc values

      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $actualMonthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.internal_status', 0)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status',0)
        ->count();
        // $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        //     ->where('za_lead.created_by', $staff->sno)
        //     ->where('za_lead.branch_id', $branch_id)
        //     ->whereYear('za_lead.registered_date', $year)
        //     ->whereMonth('za_lead.registered_date', $month)
        //     ->whereNotIn('za_lead.status',[2,6])
        //     ->where('za_lead.spam_verified',0)
        //     ->where('za_lead.drop_verified', 0)
        //     ->where('za_lead.internal_status',0)
        //     ->count();

      $actualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->count();
        
       

      $actualConversionCountlast = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        
        // ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $lastMonthYear)
        // ->where('za_staff.department_id', 1)
        ->whereMonth('za_customer.created_at', $lastMonth)
        ->count();

      $actualdayLeadCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereDate('za_customer.created_at', $currentDate)
        ->where('za_staff.department_id', 1)
        ->count();
      $actualConversionRate = $actualMonthLeadCount > 0 ? ($actualConversionCount / $actualMonthLeadCount) * 100 : 0;
      $actualConversionRate = number_format($actualConversionRate, 2);
      $convertedCustomers = 0;
      $totalCustomer = 0;
      $totalCustomerlast = 0;
      $completedCustomer = 0;
      $completedCustomerlast = 0;
      $dropCustomer = 0;
      $dropCustomerlast = 0;
      $convertedCustomerslast = 0;
      $processed_drop_customers = [];
      $processed_active_customers = [];
      $averageBusinessValueAll = 0;
      $averageCollectionValueAll = 0;
      if ($actualConversionCount > 0) {
        $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.department_id', 1)
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->get();

        $total_payment = 0;
        $total_paid_payment = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {

            // $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
            //   ->where('za_training.customer_id', $customer->sno)
            //   ->sum('za_training.overall_fees');

            // $total_payment += $payment;
            $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->where('za_training.tesbo_check', 0)
              ->sum('za_training.overall_fees');
            $total_payment += $payment;
            $latestTraining = DB::table('za_training')
              ->where('customer_id', $customer->sno)
              ->where('tesbo_check', 2)
              ->orderByDesc('sno')
              ->first();

            if ($latestTraining) {
              $total_payment += $latestTraining->overall_fees;
            }

            $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.paid_amount');

            $total_paid_payment += $paid_payment;
          }
        }


        // average 
        $averageBusinessValueAll   = $actualConversionCount > 0 ? $total_payment / $actualConversionCount : 0;
        $averageCollectionValueAll = $actualConversionCount > 0 ? $total_paid_payment / $actualConversionCount : 0;
      }

      $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereYear('za_customer.updated_at', $year)
        ->whereMonth('za_customer.updated_at', $month)
        ->where('za_training.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->get();

      $batch_Data_last = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereYear('za_customer.updated_at', $lastMonthYear)
        ->whereMonth('za_customer.updated_at', $lastMonth)
        ->where('za_training.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->get();

      $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereYear('za_training.start_date', $year)
        ->whereMonth('za_training.start_date', $month)
        ->where('za_training.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

      $batch_active_Data_last = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereYear('za_training.start_date', $lastMonthYear)
        ->whereMonth('za_training.start_date', $lastMonth)
        ->where('za_training.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();


      foreach ($batch_active_Data as $singledata) {
        if (!in_array($singledata->customer_id, $processed_drop_customers)) {
          if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
            $convertedCustomers++;
          }
        }
      }

      foreach ($batch_active_Data_last as $singledata) {
        if (!in_array($singledata->customer_id, $processed_drop_customers)) {
          if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
            $convertedCustomerslast++;
          }
        }
      }

      foreach ($batch_Data as $singledata) {
        if ($singledata->status == "2") {
          $dropCustomer++;
        }
      }

      foreach ($batch_Data_last as $singledata) {
        if ($singledata->status == "2") {
          $dropCustomerlast++;
        }
      }

      $totalCustomer = DB::table('za_customer')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_customer.created_by', '!=', 0)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->whereIn('za_customer.status',[0,6])->count();

      // return $totalCustomer;

      $totalCustomerlast = DB::table('za_customer')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_customer.created_by', '!=', 0)
        ->whereYear('za_customer.created_at', $lastMonthYear)
        ->whereMonth('za_customer.created_at', $lastMonth)
        ->whereIn('za_customer.status',[0,6])->count();

      $completedCustomer = DB::table('za_customer')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_customer.created_by', '!=', 0)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->where('za_customer.status', 4)->count();

      // return $completedCustomer;

      $completedCustomerlast = DB::table('za_customer')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_customer.created_by', '!=', 0)
        ->whereYear('za_customer.created_at', $lastMonthYear)
        ->whereMonth('za_customer.created_at', $lastMonth)
        ->where('za_customer.status', 4)->count();

      // Date range calculation
      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;

      // Approval Reports Status

      $batchextensionCount = DB::table('za_batch_extension')
        ->where('status', 0)
        ->where('branch_id', $branch_id)
        ->count();

      $spamleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.status', 5)->count();

      $dropcourseapproval = DB::table('za_drop_refund')
        ->where('type', 0)
        ->whereYear('bh_status_date', $year)
        ->whereMonth('bh_status_date', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 1)
        ->where('bh_status', 0)->count();

      $refundapproval = DB::table('za_drop_refund')
        ->where('za_drop_refund.type', 1)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 0)->count();

      // Lead Details 
      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadcurrentCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadCount = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $lastMonthYear)
        ->whereMonth('registered_date', $lastMonth)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('internal_status', 0)
        ->count();

      // Calculate the percentage change
      if ($lastmonthLeadCount > 0) {
        $percentagelastlead = (($lastmonthLeadcurrentCount - $lastmonthLeadCount) / $lastmonthLeadCount) * 100;
      } else {
        $percentagelastlead = 0; // Avoid division by zero
      }

      $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $activeLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $spamLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();

      $deadLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();

      // sales team list 

      $salesStaff = DB::table('za_staff')
        ->select(
          'za_staff.sno',
          'za_staff.staff_name',
          'za_staff.staff_image',
          'za_staff.gender',
          'za_staff.branch_id',
          'za_staff.avaiable_points',
          'za_staff.mobile_no',
          'za_staff.lead_bank_count',
          'za_staff.status as staff_status'
        )
        ->where('za_staff.department_id', 1)
        ->where('za_staff.branch_id', $branch_id)
          ->where('za_staff.status', 0);


      $total_staffsales = $salesStaff->count();
      $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->get();


      $totalAverageBusinessValue = 0;
      $totalAverageCollectionValue     = 0;
      $totalAverageconvertRatio     = 0;
      $totalconvertRatio     = 0;
      $totalSpamLeadRatio     = 0;
      $totalDeadLeadRatio     = 0;
      $totalAllLead             = 0;
      $totalMonthLead            = 0;
      $totalconvertCustomer            = 0;
      $totalHotLead        = 0;
      $totalSpamLead      = 0;
      $totalDeadLead    = 0;

      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      foreach ($salesStaff as $staff) {

        $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();

        $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();

        $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.lead_status_id', 3)
          ->where('za_lead.internal_status', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.spam_verified', 0)
          ->count();

        $walkingcount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
          ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
          ->where('za_lead_appointment.status', 0)
          ->whereIn('za_lead.status', [0, 4])
          ->where('za_lead_appointment.branch_id', $branch_id)
          ->where('za_lead_appointment.staff_id', $staff->sno)
          ->where('za_lead_appointment.appointment_category', 'walk-in')
          ->whereYear('za_lead_appointment.appointment_date', $year)
          ->whereMonth('za_lead_appointment.appointment_date', $month)
          ->count();


        $outgoing_count = DB::table('za_call_tracker')
          ->select('za_call_tracker.branch_staff_id')
          ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
          ->whereYear('za_call_tracker.call_start_date', $year)
          ->whereMonth('za_call_tracker.call_start_date', $month)
          ->where('za_staff.branch_id', $branch_id)
          ->where('za_call_tracker.branch_staff_id', $staff->sno)
          ->where('za_staff.department_id', 1)
          ->where('za_call_tracker.call_status', 0)
          ->count();
        $avg_outgoing_call_rate = $dayCount > 0 ? round($outgoing_count / $dayCount) : 0;
        $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_lead.created_by', $staff->sno)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->count();

        $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.spam_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();

        $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.drop_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 5)->count();

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
            
            // Determine end date (if current month/year, use today; else end of the month)
            $endDate = ($currentDate->year == $year && $currentDate->month == $month)
                ? $currentDate
                : $startDate->copy()->endOfMonth();
            
            // Count working days (excluding Sundays)
            // $dayCounts = 0;
            // $dateIterate = $startDate->copy();
            
            // while ($dateIterate->lte($endDate)) {
            //     if (!$dateIterate->isSunday()) {
            //         $dayCount++;
            //     }
            //     $dateIterate->addDay();
            // }

        $presentDays = StaffAttendanceModel::where('staff_id', $staff->sno)
          ->where('branch_id', $branch_id)
          ->whereIn('attendance', ['P', 'PR','HD'])
          ->whereMonth('date', $month)
          ->whereYear('date', $year)
          ->count();
        $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

        // Spam Ratio 
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);

        // Dead ratio
        $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

        // customer ratio
        $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rate, 2);

        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);

        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;
        $averageBusinessValue      = 0;
        $averageCollectionValue    = 0;

        if ($customerConvertCount > 0) {
          $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->whereIn('za_customer.status',[0,6])
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_lead.created_by', $staff->sno)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->get();

          if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {

              $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.overall_fees');

              $total_payment += $payment;

              $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.paid_amount');

              $total_paid_payment += $paid_payment;
            }
          }


          // average 
          $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
          $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
          $totalAllPayment += $total_payment;
          $totalAllPaidPayment += $total_paid_payment;
        }

        $staff->allLeadCount           = $allLeadCount;
        $staff->monthLeadCount       = $monthLeadCount;
        $staff->hotLeadCount        = $hotLeadCount;
        $staff->customerConvertCount      = $customerConvertCount;
        $staff->spamLeadCount            = $spamLeadCount;
        $staff->deadLeadCount      = $deadLeadCount;
        $staff->spam_lead_ratio            = $spam_lead_ratio;
        $staff->dead_lead_ratio      = $dead_lead_ratio;
        $staff->convertion_rate   = $convertion_rate;
        $staff->averager_convertion_rate   = $averager_convertion_rate;
        $staff->averageBusinessValue = $averageBusinessValue;
        $staff->averageCollectionValue    = $averageCollectionValue;
        $staff->walkingcount    = $walkingcount;
        $staff->outgoing_count    = $avg_outgoing_call_rate;
        $staff->presentDays    = $presentDays;

        // total cal
        $totalAllLead             += $allLeadCount;
        $totalMonthLead            += $monthLeadCount;
        $totalHotLead        += $hotLeadCount;
        $totalconvertCustomer            += $customerConvertCount;
        $totalSpamLead      += $spamLeadCount;
        $totalDeadLead    += $deadLeadCount;
      }

      $totalBatch = DB::table('za_batch')
        ->where(function ($query) use ($year, $month) {
          $query->whereYear('end_date', '>', $year)
            ->orWhere(function ($query) use ($year, $month) {
              $query->whereYear('end_date', '=', $year)
                ->whereMonth('end_date', '>=', $month);
            });
        })
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->count();

      $totalBatchstudent = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->where(function ($query) use ($year, $month) {
          $query->whereYear('za_batch.end_date', '>', $year)
            ->orWhere(function ($query) use ($year, $month) {
              $query->whereYear('za_batch.end_date', '=', $year)
                ->whereMonth('za_batch.end_date', '>=', $month);
            });
        })
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->where('za_training.status', 0)
        ->count();

      $ongoingBatch = DB::table('za_batch')
        ->whereMonth('start_date', '>=', $month)
        ->whereYear('start_date', '>=', $year)
        ->whereDate('start_date', '<', $currentDate)
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->count();

      $ongoingBatchstudent = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->whereYear('za_batch.start_date', '>=', $year)
        ->whereMonth('za_batch.start_date', '>=', $month)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the 
        ->where('za_training.status', 0)
        ->count();

      $scheduleBatch = DB::table('za_batch')
        ->whereMonth('start_date', '>=', $month)
        ->whereYear('start_date', '>=', $year)
        ->whereDate('start_date', '>', $currentDate)
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->count();

      $scheduleBatchstudent = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->whereYear('za_training.start_date', '>=', $year)
        ->whereMonth('za_training.start_date', '>=',  $month)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->whereDate('za_batch.start_date', '>', $currentDate)
        ->where('za_training.status', 0)
        ->count();

      $unpaidBatchcount = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->whereYear('za_training.created_at', $year)
        ->whereMonth('za_training.created_at', $month)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->where('za_batch.status', 0)
        ->where('za_training.status', 0)
        ->where('za_training.paid_amount', '<', 8000) // Only where paid_amount is below 8000
        ->distinct('za_training.batch_id') // Ensure unique batch_id
        ->count('za_training.batch_id'); // Count unique batch_id


      $unpaidBatchstudent = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->whereYear('za_training.created_at', $year)
        ->whereMonth('za_training.created_at', $month)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->where('za_batch.status', 0)
        ->where('za_training.status', 0)
        ->where('za_training.paid_amount', '<', 8000) // Only where paid_amount is below 8000
        ->count();

      $completedBatchs = DB::table('za_batch')
        ->whereMonth('updated_at', $month)
        ->whereYear('updated_at', $year)
        ->where('branch_id', $branch_id)
        ->where('status', 3)
        ->count();

      $completedBatchstudent = DB::table('za_training')
        ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno') // Join batch table
        ->whereMonth('za_batch.updated_at', $month)
        ->whereYear('za_batch.updated_at', $year)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->where('za_batch.status', 3)
        ->where('za_training.status', 0)
        ->count();


      $batchextenCount = DB::table('za_batch_extension')
        ->where('status', 0)
        ->where('branch_id', $branch_id)
        ->whereMonth('end_date', $month)
        ->whereYear('end_date', $year)
        ->count();
      $studentbatchextenCount = DB::table('za_training')
        ->join('za_batch_extension', 'za_training.batch_id', '=', 'za_batch_extension.batch_id') // Join batch table
        ->whereMonth('za_batch_extension.end_date', $month)
        ->whereYear('za_batch_extension.end_date', $year)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_batch_extension.branch_id', $branch_id) // Ensure batch belongs to the branch
        ->where('za_batch_extension.status', 0)
        ->where('za_training.status', 0)
        ->count();


      //production staff 
      $total_staffproduction = StaffModel::where('za_staff.status', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)->count();

      $staffproduction = StaffModel::select(
        'za_staff.sno',
        'za_staff.staff_id',
        'za_staff.staff_name',
        'za_staff.gender',
        'za_staff.dob',
        'za_staff.mobile_no',
        'za_staff.email_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.knowledge_tag',
        'za_staff.per_hour_cost',
        'za_job_position.job_position_name',
        'za_staff.avaiable_points',
        'za_staff.basic_salary',
        'za_staff.status AS staff_status'
      )
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where('za_staff.status', '=', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
          'za_staff.sno',
          'za_staff.staff_id',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.dob',
          'za_staff.mobile_no',
          'za_staff.email_id',
          'za_staff.staff_image',
          'za_job_position.job_position_name',
          'za_staff.avaiable_points',
          'za_staff.nick_name',
          'za_staff.knowledge_tag',
          'za_staff.per_hour_cost',
          'za_staff.basic_salary',
          'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc')
        ->get();

      $staffproduction = $staffproduction->unique('staff_id');
      $total_batch = 0;
      $total_student = 0;
      $total_free_batch = 0;
      $total_staff = 0;
      $overall_earned = 0;
      $overall_earned_per = 0;
      $success_staff_count = 0;


      foreach ($staffproduction as $slotType) {

        $slotType->earned_amount = 0;
        $slotType->batch_count = 0;
        $slotType->student_count = 0;
        $slotType->present_count = 0;
        $slotType->course_count = 0;
        $slotType->slotDetails = [];
        $slotType->avg_amnt = 0;
        $slotType->salary = 0;
        $branchId = $branch_id;
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
          ? $currentDate
          : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $presentDays = StaffAttendanceModel::where('staff_id', $slotType->sno)
          ->where('branch_id', $branchId)
          ->where('attendance', 'P')
          ->whereMonth('date', $month)
          ->whereYear('date', $year)
          ->count();
        $presentDays =  $dayCount > 0 ? ($presentDays / $dayCount) * 100 : 0;
        $slotType->attendance_radio =  sprintf('%02d', $presentDays);

        $user_batch = BatchModel::select("za_batch.*", "za_course.course_name", "za_slot.start_time", "za_slot.end_time", "za_slot.slot_type_days")
          ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->where('za_batch.branch_id', $branch_id)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('za_batch.status', 0)
          // ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
          ->orderBy('za_slot.start_time')
          ->orderBy('za_slot.end_time')
          ->count();

        $slotType->user_batch =  sprintf('%02d', $user_batch);

        $ongoingBatch = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year)
          ->whereMonth('start_date', '<=', $month)
          ->whereDate('start_date', '>=', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 0)
          ->count();


        $slotType->ongoingBatch =  sprintf('%02d', $ongoingBatch);

        $ongoingstudent = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year)
          ->whereMonth('start_date', '<=', $month)
          ->whereDate('start_date', '>=', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 0)
          ->pluck('sno'); // Get an array of sno values

        $student_count = DB::table('za_training')
          ->whereIn('batch_id', $ongoingstudent) // Filter using batch_id
          ->distinct('customer_id') // Ensure uniqueness before counting
          ->count('customer_id');

        $slotType->ongoingstudent = sprintf('%02d', $student_count ?? 0); // Handle null case


        $completedstudent = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->whereMonth('end_date', $month)
          ->whereYear('end_date', $year)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 3)
          ->pluck('sno'); // Get an array of sno values

        $student_countcompletedstudent = DB::table('za_training')
          ->whereIn('batch_id', $completedstudent) // Filter using batch_id
          ->distinct('customer_id') // Ensure uniqueness before counting
          ->count('customer_id');

        $slotType->completedstudent = sprintf('%02d', $student_countcompletedstudent ?? 0); // Handle null case



        $completedBatch = DB::table('za_batch')
          ->where('branch_id', $branchId)
          ->where('za_batch.staff_id', $slotType->sno)
          ->where('status', 3)
          ->whereMonth('end_date', $month)
          ->whereYear('end_date', $year)
          ->count();
        $slotType->completedBatch =  sprintf('%02d', $completedBatch);



        $batchIds = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->distinct()
          ->pluck('batch_id')
          ->toArray();

        $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array

        $slotType->batch_ids = $batchIds; // Save batch IDs

        // return $slotType;

        foreach ($slotType->batch_ids as $batchId) {
          // Fetch the slot details for the slot type
          $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->pluck('batch_id'))
            ->where('za_batch.status', 0)
            ->get();

          // Fetch the batch details
          $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->find($batchId);

          if ($batch) {
            // Calculate the duration between start_time and end_time for the specific batch
            $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
            $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance

            $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
            $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
            // return $batchDurationInHours;
            // Get attendance records for the current batch

            $attendanceRecords = AttendanceModel::select('*')
              ->where('batch_id', $batch->sno)
              ->where('staff_id', $slotType->sno)
              ->where('attendance', 'P')
              ->whereMonth('att_date', '=', $month)
              ->whereYear('att_date', '=', $year)
              ->get();


            // Loop through the attendance records and calculate the earned amount
            foreach ($attendanceRecords as $attendance) {
              // Multiply the per_hr_cost by the batch duration (instead of slotType duration)
              $earnedAmountForAttendance = $attendance->per_hr_cost * $batchDurationInHours; // Use batch duration here
              $slotType->earned_amount += $earnedAmountForAttendance;  // Add to the total earned amount
            }
          }
        }


        // return $slotType;

        $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('customer_id')
          ->count('customer_id');

        $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('course_id')
          ->count('course_id');

        $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('batch_id')
          ->count('batch_id');


        $slotType->salary = $slotType->basic_salary * 10;

        if ($slotType->salary != 0) {
          $slotType->avg_amnt = ($slotType->earned_amount / $slotType->salary) * 100;
        } else {
          $slotType->avg_amnt = 0;  // or any other value you want in case of division by zero
        }


        $total_free_batch += 8 - $slotType->batch_count;
        $overall_earned += $slotType->earned_amount;

        $overall_earned_per += $slotType->avg_amnt;

        if ($slotType->salary < $slotType->earned_amount) {
          $success_staff_count++;  // Increment staff count who meet the condition
        }
        // return $slotType;    
      }
      $today = today();
      // Query to find staff who are not present today
      $staffNotAttendedCount = DB::table('za_staff')
        ->where('status', 0)
        ->where('branch_id', $branch_id)
        ->where('za_staff.position_role', '!=', 49)
        ->whereNotIn('sno', function ($query) use ($today) {
          $query->select('staff_id')
            ->from('za_staff_attendance')
            ->where('date', $today);
          // Use the correct branch_id
        })
        ->count();

      $reports = [

        'staffNotAttendedCount' => $staffNotAttendedCount,
        'actualdayLeadCount' => str_pad((string) ($actualdayLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualConversionCount' => $actualConversionCount,
        'actualConversionCountlast' => $actualConversionCountlast,
        'actualConversionRate' => round($actualConversionRate),
        'averageBusinessValue' => round($averageBusinessValueAll),
        'averageCollectionValue' => round($averageCollectionValueAll),
        'convertedCustomers'  => $convertedCustomers,
        'convertedCustomerslast'  => $convertedCustomerslast,
        'batchextensionCount'  => $batchextensionCount,
        'spamleadapproval' => $spamleadapproval,
        'dropcourseapproval' => $dropcourseapproval,
        'deadleadapproval'   => $deadleadapproval,
        'refundapproval'   => $refundapproval,
        'monthLeadCount'    => $monthLeadCount,
        'totalCustomerlast'  => $totalCustomerlast,
        'totalCustomer'  => $totalCustomer,
        'completedCustomerlast' => $completedCustomerlast,
        'completedCustomer'  => $completedCustomer,
        'dropCustomer' => $dropCustomer,
        'dropCustomerlast'  => $dropCustomerlast,
        'percentagelastlead'  => round($percentagelastlead),
        'activeLeadCount' => $activeLeadCount,
        'spamLeadCount'   => $spamLeadCount,
        'deadLeadCount'   => $deadLeadCount,
        'activeLeadCountlast' => round($activeLeadCountlast),
        'spamLeadCountlast' => round($spamLeadCountlast),
        'deadLeadCountlast' => round($deadLeadCountlast),
        'totalamount' => round($totalamount),
        'collectamount' => round($collectamount),
        'outstandingamount' => round($outstandingAmount),
        'staffcount' => $staffcount,
        'studentcount' => $studentcount,
        'P'  => $staffAttendanceDetails->where('attendance', 'P')->count(),
        'A'  => $staffAttendanceDetails->where('attendance', 'A')->count(),
        'L'  => $staffAttendanceDetails->where('attendance', 'L')->count(),
        'OD' => $staffAttendanceDetails->where('attendance', 'OD')->count(),
        'PM' => $staffAttendanceDetails->where('attendance', 'PM')->count(),
        'WO' => $staffAttendanceDetails->where('attendance', 'WO')->count(),
        'SP'  => $stundentAttendanceDetails->where('attendance', 'P')->count(),
        'SA'  => $stundentAttendanceDetails->where('attendance', 'A')->count(),
        'SL'  => $stundentAttendanceDetails->where('attendance', 'L')->count(),
        'SH'  => $stundentAttendanceDetails->where('attendance', 'L')->count(),
        'currentmonthtotalqueries' => round($current_month_total_queries),
        'currentmonthsolvedqueries' => round($current_month_solved_queries),
        'currentmonthpendingqueries' => round($current_month_pending_queries),
        'collectamountdaily' => round($collectamountdaily),
        'outstandingAmountdaily' => round($outstandingAmountdaily),
        'salesStaff' => $salesStaff,
        'total_staff' => str_pad((string) ($total_staffsales ?? '0'), 2, '0', STR_PAD_LEFT),
        'totalBatch' => $totalBatch,
        'totalBatchstudent' => $totalBatchstudent,
        'ongoingBatch' => $ongoingBatch,
        'ongoingBatchstudent' => $ongoingBatchstudent,
        'completedBatch' => str_pad((string) ($completedBatchs ?? '0'), 2, '0', STR_PAD_LEFT),
        'completedBatchstudent' => str_pad((string) ($completedBatchstudent ?? '0'), 2, '0', STR_PAD_LEFT),
        'scheduleBatch' => str_pad((string) ($scheduleBatch ?? '0'), 2, '0', STR_PAD_LEFT),
        'scheduleBatchstudent' => str_pad((string) ($scheduleBatchstudent ?? '0'), 2, '0', STR_PAD_LEFT),
        'unpaidBatchcount' => $unpaidBatchcount,
        'unpaidBatchstudent' => $unpaidBatchstudent,
        'batchextenCount' => $batchextenCount,
        'studentbatchextenCount' => $studentbatchextenCount,
        'total_staffproduction' => $total_staffproduction,
        'staffproduction' => $staffproduction,
      ];

      // return $reports;

      // Check if it's an AJAX request
      if ($request->ajax()) {
        return response()->json([
          'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
          'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
          'reports' => $reports
        ]);
      }

      return view('content.dashboard.bh_dashboard', compact('branch_common', 'role_user', 'role_permission', 'user_details_dashboard', 'selectedMonth', 'reports'));
    }
    //else
    else if ($user->role_id == 14) {

      $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));

      // $selectedMonth = '2025-08';
      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where('za_staff.sno', $user->user_id)->first();

      $branch_id = $user->branch_id;
      $currentday = Carbon::today()->toDateString(); // Get current date in YYYY-MM-DD format

      [$year, $month] = explode('-', $selectedMonth);

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $user_details_dashboard->department_id)->where('za_goal_set_staff.branch_id', $branch_id)
        ->whereMonth('za_goal_set_staff.goal_date', $month)->where('za_goal_set_staff.staff_id', $user_details_dashboard->sno)
        ->whereYear('za_goal_set_staff.goal_date', $year)
        ->first();
      
      $branch = BranchModel::where('sno', $branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();

      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

      $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();

      $currentMonth = $month;
      $currentYear  = $year;

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

      $dayCounts = 0;
      $dateSrt = $startDate->copy();
      
      while ($dateSrt->lte($endDate)) {
        if (!$dateSrt->isSunday()) {
          $dayCounts++;
        }
        $dateSrt->addDay();
      }

      $startDateold = $startDate->copy()->subYears(20)->startOfMonth();
      $endDateold = $startDate->copy()->subMonth()->endOfMonth(); // exclude current month

      $presentDays = StaffAttendanceModel::where('staff_id',$user_details_dashboard->sno)
        ->where('branch_id', $branch_id)
        ->whereIn('attendance', ['P', 'HD'])
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();

      $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

      $dropoutCustomers = DB::table('za_training')->where('status', 2)->pluck('customer_id')->toArray();

      $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])->where('za_customer.branch_id', $branch_id)->whereNotIn('za_customer.sno', $dropoutCustomers)->whereBetween('za_customer.created_at', [$startDateold, $endDateold])->pluck('za_customer.sno')->toArray();

      $hacAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
        ->where('za_payment.status', 1) // paid amoun
        ->whereYear('za_payment.initialPayDate', $year)
        ->whereMonth('za_payment.initialPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.paidAmount');

      $sumScheduleAmount = DB::table('za_payment')
      ->where('za_payment.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      ->whereDate('za_payment.nextPayDate', $currentday)
      ->sum('za_payment.amount');
      
      $drop_payment_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->pluck('za_training.payment_id');

      $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->whereNotIn('za_payment.payment_id', $drop_payment_ids)
        ->where('za_payment.status', 0)
        // ->where('za_payment.reschedule_payment', 0)
        ->where('za_customer.status', 0)
        ->whereDate('za_payment.nextPayDate', '<=', $currentday)
        ->orderBy('za_payment.sno', 'asc')->count();

      $outstandingAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_payment_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereDate('za_payment.nextPayDate', '<=', $currentday)
        ->sum('za_payment.amount');

      $TodayPayment_query = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->select(
            'za_payment.payment_id',
            'za_payment.sno as payment_sno',
            'za_payment.branch_id',
            'za_customer.customer_id',
            'za_customer.sno as customer_sno',
            'za_course.course_id',
            'za_payment.initialPayDate',
            'za_payment.nextPayDate',
            'za_payment.amount',
            'za_payment.paidAmount',
            'za_payment.gst_amount',
            'za_payment.balanceFee',
            'za_payment.total_amount',
            'za_payment.payment_mode_label',
            'za_payment.status as payment_status',
            'za_customer.cus_name',
            'za_customer.cus_pic',
            'za_customer.cus_mobile',
            'za_customer.cus_gender',
            'za_customer.cus_email_id',
            'za_customer.jumper_skiper',
            'za_training.training_id',
            'za_course.course_name',
            'za_course.sno as course_sno'
        )
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_training.status', 0)
        ->where('za_payment.amount', '>', 0)
        ->whereDate('za_payment.nextPayDate', $currentday)
        ->distinct('za_customer.customer_id') // ✅ better than distinct
        ->orderBy('za_payment.sno', 'desc');

      // ✅ Count before pagination
      $TodayPaymentCount = $TodayPayment_query->count();

      // ✅ Pagination
      $TodayPayment = $TodayPayment_query->paginate(10);

      $common_date_format = $genaral_settings->date_format ?? 'd-M-y';

      // ✅ Backend loop
      $today_payments_list = [];
      if($TodayPaymentCount > 0){
        foreach ($TodayPayment as $row) {
          $today_payments_list[] = [
            // 'payment_id'   => $row->payment_id,
            'customer_name'     => isset($row->cus_name) && !empty($row->cus_name) ? $row->cus_name : null,
            'customer_mobile'   => isset($row->cus_mobile) && !empty($row->cus_mobile) ? $row->cus_mobile : null,
            'customer_id'       => isset($row->customer_id) && !empty($row->customer_id) ? $row->customer_id : null,
            'course_name'       => isset($row->course_name) && !empty($row->course_name) ? $row->course_name : null,
            'training_id'       => isset($row->training_id) && !empty($row->training_id) ? $row->training_id : null,
            'nextPayDate'       => isset($row->nextPayDate) && !empty($row->nextPayDate) ? date($common_date_format, strtotime($row->nextPayDate)) : null,
            'schedule_amount'   => isset($row->amount) && !empty($row->amount) ? $row->amount : 0,
            'balance_amount'    => isset($row->balanceFee) && !empty($row->balanceFee) ? $row->balanceFee : 0,
          ];
        }
      }

      $currentMonthStart = now()->startOfMonth();
      $currentMonthEnd = now()->endOfMonth();
      $nextMonthStart = now()->addMonth()->startOfMonth();
      $nextMonthEnd = now()->addMonth()->endOfMonth();
      $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();

      $drop_cust_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_drop_refund.branch_id', $branch_id)
        ->pluck('za_training.customer_id');

      // Current Month
      $currentMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_cust_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$currentMonthStart, $currentMonthEnd])
        ->sum('za_payment.amount');
    
      // Next Month
      $nextMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_cust_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$nextMonthStart, $nextMonthEnd])
        ->sum('za_payment.amount');
    
      // Greater than 3 Months
      $greaterThanThreeMonthsAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_cust_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->where('za_payment.nextPayDate', '>=', $threeMonthsLaterStart)
        ->sum('za_payment.amount');

      $overOutstandingPayment_query = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->select(
          'za_training.training_id',
          \DB::raw('MAX(za_payment.payment_id) AS payment_id'),
          \DB::raw('MAX(za_training.sno) AS tran_sno'),
          \DB::raw('MAX(za_training.batch_id) AS batch_id'),
          \DB::raw('MAX(za_payment.sno) AS payment_sno'),
          \DB::raw('MAX(za_payment.branch_id) AS branch_id'),
          \DB::raw('MAX(za_customer.customer_id) AS customer_id'),
          \DB::raw('MAX(za_customer.sno) AS customer_sno'),
          \DB::raw('MAX(za_course.course_id) AS course_id'),
          \DB::raw('MAX(za_payment.initialPayDate) AS initialPayDate'),
          \DB::raw('MAX(za_payment.nextPayDate) AS nextPayDate'),
          \DB::raw('MAX(za_payment.amount) AS amount'),
          \DB::raw('MAX(za_payment.paidAmount) AS paidAmount'),
          \DB::raw('MAX(za_payment.gst_amount) AS gst_amount'),
          \DB::raw('MAX(za_payment.balanceFee) AS balanceFee'),
          \DB::raw('MAX(za_payment.total_amount) AS total_amount'),
          \DB::raw('MAX(za_payment.payment_mode_label) AS payment_mode_label'),
          \DB::raw('MAX(za_payment.status) AS payment_status'),
          \DB::raw('MIN(za_customer.cus_name) AS cus_name'),
          \DB::raw('MAX(za_customer.cus_pic) AS cus_pic'),
          \DB::raw('MAX(za_customer.cus_gender) AS cus_gender'),
          \DB::raw('MAX(za_customer.jumper_skiper) AS jumper_skiper'),
          \DB::raw('MAX(za_customer.cus_mobile) AS cus_mobile'),
          \DB::raw('MAX(za_customer.cus_email_id) AS cus_email_id'),
          \DB::raw('MAX(za_customer.status) AS cus_status'),
          \DB::raw('MAX(za_course.course_name) AS course_name'),
          \DB::raw('MAX(za_course.sno) AS course_sno'),
          \DB::raw('MAX(za_staff.staff_name) AS pro_staff_name')
        )
        ->whereNotIn('za_payment.customer_id', $drop_cust_ids)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount', '>',0)
        ->where('za_customer.status', 0)
        ->whereDate('za_payment.nextPayDate', '<=', $currentday)
        ->groupBy('za_training.training_id')
        ->orderBy('za_payment.nextPayDate', 'DESC')->paginate(10);

      // ✅ Count before pagination
      $overOutstandingPaymentCount = $overOutstandingPayment_query->total();
      // return $overOutstandingPaymentCount;

      // ✅ Pagination
      // $overOutstandingPayment = $overOutstandingPayment_query->paginate(10);

      // ✅ Backend loop
      $today_outstanding_payments_list = [];
      if($overOutstandingPaymentCount > 0){
        foreach ($overOutstandingPayment_query as $row) {
          $today_outstanding_payments_list[] = [
            // 'payment_id'   => $row->payment_id,
            'customer_name'     => isset($row->cus_name) && !empty($row->cus_name) ? $row->cus_name : null,
            'customer_mobile'   => isset($row->cus_mobile) && !empty($row->cus_mobile) ? $row->cus_mobile : null,
            'customer_id'       => isset($row->customer_id) && !empty($row->customer_id) ? $row->customer_id : null,
            'course_name'       => isset($row->course_name) && !empty($row->course_name) ? $row->course_name : null,
            'nextPayDate'       => isset($row->nextPayDate) && !empty($row->nextPayDate) ? date($common_date_format, strtotime($row->nextPayDate)) : null,
            'schedule_amount'   => isset($row->amount) && !empty($row->amount) ? $row->amount : 0,
            'balance_amount'    => isset($row->balanceFee) && !empty($row->balanceFee) ? $row->balanceFee : 0,
          ];
        }
      }

      $min = $branch->min_prd_cost ?? 0;

        // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_training')
        ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
        ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
        ->select(
            'za_customer.customer_id',
            'za_payment.course_id',
            'za_customer.sno as customer_sno',
            'za_course.sno as course_sno',
            'za_customer.cus_name',
            'za_customer.cus_gender',
            'za_customer.cus_pic',
            'za_customer.cus_mobile',
            'za_customer.cus_email_id',
            'za_course.course_name',
            'za_staff.staff_name',
            'za_training.training_id',
            'za_training.batch_id',
            'za_training.payment_id',
            'za_payment.initialPayDate',
            'za_training.paid_amount as total_paid_amount',
            'za_training.balance_amount as total_balance_fee',
            'za_training.overall_fees as total_amount',
            DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
            'za_payment.payment_mode_label',
            'za_payment.nextPayDate'
        )
        ->where('za_payment.branch_id', $branch_id)
        ->whereNotIn('za_customer.sno', $drop_cust_ids)
        ->where('za_training.status', '!=',2)
        ->where(function ($q) use ($min) {
            $q->where('za_training.overall_fees', '>', $min)
                ->orWhere(function ($q2) use ($min) {
                    $q2->where('za_training.overall_fees', '<=', $min)
                        ->whereColumn('za_training.overall_fees', '!=', 'za_training.paid_amount');
                });
        })
        ->groupBy(
            'za_customer.customer_id',
            'za_customer.sno',
            'za_course.sno',
            'za_customer.cus_name',
            'za_customer.cus_mobile',
            'za_customer.cus_pic',
            'za_customer.cus_gender',
            'za_customer.cus_email_id',
            'za_course.course_name',
            'za_training.training_id',
            'za_training.payment_id',
            'za_staff.staff_name',
            'za_training.batch_id',
            'za_training.paid_amount',
            'za_training.balance_amount',
            'za_training.overall_fees',
            'za_payment.payment_mode_label',
            'za_payment.nextPayDate',
            'za_payment.initialPayDate',
            'za_payment.course_id'
        )
        ->orderBy('za_payment.nextPayDate', 'asc')
        ->get()
        ->unique('payment_id'); 
        
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->total_paid_amount < $branch->min_prd_cost;
      });

      // Group by customer_id
      $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {

          // Filter payments where paidAmount is greater than 0
          $filteredPayments = $payments->filter(function ($payment) {
              return $payment->total_paid_amount > 0;
          });

          // If no valid payments exist after filtering, exclude this customer
          if ($filteredPayments->isEmpty()) {
              return null;
          }

          $payment = $payments->first();

          // Return structured data for each customer
          return [
              'customer_name' => $payment->cus_name,
              'customer_sno' => $payment->customer_sno,
              'total_paid' => $payment->total_paid_amount,
              'min_required' => $branch->min_prd_cost,
              'status' => 'Pending',
              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                  return [
                      'course_name' => $payment->course_name,
                      'cus_gender' => $payment->cus_gender,
                      'cus_pic' => $payment->cus_pic,
                      'staff_name' => $payment->staff_name,
                      'batch_id' => $payment->batch_id,
                      'training_id' => $payment->training_id,
                      'payment_id' => $payment->payment_id,
                      'cus_name' => $payment->cus_name,
                      'cus_mobile' => $payment->cus_mobile,
                      'amount' => $payment->total_amount,
                      'paidAmount' => $payment->total_paid_amount,
                      'balanceFee' => $payment->total_balance_fee,
                      'gst_amount' => $payment->total_gst_amount,
                      'nextPayDate' => $payment->nextPayDate,
                      'initialPayDate' => $payment->initialPayDate,
                      'payment_mode_label' => $payment->payment_mode_label,
                  ];
              })->values(), // Reset array keys
          ];
      })->filter();

      // Paginate the results
      // $paginatedResult = $finalResult->slice(($page - 1) * 10, 10);

      // Calculate the total number of pages
      $totalItems = $finalResult->count();

      // ✅ Backend loop
      $low_mpc_payments_list = [];
      if($totalItems > 0) {
        foreach ($finalResult as $row) {
          foreach ($row['payments'] as $row_pay) {
            $low_mpc_payments_list[] = [
              // 'payment_id'   => $row->payment_id,
              'customer_name'     => isset($row_pay['cus_name']) && !empty($row_pay['cus_name']) ? $row_pay['cus_name'] : null,
              'customer_mobile'   => isset($row_pay['cus_mobile']) && !empty($row_pay['cus_mobile']) ? $row_pay['cus_mobile'] : null,
              'course_name'       => isset($row_pay['course_name']) && !empty($row_pay['course_name']) ? $row_pay['course_name'] : null,
              'registered_date'       => isset($row_pay['initialPayDate']) && !empty($row_pay['initialPayDate']) ? date($common_date_format, strtotime($row_pay['initialPayDate'])) : null,
              'schedule_amount'   => isset($row_pay['amount']) && !empty($row_pay['amount']) ? $row_pay['amount'] : 0,
              'paid_amount'    => isset($row_pay['paidAmount']) && !empty($row_pay['paidAmount']) ? $row_pay['paidAmount'] : 0,
            ];
          }
        }
      }

      $reports = [
        'presentDays' => $presentDays,
        'actual_amount' => $hacAmount,
        'sum_schedule_amount' => $sumScheduleAmount,
        'outstanding_payment_count' => $OutstandingPayment,
        'outstanding_payment_amount' => $outstandingAmount,
        'today_payments_list' => $today_payments_list,
        'today_payments_count' => $TodayPaymentCount,
        'currentDate' => $currentday,
        'current_month_outstanding_amount' => $currentMonthAmount,
        'next_month_outstanding_amount' => $nextMonthAmount,
        'upcoming_month_outstanding_amount' => $greaterThanThreeMonthsAmount,
        'overall_outstanding_count' => $overOutstandingPaymentCount,
        'overall_outstanding_list' => $today_outstanding_payments_list,
        'total_low_mpc_count' => $totalItems,
        'total_low_mpc_list' => $low_mpc_payments_list,
      ];

      // Check if it's an AJAX request
      if ($request->ajax()) {
        return response()->json([
          'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
          'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
          'user_details_dashboard' => $user_details_dashboard,
          'goalsetData' => $goalsetRecords,
          'reports' => $reports
        ]);
      }

      return view('content.dashboard.collection_executive_dashboard',[
        'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
        'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
        'user_details_dashboard' => $user_details_dashboard,
        'goalsetData' => $goalsetRecords,
        'reports' => $reports
      ]);
    }
    else {
      return view('content.dashboard.dashboards-analytics', compact('branch_common', 'role_user', 'role_permission'));
    }
  }
  public function dashboards_team(Request $request)
  {

    // Initialize variables
    $branch_common = null;
    $role_user = null;
    $role_permission = null;
    $user = Auth::user();
    if ($user) {
      $branch_common   = BranchModel::where('sno', $user->branch_id)->first();
      $role_user       = UserRoleModel::where('sno', $user->role_id)->first();
      $role_permission = UserRolePermissionModel::where('role_id', $user->role_id)->first();
    }
    $user_details_dashboard = StaffModel::where('sno', $user->user_id)->first();
    // Get sales tl self and team
    if ($user->role_id == 12) {
      // Get the selected month from request, default to the current month
      $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
      $user_details_dashboard = StaffModel::select('za_staff.*', 'za_job_position.job_position_name')
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where('za_staff.sno', $user->user_id)->first();
      $branch_id = $user->branch_id;
      $currentDate = Carbon::today()->toDateString(); // Get current date in YYYY-MM-DD format
      //  return $user_details_dashboard;
      [$year, $month] = explode('-', $selectedMonth);

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;
      $totalamountoriginal = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      $totalamountold = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereYear('za_old_payments.schedule_date', $year)
        ->whereMonth('za_old_payments.schedule_date', $month)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      $totalamount = $totalamountoriginal + $totalamountold;

      $collectamount = TransactionModel::where('branch_id', $branch_id)
        ->whereMonth('created_at', $month)
        ->whereYear('created_at', $year) // Added a comma after 'created_at'
        ->sum('credit');


      $outstandingAmount = $totalamount - $collectamount;

      // Daily Reports Status
      $staffcount = StaffModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $staffAttendanceDetails = StaffAttendanceModel::where('branch_id', $branch_id)->whereDate('date', $currentDate)->get();

      $studentcount = CustomerModel::where('branch_id', $branch_id)->where('status', 0)->count();

      $stundentAttendanceDetails = AttendanceModel::where('branch_id', $branch_id)->whereDate('att_date', $currentDate)->get();

      $current_month_total_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        // ->where('status', 0)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_solved_queries = IssueNoteModel::select('*')
        ->where('branch_id', $user->branch_id)
        ->where('status', 2)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->count();

      $current_month_pending_queries = $current_month_total_queries - $current_month_solved_queries;

      $totalamountoriginaldaily = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereIn('za_customer.status',[0,6])
        ->whereDate('za_payment.nextPayDate', $currentDate)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.amount');

      $totalamountolddaily = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->where('za_old_customer.branch_id', $branch_id)
        ->where('za_old_customer.status', 0)
        ->whereDate('za_old_payments.schedule_date', $currentDate)
        ->where('za_old_payments.branch_id', $branch_id)
        ->sum('za_old_payments.amount');

      $totalamountdaily = $totalamountoriginaldaily + $totalamountolddaily;

      $collectamountdaily = TransactionModel::where('branch_id', $branch_id)
        ->whereDate('created_at', $currentDate)
        ->sum('credit');


      // $outstandingAmount = $outstandingAmountoriginal + $outstandingAmountold;
      $outstandingAmountdaily = $totalamountdaily - $collectamountdaily;

      //top cr,cc,abv abc values

      $actualMonthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_staff.department_id', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.internal_status', 0)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->count();


      $actualConversionCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $year)
        ->where('za_staff.department_id', 1)
        ->whereMonth('za_customer.created_at', $month)
        ->count();

      $actualConversionCountdaily = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $year)
        ->where('za_staff.department_id', 1)
        ->whereMonth('za_customer.created_at', $month)
        ->whereDate('za_customer.created_at', $currentDate)
        ->count();

      $actualConversionCountold = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereYear('za_customer.created_at', $lastMonthYear)
        ->where('za_staff.department_id', 1)
        ->whereMonth('za_customer.created_at', $lastMonth)
        ->count();

      $actualdayLeadCount = DB::table('za_customer')->select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_customer.branch_id', $branch_id)
        ->whereDate('za_customer.created_at', $currentDate)
        ->where('za_staff.department_id', 1)
        ->count();

      $actualConversionRate = $actualMonthLeadCount > 0 ? ($actualConversionCount / $actualMonthLeadCount) * 100 : 0;
      $actualConversionRate = number_format($actualConversionRate, 2);


      if ($actualConversionCount > 0) {
        $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
          ->where('za_staff.department_id', 1)
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->get();

        $total_payment = 0;
        $total_paid_payment = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {

            $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.overall_fees');

            $total_payment += $payment;

            $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.paid_amount');

            $total_paid_payment += $paid_payment;
          }
        }

        $averageBusinessValue = 0;
        $averageCollectionValue = 0;
        // average
        $averageBusinessValue   = $actualConversionCount > 0 ? $total_payment / $actualConversionCount : 0;
        $averageCollectionValue = $actualConversionCount > 0 ? $total_paid_payment / $actualConversionCount : 0;
      }

      // Date range calculation
      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;

      // Approval Reports Status

      $batchextensionCount = DB::table('za_batch_extension')
        ->where('status', 0)
        ->where('branch_id', $branch_id)
        ->count();

      $spamleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadleadapproval = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.status', 5)->count();

      $dropcourseapproval = DB::table('za_drop_refund')
        ->where('type', 0)
        ->whereYear('bh_status_date', $year)
        ->whereMonth('bh_status_date', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 1)
        ->where('bh_status', 0)->count();

      $refundapproval = DB::table('za_drop_refund')
        ->where('za_drop_refund.type', 1)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->where('branch_id', $branch_id)
        ->where('bh_status', 0)->count();

      // Lead Details


      $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $monthLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadcurrentCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $lastmonthLeadCount = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $lastMonthYear)
        ->whereMonth('registered_date', $lastMonth)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('internal_status', 0)
        ->count();

      // Calculate the percentage change
      if ($lastmonthLeadCount > 0) {
        $percentagelastlead = (($lastmonthLeadcurrentCount - $lastmonthLeadCount) / $lastmonthLeadCount) * 100;
      } else {
        $percentagelastlead = 0; // Avoid division by zero
      }

      $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $activeLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.status', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();


      $spamLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();


      $deadLeadCountlast = DB::table('za_lead')->select('za_lead.sno')
        ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
        ->whereYear('za_lead.registered_date', $lastMonthYear)
        ->whereMonth('za_lead.registered_date', $lastMonth)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.status', 5)->count();

      //lead_appointment

      $dayAppointmentList = DB::table('za_lead_appointment')
        ->select(
          'za_lead_appointment.sno',
          'za_lead.lead_name',
          'za_staff.staff_name',
          DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%d-%b-%Y') as appointment_date"),
          DB::raw("DATE_FORMAT(za_lead_appointment.appointment_date, '%h:%i %p') as appointment_time"),
          'za_lead_appointment.appointment_category',
          'za_lead_appointment.appointment_status',
          'za_lead.lead_gender'
        )
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->get();


      $dailyWalkinCount = 0;
      foreach ($dayAppointmentList as $appointment) {
        $walkin_status = 0;
        if ($appointment->appointment_category == 'walk-in') {
          $dailyWalkinCount++;
          $walkin_status = 1;
        } else {
          $walkin_status = 0;
        }
        $appointment->walkin_status = $walkin_status;
      }


      $dailyFollowup = DB::table('za_appointment')->select('za_lead.lead_name', 'za_staff.staff_name', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status', 'za_appointment.progressed', 'za_lead.lead_gender')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        // ->whereDay('za_appointment.appointment_date', date('d'))
        ->get();

      $dailyFollowupCount = count($dailyFollowup);
      foreach ($dailyFollowup as $appointment) {
        if ($appointment->status == '1' && $appointment->progressed == '2') {
          $followup_status = 'Reschedule';
        } else if ($appointment->status == '4') {
          $followup_status = 'Completed';
        }
        $appointment->followup_status = $followup_status ?? "";
        $appointment->staff_name = $appointment->staff_name ?? "N/A";
      }
      // dd($dailyFollowup->toArray());
      // return response()->json($dailyFollowup);
      // Get branch details
      $branch = BranchModel::where('sno', $branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
      // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.created_by')
        ->join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->select(
          'za_customer.customer_id',
          'za_payment.course_id',
          'za_customer.sno as customer_sno',
          'za_course.sno as course_sno',
          'za_customer.cus_name',
          'za_customer.cus_gender',
          'za_customer.cus_pic',
          'za_staff.staff_name',
          'za_customer.cus_mobile',
          'za_customer.cus_email_id',
          'za_course.course_name',
          'za_training.training_id',
          'za_training.payment_id',
          DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
          DB::raw('SUM(za_payment.balanceFee) as total_balance_fee'),
          DB::raw('SUM(za_payment.amount) as total_amount'),
          DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
          DB::raw('DATEDIFF(za_payment.nextPayDate, CURDATE()) as days_left'), // Calculate days left
          'za_payment.payment_mode_label',
          'za_payment.nextPayDate'
        )
        ->where('za_payment.branch_id', $branch_id)
        ->whereYear('za_payment.nextPayDate', $year)
        ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.status', 0)
        ->groupBy(
          'za_customer.customer_id', // Group by customer_id to ensure uniqueness
          'za_customer.sno',
          'za_course.sno',
          'za_customer.cus_name',
          'za_customer.cus_mobile',
          'za_customer.cus_pic',
          'za_customer.cus_gender',
          'za_customer.cus_email_id',
          'za_staff.staff_name',
          'za_course.course_name',
          'za_training.training_id',
          'za_training.payment_id',
          'za_payment.payment_mode_label',
          'za_payment.nextPayDate',
          'za_payment.course_id'

        )
        ->orderByDesc('za_payment.sno')
        ->get();

      // Filter the results for customers with unpaid or insufficient amounts (below min_required)

      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
        return $payment->total_paid_amount < ($branch?->min_prd_cost ?? 8000);
      });

      $finalResult = collect(); // Initialize as an empty collection to prevent undefined errors

      if (!$result->isEmpty()) {
        $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          $payment = $payments->first();

          $filteredPayments = $payments->filter(function ($payment) {
            return $payment->total_paid_amount > 0;
          });

          if ($filteredPayments->isEmpty()) {
            return null;
          }

          return [
            'customer_name' => $payment->cus_name,
            'staff_name' => $payment->staff_name,
            'cus_pic' => $payment->cus_pic,
            'customer_sno' => $payment->customer_sno,
            'total_paid' => $payment->total_paid_amount,
            'min_required' => $branch->min_prd_cost,
            'status' => 'Pending',
            'payments' => $filteredPayments->map(function ($payment) {
              return [
                'course_name' => $payment->course_name,
                'cus_gender' => $payment->cus_gender,
                'cus_pic' => $payment->cus_pic,
                'training_id' => $payment->training_id,
                'payment_id' => $payment->customer_id,
                'cus_name' => $payment->cus_name,
                'cus_mobile' => $payment->cus_mobile,
                'amount' => $payment->total_amount,
                'paidAmount' => $payment->total_paid_amount,
                'balanceFee' => $payment->total_balance_fee,
                'gst_amount' => $payment->total_gst_amount,
                'nextPayDate' => $payment->nextPayDate,
                'days_left' => $payment->days_left, // Include days left
                'payment_mode_label' => $payment->payment_mode_label,
              ];
            })->values(),
          ];
        })->filter();
      }

      $finalResultcount = $finalResult->count();


      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;

      // Get the last month's values
      $lastMonthYear = ($month == 1) ? $year - 1 : $year;
      $lastMonth = ($month == 1) ? 12 : $month - 1;

      $lastMonthCrn = Carbon::createFromDate($lastMonthYear, $lastMonth, 1);
      $lstMnthStartDate = $lastMonthCrn->copy()->startOfMonth();
      $lstMnthEndDate = $lastMonthCrn->copy()->endOfMonth();
      $lastMonthDayCount = $lstMnthStartDate->diffInDays($lstMnthEndDate) + 1;

      // average Appointment
      $monthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      $avg_appointment = $dayCount > 0 ? round($monthAppointmentCount / $dayCount) : 0;

      // Average Followup
      $monthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        ->count();

      $avg_folllowup = $dayCount > 0 ? round($monthFollowupCount / $dayCount) : 0;

      // average Walkin
      $monthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->where('za_lead_appointment.appointment_category', 'Walk-in')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      $avg_walkin = $dayCount > 0 ? round($monthWalkinCount / $dayCount) : 0;

      // Average Outgoing Call
      $monthOutgoingCallCount = DB::table('za_call_tracker')
        ->select('za_call_tracker.branch_staff_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_staff.department_id', 1)
        ->where('za_call_tracker.call_status', 0)
        ->count();

      $avg_outgoing_call = $dayCount > 0 ? round($monthOutgoingCallCount / $dayCount) : 0;


      // last average Appointment
      $lastMonthAppointmentCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_appointment = $lastMonthDayCount > 0 ? round($lastMonthAppointmentCount / $lastMonthDayCount) : 0;

      // last Average Followup
      $lastMonthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->whereYear('za_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_folllowup = $lastMonthDayCount > 0 ? round($lastMonthFollowupCount / $lastMonthDayCount) : 0;

      //last average Walkin
      $lastMonthWalkinCount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.status', 0)
        ->where('za_lead_appointment.appointment_category', 'Walk-in')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_lead_appointment.branch_id', $branch_id)
        ->whereYear('za_lead_appointment.appointment_date', $lastMonthYear)
        ->whereMonth('za_lead_appointment.appointment_date', $lastMonth)
        ->count();

      $avg_last_walkin = $lastMonthDayCount > 0 ? round($lastMonthWalkinCount / $lastMonthDayCount) : 0;

      // Average Outgoing Call
      $lastMonthOutgoingCallCount = DB::table('za_call_tracker')
        ->select('za_call_tracker.branch_staff_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->whereYear('za_call_tracker.call_start_date', $lastMonthYear)
        ->whereMonth('za_call_tracker.call_start_date', $lastMonth)
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_staff.department_id', 1)
        ->where('za_call_tracker.call_status', 0)
        ->count();

      $avg_last_outgoing_call = $lastMonthDayCount > 0 ? round($lastMonthOutgoingCallCount / $lastMonthDayCount) : 0;




      // Fetch all lead sources
      $leadSources = DB::table('za_lead_source')->get();

      // Get total lead count for the year
      $totalLeads = DB::table('za_lead')
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('internal_status', '!=', 1)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('created_by', '>', 0)
        ->count();

      // Get lead count per source
      $leadData = DB::table('za_lead')
        ->select('za_lead_source.lead_source_name', DB::raw('COUNT(za_lead.lead_source_id) as lead_count'))
        ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.internal_status', '!=', 1)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.created_by', '>', 0)
        ->groupBy('za_lead_source.lead_source_name')
        ->get();

      // Add percentage calculation
      foreach ($leadData as $lead) {
        $lead->percentage = ($totalLeads > 0) ? round(($lead->lead_count / $totalLeads) * 100) : 0;
      }

      // Ensure $results is a collection
      $leadDatacount = count($leadData);


      // sales team list

      $salesStaff = DB::table('za_staff')
        ->select(
          'za_staff.sno',
          'za_staff.staff_name',
          'za_staff.staff_image',
          'za_staff.gender',
          'za_staff.branch_id',
          'za_staff.mobile_no',
          'za_staff.lead_bank_count',
          'za_staff.status as staff_status'
        )
        ->where('za_staff.department_id', 1)
        ->where('za_staff.branch_id', $branch_id)
        ->where(function ($query) use ($year, $month) {
          // Add conditions for status 4
          $query->where(function ($query) use ($year, $month) {
            $query->where('za_staff.status', 4)
              ->whereYear('za_staff.notice_end_date', '>=', $year)
              ->whereMonth('za_staff.notice_end_date', '>=', $month);
          })
            // Add conditions for status 5
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 5)
                ->whereYear('za_staff.updated_at', '>=', $year)
                ->whereMonth('za_staff.updated_at', '>=', $month);
            })
            // Add conditions for status 6
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 6)
                ->whereYear('za_staff.staff_last_date', '>=', $year)
                ->whereMonth('za_staff.staff_last_date', '>=', $month);
            })
            // Add conditions for status 7
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 7)
                ->whereYear('za_staff.updated_at', '>=', $year)
                ->whereMonth('za_staff.updated_at', '>=', $month);
            })
            // Include status 0 regardless of date
            ->orWhere('za_staff.status', 0);
        });


      $total_staffsales = $salesStaff->count();
      $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->get();


      $totalAverageBusinessValue = 0;
      $totalAverageCollectionValue     = 0;
      $totalAverageconvertRatio     = 0;
      $totalconvertRatio     = 0;
      $totalSpamLeadRatio     = 0;
      $totalDeadLeadRatio     = 0;
      $totalAllLead             = 0;
      $totalMonthLead            = 0;
      $totalconvertCustomer            = 0;
      $totalHotLead        = 0;
      $totalSpamLead      = 0;
      $totalDeadLead    = 0;

      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      foreach ($salesStaff as $staff) {

        $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();

        $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();

        $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.lead_status_id', 3)
          ->where('za_lead.internal_status', 0)
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->count();

        $walkingcount = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')
          ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
          ->where('za_lead_appointment.status', 0)
          ->whereIn('za_lead.status', [0, 4])
          ->where('za_lead_appointment.branch_id', $branch_id)
          ->where('za_lead_appointment.staff_id', $staff->sno)
          ->where('za_lead_appointment.appointment_category', 'walk-in')
          ->whereYear('za_lead_appointment.appointment_date', $year)
          ->whereMonth('za_lead_appointment.appointment_date', $month)
          ->count();


        $outgoing_count = DB::table('za_call_tracker')
          ->select('za_call_tracker.branch_staff_id')
          ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
          ->whereYear('za_call_tracker.call_start_date', $year)
          ->whereMonth('za_call_tracker.call_start_date', $month)
          ->where('za_staff.branch_id', $branch_id)
          ->where('za_call_tracker.branch_staff_id', $staff->sno)
          ->where('za_staff.department_id', 1)
          ->where('za_call_tracker.call_status', 0)
          ->count();
        $avg_outgoing_call_rate = $dayCount > 0 ? round($outgoing_count / $dayCount) : 0;

        $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_lead.created_by', $staff->sno)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->count();

        $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.spam_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();

        $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.drop_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 5)->count();

        // Spam Ratio
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);

        // Dead ratio
        $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

        // customer ratio
        $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rate, 2);

        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);

        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;
        $averageBusinessValue      = 0;
        $averageCollectionValue    = 0;

        if ($customerConvertCount > 0) {
          $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->whereIn('za_customer.status',[0,6])
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_lead.created_by', $staff->sno)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->get();

          if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {

              $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.overall_fees');

              $total_payment += $payment;

              $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.paid_amount');

              $total_paid_payment += $paid_payment;
            }
          }


          // average
          $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
          $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
          $totalAllPayment += $total_payment;
          $totalAllPaidPayment += $total_paid_payment;
        }

        $staff->allLeadCount           = $allLeadCount;
        $staff->monthLeadCount       = $monthLeadCount;
        $staff->hotLeadCount        = $hotLeadCount;
        $staff->customerConvertCount      = $customerConvertCount;
        $staff->spamLeadCount            = $spamLeadCount;
        $staff->deadLeadCount      = $deadLeadCount;
        $staff->spam_lead_ratio            = $spam_lead_ratio;
        $staff->dead_lead_ratio      = $dead_lead_ratio;
        $staff->convertion_rate   = $convertion_rate;
        $staff->averager_convertion_rate   = $averager_convertion_rate;
        $staff->averageBusinessValue = $averageBusinessValue;
        $staff->averageCollectionValue    = $averageCollectionValue;
        $staff->walkingcount    = $walkingcount;
        $staff->outgoing_count    = $avg_outgoing_call_rate;

        // total cal
        $totalAllLead             += $allLeadCount;
        $totalMonthLead            += $monthLeadCount;
        $totalHotLead        += $hotLeadCount;
        $totalconvertCustomer            += $customerConvertCount;
        $totalSpamLead      += $spamLeadCount;
        $totalDeadLead    += $deadLeadCount;
      }

      $salesStaffreports = DB::table('za_staff')
        ->select(
          'za_staff.sno',
          'za_staff.staff_name',
          'za_staff.staff_image',
          'za_staff.branch_id',
          'za_staff.gender',
          'za_staff.mobile_no',
          'za_staff.lead_bank_count',
          'za_staff.status as staff_status'
        )
        ->where('za_staff.department_id', 1)
        ->where('za_staff.branch_id', $branch_id)
        ->where(function ($query) use ($year, $month) {
          // Add conditions for status 4
          $query->where(function ($query) use ($year, $month) {
            $query->where('za_staff.status', 4)
              ->whereYear('za_staff.notice_end_date', '>=', $year)
              ->whereMonth('za_staff.notice_end_date', '>=', $month);
          })
            // Add conditions for status 5
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 5)
                ->whereYear('za_staff.updated_at', '>=', $year)
                ->whereMonth('za_staff.updated_at', '>=', $month);
            })
            // Add conditions for status 6
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 6)
                ->whereYear('za_staff.staff_last_date', '>=', $year)
                ->whereMonth('za_staff.staff_last_date', '>=', $month);
            })
            // Add conditions for status 7
            ->orWhere(function ($query) use ($year, $month) {
              $query->where('za_staff.status', 7)
                ->whereYear('za_staff.updated_at', '>=', $year)
                ->whereMonth('za_staff.updated_at', '>=', $month);
            })
            // Include status 0 regardless of date
            ->orWhere('za_staff.status', 0);
        });

      $total_staffreports = $salesStaffreports->count();
      $salesStaffreports = $salesStaffreports->orderBy('za_staff.sno', 'desc')->get();


      foreach ($salesStaffreports as $staff) {

        $activeLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.status', 0)
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();


        $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();

        $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.lead_status_id', 3)
          ->where('za_lead.internal_status', 0)
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.drop_verified', 0)
          ->count();


        $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_lead.created_by', $staff->sno)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->count();

        $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.spam_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();

        $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $staff->sno)
          ->where('za_lead.drop_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 5)->count();



        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;
        $averageBusinessValue      = 0;
        $averageCollectionValue    = 0;

        if ($customerConvertCount > 0) {
          $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->whereIn('za_customer.status',[0,6])
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_lead.created_by', $staff->sno)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->get();

          if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {

              $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.overall_fees');

              $total_payment += $payment;

              $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.paid_amount');

              $total_paid_payment += $paid_payment;
            }
          }


          // average
          $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
          $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
          $totalAllPayment += $total_payment;
          $totalAllPaidPayment += $total_paid_payment;
        }

        $staff->allLeadCount            = $activeLeadCount;
        $staff->monthLeadCount          = $monthLeadCount;
        $staff->hotLeadCount            = $hotLeadCount;
        $staff->customerConvertCount    = $customerConvertCount;
        $staff->spamLeadCount           = $spamLeadCount;
        $staff->deadLeadCount           = $deadLeadCount;
      }
      $reports = [


        'actualdayLeadCount' => str_pad((string) ($actualdayLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualConversionCount' => $actualConversionCount,
        'actualConversionCountdaily' => $actualConversionCountdaily,
        'actualConversionCountold' => $actualConversionCountold,
        'actualConversionRate' => round($actualConversionRate),

        'salesStaff' => $salesStaff,
        'total_staff' => str_pad((string) ($total_staffsales ?? '0'), 2, '0', STR_PAD_LEFT),

        'salesStaffreports' => $salesStaffreports,
        'total_staffreports' => str_pad((string) ($total_staffreports ?? '0'), 2, '0', STR_PAD_LEFT),

        'monthLeadCount'     => str_pad((string) ($monthLeadCount ?? '0'), 2, '0', STR_PAD_LEFT),
        'percentagelastlead' => round($percentagelastlead),
        'activeLeadCount'    => $activeLeadCount,
        'spamLeadCount'      => $spamLeadCount,
        'deadLeadCount'      => $deadLeadCount,

        'monthLeadCountlast'     => str_pad((string) ($monthLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'activeLeadCountlast'    => str_pad((string) ($activeLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'spamLeadCountlast'      => str_pad((string) ($spamLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'deadLeadCountlast'      => str_pad((string) ($deadLeadCountlast ?? '0'), 2, '0', STR_PAD_LEFT),
        'actualConversionCountlast'      => str_pad((string) ($actualConversionCountold ?? '0'), 2, '0', STR_PAD_LEFT),

        'avg_appointment' => str_pad((string) ($avg_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_folllowup' => str_pad((string) ($avg_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_walkin' => str_pad((string) ($avg_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_outgoing_call' => str_pad((string) ($avg_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

        'avg_last_appointment' => str_pad((string) ($avg_last_appointment ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_folllowup' => str_pad((string) ($avg_last_folllowup ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_walkin' => str_pad((string) ($avg_last_walkin ?? '0'), 2, '0', STR_PAD_LEFT),
        'avg_last_outgoing_call' => str_pad((string) ($avg_last_outgoing_call ?? '0'), 2, '0', STR_PAD_LEFT),

        'dayAppointmentList'   => $dayAppointmentList,
        'dailyWalkinCount' => str_pad((string) ($dailyWalkinCount ?? '0'), 2, '0', STR_PAD_LEFT),

        'dailyFollowup'   => $dailyFollowup,
        'dailyFollowupCount' => str_pad((string) ($dailyFollowupCount ?? '0'), 2, '0', STR_PAD_LEFT),


        'finalResult'   => $finalResult,
        'finalResultcount'   => str_pad((string) ($finalResultcount ?? '0'), 2, '0', STR_PAD_LEFT),

        'leadData'   => $leadData,
        'leadDatacount' => str_pad((string) ($leadDatacount ?? '0'), 2, '0', STR_PAD_LEFT),
      ];


      // return  $reports;

      // Check if it's an AJAX request
      if ($request->ajax()) {
        return response()->json([
          'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
          'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
          'reports' => $reports
        ]);
      }
      
       // Ensure the month is in the same format as stored in the database (single digit)
      $month = ltrim($month, '0'); // Removes leading zero, e.g., "05" becomes "5"

      // Build the query
      $query = GoalSetTeamModel::where('za_goal_set_team.team_goal_month', $month)
          ->where('za_goal_set_team.department_id', $user_details_dashboard->department_id)
          ->where('za_goal_set_team.branch_id', $user_details_dashboard->branch_id)
          ->where('za_goal_set_team.team_goal_year', $year);

      // Execute the query
      $goalsetRecords = $query->first();

      // return $goalsetRecords;

      $goalsetData = [];


      $goalsetData = $goalsetRecords ?? null;


      if(isset($goalsetData->goal_completed)){     
          if($goalsetData->goal_completed == 1){
              $customerConvertCount = $goalsetData->conversion_actual ?? 0;
              $convertion_rate = $goalsetData->CR_actual ?? 0;
              $averageBusinessValue = $goalsetData->ABV_actual ?? 0;
              $averageCollectionValue = $goalsetData->ACV_actual ?? 0;
              $monthcall_out = $goalsetData->avg_call_out_actual ?? 0;
              $monthwalkincount = $goalsetData->no_of_walk_actual ?? 0;
              $monthFollowupCount = $goalsetData->no_of_followup_actual ?? 0;
              $std_count = $goalsetData->min_no_of_students_actual ?? 0;
              $costing_amount = $goalsetData->production_costing_actual ?? 0;
              $review_count = $goalsetData->no_of_reviews_actual ?? 0;
              $placement_count = $goalsetData->no_of_placements_actual ?? 0;
              $mou_count = $goalsetData->mou_actual ?? 0;
              $totalcosting_amount = $goalsetData->productions_actual ?? 0;
              $hacAmount = $goalsetData->hac_actual ?? 0;
              $post_sale_count = $goalsetData->no_of_post_sale_actual ?? 0;
              $OutstandingPayment_count = $goalsetData->no_of_outstanding_actual ?? 0;
              $refferal_count = $goalsetData->reference_sales_actual ?? 0;
          }

      }

      $month = ltrim($lastMonth, '0'); // Removes leading zero, e.g., "05" becomes "5"

      // Build the query
      $query = GoalSetTeamModel::where('za_goal_set_team.team_goal_month', $month)
          ->where('za_goal_set_team.department_id', $user_details_dashboard->department_id)
          ->where('za_goal_set_team.branch_id', $user_details_dashboard->branch_id)
          ->where('za_goal_set_team.team_goal_year', $lastMonthYear);

      // Execute the query
      $goalsetRecordsLastmonth = $query->first();

      $goalsetDataLastMonth = [];

      $goalsetDataLastMonth = $goalsetRecordsLastmonth;

      if(isset($goalsetDataLastMonth->goal_completed)){     
          if($goalsetDataLastMonth->goal_completed == 1){
              $customerConvertCount = $goalsetDataLastMonth->conversion_actual ?? 0;
              $convertion_rate = $goalsetDataLastMonth->CR_actual ?? 0;
              $averageBusinessValue = $goalsetDataLastMonth->ABV_actual ?? 0;
              $averageCollectionValue = $goalsetDataLastMonth->ACV_actual ?? 0;
              $monthcall_out = $goalsetDataLastMonth->avg_call_out_actual ?? 0;
              $monthwalkincount = $goalsetDataLastMonth->no_of_walk_actual ?? 0;
              $monthFollowupCount = $goalsetDataLastMonth->no_of_followup_actual ?? 0;
              $std_count = $goalsetDataLastMonth->min_no_of_students_actual ?? 0;
              $costing_amount = $goalsetDataLastMonth->production_costing_actual ?? 0;
              $review_count = $goalsetDataLastMonth->no_of_reviews_actual ?? 0;
              $placement_count = $goalsetDataLastMonth->no_of_placements_actual ?? 0;
              $mou_count = $goalsetDataLastMonth->mou_actual ?? 0;
              $totalcosting_amount = $goalsetDataLastMonth->productions_actual ?? 0;
              $hacAmount = $goalsetDataLastMonth->hac_actual ?? 0;
              $post_sale_count = $goalsetDataLastMonth->no_of_post_sale_actual ?? 0;
              $OutstandingPayment_count = $goalsetDataLastMonth->no_of_outstanding_actual ?? 0;
              $refferal_count = $goalsetDataLastMonth->reference_sales_actual ?? 0;
          }
      }



      return view('content.dashboard.sales_tl_team_dashboard', compact('branch_common', 'role_user', 'role_permission', 'user_details_dashboard', 'selectedMonth', 'reports', 'goalsetData', 'goalsetDataLastMonth'));
    }
  }


  public function login(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255',
      'password' => 'required|min:4',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 422,
        'message' => 'Validation Error',
        'error_msg' => $validator->errors(),
        'data' => null
      ], 422);
    }
    $remember = $request->has('remember');
    $user = User::select('users.*', 'za_staff.status as staff_status')
      ->where('users.name', $request->name)
      ->leftJoin('za_staff', 'users.user_id', '=', 'za_staff.sno')
      ->leftJoin('za_branch', 'users.branch_id', '=', 'za_branch.sno')
      ->where('za_staff.status', 0)
       ->where('za_branch.status', 0)
      ->first();

    if (!$user) {
        DB::table('user_login_logs')->insert([
            'user_id'    => 0,        
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 1, // failed
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'User not found.'
      ]);
      return back()->withInput();
    }

    if ($user->staff_status == 1) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is inactive. Please contact the administrator.'
      ]);
      return back()->withInput();
    } elseif ($user->staff_status == 2) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is deactivated. Please contact the administrator.'
      ]);
      return back()->withInput();
    }
    if ($user->name !== $request->name) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Username is case-sensitive. Please enter the correct case.'
      ]);
      return back()->withInput();
    }

    if (!Hash::check($request->password, $user->password)) {

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid credentials'
      ]);
      return back()->withInput();
    }

    Auth::login($user, $remember);
    session(['user_id' => $user->id]);
    
    // ✅ Log login info to user_login_logs
        DB::table('user_login_logs')->insert([
            'user_id'    => $user->id,
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 0, // success
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);
    $staff = StaffModel::where('sno', $user->user_id)->first();
    // Carbon::parse($staff->updated_at)->timezone('Asia/Kolkata')->format('Y-m-d h:i A');
    // $staff->save();
    if ($staff) {
        $staff->updated_at = Carbon::now('Asia/Kolkata');
        $staff->save();
    }
    $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();

    // dd($permissions);
    // Assuming you have a method in the User model to check role permissions
    if (!$permissions) {
      // Redirect to the role_permission_error page if the user doesn't have the role
      return redirect()->route('role_permission_error');
    }
    // Create a personal access token
    $token = $user->createToken('auth_token')->plainTextToken;

    // Set the cookie with the token, valid for 1 day
    // Cookie::queue('auth_token', $token, 1440);

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Login Successfully!'
    ]);

    if ($request->expectsJson()) {
      return response()->json([
        'status' => 200,
        'message' => 'Login Successful',
        'data' => [
          'redirect_url' => route('dashboards'),
          'token' => $token,
        ]
      ]);
    } else {
      return redirect()->route('dashboards');  // Ensure correct route name
    }
  }

  public function destroy(Request $request)
  {
      
      // Get the current authenticated user
    $user = Auth::user();

    if ($user) {
        // Update the latest login log with logout time
        DB::table('user_login_logs')
            ->where('user_id', $user->id)
            ->whereNull('logout_at') // Ensure we only update the last active session
            ->latest('login_at')
            ->limit(1)
            ->update([
                'logout_at' => now(),
                'updated_at' => now()
            ]);
    }
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    $cookieName = config('session.cookie'); // Get the session cookie name from configuration
    \Cookie::queue(\Cookie::forget($cookieName));

    return redirect('/');
  }

  public function Cronjob_staff_schedule(Request $request)
  {
      
      $monitor = CronjobMonitorModel::where('sno', 4)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    // Fetch records with non-empty reschedule dates and status 0
    $get_staff_schedule = BatchModel::where('reschedule_start_date', '!=', '')
      ->where('reschedule_end_date', '!=', '')
      ->where('status', 0)
      ->get();
    // return  $get_staff_schedule;
    // Get the current date using Carbon
    $currentDate = Carbon::now()->format('Y-m-d');

    // Loop through each record
    foreach ($get_staff_schedule as $list) {
      // Log for debugging
      // \Log::info("Current date: {$currentDate} < Reschedule end date: {$list->reschedule_end_date}");

      // Check if the current date is greater than or equal to the reschedule_end_date
      if ($currentDate >= $list->reschedule_end_date) {
        // Log for debugging
        // \Log::info("Updating record sno: {$list->sno}");
        // Update the reschedule_end_date, reschedule_start_date, and staff_id.
        // echo "Updating record sno From: {$list->sno}";
        // echo "<br>";
        // echo "Updating record sno To: {$list->batch_staff}";
        // echo "<br>";
        $update = BatchModel::where('sno', $list->sno)->where('batch_staff', '!=', '')->first();
        $update->staff_id =  $list->batch_staff;
        $update->reschedule_end_date =  null;
        $update->reschedule_start_date =  null;
        $update->updated_at =  date('Y-m-d H:i:s');


        $batch_id = $update->sno;
        $branch_id = $update->branch_id;
        $user_id = $update->batch_staff;

        $batch_details = BatchModel::where('sno', $batch_id)->first();
        if ($batch_details) {
          $current_staff_id =  $list->staff_id;
          $swap_start_date  =  $batch_details->start_date;
          $get_old_swap = Batch_staff_swap_Model::where('batch_id', $batch_id)->orderBy('sno', 'DESC')->first();
          $reason = '';
          if ($get_old_swap) {
            $swap_start_date =  $get_old_swap->swap_end_date;
            $reason = $get_old_swap->reason;
          }
          $update_record =  Batch_staff_swap_Model::create([
            'branch_id' => $branch_id,
            'batch_id' => $batch_id,
            'staff_id_before' => $current_staff_id,
            'staff_id_after' => $list->batch_staff,
            'swap_start_date' => $swap_start_date,
            'swap_end_date' => date('Y-m-d'),
            'reason' => $reason,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status' => 0,
          ]);
        }

        $update->save();
      }
    }

    $update_reschedule =  StaffRescheduleModel::where('date_range', '<=', $currentDate)->where('status', 0)->update(['status' => 2]);
    // Optionally return a message or the count of updated records
    
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    
    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
       // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
    if ($monitor) {
        
        // Update the monitor
        $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor->sync_duration        = $duration;
        $monitor->running_status       = 0;
        $monitor->save();
    
        // Create a log record
        $monitor_log = new CronjobLogModel();
        $monitor_log->cronjob_id           = $monitor->sno;
        $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_duration        = $duration;
        $monitor_log->response             = json_encode([
                                                'processed_records' => $get_staff_schedule->count() ?? 0,
                                                'execution_time'    => $duration,
                                            ]);
        $monitor_log->created_by  = 0;
        $monitor_log->updated_by  = 0;
        $monitor_log->save();
    }
    
    // Return the count of updated records
    return [
        'processed_records' => $get_staff_schedule->count() ?? 0,
        'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_staff_lead_bank_update(Request $request)
  {
    // Get the current date
    $today = now(); // Current date
    $lastDayOfMonth = now()->endOfMonth(); // Last day of the current month

    $helper             = new \App\Helpers\Helpers();
    $increase_count = $helper->general_setting_data()->lead_bank_count ?? 50;

    // return $increase_count;
    // Check if today is the last day of the month
    if ($today->isSameDay($lastDayOfMonth)) {
      // Update lead_bank_count for staff with status 0
      StaffModel::where('status', 0)->update(['lead_bank_count' => $increase_count]);

      return response()->json([
        "success" => true,
        "message" => "Lead bank count updated successfully for all staff with status 0."
      ]);
    }

    return response()->json([
      "success" => false,
      "message" => "Today is not the last day of the month."
    ]);
  }



  public function Cronjob_scheduled_message(Request $request)
  {

    $start_time = microtime(true);
    // Fetch all messages with status 0
    $schedule_message = Schedule_message_model::where('status', 0)->get();

    // Array to track successfully processed IDs
    $processedIds = [];

    foreach ($schedule_message as $list) {
      $update = Communication_config_Model::find($list->config_id);

      // Check if the configuration is valid
      if (!$update) {
        // Log::error("Configuration not found for ID: {$list->config_id}");
        continue;
      }

      // Calculate the target date/time based on `time`, `duration`, and `mode_id`
      $targetTime = $this->calculateTargetTime($update->mode_id, $update->time, $update->duration, $list->created_at, $list->source_type_id, $list->source_id);

      // Check if the target time has passed (if it's the right time for execution)
      if (now()->lt($targetTime)) {
        // Skip the current iteration if it's not yet time
        continue;
      }

      // Fetch Lead, Customer, or Payment based on source_type_id
      $lead = null;
      if ($list->source_type_id == 1) { // Lead
        $lead = LeadModel::find($list->source_id);
      } elseif ($list->source_type_id == 2) { // Customer
        $lead = CustomerModel::find($list->source_id);
      } elseif ($list->source_type_id == 3) { // Payment
        // Fetch all payments for the customer with status 0 (not paid)
        $payments = PaymentModel::where('customer_id', $list->source_id)
          ->where('status', 0)
          ->orderBy('nextPayDate', 'asc')
          ->get();  // Use get() to retrieve all matching records

        // Skip if no payments found
        if ($payments->isEmpty()) {
          continue;
        }
      }

      if (!$lead && !isset($payments)) {
        continue; // Skip if no lead/customer/payment found
      }

      try {
        // If it's a single lead or customer, proceed with the normal flow
        if ($lead) {
          $this->processLead($update, $lead, $request);
        }

        // Process each payment if there are multiple records
        if (isset($payments)) {
          foreach ($payments as $payment) {
            $this->processPayment($update, $payment, $request);
          }
        }

        // Add to the processed IDs array
        $processedIds[] = $list->sno;
      } catch (\Exception $e) {
        // Log the exception for debugging
        // Log::error("Error processing schedule ID: {$list->sno} - " . $e->getMessage());
      }
    }

    // Batch update: Set status to 2 for all processed IDs
    if (!empty($processedIds)) {
      Schedule_message_model::whereIn('sno', $processedIds)->update(['status' => 2]);
    }

    // Return success message with count of updated records
    // return response()->json([
    //   'message' => 'Schedule processed successfully.',
    //   'updated_count' => count($processedIds),
    // ]);
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'execution_time' => $execution_time . ' seconds',
      'updated_count' => count($processedIds),
    ];
  }

  /**
   * Process the lead (send email/WhatsApp)
   */
  private function processLead($update, $lead, $request)
  {
    if ($update->email_check == 1) {
      $this->sendEmail($update, $lead, 'lead'); // Pass the type ('lead')
    }

    if ($update->whatsapp_check == 1) {
      $this->processWhatsAppMessage($update, $lead, $request->language ?? 'en');
    }
  }

  /**
   * Process the payment (send email/WhatsApp)
   */
  private function processPayment($update, $payment, $request)
  {
    // Extract the associated customer data from payment
    $customer = CustomerModel::find($payment->customer_id); // Fetch customer details
    if ($customer) {
      if ($update->email_check == 1) {
        $this->sendEmail($update, $customer, 'customer'); // Pass the type ('customer')
      }

      if ($update->whatsapp_check == 1) {
        $this->processWhatsAppMessage($update, $customer, $request->language ?? 'en');
      }
    }
  }

  /**
   * Send email to the lead or customer
   */
  private function sendEmail($update, $entity, $type)
  {
    $emailTemplate = EmailTemplateModel::find($update->email_template_id);
    if (! $emailTemplate) {
      // Log::error("Email Template not found for ID: {$update->email_template_id}");
      return;
    }

    // Dynamically map the fields based on the type
    $name     = $type === 'lead' ? $entity->lead_name : $entity->cus_name;
    $email    = $type === 'lead' ? $entity->lead_email_id : $entity->cus_email_id;
    $gender   = $type === 'lead' ? $entity->lead_gender : $entity->cus_gender;
    $contact2 = $type === 'lead' ? $entity->phone_number : $entity->cus_phone_number;

    // $branchMobile = BranchModel::find($entity->branch_id)?->mobile; // Assuming branch_id exists in both tables
    $branch_data = BranchModel::where('sno', $entity->branch_id)->first();
    $branch_name = " ";
    if ($branch_data->branch_type == 1) {
      $branch_name = $branch_data->branch_name;
    } elseif ($branch_data->branch_type == 2) {
      $branch_name = $branch_data->franchise_name;
    }

    // $coursename = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();

    // $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
    $dynamicSubject = str_replace('#course', 'Java Full stack', $emailTemplate->email_name);

    // $helper             = new \App\Helpers\Helpers();
    // $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // $paymentDate        = date($common_date_format);
    // $paymentAmt         = number_format($totalAmount, 2, '.', ',');
    // $paymentAmount      = $paymentAmt . ". Rs";
    $content     = $emailTemplate->email_subject;
    $content     = str_replace('#name', "Raja", $content);
    $content     = str_replace('#course', 'Java Full Stack', $content);
    $content     = str_replace('#amount', "5000.Rs", $content);
    $content     = str_replace('#dueDate', "26-Jan-2025", $content);
    $content     = str_replace('#mail', 'info@elysiumacademy.org', $content);
    $branchNo    = $branch_data->mobile ?? "67865787545";
    $branchemail = $branch_data->mail ?? "hfghdgh";
    $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
    $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
    $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? 'Branch Mobile', $content);
    $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

    $mailData = [
      'url'         => 'Eapl.com',
      'subject'     => $dynamicSubject,
      'content'     => $content,
      'branchNo'    => $branchNo,
      'branchemail' => $branchemail, // Use the message content from the request
      'fbLink'      => $fbLink,      // Use the message content from the request
      'instaLink'   => $instaLink,   // Use the message content from the request
      'salesMobile' => $branch_data->sales_mobile,
    ];

    $to_address   = $email;
    $from_address = 'elysiumacademy@elysium.community';
    $from_name    = 'Elysium Academy速';
    Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  }

  /**
   * Calculate the target time based on mode, time, duration, and created_at timestamp
   */
  private function calculateTargetTime($modeId, $time, $duration, $createdAt, $sourceTypeId, $sourceId)
  {
    // Default target time is based on created_at
    $targetTime = Carbon::parse($createdAt);

    if ($sourceTypeId == 3) { // If source is payment, use nextPayDate
      $payment = PaymentModel::where('customer_id', $sourceId)->where('status', 0)->orderBy('nextPayDate', 'asc')->first();
      if ($payment) {
        $targetTime = Carbon::parse($payment->nextPayDate); // Use nextPayDate for payment reminders
      }
    }

    // Calculate the target time based on the mode, duration, and provided time
    switch ($modeId) {
      case 1: // Before
        $targetTime = $targetTime->sub($this->getDurationInterval($duration, $time));
        break;
      case 2: // After
        $targetTime = $targetTime->add($this->getDurationInterval($duration, $time));
        break;
      default:
        break;
    }

    return $targetTime;
  }

  /**
   * Convert duration into Carbon interval and return timestamp or string
   */
  private function getDurationInterval($duration, $time)
  {
    // Create a fresh Carbon instance for each calculation
    $carbon = Carbon::now();

    switch ($duration) {
      case 'Hours':
        return new \DateInterval('PT' . $time . 'H');
      case 'Minutes':
        return new \DateInterval('PT' . $time . 'M');
      case 'Days':
        return new \DateInterval('P' . $time . 'D');
      case 'Months':
        return new \DateInterval('P' . $time . 'M');
      case 'Years':
        return new \DateInterval('P' . $time . 'Y');
      default:
        return new \DateInterval('PT0S');
    }
  }

  //New Vasanth
  public function team_goals_dashboard(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $month = date('n', strtotime($month_id)); // Returns 3
    $year = $request->year;
    $branch_id = $request->branch_id;

    // Convert month name to number if necessary
    if (!empty($request->month_id)) {
      if (!is_numeric($request->month_id)) {
        $monthNumber = date('m', strtotime($request->month_id . ' 1'));
        $month_id = (int) $monthNumber;
      } else {
        $month_id = (int) $request->month_id;
      }
    }
    // Get goal records for the selected department and month
    $goalteam = GoalSetTeamModel::
    //     where('department_id', $departmentId)
    //   ->
      where('branch_id', $branchId)
      ->where('team_goal_month', $month_id)
      ->first();

    $staff = StaffModel::where('za_staff.branch_id', $branch_id)
    //   ->where('za_staff.department_id', $departmentId)
      ->where('za_staff.status', 0)
    //   ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'za_staff.sno',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image',
        'za_staff.basic_salary',
        // 'za_department.department_name',
        'za_user_role.role_name'
      ]);

    // // Initialize Totals
    // $totalDepartmentAllLead = $totalDepartmentMonthLead = $totalDepartmentHotLead = 0;
    // $totalDepartmentSpamLead = $totalDepartmentDeadLead = $totalDepartmentConvertCustomer = 0;
    // $totalDepartmentBusinessValue = $totalDepartmentCollectionValue = 0;
    // $totalDepartmentPaidPayment = $totalDepartmentTotalPayment = 0;
    // $totalmonthFollowupCount = $totalmonthwalkincount = $totalmonthcall_outcount = 0;
    // $totalmonthLead =  0;
    // $monthtotalLead =  0;
    // $totalDepartmentConvertCustomer = CustomerModel::whereIn('za_customer.status',[0,6])
    //     ->where('za_customer.branch_id', $branch_id)
    //     ->whereYear('za_customer.created_at', $year)
    //     ->whereMonth('za_customer.created_at', $month)
    //     ->count();
        

    // foreach ($staff as $member) {

      // Leads Count
      $totalDepartmentAllLead = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('internal_status', 0)
        ->count();
        
        $totalDepartmentMonthLead = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status',[2, 6])
            ->where('za_lead.spam_verified',0)
            ->where('za_lead.drop_verified', 0)
            ->where('za_lead.internal_status',0)
            ->count();


    //   $totalmonthLead += $totalDepartmentMonthLead;

      $monthtotalLeadCount = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('internal_status', 0)
        ->count();

    //   $monthtotalLead += $monthtotalLeadCount;?

      $totalDepartmentHotLead = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->whereNotIn('status', [2, 6])
        ->where('lead_status_id', 3)
        ->where('internal_status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->count();

      $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->whereIn('za_customer.status',[0,6])
        ->where('za_customer.branch_id', $branch_id)
        // ->where('za_lead.created_by', $member->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->count();
        
        

      $totalDepartmentSpamLead = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('spam_verified', 1)
        ->where('status', 7)
        ->count();

      $totalDepartmentDeadLead = DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('drop_verified', 1)
        ->where('status', 5)
        ->count();

      // Follow-ups & Walk-ins
      $totalmonthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        ->count();

      $totalmonthwalkincount = DB::table('za_lead_appointment')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.appointment_category', 'walk-in')
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      // Call Out Count
      $totalmonthcall_outcount = DB::table('za_call_tracker')
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->where('za_call_tracker.branch_id', $branch_id)
        ->where('call_status', 0)
        ->count();

      // Update Department Totals
    //   $totalDepartmentAllLead += $allLeadCount;
    //   $totalDepartmentMonthLead += $monthLeadCount;
    //   $totalDepartmentHotLead += $hotLeadCount;
    //   $totalDepartmentSpamLead += $spamLeadCount;
    //   $totalDepartmentDeadLead += $deadLeadCount;
    //   $totalDepartmentConvertCustomer += $customerConvertCount;
    //   $totalmonthFollowupCount += $monthFollowupCount;
    //   $totalmonthwalkincount += $monthwalkincount;
    //   $totalmonthcall_outcount += $monthcall_out;

      // Payments Calculation
    //   $totalPayment = 0;
    //   $totalPaidPayment = 0;

    //   if ($customerConvertCount > 0) {
    //     $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
    //       ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //       ->where('za_customer.branch_id', $branch_id)
    //       ->where('za_lead.created_by', $member->sno)
    //       ->whereYear('za_customer.created_at', $year)
    //       ->whereMonth('za_customer.created_at', $month)
    //       ->get();

    //     if ($currentMonthCustomer->isNotEmpty()) {
    //       foreach ($currentMonthCustomer as $customer) {

    //         $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
    //           ->where('za_training.customer_id', $customer->sno)
    //           ->where('za_training.tesbo_check', 0)
    //           ->sum('za_training.overall_fees');
    //         $totalPayment += $payment;
    //         $latestTraining = DB::table('za_training')
    //           ->where('customer_id', $customer->sno)
    //           ->where('tesbo_check', 2)
    //           ->orderByDesc('sno')
    //           ->first();

    //         if ($latestTraining) {
    //           $totalPayment += $latestTraining->overall_fees;
    //         }
    //         $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
    //           ->where('za_training.customer_id', $customer->sno)
    //           ->sum('za_training.paid_amount');

    //         $totalPaidPayment += $paid_payment;
    //       }
    //     }
    //   }
      // Update Total Department Payments
    //   $totalDepartmentTotalPayment += $totalPayment;
    //   $totalDepartmentPaidPayment += $totalPaidPayment;
    //   // Sales Exc *****************************************************
    //   $drop_ids = DB::table('za_drop_refund')
    //     ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
    //     ->where('za_drop_refund.bh_status', 1)
    //     ->where('za_drop_refund.branch_id', $branch_id)
    //     ->pluck('za_training.payment_id');
    //   // Sales Exc *****************************************************

    // }

    // Business and Collection Value Calculation
    // $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

    // $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

    // // Conversion Rate
    // $convertion_rate = $totalDepartmentMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

    // $totalConvertRatio = number_format($convertion_rate, 2);
    // $totalConvertRatio = $totalDepartmentConvertCustomer.'/'.$totalDepartmentMonthLead.'*100';


    // Get the total leads count
        $totalAllLead = DB::table('za_lead')
            ->where('branch_id', $branch_id)
            ->whereNotIn('status', [2, 6])
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->count();
    
        // Get the month-wise lead count
        $monthtotalLeadCount = DB::table('za_lead')
            ->where('branch_id', $branch_id)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->where('internal_status', 0)
            ->count();
    
        // Get the active leads count for a specific member
        $totalMonthLead = DB::table('za_lead')
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status', [2, 6])
            ->where('za_lead.spam_verified', 0)
            ->where('za_lead.drop_verified', 0)
            ->where('za_lead.internal_status', 0)
            ->count();
    
        // Get the total converted customers
        $totalConvertCustomer = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->whereIn('za_customer.status', [0, 6])
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->count();
    
        // Payments Calculation
        $totalPayment = 0;
        $totalPaidPayment = 0;
    
        if ($totalConvertCustomer > 0) {
            $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branch_id)
                ->whereYear('za_customer.created_at', $year)
                ->whereMonth('za_customer.created_at', $month)
                ->get();
    
            if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                    $payment = DB::table('za_training')->where('za_training.customer_id', $customer->sno)
                        ->where('za_training.tesbo_check', 0)
                        ->sum('za_training.overall_fees');
                    $totalPayment += $payment;
    
                    $latestTraining = DB::table('za_training')
                        ->where('customer_id', $customer->sno)
                        ->where('tesbo_check', 2)
                        ->orderByDesc('sno')
                        ->first();
    
                    if ($latestTraining) {
                        $totalPayment += $latestTraining->overall_fees;
                    }
    
                    $paid_payment = DB::table('za_training')
                        ->where('za_training.customer_id', $customer->sno)
                        ->sum('za_training.paid_amount');
    
                    $totalPaidPayment += $paid_payment;
                }
            }
        }
    
        $totalBusinessValue = $totalConvertCustomer > 0 ? round($totalPayment / $totalConvertCustomer, 2) : 0;
        $totalCollectionValue = $totalConvertCustomer > 0 ? round($totalPaidPayment / $totalConvertCustomer, 2) : 0;
    
        // Conversion Rate
        $conversion_rate = $totalMonthLead > 0 ? ($totalConvertCustomer / $totalMonthLead) * 100 : 0;
        $totalConvertRatio = number_format($conversion_rate, 2);

    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;
    $total_staff = count($staff) ?? 0;
    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
    $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
    $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;
    if (isset($goalteam->goal_completed)) {
      if ($goalteam->goal_completed == 1) {
        $totalConvertCustomer =  $goalteam->conversion_actual;
        $totalConvertRatio =  $goalteam->cr_actual;
        $totalBusinessValue =  $goalteam->abv_actual;
        $totalCollectionValue =  $goalteam->acv_actual;
        $totalmonthcall_outcount =  $goalteam->avg_call_out_actual;
        $totalmonthwalkincount =  $goalteam->no_of_walk_actual;
        $totalmonthFollowupCount =  $goalteam->no_of_followup_actual;
      }
    }
    // Prepare goal details response
    $goalteamDetails = [
      'team_id'                       => optional($goalteam)->sno ?? '',

      'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
      'conversion_check'              => 1,
      'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
      'conversion_actual'             => $totalConvertCustomer ?? 0,

      'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
      'cr_check'                      => 1,
      'cr_type'                       => optional($goalteam)->cr_type ?? 0,
      'cr_actual'                     => $totalConvertRatio ?? 0,

      'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
      'abv_check'                     => 1,
      'abv_type'                      => optional($goalteam)->abv_type ?? 0,
      'abv_actual'                    => $totalBusinessValue ?? 0,

      'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
      'acv_check'                     => 1,
      'acv_type'                      => optional($goalteam)->acv_type ?? 0,
      'acv_actual'                    => $totalCollectionValue ?? 0,

      'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
      'avg_call_out_check'            => 0,
      'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
      'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

      'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
      'no_of_walk_check'              => 0,
      'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
      'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

      'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
      'no_of_followup_check'          => 0,
      'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
      'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

      'active_lead'                    => $totalMonthLead ?? 0,
      'total_lead'                     => $monthtotalLeadCount ?? 0,

      'status' => optional($goalteam)->status == 1 ? true : false,
      'month'  => $month_id
    ];

    return response()->json([
      'status' => 200,
      'data'   => $goalteamDetails
    ]);
  }

  public function staff_goal_dashboard(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $month = date('n', strtotime($month_id)); // Returns 3
    $year = $request->year;
    $branch_id = $request->branch_id;

    if (!empty($month_id)) {
      if (!is_numeric($month_id)) {
        // Convert month name (e.g., "February") to its numeric value
        $monthNumber = date('m', strtotime($month_id . ' 1'));
        $request->merge(['month_id' => (int)$monthNumber]);
      } else {
        // Ensure month_id is an integer if it's already numeric
        $request->merge(['month_id' => (int)$month_id]);
      }
    }
    // Get staff members with department and role details
    $staff = StaffModel::where('za_staff.branch_id', $branchId)
      ->where('za_staff.department_id', $departmentId)
      ->where('za_staff.status', 0)
      ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'za_staff.sno',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image',
        'za_staff.basic_salary',
        'za_staff.avaiable_points',
        'za_department.department_name',
        'za_user_role.role_name'
      ]);
    $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', $departmentId)->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $departmentId)->where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $month)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->get();
    // return $goalsetRecords;
    // Convert goalsetRecords to an associative array for easy lookup
    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    $helper = new \App\Helpers\Helpers();


    $totalAverageBusinessValue = 0;
    $totalAverageCollectionValue     = 0;
    $totalAverageconvertRatio     = 0;
    $totalconvertRatio     = 0;
    $totalSpamLeadRatio     = 0;
    $totalDeadLeadRatio     = 0;
    $totalAllLead             = 0;
    $totalMonthLead            = 0;
    $totalconvertCustomer            = 0;
    $totalHotLead        = 0;
    $totalSpamLead      = 0;
    $totalDeadLead    = 0;

    $totalAllPayment             = 0;
    $totalAllPaidPayment        = 0;
    $total_basic_pay_pro = 0;


    // Attach goal details to staff members
    $staffDetails = [];
    foreach ($staff as $member) {

      $current_date = date('Y-m-d'); // Define the current date
      $std_count = TrainingModel::where('za_training.status', 0)
        ->where('za_batch.status', 0)
        ->where('za_training.status', 0)
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_training.staff_id', $member->sno)
        ->where('za_batch.start_date', '<=', $current_date)
        ->where('za_batch.end_date', '>=', $current_date)
        ->count();

      //Sales Team 

      $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.branch_id', $branch_id)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.internal_status', 0)
        ->count();

      $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.branch_id', $branch_id)
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->whereNotIn('za_lead.status', [2, 6])
        ->where('za_lead.lead_status_id', 3)
        ->where('za_lead.internal_status', 0)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->count();

      $customerConvertCount = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 4)->count();

      $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_lead.created_by', $member->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->count();

      $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.spam_verified', 1)
        ->where('za_lead.branch_id', $branch_id)
        ->where('za_lead.status', 7)->count();

      $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
        ->whereYear('za_lead.registered_date', $year)
        ->whereMonth('za_lead.registered_date', $month)
        ->where('za_lead.created_by', $member->sno)
        ->where('za_lead.drop_verified', 1)
        ->where('za_lead.branch_id', $branch_id)

        ->where('za_lead.status', 5)->count();

      $monthFollowupCount = DB::table('za_appointment')
        ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        ->whereIn('za_lead.status', [0, 4])
        ->where('za_appointment.created_by', $member->sno)
        ->whereYear('za_appointment.appointment_date', $year)
        ->whereMonth('za_appointment.appointment_date', $month)
        ->count();
      $monthwalkincount = DB::table('za_lead_appointment')
        ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
        ->where('za_lead_appointment.appointment_category', 'walk-in') // Fixed the table reference
        ->where('za_lead_appointment.created_by', $member->sno)
        ->whereYear('za_lead_appointment.appointment_date', $year)
        ->whereMonth('za_lead_appointment.appointment_date', $month)
        ->count();

      $monthcall_out = DB::table('za_call_tracker')
        ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->where('za_call_tracker.branch_id', $branch_id)
        ->where('za_call_tracker.branch_staff_id', $member->sno)
        ->first();
      $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;


      // Spam Ratio 
      $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
      $spam_lead_ratio = number_format($spam_lead_ratio, 2);

      // Dead ratio
      $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
      $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

      // customer ratio
      $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
      $convertion_rate = number_format($convertion_rate, 2);

      //acr
      $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
      $averager_convertion_rate = number_format($averager_convertion_rate, 2);



      $currentMonthCustomerCount = 0;
      $total_business_amount     = 0;
      $total_payment             = 0;
      $total_paid_payment        = 0;
      $averageBusinessValue      = 0;
      $averageCollectionValue    = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->whereIn('za_customer.status',[0,6])
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_lead.created_by', $member->sno)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->get();
        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {

            $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->where('za_training.tesbo_check', 0)
              ->sum('za_training.overall_fees');

            $total_payment += $payment;


            $latestTraining = DB::table('za_training')
              ->where('customer_id', $customer->sno)
              ->where('tesbo_check', 2)
              ->orderByDesc('sno')
              ->first();

            if ($latestTraining) {
              $total_payment += $latestTraining->overall_fees;
            }

            $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
              ->where('za_training.customer_id', $customer->sno)
              ->sum('za_training.paid_amount');

            $total_paid_payment += $paid_payment;
          }
        }

        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
        $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

        $totalAllPayment += $total_payment;
        $totalAllPaidPayment += $total_paid_payment;
      }

      // Production Goal***********************************************


      $staffproduction = StaffModel::select(
        'za_staff.sno',
        'za_staff.staff_id',
        'za_staff.staff_name',
        'za_staff.gender',
        'za_staff.dob',
        'za_staff.mobile_no',
        'za_staff.email_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.knowledge_tag',
        'za_staff.per_hour_cost',
        'za_job_position.job_position_name',
        'za_staff.avaiable_points',
        'za_staff.basic_salary',
        'za_staff.status AS staff_status'
      )
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where([
          ['za_staff.status', 0],
          ['za_staff.branch_id', $branch_id],
          ['za_staff.sno', $member->sno]
        ])
        ->orderByDesc('za_staff.sno')
        ->first();

      // Initialize variables
      $total_batch = $total_student = $total_free_batch = $total_staff = 0;
      $overall_earned = $overall_earned_per = $success_staff_count = 0;
      $slotType = $staffproduction;

      $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
      $slotType->present_count = $slotType->course_count = 0;
      $slotType->slotDetails = [];
      $slotType->avg_amnt = $slotType->salary = 0;

      // Fetch batch IDs associated with staff
      $batchIds = TrainingModel::where('branch_id', $branch_id)
        ->where('staff_id', $slotType->sno)
        ->distinct()
        ->pluck('batch_id')
        ->toArray();

      $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

      foreach ($slotType->batch_ids as $batchId) {
        // Fetch slot details for the staff's batches
        $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where('za_training.status', 0)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->pluck('batch_id'))
          ->where('za_batch.status', 0)
          ->get();

        $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

        // Fetch batch details
        $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->find($batchId);

        if ($batch) {
          $startTime = Carbon::parse($batch->start_time);
          $endTime = Carbon::parse($batch->end_time);
          $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

          // Fetch attendance records
          $attendanceRecords = AttendanceModel::select('per_hr_cost')
            ->where([
              ['batch_id', $batch->sno],
              ['staff_id', $slotType->sno],
              ['attendance', 'P']
            ])
            ->whereMonth('att_date', $month)
            ->whereYear('att_date', $year)
            ->get();

          foreach ($attendanceRecords as $attendance) {
            $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
          }
        }
      }

      // Student count
      $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
        ->where('staff_id', $slotType->sno)
        ->where(function ($query) use ($month, $year) {
          $query->whereMonth('start_date', '<=', $month)
            ->whereYear('start_date', '<=', $year)
            ->whereMonth('end_date', '>=', $month)
            ->whereYear('end_date', '>=', $year);
        })
        ->distinct('customer_id')
        ->count('customer_id');

      // Course count
      $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
        ->where('staff_id', $slotType->sno)
        ->where(function ($query) use ($month, $year) {
          $query->whereMonth('start_date', '<=', $month)
            ->whereYear('start_date', '<=', $year)
            ->whereMonth('end_date', '>=', $month)
            ->whereYear('end_date', '>=', $year);
        })
        ->distinct('course_id')
        ->count('course_id');

      // Batch count
      $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
        ->where('staff_id', $slotType->sno)
        ->where(function ($query) use ($month, $year) {
          $query->whereMonth('start_date', '<=', $month)
            ->whereYear('start_date', '<=', $year)
            ->whereMonth('end_date', '>=', $month)
            ->whereYear('end_date', '>=', $year);
        })
        ->distinct('batch_id')
        ->count('batch_id');

      // Salary calculation
      $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
      // Average earned percentage calculation
      $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
      // Calculate free batch count
      $total_free_batch = max(0, 8 - $slotType->batch_count);
      $overall_earned += $slotType->earned_amount;
      $overall_earned_per += $slotType->avg_amnt;
      // Count success staff
      if ($slotType->salary < $slotType->earned_amount) {
        $success_staff_count++;
      }
      $staffproduction = $slotType;
      $costing_amount = $staffproduction->earned_amount ?? 0;

      $refferal_count = DB::table('za_referral_persons')
        ->where('branch_id', $branch_id)
        ->where('referral_id', $member->sno)
        ->where('status', 0)
        ->where('referral_type', 2)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      // Production Goal***********************************************  
      // CRE Goal *****************************************************
      $review_count = DB::table('za_review')
        ->where('branch_id', $branch_id)
        ->where('created_by', $member->sno)
        ->where('status', 0)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      // CRE Goal *****************************************************
      // PC Goal *****************************************************

      $staff_pc = StaffModel::where('za_staff.branch_id', $branch_id)
        ->where('za_staff.department_id', 2)
        ->where('za_staff.status', 0)
        ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
        ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
        ->orderBy('staff_name', 'ASC')
        ->get([
          'za_staff.sno',
          'za_staff.staff_name',
          'za_staff.nick_name',
          'za_staff.gender',
          'za_staff.staff_image',
          'za_department.department_name',
          'za_user_role.role_name'
        ]);

      $totalcosting_amount = 0;
      $totalrefferal_count = 0;

      foreach ($staff_pc as $staff_pc_list) {

        // Production Goal***********************************************


        $staffproduction = StaffModel::select(
          'za_staff.sno',
          'za_staff.staff_id',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.dob',
          'za_staff.mobile_no',
          'za_staff.email_id',
          'za_staff.staff_image',
          'za_staff.nick_name',
          'za_staff.knowledge_tag',
          'za_staff.per_hour_cost',
          'za_job_position.job_position_name',
          'za_staff.avaiable_points',
          'za_staff.basic_salary',
          'za_staff.status AS staff_status'
        )
          ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
          ->where([
            ['za_staff.status', 0],
            ['za_staff.branch_id', $branch_id],
            ['za_staff.sno', $staff_pc_list->sno]
          ])
          ->orderByDesc('za_staff.sno')
          ->first();

        // Initialize variables
        $total_batch = $total_student = $total_free_batch = $total_staff = 0;
        $overall_earned = $overall_earned_per = $success_staff_count = 0;
        $slotType = $staffproduction;

        $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
        $slotType->present_count = $slotType->course_count = 0;
        $slotType->slotDetails = [];
        $slotType->avg_amnt = $slotType->salary = 0;

        // Fetch batch IDs associated with staff
        $batchIds = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->distinct()
          ->pluck('batch_id')
          ->toArray();

        $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

        foreach ($slotType->batch_ids as $batchId) {
          // Fetch slot details for the staff's batches
          $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->pluck('batch_id'))
            ->where('za_batch.status', 0)
            ->get();

          $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

          // Fetch batch details
          $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->find($batchId);

          if ($batch) {
            $startTime = Carbon::parse($batch->start_time);
            $endTime = Carbon::parse($batch->end_time);
            $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

            // Fetch attendance records
            $attendanceRecords = AttendanceModel::select('per_hr_cost')
              ->where([
                ['batch_id', $batch->sno],
                ['staff_id', $slotType->sno],
                ['attendance', 'P']
              ])
              ->whereMonth('att_date', $month)
              ->whereYear('att_date', $year)
              ->get();

            foreach ($attendanceRecords as $attendance) {
              $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
            }
          }
        }

        // Student count
        $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('customer_id')
          ->count('customer_id');

        // Course count
        $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('course_id')
          ->count('course_id');

        // Batch count
        $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('batch_id')
          ->count('batch_id');

        // Salary calculation
        $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
        // Average earned percentage calculation
        $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
        // Calculate free batch count
        $total_free_batch = max(0, 8 - $slotType->batch_count);
        $overall_earned += $slotType->earned_amount;
        $overall_earned_per += $slotType->avg_amnt;
        // Count success staff
        if ($slotType->salary < $slotType->earned_amount) {
          $success_staff_count++;
        }
        $staffproduction = $slotType;



        $totalcosting_amount += $staffproduction->earned_amount ?? 0;
        $total_basic_pay_pro += $slotType->basic_salary ?? 0;

        $refferal_count = DB::table('za_referral_persons')
          ->where('branch_id', $branch_id)
          ->where('referral_id', $staff_pc_list->sno)
          ->where('status', 0)
          ->where('referral_type', 2)
          ->whereYear('created_at', $year)
          ->whereMonth('created_at', $month)
          ->count();

        $totalrefferal_count += $refferal_count ?? 0;
      }

      if ($departmentId == 5) {
        $review_count = $totalrefferal_count;
      }

      // PC Goal *****************************************************

      // Sales Exc *****************************************************
      $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_drop_refund.branch_id', $branch_id)
        ->pluck('za_training.payment_id');

      $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount', '>', 0)
        ->whereIn('za_customer.status',[0,6])
        ->whereMonth('za_payment.nextPayDate', $month)
        ->whereYear('za_payment.nextPayDate', $year)
        ->orderBy('za_payment.sno', 'asc')
        ->count();

      $post_sale_count = DB::table('za_training')
        ->where('created_by', $member->sno)
        ->where('post_sale_check', 1)
        ->whereYear('post_sale_date', $year)
        ->whereMonth('post_sale_date', $month)
        ->distinct()
        ->count('customer_id');


      $hacAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_payment.status', 1) // paid amount
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.initialPayDate', $year)
        ->whereMonth('za_payment.initialPayDate', $month)
        // ->whereYear('za_payment.nextPayDate', $year)
        // ->whereMonth('za_payment.nextPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.paidAmount');

      // Sales Exc *****************************************************

      $placement_count = DB::table('za_placement_interview')
        ->where('updated_by', $member->sno)
        ->where('status', 4)
        ->whereYear('selected_date', $year)
        ->whereMonth('selected_date', $month)
        ->distinct()
        ->count('customer_id');


      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      $monthcall_out = $dayCount > 0  ? round($monthcall_out /  $dayCount) : 0;
      $monthwalkincount = $dayCount > 0  ? round($monthwalkincount /  $dayCount) : 0;
      $monthFollowupCount = $dayCount > 0  ? round($monthFollowupCount /  $dayCount) : 0;

      $basic_pay = $member->basic_salary ?? 0;
      $costing_amount_asign = $goalsetData[$member->sno]->production_costing ?? 0;
      $costing_amount = $basic_pay > 0  ? round(($costing_amount /  $basic_pay) *  $costing_amount_asign) : 0;



      $productions_asign   = $goalsetData[$member->sno]->productions ?? 0;
      $totalcosting_amount = $total_basic_pay_pro > 0  ? round(($totalcosting_amount /  $total_basic_pay_pro) *  $productions_asign) : 0;

      if (isset($goalsetData[$member->sno]->goal_completed)) {
        if ($goalsetData[$member->sno]->goal_completed == 1) {
          $customerConvertCount = $goalsetData[$member->sno]->conversion_actual ?? 0;
          $convertion_rate = $goalsetData[$member->sno]->CR_actual ?? 0;
          $averageBusinessValue = $goalsetData[$member->sno]->ABV_actual ?? 0;
          $averageCollectionValue = $goalsetData[$member->sno]->ACV_actual ?? 0;
          $monthcall_out = $goalsetData[$member->sno]->avg_call_out_actual ?? 0;
          $monthwalkincount = $goalsetData[$member->sno]->no_of_walk_actual ?? 0;
          $monthFollowupCount = $goalsetData[$member->sno]->no_of_followup_actual ?? 0;
          $std_count = $goalsetData[$member->sno]->min_no_of_students_actual ?? 0;
          $costing_amount = $goalsetData[$member->sno]->production_costing_actual ?? 0;
          $review_count = $goalsetData[$member->sno]->no_of_reviews_actual ?? 0;
          $placement_count = $goalsetData[$member->sno]->no_of_placements_actual ?? 0;
          $mou_actual = $goalsetData[$member->sno]->mou_actual ?? 0;
          $totalcosting_amount = $goalsetData[$member->sno]->productions_actual ?? 0;
          $hacAmount = $goalsetData[$member->sno]->hac_actual ?? 0;
          $post_sale_count = $goalsetData[$member->sno]->no_of_post_sale_actual ?? 0;
          $OutstandingPayment_count = $goalsetData[$member->sno]->no_of_outstanding_actual ?? 0;
          $refferal_count = $goalsetData[$member->sno]->reference_sales_actual ?? 0;
        }
      }






      // $slot_heart  = str_pad($staff->user_batch ?? 0, 2, '0', STR_PAD_LEFT);

      // $battery_image = 'b_0.png';
      // if ($slot_heart == 0) {
      //   $battery_image = 'b_0.png';
      // } elseif ($slot_heart > 0 && $slot_heart < 2) {
      //   $battery_image = 'b_25.png';
      // } elseif ($slot_heart >= 2 && $slot_heart < 4) {
      //   $battery_image = 'b_50.png';
      // } elseif ($slot_heart >= 4 && $slot_heart < 7) {
      //   $battery_image = 'b_75.png';
      // } elseif ($slot_heart >= 7) {
      //   $battery_image = 'b_100.png';
      // }
      // $battery = '<div class="symbol symbol-35px cursor-pointer mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ongoing Batch">
      //               <img src="' . asset('assets/eapl_images/' . $battery_image) . '" alt="user-avatar" class="image-input-wrapper w-25px h-25px" />
      //               <div class="fs-8 fw-semibold text-center text-black">' . $slot_heart . ' / 08</div>
      //           </div>';

      $currentMonth = $month;
      $currentYear  = $year;

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

        $dayCounts = 0;
        $dateSrt = $startDate->copy();
        
        while ($dateSrt->lte($endDate)) {
            if (!$dateSrt->isSunday()) {
                $dayCounts++;
            }
            $dateSrt->addDay();
        }

    
        //   $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
        //     ->where('branch_id', $branchId)
        //     ->where('attendance', 'P')
        //     ->whereMonth('date', $month)
        //     ->whereYear('date', $year)
        //     ->count();
        //   $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;
     $presentDays = StaffAttendanceModel::where('staff_id',$member->sno)
        ->where('branch_id', $branchId)
        ->whereIn('attendance', ['P', 'HD'])
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();
        //  return $dayCounts;
      $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

      if ($presentDays == 0) {
        $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays > 0 && $presentDays < 50) {
        $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays >= 50 && $presentDays < 75) {
        $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays >= 75 && $presentDays < 100) {
        $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays == 100) {
        $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      }
        
       $goal_progress = 0;
        if ($departmentId == 1) {
            $actual = $customerConvertCount ?? 0;
            $target = $goalsetData[$member->sno]->conversion ?? 0;
            $goal_progress = $target > 0 ? floor(($actual / $target) * 100) : 0;
        }
       
        
       $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, 1, $month, $year, $branch_id) ?? 0;
                   
      
         // return $actualMonthLeadCount;
        $promisecount = DB::table('za_sales_promise')
            ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
            ->where('za_staff.department_id', 1)
            ->where('za_sales_promise.branch_id', $branch_id)
            ->whereYear('za_sales_promise.promise_date', $year)
            ->whereMonth('za_sales_promise.promise_date', $month)
            ->where('za_sales_promise.status', 0)
            ->where('za_staff.sno', $member->sno)
            ->sum('za_sales_promise.promise_count');
        
        $successcount = DB::table('za_sales_promise')
            ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
            ->where('za_staff.department_id', 1)
            ->where('za_sales_promise.branch_id', $branch_id)
            ->whereYear('za_sales_promise.promise_date', $year)
            ->whereMonth('za_sales_promise.promise_date', $month)
            ->where('za_sales_promise.status', 1)
            ->where('za_staff.sno', $member->sno)
            ->sum('za_sales_promise.promise_count');
        
        // Avoid division by zero
       $formattedPromiseSuccess = 0;

        if ($promisecount > 0) {
            $rawScore = ($successcount / $promisecount) * 10;
            $score = min(round($rawScore), 10); // round to whole number and cap at 10
            $formattedPromiseSuccess = str_pad($score, 2, '0', STR_PAD_LEFT); // ensure 2 digits like 02, 10
        } else {
            $formattedPromiseSuccess = '00';
        }
                        
        // Determine badge color
        $trustBadgeColor = 'bg-danger';
        if ($formattedPromiseSuccess >= 5 && $formattedPromiseSuccess <= 8) {
            $trustBadgeColor = 'bg-warning';
        } elseif ($formattedPromiseSuccess >= 9) {
            $trustBadgeColor = 'bg-success';
        }
    //   $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, $departmentId, $month, $year, $branch_id) ?? 0;
                    $ratio = $goal_progress;
                   if ($ratio > 100) {
                        $color = '#7854c7'; // Purple
                    } elseif ($ratio >= 80) {
                        $color = '#34C759'; // Green
                    } elseif ($ratio >= 40) {
                        $color = '#FFCC00'; // Yellow
                    } else {
                        $color = '#FF3B30'; // Red
                    }
                 
                    $points = $member->avaiable_points ?? 0;
                
                    if ($points < 0) {
                        $badgeClass = 'bg-danger'; // Red for negative points
                    } elseif ($points == 0) {
                        $badgeClass = 'bg-info'; // Blue for 0 points
                    } else {
                        $badgeClass = 'bg-success'; // Green for positive points
                    }
                   




      $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
        . $heart .
        '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    <div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
                      <div class="fs-8 fw-semibold text-dark">TS</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge ' . $trustBadgeColor . ' fw-semibold fs-8">' . $formattedPromiseSuccess  . '</label>
                      </div>
                    </div>
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge '. $badgeClass .' fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';
                  
                  
        $staffDetails2 = [
        'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
        'conversion_actual'         => $customerConvertCount ?? 0,
        'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
        'cr_actual'                 => $convertion_rate ?? 0,
        'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
        'abv_actual'                => $averageBusinessValue ?? 0,
        'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
        'acv_actual'                => $averageCollectionValue ?? 0,
        'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
        'avg_call_out_actual'       => $monthcall_out ?? 0,
        'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
        'no_of_walk_actual'         => $monthwalkincount ?? 0,
        'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
        'no_of_followup_actual'     => $monthFollowupCount ?? 0,
        'min_no_of_students'        => $goalsetData[$member->sno]->min_no_of_students ?? 0,
        'min_no_of_students_actual' => $std_count ?? 0,
        'production_costing'        => $goalsetData[$member->sno]->production_costing ?? 0,
        'production_costing_actual' => $costing_amount ?? 0,
        'no_of_reviews'             => $goalsetData[$member->sno]->no_of_reviews ?? 0,
        'no_of_reviews_actual'      => $review_count ?? 0,
        'no_of_placements'          => $goalsetData[$member->sno]->no_of_placements ?? 0,
        'no_of_placements_actual'   => $placement_count ?? 0,
        'mou'                       => $goalsetData[$member->sno]->mou ?? 0,
        'mou_actual'                => $mou_count ?? 0,
        'productions'               => $goalsetData[$member->sno]->productions ?? 0,
        'productions_actual'        => $totalcosting_amount ?? 0,
        'hac'                       => $goalsetData[$member->sno]->hac ?? 0,
        'hac_actual'                => $hacAmount ?? 0,
        'no_of_post_sale'           => $goalsetData[$member->sno]->no_of_post_sale ?? 0,
        'no_of_post_sale_actual'    => $post_sale_count ?? 0,
        'no_of_outstanding'         => $goalsetData[$member->sno]->no_of_outstanding ?? 0,
        'no_of_outstanding_actual'  => $OutstandingPayment_count ?? 0,
        'reference_sales'           => $goalsetData[$member->sno]->reference_sales ?? 0,
        'reference_sales_actual'    => $refferal_count ?? '0',
      ];
        $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
        $goal_achievements = false;
        if(isset($ten_x)){
            foreach ($ten_x as $key => $value) {
                $isChecked = $value === "1";
                if ($isChecked) {
                    $type2 = str_replace("_10x", "", $key);
                    $goal_value = $staffDetails2[$type2] ?? 0;
                    $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                    if($goal_value > 0){
                        if ($actual_value < $goal_value) {
                            $goal_achievements = true; // Not Achieved
                            break; // No need to continue checking if one goal failed
                        }
                    }else{
                        $goal_achievements = true; // Invalid goal
                        break;
                    }
                }
            }
        }

      $staffDetails[] = [
        'sno'                       => $member->sno,
        'staff_name'                => $member->staff_name,
        'nick_name'                 => $member->nick_name,
        'gender'                    => $member->gender,
        'staff_image'               => $member->staff_image,
        'department_name'           => $member->department_name,
        'role_name'                 => $member->role_name,
        'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
        'goal_achievements'         => $goal_achievements,
        'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
        'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',

        'month'                     => $month_id,
        'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,

        'conversion_check'          => 1,
        'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
        'conversion_actual'         => $customerConvertCount ?? 0,

        'cr_check'                  => 1,
        'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
        'cr_actual'                 => $convertion_rate ?? 0,

        'abv_check'                 => 1,
        'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
        'abv_actual'                => $averageBusinessValue ?? 0,
         'sales_lead_checks'    => $goalsetData[$member->sno]->sales_lead_check ?? 0,

        'acv_check'                 => 1,
        'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
        'acv_actual'                => $averageCollectionValue ?? 0,
        'score_td'                => $score_td ?? '-',
      ];
    }

    return response()->json([
      'status' => 200,
      'data' => $staffDetails
    ]);
  }
  
  public function ceo_alertdashboard(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $Current_date = date('Y-m-d');

    $month_id = $request->month_id;
    $month = date('n', strtotime($month_id)); // Returns 3
    $year = $request->year;
    // Get today's date
    //Attendance Pending
    $today    = today();
    $staffCount = DB::table('za_staff')
      ->where('status', 0)
      ->where('branch_id', $branchId)
      ->where('za_staff.position_role', '!=', 49)
      ->count();
    // Query to find staff who are not present today
    $staffNotAttendedCount = DB::table('za_staff')
      ->where('status', 0)
      ->where('branch_id', $branchId)
      ->where('za_staff.position_role', '!=', 49)
      ->whereNotIn('sno', function ($query) use ($today) {
        $query->select('staff_id')
          ->from('za_staff_attendance')
          ->where('date', $today);
      })
      ->count();
    $staffAttendedCount = $staffCount - $staffNotAttendedCount;

    // outstanding
        $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_drop_refund.branch_id', $branchId)
        ->pluck('za_training.customer_id');

        // Get the current date
        $currentDate = now()->subDay()->toDateString();

        
            
         $OutstandingPaymentss = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
            ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
            ->where('za_payment.branch_id', $branchId)
            ->whereNotIn('za_payment.customer_id', $drop_ids)
            ->where('za_payment.status', 0)
            ->where('za_payment.amount', '>', 0)
            ->where('za_customer.status', 0)
            ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
            ->select('za_training.training_id')
            ->groupBy('za_training.training_id')
            ->orderBy('za_payment.nextPayDate', 'DESC')
            ->get();
       $OutstandingPayment = $OutstandingPaymentss->count();

    //Low Paid
    // Get branch details
    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

 $drop_ids = DB::table('za_drop_refund')
          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
          ->where('za_drop_refund.bh_status', 1)
          ->pluck('za_training.customer_id');
 
        // Sum of the amounts
        $sumScheduleAmount = DB::table('za_payment')
            ->where('za_payment.branch_id', $branchId)
            ->sum('za_payment.amount');
 
        $sumBalanceFee = DB::table('za_payment')
            ->where('za_payment.branch_id', $branchId)
            ->sum('za_payment.balanceFee');
     $min = $branch->min_prd_cost;
        // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_training')
          ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
          ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
          ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
          ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
          ->select(
              'za_customer.customer_id',
              'za_payment.course_id',
              'za_customer.sno as customer_sno',
              'za_course.sno as course_sno',
              'za_customer.cus_name',
              'za_customer.cus_gender',
              'za_customer.cus_pic',
              'za_customer.cus_mobile',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_staff.staff_name',
              'za_training.training_id',
              'za_training.batch_id',
              'za_training.payment_id',
              'za_payment.initialPayDate',
              'za_training.paid_amount as total_paid_amount',
             'za_training.balance_amount as total_balance_fee',
             'za_training.overall_fees as total_amount',
              DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate'
          )
          ->where('za_payment.branch_id', $branchId)
           ->whereNotIn('za_customer.sno', $drop_ids)
          ->where('za_training.status', '!=',2)
          //   ->where('za_training.balance_amount', '!=',0)
            ->where(function ($q) use ($min) {
                $q->where('za_training.overall_fees', '>', $min)
                  ->orWhere(function ($q2) use ($min) {
                      $q2->where('za_training.overall_fees', '<=', $min)
                         ->whereColumn('za_training.overall_fees', '!=', 'za_training.paid_amount');
                  });
            })
          ->groupBy(
              'za_customer.customer_id',
              'za_customer.sno',
              'za_course.sno',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_pic',
              'za_customer.cus_gender',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
               'za_staff.staff_name',
                'za_training.batch_id',
               'za_training.paid_amount',
             'za_training.balance_amount',
             'za_training.overall_fees',
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate',
              'za_payment.initialPayDate',
              'za_payment.course_id'
          )
        //   ->orderByDesc('za_payment.sno')
        ->orderBy('za_payment.nextPayDate', 'asc')
          ->get()
          ->unique('payment_id'); // Keep only unique customer records;
      //   return $PaidUnderPayment;
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->total_paid_amount < ($branch?->min_prd_cost ?? 8000);
      });
 
 
      // Group by customer_id
      $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          // Filter payments where paidAmount is greater than 0
          $filteredPayments = $payments->filter(function ($payment) {
              return $payment->total_paid_amount > 0;
          });
 
          // If no valid payments exist after filtering, exclude this customer
          if ($filteredPayments->isEmpty()) {
              return null;
          }
 
          $payment = $payments->first();
          // Return structured data for each customer
          return [
              'customer_name' => $payment->cus_name,
              'customer_sno' => $payment->customer_sno,
              'total_paid' => $payment->total_paid_amount,
              'min_required' => $branch->min_prd_cost,
              'status' => 'Pending',
              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                  return [
                      'course_name' => $payment->course_name,
                      'cus_gender' => $payment->cus_gender,
                      'cus_pic' => $payment->cus_pic,
                      'staff_name' => $payment->staff_name,
                      'batch_id' => $payment->batch_id,
                      'training_id' => $payment->training_id,
                      'payment_id' => $payment->payment_id,
                      'cus_name' => $payment->cus_name,
                      'cus_mobile' => $payment->cus_mobile,
                      'amount' => $payment->total_amount,
                      'paidAmount' => $payment->total_paid_amount,
                      'balanceFee' => $payment->total_balance_fee,
                      'gst_amount' => $payment->total_gst_amount,
                      'nextPayDate' => $payment->nextPayDate,
                      'initialPayDate' => $payment->initialPayDate,
                      'payment_mode_label' => $payment->payment_mode_label,
                  ];
              })->values(), // Reset array keys
          ];
      })->filter();
 
        // Paginate the results
        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
 
        // Calculate the total number of pages
        $totalItems = $finalResult->count();

    // not Yet Started Count
    $batch_Data = DB::table('za_training')
      ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      // ->whereNotNull('za_training.start_date')
      ->where('za_training.branch_id', $branchId)
      ->where('za_customer.status',0)
      // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->get();


    $dropCount = 0;
    $activeCount = 0;
    $notYetStartedCount = 0;
    $scheduleCount = 0;

    $processed_drop_customers = [];
    $processed_active_customers = [];
    $processed_schedule_customers = [];
    $processed_not_started_customers = [];

    foreach ($batch_Data as $singledata) {
      if (in_array($singledata->customer_id, $processed_drop_customers)) {
        continue;
      }
      if ($singledata->status == "2") {
        $dropCount++;
        $processed_drop_customers[] = $singledata->customer_id;
      }
    }

    $batch_active_Data = DB::table('za_training')
      ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereNotNull('za_training.start_date')
      ->where('za_training.branch_id', $branchId)
      ->where('za_customer.status',0)
      ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->get();


    foreach ($batch_active_Data as $singledata) {
      if (!in_array($singledata->customer_id, $processed_drop_customers)) {
        if (in_array($singledata->customer_id, $processed_active_customers)) {
          continue;
        }
        if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
          $activeCount++;
          $processed_active_customers[] = $singledata->customer_id;
        }
      }
    }


    $batch_Data_old = DB::table('za_training')
      ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_training.branch_id', $branchId)
      ->where('za_customer.status',0)
      ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->get();


    // return  $processed_active_customers;
    foreach ($batch_Data_old as $singledata) {

      if (!in_array($singledata->customer_id, $processed_drop_customers)) {
        if (!in_array($singledata->customer_id, $processed_active_customers)) {
          if (in_array($singledata->customer_id, $processed_schedule_customers)) {
            continue;
          }
          if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
            $scheduleCount++;
            $processed_schedule_customers[] = $singledata->customer_id;
          }
        }
      }
    }
    $batch_notyetStated = DB::table('za_training')
      ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_training.branch_id', $branchId)
      ->where('za_customer.status',0)
      ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
      ->get();

    foreach ($batch_notyetStated as $singledata) {

      if (!in_array($singledata->customer_id, $processed_drop_customers)) {
        if (!in_array($singledata->customer_id, $processed_active_customers)) {
          if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
            if (in_array($singledata->customer_id, $processed_not_started_customers)) {
              continue;
            }
            if ($singledata->start_date === null) {
              $notYetStartedCount++;
              $processed_not_started_customers[] = $singledata->customer_id;
            }
          }
        }
      }
    }

    $sales_staff = StaffModel::where('status', 0)
      ->where('department_id', 1)
      ->where('branch_id', $branchId)
      ->count();
    $production_staff = StaffModel::where('status', 0)
      ->where('department_id', 2)
      ->where('position_role', '!=', 38)
      ->where('branch_id', $branchId)
      ->count();
    $production_staff_freelance = StaffModel::where('status', 0)
      ->where('department_id', 2)
      ->where('position_role', 38)
      ->where('branch_id', $branchId)
      ->count();

    $placement_staff = StaffModel::where('status', 0)
      ->where('department_id', 8)
      ->where('branch_id', $branchId)
      ->count();

    $dropcourseapproval = DB::table('za_drop_refund')
      ->where('type', 0)
    //   ->whereDate('bh_status_date', $Current_date)
      ->where('branch_id', $branchId)
      ->where('bh_status', 1)
      ->where('bh_status', 0)->count();

    $refundapproval = DB::table('za_drop_refund')
      ->where('za_drop_refund.type', 1)
    //   ->whereDate('bh_status_date', $Current_date)
      ->where('branch_id', $branchId)
      ->where('bh_status', 0)->count();



    $payment_count = TransactionModel::where('branch_id', $branchId)
    //   ->whereDate('transaction_date', $Current_date)
      ->whereIn('payment_status', [0, 2])
      ->count();


    $certificate_count = DB::table('za_manage_certificate')
      ->where('branch_id', $branchId)
    //   ->whereDate('req_cert_date', $Current_date)
      ->where('status', 0)
      ->select(DB::raw('SUM(COALESCE(req_stud_count, 0) - COALESCE(confirm_stud_count, 0)) as total_count'))
      ->value('total_count') ?? 0;
    $currentDate = now()->toDateString();
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->where('za_drop_refund.branch_id', $branchId)
      ->pluck('za_training.payment_id');
    $OutstandingPayment_cri = PaymentModel::where('za_payment.branch_id', $branchId)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->select(
        'za_training.training_id',
        DB::raw('MAX(za_payment.payment_id) AS payment_id'),
        DB::raw('MAX(za_training.sno) AS tran_sno'),
        DB::raw('MAX(za_training.batch_id) AS batch_id'),
        DB::raw('MAX(za_payment.sno) AS payment_sno'),
        DB::raw('MAX(za_payment.branch_id) AS branch_id'),
        DB::raw('MAX(za_customer.customer_id) AS customer_id'),
        DB::raw('MAX(za_customer.sno) AS customer_sno'),
        DB::raw('MAX(za_course.course_id) AS course_id'),
        DB::raw('MAX(za_payment.initialPayDate) AS initialPayDate'),
        DB::raw('MAX(za_payment.nextPayDate) AS nextPayDate'),
        DB::raw('MAX(za_payment.amount) AS amount'),
        DB::raw('MAX(za_payment.paidAmount) AS paidAmount'),
        DB::raw('MAX(za_payment.gst_amount) AS gst_amount'),
        DB::raw('MAX(za_payment.balanceFee) AS balanceFee'),
        DB::raw('MAX(za_payment.total_amount) AS total_amount'),
        DB::raw('MAX(za_payment.payment_mode_label) AS payment_mode_label'),
        DB::raw('MAX(za_payment.status) AS payment_status'),
        DB::raw('MIN(za_customer.cus_name) AS cus_name'),
        DB::raw('MAX(za_customer.cus_pic) AS cus_pic'),
        DB::raw('MAX(za_customer.cus_gender) AS cus_gender'),
        DB::raw('MAX(za_customer.jumper_skiper) AS jumper_skiper'),
        DB::raw('MAX(za_customer.cus_mobile) AS cus_mobile'),
        DB::raw('MAX(za_customer.cus_email_id) AS cus_email_id'),
        DB::raw('MAX(za_course.course_name) AS course_name'),
        DB::raw('MAX(za_course.sno) AS course_sno')
      )
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_payment.amount', '>', 0)
      ->whereIn('za_customer.status',[0,6])
      ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->groupBy('za_training.training_id')
      ->orderBy('za_payment.nextPayDate', 'DESC')
      ->get();

    $critical_cus = 0;
    $long_abs_cus = 0;

    foreach ($OutstandingPayment_cri as $list) {
      $tran_sno = $list->tran_sno;
      $cus_sno  = $list->customer_sno;

      $training = TrainingModel::find($tran_sno);
      if (!$training) {
        continue;
      }

      $batch_id = $training->batch_id;
      $course_id = $training->course_id;

      // 1. Check course progress
      $presentDates = AttendanceModel::where('customer_id', $cus_sno)
        ->where('batch_id', $batch_id)
        ->where('attendance', 'P')
        ->pluck('att_date');

      if ($presentDates->isEmpty()) {
        continue;
      }

      $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)
        ->where('status', 0)
        ->count();

      if ($course_topic_count == 0) {
        continue;
      }

      $topicCount = SyllabusUpdateModel::where('batch_id', $batch_id)
        ->where('percentage', '100')
        ->distinct()
        ->count('sno');

      $courseProgress = ($topicCount / $course_topic_count) * 100;

      if ($courseProgress >= 75) {
        $critical_cus++;
      }

      // 2. Check long absenteeism (e.g., 3+ consecutive absents)
      $absentDates = AttendanceModel::where('customer_id', $cus_sno)
        ->where('attendance', 'A')
        ->orderBy('att_date', 'desc')
        ->pluck('att_date')
        ->toArray();

      $consecutiveCount = 1;
      for ($i = 1; $i < count($absentDates); $i++) {
        $prev = strtotime($absentDates[$i - 1]);
        $curr = strtotime($absentDates[$i]);

        if ($prev === strtotime('+1 day', $curr)) {
          $consecutiveCount++;
        } else {
          // break; // Stop when not continuous
        }
      }

      if ($consecutiveCount >= 3) {
        $long_abs_cus++;
        // $long_abs_cus =$cus_sno;
      }
    }



    $staffproduction = StaffModel::select(
      'za_staff.sno',
      'za_staff.staff_id',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.dob',
      'za_staff.mobile_no',
      'za_staff.email_id',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_staff.per_hour_cost',
      'za_job_position.job_position_name',
      'za_staff.avaiable_points',
      'za_staff.basic_salary',
      'za_staff.status AS staff_status'
    )
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', '=', 0)
      ->where('za_staff.role_id', '=', 22)
      ->where('za_staff.branch_id', $branchId)
      ->groupBy(
        'za_staff.sno',
        'za_staff.staff_id',
        'za_staff.staff_name',
        'za_staff.gender',
        'za_staff.dob',
        'za_staff.mobile_no',
        'za_staff.email_id',
        'za_staff.staff_image',
        'za_job_position.job_position_name',
        'za_staff.avaiable_points',
        'za_staff.nick_name',
        'za_staff.knowledge_tag',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_staff.status'
      )
      ->orderBy('za_staff.sno', 'desc')
      ->get();

    $staffproduction_loop = $staffproduction->unique('staff_id');

    $total_batch = 0;
    $total_student = 0;
    $total_free_batch = 0;
    $total_staff = 0;
    $overall_earned = 0;
    $overall_earned_per = 0;
    $success_staff_count = 0;
    $rows = '';
 $helper = new \App\Helpers\Helpers();

    foreach ($staffproduction_loop as $slotType) {

      $slotType->earned_amount = 0;
      $slotType->batch_count = 0;
      $slotType->student_count = 0;
      $slotType->present_count = 0;
      $slotType->course_count = 0;
      $slotType->slotDetails = [];
      $slotType->avg_amnt = 0;
      $slotType->salary = 0;
      $branchId = $branchId;
      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month)  ? $currentDate: $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      
      
      $currentMonth = $month;
      $currentYear  = $year;

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();
      
      $dayCount = $startDate->diffInDays($endDate) + 1;
      
      $presentDays = StaffAttendanceModel::where('staff_id', $slotType->sno)
        ->where('branch_id', $branchId)
        ->where('attendance', 'P')
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();
      $presentDays =  $dayCount > 0 ? ($presentDays / $dayCount) * 100 : 0;

      $slotType->attendance_radio =  sprintf('%02d', $presentDays);

      $user_batch = BatchModel::select("za_batch.*", "za_course.course_name", "za_slot.start_time", "za_slot.end_time", "za_slot.slot_type_days")
        ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->where('za_batch.branch_id', $branchId)
        ->where('za_batch.staff_id', $slotType->sno)
        ->where('za_batch.status', 0)
        // ->whereJsonContains('za_slot.slot_type_days', (string)$currentDayNumber) // Filter by current day
        ->orderBy('za_slot.start_time')
        ->orderBy('za_slot.end_time')
        ->count();

      $slotType->user_batch =  sprintf('%02d', $user_batch);

      $ongoingBatch = DB::table('za_batch')
        ->where('branch_id', $branchId)
        ->whereMonth('end_date', '>=', $month)
        ->whereYear('end_date', '>=', $year)
        ->whereMonth('start_date', '<=', $month)
        ->whereDate('start_date', '>=', $year)
        ->where('za_batch.staff_id', $slotType->sno)
        ->where('status', 0)
        ->count();


      $slotType->ongoingBatch =  sprintf('%02d', $ongoingBatch);

      $ongoingstudent = DB::table('za_batch')
        ->where('branch_id', $branchId)
        ->whereMonth('end_date', '>=', $month)
        ->whereYear('end_date', '>=', $year)
        ->whereMonth('start_date', '<=', $month)
        ->whereDate('start_date', '>=', $year)
        ->where('za_batch.staff_id', $slotType->sno)
        ->where('status', 0)
        ->pluck('sno'); // Get an array of sno values

      $student_count = DB::table('za_training')
        ->whereIn('batch_id', $ongoingstudent) // Filter using batch_id
        ->distinct('customer_id') // Ensure uniqueness before counting
        ->count('customer_id');

      $slotType->ongoingstudent = sprintf('%02d', $student_count ?? 0); // Handle null case


      $completedstudent = DB::table('za_batch')
        ->where('branch_id', $branchId)
        ->whereMonth('end_date', $month)
        ->whereYear('end_date', $year)
        ->where('za_batch.staff_id', $slotType->sno)
        ->where('status', 3)
        ->pluck('sno'); // Get an array of sno values

      $student_countcompletedstudent = DB::table('za_training')
        ->whereIn('batch_id', $completedstudent) // Filter using batch_id
        ->distinct('customer_id') // Ensure uniqueness before counting
        ->count('customer_id');

      $slotType->completedstudent = sprintf('%02d', $student_countcompletedstudent ?? 0); // Handle null case



      $completedBatch = DB::table('za_batch')
        ->where('branch_id', $branchId)
        ->where('za_batch.staff_id', $slotType->sno)
        ->where('status', 3)
        ->whereMonth('end_date', $month)
        ->whereYear('end_date', $year)
        ->count();
      $slotType->completedBatch =  sprintf('%02d', $completedBatch);



      $batchIds = TrainingModel::where('branch_id', $branchId)
        ->where('staff_id', $slotType->sno)
        ->distinct()
        ->pluck('batch_id')
        ->toArray();

      $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array

      $slotType->batch_ids = $batchIds; // Save batch IDs

      // return $slotType;

      foreach ($slotType->batch_ids as $batchId) {
        // Fetch the slot details for the slot type
        $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
            ->where('staff_id', $slotType->sno)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->pluck('batch_id'))
          ->where('za_batch.status', 0)
          ->get();

        // Fetch the batch details
        $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->find($batchId);

        if ($batch) {
          // Calculate the duration between start_time and end_time for the specific batch
          $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
          $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance

          $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
          $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
          // return $batchDurationInHours;
          // Get attendance records for the current batch

          $attendanceRecords = AttendanceModel::select('*')
            ->where('batch_id', $batch->sno)
            ->where('staff_id', $slotType->sno)
            ->where('attendance', 'P')
            ->whereMonth('att_date', '=', $month)
            ->whereYear('att_date', '=', $year)
            ->get();


          // Loop through the attendance records and calculate the earned amount
          foreach ($attendanceRecords as $attendance) {
            // Multiply the per_hr_cost by the batch duration (instead of slotType duration)
            $earnedAmountForAttendance = $attendance->per_hr_cost * $batchDurationInHours; // Use batch duration here
            $slotType->earned_amount += $earnedAmountForAttendance;  // Add to the total earned amount
          }
        }
      }


      // return $slotType;
    $current_date = date('Y-m-d');
      $slotType->student_count = TrainingModel::where('branch_id', $branchId)
        ->where('staff_id', $slotType->sno)
        ->where('za_training.status', 0)
        ->whereDate('start_date', '<=', $current_date)
        ->whereDate('end_date', '>=', $current_date)
       
        // ->distinct('customer_id')
        ->count();

      $slotType->course_count = TrainingModel::where('branch_id', $branchId)
        ->where('staff_id', $slotType->sno)
        ->where(function ($query) use ($month, $year) {
          $query->whereMonth('start_date', '<=', $month)
            ->whereYear('start_date', '<=', $year)
            ->whereMonth('end_date', '>=', $month)
            ->whereYear('end_date', '>=', $year);
        })
        ->distinct('course_id')
        ->count('course_id');

      $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
        ->where('staff_id', $slotType->sno)
        ->where(function ($query) use ($month, $year) {
          $query->whereMonth('start_date', '<=', $month)
            ->whereYear('start_date', '<=', $year)
            ->whereMonth('end_date', '>=', $month)
            ->whereYear('end_date', '>=', $year);
        })
        ->distinct('batch_id')
        ->count('batch_id');


      $slotType->salary = $slotType->basic_salary * 10;

      if ($slotType->salary != 0) {
        $slotType->avg_amnt = ($slotType->earned_amount / $slotType->salary) * 100;
      } else {
        $slotType->avg_amnt = 0;  // or any other value you want in case of division by zero
      }


      $total_free_batch += 8 - $slotType->batch_count;
      $overall_earned += $slotType->earned_amount;

      $overall_earned_per += $slotType->avg_amnt;

      if ($slotType->salary < $slotType->earned_amount) {
        $success_staff_count++;  // Increment slotType count who meet the condition
      }

      $staffImage = asset('staff_images/' . $slotType->staff_image);
      $staffName = htmlspecialchars($slotType->staff_name);
      $nickName = htmlspecialchars($slotType->nick_name);
      $avaiablePoints = sprintf('%02d', $slotType->avaiable_points ?? 0);
      
                
        if ($avaiablePoints < 0) {
            $badgeClass = 'bg-danger'; // Red for negative points
        } elseif ($avaiablePoints == 0) {
            $badgeClass = 'bg-info'; // Blue for 0 points
        } else {
            $badgeClass = 'bg-success'; // Green for positive points
        }
        
        
      $currentMonth = $month;
      $currentYear  = $year;

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

        $dayCounts = 0;
        $dateSrt = $startDate->copy();
        
        while ($dateSrt->lte($endDate)) {
            if (!$dateSrt->isSunday()) {
                $dayCounts++;
            }
            $dateSrt->addDay();
        }
        
        $presentDays = StaffAttendanceModel::where('staff_id',$slotType->sno)
        ->where('branch_id', $branchId)
        ->whereIn('attendance', ['P', 'HD'])
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();
        //  return $dayCounts;
      $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;
        
    //   $presentDays = $slotType->attendance_radio ?? 0;
      $userBatch = $slotType->user_batch ?? 0;
      $batchCount = $slotType->batch_count ?? 0;
      $studentCount = $slotType->student_count ?? 0;
      $remaining = 8 - $batchCount;
      
      if($remaining < 0){
          $remaining = 0;
      }
      $earnedAmount = number_format($slotType->earned_amount ?? 0);

      // Attendance image
      if ($presentDays == 0) {
        $attendanceImage = asset('assets/eapl_images/staff_rate/h_0.png');
      } elseif ($presentDays < 50) {
        $attendanceImage = asset('assets/eapl_images/staff_rate/h_25.png');
      } elseif ($presentDays < 75) {
        $attendanceImage = asset('assets/eapl_images/staff_rate/h_50.png');
      } elseif ($presentDays < 100) {
        $attendanceImage = asset('assets/eapl_images/staff_rate/h_75.png');
      } else {
        $attendanceImage = asset('assets/eapl_images/staff_rate/h_100.png');
      }

      // Batch image
      if ($userBatch == 0) {
        $batchImage = asset('assets/eapl_images/b_0.png');
      } elseif ($userBatch < 2) {
        $batchImage = asset('assets/eapl_images/b_25.png');
      } elseif ($userBatch < 4) {
        $batchImage = asset('assets/eapl_images/b_50.png');
      } elseif ($userBatch < 7) {
        $batchImage = asset('assets/eapl_images/b_75.png');
      } else {
        $batchImage = asset('assets/eapl_images/b_100.png');
      }
      
       $goal_progress =  $helper->getStaffGoal_progress_bar($slotType->sno, 2, $month, $year, $branchId) ?? 0;
        $ratio = $goal_progress;
        if ($ratio > 100) {
            $color = '#7854c7'; // Purple
        } elseif ($ratio >= 80) {
            $color = '#34C759'; // Green
        } elseif ($ratio >= 40) {
            $color = '#FFCC00'; // Yello
        } else {
            $color = '#FF3B30'; // Red
        }

      

      $rows .= "
                <tr>
                    <td>
                        <div class='d-flex align-items-center'>
                            <div class='symbol symbol-35px me-1'>
                                <div class='image-input border rounded-pill image-input-circle'>
                                    <img src='{$staffImage}' alt='user-avatar'class='rounded-circle w-50px h-50px' />
                                </div>
                            </div>
                            <div class='mb-0'>
                                <div class='text-black text-truncate max-w-100px fw-bold fs-6' title='{$staffName}'>{$staffName}</div>
                                <div class='d-block'><label class='fs-7 text-dark fw-semibold'>{$nickName}</label></div>
                                <div class='d-block'><div class='text-black fs-8 badge bg-info text-white' title='Faculty'>Faculty</div></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class='d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1'>
                            <div class='symbol symbol-35px cursor-pointer mb-0' title='Attendance Ratio'>
                                <img src='{$attendanceImage}' alt='attendance' class='image-input-wrapper w-20px h-20px' />
                                <div class='fs-8 fw-semibold text-center text-black'>{$presentDays}%</div>
                            </div>
                            <div class='symbol symbol-35px cursor-pointer mb-0' title='Ongoing Batch'>
                                <img src='{$batchImage}' alt='batch' class='image-input-wrapper w-25px h-25px' />
                                <div class='fs-8 fw-semibold text-center text-black'>{$userBatch} / 08</div>
                            </div>
                            <div class='cursor-pointer'>
                                <div class='progress border rounded h-15px w-60px mb-1' data-bs-toggle='tooltip' data-bs-placement='bottom' title='Goalset Ratio'>
                                    <div class='progress-bar progress-bar-striped progress-bar-animated'
                                        role='progressbar'
                                        style='width: {$goal_progress}%; background: {$color};'
                                        aria-valuenow='{$goal_progress}' aria-valuemin='0' aria-valuemax='100'></div>
                                </div>
                                <div class='fs-8 fw-semibold text-center text-black'>{$goal_progress}%</div>
                            </div>
                            <div class='mb-0 text-center'>
                                <div class='fs-8 fw-semibold text-dark'>Points</div>
                                <div class='fs-8 fw-semibold text-black'>
                                     <label class=\"badge {$badgeClass} fw-semibold fs-8\">{$avaiablePoints}</label>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class='d-flex align-items-center justify-content-center'>
                            <label class='cursor-pointer fs-7 badge bg-info badge-center rounded-pill fw-semibold' title='Batch Count'>{$batchCount}</label>
                            <label class='fs-6 fw-semibold me-1 ms-1'>/</label>
                            <label class='cursor-pointer fs-7 badge bg-success badge-center text-black rounded-pill fw-semibold' title='Students Count'>{$studentCount}</label>
                        </div>
                    </td>
                    <td><div class='text-center'><label class='badge bg-danger fs-7'>{$remaining}</label></div></td>
                    <td><div class='fs-1 badge bg-label-danger fw-semibold'>&#8377; {$earnedAmount}</div></td>
                </tr>";

    }

    $sp_count = count($staffproduction_loop) ?? 0;

    $data = [
      'total_staff' => $staffCount,
      'total_present_staff' => $staffAttendedCount,
      'total_outstanding' => $OutstandingPayment,
      'total_low_mpc' => $totalItems,
      'total_not_yet_count' => $notYetStartedCount,
      'drop_count' => $dropcourseapproval,
      'refund_count' => $refundapproval,
      'payment_count' => $payment_count,
      'certificate_count' => $certificate_count,
      'sales_staff' => $sales_staff,
      'production_staff' => $production_staff,
      'production_staff_freelance' => $production_staff_freelance,
      'placement_staff' => $placement_staff,
      'critical_cus_count' => $critical_cus,
      'long_abs_count' => $long_abs_cus,
      'staffproduction' => $rows,
      'staffproduction_count' => $sp_count,
    ];

    return response()->json([
      'status' => 200,
      'data' => $data
    ]);
  }
  
    public function Cronjob_website_lead()
  {
    $start_time = microtime(true);

    $genset = GeneralSettingsModel::where('sno', 1)->first();

    // return $genset;
    $getLeads = DB::table('za_website_lead')
      ->select('*')
      ->where('status', 0)
      //   ->where('sno', 39)
      ->limit(1000)
      ->orderBy('sno', 'ASC')
      ->get();

    $inserted_records = 0;
    foreach ($getLeads as $jlead) {
      $parentid = $jlead->branch_id;
      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'branch_id')
        ->where('branch_id', $parentid)
        ->first();
      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $jlead->lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
        // Check if lead already exists
        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = WebsiteleadModel::where('sno', $jlead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($jlead->lead_name);
        $add_category->lead_mobile = $lead_mobile;
        $add_category->lead_email_id = $jlead->lead_mail;
        // $add_category->lead_knowledge_tags = $jlead->lead_knowledge_tags;
        $add_category->registered_date = date('Y-m-d', strtotime($jlead->created_at));
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 17;
        $add_category->website_id = $jlead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;

        if ($add_category->save()) {
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 13;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          $add_history->save();

          $lead_update = WebsiteleadModel::where('sno', $jlead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($jlead->lead_name);
        $lead_email_id = $jlead->lead_mail;

        if ($add_category) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 9; // from Cloud Call Spam
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          // return $add_history;
          $add_history->save();
        }
        // sms thank you lead
        if ($add_category && $lead_mobile) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $jlead->lead_mail) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium Academy速';
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }
        // whatsapp message
        if ($add_category && $lead_mobile) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '7708053111',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }
     // Egc Login handle
   public function HandleEGCLogin(Request $request)
{
    if (!$request->token) {
        abort(400, "Missing SSO token");
    }

    

    // Verify with App1
    $verifyResponse = Http::get($request->token);

    if (!$verifyResponse->ok()) {
        abort(401, "SSO Verification failed");
    }

    $data = $verifyResponse->json()['data'];

    if($data['secret_token'] !='egcswitchportal2027'){
        abort(401, "UnAuthorized Entry");
    }

    $user_name = $data['user_name'];
    $email = $data['email'];

    // Find user in ERP database
    $user = User::where('name', $user_name)
                ->first();

    if (!$user) {
        abort(404, "User not found");
    }

    // Direct login, no password check needed
    Auth::login($user);

    return redirect()->route('dashboards');
}

}
