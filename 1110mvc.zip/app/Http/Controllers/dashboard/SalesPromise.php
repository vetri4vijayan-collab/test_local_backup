<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SalesPromiseModel;
use App\Models\CustomerModel;
use Illuminate\Support\Facades\DB;
use App\Models\StaffModel;
use App\Models\StaffpointsModel;

class SalesPromise extends Controller
{
    public function showTaskPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        // return $user;
        // Only show the modal for these roles
        $allowedRoles = ['11'];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => true, 'show_modal' => false]); // No modal for other roles
        }
        $task = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->first();

        return response()->json([
            'task' => $task,
            'show_modal' => !$task  // Show modal if task is not already submitted
        ]);
    }

    public function submitTask(Request $request)
    {
        $request->validate([
            'promise_count' => 'required|integer|min:1',
        ]);
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();

        $task = SalesPromiseModel::updateOrCreate(
            ['staff_id' => $user->user_id, 'promise_date' => $today],
            [
                'promise_count' => $request->promise_count,
                'branch_id' => $branch_id,
                'created_by' => $user->user_id,
                'updated_by' => $user->user_id,
                'created_at' => now(),
            ]
        );

        return response()->json(['success' => true]);
    }

    public function showFailerPopup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request('year', date('Y'));
        $month = request('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = [11];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['show_modal' => false]);
        }

        // Count successfully converted customers
        $customerConvertCount = CustomerModel::where('za_customer.status', 0)
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $user->branch_id)
            ->where('za_lead.created_by', $user->user_id)
            ->whereDate('za_customer.created_at',  date('Y-m-d'))
            ->count();

        // Check if the promise was not met
        $taskFailure = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->whereNull('failer_date_time') // Check if failer_date_time is NOT NULL
            ->where('status', 0)
            ->where('promise_count', '>', $customerConvertCount) // If the promise count was not met
            ->exists();
        // Count successfully converted customers
        $data = CustomerModel::where('za_customer.status', 0)->select('za_customer.cus_name', 'za_customer.created_at')
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $user->branch_id)
            ->where('za_lead.created_by', $user->user_id)
            ->whereMonth('za_customer.created_at',  date('m'))
            ->get();
        $sch_count  = DB::table('et_schedule_daily_call')
            ->where('current_staff', $user->user_id)
            ->where('sch_date', date('Y-m-d'))
            ->where('branch_id', $user->branch_id)
            ->count();
        $dailyCallmet = DB::table('za_sales_dailly_call')
            ->where('branch_id', $user->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user->user_id)
            ->whereDate('created_at', date('Y-m-d'))
            ->where('dc_count', '<', $sch_count) // Promise met
            ->exists();
        return response()->json([
            'show_modal' => $taskFailure,
            'show_modal_call' => $dailyCallmet,
            'customerConvertCount' => $customerConvertCount,
            '$data' => $customerConvertCount
        ]);
    }


    public function submitFailureReasonCall(Request $request)
  {
    $request->validate([
      'reason' => 'required|string|max:255',
    ]);
 
    $user = auth()->user();
    $today = now()->toDateString();
    $branch_id = $request->user()->branch_id;
    $updated = DB::table('za_sales_dailly_call')
      ->where('staff_id', $user->user_id)
      ->where('branch_id', $branch_id)
      ->where('dc_date', $today)
      ->update([
        'failer_date_time' => now(),
        'reason' => $request->reason,
        'updated_by' => $user->user_id,
        'status' => 2,
      ]);
 
    return response()->json(['success' => true]);
  }
  
 
    
    public function showSuccessPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request()->get('year', date('Y'));
        $month = request()->get('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = ['11','12'];
        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => false, 'show_modal' => false]); // No modal for other roles
        }

        $customerConvertCount = CustomerModel::select('za_customer.sno')
            ->where('za_customer.status', 0)
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $user->branch_id)
            ->where('za_lead.created_by', $user->user_id)
            ->whereDate('za_customer.created_at',  date('Y-m-d'))
            ->count();

        // Check if promise was met
        $promiseMet = SalesPromiseModel::where('staff_id', $user->user_id)
            ->whereDate('promise_date', $today)
            ->where('status', 0)
            ->where('promise_count', '>', 0) // Ignore zero
            ->where('promise_count', '<=', $customerConvertCount)
            ->exists();
        $sch_count  = DB::table('et_schedule_daily_call')
            ->where('current_staff', $user->user_id)
            ->where('sch_date', date('Y-m-d'))
            ->where('branch_id', $user->branch_id)
            ->count();
        $dailyCallmet = DB::table('za_sales_dailly_call')
            ->where('branch_id', $user->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user->user_id)
            ->whereDate('created_at', date('Y-m-d'))
            ->where('dc_count', '>=', $sch_count) // Promise met
            ->exists();
        if ($dailyCallmet) {
            $user = auth()->user();
            $branch_id = $user->branch_id;
            $staff_id = $user->user_id;
 
            // Check if points already awarded today
            $prechk = StaffpointsModel::where('points_id', 25)
                ->whereDate('created_at', today())
                ->where('staff_id', $staff_id)
                ->first();
 
            if (!$prechk) {
                // Initialize helper and get points data
                $helper = new \App\Helpers\Helpers();
                $pointsData = $helper->get_points_by_id(25);
 
                // Set default values if pointsData is null
                $point = $pointsData->points ?? 0;
                $reason = $pointsData->points_name ?? 'Schedule Daily Call Complete points';
 
                try {
                    // Save new points for the staff
                    $newPoints = StaffpointsModel::create([
                        'branch_id' => $branch_id,
                        'staff_id'  => $staff_id,
                        'points_by' => 0,
                        'points_id' => 25,
                        'points'    => $point,
                        'reason'    => $reason
                    ]);
 
                    // Update staff's available points
                    if ($newPoints && $point > 0) {
                        StaffModel::where('sno', $staff_id)
                            ->increment('avaiable_points', $point);
                    }
                } catch (\Exception $e) {
                    // Log error or handle exception as needed
                    // \Log::error('Failed to award daily call points: ' . $e->getMessage());
                }
            }
        }
 
        return response()->json([
            'promiseMet' => $promiseMet,
            'show_modal' => $promiseMet,  // Show modal only if promise was met
            'show_modal_call' => $dailyCallmet,  // Show modal cal only if daily Call was met
        ]);
    }

    public function submitSuccessCheers(Request $request)
    {

        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $request->user()->branch_id;
        SalesPromiseModel::where('staff_id', $user->user_id)->where('branch_id', $branch_id)
            ->where('promise_date', $today)
            ->update([
                'updated_by' => $user->user_id,
                'status' => 1,
            ]);

        return response()->json(['success' => true]);
    }

    public function submitSuccessCheersCall(Request $request)
    {
        try {

            $user = auth()->user();
            $today = now()->toDateString();
            $branch_id = $request->user()->branch_id;

            $updated = DB::table('za_sales_dailly_call')
                ->where('staff_id', $user->user_id)
                ->where('branch_id', $branch_id)
                ->whereDate('created_at', $today) // FIXED
                ->update([
                    'status'      => 2,
                    'updated_by'  => $user->user_id,
                    'updated_at'  => now()
                ]);

            if ($updated > 0) {
                return response()->json([
                    'success' => true,
                    'message' => 'Status updated successfully.'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'No record found to update.'
                ], 404);
            }
        } catch (\Exception $e) {

            return response()->json([
                'success' => false,
                'message' => 'Something went wrong.',
                'error'   => $e->getMessage()
            ], 500);
        }
    }
}
