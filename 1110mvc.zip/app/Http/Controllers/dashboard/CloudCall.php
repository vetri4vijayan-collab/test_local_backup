<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\CloudCallModel;
use App\Models\LeadModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Models\SpamReasonModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\CloudCallApiSetupModel;

class CloudCall extends Controller
{
  protected $apiUrl;
  protected $apiToken;
  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;

  public function __construct()
  {
    $this->apiUrl = env('MYOPERATOR_BASE_URL', 'https://in.app.myoperator.com');
    $this->apiToken = env('MYOPERATOR_API_TOKEN');
    $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
    $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
    $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
    $this->baseUrl = 'https://graph.facebook.com/v17.0';
    $this->businessId = $whatsappConfig->waba_id;
  }

  public function Index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year  = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    if ($month . $year == date('mY') || $year > date('Y')) {
      $month_chk = 0;
    } else {
      $month_chk = 1;
    }

    // Get the current date
    $currentDate = now()->toDateString();
    $customer_fill = $request->cus_fill ?? '';
    $unattended_fill = $request->get('unattended', $unattended ?? '');


    $Call_log = CloudCallModel::select(
      'za_cloud_call.*',
      'za_lead.lead_name',
      'za_lead.drop_verified',
      'za_lead.drop_tl_verified',
      'za_lead.spam_verified',
      'za_lead.spam_tl_verified',
      'za_lead.status AS lead_status',
      'za_lead.lead_mobile',
      'za_lead.created_by AS lead_created_by',
      'za_staff.staff_name' // Assuming you want to retrieve staff names
    )
      ->leftJoin('za_lead', function ($join) use ($branch_id) {
        $join->on('za_lead.lead_mobile', '=', DB::raw('RIGHT(za_cloud_call.caller_number, 10)'))
          ->where('za_lead.branch_id', '=', $branch_id);
      })
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by') // Ensure correct column mapping
      ->whereYear('start_time', $year)
      ->where('za_cloud_call.branch_id', $branch_id)
      ->whereMonth('start_time', $month);

    if (!empty($customer_fill)) {
      $Call_log->where(function ($query) use ($customer_fill) {
        $query->where('received_by', 'LIKE', "%{$customer_fill}%")
          ->orWhere('caller_number', 'LIKE', "%{$customer_fill}%")
          ->orWhere('action', 'LIKE', "%{$customer_fill}%")
          ->orWhere('department_name', 'LIKE', "%{$customer_fill}%");
      });
    }

    if (!empty($unattended_fill)) {
      $Call_log
        // ->whereNull('za_cloud_call.action') // Ensures 'action' is NULL
        // ->where('za_cloud_call.status', 2)
        ->whereNotExists(function ($query) {
          $query->select(DB::raw(1))
            ->from('za_lead')
            ->whereRaw("RIGHT(za_cloud_call.caller_number, 10) = za_lead.lead_mobile");
        });
    }

    // Assign paginated result
    $Call_log = $Call_log->orderBy('start_time', 'DESC')->paginate($perpage);



    $missed_call_count = CloudCallModel::whereYear('start_time', $year)
      ->whereMonth('start_time', $month)
      ->where('branch_id', $branch_id)
      ->where('action', 'missed')
      ->count();

    $received_call_count = CloudCallModel::whereYear('start_time', $year)
      ->whereMonth('start_time', $month)
      ->where('branch_id', $branch_id)
      ->where('action', 'received')
      ->count();

    $not_atten_call_count = CloudCallModel::whereYear('start_time', $year)
      ->whereMonth('start_time', $month)
      ->where('branch_id', $branch_id)
      ->whereNull('action') // Correct way to check NULL in Laravel
      ->where('status', 2)
      ->whereNotExists(function ($query) {
        $query->select(DB::raw(1))
          ->from('za_lead')
          ->whereRaw("RIGHT(za_cloud_call.caller_number, 10) = za_lead.lead_mobile");
      })
      ->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    // Return the view with the data and total count
    return view('content.sales.cloud_call.cloud_call_list', [
      'perpage' => $perpage,
      'month_chk' => $month_chk,
      'Call_log' => $Call_log,
      'reasonList' => $reasonList,
      'month' => $month,
      'year' => $year,
      'missed_call_count' => $missed_call_count,
      'not_atten_call_count' => $not_atten_call_count,
      'received_call_count' => $received_call_count,
      'customer_fill' => $customer_fill
    ])->with('filter_on', false);
  }

  // public function getCallLogs()
  // {

  //     $monitor = CronjobMonitorModel::where('sno', 14)->first();
  //     $start_time = microtime(true);
  //     // Get start time in India time
  //     $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
  //     if ($monitor) {
  //       if ($monitor->status != 0) {
  //         // Stop execution if cron is OFF
  //         return response()->json([
  //           'success' => false,
  //           'message' => 'Cronjob status Off'
  //         ]);
  //       }
  //       $monitor->running_status = 1;
  //       $monitor->save();
  //     }
  //     $branches = BranchModel::select('sno AS branch_id', 'cloud_call_api_key')
  //         ->where('status', 0)
  //         ->where('cloud_call_api_key', '!=', '')
  //         ->get();
  //     $inserted_records = 0; // Array to store inserted records

  //     if ($branches->isEmpty()) {
  //         return response()->json(['message' => 'Branch not found'], 404);
  //     }

  //     foreach ($branches as $branch) {

  //         $branch_id = $branch->branch_id;

  //         $apiToken = $branch->cloud_call_api_key;

  //         $apiKey     = "a908f1a416aff58127bf49ac926e1fa1dbd56be54a942a8b";      // API Key from Exotel Dashboard
  //         $apiToken    = "886cfe5e3782af70275b28d1c6b5e9e3735df10f64b2a790";    // API Token from Exotel Dashboard
  //         $accountSid  = "elysiumgroups3";  // Account SID from dashboard
  //         $subdomain   = "api.exotel.com";    // or api.sg.exotel.com

  //        // Start of yesterday in IST
  //         $from = Carbon::yesterday('Asia/Kolkata')->startOfDay()->toDateTimeString();
  //         // Current time in IST
  //         $to = Carbon::now('Asia/Kolkata')->toDateTimeString();
  //         // return [$from, $to];

  //         // $from = date('Y-m-d H:i:s', strtotime('2025-10-05 midnight'));
  //         // $to   = date('Y-m-d H:i:s', strtotime('2025-10-06 midnight'));

  //         // Build the “DateCreated” filter string
  //         $filter = "DateCreated=gte:{$from};lte:{$to}";

  //         $apiUrl = "https://{$subdomain}/v1/Accounts/{$accountSid}/Calls.json";

  //         // Pass the filter as query parameter
  //         $response = Http::withBasicAuth($apiKey, $apiToken)
  //             ->get($apiUrl, [
  //                 // Other filters if needed
  //                 'DateCreated' => "gte:{$from};lte:{$to}",
  //                 'PhoneNumber' => '08047095779' // 👈 Add this filter
  //             ]);

  //         if (!$response->successful()) {
  //             return response()->json([
  //                 'error'       => 'Failed to fetch call logs',
  //                 'status_code' => $response->status(),
  //                 'message'     => $response->body(),
  //             ], $response->status());
  //         }

  //         $calls = $response->json()['Calls'] ?? [];
  //         // return $calls;
  //         if (!isset($calls)) {
  //             return response()->json(['error' => 'No call logs found'], 404);
  //         }
  //         foreach ($calls as $call) {

  //             $callSid   = $call['Sid'];
  //             $caller    = $call['From'] ?? null;
  //             $receiver  = $call['To'] ?? null;
  //             $status    = $call['Status'] ?? null;
  //             $startTime = $call['DateCreated'] ?? null;
  //             $endTime = $call['DateUpdated'] ?? null;
  //             $Direction = $call['Direction'] ?? null;
  //             $durationSeconds = $call['Duration'] ?? 0;

  //             $hours   = floor($durationSeconds / 3600);
  //             $minutes = floor(($durationSeconds % 3600) / 60);
  //             $seconds = $durationSeconds % 60;

  //             $duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

  //             $Price  = $call['Price'] ?? 0;

  //             // Fetch recording for this call
  //             $recordingUrl = $call['RecordingUrl'] ?? null;

  //             $audioFilePath = null;

  //             if ($recordingUrl) {
  //                 try {
  //                     // Exotel requires API Key / Token to download recordings
  //                     $audioResponse = Http::withBasicAuth($apiKey, $apiToken)
  //                         ->get($recordingUrl);

  //                     if ($audioResponse->successful()) {
  //                         $folder = 'cloud_call_recordings';
  //                         $fileName = $callSid . '.mp3';
  //                         $publicDir = public_path($folder);

  //                         if (!File::exists($publicDir)) {
  //                             File::makeDirectory($publicDir, 0777, true, true);
  //                         }

  //                         $publicPath = $publicDir . '/' . $fileName;
  //                         file_put_contents($publicPath, $audioResponse->body());

  //                         $audioFilePath = $fileName; // save only filename in DB
  //                     } else {
  //                         // \Log::error("Failed to download audio, status: ".$audioResponse->status());
  //                     }
  //                 } catch (\Exception $e) {
  //                     // \Log::error("Error downloading audio for CallSid {$callSid}: ".$e->getMessage());
  //                 }
  //             }


  //             $model = CloudCallModel::updateOrCreate(
  //                 ['call_id' => $callSid],
  //                 [
  //                     'branch_id'       => $branch_id,
  //                     'caller_number'   => $caller,
  //                     'state'           => $Direction,
  //                     'start_time'      => $startTime,
  //                     'end_time'        => $endTime,
  //                     'duration'        => $duration,
  //                     'action'          => $status,
  //                     'price'           => $Price,
  //                     'log_details'     => json_encode($call),
  //                     'department_name' => 'Enquire',
  //                     'audioUrl'        => $recordingUrl,
  //                     'received_by'     => $receiver,
  //                     'audio_file'      => $audioFilePath,
  //                     'status'          => 1,
  //                     'call_app'          => 1,
  //                 ]
  //             );

  //             // Check if newly created or updated
  //             if ($model->wasRecentlyCreated) {
  //                 $inserted_records++;
  //             } else {
  //                 $inserted_records = max(0, $inserted_records - 1);
  //             }
  //         }
  //     }

  //     $end_time = microtime(true);
  //     $execution_time = round($end_time - $start_time, 4);

  //     $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
  //        // Convert seconds → H:i:s
  //     $hours   = floor($execution_time / 3600);
  //     $minutes = floor(($execution_time % 3600) / 60);
  //     $seconds = $execution_time % 60;
  //     $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

  //     if ($monitor) {

  //         // Update the monitor
  //         $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
  //         $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
  //         $monitor->sync_duration        = $duration;
  //         $monitor->running_status       = 0;
  //         $monitor->save();

  //         // Create a log record
  //         $monitor_log = new CronjobLogModel();
  //         $monitor_log->cronjob_id           = $monitor->sno;
  //         $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
  //         $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
  //         $monitor_log->sync_duration        = $duration;
  //         $monitor_log->response             = json_encode([
  //                                                 'inserted_records' => isset($inserted_records) ? $inserted_records : 0,
  //                                                 'execution_time'    => $duration,
  //                                             ]);
  //         $monitor_log->created_by  = 0;
  //         $monitor_log->updated_by  = 0;
  //         $monitor_log->save();
  //     }

  //     // Return the count of updated records
  //     return [
  //         'inserted_records' => isset($inserted_records) ? $inserted_records : 0,
  //         'execution_time'    => "{$execution_time} seconds",
  //     ];
  // }

  public function getCallLogs()
  {
    $monitor = CronjobMonitorModel::where('sno', 14)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $branches = CloudCallApiSetupModel::where('status', 0)->get();
    $inserted_records = 0;
    $updated_records = 0;
    $errors = [];
    $branch_summary = []; // Track per branch statistics

    if ($branches->isEmpty()) {
      return response()->json(['message' => 'Branch not found'], 404);
    }

    foreach ($branches as $branch) {
      $branch_id = $branch->branch_id;
      $branch_info = DB::table('za_branch')->where('sno', $branch_id)->first();
      $branch_name = $branch_info->branch_type == 1 ? $branch_info->branch_name : $branch_info->franchise_name;

      // Initialize branch summary
      $branch_summary[$branch_name] = [
        'branch_id' => $branch_id,
        'api_key' => $branch->api_key,
        'calls_found' => 0,
        'inserted' => 0,
        'updated' => 0,
        'status' => 'success'
      ];

      $apiKey     = "a908f1a416aff58127bf49ac926e1fa1dbd56be54a942a8b";      // API Key from Exotel Dashboard
      $apiToken    = "886cfe5e3782af70275b28d1c6b5e9e3735df10f64b2a790";    // API Token from Exotel Dashboard
      $accountSid  = "elysiumgroups3";  // Account SID from dashboard
      $subdomain   = "api.exotel.com";  // or api.sg.exotel.com
      $from = Carbon::yesterday('Asia/Kolkata')->startOfDay()->toDateTimeString();
      $to = Carbon::now('Asia/Kolkata')->toDateTimeString();

      $apiUrl = "https://{$subdomain}/v1/Accounts/{$accountSid}/Calls.json";
      $branchAPIKEY = $branch->api_key;
      $phoneNumber = $branchAPIKEY;

      // Build query parameters
      $queryParams = [
        'DateCreated' => "gte:{$from};lte:{$to}",
      ];

      // Only add PhoneNumber if it's valid
      if (!empty($phoneNumber) && $this->isValidPhoneNumber($phoneNumber)) {
        $queryParams['PhoneNumber'] = $phoneNumber;
      } else {
        $branch_summary[$branch_name]['status'] = 'failed';
        $branch_summary[$branch_name]['error'] = 'Invalid or empty phone number: ' . $phoneNumber;
        $errors[] = [
          'branch' => $branch_name,
          'api_key' => $branchAPIKEY,
          'error' => 'Invalid or empty phone number: ' . $phoneNumber
        ];
        continue;
      }

      $response = Http::withBasicAuth($apiKey, $apiToken)
        ->get($apiUrl, $queryParams);

      if (!$response->successful()) {
        $errorMessage = $response->json()['RestException'][0]['Message'] ?? $response->body();
        $branch_summary[$branch_name]['status'] = 'failed';
        $branch_summary[$branch_name]['error'] = $errorMessage;
        $branch_summary[$branch_name]['status_code'] = $response->status();
        $errors[] = [
          'branch' => $branch_name,
          'api_key' => $branchAPIKEY,
          'error' => $errorMessage,
          'status_code' => $response->status()
        ];
        continue;
      }

      $calls = $response->json()['Calls'] ?? [];
      $branch_summary[$branch_name]['calls_found'] = count($calls);

      if (empty($calls)) {
        $branch_summary[$branch_name]['message'] = 'No calls found for this date range';
        continue;
      }

      $branch_inserted = 0;
      $branch_updated = 0;

      foreach ($calls as $call) {
        $callSid = $call['Sid'];
        $caller = $call['From'] ?? null;
        $receiver = $call['To'] ?? null;
        $status = $call['Status'] ?? null;
        $startTime = $call['DateCreated'] ?? null;
        $endTime = $call['DateUpdated'] ?? null;
        $Direction = $call['Direction'] ?? null;
        $durationSeconds = $call['Duration'] ?? 0;

        $hours = floor($durationSeconds / 3600);
        $minutes = floor(($durationSeconds % 3600) / 60);
        $seconds = $durationSeconds % 60;
        $duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
        $Price = $call['Price'] ?? 0;

        $recordingUrl = $call['RecordingUrl'] ?? null;
        $audioFilePath = null;

        if ($recordingUrl) {
          try {
            $audioResponse = Http::withBasicAuth($apiKey, $apiToken)
              ->get($recordingUrl);

            if ($audioResponse->successful()) {
              $folder = 'cloud_call_recordings';
              $fileName = $callSid . '.mp3';
              $publicDir = public_path($folder);

              if (!File::exists($publicDir)) {
                File::makeDirectory($publicDir, 0777, true, true);
              }

              $publicPath = $publicDir . '/' . $fileName;
              file_put_contents($publicPath, $audioResponse->body());
              $audioFilePath = $fileName;
            }
          } catch (\Exception $e) {
            // Log error if needed
          }
        }

        $model = CloudCallModel::updateOrCreate(
          ['call_id' => $callSid],
          [
            'branch_id'       => $branch_id,
            'caller_number'   => $caller,
            'state'           => $Direction,
            'start_time'      => $startTime,
            'end_time'        => $endTime,
            'duration'        => $duration,
            'action'          => $status,
            'price'           => $Price,
            'log_details'     => json_encode($call),
            'department_name' => 'Enquire',
            'audioUrl'        => $recordingUrl,
            'received_by'     => $receiver,
            'audio_file'      => $audioFilePath,
            'status'          => 1,
            'call_app'        => 1,
          ]
        );

        if ($model->wasRecentlyCreated) {
          $inserted_records++;
          $branch_inserted++;
        } else {
          // Check if model was updated (not newly created)
          if ($model->wasChanged()) {
            $updated_records++;
            $branch_updated++;
          }
        }
      }

      $branch_summary[$branch_name]['inserted'] = $branch_inserted;
      $branch_summary[$branch_name]['updated'] = $branch_updated;
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration = $duration;
      $monitor_log->response = json_encode([
        'inserted_records' => $inserted_records,
        'updated_records' => $updated_records,
        'total_records_processed' => $inserted_records + $updated_records,
        'execution_time' => $duration,
        'branches_processed' => count($branches),
        'branches_with_errors' => count($errors),
        'branch_wise_summary' => $branch_summary,
        'errors' => $errors
      ], JSON_PRETTY_PRINT);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    return [
      'success' => true,
      'summary' => [
        'inserted_records' => $inserted_records,
        'updated_records' => $updated_records,
        'total_records' => $inserted_records + $updated_records,
        'execution_time' => "{$execution_time} seconds",
        'branches_processed' => count($branches),
        'branches_with_errors' => count($errors)
      ],
      'branch_wise_summary' => $branch_summary,
      'errors' => $errors
    ];
  }

  /**
   * Validate phone number format
   */
  private function isValidPhoneNumber($phoneNumber)
  {
    // Remove any non-numeric characters
    $cleaned = preg_replace('/[^0-9]/', '', $phoneNumber);

    // Check if it's a valid phone number (adjust length as needed)
    $length = strlen($cleaned);

    // Allow numbers with 10-13 digits (adjust according to your needs)
    return $length >= 10 && $length <= 13;
  }



  public function getCallLogsnew()
  {
    $apiKey     = "a908f1a416aff58127bf49ac926e1fa1dbd56be54a942a8b";      // API Key from Exotel Dashboard
    $apiToken    = "886cfe5e3782af70275b28d1c6b5e9e3735df10f64b2a790";    // API Token from Exotel Dashboard
    $accountSid  = "elysiumgroups3";  // Account SID from dashboard
    $subdomain   = "api.exotel.com";    // or api.sg.exotel.com

    $apiUrl = "https://{$subdomain}/v1/Accounts/{$accountSid}/Calls.json";

    $response = Http::withBasicAuth($apiKey, $apiToken)->get($apiUrl);

    if (!$response->successful()) {
      return response()->json([
        'error'       => 'Failed to fetch call logs',
        'status_code' => $response->status(),
        'message'     => $response->body(),
      ], $response->status());
    }

    return $calls = $response->json()['Calls'] ?? [];

    foreach ($calls as $call) {
      $callSid   = $call['Sid'];
      $caller    = $call['From'] ?? null;
      $receiver  = $call['To'] ?? null;
      $status    = $call['Status'] ?? null;
      $startTime = $call['DateCreated'] ?? null;
      $duration  = $call['Duration'] ?? 0;

      $audioFilePath = null;
      $audioUrl      = null;

      // Fetch recording for this call
      $recUrl = "https://{$subdomain}/v1/Accounts/{$accountSid}/Calls/{$callSid}/Recordings";
      $recResponse = Http::withBasicAuth($apiKey, $apiToken)->get($recUrl);

      if ($recResponse->successful()) {
        $recordings = $recResponse->json()['Recordings'] ?? [];
        if (!empty($recordings)) {
          $recording = $recordings[0];
          $audioUrl  = $recording['Uri'];

          try {
            $audioResponse = Http::get($audioUrl);
            if ($audioResponse->successful()) {
              $folder = 'cloud_call_recordings';
              $fileName = $callSid . '.mp3';
              $publicDir = public_path($folder);
              if (!File::exists($publicDir)) {
                File::makeDirectory($publicDir, 0777, true, true);
              }
              $publicPath = $publicDir . '/' . $fileName;
              file_put_contents($publicPath, $audioResponse->body());
              $audioFilePath = $fileName;
            }
          } catch (\Exception $e) {
            // handle download error
          }
        }
      }

      // Save to DB
      CloudCallModel::updateOrCreate(
        ['call_id' => $callSid],
        [
          'caller_number' => $caller,
          'start_time'    => $startTime,
          'duration'      => $duration,
          'log_details'   => json_encode($call),
          'audioUrl'      => $audioUrl,
          'audio_file'    => $audioFilePath,
          'status'        => $status,
        ]
      );
    }

    return response()->json([
      'inserted_records' => count($calls),
      'message' => 'Exotel call logs stored successfully'
    ]);
  }


  public function spamLeadConvert(Request $request)
  {

    // return $request;
    $converted_to = $request->lead_convert_to;
    $cloud_call_id = $request->cloud_call_id;
    $created_by = $request->sales_staff_add;
    $lead_name = $request->lead_name;
    $spam_reason = $request->spam_reason;
    $reason_text = $request->reason_text;
    $spam_comments = $request->spam_comments;

    // return $request;

    $cloud_call = CloudCallModel::select('caller_number', 'start_time')->where('id', $cloud_call_id)->first();
    // return $cloud_call;

    if (strpos($cloud_call->caller_number, '+91') === 0) {
      $country_code = '91';
      $lead_mobile = substr($cloud_call->caller_number, 3); // Remove '+91'
    } elseif (strpos($cloud_call->caller_number, '+971') === 0) {
      $country_code = '971';
      $lead_mobile = substr($cloud_call->caller_number, 4); // Remove '+971'
    } else {
      $country_code = '';
      $lead_mobile = $cloud_call->caller_number; // No country code
    }

    if ($country_code == '') {
      $country_code = 91;
    }


    $registered_date    = date('Y-m-d', strtotime($cloud_call->start_time));
    $user_id            = $request->user()->user_id;
    $branch_id          = $request->user()->branch_id;

    // return $registered_date;

    $chk = LeadModel::where('lead_mobile', $lead_mobile)->where('za_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();

    if ($chk) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Mobile Number already created!'
      ]);
    } else {
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

      $branch_code = $branch_check->city_short_code;

      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      $year = date("Y");
      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      if ($converted_to == 1) {

        $add_category = new LeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->inter_calls             = $country_code;
        $add_category->registered_date         = $registered_date;
        $add_category->branch_id               = $branch_id;
        $add_category->lead_source_id          = 4;
        $add_category->cloud_call_id           = $cloud_call_id;
        $add_category->created_by              = $created_by;
        $add_category->updated_by              = $user_id;
        $add_category->lead_status_id          = 1;
        $add_category->lead_condition          = 2;


        // return $add_category;
        // return $add_category;
        $add_category->save();

        if ($add_category) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 8; // from Cloud Call
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
        }

        $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        // sms thank you lead
        if ($add_category) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }

        // Thank whatsapp message
        if ($add_category) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '9677781155',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }


        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      } else if ($converted_to == 2) {


        $add_category = new LeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->inter_calls             = $country_code;
        $add_category->registered_date         = $registered_date;
        $add_category->branch_id               = $branch_id;
        $add_category->lead_source_id          = 4;
        $add_category->cloud_call_id           = $cloud_call_id;
        $add_category->created_by              = $created_by;
        $add_category->updated_by              = $user_id;
        $add_category->status                  = 7;
        $add_category->lead_status_id          = 6;
        $add_category->spam_verified           = 0;
        $add_category->spam_tl_verified        = 0;
        $add_category->lead_condition          = 2;

        if ($spam_reason == 1) {
          $add_category->spam_reason = $request->reason_text;  // Set drop_reason from drop_reason_text
        } else {
          $spam = SpamReasonModel::where('reason_name', $spam_reason)->first();
          // return $spam;
          if ($spam->comments_check == 1) {
            $add_category->spam_comments = $request->spam_comments;
          }
          $add_category->spam_reason = $spam_reason;
        }

        // return $add_category;
        $add_category->save();

        if ($add_category) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 9; // from Cloud Call Spam
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
        }
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Spam Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
    }

    return redirect('/CloudCall');
  }
  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

  public function streamAudio()
  {
    $audioUrl = 'https://in.app.myoperator.com/audio/56930fde4fcadbb7fd5eb777d92de70b02c9cd37bac54d1abb0cbeec970845628787b777a0c900a9e843bea00693867f-v2';

    // Use an Authorization token (if available) or session cookie
    $response = Http::withHeaders([
      'User-Agent' => 'Mozilla/5.0',  // Avoid bot detection
      'Cookie' => '199.250.207.212:443',  // If MyOperator uses session-based authentication
      'Authorization' => $this->apiToken,
    ])->get($audioUrl);

    if ($response->failed()) {
      return response()->json(['error' => 'Unauthorized or audio access restricted'], 403);
    }

    return response($response->body(), 200)
      ->header('Content-Type', 'audio/mpeg');
  }
}
