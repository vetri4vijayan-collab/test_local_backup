<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\JustDialModel;
use App\Models\WebsiteleadModel;
use App\Models\LeadModel;
use App\Models\SulekhaModel;
use App\Models\UrbanProModel;
use App\Models\GoogleAdsModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\WhatsappApiConfigureModel;
use App\Services\DoubletickService;
use App\Models\EmailTemplateModel;
use App\Models\SmsTemplateModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Mail;
class OtherSourceLead extends Controller
{
    
  protected $doubletickService;
  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;
    
    public function __construct(DoubletickService $doubletickService)
  {
    $this->doubletickService = $doubletickService;
    $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
    $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
    $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
    $this->baseUrl = 'https://graph.facebook.com/v17.0';
    $this->businessId = $whatsappConfig->waba_id;
  }
  public function justdial(Request $request)
  {
    // http://erp.elysium.academy/justdial?leadid=JD57154BC2A4E7&leadtype=category&prefix=Ms&name=HIRAL&mobile=9820097546&phone=02224100086&email=&date=2012-06-22&category=Taxi+Services&area=Dadar+West&city=Mumbai&brancharea=Andheri+East&dncmobile=1&dncphone=0&company>>

    // Extract parameters from the URL
    $lead_id = $request->query('leadid');
    $lead_type = $request->query('leadtype');
    $prefix = $request->query('prefix');
    $name = $request->query('name');
    $mobile = $request->query('mobile');
    $phone = $request->query('phone');
    $email = $request->query('email');
    $date = $request->query('date');
    $category = $request->query('category');
    $area = $request->query('area');
    $city = $request->query('city');
    $branch_area = $request->query('brancharea');
    $dncmobile = $request->query('dncmobile');
    $dncphone = $request->query('dncphone');
    $company = $request->query('company');
    $pincode = $request->query('pincode');
    $time = $request->query('time');
    $branchpin = $request->query('branchpin');
    $parentid = $request->query('parentid');
    
    if($parentid == 'PX452.X452.160511121626.Q2Y4'){
       // Build query parameters
        $params = http_build_query([
            'leadid' => $lead_id,
            'leadtype' => $lead_type,
            'prefix' => $prefix,
            'name' => $name,
            'mobile' => $mobile,
            'phone' => $phone,
            'email' => $email,
            'date' => $date,
            'category' => $category,
            'area' => $area,
            'city' => $city,
            'brancharea' => $branch_area,
            'dncmobile' => $dncmobile,
            'dncphone' => $dncphone,
            'company' => $company,
            'pincode' => $pincode,
            'time' => $time,
            'branchpin' => $branchpin,
            'parentid' => $parentid,
        ]);
        
        // Final URL
        $url = "https://erp.elysiumtechnologies.com/justdial?" . $params;
        
        // Initialize cURL
        $ch = curl_init();
        
        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // Execute the request
        $response = curl_exec($ch);
        
        // Check for error
        if (curl_errno($ch)) {
            return response()->json(['error' => curl_error($ch)]);
        }
        
        // Close cURL
        curl_close($ch);
        
        // Return response (or do something with it)
        return response()->json(['response' => $response]);
    }
    if($parentid == 'PX452.X452.180308130054.N3D2'){
       // Build query parameters
        $params = http_build_query([
            'leadid' => $lead_id,
            'leadtype' => $lead_type,
            'prefix' => $prefix,
            'name' => $name,
            'mobile' => $mobile,
            'phone' => $phone,
            'email' => $email,
            'date' => $date,
            'category' => $category,
            'area' => $area,
            'city' => $city,
            'brancharea' => $branch_area,
            'dncmobile' => $dncmobile,
            'dncphone' => $dncphone,
            'company' => $company,
            'pincode' => $pincode,
            'time' => $time,
            'branchpin' => $branchpin,
            'parentid' => $parentid,
        ]);
        
        // Final URL
        $url = "https://erp.eibsglobal.com/justdial?" . $params;
        
        // Initialize cURL
        $ch = curl_init();
        
        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // Execute the request
        $response = curl_exec($ch);
        
        // Check for error
        if (curl_errno($ch)) {
            return response()->json(['error' => curl_error($ch)]);
        }
        
        // Close cURL
        curl_close($ch);
        
        // Return response (or do something with it)
        return response()->json(['response' => $response]);
    }
    // change cbe branch to hopes branch
    if($parentid == 'PX422.X422.180901175152.T7I3'){
        $parentid = 'PX422.X422.250609153129.C8N9';
    }
    
    
    
    $chk = JustDialModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();

    if ($chk) {
      return response()->json([
        'status' => 409,
        'message' => 'Mobile Number Already Exists',
      ], 409);
    } else {

      // If the lead doesn't exist, create it
      $add_category = new JustDialModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($name);
      $add_category->lead_mobile = $mobile;
      $add_category->lead_type = $lead_type;
      $add_category->lead_alternate_mobile = $phone;
      $add_category->lead_email_id = $email;
      $add_category->prefix = $prefix;
      $add_category->registered_date = $date;
      $add_category->state = $city;
      $add_category->city = $area;
      $add_category->area = $branch_area;
      $add_category->dnc_mobile = $dncmobile;
      $add_category->dnc_phone = $dncphone;
      $add_category->company = $company;
      $add_category->pincode = $pincode;
      $add_category->lead_knowledge_tags = $category;
      $add_category->time = $time;
      $add_category->branchpin = $branchpin;
      $add_category->parentid = $parentid;
      // return $add_category;
      $add_category->save();
    }
    
    
    return response()->json([
      'status' => 200,
      'message' => 'Received',
    ], 200);
  }
  
  public function website_lead(Request $request)
   {
        
        // http://erp.elysium.academy/website_lead?name=rosini&mobile=6874598745&email=rose@gmail.com&branch_id=BR-0006/24
        // Extract parameters from the URL
        $name = $request->query('name');
        $mobile = $request->query('mobile');
        $email = $request->query('email');
        $type = $request->query('type');
        if($type == 'https://embeddedschool.in/'){
            $branchpin = 6;
        }else{
            $branchpin = $request->query('branch');
        }
        
    
        // Check if the mobile number already exists
        $chk = WebsiteleadModel::where('lead_mobile', $mobile)->exists();
    
        if ($chk) {
            return response()->json([
                'status' => 409,
                'message' => 'Mobile Number Already Exists',
            ], 409);
        }
        try {
           DB::beginTransaction();
        
            // If the lead doesn't exist, create it
            $add_category_web = new WebsiteleadModel();
            $add_category_web->lead_name = ucfirst($name);
            $add_category_web->lead_mobile = $mobile;
            $add_category_web->lead_mail = $email;
            $add_category_web->type = $type;
            $add_category_web->branch_id = $branchpin;
            $add_category_web->save();
           
            $branch_get = BranchModel::select('sno', 'other_src_staff_id')
             ->where('sno', $branchpin)
             ->first();
            //  return $branch_get;
            if ($branch_get && $branch_get->other_src_staff_id) {

             $branch_sno = $branch_get->sno;
             $lead_mobile = $add_category_web->lead_mobile;
             $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 2;
    
             $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
             $branch_code = $branch_check->city_short_code ?? 'MDU';
    
             // Check if already number for this lead
            $alreadyBooked = LeadModel::where('lead_mobile', $lead_mobile)
                ->first();
        
            if ($alreadyBooked) {
                return response()->json([
                    'status'  => false,
                    'message' => 'You have already exit number.'
                ], 409);
            }
             $year = date("Y");
             $category_check = LeadModel::where('status', '!=', 2)
              ->orderBy('sno', 'desc')
              ->first();
    
             if (!$category_check) {
              $lead_id = "{$year}/{$branch_code}/LED0001";
             } else {
              $last_lead_id = $category_check->lead_id;
              $slice = explode("/", $last_lead_id);
              $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
              $next_number = (int)$resultcus + 1;
              $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
             }
    
             $add_category = new LeadModel();
             $add_category->lead_id = $lead_id;
             $add_category->lead_name = ucfirst($add_category_web->lead_name);
             $add_category->lead_mobile = $lead_mobile;
             $add_category->lead_email_id = $add_category_web->lead_mail;
             $add_category->branch_id = $branch_sno;
             $add_category->lead_source_id = 17;
             $add_category->website_id = $add_category_web->sno;
             $add_category->registered_date = now();
             $add_category->created_by = $lead_othr_src_staff;
             $add_category->updated_by = $lead_othr_src_staff;
             $add_category->lead_status_id = 1;
             $add_category->lead_condition = 2;
    
   
             if ($add_category->save()) {
              $add_history = new LeadTransferLogModel();
              $add_history->lead_id = $add_category->sno;
              $add_history->branch_id = $add_category->branch_id;
              $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
              $add_history->current_staff_id = $add_category->created_by;
              $add_history->change_staff_id = 0;
              $add_history->end_date = null;
              $add_history->transferred_from = 13;
              $add_history->created_by = $lead_othr_src_staff;
              $add_history->updated_by = $lead_othr_src_staff;
              $add_history->save();
    
                  $lead_update = WebsiteleadModel::where('sno', $add_category_web->sno)->first();
                  $lead_update->status = 2;
                  $lead_update->save();
            }
        }
          
            $branch_data = BranchModel::where('sno', $branchpin)->first();
            $branch_name = " ";
            if ($branch_data->branch_type == 1) {
              $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
              $branch_name = $branch_data->franchise_name;
            }
            // sms thank you lead
            if ($add_category) {
    
              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
              $authkey = $result_sms ? $result_sms->authkey : '';
              $sender_id = $result_sms ? $result_sms->sender_id : '';
              $template_id = $result_sms ? $result_sms->template_id : '';
              $country_code = $result_sms ? $result_sms->country_code : '';
              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
              $mobile_number = $country_code . $lead_mobile;
    
              $cre_mobile = $branch_data->cre_mobile ?? '9677781155';
    
              // Replace placeholders with actual values
              $replacement_values = [$add_category->lead_name, $cre_mobile];
              $message_content = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                  return array_shift($replacement_values);
                },
                $message_content
              );
    
              $route = "default";
              $postData = array(
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender' => $sender_id,
                'route' => $route,
              );
    
              // API URL
              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
              // Initialize the resource
              $ch = curl_init();
              curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
              ));
    
              // Get response
              $response = curl_exec($ch);
              // return $response;
              $err = curl_error($ch);
              curl_close($ch);
            }
            // Thank you email send
            if ($add_category && $add_category->lead_email_id) {
              $email_template_id = 6; // thank you template
              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
    
              $content = $emailTemplate->email_subject;
              $content = str_replace('#name', $add_category->lead_name, $content);
              $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
              $branchNo = $branch_data->mobile;
              $branchemail = $branch_data->mail;
              $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
              $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
              $content = str_replace('#salesNo', $branch_data->sales_mobile ? $branch_data->sales_mobile : '9677781155', $content);
              $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
              $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
              $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
    
              $mailData = [
                'url' => 'Eapl.com',
                'subject' => $emailTemplate->email_name,
                'content' => $content,
                'branchNo' => $branchNo,
                'branchemail' => $branchemail, // Use the message content from the request
                'fbLink' => $fbLink, // Use the message content from the request
                'instaLink' => $instaLink, // Use the message content from the request
                'salesMobile' => $branch_data->sales_mobile,
              ];
    
              $to_address = $add_category->lead_email_id;
              $from_address = 'elysiumacademy@elysium.community';
              $from_name = 'Elysium Academy ' . "\xC2\xAE";
              Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
            }
    
            // Thank whatsapp message
            if ($add_category) {
              $templateName = "elysium_academy_welcome_message";
    
              $hasHeader  = false; // Example flag: set based on template
              $hasBody    = false; // Example flag: set based on template
              $hasFooter  = false; // Example flag: set based on template
              $hasButton  = false;
              $components = [];
              $couponCode = " ";
              date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
              $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
              // $currentHour = date('H'); // Get current hour in 24-hour format
              if ($currentHour >= 5 && $currentHour < 12) {
                $greeting = 'Good Morning';
              } elseif ($currentHour >= 12 && $currentHour < 18) {
                $greeting = 'Good Afternoon';
              } else {
                $greeting = 'Good Evening';
              }
    
              if ($templateName == 'elysium_academy_welcome_message') {
    
                $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
                $couponCode  = 'NOOFFER';
                $buttonIndex = 0;
                $bodyText    = [
                  [
                    'type'           => 'text',
                    'text'           => $greeting,
                    'parameter_name' => 'greet_msg',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $add_category->lead_name,
                    'parameter_name' => 'customer_name',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                    'parameter_name' => 'web_link',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $branch_name,
                    'parameter_name' => 'branch_name',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $branch_data->cre_mobile ?? '9677781155',
                    'parameter_name' => 'contact_no',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                    'parameter_name' => 'contact_email',
                  ],
                ];
                $hasHeader = true;
                $hasBody   = true;
                $hasButton = true;
              }
    
              // Add Header if required
              if ($hasHeader) {
                $components[] = [
                  'type'       => 'header',
                  'parameters' => [
                    [
                      'type'  => 'image',
                      'image' => [
                        'link' => $headerImage, // Dynamically set header image
                      ],
                    ],
                  ],
                ];
              }
    
              // Add Body if required
              if ($hasBody) {
                $components[] = [
                  'type'       => 'body',
                  'parameters' => $bodyText,
                ];
              }
    
              // Add Footer if required
              if ($hasFooter) {
                $components[] = [
                  'type'       => 'footer',
                  'parameters' => [
                    [
                      'type'           => 'text',
                      'text'           => 'This is the footer text.',
                      'parameter_name' => 'footer_text',
                    ],
                  ],
                ];
              }
    
              // Add Button if required
              if ($hasButton) {
                $components[] = [
                  'type'       => 'button',
                  'sub_type'   => 'copy_code',
                  'index'      => $buttonIndex,
                  'parameters' => [
                    [
                      'type'        => 'coupon_code',
                      'coupon_code' => $couponCode,
                    ],
                  ],
                ];
              }
    
              $dynamicParameters         = $templateParameters[$templateName] ?? [];
              $WhatsAppBusinessAccountId = $this->businessId;
              $accessToken               = $this->accessToken;
              $fromPhoneNumberId         = $this->phoneNumberId;
    
              $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
              $to           = $lead_mobile;
              $languageCode = 'en_US';
    
              if (strpos($to, '+91') !== 0) {
                $to = '+91' . $to;
              }
    
              $message = 'test~message';
              if (empty($components)) {
                $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                    'name'     => $templateName,
                    'language' => [
                      'code' => $languageCode,
                    ],
                  ],
                ];
              } else {
                $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                    'name'       => $templateName,
                    'language'   => [
                      'code' => $languageCode,
                    ],
                    'components' => $components,
                  ],
                ];
              }
    
              $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            }
            DB::commit();
            return response()->json([
                'status' => 200,
                'message' => 'Lead Created Successfully',
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong. Please try again.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

  public function urbanpro(Request $request)
  {

    // http://erp.elysium.academy/urbanpro_mdu?secretkey=1234&name=Rosini&PhoneNumber=6987451234&location=SomeLocation&localityDetails=SomeArea&topicName=Maths&cityName=Madurai&created=2012-04-26&description=newlead


      $lead_id = $request->query('secretkey');
      $name = $request->query('name');
      $mobile = $request->query('PhoneNumber');
      $phone = $request->query('PhoneNumber');
      $date = $request->query('created');
      $category = $request->query('topicName');
      $state = $request->query('cityName');
      $pincode = $request->query('localityWithPinCode');
      $location = $request->query('localityDetails');
      $class_location = $request->query('classLocation');
      $desc = $request->query('description');
  
      // Check if lead already exists
      $chk = UrbanProModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();
  
      if ($chk) {
          return response()->json([
              'status' => 409,
              'message' => 'Mobile Number Already Exists',
          ], 409);
      }
  
      // Create new lead
      $add_category = new UrbanProModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($name);
      $add_category->lead_mobile = $mobile;
      $add_category->lead_alternate_mobile = $phone;
      $add_category->registered_date = $date ?? now(); // Use current timestamp if not provided
      $add_category->state = $state;
      $add_category->city = $location;
      $add_category->category = $category;
      $add_category->pincode = $pincode;
      $add_category->classLocation = $class_location;
      $add_category->description = $desc;
      $add_category->branch_id = 6;
  
      $add_category->save(); // Save the record
  
      return response()->json([
          'status' => 200,
          'message' => 'Lead Added Successfully',
      ], 200);
  }


  public function sulekha(Request $request)
  {

    // http://erp.elysium.academy/sulekha?userName=Kavitha&userMobile=698745123&userEmail=kavitha@info.org&userCity=madurai&userLocalities=kknagar&userComments=surfing&keywords=digitalmarketing


      $name = $request->query('userName');
      $mobile = $request->query('userMobile');
      $email = $request->query('userEmail');
      $state = $request->query('userCity');
      $city = $request->query('userLocalities');
      $desc = $request->query('userComments');
      $category = $request->query('keywords');
      $branch_id = $request->query('branchId');
  
      // Check if lead already exists
      $chk = SulekhaModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();
  
      if ($chk) {
          return response()->json([
              'status' => 409,
              'message' => 'Mobile Number Already Exists',
          ], 409);
      }
  
      // Create new lead
      $add_category = new SulekhaModel();
      $add_category->lead_name = ucfirst($name);
      $add_category->lead_mobile = $mobile;
      $add_category->lead_email = $email;
      $add_category->state = $state;
      $add_category->city = $city;
      $add_category->category = $category;
      $add_category->description = $desc;
      $add_category->branch_id = $branch_id;
  
      $add_category->save(); // Save the record
  
      return response()->json([
          'status' => 200,
          'message' => 'Lead Added Successfully',
      ], 200);
  }
  
//   public function googleads(Request $request)
//   {
//     // http://erp.elysium.academy/justdial?leadid=JD57154BC2A4E7&leadtype=category&prefix=Ms&name=HIRAL&mobile=9820097546&phone=02224100086&email=&date=2012-06-22&category=Taxi+Services&area=Dadar+West&city=Mumbai&brancharea=Andheri+East&dncmobile=1&dncphone=0&company>>

//     // Extract parameters from the URL
//     $data = $request->query('data');
    

//     // $chk = GoogleAdsModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();

//     // if ($chk) {
//     //   return response()->json([
//     //     'status' => 409,
//     //     'message' => 'Mobile Number Already Exists',
//     //   ], 409);
//     // } else {

//       // If the lead doesn't exist, create it
//       $add_category = new GoogleAdsModel();
//       $add_category->data = $data;
//       // return $add_category;
//       $add_category->save();
//     // }
//     return response()->json([
//       'status' => 200,
//       'message' => 'Received',
//     ], 200);
//   }

//     public function googleads(Request $request)
// {
//     $data = $request->query('data');

//     // Check if data is missing or empty
//     if (!$data) {
//         return response()->json([
//             'status' => 400,
//             'message' => 'Missing or empty data parameter',
//         ], 400);
//     }

//     $decoded = json_decode($data, true);

//     if (json_last_error() !== JSON_ERROR_NONE) {
//         return response()->json([
//             'status' => 400,
//             'message' => 'Invalid JSON format',
//         ], 400);
//     }

//     $add_category = new GoogleAdsModel();
//     $add_category->data = json_encode($decoded);
//     $add_category->save();

//     return response()->json([
//         'status' => 200,
//         'message' => 'Data received and stored',
//     ]);
// }

    public function googleads(Request $request)
    {
    $payload = $request->getContent(); // raw JSON body

    $decoded = json_decode($payload, true); // Convert to array
    // Validate Google Key
    if (!isset($decoded['google_key']) || $decoded['google_key'] !== 'myElysium166d9b0a') {
        return response()->json([
            'status' => 403,
            'message' => 'Unauthorized - Invalid Google Key',
        ], 403);
    }
    if (json_last_error() !== JSON_ERROR_NONE) {
        return response()->json([
            'status' => 400,
            'message' => 'Invalid JSON payload',
        ], 400);
    }

    // Optional: You can store the full data or extract fields
    $lead = new GoogleAdsModel();
    $lead->data = json_encode($decoded);
    $lead->save();

    return response()->json([
        'status' => 200,
        'message' => 'Lead received successfully',
    ]);
}

   public function facebookleads(Request $request)
    {
        // Your actual token and endpoint
        $accessToken = 'EAAZABjj0AYWIBO5N1ZBFyLfOpbiJZBdFdAv4p3JPar9Oc8xA4OpCj7RQfJHW7uzBOviQ3bsb6imqkvAMhXKeBvP1OVV8IjH8NgtTR6k5rNzckXuQSqTskVZCiElwEtXHc5oG8QZAA3crU9cRODPdLsZCUVWZCpaL0j6eQZB8Iw04ZAncjNCm1FYfnIVS0CjpxzrDPhAZDZD';
        $endpoint = 'https://graph.facebook.com/v23.0/1032291428641705/events?access_token=EAAZABjj0AYWIBO5N1ZBFyLfOpbiJZBdFdAv4p3JPar9Oc8xA4OpCj7RQfJHW7uzBOviQ3bsb6imqkvAMhXKeBvP1OVV8IjH8NgtTR6k5rNzckXuQSqTskVZCiElwEtXHc5oG8QZAA3crU9cRODPdLsZCUVWZCpaL0j6eQZB8Iw04ZAncjNCm1FYfnIVS0CjpxzrDPhAZDZD';

        // Build the payload
        $payload = [
            'data' => [
                [
                    'event_name' => 'Lead',
                    'event_time' => time(),
                    'action_source' => 'system_generated',
                    'custom_data' => [
                        'event_source' => 'CRM',
                        'lead_event_source' => 'Elysium Academy',
                    ],
                    'user_data' => [
                        'em' => [hash('sha256', $request->email)],
                        'ph' => [hash('sha256', $request->phone)],
                        'lead_id' => $request->lead_id
                    ]
                ]
            ]
        ];

        // Send request
        $response = Http::withToken($accessToken)
                        ->post($endpoint, $payload);

        return response()->json([
            'success' => $response->successful(),
            'facebook_response' => $response->json()
        ]);
    }
    
  
    // webhook.php
     
     public function facebookhandle(Request $request)
    {
    if ($request->isMethod('get')) {
        if ($request->query('hub_verify_token') === env('FB_VERIFY_TOKEN')) {
            return response($request->query('hub_challenge'));
        } else {
            return response('Invalid verification token', 403);
        }
    }

    $data = $request->all();
    $responses = [];

    foreach ($data['entry'] as $entry) {
        foreach ($entry['changes'] as $change) {
            $lead_id = $change['value']['leadgen_id'] ?? null;
            if ($lead_id) {
                $result = $this->fetchAndStoreLead($lead_id);
                $responses[] = $result;
            }
        }
    }

    return response()->json([
        'status' => 'done',
        'results' => $responses
    ]);
}

    protected function fetchAndStoreLead($lead_id)
    {
        $accessToken = env('FACEBOOK_ACCESS_TOKEN');
        $url = "https://graph.facebook.com/v19.0/{$lead_id}?access_token={$accessToken}";
    
        $response = Http::get($url);
    
        if ($response->successful()) {
            $lead_data = $response->json();
            $fields = [];
    
            foreach ($lead_data['field_data'] ?? [] as $field) {
                $fields[$field['name']] = $field['values'][0] ?? '';
            }
    
            // Save to DB
            DB::table('facebook_leads')->insertOrIgnore([
                'lead_id'    => $lead_id,
                'name'       => $fields['full_name'] ?? '',
                'email'      => $fields['email'] ?? '',
                'phone'      => $fields['phone_number'] ?? '',
                'created_at' => now(),
            ]);
    
            return [
                'status'  => 'success',
                'message' => 'Lead stored successfully',
                'lead_id' => $lead_id,
                'fields'  => $fields
            ];
        } else {
            return [
                'status'  => 'error',
                'message' => 'Failed to fetch lead from Facebook',
                'lead_id' => $lead_id,
                'error'   => $response->body()
            ];
        }
    }

 private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }



  

}