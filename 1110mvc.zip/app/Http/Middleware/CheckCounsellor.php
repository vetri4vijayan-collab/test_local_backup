<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckCounsellor
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // dd($request);
        // dd($request->bearerToken());
        // // \Log::info('Token:', ['token' => $request->bearerToken()]);
        // // \Log::info('Middleware User: ', [$request->user()]);
        // $user = $request->user();
        // dd($user);
        return $next($request);
    }
}
// class CheckCounsellor
// {
//     /**
//      * Handle an incoming request.
//      *
//      * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
//      */
//     // public function handle(Request $request, Closure $next): Response
//     // {
//     //     $authHeader = $request->header('Authorization');
//     //     // dd($request->headers->all());
//     //     $user = Auth::guard('api')->user();
//     //     dd($user);
//     //     // Check if the user is authenticated
//     //     if (!Auth::guard('api')->check()) {
//     //         return response()->json(['status' => 401, 'message' => 'Unauthorized'], 401);
//     //     }


//     //     $user = Auth::guard('api')->user();
//     //     $staff = StaffModel::where('sno', $user->user_id)->first();

//     //     // Check if the user is a counsellor and is active
//     //     if ($staff->accessible_app == 1 || $user->status == 0) {
//     //         return response()->json(['status' => 403, 'message' => 'Forbidden'], 403);
//     //     }

//     //     return $next($request);
//     // }
//     // public function handle(Request $request, Closure $next)
//     // {
//     //     $user = Auth::guard('api')->user();

//     //     // Check if the user is authenticated
//     //     if (!$user) {
//     //         return response()->json(['status' => 401, 'message' => 'Unauthorized'], 401);
//     //     }

//     //     // Fetch staff information based on the user
//     //     $staff = StaffModel::where('sno', $user->user_id)->first();

//     //     // Check if the user is a counsellor and is active
//     //     if (!$staff || $staff->accessible_app != 1 || $user->status != 0) {
//     //         return response()->json(['status' => 403, 'message' => 'Forbidden'], 403);
//     //     }

//     //     return $next($request);
//     // }
// }