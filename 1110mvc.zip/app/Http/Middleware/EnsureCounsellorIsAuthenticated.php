<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use App\Models\StaffModel;

class EnsureCounsellorIsAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Check if the user is authenticated
        if (!Auth::guard('api')->check()) {

            dd('Token not found or invalid');
            return response()->json(['status' => 401, 'message' => 'Unauthorized'], 401);
        }

        $user = Auth::guard('api')->user();
        dd($user);
        $staff = StaffModel::where('sno', $user->user_id)->first();

        // Check if the user is a counsellor and is active
        if ($staff->accessible_app == 1 || $user->status == 0) {
            return response()->json(['status' => 403, 'message' => 'Forbidden'], 403);
        }

        return $next($request);
    }
}