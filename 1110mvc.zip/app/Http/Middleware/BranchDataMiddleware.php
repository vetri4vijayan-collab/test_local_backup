<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Models\BranchModel;

class BranchDataMiddleware
{
    public function handle($request, Closure $next)
    {
        $user = Auth::user();
        if ($user) {
            $branch = BranchModel::select('za_branch.*', 'za_cities.name as city_name', 'za_cities.id as city_id')
                ->leftJoin('za_cities', 'za_branch.city_id', '=', 'za_cities.id')
                ->where('za_branch.sno', $user->branch_id)
                ->first();

            view()->share('branch_common', $branch);
        }

        return $next($request);
    }
}