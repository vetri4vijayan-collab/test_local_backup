<?php
namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ComposeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $subject;
    public $body;
    public $attachment;

    public function __construct($subject, $body, $attachment = null)
    {
        $this->subject = $subject;
        $this->body = $body;
        $this->attachment = $attachment;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subject,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'content.manage_gmail.email',  // Ensure this view exists
            with: [
                'body' => $this->body,
            ]
        );
    }
    
    public function attachments(): array
    {
        $attachments = [];
    
        if ($this->attachment) {
            // Move the file to storage and get the new path
            $storedFile = $this->attachment->store('attachments'); // Stores in `storage/app/attachments`
    
            // Get only the file name (without path)
            $attachments[] = basename($storedFile);
        }
    
        return $attachments;
    }
    
    
}