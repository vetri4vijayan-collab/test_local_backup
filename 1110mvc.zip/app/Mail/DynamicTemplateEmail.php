<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use App\Models\EmailTemplateModel;

class DynamicTemplateEmail extends Mailable
{
    use SerializesModels;

    public $lead;
    public $templateContent;

    public function __construct($lead, $templateId)
    {
        $this->lead = $lead;
        $this->templateContent = EmailTemplateModel::where('status', 0)
                                                   ->where('sno', $templateId)
                                                   ->first();
    }

    public function build()
{
    $content = $this->templateContent->email_body;

    // Replace placeholders with actual values
    $content = str_replace('#gender', $this->getGenderPrefix(), $content);
    $content = str_replace('#name', $this->lead->lead_name, $content);
    $content = str_replace('#coursename', $this->lead->course_name, $content);
    $content = str_replace('#contact1', $this->lead->branch_contact, $content);
    $content = str_replace('#contact2', $this->lead->phone_number, $content);

    // Log the email content (for debugging purposes)
    \Log::info('Sending email to: ' . $this->lead->lead_email);

    // Check if the email content meets certain criteria before sending
    if (empty($content)) {
        \Log::warning('Email content is empty, aborting email send.');
        return; // Do not return the email if the content is empty
    }

    // If content is valid, return the email to be sent
    return $this->view('emails.DynamicTemplate')
        ->with([
            'content' => $content,
            'subject' => $this->templateContent->email_subject
        ])
        ->subject($this->templateContent->email_subject);
}



    private function getGenderPrefix()
    {
        return $this->lead->lead_gender == 1 ? 'Mr' : 'Ms';
    }
}
