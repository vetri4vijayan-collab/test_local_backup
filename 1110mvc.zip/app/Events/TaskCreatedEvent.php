<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Queue\SerializesModels;

class TaskCreatedEvent implements ShouldBroadcastNow
{
    use SerializesModels;

    public $task;

    public function __construct($task)
    {
        $this->task = $task;
    }

    public function broadcastOn()
    {
        return new Channel('task-channel');
    }

    public function broadcastAs()
    {
        return 'task-created';
    }
}
