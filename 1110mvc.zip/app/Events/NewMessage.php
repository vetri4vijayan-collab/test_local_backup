<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;

class NewMessage implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message; // The message object to broadcast
    public $webhookData; // Full webhook data for logging or additional processing

    /**
     * Create a new event instance.
     *
     * @param mixed $message The message data to broadcast
     * @param array $webhookData Full webhook data for logging
     */
    public function __construct($message, $webhookData = [])
    {
        $this->message = $message;
        $this->webhookData = $webhookData;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new Channel('chat'); // Broadcast on the 'chat' channel
    }

    /**
     * The event's broadcast name.
     *
     * @return string
     */
    public function broadcastAs()
    {
        return 'message.received'; // Changed to match frontend expectations
    }

    /**
     * Get the data to broadcast.
     *
     * @return array
     */
    public function broadcastWith()
    {
        // Customize the data sent to the frontend
        return [
            'message' => $this->message,
            'webhookData' => $this->webhookData, // Include webhook data if needed
        ];
    }
}