<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditNotificationModel extends Model
{
    use HasFactory;
    public $table      = 'za_audit_notification';
    public $primaryKey = 'sno';

    protected $fillable = [
        'audit_id',
        'audit_staff_id',
        'notification_content',
        'notification_date',
        'created_by',
        'updated_by',
        'status',
        'notification_status',
    ];
}