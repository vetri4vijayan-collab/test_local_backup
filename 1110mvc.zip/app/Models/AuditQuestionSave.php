<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditQuestionSave  extends Model
{
    use HasFactory;
    public $table      = "za_audit_question_save";
    public $primaryKey = 'sno';

    protected $fillable = [
        'audit_id',
        'department_question_id',
        'audit_department_id',
        'audit_question_answer',
        'score',
        'created_by',
        'updated_by',
        'status',
    ];
}