<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AudioCategoryModel extends Model {
    use HasFactory;
    public $table      = 'za_audio_category';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'audio_category',
        'audio_desc',
        'created_by',
        'created_at',
        'status',
    ];
}