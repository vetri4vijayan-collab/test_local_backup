<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AIModel extends Model {
    use HasFactory;
    public $table      = 'za_ai_sugg';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        
        'ai',
        'ai_desc',
        'created_by',
        'created_at',
        'status',
    ];
}