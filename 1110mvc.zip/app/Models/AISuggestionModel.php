<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AISuggestionModel extends Model
{
    use HasFactory;
    public $table      = "za_ai_suggestion";
    public $primaryKey = 'sno';


    protected $fillable = [
        'role_id',
        'date',
        'suggestion_content',
        'created_by',
        'updated_by',
        'status',
    ];
}
