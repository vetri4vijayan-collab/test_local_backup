<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditScoreModel extends Model {

    use HasFactory;
    public $table      = 'za_audit_score';
    public $primaryKey = 'sno';

    protected $fillable = [
        'audit_score_id',
        'branch_id',
        'score_name',
        'score_min_value',
        'score_max_value',
        'score_color',
        'score_logo',
        'score_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}