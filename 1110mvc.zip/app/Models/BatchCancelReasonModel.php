<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchCancelReasonModel extends Model
{
    use HasFactory;
    public $table      = "za_batch_cancel_reason";
    public $primaryKey = 'sno';


    protected $fillable = [
        'sno',
        'branch_id',
        'reason_name',
        'comments_check',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}