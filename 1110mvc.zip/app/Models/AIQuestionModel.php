<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AIQuestionModel extends Model
{
  use HasFactory;
  public $table      = 'za_exam_ai_question';
  public $primaryKey = 'sno';
  //public $timestamps = false;

  protected $fillable = [
    'previous_count',
    'ask_count',
    'completed_count',
    'pending_count',
    'question_bank_id',
    'hint_check',
    'snippet_check',
    'explanations_check',
    'prompt',
    'created_by',
    'updated_by',
    'status',
  ];
}
