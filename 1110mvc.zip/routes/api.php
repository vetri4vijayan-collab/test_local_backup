<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\settings\course\CourseCategory;
use App\Http\Controllers\CounsellorApp\CounsellorAppController;
use App\Http\Controllers\StaffApp\StaffAppController;
use App\Http\Controllers\StudentApp\StudentAppController;
use App\Http\Controllers\ExamApp\ExamAppController;
use App\Http\Controllers\settings\counsellor\CategoryQuestion;
use App\Http\Controllers\BHApp\BHAppController;
use App\Http\Controllers\AuditApp\AuditAppController;
use App\Http\Controllers\WebHookHandler\WebhookReceiverController;
use App\Http\Controllers\WebHookHandler\WebhookReceiverEPROController;
use App\Http\Controllers\PcApp\PcAppController;
use App\Http\Controllers\WebHookHandler\WebhookController;
use App\Http\Controllers\mobile_apps\CallerPilotController;
use App\Http\Controllers\Api\BookingController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// In routes/api.php or routes/web.php
// Route::middleware(['counsellor'])->group(function () {
//     Route::post('/counsellor_quick_add', [CounsellorAppController::class, 'CounsellorQuickAdd']);
//     Route::get('/counsellor_course_category', [CounsellorAppController::class, 'CourseCategoryList']);
//     Route::get('/counsellor_lead_question', [CounsellorAppController::class, 'LeadQuestionList']);
// });

// pc app
Route::post('/pc_login', [PcAppController::class, 'StaffLogin']);
Route::post('/pc_otp_check', [PcAppController::class, 'verifyOtp']);
Route::post('/pc_profile_details', [PcAppController::class, 'pcProfileDetails']);
Route::post('/pc_profile_change', [PcAppController::class, 'pcProfileChange']);
Route::post('/pc_task_list', [PcAppController::class, 'pcTaskList']);
Route::post('/pc_task_view', [PcAppController::class, 'pcTaskView']);
Route::post('/pc_task_save', [PcAppController::class, 'pcTaskSave']);
Route::post('/pc_grievance', [PcAppController::class, 'pcGrievance']);
Route::post('/pc_issue_save', [PcAppController::class, 'pcTaskIssueSave']);
Route::post('/pc_logout', [PcAppController::class, 'StaffLogout']);


//EPRO API

Route::get('/department_college_get', [WebhookReceiverEPROController::class, 'DepartmentList']);
Route::post('/webhooks/add_college_department', [WebhookReceiverEPROController::class, 'DepartmentHook']);
 
Route::post('/webhooks/add_college', [WebhookReceiverEPROController::class, 'CollegeHook']);
Route::post('/webhooks/add_database', [WebhookReceiverEPROController::class, 'languageHook']);
Route::post('/webhooks/add_language', [WebhookReceiverEPROController::class, 'projectdomainHook']);
Route::post('/webhooks/add_domain', [WebhookReceiverEPROController::class, 'databaseHook']);
Route::post('/webhooks/add_project', [WebhookReceiverEPROController::class, 'manageprojectHook']);


// Verified Intern Certificate
Route::post('/webhook/certificate-data', [WebhookController::class, 'getCertificateData']);


// egc api
//Post
Route::post('/webhooks/add_broadcast', [WebhookReceiverController::class, 'broadcastMessage']);
Route::post('/webhooks/new_department', [WebhookReceiverController::class, 'DepartmentHook']);
Route::post('/webhooks/new_division', [WebhookReceiverController::class, 'DivisionHook']);
Route::post('/webhooks/new_job_position', [WebhookReceiverController::class, 'JobPositionHook']);
Route::post('/webhooks/new_staff_add', [WebhookReceiverController::class, 'StaffAddHook']);
Route::post('/webhooks/update_department_uuid', [WebhookReceiverController::class, 'UpdateDepartmentUUID']);
Route::post('/webhooks/update_division_uuid', [WebhookReceiverController::class, 'UpdateDivisionUUID']);
Route::post('/webhooks/update_jobrole_uuid', [WebhookReceiverController::class, 'UpdateJobPositionUUID']);
Route::post('/webhooks/update_staff_uuid', [WebhookReceiverController::class, 'UpdateStaffUUID']);
Route::post('/webhooks/update_userrole_uuid', [WebhookReceiverController::class, 'UpdateUserRoleUUID']);
Route::post('/webhooks/staff_attendance_update', [WebhookReceiverController::class, 'StaffAddAttendanceHook']);
Route::post('/webhooks/staff_attendance_update_essl', [WebhookReceiverController::class, 'StaffAddAttendanceHookEssl']);
Route::post('/webhooks/update_branch_target', [WebhookReceiverController::class, 'updateTargets']);
Route::post('/webhooks/add_transfer_staff', [WebhookReceiverController::class, 'AddTransferStaff']); 

// Get
Route::get('/staff_data_get', [WebhookReceiverController::class, 'StaffData']);
Route::get('/department_data_get', [WebhookReceiverController::class, 'DepartmentList']);
Route::get('/division_data_get', [WebhookReceiverController::class, 'DivisionList']);
Route::get('/job_role_data_get', [WebhookReceiverController::class, 'JobPostionList']);
Route::get('/get_user_role_egc', [WebhookReceiverController::class, 'UserRoleList']);
Route::get('/erp_user_credential_check', [WebhookReceiverController::class, 'userCrendentialCheck']);

Route::post('/webhooks/update_exist_staff', [WebhookReceiverController::class, 'UpdateExistStaff']);
Route::get('/exist-staff-count', [WebhookReceiverController::class, 'existStaffCount']);
Route::get('/exist-staff-list', [WebhookReceiverController::class, 'existStaffList']);
Route::get('/get_incentive_by_role', [WebhookReceiverController::class, 'GetIncentive']);
Route::post('/get_achieve_values', [WebhookReceiverController::class, 'getAchieveData']);

// egc end

Route::middleware(['counsellor'])->group(function () {
    Route::post('/counsellor_quick_add', [CounsellorAppController::class, 'CounsellorQuickAdd']);
    Route::get('/counsellor_course_category', [CounsellorAppController::class, 'CourseCategoryList']);
    Route::get('/counsellor_lead_question', [CounsellorAppController::class, 'LeadQuestionList']);

    Route::post('/counsellor_appointment_common', [CounsellorAppController::class, 'AppointmentCommon']);
    Route::post('/counsellor_not_yet_decided', [CounsellorAppController::class, 'NotYetDecided']);
    Route::post('/counsellor_appointment', [CounsellorAppController::class, 'Appointment']);
    Route::post('/counsellor_save_no', [CounsellorAppController::class, 'CounsellorSaveNo']);

    Route::get('/counsellor_self_assessment', [CounsellorAppController::class, 'AssessmentQuestionList']);
    Route::post('/self_assessment_save', [CounsellorAppController::class, 'SelectedCategory']);
    Route::post('/counsellor_category_question', [CounsellorAppController::class, 'CategoryQuestionList']);
    Route::post('/counsellor_category_question_save', [CounsellorAppController::class, 'CategoryQuestionSave']);
    Route::post('/counsellor_category_Score_board', [CounsellorAppController::class, 'ScoreBoard']);
    Route::get('/course_question_list', [CounsellorAppController::class, 'CourseQuestion']);
    Route::post('/counsellor_course_question_save', [CounsellorAppController::class, 'CourseQuestionSave']);
    Route::post('/get_course', [CounsellorAppController::class, 'GetCourse']);
    Route::post('/selected_course', [CounsellorAppController::class, 'SelectedCourse']);
    Route::post('/course_offer', [CounsellorAppController::class, 'CourseOffer']);
    Route::post('/coupon_code', [CounsellorAppController::class, 'couponCode']);

    Route::get('/counsellor_feedback', [CounsellorAppController::class, 'Feedback']);
    Route::get('/offer_page', [CounsellorAppController::class, 'OfferPage']);
    Route::post('/counsellor_batch_list', [CounsellorAppController::class, 'BatchList']);
    Route::post('/counsellor_trackList', [CounsellorAppController::class, 'TrackList']);


    Route::post('/counsellor_feedback_save', [CounsellorAppController::class, 'FeedbackSave']);

    Route::post('/student_payment', [CounsellorAppController::class, 'Payment']);
    Route::post('/complete_payment', [CounsellorAppController::class, 'customerPayment']);

    Route::post('/counsellor_trackview', [CounsellorAppController::class, 'TrackView']);
    Route::post('/staff_list', [CounsellorAppController::class, 'StaffList']);
    Route::get('/counsellor_course', [CounsellorAppController::class, 'CourseList']);
    Route::post('/appointment_list', [CounsellorAppController::class, 'AppointmentList']);
    Route::post('/counsellor_dashboard', [CounsellorAppController::class, 'Dashboard']);
    Route::post('/student_list', [CounsellorAppController::class, 'leadList']);

    Route::post('/batch_save', [CounsellorAppController::class, 'BatchSave']);
    Route::post('/report_list', [CounsellorAppController::class, 'Report']);

    Route::post('/generate_qr_code', [CounsellorAppController::class, 'generateQrCode']);
    Route::get('guidy/app_update_check', [CounsellorAppController::class, 'appUpdateCheck']);
    // Route::get('/category_question', [CategoryQuestion::class, 'List'])->name('category_question');
});

// counsellor login
Route::post('/counsellor_login', [CounsellorAppController::class, 'CounsellorLogin']);
Route::post('/counsellor_otp_check', [StaffAppController::class, 'verifyOtp']);
Route::get('/app_update_check', [StaffAppController::class, 'appUpdateCheck']);
// Route::post('/counsellor_login', [CounsellorAppController::class, 'CounsellorLogin'])->middleware('throttle:10,1');
// ```

// This limits the login attempts to 10 per minute.




// staff login
Route::post('/staff_login', [StaffAppController::class, 'StaffLogin']);
Route::post('/staff_otp_check', [StaffAppController::class, 'verifyOtp']);

Route::post('/staff_under_list', [StaffAppController::class, 'staffUnderlist']);
Route::post('/staff_batch', [StaffAppController::class, 'staffBatch']);
Route::post('/staff_batch_details', [StaffAppController::class, 'staffBatchDetails']);
Route::post('/staff_batch_student', [StaffAppController::class, 'staffBatchStudent']);
Route::post('/staff_batch_course', [StaffAppController::class, 'staffBatchCourse']);
Route::post('/staff_course_view', [StaffAppController::class, 'staffCourseView']);
Route::post('/staff_attendance_save', [StaffAppController::class, 'staffAttendance']);
Route::put('/staff_syllabus_list', [StaffAppController::class, 'staffSyllubusList']);
Route::post('/staff_syllabus_save', [StaffAppController::class, 'staffSyllabusUpdate']);
Route::put('/staff_dasboard', [StaffAppController::class, 'staffDasboard']);
Route::post('/staff_battery_heart', [StaffAppController::class, 'staffBatteryHeart']);

Route::post('/staff_exam_dasboard', [StaffAppController::class, 'StaffExamDash']);

Route::post('/course_material_staff', [StaffAppController::class, 'CourseMaterial']);

Route::post('/course_material_by_type_id_staff', [StaffAppController::class, 'CourseMaterialByTypeId']);


//Vasanthan Raj
Route::get('/staff_course', [StaffAppController::class, 'StaffCourseList']);
Route::post('/staff_exam_topic_list', [StaffAppController::class, 'StaffExamTopicList']);
Route::post('/staff_exam_questions', [StaffAppController::class, 'ExamQuestions']);
Route::post('/staff_save_answer', [StaffAppController::class, 'saveAnswer']);
Route::post('/staff_exam_complete_list', [StaffAppController::class, 'ExamCompleteList']);
Route::post('/staff_exam_result', [StaffAppController::class, 'ExamResult']);

// Student APP
// rosini 
Route::post('/student_login', [StudentAppController::class, 'StudentLogin']);
Route::post('/student_otp_check', [StudentAppController::class, 'verifyOtp']);
Route::post('/batch_details', [StudentAppController::class, 'Batchdetails']);   
Route::post('/attendance', [StudentAppController::class, 'AttendanceList']); 
Route::post('/attendance_chapter', [StudentAppController::class, 'AttendanceChapter']); 
Route::post('/student/daily-check', [StudentAppController::class, 'StudentDailyCheck']);
Route::post('/student/redeem_add', [StudentAppController::class, 'redeemAdd']);
Route::post('/student/redeem_list', [StudentAppController::class, 'redeemList']);
Route::match(['get','post'],'/customer_score', [StudentAppController::class, 'CustomerScore']);
Route::match(['get','post'],'/notification', [StudentAppController::class, 'Notification']);
//raj 
// Route::post('/customer_list', [StudentAppController::class, 'customerList']);
Route::post('/customer_course_list', [StudentAppController::class, 'customer_course_List']);
Route::post('/course_Payment_Combo', [StudentAppController::class, 'coursePaymentCombo']);
Route::post('/feedback_alert', [StudentAppController::class, 'feedbackAlert']);
Route::post('/course_rating', [StudentAppController::class, 'courseRating']);
Route::post('/customer_points', [StudentAppController::class, 'CustomerPoints']);
Route::post('/daily_status', [StudentAppController::class, 'StudentSyllabus']);
Route::post('/payment_history', [StudentAppController::class, 'paymentHistory']);

Route::post('/attendance_feedback', [StudentAppController::class, 'AttendanceFeedback']);
//Issuenote
Route::post('/issue_note_conversation', [StudentAppController::class, 'IssueNoteConversation']);
Route::post('/customer_issue_note_add', [StudentAppController::class, 'IssueNoteAdd']);
Route::post('/customer_issue_closed', [StudentAppController::class, 'IssueClosed']);
Route::post('/mark_seen', [StudentAppController::class, 'markSeen']);
Route::post('/customer_issue_note_list', [StudentAppController::class, 'IssueNoteList']);
Route::post('/date_based_course_topic', [StudentAppController::class, 'CourseTopic']);
Route::post('/job_interested_by_student', [StudentAppController::class, 'StudentJobInteresetAdd']);

Route::post('/profile_change', [StudentAppController::class, 'profileChange']);


//akilan
Route::post('/student_chapter_Details', [StudentAppController::class, 'studentChapterDetails']);
Route::post('/student_Chapter_section_list', [StudentAppController::class, 'studentSectionList']);
Route::post('/new_course_list', [StudentAppController::class, 'NewCourseList']);
Route::post('/existing_course_list', [StudentAppController::class, 'ExistingCourseList']);
Route::post('/interest_course_list', [StudentAppController::class, 'AddCourseList']);
Route::post('/add_course', [StudentAppController::class, 'AddCourseSave']);
Route::post('/remove_course', [StudentAppController::class, 'RemoveCourseSave']);
Route::post('/staff_student_list', [StaffAppController::class, 'staffStudentList']);

Route::post('/event_list', [StudentAppController::class, 'EventList']);
Route::post('/book_event', [StudentAppController::class, 'bookEvent']);
Route::post('/placement_list', [StudentAppController::class, 'PlacementList']);
Route::post('/placement_list_student', [StudentAppController::class, 'PlacementListStudent']);
Route::post('/Placement_list_interview', [StudentAppController::class, 'PlacementListInterview']);
Route::post('/placement_history_list', [StudentAppController::class, 'PlacementHistoryList']);
Route::post('/apply_job', [StudentAppController::class, 'ApplyInterestStudent']);
Route::post('/save_job', [StudentAppController::class, 'JobSave']);
Route::post('/remove_job', [StudentAppController::class, 'JobRemove']);
Route::post('/student_notification_list', [StudentAppController::class, 'NotificationList']);
Route::post('/student_clear_all', [StudentAppController::class, 'ClearAllNotifications']);
Route::post('/student_clear_notification/{id}', [StudentAppController::class, 'ClearSingleNotification']);



Route::post('/course_material', [StudentAppController::class, 'CourseMaterial']);
Route::post('/course_material_by_type_id', [StudentAppController::class, 'CourseMaterialByTypeId']);

Route::post('/add_contact_details', [StudentAppController::class, 'AddContactDetails'])->name('add_contact_details');
Route::post('/leaderBoardList', [StudentAppController::class, 'leaderShipBoard'])->name('leaderBoardList');
Route::match(['get','post'],'/ticket_closing', [StudentAppController::class, 'TicketClose']);


Route::post('/add_contacts', [StudentAppController::class, 'AddContactDetailsSelect'])->name('add_contacts');
Route::post('/exchange_reward', [StudentAppController::class, 'exchangeReward'])->name('exchange_reward');

Route::post('/payment_list', [StudentAppController::class, 'PaymentList']);
Route::get('/app_update_check', [StudentAppController::class, 'appUpdateCheck']);
Route::post('/payment_save', [StudentAppController::class, 'PaymentSave']);
Route::post('/coupon_amount', [StudentAppController::class, 'couponAmount']);

// students feedback
Route::get('/feedback_category', [StudentAppController::class, 'category_list']);
Route::post('/feedback_request', [StudentAppController::class, 'feedback_request']);
Route::post('/feedback_allList', [StudentAppController::class, 'feedback_allList']);
Route::post('/issue_list', [StudentAppController::class, 'issue_list']);
Route::post('/issue_rating', [StudentAppController::class, 'issue_rating']);
Route::post('/overall_feedback_get', [StudentAppController::class, 'overallFeedbackget']);
Route::post('/overall_feedback_submit', [StudentAppController::class, 'overallFeedback']);
Route::post('/save-fcm-token', [StudentAppController::class, 'saveFcmToken']);
// end Student APP

        Route::post('/webhook/save-booking', [BookingController::class, 'saveBooking']);
        Route::post('/webhook/save-career-path', [BookingController::class, 'saveCareerPath']);
        Route::get('/webhook/branches', [BookingController::class, 'getBranches']);     
        
// exam login
Route::post('/exam_login', [ExamAppController::class, 'ExamLogin']);
Route::post('/exam_otp_check', [ExamAppController::class, 'verifyOtp']);
Route::post('/exam_course_list', [ExamAppController::class, 'StudentExamList']);
Route::post('/exam_topic_list', [ExamAppController::class, 'StudentExamTopicList']);
Route::get('/exam_guidelines', [ExamAppController::class, 'ExamGuidelines']);
Route::post('/exam_questions', [ExamAppController::class, 'ExamQuestions']);
Route::post('/save_answer', [ExamAppController::class, 'saveAnswer']);
Route::post('/exam_dasboard', [ExamAppController::class, 'ExamDash']);
Route::post('/exam_list', [ExamAppController::class, 'ExamList']);
Route::post('/exam_complete_list', [ExamAppController::class, 'ExamCompleteList']);
Route::post('/exam_result', [ExamAppController::class, 'examResult']);

// BH App
Route::post('/bh_login', [BHAppController::class, 'bhLogin']);
Route::post('/bh_otp_check', [BHAppController::class, 'verifyOtp']);
Route::post('/bh_dashboard', [BHAppController::class, 'bhDashBoard']);
Route::post('/bh_course_list', [BHAppController::class, 'bhCourseList']);
Route::post('/bh_staff_list', [BHAppController::class, 'bhstaffList']);
Route::get('/bh_department_dropdown', [BHAppController::class, 'bhDepartmentList']);
Route::post('/bh_position_dropdown', [BHAppController::class, 'bhPositionList']);
Route::post('/bh_staff_details', [BHAppController::class, 'bhStaffDetails']);
Route::post('/bh_course_type_dropdown', [BHAppController::class, 'bhCourseTypeList']);
Route::post('/bh_course_details', [BHAppController::class, 'bhCourseDetails']);
Route::post('/bh_active_lead_list', [BHAppController::class, 'bhActiveList']);
Route::post('/bh_spam_lead_list', [BHAppController::class, 'bhSpamList']);
Route::post('/bh_dead_lead_list', [BHAppController::class, 'bhDeadList']);
Route::post('/bh_harvesting_list', [BHAppController::class, 'bhHarvestingList']);
Route::post('/bh_collection_list', [BHAppController::class, 'bhcollectionList']);
Route::post('/bh_outstanding_list', [BHAppController::class, 'bhOutstandingList']);

Route::post('/bh_branch_list', [BHAppController::class, 'bhBranchList']);
Route::post('/bh_change_branch', [BHAppController::class, 'bhChangeBranch']);
Route::post('/bh_get_Targets', [BHAppController::class, 'bhgetTargets']);

// Branch Audit
Route::post('/audit_login', [AuditAppController::class, 'AuditLogin']);
Route::post('/otp_check', [AuditAppController::class, 'verifyOtp']);
Route::post('/audit_dashboard', [AuditAppController::class, 'auditDashCount']);
Route::post('/audit_activelist', [AuditAppController::class, 'AuditActiveList']);
Route::post('/audit_completedlist', [AuditAppController::class, 'AuditCompleteList']);
Route::post('/audit_start', [AuditAppController::class, 'AuditStart']);
Route::post('/audit_questions_list', [AuditAppController::class, 'AuditQuestionsList']);
Route::post('/audit_question_save', [AuditAppController::class, 'AuditQuestionSave']);
Route::post('/view_audit_report', [AuditAppController::class, 'ReviewAudit']);
Route::post('/reschedule', [AuditAppController::class, 'AuditReschedule']);
Route::post('/audit_notification_list', [AuditAppController::class, 'auditNotficationList']);
Route::post('/audit_notification_marked', [AuditAppController::class, 'auditMarkUsRead']);
Route::post('/audit_notify_clear_all', [AuditAppController::class, 'ClearAllNotifications']);
Route::post('/audit_notify_clear_notification/{id}', [AuditAppController::class, 'ClearSingleNotification']);

// new Call Tracker
// sales App
Route::prefix('sales_app')->group(function () {
    Route::post('/staff_login', [CallerPilotController::class, 'StaffLogin']);
    Route::post('/verify_otp_staff', [CallerPilotController::class, 'verifyOtp']);
 
    Route::middleware(['salesauth.jwt'])->group(function () {
        Route::get('/staff_details', [CallerPilotController::class, 'staffDetails']);
        Route::get('/lead_list', [CallerPilotController::class, 'LeadList']);
        Route::get('/lead_detail_by_id', [CallerPilotController::class, 'LeadDetail']);
        Route::get('/lead_source_list', [CallerPilotController::class, 'leadSourceList']);
        Route::get('/product_list', [CallerPilotController::class, 'productList']);
        Route::get('/followup_list', [CallerPilotController::class, 'FollowupList']);
        Route::post('/followup_add', [CallerPilotController::class, 'FollowupAdd']);
        Route::post('/followup_detail', [CallerPilotController::class, 'FollowupDetail']);
        Route::post('/followup_reschedule', [CallerPilotController::class, 'FollowupReschedule']);
        Route::post('/followup_close', [CallerPilotController::class, 'FollowupClose']);
        Route::get('/team_call_list', [CallerPilotController::class, 'TeamCallList']);
        Route::get('/team_call_by_staff_id', [CallerPilotController::class, 'TeamCallByStaffId']);
        Route::get('/lead_dashboard_card', [CallerPilotController::class, 'LeadDashboardCard']);
        Route::get('/followup_dashboard', [CallerPilotController::class, 'FollowupDashboard']);
        Route::get('/team_call_dashboard', [CallerPilotController::class, 'TeamCallDashboard']);
        Route::get('/call_dashboard', [CallerPilotController::class, 'CallDashboard']);
        Route::get('/followup_reason_list', [CallerPilotController::class, 'followupReasonList']);
        Route::post('/call_tracker_log_save', [CallerPilotController::class, 'CallTrackerLogSave']);
        Route::get('/staff_call_log_list', [CallerPilotController::class, 'StaffCallLogList']);
        Route::post('/contact_call_history_by_phone', [CallerPilotController::class, 'ContactCallHistoryByPhone']);
        Route::post('/contact_detail_by_phone', [CallerPilotController::class, 'ContactDetailByPhone']);
        Route::post('/role_check_by_user_id', [CallerPilotController::class, 'roleCheckByUserId']);
         Route::post('/cug_staff_last_login', [CallerPilotController::class, 'cugStaffLastLogin']);
          Route::post('/update_online_status', [CallerPilotController::class, 'updateOnlineStatus']);
          Route::post('/application_alive', [CallerPilotController::class, 'applicationAlive']);
          Route::get('/this_week_call_bar_chart_count', [CallerPilotController::class, 'thisWeekCallBarChartCount']);
         Route::post('/update_app_version', [CallerPilotController::class, 'updateAppVersion']);
      });
      


 
});


