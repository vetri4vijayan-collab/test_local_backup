<?php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;
use App\Models\GeneralSettingsModel;
use App\Models\ServiceVarientModel;
use App\Models\ManageCoursesModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\BatchHistoryModel;
use App\Models\JobRollModel;
use App\Models\PreSkillSetModel;
use App\Models\BrandModel;
use App\Models\GroupModel;
use App\Models\KnowledgeLevelModel;
use App\Models\CourseActionModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\DocumentTypeModel;
use App\Models\BranchTypeModel;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\JobpositionModel;
use App\Models\TimeZoneModel;
use App\Models\CurrencyFormatModel;
use App\Models\FacilityModel;
use App\Models\TrainingModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\InterviewTypeModel;
use App\Models\HrDirectoryModel;
use App\Models\JobDirectoryModel;
use App\Models\ManageQuestionModel;
use App\Models\UserRolePermissionModel;
use App\Models\FinancialYearModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\Rules_guidelinesModel;
use App\Models\ShiftTimeModel;
use App\Models\SyllabusUpdateModel;
use App\Models\SlotModel;
use App\Models\BatchModel;
use App\Models\NotificationTypeModel;
use App\Models\NotificationModel;
use App\Models\ExamModel;
use App\Models\MaterialTypeModel;
use App\Models\MarketingModel;
use App\Models\Student;
use App\Models\PointsModel;
use App\Models\CustomerPlacementModel;
use App\Models\ManageCouponHistoryModel;
use App\Models\ManageCouponModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

use App\Models\AppointmentModel;
use App\Models\LeadAppointmentModel;
use App\Models\Addon_product_VariantModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Models\GoalSetStaffModel;
use App\Models\CustomerModel;
use App\Models\CurrencyRateModel;
use App\Models\ProposalModel;

class Helpers
{
    protected static $branch_id = 1;
    public static function appClasses()
    {
        $data = config('custom.custom');
        // default data array
        $DefaultData = [
            'myLayout' => 'vertical',
            'myTheme' => 'theme-default',
            'myStyle' => 'light',
            'myRTLSupport' => true,
            'myRTLMode' => true,
            'hasCustomizer' => true,
            'showDropdownOnHover' => true,
            'displayCustomizer' => true,
            'contentLayout' => 'compact',
            'headerType' => 'fixed',
            'navbarType' => 'fixed',
            'menuFixed' => true,
            'menuCollapsed' => false,
            'footerFixed' => false,
            'menuFlipped' => false,
            // 'menuOffcanvas' => false,
            'customizerControls' => [
                'rtl',
                'style',
                'headerType',
                'contentLayout',
                'layoutCollapsed',
                'showDropdownOnHover',
                'layoutNavbarOptions',
                'themes',
            ],
            //   'defaultLanguage'=>'en',
        ];
        // if any key missing of array from custom.php file it will be merge and set a default value from dataDefault array and store in data variable
        $data = array_merge($DefaultData, $data);

        // All options available in the template
        $allOptions = [
            'myLayout' => ['vertical', 'horizontal', 'blank', 'front'],
            'menuCollapsed' => [true, false],
            'hasCustomizer' => [true, false],
            'showDropdownOnHover' => [true, false],
            'displayCustomizer' => [true, false],
            'contentLayout' => ['compact', 'wide'],
            'headerType' => ['fixed', 'static'],
            'navbarType' => ['fixed', 'static', 'hidden'],
            'myStyle' => ['light', 'dark', 'system'],
            'myTheme' => ['theme-default', 'theme-bordered', 'theme-semi-dark'],
            'myRTLSupport' => [true, false],
            'myRTLMode' => [true, false],
            'menuFixed' => [true, false],
            'footerFixed' => [true, false],
            'menuFlipped' => [true, false],
            // 'menuOffcanvas' => [ true, false ],
            'customizerControls' => [],
            // 'defaultLanguage'=>array( 'en'=>'en', 'fr'=>'fr', 'de'=>'de', 'ar'=>'ar' ),
        ];

        //if myLayout value empty or not match with default options in custom.php config file then set a default value
        foreach ($allOptions as $key => $value) {
            if (array_key_exists($key, $DefaultData)) {
                if (gettype($DefaultData[$key]) === gettype($data[$key])) {
                    // data key should be string
                    if (is_string($data[$key])) {
                        // data key should not be empty
                        if (isset($data[$key]) && $data[$key] !== null) {
                            // data key should not be exist inside allOptions array's sub array
                            if (!array_key_exists($data[$key], $value)) {
                                // ensure that passed value should be match with any of allOptions array value
                                $result = array_search($data[$key], $value, 'strict');
                                if (empty($result) && $result !== 0) {
                                    $data[$key] = $DefaultData[$key];
                                }
                            }
                        } else {
                            // if data key not set or
                            $data[$key] = $DefaultData[$key];
                        }
                    }
                } else {
                    $data[$key] = $DefaultData[$key];
                }
            }
        }
        $styleVal = $data['myStyle'] == "dark" ? "dark" : "light";
        if (isset($_COOKIE['mode'])) {
            if ($_COOKIE['mode'] === "system") {
                if (isset($_COOKIE['colorPref'])) {
                    $styleVal = Str::lower($_COOKIE['colorPref']);
                }
            } else {
                $styleVal = $_COOKIE['mode'];
            }
        }
        isset($_COOKIE['theme']) ? $themeVal = $_COOKIE['theme'] : $themeVal = $data['myTheme'];
        //layout classes
        $layoutClasses = [
            'layout' => $data['myLayout'],
            'theme' => $themeVal,
            'themeOpt' => $data['myTheme'],
            'style' => $styleVal,
            'styleOpt' => $data['myStyle'],
            'rtlSupport' => $data['myRTLSupport'],
            'rtlMode' => $data['myRTLMode'],
            'textDirection' => $data['myRTLMode'],
            'menuCollapsed' => $data['menuCollapsed'],
            'hasCustomizer' => $data['hasCustomizer'],
            'showDropdownOnHover' => $data['showDropdownOnHover'],
            'displayCustomizer' => $data['displayCustomizer'],
            'contentLayout' => $data['contentLayout'],
            'headerType' => $data['headerType'],
            'navbarType' => $data['navbarType'],
            'menuFixed' => $data['menuFixed'],
            'footerFixed' => $data['footerFixed'],
            'menuFlipped' => $data['menuFlipped'],
            'customizerControls' => $data['customizerControls'],
        ];

        // sidebar Collapsed
        if ($layoutClasses['menuCollapsed'] == true) {
            $layoutClasses['menuCollapsed'] = 'layout-menu-collapsed';
        }

        // Header Type
        if ($layoutClasses['headerType'] == 'fixed') {
            $layoutClasses['headerType'] = 'layout-menu-fixed';
        }
        // Navbar Type
        if ($layoutClasses['navbarType'] == 'fixed') {
            $layoutClasses['navbarType'] = 'layout-navbar-fixed';
        } elseif ($layoutClasses['navbarType'] == 'static') {
            $layoutClasses['navbarType'] = '';
        } else {
            $layoutClasses['navbarType'] = 'layout-navbar-hidden';
        }

        // Menu Fixed
        if ($layoutClasses['menuFixed'] == true) {
            $layoutClasses['menuFixed'] = 'layout-menu-fixed';
        }


        // Footer Fixed
        if ($layoutClasses['footerFixed'] == true) {
            $layoutClasses['footerFixed'] = 'layout-footer-fixed';
        }

        // Menu Flipped
        if ($layoutClasses['menuFlipped'] == true) {
            $layoutClasses['menuFlipped'] = 'layout-menu-flipped';
        }

        // Menu Offcanvas
        // if ($layoutClasses['menuOffcanvas'] == true) {
        //   $layoutClasses['menuOffcanvas'] = 'layout-menu-offcanvas';
        // }

        // RTL Supported template
        if ($layoutClasses['rtlSupport'] == true) {
            $layoutClasses['rtlSupport'] = '/rtl';
        }

        // RTL Layout/Mode
        if ($layoutClasses['rtlMode'] == true) {
            $layoutClasses['rtlMode'] = 'rtl';
            $layoutClasses['textDirection'] = 'rtl';
        } else {
            $layoutClasses['rtlMode'] = 'ltr';
            $layoutClasses['textDirection'] = 'ltr';
        }

        // Show DropdownOnHover for Horizontal Menu
        if ($layoutClasses['showDropdownOnHover'] == true) {
            $layoutClasses['showDropdownOnHover'] = true;
        } else {
            $layoutClasses['showDropdownOnHover'] = false;
        }

        // To hide/show display customizer UI, not js
        if ($layoutClasses['displayCustomizer'] == true) {
            $layoutClasses['displayCustomizer'] = true;
        } else {
            $layoutClasses['displayCustomizer'] = false;
        }

        return $layoutClasses;
    }

    public static function updatePageConfig($pageConfigs)
    {
        $demo = 'custom';
        if (isset($pageConfigs)) {
            if (count($pageConfigs) > 0) {
                foreach ($pageConfigs as $config => $val) {
                    // Config::set('custom.' . $demo . '.' . $config, $val);
                }
            }
        }
    }

    function Logo_pic($pic)
    {
        if ($pic) {
            return url('logos/' . $pic);
        } else {
            return ""; // Return an empty string if no picture is provided
        }
    }

    function Fav_Icon_pic($pic)
    {
        if ($pic) {
            return url('fav_icons/' . $pic);
        } else {
            return ''; // Return an empty string if no picture is provided
        }
    }
    // ******************************** Vasanth ****************************
    //goalset
    function goal_staff_student_count_data($staff_id = '')
    {
        $current_date = date('Y-m-d'); // Define the current date

        return TrainingModel::where('et_training.status', 0)
            ->where('et_batch.status', 0)
            ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
            ->where('et_training.staff_id', $staff_id)
            ->where('et_batch.start_date', '<=', $current_date)
            ->where('et_batch.end_date', '>=', $current_date)
            ->count();
    }

    function goal_staff_costing($staff_id = '')
    {
        $result = TrainingModel::where('et_training.status', 0)->where('et_batch.status', 0)
            ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
            ->where('et_training.staff_id', $staff_id)->count();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //goalset

    function get_branch_staff_list_by_id($branch_id)
    {
        $result = StaffModel::select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.branch_id', $branch_id)


            ->orderBy('et_staff.staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_points_by_id($id = '')
    {
        $result = PointsModel::where('status', 0)->where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Dashboard
    function get_batch_student_count_data($batch = '')
    {
        $result = TrainingModel::where('status', 0)->where('batch_id', $batch)->count();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_batch_today_syllabus_count_data($batch = '')
    {
        $result = SyllabusUpdateModel::where('batch_id', $batch)->whereDate('created_at', '=', date('Y-m-d'))->count();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_staff_student_count_data($staff_id = '')
    {
        $result = TrainingModel::where('et_training.status', 0)->where('et_batch.status', 0)
            ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
            ->where('et_training.staff_id', $staff_id)->count();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_staff_courrse_count_data($staff_id = '')
    {
        $result = TrainingModel::where('status', 0)
            ->where('staff_id', $staff_id)
            ->groupBy('course_id')
            ->count();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_staff_student_feedback($staff_id = '')
    {
        // Ensure staff_id is provided and is a valid value
        if (empty($staff_id)) {
            return null;
        }

        // Fetch the results based on the criteria
        $result = AttendanceModel::select("et_attendance.*", "et_course.course_name", "et_batch.batch_name", "et_customer.cus_name", "et_customer.cus_pic", "et_customer.cus_gender")
            ->where('et_attendance.attendance', 'P')
            ->where('et_attendance.feedback', '!=', '')
            ->leftJoin('et_course', 'et_attendance.course_id', '=', 'et_course.sno')
            ->leftJoin('et_customer', 'et_attendance.customer_id', '=', 'et_customer.sno')
            ->leftJoin('et_batch', 'et_attendance.batch_id', '=', 'et_batch.sno')
            ->where('et_attendance.staff_id', $staff_id)
            ->orderBy('et_attendance.sno', 'DESC')
            ->limit(5)
            ->get();

        // Return null if no results are found, otherwise return the results
        return $result->isEmpty() ? null : $result;
    }

    function get_atten_data_staff($staff_id = '', $date = '')
    {
        // Validate inputs
        if (empty($staff_id) || empty($date)) {
            return ''; // Return an empty string if required inputs are missing
        }

        // Format the date
        $atten_date = date('Y-m-d', strtotime($date));

        $result = StaffAttendanceModel::where('date', $atten_date)
            ->where('staff_id', $staff_id)
            ->first();

        // Return attendance if the record exists, otherwise return an empty string
        return $result ? $result->attendance : '';
    }
    // Attendance amount calc student
    function get_student_attendance_amount($cus_sno, $batch_sno, $course_sno)
    {
        $attendance = AttendanceModel::selectRaw('SUM(total_cost) AS total_att_amount, SUM(total_duration) AS total_att_hours')
            ->where('status', 1)
            ->where('attendance', 'P')
            ->where('customer_id', $cus_sno)
            ->where('batch_id', $batch_sno)
            ->where('course_id', $course_sno)
            ->first();

        // Handle null values by using the null coalescing operator
        $totalAttAmount = $attendance->total_att_amount ?? 0;
        $totalAttHours = $attendance->total_att_hours ?? 0;

        // Return both values as an array
        return [
            'total_att_amount' => $totalAttAmount,
            'total_att_hours' => $totalAttHours,
        ];
    }
    function get_payment_percentage($tran_sno, $cus_sno)
    {
        // Retrieve summed paidAmount and individual total_amounts for the specific course and batch
        $paymentDetails = TrainingModel::selectRaw('SUM(et_payment.paidAmount) as total_paid_amount, et_payment.total_amount')
            ->join('et_payment', 'et_training.payment_id', '=', 'et_payment.payment_id')
            ->where('et_training.customer_id', $cus_sno)
            ->where('et_training.sno', $tran_sno)
            ->groupBy('et_payment.total_amount')
            ->get(); // Use `get()` to handle multiple rows

        // Initialize total variables
        $totalPaidAmount = 0;
        $totalAmount = 0;

        // Iterate over the result set to accumulate values
        foreach ($paymentDetails as $payment) {
            $totalPaidAmount += $payment->total_paid_amount;
            $totalAmount += $payment->total_amount;
        }

        // Initialize payment percentage to 0
        $paymentPercentage = 0;

        // Calculate payment percentage if valid data is retrieved
        if ($totalAmount > 0) {
            $paymentPercentage = number_format(
                ($totalPaidAmount / $totalAmount) * 100,
                1
            );
        }

        // Return the calculated percentage
        return $paymentPercentage;
    }
    function get_long_absent_customers($cus_sno)
    {
        // Fetch attendance records with 'A' (Absent) status and sort them in descending order
        $attendanceDates = AttendanceModel::where('customer_id', $cus_sno)
            ->where('attendance', 'A')
            ->orderBy('att_date', 'desc') // Latest dates first
            ->pluck('att_date')
            ->toArray();

        // If there are less than 3 absent records, return 0
        if (count($attendanceDates) < 3) {
            return 0;
        }

        // Check if the last 3 dates are consecutive
        $first = strtotime($attendanceDates[0]);
        $second = strtotime($attendanceDates[1]);
        $third = strtotime($attendanceDates[2]);

        if ($second == strtotime("-1 day", $first) && $third == strtotime("-2 days", $first)) {
            return 1; // Last 3 absent days are consecutive
        }

        return 0; // Not consecutively absent for the last 3 days
    }




    function get_course_percentage($tran_sno, $cus_sno)
    {
        // Fetch training details
        $training = TrainingModel::find($tran_sno);
        if (!$training) {
            return 0; // If no training record found, return 0% progress
        }

        $batch_id = $training->batch_id;
        $course_id = $training->course_id;

        // Fetch attendance records with 'P' status
        $attendanceDates = AttendanceModel::where('customer_id', $cus_sno)
            ->where('batch_id', $batch_id)
            ->where('attendance', 'P')
            ->pluck('att_date'); // Fetch only dates for efficiency

        if ($attendanceDates->isEmpty()) {
            return 0; // No attendance records, return 0% progress
        }

        // Fetch the total number of course topics
        $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)->where('status', 0)->count();

        if ($course_topic_count == 0) {
            return 0; // Avoid division by zero
        }

        // Fetch syllabus updates for the attended dates
        $topicCount = SyllabusUpdateModel::where('batch_id', $batch_id)
            // ->whereIn('date', $attendanceDates)
            ->where('percentage', '100')
            ->distinct()
            ->count('sno'); // Ensure distinct topic count

        // Calculate course progress as a percentage
        $courseProgress = ($topicCount / $course_topic_count) * 100;

        // Cap the progress at 100% and format to 2 decimal places
        return number_format(min($courseProgress, 100), 2);
    }


    // schedule_messages
    public function scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId)
    {
        try {
            $addMessage = new Schedule_message_model();
            $addMessage->config_id = $configId;
            $addMessage->source_type_id = $sourceTypeId;
            $addMessage->source_id  = $sourceId;
            $addMessage->branch_id  = $branchId;
            $addMessage->created_by = $userId;
            $addMessage->updated_by = $userId;
            $addMessage->save();
            return response()->json([
                'status' => 200,
                'message' => 'Successfully scheduled message!',
                'error_msg' => null,
                'data' => $addMessage,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error scheduling message.',
                'error_msg' => $e->getMessage(),
                'data' => null,
            ], 500);
        }
    }


    function get_tracker_last_login_data($staff_mobile)
    {

        $other_db = DB::connection('mysql_secondary');
        $select_users = $other_db
            ->table('user as u')
            ->select('u.user_id', 'u.last_sync_date', 'u.last_sync_time')
            ->where('u.phone_no', $staff_mobile)
            ->first();
        return $select_users;
    }

    //   GET ROLE USRMANAGEMENT
    function get_roles_list()
    {
        // Fetch roles from the UserRoleModel
        $roles = UserRoleModel::where('status', 0)->get();

        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Filter roles to exclude those that are in userRolePermissions
        $filteredRoles = $roles->filter(function ($role) use ($userRolePermissions) {
            return !in_array($role->sno, $userRolePermissions); // Exclude roles with matching role_id
        });

        return $filteredRoles;
    }

    // Get SmS Tempalate
    function get_sms_template($id = '')
    {
        $result = SmsTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Whatsapp Template
    function get_whatsapp_template($id = '')
    {
        $result = WhatsappTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Email Template
    function get_email_template($id = '')
    {
        $result = EmailTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // function get_roles_list_nav($user_id = null)
    // {
    //     // Fetch the role IDs from UserRolePermissionModel
    //     $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

    //     // Fetch only the roles that exist in userRolePermissions
    //     $matchingRoles = UserRoleModel::where('status', 0)
    //         ->whereIn('sno', $userRolePermissions) // Only roles that match
    //         ->get();

    //     return $matchingRoles;
    // }

    function get_roles_list_nav($user_id = null)
    {
        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Get the user details
        $user = StaffModel::where('sno', $user_id)->first();

        // Special case for user with sno = 124
        if ($user && $user->sno == 1) {
            // Exclude roles with ID 1 and 11
            $matchingRoles = UserRoleModel::where('status', 0)
                // ->whereNotIn('sno', [9])
                ->whereIn('sno', $userRolePermissions)
                ->get();
        } else if ($user->role_id == 20) {
            $matchingRoles = UserRoleModel::where('status', 0)
                ->whereNotIn('sno', [1])
                ->whereIn('sno', $userRolePermissions)
                ->get();
        } else {
            $matchingRoles = UserRoleModel::where('status', 0)
                ->whereIn('sno', $userRolePermissions)
                ->get();
        }

        return $matchingRoles;
    }
    // Get Branch and Franchise list based on user_id
    function get_branch_control_list($user_id)
    {
        // Fetch the user based on user_id
        $user = StaffModel::where('sno', $user_id)->first();

        if ($user && $user->sno == 1) {
            $branches = BranchModel::where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();

            return ['branches' => $branches, 'franchises' => $franchises];
        } elseif ($user !== null) {
            // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
            $accessibleBranches = json_decode($user->multi_branch_access, true);

            if (!empty($accessibleBranches)) {
                // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
                $branches = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 1)
                    ->get();

                $franchises = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 2)
                    ->get();

                return ['branches' => $branches, 'franchises' => $franchises];
            }
        } else {
            // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
            $branches = BranchModel::where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();
            return ['branches' => $branches, 'franchises' => $franchises];
        }
    }



    // common Date Format
    function general_setting_data()
    {
        $sno = 1;
        $result = GeneralSettingsModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // encrypt_decrypt
    // function encrypt_decrypt($string, $action = 'encrypt')
    // {
    //     $encrypt_method = "AES-256-CBC";
    //     $secret_key = 'EAPL'; // Change this to your secret key
    //     $secret_iv = 'YourSecretIV'; // Change this to your secret IV

    //     $key = hash('sha256', $secret_key);
    //     $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

    //     if ($action == 'encrypt') {
    //         $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
    //         $output = base64_encode($output);
    //     } elseif ($action == 'decrypt') {
    //         $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    //     } else {
    //         $output = false;
    //     }

    //     return $output;
    // }
    function encrypt_decrypt($string, $action = 'encrypt')
    {
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'ETPL'; // Change this to your secret key
        $secret_iv = 'ABCDEFETPL46464566@#$%ETPL'; // Change this to your secret IV
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } elseif ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        } else {
            $output = false;
        }

        return $output;
    }
    // Get Country Names by ID
    function get_country_data($id = '')
    {
        $result = CountryModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get State Names by ID
    function get_state_data($id = '')
    {
        $result = StateModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get City Names by ID
    function get_city_data($id = '')
    {
        $result = CityModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Get Branch list
    function get_branch_list()
    {
        $result = BranchModel::where('status', 0)->where('branch_type', 1)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_branch_franchise_list()
    {
        $result = BranchModel::where('status', 0)->where('sno', '!=', 1)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Franchise list
    function get_franchise_list()
    {
        $result = BranchModel::where('status', 0)->where('branch_type', 2)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Branch id
    function get_branch_id($sno = "")
    {
        $result = BranchModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Franchise list
    function get_franchise_id($sno = "")
    {
        $result = BranchModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Role list
    function get_role_list()
    {
        $result = UserRoleModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Role id
    function get_role_id($sno = "")
    {
        $result = UserRoleModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Staff by id
    function get_staff_data($id = '')
    {
        $result = StaffModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Staff list
    function get_staff_list()
    {
        $result = StaffModel::where('status', 0)->orderBy('staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Name imgae user
    function name_image($ins = "A", $gender = 1)
    {
        // Array of all avatar divs
        if ($gender === 1) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-primary'>" . $ins . "</span>
            </div>";
        } else if ($gender === 2) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-info'>" . $ins . "</span>
            </div>";
        } else {
            $divs = "<div class='avatar  me-2'>
              <span class='avatar-initial rounded-circle bg-label-warning'>" . $ins . "</span>
            </div>";
        }

        return $divs;
    }
    // get course type data
    function get_course_type_data($sno = '')
    {
        $result = CourseTypeModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_course_data($sno = '')
    {
        $result = ManageCoursesModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_batch_data($sno = '')
    {
        $result = BatchModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_slot_data($sno = '')
    {
        $result = SlotModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function tcourse_data($sno = '')
    {
        $result = ManageCoursesModel::select('et_course.*', 'et_course_type.course_type_name')
            ->from('et_course')
            ->leftJoin('et_course_type', 'et_course.course_type_id', '=', 'et_course_type.sno')
            ->where('et_course.sno', $sno)
            ->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Get course category data
    function get_course_category_data($sno = '')
    {
        $result = CourseCategoryModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get course Sub category data
    function get_course_subcategory_data($sno = '')
    {
        $result = CourseSubCategoryModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Brand
    function get_course_brand_data($sno = '')
    {
        $result = BrandModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Group
    function get_course_group_data($sno = '')
    {
        $result = GroupModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Jobe Roll
    function get_course_job_role_data($sno = '')
    {
        $result = JobRollModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //pre skill set
    function get_course_pre_skill_data($sno = '')
    {
        $result = PreSkillSetModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //knowledge level list by id
    function get_knowledge_level_data($sno = '')
    {
        $result = KnowledgeLevelModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // knowledge level list
    function get_knowledge_level_list()
    {
        $result = KnowledgeLevelModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Action list
    function get_course_action_data($id = '')
    {
        $result = CourseActionModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Action list
    function get_course_action_list()
    {
        $result = CourseActionModel::where('status', 0)->orderBy('course_action_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Action list Count in Chapter
    function get_course_action_count_list($id = '')
    {

        $result = ManageCoursesSyllabusModel::selectRaw('COUNT(et_course_chapter.course_action_id) AS count, MAX(et_course_action.course_action_icon) AS course_action_icon, MAX(et_course_action.course_action_name) AS course_action_name')
            ->leftJoin('et_course_action', 'et_course_chapter.course_action_id', '=', 'et_course_action.sno')
            ->where('et_course_chapter.course_chapter_id', $id)
            ->where('et_course_chapter.status', 0)
            ->groupBy('et_course_chapter.course_action_id')
            ->get();
        return $result->isEmpty() ? null : $result;
    }
    //Course Chapter Get by course id
    function get_course_chapter_id($id = '')
    {
        $result = ManageCoursesSyllabusModel::where('course_id', $id)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //Course Chapter Get by course id Group
    function get_course_chapter_group_id($id = '')
    {
        $result = ManageCoursesSyllabusModel::selectRaw('MAX( sno ) AS max_sno')
            ->where('course_id', $id)
            ->where('status', 0)
            ->groupBy('course_chapter_id')
            ->get();

        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //Course Chapter
    function get_course_chapter_data($id = '')
    {
        $result = ManageCoursesSyllabusModel::where('course_chapter_id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //Course section
    function get_course_section_data($id = '')
    {
        $result = ManageCoursesSyllabusModel::where('session_id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //Course Topic
    function get_course_topic_data($id = '')
    {
        $result = ManageCoursesSyllabusModel::where('topic_id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function topic_complete_data($id = '', $batch = '')
    {
        $result = SyllabusUpdateModel::where('topic_id', $id)->where('batch_id', $batch)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_course_section_com_percentage($currentSessionId = '', $batch = '')
    {
        if (empty($currentSessionId) || empty($batch)) {
            return [
                'percentage' => 0,
                'prev_percentage' => 0
            ];
        }

        // Total syllabus sections for the current session
        $ses_count = ManageCoursesSyllabusModel::where('session_id', $currentSessionId)
            ->where('status', 0)
            ->count();

        // Completed syllabus sections for the current session
        $complete = SyllabusUpdateModel::where('section_id', $currentSessionId)
            ->where('batch_id', $batch)
            ->where('status', 0)
            ->count();

        $percentage = ($ses_count > 0) ? round(($complete / floatval($ses_count)) * 100, 2) : 0;

        $current_ses = ManageCoursesSyllabusModel::where('session_id', $currentSessionId)
            ->orderBy('session_id', 'desc')
            ->first();
        // Get previous session
        $previousSession = ManageCoursesSyllabusModel::where('session_id', '<', $currentSessionId)
            ->where('course_id', $current_ses->course_id)
            ->orderBy('session_id', 'desc')
            ->first();
        $prev_percentage = 0;

        if ($previousSession) {
            $prev_ses_count = ManageCoursesSyllabusModel::where('session_id', $previousSession->session_id)
                ->where('status', 0)
                ->count();

            $prev_complete = SyllabusUpdateModel::where('section_id', $previousSession->session_id)
                ->where('batch_id', $batch)
                ->where('status', 0)
                ->count();

            $prev_percentage = ($prev_ses_count > 0) ? round(($prev_complete / floatval($prev_ses_count)) * 100, 2) : 0;
        }

        return [
            'percentage' => $percentage,
            'prev_percentage' => $prev_percentage
        ];
    }

    function get_course_section_com_percentage_batch_summary($id = '', $batch = '')
    {
        $ses_count = ManageCoursesSyllabusModel::where('session_id', $id)->where('status', 0)->count();
        $complete  = SyllabusUpdateModel::where('section_id', $id)->where('batch_id', $batch)->where('status', 0)->count();
        if ($ses_count > 0) {
            $percentage = ($complete / $ses_count) * 100;
        } else {
            $percentage = 0;
        }
        return round($percentage, 2);
    }
    function get_question_bank_count($id = '')
    {
        $result = ManageQuestionModel::where('question_bank_id', $id)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_examers_count($id = '')
    {
        $result = Student::where('exam_id', $id)->count();
        if ($result !== null) {
            return $result;
        } else {
            return 0;
        }
    }
    function exam_details($exam_id)
    {

        $results = ExamModel::select('*')->where('sno', $exam_id)->get();

        return $results;
    }
    // document type List
    function get_document_type_list()
    {
        $result = DocumentTypeModel::where('status', 0)->orderBy('documenttype_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // branch Category List
    function get_branch_category_list()
    {
        $result = BranchTypeModel::where('status', 0)->orderBy('branchtype_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Department List
    function get_department_list()
    {
        $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch Category ID
    function get_branch_category_id($id = '')
    {
        $result = BranchTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch time zone ID
    function get_time_zone_id($id = '')
    {
        $result = TimeZoneModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch currency format ID
    function get_currency_format_id($id = '')
    {
        $result = CurrencyFormatModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_department_id($id = '')
    {
        $result = DepartmentModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //position
    function get_position_id($id = '')
    {
        $result = JobpositionModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Document By id
    function get_document_id($id = '')
    {
        $result = DocumentTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function absent_list_two_days()
    {

        $startDate = now()->subDays(2)->startOfDay();
        $endDate = now()->endOfDay();


        $attendance = StaffAttendanceModel::where('attendance', 'A')
            ->whereBetween('date', [$startDate, $endDate])
            ->pluck('staff_id');

        return $attendance;
    }

    function absent_list_seven_days()
    {

        $startDate = now()->subDays(7)->startOfDay();
        $endDate = now()->endOfDay();


        $attendance = StaffAttendanceModel::where('attendance', 'A')
            ->whereBetween('date', [$startDate, $endDate])
            ->pluck('staff_id');

        return $attendance;
    }

    // Course assign By branch id
    function get_course_assign_branchid($id = '')
    {
        $result = CourseAssigne_model::where('branch_id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // rosini
    function getFollowupCount($lead_id)
    {
        $lead =  AppointmentModel::select('*')->where('lead_id', $lead_id)->where('progressed', '=', 1)->count();

        return $lead ? $lead : 0;
    }
    function get_coupon_used_by_id($modal_id = "", $user_id = "")
    {

        if ($modal_id == 1) {
            $coupon_usage_history = ManageCouponHistoryModel::select(
                'et_lead.lead_name as person_name',
                'et_lead.lead_mobile as mobile_no'
            )
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_coupon_usage_history.used_by')
                ->where('et_lead.sno', $user_id)
                ->first();
            if ($coupon_usage_history) {
                return '
            <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
            <div class="d-block">
                <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
            </div>';
            }
        } elseif ($modal_id == 2) {

            $coupon_usage_history = ManageCouponHistoryModel::select(
                'et_customer.cus_name as person_name',
                'et_customer.cus_mobile as mobile_no'
            )
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_coupon_usage_history.used_by')
                ->where('et_customer.sno', $user_id)
                ->first();
            if ($coupon_usage_history) {
                return '
              <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
              <div class="d-block">
                  <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
              </div>';
            }
        }
    }
    function get_coupon()
    {

        $coupon_list = ManageCouponModel::select('*')
            ->where('et_manage_coupon.public_check', 1)
            ->where('et_manage_coupon.status', 0)
            ->get();


        return $coupon_list;
    }
    public function convertNumberToWords($number)
    {
        $words = [
            '0' => 'Zero',
            '1' => 'One',
            '2' => 'Two',
            '3' => 'Three',
            '4' => 'Four',
            '5' => 'Five',
            '6' => 'Six',
            '7' => 'Seven',
            '8' => 'Eight',
            '9' => 'Nine',
            '10' => 'Ten',
            '11' => 'Eleven',
            '12' => 'Twelve',
            '13' => 'Thirteen',
            '14' => 'Fourteen',
            '15' => 'Fifteen',
            '16' => 'Sixteen',
            '17' => 'Seventeen',
            '18' => 'Eighteen',
            '19' => 'Nineteen',
            '20' => 'Twenty',
            '30' => 'Thirty',
            '40' => 'Forty',
            '50' => 'Fifty',
            '60' => 'Sixty',
            '70' => 'Seventy',
            '80' => 'Eighty',
            '90' => 'Ninety'
        ];

        $suffixes = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];

        // For numbers less than 21, we can directly return the word.
        if ($number < 21) {
            return $words[$number];
        }

        // Handle numbers less than 100
        elseif ($number < 100) {
            $tens = floor($number / 10) * 10;
            $ones = $number % 10;
            return $words[$tens] . ($ones ? ' ' . $words[$ones] : '');
        }

        // Handle numbers less than 1000
        elseif ($number < 1000) {
            $hundreds = floor($number / 100);
            $remainder = $number % 100;
            $wordsString = $words[$hundreds] . ' ' . $suffixes[1];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the thousands range
        elseif ($number < 100000) {
            $thousands = floor($number / 1000);
            $remainder = $number % 1000;
            $wordsString = $this->convertNumberToWords($thousands) . ' ' . $suffixes[2];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the lakhs range
        elseif ($number < 10000000) {
            $lakhs = floor($number / 100000);
            $remainder = $number % 100000;
            $wordsString = $this->convertNumberToWords($lakhs) . ' ' . $suffixes[3];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the crores range
        elseif ($number < 1000000000) {
            $crores = floor($number / 10000000);
            $remainder = $number % 10000000;
            $wordsString = $this->convertNumberToWords($crores) . ' ' . $suffixes[4];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }
    }
    public function batch_completed_days($id = '')
    {
        $customer_count = BatchHistoryModel::where('batch_id', $id)->where('attendance', 'P')->count();
        return $customer_count > 0 ? $customer_count : 0;
    }
    public function customer_fee_not_paid_count($id = '')
    {
        $customer_data = TrainingModel::where('batch_id', $id)->get();

        $fee_unpaid_count = 0;

        foreach ($customer_data as $customer) {
            if ($customer->total_amount > $customer->paid_amount) {
                $fee_unpaid_count++;
            }
        }

        return $fee_unpaid_count;
    }
    public function branch_franchise($id = '')
    {

        $branch_data = BranchModel::where('sno', $id)->first();

        if ($branch_data) {
            if ($branch_data->branch_type == 2) {
                return $branch_data->franchise_name;
            } else {
                return $branch_data->branch_name;
            }
        }
        return $branch_data;
    }
    function get_rules_data($id = '')
    {
        $user = StaffModel::select('et_staff.*', 'et_department.department_name', 'et_sub_department.sub_department_name')
            ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->leftJoin('et_sub_department', 'et_staff.sub_department_id', '=', 'et_sub_department.sno')
            ->where('et_staff.status', '!=', 2)
            ->where('et_staff.sno', $id)
            ->first();


        $editcategory = Rules_guidelinesModel::select('et_rules_guidelines.*', 'et_department.department_name', 'et_sub_department.sub_department_name')
            ->leftJoin('et_department', 'et_rules_guidelines.department_id', '=', 'et_department.sno')
            ->leftJoin('et_sub_department', 'et_rules_guidelines.sub_dept_id', '=', 'et_sub_department.sno')
            ->where('et_rules_guidelines.status', '!=', 2)
            ->where('et_department.sno', $user->department_id)
            ->where('et_sub_department.sno', $user->sub_department_id)
            ->first();

        // return $editcategory;

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $editcategory
        ], 200);
    }
    function get_chapter_status($chapter_id, $batch_id)
    {
        // Get the total number of topics associated with the chapter (status = 0)
        $totalTopics = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
            ->where('status', 0)  // Filter by status (not completed)
            ->count();

        // Get the count of completed topics (status = 1, or based on your requirement)
        $completedTopics = SyllabusUpdateModel::where('chapter_id', $chapter_id)
            ->where('batch_id', $batch_id)
            ->where('status', 0) // Assuming 1 means completed, adjust as needed
            ->count();

        // Calculate the total completion percentage (avoid division by zero)
        $totalPercentage = ($totalTopics > 0) ? ($completedTopics / $totalTopics) * 100 : 0;

        // Determine badge label based on completion
        if ($completedTopics === $totalTopics) {
            $badgeLabel = 'Completed';
        } elseif ($totalPercentage > 0) {
            $badgeLabel = 'In Progress';
        } else {
            $badgeLabel = 'Not yet Started';
        }
        return $badgeLabel;
    }

    // get financial year list
    function get_fin_yr()
    {
        $result = FinancialYearModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_fin_year_by_sno($id = '')
    {
        $result = FinancialYearModel::where('sno', $id)->where('status', 0)->first();

        // Check if a record was found
        if ($result !== null) {
            return $result; // Return the single instance
        } else {
            return null; // Return null if no results found
        }
    }
    // facility Roll
    function get_branch_staff_list($branch_id)
    {
        $result = StaffModel::where('status', 0)->where('branch_id', $branch_id)->orderBy('staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_facility_data($sno = '')
    {
        $result = FacilityModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Shift time list
    function get_shift_time()
    {
        $result = ShiftTimeModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Shift time id
    function get_shift_time_id($sno = " ")
    {
        $result = ShiftTimeModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }



    function get_course_syllabus_data($batch, $chapter, $sec, $topic = '')
    {
        // return $batch;
        $result =  SyllabusUpdateModel::where('batch_id', $batch)
            ->where('chapter_id', $chapter)
            ->where('section_id', $sec)
            // ->whereIn('topic_id', $latest_topics->pluck('topic_id')->toArray())
            // ->where('staff_id', $batch->staff_id)
            ->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // ********************************* Rajkumar I Start **************************************
    // Get Hr Sub Branch 

    function get_hr_sub_branch($id = '')
    {
        $result = HrDirectoryBranchModel::where('company_id', $id)->where('status', 0)->get();
        return $result;
    }

    //interview type ID
    function get_interview_type_id($id = '')
    {
        $result = InterviewTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Company Hr Directory BY ID
    function get_company_hr_id($id = '')
    {
        $result = HrDirectoryModel::where('sno', $id)->first();
        // return $result;

        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_total_vacancy_by_company_id($id = '')
    {
        // Retrieve all records for the given company ID
        $results = JobDirectoryModel::select('vacancy_count')->where('job_company_id', $id)->get();

        // Initialize total vacancy count
        $total_count_vacancy = 0;

        // Iterate through each result
        foreach ($results as $result) {
            // Decode JSON
            $vacancy_count = json_decode($result->vacancy_count, true);

            // Check if the decoded value is an array
            if (is_array($vacancy_count)) {
                // Sum the values
                $total_count_vacancy += array_sum($vacancy_count);
            }
        }

        return $total_count_vacancy; // Return the total count
    }




    function calculate_percentage($part, $total)
    {
        // dd($part, $total);
        if ($total == 0) {
            return 0; // Avoid division by zero
        }
        return ($part / $total) * 100;
    }
    function paymentnumberToWords($num)
    {
        $ones = [
            '',
            'First',
            'Second',
            'Third',
            'Fourth',
            'Fifth',
            'Sixth',
            'Seventh',
            'Eighth',
            'Ninth',
            'Tenth',
            'Eleventh',
            'Twelfth',
            'Thirteenth',
            'Fourteenth',
            'Fifteenth',
            'Sixteenth',
            'Seventeenth',
            'Eighteenth',
            'Nineteenth'
        ];

        $tens = [
            '',
            '',
            'Twentieth',
            'Thirtieth',
            'Fortieth',
            'Fiftieth',
            'Sixtieth',
            'Seventieth',
            'Eightieth',
            'Ninetieth'
        ];

        $thousands = ['', 'Thousand'];

        // Return "Initial" for zero payment
        if ($num == 0) {
            return 'Initial';
        }

        $words = '';

        if ($num >= 1000) {
            $words .= $ones[intval($num / 1000)] . ' ' . $thousands[1] . ' ';
            $num %= 1000;
        }

        if ($num >= 100) {
            $words .= $ones[intval($num / 100)] . ' Hundred ';
            $num %= 100;
        }

        if ($num >= 20) {
            $words .= $tens[intval($num / 10)] . ' ';
            $num %= 10;
        }

        if ($num > 0) {
            $words .= $ones[$num] . ' ';
        }

        return trim($words);
    }

    function get_verify_activity_count($id = '')
    {
        $count = MarketingModel::where('status', 0)
            ->where('sno', $id)
            ->first();

        if ($count !== null) {
            return $count;
        } else {
            return null;
        }
    }


    // ********************************* Rajkumar I End **************************************
    function get_total_interested_by_job_id($id = " ")
    {
        $results = CustomerPlacementModel::where('job_name_id', $id)->get(); // To get the records
        $results_count = $results->count(); // To get the count of records
        // dd($results_count);


        return $results_count;
    }


    function GRADE_LOGO_PIC_PATH($pic)
    {
        if ($pic) {
            return url('grade_logo/' . $pic);
        } else {
            return '';
        }
    }


    function get_profile_image_url($staff_image, $default = 'assets/eapl_images/Super-Admin.png')
    {
        $path = public_path($staff_image);
        return file_exists($path) ? asset($staff_image) : asset($default);
    }
    // material type name by id
    function get_material_typeName($sno = '')
    {
        // return $sno;
        $result = MaterialTypeModel::where('sno', $sno)->value('material_type_name');
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    //here need create helfer funtion for notification message from notification type based to fetch 

    public function createNotification(array $data, $notificationtype)
    {
        // Step 1: Find the Notification Type based on the name
        $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();

        // Check if notification type exists and proceed
        if ($notificationType) {
            // Decode the JSON string array of roles
            $rolesArray = json_decode($notificationType->notification_roles, true);

            // Step 2: Fetch staff based on branch, status, and roles array
            $staffMembers = StaffModel::where('branch_id', $data['branch_id'])
                ->where('status', 0) // Assuming 0 is the active status
                ->whereIn('role_id', $rolesArray)
                ->get();

            // Step 3: Prepare notifications for each staff member
            $notifications = [];
            foreach ($staffMembers as $staff) {
                $notificationData = [
                    'branch_id'            => $data['branch_id'] ?? 0,
                    'notification_type_id' => $notificationType->sno,
                    'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
                    'notification_content' => $data['notification_content'],
                    'notification_date'    => now(),
                    'who'                  => $data['who'] ?? '0',
                    'whom'                 => $staff->sno,
                    'created_by'           => $data['created_by'] ?? 0,
                    'updated_by'           => $data['updated_by'] ?? 0,
                    'status'               => $data['status'] ?? 0
                ];

                // Insert the notification and store the result
                $notifications[] = NotificationModel::create($notificationData);
            }

            return $notifications; // Return all created notifications
        }

        // Return null if notification type was not found
        return null;
    }
    
    public function createNotificationAssessment(array $data, $notificationtype, $staff)
    {
        // Step 1: Find the Notification Type based on the name
        $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();
 
        // Check if notification type exists and proceed
        if ($notificationType) {
            $staffMembers = StaffModel::where('branch_id', $data['branch_id'])
                ->where('status', 0)
                ->where('sno', $staff)
                ->get();
 
            // Step 3: Prepare notifications for each staff member
            $notifications = [];
            foreach ($staffMembers as $staff) {
                $notificationData = [
                    'branch_id'            => $data['branch_id'] ?? 0,
                    'notification_type_id' => $notificationType->sno,
                    'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
                    'notification_content' => $data['notification_content'],
                    'notification_date'    => now(),
                    'who'                  => $data['who'] ?? '0',
                    'whom'                 => $staff->sno,
                    'created_by'           => $data['created_by'] ?? 0,
                    'updated_by'           => $data['updated_by'] ?? 0,
                    'status'               => $data['status'] ?? 0
                ];
 
                // Insert the notification and store the result
                $notifications[] = NotificationModel::create($notificationData);
            }
 
            return $notifications; // Return all created notifications
        }
 
        // Return null if notification type was not found
        return null;
    }
    //   AK max
    // incoming call
    function incoming_call_count($staff_id)
    {
        $incoming_call_count = DB::table('et_call_tracker')->select('et_call_tracker.sno')
            ->where('et_call_tracker.branch_staff_id', $staff_id)
            // ->where('a.call_date >=', $call_start_date)
            // ->where('a.call_date <=', $call_end_date)
            ->where('et_call_tracker.call_status', 1)        // Status is 1
            ->count();

        return $incoming_call_count ? $incoming_call_count : 0;
    }

    // outcoming_call
    function outcoming_call_count($staff_id)
    {
        $outgoingcall_count = DB::table('et_call_tracker')->select('et_call_tracker.sno')
            ->where('et_call_tracker.branch_staff_id', $staff_id)        // Filter by user ID
            // ->where('et_call_tracker.call_date >=', $call_start_date)
            // ->where('et_call_tracker.call_date <=', $call_end_date)

            ->where('et_call_tracker.call_status', 0)                  // Status is 0
            ->where('et_call_tracker.call_duration', '!=', '00:00:00') // Duration is not '00:00:00'
            ->count();

        return $outgoingcall_count ? $outgoingcall_count : 0;
    }

    // missed_call
    function missed_call_count($staff_id)
    {
        $missedcall_count = DB::table('et_call_tracker')->select('et_call_tracker.sno')
            ->where('et_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
            // ->where('et_call_tracker.call_date >=', $call_start_date)
            // ->where('et_call_tracker.call_date <=', $call_end_date)

            ->where('et_call_tracker.call_status', 2)
            ->count();

        return $missedcall_count ? $missedcall_count : 0;
    }

    // rejected_call
    function rejected_call_count($staff_id)
    {
        $rejected_call = DB::table('et_call_tracker')->select('et_call_tracker.sno')
            ->where('et_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
            // ->where('et_call_tracker.call_date >=', $call_start_date)
            // ->where('et_call_tracker.call_date <=', $call_end_date)
            ->where('et_call_tracker.call_status', 3)           // Status is 3 for rejected calls
            ->count();

        return $rejected_call ? $rejected_call : 0;
    }




    // incoming call lead
    function incoming_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('et_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('et_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id     = $contact_book->contact_book_id ?? '0';
        $incoming_call_count = DB::table('et_call_log')
            ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
            ->where('et_call_log.contact_book_id', $contact_book_id)
            // ->where('a.call_date >=', $call_start_date)
            // ->where('a.call_date <=', $call_end_date)
            ->where('et_call_log.redirected_to', 0) // Redirected to 0
            ->where('et_call_log.status', 1)        // Status is 1
            ->count();

        return $incoming_call_count ? $incoming_call_count : 0;
    }

    // outcoming_call lead
    function outcoming_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('et_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('et_contact_book.contact_book_id', 'desc')->first();
        $contact_book_id    = $contact_book->contact_book_id ?? '0';
        $outgoingcall_count = DB::table('et_call_log')
            ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
            ->where('et_call_log.contact_book_id', $contact_book_id) // Filter by user ID
            // ->where('et_call_log.call_date >=', $call_start_date)
            // ->where('et_call_log.call_date <=', $call_end_date)
            ->where('et_call_log.redirected_to', 0)                  // Redirected to 0
            ->where('et_call_log.status', 0)                         // Status is 0
            ->where('et_call_log.duration', '!=', '00:00:00')        // Duration is not '00:00:00'
            ->count();

        return $outgoingcall_count ? $outgoingcall_count : 0;
    }

    // missed_call lead
    function missed_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('et_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('et_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id  = $contact_book->contact_book_id ?? '0';
        $missedcall_count = DB::table('et_call_log')
            ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
            ->where('et_call_log.contact_book_id', $contact_book_id)
            // ->where('et_call_log.call_date >=', $call_start_date)
            // ->where('et_call_log.call_date <=', $call_end_date)
            ->where('et_call_log.redirected_to', 0) // Redirected to 0
            ->where('et_call_log.status', 2)        // Status is 2 for missed calls
            ->where('et_call_log.missed_status', 0) // Missed status is 0
            ->count();

        return $missedcall_count ? $missedcall_count : 0;
    }

    // rejected_call lead
    function rejected_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('et_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('et_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id = $contact_book->contact_book_id ?? '0';
        $rejected_call   = DB::table('et_call_log')
            ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
            ->where('et_call_log.contact_book_id', $contact_book_id)
            // ->where('et_call_log.call_date >=', $call_start_date)
            // ->where('et_call_log.call_date <=', $call_end_date)
            ->where('et_call_log.redirected_to', 0) // Redirected to 0
            ->where('et_call_log.status', 3)        // Status is 3 for rejected calls
            ->count();

        return $rejected_call ? $rejected_call : 0;
    }

    function get_varient_list()
    {
        $result = Addon_product_VariantModel::where('status', 0)->orderBy('addon_varientname', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_variant_count_data($product_id = '')
    {
        $result =  DB::table('et_manage_product_variant')->where('status', 0)
            ->where('product_id', $product_id)
            ->get();

        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_variable_data($id = '')
    {
        return DB::table('et_manage_product_variable')
            ->where('status', '!=', 2)
            ->where('product_variant_id', $id)
            ->get();
    }

    function get_category_based_products($id = '', $branch_id = '')
    {
        return DB::table('et_product')
            ->where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('product_category_id', $id)
            ->get();
    }

    function get_package_product_data($id = '')
    {
        return DB::table('et_package_product')
            ->select('et_package_product.*', 'et_product.product_name', 'et_product_category.product_category_name')
            ->leftJoin('et_product', 'et_product.sno', 'et_package_product.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_package_product.status', 0)
            ->where('package_id', $id)
            ->get();
    }

    function get_product_facility($id = '')
    {
        return DB::table('et_facility')
            ->where('status', 0)
            ->where('sno', $id)
            ->first();
    }
    function get_tools_by_id($id = '')
    {
        return DB::table('et_product_tools')
            ->where('status', 0)
            ->where('sno', $id)
            ->first();
    }
    function get_variant_data_product($product_id = '')
    {
        $result =  DB::table('et_manage_product_variant')->where('status', 0)
            ->where('product_id', $product_id)
            ->get();

        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_package_add_on_counts($package = '')
    {
        $free_count = DB::table('et_package_addon')
            ->where('status', 0)
            ->where('package_id', $package)
            ->where('free_paid', 0)
            ->count();

        $paid_count = DB::table('et_package_addon')
            ->where('status', 0)
            ->where('package_id', $package)
            ->where('free_paid', 1)
            ->count();

        return [
            'free' => $free_count,
            'paid' => $paid_count
        ];
    }
    function get_variable_by_variant($id = '')
    {
        return DB::table('et_manage_product_variable')
            ->where('status', 0)
            ->where('product_variant_id', $id)
            ->get();
    }
    function get_package_addon_by_id($id = '', $package_id)
    {
        return DB::table('et_package_addon')
            ->where('status', 0)
            ->where('addon_id', $id)
            ->where('package_id', $package_id)
            ->first();
    }
    function get_package_addon_vari_by_id($id = '', $package_id = '')
    {
        return DB::table('et_package_addon')
            ->where('status', 0)
            ->where('addon_variant_id', $id)
            ->where('package_id', $package_id)
            ->first();
    }

    function convertFromINR($targetCurrency)
    {
        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
        $api_key = 'cur_live_eFtAAPwYAI2xWoBgFCqsB0FsOma21R9kEgpEsHV1';
        $endpoint = 'convert';



        $response = Http::get("https://api.currencyapi.com/v3/latest?apikey={$api_key}&currencies={$targetCurrency}&base_currency=INR");


        // $response = Http::get("https://api.exchangerate.host/{$endpoint}", [
        //     'access_key' => $accessKey,
        //     'from' => 'INR',
        //     'to' => $targetCurrency,
        //     'amount' => $amountInR,
        // ]);

        if ($response->successful()) {
            $data = $response->json();
            return [
                'exchange_rate' => $data['data'][$targetCurrency]['value'] ?? null,
            ];
            // return [
            //     'converted_amount' => $data['result'] ?? null,
            //     'exchange_rate' => $data['info']['rate'] ?? null,
            //     'exchange_quote' => $data['info']['quote'] ?? null,
            // ];
        } else {
            return  null;
            // return [
            //         'converted_amount' =>  null,
            //         'exchange_rate' => null,
            //         'exchange_quote' =>  null,
            //     ];
        }
    }
    function ConvertedAmount($exchange_quote, $amount)
    {
        $converted_amount = ($exchange_quote != 0) ? $amount * $exchange_quote : 0;
        return $converted_amount;
    }
    //New
    function staff_details($sno)
    {
        $result = StaffModel::select('et_staff.sno', 'et_staff.department_id', 'et_staff.branch_id', 'et_staff.staff_image', 'et_staff.status', 'et_staff.staff_name',  'et_staff.nick_name', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.sno', $sno)
            ->orderBy('et_staff.staff_name', "ASC")->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function completed_task_details_new($sno)
    {
        return 1;
        return DB::table('et_daily_tasks')
            ->where('task_id', $sno)
            ->where('status', 0)
            ->where('completed_percentage', '>=', 100)
            ->count();
    }
    function task_pending_or_not($staff_id, $task_id)
    {
        return DB::table('et_task_log')
            ->where('task_id', $task_id)
            ->where('staff_id', $staff_id)
            ->where('status', 0)
            ->exists() ? 1 : 0;
    }


    public function task_status_details($service_id)
    {
        $status_counts = DB::table('et_task')
            ->select('status', DB::raw('count(*) as total'))
            ->where('service_id', $service_id)
            ->groupBy('status')
            ->pluck('total', 'status');

        return [
            'total' => $status_counts->sum(),
            'not_started' => $status_counts->get(0, 0),
            'in_progress' => $status_counts->get(1, 0),
            'complete' => $status_counts->get(3, 0),
            'delayed' => 0, // Add logic if needed
            'hold' => 0,     // Add logic if needed
            'not_completed' => 0, // Add logic if needed
            'verified' => $status_counts->get(4, 0),
            'qc_verified' => $status_counts->get(5, 0)
        ];
    }

    function task_usage_hours($id)
    {
        $task_data =  DB::table('et_task')
            ->where('status', '!=', 2)
            ->where('sno', $id)
            ->first();

        $staff_list = json_decode($task_data->assign_staffs, true);
        $grandTotalSeconds = 0;

        if (is_array($staff_list)) {
            foreach ($staff_list as $staff_id) {
                $task_logs = DB::table('et_task_log')
                    ->where('task_id', $id)
                    ->where('staff_id', $staff_id)
                    ->where('status', 1)
                    ->get();

                foreach ($task_logs as $log) {
                    if (!empty($log->duration)) {
                        list($h, $m, $s) = explode(':', $log->duration);
                        $grandTotalSeconds += ($h * 3600) + ($m * 60) + $s;
                    }
                }
            }
        }

        // Convert total seconds to human-readable format
        $hours = floor($grandTotalSeconds / 3600);
        $minutes = floor(($grandTotalSeconds % 3600) / 60);
        $seconds = $grandTotalSeconds % 60;

        $grandTotalDuration = '';
        if ($hours > 0) {
            $grandTotalDuration = $hours . ' hr' . ($hours > 1 ? 's' : '');
            if ($minutes > 0) {
                $grandTotalDuration .= ' ' . $minutes . ' min' . ($minutes > 1 ? 's' : '');
            }
        } elseif ($minutes > 0) {
            $grandTotalDuration = $minutes . ' min' . ($minutes > 1 ? 's' : '');
            if ($seconds > 0) {
                $grandTotalDuration .= ' ' . $seconds . ' sec' . ($seconds > 1 ? 's' : '');
            }
        } else {
            if ($seconds > 0) {
                $grandTotalDuration = $seconds . ' sec' . ($seconds > 1 ? 's' : '');
            } else {
                $grandTotalDuration = '0';
            }
        }

        return $grandTotalDuration;
    }

    function completed_task_details($sno)
    {
        return DB::table('et_task_check_list')
            ->where('task_id', $sno)
            ->where('status', 0)
            ->where('completed_percentage', '>=', 100)
            ->count();
    }

    function completed_task_percentage_old($sno)
    {
        // Get total checklist count for the task
        $total_tasks = DB::table('et_task_check_list')
            ->where('task_id', $sno)
            ->where('status', 0)
            ->count();

        if ($total_tasks == 0) {
            return 0; // Avoid division by zero
        }

        // Count checklist items fully completed (completed_percentage >= 100)
        $completed_tasks = DB::table('et_task_check_list')
            ->where('task_id', $sno)
            ->where('status', 0)
            ->where('completed_percentage', '>=', 100)
            ->count();

        // Calculate percentage completed
        $percentage = ($completed_tasks / $total_tasks) * 100;

        // Optionally round or format the percentage
        return round($percentage, 2);
    }



    // function completed_task_percentage($sno)
    // {
    //     $data = DB::table('et_daily_tasks')
    //         ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
    //         ->where('et_daily_tasks.sno', $sno)
    //         ->where('et_daily_tasks.status', '!=', 2)
    //         ->select('et_daily_tasks.min_page_or_per', 'et_daily_tasks.rework_check', 'et_daily_tasks.max_page_or_per', 'et_task.pages_percentage')
    //         ->first();

    //     if (!$data) {
    //         return 0;
    //     }

    //     $maxValue = 0;
    //     $maxValue = $data->max_page_or_per;

    //     if ($data->min_page_or_per == 0) {
    //         $percentage = 0;
    //     } elseif ($maxValue == 0) {
    //         $percentage = 0;
    //     } elseif ($data->min_page_or_per == $maxValue) {
    //         $percentage = 100;
    //     } else {
    //         $percentage = ($data->min_page_or_per / $maxValue) * 100;
    //     }

    //     return round($percentage, 2);
    // }

    function completed_task_percentage($sno)
    {
        $data = DB::table('et_daily_tasks')
            ->where('et_daily_tasks.sno', $sno)
            ->where('et_daily_tasks.status', '!=', 2)
            ->select('et_daily_tasks.min_page_or_per', 'et_daily_tasks.max_page_or_per')
            ->first();

        if (!$data) {
            return 0;
        }

        $maxValue = 0;
        $maxValue = $data->max_page_or_per;

        if($data->min_page_or_per == 0) {
            $percentage = 0;
        } elseif($maxValue == 0) {
            $percentage = 0;
        } elseif($data->min_page_or_per == $maxValue) {
            $percentage = 100;
        } else {
            $percentage = ($data->min_page_or_per / $maxValue) * 100;
        }

        return round($percentage, 2);
    }
    
    function completed_service_percentage($sno)
    {
        // Get total checklist count for the task
        $total_tasks = DB::table('et_task')
            ->where('service_id', $sno)
            ->where('status', '!=', 2)
            ->count();

        if ($total_tasks == 0) {
            return 0; // Avoid division by zero
        }

        // Count checklist items fully completed (completed_percentage >= 100)
        $completed_tasks = DB::table('et_task')
            ->where('service_id', $sno)
            ->where('status', 8)
            ->count();

        // Calculate percentage completed
        $percentage = ($completed_tasks / $total_tasks) * 100;

        // Optionally round or format the percentage
        return round($percentage, 2);
    }
    function get_branch_sales_staff_list($branch_id)
    {
        $result = StaffModel::select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->orderBy('et_staff.staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Monish
    function get_total_leads($id)
    {

        $month = date('m');
        $year = date('Y');

        $data = DB::table('et_lead')
            ->where('created_by', $id)
            ->whereNotIn('status', [2, 6])
            ->where('internal_status', 0)
            ->whereMonth('registered_date', $month)
            ->whereYear('registered_date', $year)
            ->count();

        return $data;
    }

    function get_active_leads($id)
    {

        $month = date('m');
        $year = date('Y');

        $data = DB::table('et_lead')
            ->where('created_by', $id)
            ->where('status', 0)
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->whereMonth('registered_date', $month)
            ->whereYear('registered_date', $year)
            ->count();

        return $data;
    }

    function get_spam_leads($id)
    {

        $month = date('m');
        $year = date('Y');

        $data = DB::table('et_lead')
            ->where('created_by', $id)
            ->where('spam_verified', 0)
            ->where('internal_status', 0)
            ->whereMonth('registered_date', $month)
            ->whereYear('registered_date', $year)
            ->count();

        return $data;
    }

    function get_dead_leads($id)
    {

        $month = date('m');
        $year = date('Y');

        $data = DB::table('et_lead')
            ->where('created_by', $id)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->whereMonth('registered_date', $month)
            ->whereYear('registered_date', $year)
            ->count();

        return $data;
    }

    function get_convrt_customer($id)
    {

        $month = date('m');
        $year = date('Y');

        $data = DB::table('et_lead')
            ->where('created_by', $id)
            ->where('status', 4)
            ->where('internal_status', 0)
            ->whereMonth('registered_date', $month)
            ->whereYear('registered_date', $year)
            ->count();

        return $data;
    }

    function get_odc_count($id)
    {

        $today = date('d-m-Y');

        $data = DB::table('et_lead')
            ->join('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->whereDate('et_lead.created_at', $today)
            ->whereDate('et_customer.created_at', $today)
            ->where('et_customer.branch_id', $id)
            ->count();

        return $data;
    }
    function get_delivarabiles_count($id)
    {
        $data = DB::table('et_deliverables')
            ->where('service_id', $id)
            ->count();
        return $data;
    }

    function get_mc_count($userId)
    {
        $starting_month = \Carbon\Carbon::now()->startOfMonth()->toDateString();
        $ending_month   = \Carbon\Carbon::now()->endOfMonth()->toDateString();

        $data = DB::table('et_lead')
            ->join('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->whereBetween('et_lead.created_at', [$starting_month, $ending_month])
            ->whereBetween('et_customer.created_at', [$starting_month, $ending_month])
            ->where('et_customer.branch_id', $userId)
            ->count();


        return $data;
    }

    function get_journal_monitor_list($service_id)
    {
        // Fetch the role IDs from UserRolePermissionModel
        return DB::table('et_journal_monitor')->where('manage_journal_id', $service_id)->get();
    }
    function get_journal_monitor_paper($id)
    {
        $data = DB::table('et_journal_monitor')
            ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')
            // Conditionally join et_product if product_package = 1
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_product_category if product_package = 1
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_package if product_package = 2
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_journal_monitor.*',
                'et_customer.cus_name',
                'et_journal_history.paper_name',
                'et_journal_booklet.journal_name',
                'et_customer.customer_id',
                'et_journal_booklet.domain_id',
                'et_customer_services.product_package',
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name"),
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                        ELSE NULL
                    END as category_name")
            )
            ->where('et_journal_monitor.sno', $id)
            ->first();

        $domainIds = json_decode($data->domain_id, true);

        if (is_array($domainIds)) {
            $domains = DB::table('et_domain')->whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
            $data->domain_names = $domains;
        } else {
            $data->domain_names = [];
        }

        return $data;
    }




    function get_omc_count($id)
    {
        $month = date('m');
        $year = date('Y');
        $starting_month = \Carbon\Carbon::now()->subMonthNoOverflow()->startOfMonth()->toDateString();
        $ending_month   = \Carbon\Carbon::now()->subMonthNoOverflow()->endOfMonth()->toDateString();

        $data = DB::table('et_lead')
            ->join('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_customer.branch_id', $id)
            ->whereMonth('et_lead.created_at', $month)
            ->whereYear('et_lead.created_at', $year)
            ->whereBetween('et_customer.created_at', [$starting_month, $ending_month])
            ->count();

        return $data;
    }

    public function get_cr_pre($id)
    {

        $today = date('d-m-Y');

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $id)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $id)
            ->whereDate('et_customer.created_at', $today)
            ->count();

        // customer ratio
        $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rate, 2);

        return $convertion_rate;
    }

    public function get_abc_count($id)
    {
        // ABV and ACV Today
        $total_payment             = 0;
        $averageBusinessValue      = 0;

        $today = date('d-m-Y');

        $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $id)
            ->whereDate('et_customer.created_at', $today)
            ->count();

        if ($customerConvertCount > 0) {
            $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->where('et_customer.status', 0)
                ->where('et_lead.created_by', $id)
                ->whereDate('et_customer.created_at', $today)
                ->get();

            if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                    $proposal_ids = json_decode($customer->proposal_ids);

                    $total_payment = DB::table('et_proposal')
                        ->whereIn('sno', $proposal_ids)
                        ->where('status', 0)
                        ->sum('total_amount');
                }
            }

            $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
        }

        return $averageBusinessValue;
    }

    public function get_walkin_count($id)
    {

        $starting_month = \Carbon\Carbon::now()->subMonthNoOverflow()->startOfMonth()->toDateString();
        $ending_month   = \Carbon\Carbon::now()->subMonthNoOverflow()->endOfMonth()->toDateString();

        $thismonth_walkin = DB::table('et_lead_appointment')
            ->where('appointment_category', 'Walk-in')
            ->where('created_by', $id)
            ->whereBetween('created_at', [$starting_month, $ending_month])
            ->count();

        return $thismonth_walkin;
    }

    public function get_acv_count($id)
    {
        $total_paid_payment        = 0;
        $averageCollectionValue    = 0;

        $today = date('d-m-Y');

        $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $id)
            ->whereDate('et_customer.created_at', $today)
            ->count();

        if ($customerConvertCount > 0) {
            $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->where('et_customer.status', 0)
                ->where('et_lead.created_by', $id)
                ->whereDate('et_customer.created_at', $today)
                ->get();

            if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {

                    $proposal_ids = json_decode($customer->proposal_ids);
                    $total_paid_payment = DB::table('et_proposal_pay_slot')
                        ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
                        ->where('status', 0)
                        ->sum('paidAmount');
                }
            }

            $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
        }

        return $averageCollectionValue;
    }
    function get_product_variant($proposal_id)
    {
        // return $proposal_id;
        // Fetch product cart data with joins
        $data = DB::table('et_proposal_product_cart')
            ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
            ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
            ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->where('et_proposal_product_cart.status', 0)
            ->where('et_proposal_product_cart.proposal_sno', $proposal_id)
            ->get();

        $results = [];

        foreach ($data as $item) {
            $variant_variable_data = json_decode($item->variant_variable_ids ?? '[]', true);
            $variantVariableDetails = [];

            foreach ($variant_variable_data as $pair) {
                $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
                $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

                $variantVariableDetails[] = [
                    'variant' => $variant->product_variant_name ?? null,
                    'variable' => $variable->variable_name ?? null,
                ];
            }

            $results[] = [
                'product_cart' => $item,
                'variant_variable_data' => $variantVariableDetails
            ];
        }

        return $results;
    }



    function get_variant_data_by_id($sno = '')
    {
        $result =  DB::table('et_manage_product_variant')->where('sno', $sno)->first();
        return $result;
    }
    function get_variable_data_by_id($sno = '')
    {
        $result =  DB::table('et_manage_product_variable')->where('sno', $sno)->first();
        return $result;
    }


    public function getStaffGoal_progress_bar($staff_id_get, $departmentId, $month_id, $year_id, $branchId)
    {
        $month_id = $month_id;
        $month    = $month_id;
        $year     = date('Y');
        // Get goal records for the selected department and month
        $goalsetRecords = GoalSetStaffModel::whereMonth('goal_date', $month_id)
            ->whereYear('goal_date', $year)
            ->where('staff_id', $staff_id_get)
            ->first();

        if (!$goalsetRecords) {
            return 0;
        }

        $current_date = date('Y-m-d');
        $branch_id = $branchId;
        $departmentId = $departmentId;

        if ($goalsetRecords->goal_completed == 1) {
            // Sales
            if ($departmentId == 1) {
                $actual = $goalsetRecords->conversion_actual ?? 0;
                $target = $goalsetRecords->conversion ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return round($goal_progress);
            }
            // Production
            if ($departmentId == 2) {
                $actual = $goalsetRecords->min_no_of_students_actual ?? 0;
                $target = $goalsetRecords->min_no_of_students ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return round($goal_progress);
            }
            // PC
            if ($departmentId == 5) {
                $actual = $goalsetRecords->productions_actual ?? 0;
                $target = $goalsetRecords->productions ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return round($goal_progress);
            }
            // CRE
            if ($departmentId == 6) {
                $actual = $goalsetRecords->no_of_reviews_actual ?? 0;
                $target = $goalsetRecords->no_of_reviews ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return round($goal_progress);
            }
            // Collection Executive
            if ($departmentId == 7) {
                $actual = $goalsetRecords->conversion_actual ?? 0;
                $target = $goalsetRecords->conversion ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return 0;
            }
            // Placement Executive
            if ($departmentId == 8) {
                $actual = $goalsetRecords->mou_actual ?? 0;
                $target = $goalsetRecords->mou ?? 0;
                $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
                // if ($goal_progress > 100) {
                //   $goal_progress = 100;
                // }
                return round($goal_progress);
            }
        }
        // Sales
        if ($departmentId == 1) {
            $customerConvertCount = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status', [0, 6])
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by', $staff_id_get)
                ->whereYear('et_customer.created_at', $year)
                ->whereMonth('et_customer.created_at', $month)
                ->count();
            $actual = $customerConvertCount ?? 0;
            $target = $goalsetRecords->conversion ?? 0;
            $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
            //   if ($goal_progress > 100) {
            //     $goal_progress = 100;
            //   }
            return round($goal_progress);
        }
        // Production
        if ($departmentId == 2) {

            $current_date = date('Y-m-d'); // Define the current date
            $std_count = TrainingModel::where('et_training.status', 0)
                ->where('et_batch.status', 0)
                ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                ->where('et_training.staff_id', $staff_id_get)
                ->where('et_batch.start_date', '<=', $current_date)
                ->where('et_batch.end_date', '>=', $current_date)
                ->count();


            $actual = $std_count ?? 0;
            $target = $goalsetRecords->min_no_of_students ?? 0;
            $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
            //   if ($goal_progress > 100) {
            //     $goal_progress = 100;
            //   }

            return round($goal_progress);
            // Production Goal*********************************************** 
        }
        // PC
        if ($departmentId == 5) {
            // PC Goal *****************************************************
            $staff_pc = StaffModel::where('et_staff.branch_id', $branch_id)
                ->where('et_staff.department_id', 2)
                ->where('et_staff.status', 0)
                ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
                ->orderBy('staff_name', 'ASC')
                ->get([
                    'et_staff.sno',
                    'et_staff.staff_name',
                    'et_staff.nick_name',
                    'et_staff.gender',
                    'et_staff.staff_image',
                    'et_department.department_name',
                    'et_user_role.role_name'
                ]);

            $totalcosting_amount = 0;
            $totalrefferal_count = 0;
            $total_basic_pay_pro = 0;
            foreach ($staff_pc as $staff_pc_list) {
                // Production Goal***********************************************
                $staffproduction = StaffModel::select(
                    'et_staff.sno',
                    'et_staff.staff_id',
                    'et_staff.staff_name',
                    'et_staff.gender',
                    'et_staff.dob',
                    'et_staff.mobile_no',
                    'et_staff.email_id',
                    'et_staff.staff_image',
                    'et_staff.nick_name',
                    'et_staff.knowledge_tag',
                    'et_staff.per_hour_cost',
                    'et_job_position.job_position_name',
                    'et_staff.avaiable_points',
                    'et_staff.basic_salary',
                    'et_staff.status AS staff_status'
                )
                    ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                    ->where([
                        ['et_staff.status', 0],
                        ['et_staff.branch_id', $branch_id],
                        ['et_staff.sno', $staff_pc_list->sno]
                    ])
                    ->orderByDesc('et_staff.sno')
                    ->first();

                // Initialize variables
                $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                $overall_earned = $overall_earned_per = $success_staff_count = 0;
                $slotType = $staffproduction;

                $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                $slotType->present_count = $slotType->course_count = 0;
                $slotType->slotDetails = [];
                $slotType->avg_amnt = $slotType->salary = 0;

                // Fetch batch IDs associated with staff
                $batchIds = TrainingModel::where('branch_id', $branch_id)
                    ->where('staff_id', $slotType->sno)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();

                $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

                foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                        ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                        ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branch_id)
                            ->where('staff_id', $slotType->sno)
                            ->where(function ($query) use ($month, $year) {
                                $query->whereMonth('start_date', '<=', $month)
                                    ->whereYear('start_date', '<=', $year)
                                    ->whereMonth('end_date', '>=', $month)
                                    ->whereYear('end_date', '>=', $year);
                            })
                            ->pluck('batch_id'))
                        ->where('et_batch.status', 0)
                        ->get();

                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                        ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                        ->find($batchId);

                    if ($batch) {
                        $startTime = \Carbon\Carbon::parse($batch->start_time);
                        $endTime = \Carbon\Carbon::parse($batch->end_time);
                        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

                        // Fetch attendance records
                        $attendanceRecords = AttendanceModel::select('per_hr_cost')
                            ->where([
                                ['batch_id', $batch->sno],
                                ['staff_id', $slotType->sno],
                                ['attendance', 'P']
                            ])
                            ->whereMonth('att_date', $month)
                            ->whereYear('att_date', $year)
                            ->get();

                        foreach ($attendanceRecords as $attendance) {
                            $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                        }
                    }
                }

                // Student count
                $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('staff_id', $slotType->sno)
                    ->where(function ($query) use ($month, $year) {
                        $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');

                // Course count
                $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('staff_id', $slotType->sno)
                    ->where(function ($query) use ($month, $year) {
                        $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');

                // Batch count
                $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('staff_id', $slotType->sno)
                    ->where(function ($query) use ($month, $year) {
                        $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');

                // Salary calculation
                $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                // Average earned percentage calculation
                $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                // Calculate free batch count
                $total_free_batch = max(0, 8 - $slotType->batch_count);
                $overall_earned += $slotType->earned_amount;
                $overall_earned_per += $slotType->avg_amnt;
                // Count success staff
                if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                }
                $staffproduction = $slotType;
                $totalcosting_amount += $staffproduction->earned_amount ?? 0;
                $total_basic_pay_pro += $slotType->basic_salary ?? 0;

                $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branch_id)
                    ->where('referral_id', $staff_pc_list->sno)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();

                $totalrefferal_count += $refferal_count ?? 0;
            }
            $productions_asign   = $goalsetRecords->productions ?? 0;
            //   return $totalcosting_amount . ' / ' . $total_basic_pay_pro.'*'.$productions_asign;
            $totalcosting_amount2 = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro) *  $productions_asign : 0;

            $actual = $totalcosting_amount2 ?? 0;
            $target = $goalsetRecords->productions ?? 0;
            // return $actual . ' / ' . $target;
            $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
            //   if ($goal_progress > 100) {
            //     $goal_progress = 100;
            //   }

            return round($goal_progress);
            // PC Goal *****************************************************

        }
        // CRE
        if ($departmentId == 6) {
            // CRE Goal *****************************************************
            $review_count = DB::table('et_review')
                ->where('branch_id', $branch_id)
                ->where('created_by', $staff_id_get)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
            $actual = $review_count ?? 0;
            $target = $goalsetRecords->no_of_reviews ?? 0;
            // return $actual . ' / ' . $target;
            $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
            //   if ($goal_progress > 100) {
            //     $goal_progress = 100;
            //   }

            return round($goal_progress);
            // CRE Goal *****************************************************
        }
        // Collection Executive
        if ($departmentId == 7) {
            return 0;
            // Collection Exc *****************************************************
            $drop_ids = DB::table('et_drop_refund')
                ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                ->where('et_drop_refund.bh_status', 1)
                ->where('et_drop_refund.branch_id', $branch_id)
                ->pluck('et_training.payment_id');

            $OutstandingPayment_count = DB::table('et_payment')->where('et_payment.branch_id', $branch_id)
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_course', 'et_payment.course_id', '=', 'et_course.sno')
                ->whereNotIn('et_payment.payment_id', $drop_ids)
                ->where('et_payment.status', 0)
                ->where('et_payment.amount', '>', 0)
                ->whereIn('et_customer.status', [0, 6])
                ->whereMonth('et_payment.nextPayDate', $month)
                ->whereYear('et_payment.nextPayDate', $year)
                ->orderBy('et_payment.sno', 'asc')
                ->count();

            $post_sale_count = DB::table('et_training')
                ->where('created_by', $staff_id_get)
                ->where('post_sale_check', 1)
                ->whereYear('post_sale_date', $year)
                ->whereMonth('post_sale_date', $month)
                ->distinct()
                ->count('customer_id');


            $hacAmount = DB::table('et_payment')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->where('et_payment.status', 1) // paid amount
                ->whereIn('et_customer.status', [0, 6])
                ->whereYear('et_payment.initialPayDate', $year)
                ->whereMonth('et_payment.initialPayDate', $month)
                ->where('et_payment.branch_id', $branch_id)
                ->sum('et_payment.paidAmount');

            // Collection Exc *****************************************************
        }
        // Placement Executive
        if ($departmentId == 8) {
            $placement_count = DB::table('et_placement_interview')
                ->where('updated_by', $staff_id_get)
                ->where('status', 4)
                ->whereYear('selected_date', $year)
                ->whereMonth('selected_date', $month)
                ->distinct()
                ->count('customer_id');

            $actual = $placement_count ?? 0;
            $target = $goalsetRecords->mou ?? 0;
            // return $actual . ' / ' . $target;
            $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
            //   if ($goal_progress > 100) {
            //     $goal_progress = 100;
            //   }

            return round($goal_progress);
        }
        return 0;
    }
    // Get Branch and Franchise list based on user_id
    function get_branch_control_list_user($user_id)
    {
        // Fetch the user based on user_id
        $user = StaffModel::where('sno', $user_id)->first();

        if ($user && $user->sno == 124) {
            $branches = BranchModel::whereNotIn('sno', [1])
                ->where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();

            return ['branches' => $branches, 'franchises' => $franchises];
        } elseif ($user !== null) {
            // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
            $accessibleBranches = json_decode($user->multi_branch_access, true);

            if (!empty($accessibleBranches)) {
                // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
                $branches = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 1)
                    ->get();

                $franchises = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 2)
                    ->get();

                return ['branches' => $branches, 'franchises' => $franchises];
            }
        } else {
            // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
            $branches = BranchModel::where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();
            return ['branches' => $branches, 'franchises' => $franchises];
        }
    }

    function get_variant_and_varibale_name($cart_id)
    {
        $proposalProduct = DB::table('et_proposal_product_cart')
            ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
            ->where('et_proposal_product_cart.status', 0)
            ->where('et_proposal_product_cart.cart_id', $cart_id)
            ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
            ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->first();

        $variant_variable_ids = json_decode($proposalProduct->variant_variable_ids ?? '[]', true);

        $variant_names = [];

        foreach ($variant_variable_ids as $pair) {
            $variable_id = $pair['variable_id'] ?? null;
            $variant_id = $pair['variant_id'] ?? null;

            $product_variant_name = '';
            $variable_name = '';

            if ($variant_id) {
                $get_variant = ManageProductVaiantModel::find($variant_id);
                $product_variant_name = $get_variant->product_variant_name ?? '';
            }

            if ($variable_id) {
                $get_variables = ManageProductVariableModel::find($variable_id);
                if ($get_variables) {
                    $variable_name = $get_variables->variable_name;
                }
            }

            if ($product_variant_name && $variable_name) {
                $variant_names[] = "{$product_variant_name} - {$variable_name}";
            } elseif ($product_variant_name) {
                $variant_names[] = $product_variant_name;
            }
        }

        // ✅ Return as a string
        return !empty($variant_names) ? implode(', ', $variant_names) : '';
    }
    function get_product_task_count($id)
    {
        $data = DB::table('et_product_task')
            ->where('product_id', $id)
            ->whereMonth('status', 0)
            ->count();
        return $data;
    }

    function get_employee_skill_by_id($id = '')
    {
        $result = DB::table('et_employee_skill')->where('status', 0)->where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_Qbank_section_count($id)
    {
        $data = DB::table('et_exam_questions')
            ->where('bank_id', $id)
            ->distinct('section_id')  // only unique sections
            ->count('section_id');

        return $data;
    }

    function ConvertedAmountInr($currency_code, $amount)
    {
        $currencyRate = CurrencyRateModel::orderBy('sno', 'desc')->first();
        $rate = 1;
        if ($currencyRate) {
            $currencyData = json_decode($currencyRate->currency_data, true);

            $code = $currency_code;

            if (isset($currencyData[$code]) && $currencyData[$code] != 0) {
                $rate = 1 / $currencyData[$code]; // Convert to INR
            } else {
                $rate = 1; // Handle missing or zero rate
            }
        }
        $converted_amount = ($rate != 0) ? $amount * $rate : 0;
        $rounded = round($converted_amount, 2);
        return $rounded;
    }

    function ConvertedAmountAny($from_currency, $to_currency, $amount)
    {
        $currencyRate = CurrencyRateModel::orderBy('sno', 'desc')->first();
        $rateFrom = 1;
        $rateTo   = 1;

        if ($currencyRate) {
            $currencyData = json_decode($currencyRate->currency_data, true);

            // Rate for "from" currency
            if (isset($currencyData[$from_currency]) && $currencyData[$from_currency] != 0) {
                $rateFrom = $currencyData[$from_currency];
            }

            // Rate for "to" currency
            if (isset($currencyData[$to_currency]) && $currencyData[$to_currency] != 0) {
                $rateTo = $currencyData[$to_currency];
            }
        }

        // Convert to INR first, then to target currency
        $amountInInr = $amount / $rateFrom;
        $converted   = $amountInInr * $rateTo;

        return round($converted, 2);
    }


    function get_currency_product_price_book($product_id, $currency_id)
    {
        $data = DB::table('et_price_book')
            ->select(
                'et_price_book.max_amount',
                'et_price_book.min_amount',
                'et_price_book.base_price'
            )
            ->where('et_price_book.currency_id', $currency_id)
            ->where('et_price_book.product_id', $product_id)
            ->first();

        return $data;
    }

    function get_currency_package_price_book($package_id, $currency_id)
    {
        $data = DB::table('et_price_book')
            ->select(
                'et_price_book.max_amount',
                'et_price_book.min_amount',
                'et_price_book.base_price',
            )
            ->where('et_price_book.currency_id', $currency_id)
            ->where('et_price_book.package_id', $package_id)
            ->first();

        return $data;
    }

    function get_addon_variant($id)
    {
        $data = DB::table('et_manage_addon_variant')
            ->select(
                'et_manage_addon_variant.amount',
                'et_addon_varient.addon_varientname as varient_name',
                'et_manage_addon_variant.sno as varient_id',
            )
            ->leftJoin('et_addon_variable', 'et_addon_variable.sno', '=', 'et_manage_addon_variant.variable_id')
            ->leftJoin('et_addon_varient', 'et_addon_varient.sno', '=', 'et_addon_variable.addon_varientid')
            ->where('et_manage_addon_variant.addon_id', $id)
            ->get();

        return $data;
    }

    function get_currency_addon_price_book($addon_id, $currency_id)
    {
        $data = DB::table('et_price_book')
            ->where('currency_id', $currency_id)
            ->where('addon_id', $addon_id)
            ->first();

        if ($data && $data->varient_details) {
            // return the whole variant details array (not just amounts)
            return json_decode($data->varient_details, true);
        }

        return [];
    }

    public function showTicker($branch_id = '', $role_id = '')
    {
        $now = \Carbon\Carbon::now();

        $ticker = DB::table('et_news_broadcast')
            ->where('status', 0)
            ->whereJsonContains('branch_id', (string) $branch_id) // cast to string if stored as strings
            ->whereJsonContains('role_ids', (string) $role_id)
            ->where('start_date', '<=', $now)
            ->where('end_date', '>=', $now)
            ->orderBy('sno', 'desc')
            ->first();

        if ($ticker) {
            $settings = json_decode($ticker->theme_style, true);
            $news = json_decode($ticker->information, true);

            // Attach news data to settings (plugin expects "data")
            $settings['data'] = $news ?? [];
            return $settings;
        }

        return null;
    }

    public function getFirstPaymentDate($proposal_id = "")
    {
        $proposalData = DB::table('et_payment')->where('proposal_id', $proposal_id)->orderBy('sno', 'asc')->first();

        if ($proposalData && $proposalData->transaction_date) {
            return $proposalData->transaction_date;
        }

        return null;
    }
    public function getCustomerFirstPaymentDate($customer_id = "")
    {
        $proposalData = DB::table('et_payment')->where('customer_id', $customer_id)->orderBy('sno', 'asc')->first();

        if ($proposalData && $proposalData->transaction_date) {
            return $proposalData->transaction_date;
        }

        return null;
    }

    public function isProposalPageUpdated($proposalId = '')
    {
        $proposal = ProposalModel::where('sno', $proposalId)->first();
        if (!$proposal) {
            return 0;
        }
        if ($proposal->product_package == 1) {
            $productCart = DB::table('et_proposal_product_cart')
                ->where('proposal_sno', $proposalId)
                ->get();
            foreach ($productCart as $cart) {
                $product = DB::table('et_product')->where('sno', $cart->product_id)->first();
                if ($product->product_category_id == 2) {
                    continue;
                }
                if ($cart->total_pages == 0) {
                    return 1;
                }
            }
        } elseif ($proposal->product_package == 2) {
            $packageCart = DB::table('et_proposal_package_cart')
                ->where('proposal_sno', $proposalId)
                ->get();
            foreach ($packageCart as $cart) {
                $product = DB::table('et_product')->where('sno', $cart->product_id)->first();
                if ($product->product_category_id == 2) {
                    continue;
                }
                if ($cart->total_pages == 0) {
                    return 1;
                }
            }
        }
        return 0;
    }
    public function customer_total_paid_bal_percentage($customer_id)
    {
        // Retrieve all proposals for the given customer
        $proposals = DB::table('et_proposal')
            ->where('customer_id', $customer_id)
            ->get();

        // Initialize totals
        $total_payable_amount = 0;
        $total_paid_amount = 0;

        foreach ($proposals as $proposal) {
            // For each proposal, sum up the payable and paid amounts
            $payable_amount = DB::table('et_proposal_pay_slot')
                ->where('proposal_sno', $proposal->sno)
                ->sum('payable_amount');

            $paid_amount = DB::table('et_proposal_pay_slot')
                ->where('proposal_sno', $proposal->sno)
                ->sum('paidAmount');

            // Accumulate totals
            $total_payable_amount += $payable_amount;
            $total_paid_amount += $paid_amount;
        }

        // Calculate balance amount
        $balance_amount = $total_payable_amount - $total_paid_amount;

        // Calculate balance percentage
        if ($total_payable_amount > 0) {
            $balance_percentage = ($balance_amount / $total_payable_amount) * 100;
        } else {
            $balance_percentage = 0; // Avoid division by zero
        }

        // Calculate paid percentage
        if ($total_payable_amount > 0) {
            $paid_percentage = ($total_paid_amount / $total_payable_amount) * 100;
        } else {
            $paid_percentage = 0; // Avoid division by zero
        }

        // Return the results as an associative array
        return [
            'paid_amount' => $total_paid_amount,
            'payable_amount' => $total_payable_amount,
            'balance_amount' => $balance_amount,
            'balance_percentage' => $balance_percentage,
            'paid_percentage' => $paid_percentage,
        ];
    }

    //   GET ROLE USRMANAGEMENT
    function get_roles_task()
    {
        // Fetch roles from the UserRoleModel
        $roles = UserRoleModel::where('status', 0)->whereNotIn('sno', [1, 9])->get();

        // Filter roles to exclude those that are in userRolePermissions
        $filteredRoles = $roles;

        return $filteredRoles;
    }


    function get_nav_points($user_id)
    {
        // Exam-based points
        $history = DB::table('et_staff_exam_points')
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_staff_exam_points.badge_id')
            ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_staff_exam_points.badge_id')
            ->where('et_staff_exam_points.staff_id', $user_id)
            ->where('et_exam_badge.prize_id', 2)
            ->where('et_exam_badge.status', 0)
            ->where('et_staff_exam_points.status', 0)
            ->where('et_manage_exam.status', 0)
            ->select(
                'et_staff_exam_points.points',
                'et_staff_exam_points.created_at',
                DB::raw("'Assessment' as type"),
                'et_manage_exam.exam_name as name'
            )
            ->orderByDesc('et_staff_exam_points.created_at') // Sorting at DB level
            ->get();

        // Manual staff points
        $history2 = DB::table('et_staff_points')
            ->leftJoin('et_points', 'et_staff_points.points_id', '=', 'et_points.sno')
            ->where('et_staff_points.staff_id', $user_id)
            ->where('et_staff_points.status', 0)
            ->where('et_points.status', 0)
            ->select(
                'et_staff_points.points',
                'et_staff_points.created_at',
                DB::raw("'General' as type"),
                'et_points.points_name as name'
            )
            ->orderByDesc('et_staff_points.created_at') // Sorting at DB level
            ->get();

        // Merge both collections
        $merged = $history->merge($history2);

        // Total points
        $total_points = $merged->sum('points');

        return $total_points;
    }
    function get_task_status($staff_id, $task_id)
    {
        return DB::table('et_task_log')
            ->where('task_id', $task_id)
            ->where('staff_id', $staff_id)
            ->exists() ? 1 : 0;
    }
    
    public function journal_last_followup_data($service_id, $customer_id)
    {
        $data = DB::table('et_journal_followup')
            ->where('customer_service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->orderBy('sno', 'desc')
            ->first();
 
        return $data;
    }
    public function journal_last_followup_count($service_id, $customer_id)
    {
        $data = DB::table('et_journal_followup')
            ->where('customer_service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->orderBy('sno', 'desc')
            ->count();
 
        return $data;
    }
    
    function get_submitted_count($service_id, $customer_id) {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('submitted_count');
 
        return $data;
    }
 
    function get_reviewed_count($service_id, $customer_id)
    {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('reviewed_count');
 
        return $data;
    }
 
    function get_resubmitted_count($service_id, $customer_id)
    {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('resubmitted_count');
 
        return $data;
    }
 
    function get_accepted_count($service_id, $customer_id)
    {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('accepted_count');
 
        return $data;
    }
 
    function get_rejected_count($service_id, $customer_id)
    {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('reject_count');
 
        return $data;
    }
 
    function get_published_count($service_id, $customer_id)
    {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('published_count');
 
        return $data;
    }
    // GET Exam New Limits
    function get_new_exam_limits($exam_sno, $staff_sno)
    {
        $data = DB::table('et_exam_limit_increase')
            ->where('exam_id', $exam_sno)
            ->where('staff_id', $staff_sno)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();
 
        return $data->new_limit ?? 0;
    }
 public function get_work_order_status($id)
    {
        // Step 1: Get service details
        $service_details = DB::table('et_customer_services')->where('sno', $id)->first();
 
        // Step 2: Get milestone mapping (status = 0 means active/incomplete)
        $milestone_mapping = DB::table('et_milestone_mapping')
            ->where('customer_id', $service_details->customer_id)
            ->where('proposal_id', $service_details->proposal_id)
            ->where('status', 0)
            ->first();
 
        // Step 3: Get unlocked tasks
        $task_list = collect();
        $task_count = 0;
        if ($milestone_mapping) {
            $task_ids = json_decode($milestone_mapping->unlock_task_ids, true);
            if (!empty($task_ids)) {
                $task_list = DB::table('et_product_task')
                    ->whereIn('et_product_task.sno', $task_ids)
                    ->where('et_product_task.status', 0)
                    ->get();
                $task_count = count($task_list ?? []);
            }
        }
 
        // Step 4: Allocated task details
        $allocated_tasks = DB::table('et_task')->where('service_id', $id)->get();
 
        // Step 5: Calculate totals
        $allocated_task_count = count($allocated_tasks);
 
        $task_percentage = $task_count > 0
            ? round(($allocated_task_count / $task_count) * 100, 2)
            : 0;
 
        // Step 7: Return clean summary
        return (object)[
            'task_count' => $task_count,
            'allocated_task_count' => $allocated_task_count,
            'completion_percentage' => $task_percentage,
        ];
    }
    function get_domain_by_proposalId($proposal_id)
{
    if (!is_numeric($proposal_id)) {
        return null;
    }

    // Use DB::table() to query a specific table
    $proposal = DB::table('et_proposal')->where('sno', $proposal_id)->first();

    if (!$proposal) {
        return null;
    }

    $domain_ids = $proposal->domain_ids ? json_decode($proposal->domain_ids) : null;

    if ($domain_ids && is_array($domain_ids)) {
        $result = DB::table('et_domain') // Make sure this is your correct domain table
            ->whereIn('sno', $domain_ids)
            ->orderBy('domain_name', 'ASC')
            ->pluck('domain_name');

        return $result->isNotEmpty() ? $result : null;
    }

    return null;
}
public function get_payable_percentage($payable_amount, $paid_amount) {
        if ($payable_amount == 0) {
            return 0; // avoid division by zero
        }
 
        return ($paid_amount / $payable_amount) * 100;
    }
    
    function get_with_editor_count($service_id, $customer_id) {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('with_editor_count');
 
        return $data;
    }
 
    function get_under_reviewer_count($service_id, $customer_id) {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('under_reviewer_count');
 
        return $data;
    }
 
    function get_e_proofing_count($service_id, $customer_id) {
        $data = DB::table('et_manage_journal')
            ->where('service_id', $service_id)
            ->where('customer_id', $customer_id)
            ->where('status', '!=', 2)
            ->sum('e_proofing_count');
 
        return $data;
    }
    public static function getFileIcon($extension)
    {
        $icons = [
            'pdf' => 'mdi mdi-file-pdf text-danger',
            'doc' => 'mdi mdi-file-word text-primary',
            'docx' => 'mdi mdi-file-word text-primary',
            'xls' => 'mdi mdi-file-excel text-success',
            'xlsx' => 'mdi mdi-file-excel text-success',
            'ppt' => 'mdi mdi-file-powerpoint text-warning',
            'pptx' => 'mdi mdi-file-powerpoint text-warning',
            'jpg' => 'mdi mdi-file-image text-info',
            'jpeg' => 'mdi mdi-file-image text-info',
            'png' => 'mdi mdi-file-image text-info',
            'gif' => 'mdi mdi-file-image text-info',
            'txt' => 'mdi mdi-file-document',
            'zip' => 'mdi mdi-zip-box',
            'rar' => 'mdi mdi-zip-box',
            'csv' => 'mdi mdi-file-excel text-success',
        ];
 
        return $icons[strtolower($extension)] ?? 'mdi mdi-file';
    }
    
    public function getJournalTaskName($sno) {
        return DB::table('et_daily_tasks')
            ->leftJoin('et_journal_revision', 'et_journal_revision.sno', '=', 'et_daily_tasks.task_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
            ->where('et_daily_tasks.is_journal', 1)
            ->where('et_daily_tasks.sno', $sno)
            ->select('et_manage_journal.paper_name', 'et_manage_journal.journal_id')
            ->first();
    }
    public function getRequestTaskNames($sno) {
        return DB::table('et_daily_tasks')
            ->leftJoin('et_task_request', 'et_task_request.sno', '=', 'et_daily_tasks.task_id')
            ->leftJoin('et_journal_request', 'et_journal_request.sno', '=', 'et_task_request.request_id')
            ->where('et_daily_tasks.is_request', 1)
            ->where('et_daily_tasks.sno', $sno)
            ->select('et_journal_request.request_name')
            ->first();
    }     
    
}
