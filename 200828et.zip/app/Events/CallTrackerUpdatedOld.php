<?php

namespace App\Events;

use App\Models\CallTrackerModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Services\CallTrackerRealtimeService;

class CallTrackerUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Only send the data the frontend needs.
     */
    public array $call;

    public array $row;

    public function __construct(CallTrackerModel $call)
    {
        $this->row = app(CallTrackerRealtimeService::class)
                        ->getRow($call->sno);
    }

    /**
     * Public channel.
     * Later we can change this to a private channel.
     */
    public function broadcastOn(): array
    {
        return [
            new Channel('calls')
        ];
    }

    /**
     * Event name used in JavaScript.
     */
    public function broadcastAs(): string
    {
        return 'call.updated';
    }

    public function broadcastWith()
    {
        return [
            'row'=>$this->row
        ];
    }
}