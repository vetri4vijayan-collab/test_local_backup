<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class StaffExistUpdated implements ShouldBroadcastNow
{
    use Dispatchable, SerializesModels;

    public $staff;

    public function __construct($staff)
    {
        //  Send only required fields (important for performance)
        $this->staff = [
            'id' => $staff->sno,
            'name' => $staff->staff_name,
            'is_exist_egc' => $staff->is_exist_egc,
            'status' => $staff->status
        ];
    }

    public function broadcastOn()
    {
        return new Channel('staff-exist-channel');
    }

    public function broadcastAs()
    {
        return 'staff.exist.updated';
    }
}