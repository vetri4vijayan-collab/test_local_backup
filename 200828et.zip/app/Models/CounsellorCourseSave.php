<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CounsellorCourseSave  extends Model
{
    use HasFactory;
    public $table      = "et_counsellor_course_save";
    public $primaryKey = 'sno';

    protected $fillable = [
        'lead_id',
        'branch_id',
        'course_question_id',
        'category_id',
        'course_question_answer',
        'courses',
        'created_by',
        'updated_by',
        'status',
    ];
}
