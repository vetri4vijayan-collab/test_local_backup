<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClassRoomModel extends Model
{
    use HasFactory;
    public $table      = "et_class_room";
    public $primaryKey = 'sno';


    protected $fillable = [
        'class_room_id',
        'class_room_name',
        'class_room_type',
        'maximum_capacity',
        'facility_id',
        'class_room_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
