<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchChecklistModel extends Model
{
    use HasFactory;
    public $table      = 'et_batch_checklist';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'batch_checklist_id',
        'batch_checklist_name',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
