<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookletStatusModel extends Model
{
    use HasFactory;
    public $table      = "et_booklet_status";
    public $primaryKey = 'sno';


    protected $fillable = [
        'booklet_name',
        'booklet_desc',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
