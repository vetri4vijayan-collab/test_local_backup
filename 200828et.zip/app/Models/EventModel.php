<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventModel extends Model
{
    use HasFactory;
    public $table = "et_event";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'event_id',
        'event_category',
        'event_name',
        'location_url',
        'event_address',
        'zoom_link',
        'event_date',
        'event_offer',
        'event_amount',
        'coupon_code',
        'participants',
        'no_of_participants',
        'contact_person_name',
        'contact_person_mob_no',
        'handle_others_name',
        'handle_others_mobile',
        'handle_staff_id',
        'handle_type',
        'certificate',
        'certificate_type',
        'drop_reason',
        'event_description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'created_by',
        'status',
        'active_Event',
        'attendance_status',
        'transfer_participant',
        'event_key_tag',
    ];
}
