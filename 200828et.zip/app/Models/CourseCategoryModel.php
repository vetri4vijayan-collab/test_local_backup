<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseCategoryModel extends Model
{
    use HasFactory;
    public $table      = "et_course_category";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'course_category_id',
        'course_category_name',
        'course_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
