<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContactDetailsModel extends Model
{
    use HasFactory;
    public $table = 'et_contact_details';
    public $primaryKey = 'sno';

    protected $fillable = [
        'id',
        'contact_detail_id',
        'branch_id',
        'name',
        'mobile_no',
        'referral_by',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
