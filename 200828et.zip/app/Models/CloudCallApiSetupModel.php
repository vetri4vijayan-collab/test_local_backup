<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CloudCallApiSetupModel extends Model
{
    use HasFactory;
    public $table      = "et_cloudcall_api_setup";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'api_key',
        'phonecode',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}