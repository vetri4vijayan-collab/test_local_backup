<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamCategoryModel extends Model
{
    use HasFactory;
    public $table = 'et_exam_category';
    public $primaryKey = 'sno';

    protected $fillable = [
        'category_name',
        'category_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
