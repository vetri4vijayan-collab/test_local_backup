<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CronjobMonitorModel extends Model
{
    use HasFactory;
    public $table      = "et_cronjob_monitor";
    public $primaryKey = 'sno';


    protected $fillable = [
        'cronjob_name',
        'cronjob_desc',
        'sync_start_date_time',
        'sync_end_date_time',
        'sync_duration',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}
