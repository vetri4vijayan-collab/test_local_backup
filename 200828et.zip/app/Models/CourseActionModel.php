<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseActionModel extends Model
{
    use HasFactory;
    public $table      = "et_course_action";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'course_action_type_id',
        'course_action_icon',
        'course_action_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
