<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Batch_staff_swap_Model extends Model
{
  use HasFactory;
  public $table      = "et_batch_staff_swap_history";
  public $primaryKey = 'sno';


  protected $fillable = [
    'batch_id',
    'branch_id',
    'staff_id_before',
    'course_type_id',
    'staff_id_after',
    'swap_start_date',
    'swap_end_date',
    'reason',
    'updated_at',
    'updated_by',
    'created_at',
    'created_by',
    'status',
  ];
}
