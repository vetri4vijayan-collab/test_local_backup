<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamProcessModel extends Model
{
    use HasFactory;

    public $table = 'et_exam_process';
    public $primaryKey = 'sno';

    protected $fillable = [
        'exam_process_id',
        'branch_id',
        'exam_id',
        'staff_id',
        'exam_question_answers_datas', // Data for questions and answers
        'total_marks',
        'staff_marks',
        'attempted_not_count',
        'total_attended_duration',
        'created_by',
        'updated_by',
        'status',
    ];

    // Cast the JSON column to an array
    protected $casts = [
        'exam_question_answers_datas' => 'array',
    ];
}