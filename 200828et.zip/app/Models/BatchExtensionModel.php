<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchExtensionModel extends Model
{
    use HasFactory;
    public $table      = "et_batch_extension";
    public $primaryKey = 'sno';


    protected $fillable = [
        'batch_id',
        'branch_id',
        'batch_name',
        'start_date',
        'end_date',
        'change_date',
        'updated_at',
        'updated_by',
        'created_at',
        'created_by',
        'status',
    ];
}
