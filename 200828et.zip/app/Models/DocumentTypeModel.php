<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentTypeModel extends Model
{
    use HasFactory;
    public $table = 'et_document_type';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'documenttype_id',
        'branch_id',
        'documenttype_name',
        'documenttype_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
