<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Addon_product_VariantModel extends Model
{
    use HasFactory;

    public $table = "et_addon_varient"; // Replace with your actual table name
    public $primaryKey = 'sno';
    public $timestamps = false; // Because you're manually handling created_at & updated_at

    protected $fillable = [
        'sno',
        'addon_varientid',
        'addon_varientname',
        'addon_varientdes',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
