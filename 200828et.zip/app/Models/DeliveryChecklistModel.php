<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryChecklistModel extends Model
{

    use HasFactory;
    public $table = 'et_delivery_checklist';
    public $primaryKey = 'sno';

    protected $fillable = [
        'delivery_checklist',
        'updated_at',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
