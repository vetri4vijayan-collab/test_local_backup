<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamLimitIncreaseModel extends Model
{
    use HasFactory;
    public $table      = 'et_exam_limit_increase';
    public $primaryKey = 'sno';
    protected $fillable = [
        'sno',
        'exam_id',
        'staff_id',
        'old_limit',
        'new_limit',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status'
    ];
}
