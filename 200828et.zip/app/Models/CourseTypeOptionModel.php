<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseTypeOptionModel extends Model
{
    use HasFactory;
    public $table      = "et_customer_type_option";
    public $primaryKey = 'sno';


    protected $fillable = [
        'cus_type_opt_id',
        'customer_type_id',
        'field_name',
        'field_value',
        'field_option',
        'is_depends',
        'depends_on',
        'is_mandatory',
        'created_by',
        'created_at',
        'status',
    ];
}
