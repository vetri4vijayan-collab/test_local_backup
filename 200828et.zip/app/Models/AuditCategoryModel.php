<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditCategoryModel extends Model
{
    use HasFactory;
    public $table      = 'et_audit_category';
    public $primaryKey = 'sno';

    protected $fillable = [
        'audit_category_id',
        'branch_id',
        'audit_category_name',
        'audit_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
