<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdditionalChargesModel extends Model
{
    use HasFactory;
    public $table      = "et_additional_charges";
    public $primaryKey = 'sno';


    protected $fillable = [
        'adc_name',
        'adc_per',
        'adc_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
