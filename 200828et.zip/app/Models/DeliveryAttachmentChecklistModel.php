<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryAttachmentChecklistModel extends Model
{

    use HasFactory;
    public $table = 'et_delivery_attachment_checklist';
    public $primaryKey = 'sno';

    protected $fillable = [
        'delivery_attachment_checklist',
        'updated_at',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
