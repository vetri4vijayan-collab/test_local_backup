<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseActionTypeModel extends Model
{
    use HasFactory;
    public $table      = "et_course_action_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'course_action_type_name',
        'category',
        'category_file_upload',
        'category_text_link',
        'category_text_field',
        'category_text_area',
        'created_by',
        'created_at',
        'status',
    ];
}
