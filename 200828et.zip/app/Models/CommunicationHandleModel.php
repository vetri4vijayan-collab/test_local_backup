<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommunicationHandleModel extends Model
{
    use HasFactory;
    public $table      = 'et_communication_handle';
    public $primaryKey = 'sno';

    protected $fillable = [
        'module_name',
        'sms',
        'email',
        'whatsapp',
        'created_by',
        'updated_by',
        'status',
    ];
}
