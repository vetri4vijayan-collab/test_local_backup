<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CurrencyFormatModel extends Model
{
    use HasFactory;
    public $table = "et_country_currencies";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'country_name',
        'currency_code',
        'currency_name',
        'currency_symbol',
        'description',
        'created_at',
        'updated_at',
        'status',
    ];
}