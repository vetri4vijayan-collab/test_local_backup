<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppointmentModel extends Model
{
    use HasFactory;
    public $table      = "et_appointment";
    public $primaryKey = 'sno';

    protected $fillable = [
        'appointment_id',
        'lead_id',
        'branch_id',
        'appointment_date',
        'appointment_time',
        'created_by',
        'created_at',
        'follow_through',
        'status',
        'progressed',
    ];
}
