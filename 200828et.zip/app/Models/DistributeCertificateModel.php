<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DistributeCertificateModel extends Model
{
    use HasFactory;
    public $table      = 'et_certificate_distribution';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'batch_id',
        'student_status',
        'created_at',
        'updated_at',
        'created_by',
        'updated_by',
        'status',
    ];
}
