<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppointmentModeModel extends Model
{
    use HasFactory;

    public $table = "et_appointment_mode";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'appointment_mode_name',
        'appointment_mode_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
