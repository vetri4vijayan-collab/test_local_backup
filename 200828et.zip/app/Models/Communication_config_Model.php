<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Communication_config_Model extends Model
{
  use HasFactory;
  public $table      = 'et_communication_config';
  public $primaryKey = 'sno';

  protected $fillable = [
    'config_id',
    'work_flow_id',
    'work_flow_id',
    'time',
    'duration',
    'sms_check',
    'sms_template_id',
    'whatsapp_check',
    'whatsapp_template_id',
    'email_check',
    'created_at',
    'created_by',
    'updated_at',
    'updated_by',
    'status',
  ];
}
