<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerEducationModel extends Model
{
    use HasFactory;
    public $table      = "et_customer_education";
    public $primaryKey = 'sno';

    protected $fillable = [
        'education_id',
        'branch_id',
        'customer_type_id',
        'customer_id',
        'datas',
        'created_by',
        'updated_by',
        'status',
    ];
}
