<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckMaintenance
{
    public function handle(Request $request, Closure $next)
    {
        $maintenance = DB::table('et_general_settings')->value('maintenance_chk');

         $user = $request->user();
        // Check if maintenance is on AND user is authenticated AND user_id != 1
        if ($maintenance == 1 && $user && $user->user_id >1 ) {
            return response()->view('content.server_maintenance'); // maintenance page for non-admin users
        }

        return $next($request);
    }
}
