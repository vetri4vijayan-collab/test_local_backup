<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Models\BranchModel;

class BranchDataMiddleware
{
    public function handle($request, Closure $next)
    {
        $user = Auth::user();
        if ($user) {
            $branch = BranchModel::select('et_branch.*', 'et_cities.name as city_name', 'et_cities.id as city_id')
                ->leftJoin('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
                ->where('et_branch.sno', $user->branch_id)
                ->first();

            view()->share('branch_common', $branch);
        }

        return $next($request);
    }
}
