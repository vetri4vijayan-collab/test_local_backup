<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequestProfiler
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
    {
        $start = microtime(true);

        $response = $next($request);

        logger()->info([
            'url' => $request->fullUrl(),
            'request_time' => round((microtime(true) - $start), 3) . ' sec',
        ]);

        return $response;
    }
}
