<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PerformanceProfiler
{
    public function handle(Request $request, Closure $next)
    {
        $start = microtime(true);

        $response = $next($request);

        Log::info([
            'url' => $request->path(),
            'total_request_time' => round((microtime(true) - $start), 3).' sec'
        ]);

        return $response;
    }
}