<?php

namespace App\Http\Controllers\mobile_apps;

use App\Http\Controllers\Controller;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use App\Models\OtpModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class CustomerAppController extends Controller
{
    public function customerLogin(Request $request)
    {
        $mobile_no = $request->mobile_no;
        $email_id = $request->email_id;
        $check = $request->check;

        $validator = Validator::make($request->all(), [
            'check' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first()
            ]);
        } else {

            if ($check == 0) {
                $customer = DB::table('et_customer')
                    ->where('status', 0)
                    ->where('cus_mobile', $mobile_no)
                    ->whereNotNull('cus_mobile')
                    ->first();

                if (!$customer) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Customer Not Found !',
                        'status_code' => 404
                    ], 404);
                }

                $branch_data = DB::table('et_branch')
                    ->where('sno', $customer->branch_id)
                    ->where('status', 0)
                    ->first();

                if ($customer) {
                    if ($mobile_no == '9677482114') {
                        $otp_value = 123456;
                    } else {
                        $otp_value = rand(100000, 999999);
                    }

                    $otp = new OtpModel();

                    $otp->user_id = $customer->sno;
                    $otp->otp_check = $check;
                    $otp->user_from = $mobile_no;
                    $otp->otp_number = $otp_value;
                    $otp->created_by = $customer->sno;
                    $otp->updated_by = $customer->sno;
                    $otp->save();

                    // if ($mobile_no !== '9677482114') {
                    if ($otp_value) {
                        $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey         = $result_sms ? $result_sms->authkey : '';
                        $sender_id       = $result_sms ? $result_sms->sender_id : '';
                        $template_id     = $result_sms ? $result_sms->template_id : '';
                        $country_code    = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number   = $country_code . $mobile_no;

                        $app_name = "PhdIzone";
                        // $app_link = 'https://elysiumacademy.org/';
                        $app_code = "yDWtn76svb8";
                        // Replace placeholders with actual values
                        $replacement_values = [$customer->cus_name, $app_name, $otp_value, $app_code];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );

                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];

                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);

                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                    // }

                    return response()->json([
                        'status'             => "1",
                        'otp'                => $otp_value,
                        //  'otp'                => 123456,
                        'user_name'          => $customer->cus_name,
                        'customer_id'        => $customer->customer_id,
                        'phone_no'           => $customer->cus_mobile,
                        'email_id'           => $customer->cus_email_id,

                        'message'            => 'Successfully Login',
                        "error_msg"          => null,
                        'data'               => null,
                        'status_code'        => 200
                        // 'api_token'          => $token,
                    ], 200);
                }
            } else if ($check == 1) {
                $customer = DB::table('et_customer')
                    ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.cus_email_id', $email_id)
                    ->whereNotNull('et_customer.cus_email_id')
                    ->select('et_customer.*', 'et_lead.created_by as created_by')
                    ->first();

                if (!$customer) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Customer Not Found !',
                        'status_code' => 404
                    ], 404);
                }

                $branch_data = DB::table('et_branch')
                    ->where('sno', $customer->branch_id)
                    ->where('status', 0)
                    ->first();

                $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $customer->created_by)->first();

                if ($customer) {
                    if ($email_id == 'vetri4vijayan@gmail.com') {
                        $otp_value = 123456;
                    } else {
                        $otp_value = rand(100000, 999999);
                    }

                    $otp = new OtpModel();

                    $otp->user_id = $customer->sno;
                    $otp->otp_number = $otp_value;
                    $otp->otp_check = $check;
                    $otp->user_from = $email_id;
                    $otp->created_by = $customer->sno;
                    $otp->updated_by = $customer->sno;
                    $otp->save();

                    if ($otp_value) {
                        if ($customer && $email_id) {
                            $email_template_id = 12; // thank you template
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                            $dynamicSubject = str_replace('#entity_name', 'PhdIzone', $emailTemplate->email_name);
                            $content = $emailTemplate->email_subject;
                            $content = str_replace('#user_name', $customer->cus_name, $content);
                            $content = str_replace('#entity_name', 'PhdIzone', $content);
                            $content = str_replace('#otp_code', $otp_value, $content);
                            $branchNo = $branch_data->mobile;
                            $branchemail = $branch_data->mail;
                            $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                            $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                            $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
                            $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
                            $url = 'phdizone.com';
                            $mailData = [
                                'url'         => $url,
                                'subject'     => $dynamicSubject,
                                'content'     => $content,
                                'branchNo'    => $branchNo,
                                'branchemail' => $branchemail, // Use the message content from the request
                                'fbLink'      => $fbLink,      // Use the message content from the request
                                'instaLink'   => $instaLink,   // Use the message content from the request
                                'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                            ];

                            $to_address = $email_id;
                            $from_address = 'elysiumtechnology@elysium.community';
                            $from_name = 'PhdIzone';

                            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                        }
                    }

                    return response()->json([
                        'status'             => "1",
                        'otp'                => $otp_value,
                        //  'otp'                => 123456,
                        'user_name'          => $customer->cus_name,
                        'customer_id'        => $customer->customer_id,
                        'phone_no'           => $customer->cus_mobile,
                        'email_id'           => $customer->cus_email_id,

                        'message'            => 'Successfully Login',
                        "error_msg"          => null,
                        'data'               => null,
                        'status_code'        => 200
                        // 'api_token'          => $token,
                    ], 200);
                }
            } else {
                $response = [
                    'status' => "2",
                    'message' => 'Customer does not exists',
                    'error_msg' => null,
                    'data' => null,
                    'status_code' => 404
                ];

                return response($response, 200);
            }
        }
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first(),
                'status_code' => 410
            ], 410);
        }

        $check = $request->check;
        $mobile_no = $request->mobile_no;
        $email_id = $request->email_id;
        $otpInput = $request->otp;

        if ($check == 0) {
            $otpRecord = OtpModel::where('user_from', $mobile_no)
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->orderBy('sno', 'desc')
                ->first();

            if (!$otpRecord) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No OTP found for this number.',
                    'status_code' => 404
                ], 404);
            }

            $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
            $expiryTime = $createdAt->copy()->addMinutes(2);
            $currentTime = Carbon::now('UTC');

            if ($currentTime->greaterThan($expiryTime)) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'OTP expired. Please request a new one.',
                    'status_code' => 410
                ], 410);
            }

            if ($otpRecord->otp_number != $otpInput) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Invalid OTP.',
                    'status_code' => 401
                ], 401);
            }
        } else {
            $otpRecord = OtpModel::where('user_from', $email_id)
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->first();

            if (!$otpRecord) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No OTP found for this email.',
                    'status_code' => 404,
                ], 404);
            }

            $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
            $expiryTime = $createdAt->copy()->addMinutes(10);
            $currentTime = Carbon::now('UTC');

            if ($currentTime->greaterThan($expiryTime)) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'OTP expired. Please request a new one.',
                    'status_code' => 410
                ], 410);
            }

            if ($otpRecord->otp_number != $otpInput) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Invalid OTP.',
                    'status_code' => 401
                ], 401);
            }
        }

        if ($otpRecord->otp_number == $otpInput) {
            DB::table('et_otp')
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->update([
                    'status' => 2
                ]);
        }

        return response()->json([
            'status'  => 'success',
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
            'status_code' => 200
        ], 200);
    }

    public function customerDetails(Request $request)
    {
        $id = $request->user_id;

        if (!$id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $customer = DB::table('et_customer')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->where('et_customer.sno', $id)
            ->where('et_customer.status', 0)
            ->select(
                'et_customer.*',
                'et_countries.name as country_name',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->first();

        if (!$customer) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Not Found !',
                'status_code' => 404
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Customer Data Fetched Successfully !',
            'data' => [
                'name' => $customer->cus_name,
                'customer_id' => $customer->customer_id,
                'mobile_no' => $customer->cus_mobile,
                'email_id' => $customer->cus_email_id,
                'country' => $customer->country_name,
                'state' => $customer->state_name,
                'city' => $customer->city_name,
                'door_no' => $customer->door_no,
                'area' => $customer->address,
                'pincode' => $customer->pincode
            ],
            'status_code' => 200
        ], 200);
    }

    public function proposalData(Request $request)
    {
        $id = $request->user_id;

        if (!$id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $proposals = DB::table('et_proposal')
            ->where('customer_id', $id)
            ->select('service_title', 'proposal_id', 'sno')
            ->get();

        if ($proposals->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404
            ], 404);
        }

        $data = [];

        foreach ($proposals as $pro) {
            $pro->service_count = DB::table('et_customer_services')
                ->where('proposal_id', $pro->sno)
                ->count();

            $data[] = [
                'id' => $pro->sno,
                'title' => $pro->service_title,
                'proposal_id' => $pro->proposal_id,
                'service_count' => $pro->service_count
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Proposal Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200
        ], 200);
    }

    public function serviceData(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;

        if (!$id || !$proposal_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.proposal_id', $proposal_id)
            ->select(
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.variant_variable_ids',
                'et_product.product_name',
                'et_product_category.product_category_name'
            )
            ->get();

        if ($services->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Services Found For This Proposal !',
                'status_code' => 404
            ], 404);
        }

        $data = [];
        foreach ($services as $service) {
            $variantVariableIds = json_decode($service->variant_variable_ids, true);

            $variantName = '';
            $variableName = '';

            if (is_array($variantVariableIds)) {
                foreach ($variantVariableIds as $variantVariable) {
                    $variant = DB::table('et_manage_product_variant')->where('sno', $variantVariable['variant_id'])->first();
                    $variable = DB::table('et_manage_product_variable')->where('sno', $variantVariable['variable_id'])->first();

                    if ($variant) {
                        $variantName = $variant->product_variant_name ?? '';
                    }

                    if ($variable) {
                        $variableName = $variable->variable_name ?? '';
                    }
                }
            }

            $year = date('Y', strtotime($service->created_at));
            $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$tempid}/{$year}";

            $service->variant_name = $variantName;
            $service->variable_name = $variableName;

            $milestoneCount = DB::table('et_milestone_mapping')
                ->where('service_id', $service->sno)
                ->where('customer_id', $id)
                ->where('proposal_id', $proposal_id)
                ->where('status', 0)
                ->count();

            $data[] = [
                'id' => $service->sno,
                'service_id' => $service->service_id,
                'name' => $service->product_name,
                'category' => $service->product_category_name,
                'variant' => $service->variant_name,
                'variable' => $service->variable_name,
                'milestone_count' => $milestoneCount
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Service Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200
        ], 200);
    }

    public function milestoneData(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;
        $service_id = $request->service_id;

        if (!$id || !$service_id || !$proposal_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Id Not Found !'
            ], 404);
        }

        $service = DB::table('et_customer_services')
            ->where('sno', $service_id)
            ->first();

        if (!$service) {
            return response([
                'status' => 404,
                'message' => 'No Service Found',
                'status_code' => 404,
                'data' => null
            ], 404);
        }

        $year = date('Y', strtotime($service->created_at));
        $serviceFormatId = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
        $formatted_service_id = "SR-{$serviceFormatId}/{$year}";

        $service_dates = DB::table('et_work_order')
            ->where('proposal_id', $proposal_id)
            ->select(
                'development_date',
                'deliverable_date',
                'customer_end_date'
            )
            ->where('status', 0)
            ->first();

        // 1️⃣ Get milestones
        $milestones = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->where('et_milestone_mapping.customer_id', $id)
            ->where('et_milestone_mapping.service_id', $service_id)
            ->where('et_milestone_mapping.proposal_id', $proposal_id)
            ->select(
                'et_milestone_mapping.sno',
                'et_milestone_mapping.task_ids',
                'et_milestone_mapping.status',
                 'et_proposal_pay_slot.proposal_sno',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->get();

        if ($milestones->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Milestones Found'
            ], 404);
        }

        // 2️⃣ Collect all task IDs
        $allTaskIds = [];
        foreach ($milestones as $mile) {
            $taskIds = json_decode($mile->task_ids, true);
            if (is_array($taskIds)) {
                $allTaskIds = array_merge($allTaskIds, $taskIds);
            }
        }
        $allTaskIds = array_unique($allTaskIds);

        // 3️⃣ Fetch task names
        $taskNames = [];
        if (!empty($allTaskIds)) {
            $taskNames = DB::table('et_product_task')
                ->whereIn('sno', $allTaskIds)
                ->pluck('task_name', 'sno')
                ->toArray();
        }

        // 4️⃣ Build final response
        $finalMilestones = [];
        $totalTaskIds = [];

        foreach ($milestones as $mile) {
            $taskIds = json_decode($mile->task_ids, true) ?? [];
            $taskNameList = [];

            foreach ($taskIds as $taskId) {
                if (isset($taskNames[$taskId])) {
                    $taskNameList[] = $taskNames[$taskId];
                }
            }

            $totalTaskIds = array_merge($totalTaskIds, $taskIds);

            $milestoneProgress = 0;
            if ($mile->payable_amount > 0) {
                $milestoneProgress = round(($mile->paidAmount / $mile->payable_amount) * 100, 2);
            }

            $Proposals = DB::table('et_proposal')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.sno', $mile->proposal_sno)
            ->select('et_proposal.service_title', 'et_proposal.proposal_id', 'et_proposal.sno', 'et_proposal.total_amount', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->first();
 
            $finalMilestones[] = [
                'sno' => $mile->sno,
                'payment_slot_name' => $mile->payment_slot_name,
                'currency_symbol' => $Proposals->currency_symbol,
                'payable_amount' => $mile->payable_amount,
                'paidAmount' => $mile->paidAmount,
                'progress' => $milestoneProgress,
                'status' => $mile->status,
                'task_ids' => $taskIds,
                'task_names' => $taskNameList,
                'task_count' => count($taskNameList),
            ];
        }

        $overallPayable = $milestones->sum(function ($item) {
            return (float) $item->payable_amount;
        });

        $overallPaid = $milestones->sum(function ($item) {
            return (float) $item->paidAmount;
        });

        $overallBalance = $overallPayable - $overallPaid;

        $paymentProgress = 0;

        if ($overallPayable > 0) {
            $paymentProgress = round(($overallPaid / $overallPayable) * 100, 2);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Milestone Data Fetched Successfully!',
            'total_task_count' => count(array_unique($totalTaskIds)),
            'service_id' => $formatted_service_id,
            'total_costing' => $overallPayable,
            'paid_cost' => $overallPaid,
            'due_cost' => $overallBalance,
            'payment_progress' => $paymentProgress,
            'estimated_date' => $service_dates->deliverable_date ?? null,
            'validity_date' => $service_dates->customer_end_date ?? null,
            'data' => $finalMilestones
        ]);
    }

    public function getJournalServices(Request $request)
    {
        $id = $request->user_id;

        if (!$id) {
            return response()->json([
                'status' => 404,
                'message' => 'Please Login...',
                'status_code' => 404,
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->where('et_customer_services.status', '!=', 2)
            ->where('et_customer_services.sno', $id)
            ->where('et_customer_services.journal_check', 1)
            ->select(
                'et_product.product_name',
                'et_customer_services.sno',
                'et_customer_services.created_at'
            )
            ->get();

        if ($services->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No Services Found !',
                'status_code' => 404
            ], 404);
        }

        $data = [];

        foreach ($services as $service) {
            $year = date('Y', strtotime($service->created_at));
            $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$tempid}/{$year}";

            $service->journal_count = DB::table('et_manage_journal')
                ->where('service_id', $service->sno)
                ->where('customer_id', $id)
                ->where('status', '!=', 2)
                ->count();

            $data[] = [
                'sno' => $service->sno,
                'name' => $service->product_name,
                'service_id' => $service->service_id,
                'journal_count' => $service->journal_count
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Service Data Fetched Successfully !',
            'status_code' => 200,
            'data' => $data
        ], 200);
    }

    public function getJournalList(Request $request)
    {
        $id = $request->user_id;
        $serviceId = $request->service_id;
        $helper = new \App\Helpers\Helpers();

        if (!$id || !$serviceId) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'Id Not Found !'
            ], 404);
        }

        $service = DB::table('et_customer_services')
            ->where('customer_id', $id)
            ->where('sno', $serviceId)
            ->select('proposal_id')
            ->first();

        if (!$service) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No Service Found !'
            ], 404);
        }

        $journals = DB::table('et_manage_journal')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.customer_id', $id)
            ->where('et_manage_journal.service_id', $serviceId)
            ->select(
                'et_manage_journal.sno',
                'et_manage_journal.paper_name',
                'et_manage_journal.submited_date',
                'et_manage_journal.status',
                'et_manage_journal.journal_id',
                'et_manage_journal.publish_author',
                'et_journal_booklet.journal_name'
            )
            ->get();

        if ($journals->isEmpty()) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No Journals Found For the Customer !'
            ], 404);
        }

        $submittedCount = DB::table('et_manage_journal')
            ->where('status', 0)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $withEditorCount = DB::table('et_manage_journal')
            ->where('status', 1)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $underReviewerCount = DB::table('et_manage_journal')
            ->where('status', 3)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $revisionCount = DB::table('et_manage_journal')
            ->where('status', 4)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $acceptedCount = DB::table('et_manage_journal')
            ->where('status', 5)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $rejectedCount = DB::table('et_manage_journal')
            ->where('status', 6)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $eProofingCount = DB::table('et_manage_journal')
            ->where('status', 7)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $publichedCount = DB::table('et_manage_journal')
            ->where('status', 8)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $data = [];
        foreach ($journals as $journal) {

            $domain_names = $helper->get_domain_by_proposalId($service->proposal_id);

            $data[] = [
                'sno' => $journal->sno,
                'journal_name' => $journal->paper_name,
                'status' => $journal->status,
                'booklet' => $journal->journal_name,
                'author' => $journal->publish_author ?? '-',
                'domains' => $domain_names,
                'submited_date' => $journal->submited_date,
                'journal_id' => $journal->journal_id
            ];
        }

        return response()->json([
            'status' => 200,
            'status_code' => 200,
            'message' => 'Journal Data Fetched Successfully !',
            'submitted_count' => $submittedCount,
            'with_editor_count' => $withEditorCount,
            'under_reviewer_count' => $underReviewerCount,
            'revision_count' => $revisionCount,
            'accepted_count' => $acceptedCount,
            'rejected_count' => $rejectedCount,
            'e_proofing_count' => $eProofingCount,
            'published_count' => $publichedCount,
            'journal_data' => $data
        ], 200);
    }

    public function getJournalHistory(Request $request)
    {
        $id = $request->user_id;
        $service_id = $request->service_id;
        $journal_id = $request->journal_id;

        if (!$id || !$service_id || !$journal_id) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'ID Not Found !'
            ], 404);
        }

        $histories = DB::table('et_journal_history')
            ->where('customer_id', $id)
            ->where('service_id', $service_id)
            ->where('journal_id', $journal_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'asc')
            ->get();

        if ($histories->isEmpty()) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No History Found !'
            ], 404);
        }

        foreach ($histories as $history) {
            $history->submitteddocuments = json_decode($history->submitted_documents, true);
            $history->with_editordocuments = json_decode($history->with_editor_documents, true);
            $history->under_reviewerdocuments = json_decode($history->under_reviewer_documents, true);
            $history->reviewerdocument = json_decode($history->reviewer_document, true);
            $history->accepteddocument = json_decode($history->accepted_document, true);
            $history->e_proofingdocuments = json_decode($history->e_proofing_documents, true);
            $history->publishedfiles = json_decode($history->published_files, true);
        }


        return response()->json([
            'status' => 200,
            'status_code' => 200,
            'message' => 'Journal Histories Fetched Successfully !',
            'data' => $histories
        ], 200);
    }

    public function PaymentData(Request $request)
    {
        $id = $request->user_id;

        if (!$id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $proposals = DB::table('et_proposal')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.customer_id', $id)
            ->select('et_proposal.service_title', 'et_proposal.proposal_id', 'et_proposal.sno', 'et_proposal.total_amount', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->get();

        if ($proposals->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404
            ], 404);
        }

        $data = [];

        foreach ($proposals as $pro) {

            // $pay_slot

            $pro->service_count = DB::table('et_customer_services')
                ->where('proposal_id', $pro->sno)
                ->count();

            $data[] = [
                'id' => $pro->sno,
                'title' => $pro->service_title,
                'proposal_id' => $pro->proposal_id,
                'currency_symbol' => $pro->currency_symbol,
                'proposal_total_amount' => round($pro->total_amount),
                'service_count' => $pro->service_count
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Data Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }

    public function PaymentDetails(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;

        if (!$id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $proposal = DB::table('et_proposal')
            ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->where('et_proposal.sno', $proposal_id)
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.status', '!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->first();

        if (!$proposal) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404
            ], 404);
        }

        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->leftJoin('et_payment', function ($join) {
                $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->where('et_payment.status', 0);  // Adding the status condition here
            })
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->get();

        $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $PaidAmount = $slots->sum('paidAmount');
        $total_balance = $slot_total->total_amount ? $slot_total->total_amount - $PaidAmount : 0;
        $data = [];
        $list = [];
        $paidCount = 0;
        foreach ($slots as $li) {
            $payment_status = 'Waiting';
            if (isset($li->temp_send_link)) {
                $payment_status = 'Pay Now';
            }
            if ($li->payment_status == 1) {
                $payment_status = 'Paid';
                $paidCount++;
                $li->temp_send_link = '';
            }

            $list[] = [
                'payment_slot_id' => $li->sno,
                'payment_slot_name' => $li->payment_slot_name,
                'payment_status' => $payment_status,
                'payment_link' => $li->temp_send_link,
                'slot_amount' => $li->slot_amount,
            ];
        }
        $total_payments = $slots->isNotEmpty() ? count($slots) : 0;

        $data[] = [
            'id' => $proposal->sno,
            'title' => $proposal->service_title,
            'proposal_id' => $proposal->proposal_id,
            'currency_symbol' => $proposal->currency_symbol,
            'total_amount' => round($slot_total->total_amount),
            'total_paid' => round($PaidAmount),
            'total_balance' => round($total_balance),
            'total_payment_count' => $total_payments,
            'paid_payments_count' => $paidCount,
            'payment_list' => $list,
        ];

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Details Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }
    public function PaymentSlotDetails(Request $request)
    {
        $id = $request->user_id;
        $proposal_slot_id = $request->payment_slot_id;

        if (!$id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404
            ], 404);
        }

        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->leftJoin('et_payment', function ($join) {
                $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->where('et_payment.status', 0);  // Adding the status condition here
            })
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_proposal_pay_slot.sno', $proposal_slot_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.sno', $proposal_slot_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $PaidAmount = $slots->paidAmount;
        $total_balance = $slot_total->slot_amount ? $slot_total->slot_amount - $PaidAmount : 0;


        $proposal = DB::table('et_proposal')
            ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->where('et_proposal.sno', $slots->proposal_sno)
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.status', '!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->first();

        if (!$proposal) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404
            ], 404);
        }

        $payment = DB::table('et_payment')
            ->where('pay_slot_id', $proposal_slot_id)
            ->first();
        $helper = new \App\Helpers\Helpers();


        $encryptedValue = $helper->encrypt_decrypt($proposal_slot_id, 'encrypt');
        $print_url = url('/receipt_print/' . $encryptedValue);

        $data = [];

        $data[] = [
            'id' => $proposal->sno,
            'title' => $proposal->service_title,
            'proposal_id' => $proposal->proposal_id,
            'currency_symbol' => $proposal->currency_symbol,
            'total_amount' => round($slot_total->slot_amount),
            'total_paid' => round($PaidAmount),
            'total_balance' => round($total_balance),
            'payment_slot_name' => $slots->payment_slot_name,
            'payment_date' => $payment->transaction_date ? date('d-M-Y', strtotime($payment->transaction_date)) : '',
            'print_url' =>$print_url
        ];

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Slot Details Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }
}
