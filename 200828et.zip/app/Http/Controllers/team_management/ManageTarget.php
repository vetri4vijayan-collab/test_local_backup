<?php

namespace App\Http\Controllers\goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
class ManageTarget extends Controller
{


  public function index()
    {
        return view('content.team_management.manage_target');
    }

       public function getTargets(Request $request)
    {
        // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    
        // Fetch target record for given branch and date
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->first();
    
        return response()->json(['status' => 200, 'data' => $targets]);
    }
    
    public function getTargetsTeam(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
    
        // Fetch target
        $targets = DB::table('branch_target')->where('branch_target.branch_id', $request->branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
    
        // Old payments
        $totalPaidAmountOld = 0;
    
        // New payments
        $totalPaidAmountNew = 0;
    
             $transaction = 0;
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $transaction;
    
        // Post-sale & pre-sale actuals (count only)
        $postSaleActual = CustomerModel::whereIn('status', [0, 6])
            // ->where('post_sale_check', 1)
            ->where('branch_id', $request->branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
    
        $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            // ->where('post_sale_check', 0)
            ->where('branch_id', $request->branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
    
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
            ]
        ]);
    }


    public function updateTargets(Request $request)
{
    $request->validate([
        'branch_id' => 'required|integer',
        'no_of_registrations' => 'required|integer|min:0',
        'post_sale' => 'required|integer|min:0',
        'monthly_target' => 'required|integer|min:0',
    ]);

    // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    $userId = auth()->user()->user_id ?? 0; // Get current logged-in user

    // Check if record already exists
    $existing = ManageTargetModel::where('branch_id', $request->branch_id)
                ->where('date', $targetDate)
                ->first();

    if ($existing) {
        // Update path
        $existing->no_of_registrations = $request->no_of_registrations;
        $existing->post_sale = $request->post_sale;
        $existing->monthly_target = $request->monthly_target;
        $existing->updated_by = $userId;
        $existing->save();
    } else {
        // Insert path
        ManageTargetModel::create([
            'branch_id' => $request->branch_id,
            'date' => $targetDate,
            'no_of_registrations' => $request->no_of_registrations,
             'post_sale' => $request->post_sale,
            'monthly_target' => $request->monthly_target,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Target saved successfully.'
    ]);
}



}
