<?php
namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use App\Models\LeadMetricsModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class TeamManagement extends Controller
{
    
    public function TeamLead(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 50);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));
        
        $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;

    //   if($user_id==0){
          
    //   }else{
    //         return view('content.working_on_progress');
    //   }

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

            // $salesStaff = DB::table('et_staff')
            //     ->select('et_staff.sno', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_staff.lead_bank_count')
            //     ->where('et_staff.status','!=',2)
            //     ->where('et_staff.department_id', 1)
            //     ->where('et_staff.branch_id', $branch_id);
            
        
         $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.sno','>', 1)
            // ->where('et_staff.sno', 10)
            ->where('et_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $year)
                            ->whereMonth('et_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $year)
                            ->whereMonth('et_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('et_staff.status', 0);
            });

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $total_staff=$salesStaff->count();
        $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);


        $totalAverageBusinessValue = 0;
        $totalAverageCollectionValue     = 0;
        $totalAverageconvertRatio     = 0;
        $totalconvertRatio     = 0;
        $totalSpamLeadRatio     = 0;
        $totalDeadLeadRatio     = 0;
        $totalAllLead             = 0;
        $totalMonthLead            = 0;
        $totalconvertCustomer            = 0;
        $totalHotLead        = 0;
        $totalSpamLead      = 0;
        $totalDeadLead    = 0;

        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $staff) {

          $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.branch_id', $branch_id)
              ->whereNotIn('et_lead.status',[2,6])
              ->where('et_lead.spam_verified',0)
              ->where('et_lead.drop_verified', 0)
              ->where('et_lead.internal_status',0)
              ->count();

            $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status',0)
            ->count();

            $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.lead_status_id',3)
            ->where('et_lead.internal_status',0)
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.drop_verified', 0)
            ->count();

          

            // $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
            // ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            // ->where('et_customer.branch_id', $branch_id)
            // ->where('et_customer.status', 0)
            // ->where('et_lead.created_by', $staff->sno)
            // ->whereYear('et_customer.created_at', $year)
            // ->whereMonth('et_customer.created_at', $month)
            // ->count();
            
          $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $staff->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

            
            
            $customerConvertCount =count($customerConvertData);
            // return $customerConvertCount;

            $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.spam_verified',1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 7)->count();

            $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.drop_verified', 1)
                ->where('et_lead.branch_id', $branch_id)
                ->where('et_lead.status', 5)->count();

            // Spam Ratio 
            $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio>100 ? 100:$spam_lead_ratio, 2);

            // Dead ratio
            $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio>100 ? 100:$dead_lead_ratio, 2);

            // customer ratio
            $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            //acr
            $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
            $averager_convertion_rate =  number_format($averager_convertion_rate>100 ? 100:$averager_convertion_rate, 2);
          
            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            
            $base_amount_paid = 0; // keep track of GST-excluded total

            $gst_percent = 18;
            
            $currentMonthCustomer = $customerConvertData;

            if ($customerConvertCount > 0) {
                if ($currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                            $proposal_ids = DB::table('et_proposal')
                                ->where('et_proposal.customer_id', $customer->sno)
                                ->where('et_proposal.status', 0)
                                ->whereNot('et_proposal.post_sale_check', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                ->pluck('sno')
                                ->toArray();
                                // return $proposal_ids;
                    
                            $proposals = DB::table('et_proposal')
                                ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                ->whereIn('et_proposal.sno', $proposal_ids)
                                ->get();
                    
                            foreach ($proposals as $proposal) {
                                // Paid slots for this proposal
                                $paidAmount = DB::table('et_proposal_pay_slot')
                                    ->where('proposal_sno', $proposal->sno)
                                    ->where('status', 0)
                                    ->sum('paidAmount');
                    
                                $grantAmount = $proposal->grant_total_amount;
                    
                                // First remove GST from paidAmount (base value in proposal's currency)
                                $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                    
                                if ($proposal->currency_id == 70) {
                                    // INR: add directly
                                    $total_paid_payment += $paidAmount;
                                    $total_payment += $grantAmount;
                                    $base_amount_paid += $basePaidLocal;
                                } else {
                                    // Non-INR: convert both amounts and base value
                                    $currency_code = $proposal->currency_code;
                                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                }
                            }
                        }
                    }
                
                
                // average 
                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                $totalAllPayment +=$total_payment;
                $totalAllPaidPayment +=$base_amount_paid;
            }

            $staff->allLeadCount           = $allLeadCount;
            $staff->monthLeadCount       = $monthLeadCount;
            $staff->hotLeadCount        = $hotLeadCount;
            $staff->customerConvertCount      = $customerConvertCount;
            $staff->spamLeadCount            = $spamLeadCount;
            $staff->deadLeadCount      = $deadLeadCount;
            $staff->spam_lead_ratio            = $spam_lead_ratio;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->convertion_rate   = $convertion_rate;
            $staff->averager_convertion_rate   = $averager_convertion_rate;
            $staff->averageBusinessValue = $averageBusinessValue;
            $staff->averageCollectionValue    = $averageCollectionValue;

            // total cal
            $totalAllLead             += $allLeadCount;
            $totalMonthLead            += $monthLeadCount;
            $totalHotLead        += $hotLeadCount;
            $totalconvertCustomer            += $customerConvertCount;
            $totalSpamLead      += $spamLeadCount;
            $totalDeadLead    += $deadLeadCount;


        }

        // Calculate total ratio
        // Spam Ratio 
        $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
        $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);

        // Dead ratio
        $totalDeadLeadRatio      = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
        $totalDeadLeadRatio      = number_format($totalDeadLeadRatio, 2);

        // customer ratio
        $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
        $totalconvertRatio = number_format($totalconvertRatio, 2);

        //acr
        $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
        $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

        $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
        $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.team_management.team_lead', [
            'salesStaff'       => $salesStaff,
            'totalAverageBusinessValue'       => $totalAverageBusinessValue,
            'totalAverageCollectionValue'       => $totalAverageCollectionValue,
            'totalAverageconvertRatio'       => $totalAverageconvertRatio,
            'totalconvertRatio'       => $totalconvertRatio,
            'totalDeadLeadRatio'       => $totalDeadLeadRatio,
            'totalSpamLeadRatio'       => $totalSpamLeadRatio,
            'totalDeadLead'       => $totalDeadLead,
            'totalSpamLead'       => $totalSpamLead,
            'totalHotLead'       => $totalHotLead,
            'totalconvertCustomer'       => $totalconvertCustomer,
            'totalMonthLead'       => $totalMonthLead,
            'totalAllLead'       => $totalAllLead,
            'month_chk'        => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
            'month_filter' => $month_filter,

        ]);
    }
    
    public function PostSaleTeamLead(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 50);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));
        
        $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;

       

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        $lead_fill = $request->input('lead_fill', '');

            // $salesStaff = DB::table('et_staff')
            //     ->select('et_staff.sno', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_staff.lead_bank_count')
            //     ->where('et_staff.status','!=',2)
            //     ->where('et_staff.department_id', 1)
            //     ->where('et_staff.branch_id', $branch_id);
            
      
         $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 15)
            ->where('et_staff.sno','!=', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $year)
                            ->whereMonth('et_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $year)
                            ->whereMonth('et_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('et_staff.status', 0);
            });
        

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $total_staff=$salesStaff->count();
        $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);


        $totalAverageBusinessValue = 0;
        $totalAverageCollectionValue     = 0;
        $totalAverageconvertRatio     = 0;
        $totalconvertRatio     = 0;
        $totalSpamLeadRatio     = 0;
        $totalDeadLeadRatio     = 0;
        $totalAllLead             = 0;
        $totalMonthLead            = 0;
        $totalconvertCustomer            = 0;
        $totalHotLead        = 0;
        $totalSpamLead      = 0;
        $totalDeadLead    = 0;

        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;
            $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $staff) {

        //   $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
        //       ->where('et_lead.created_by', $staff->sno)
        //       ->where('et_lead.branch_id', $branch_id)
        //       ->whereNotIn('et_lead.status',[2,6])
        //       ->where('et_lead.spam_verified',0)
        //       ->where('et_lead.drop_verified', 0)
        //       ->where('et_lead.internal_status',0)
        //       ->count();
              
             $allpostSaleData = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids','et_proposal.post_sale_date')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal.created_by', $staff->sno)
                ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
                ->get();
            $allLeadCount =count($allpostSaleData);
            $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status',0)
            ->count();

            $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.lead_status_id',3)
            ->where('et_lead.internal_status',0)
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.drop_verified', 0)
            ->count();

            

            // $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
            // ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            // ->where('et_customer.branch_id', $branch_id)
            // ->where('et_customer.status', 0)
            // ->where('et_lead.created_by', $staff->sno)
            // ->whereYear('et_customer.created_at', $year)
            // ->whereMonth('et_customer.created_at', $month)
            // ->count();
            
            
            $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal.created_by', $staff->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
           
            // return $customerConvertData;
            
            $customerConvertCount =count($customerConvertData);
        
            $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.spam_verified',1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 7)->count();

            $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.drop_verified', 1)
                ->where('et_lead.branch_id', $branch_id)
                ->where('et_lead.status', 5)->count();

            // Spam Ratio 
            $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio>100 ? 100:$spam_lead_ratio, 2);

            // Dead ratio
            $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio>100 ? 100:$dead_lead_ratio, 2);

            // customer ratio
            $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            //acr
            $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
            $averager_convertion_rate =  number_format($averager_convertion_rate>100 ? 100:$averager_convertion_rate, 2);
          
            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            
            $base_amount_paid = 0; // keep track of GST-excluded total

            $gst_percent = 18;


            if ($customerConvertCount > 0) {
                

                $currentMonthCustomer=$customerConvertData;
                if ($currentMonthCustomer->isNotEmpty()) {
                    foreach ($currentMonthCustomer as $customer) {
                        $proposal_ids = DB::table('et_proposal')
                            ->where('et_proposal.customer_id', $customer->sno)
                            ->where('et_proposal.status', 0)
                            ->where('et_proposal.post_sale_check', 1)
                            ->whereYear('et_proposal.estimate_date', $year)
                            ->whereMonth('et_proposal.estimate_date', $month)
                            ->whereNotIn('et_proposal.proposal_status', [0, 2])
                            ->pluck('sno')
                            ->toArray();
                    
                        $proposals = DB::table('et_proposal')
                            ->select('et_proposal.*', 'et_country_currencies.currency_code')
                            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                            ->whereIn('et_proposal.sno', $proposal_ids)
                            ->get();
                
                        foreach ($proposals as $proposal) {
                            // Paid slots for this proposal
                            $paidAmount = DB::table('et_proposal_pay_slot')
                                ->where('proposal_sno', $proposal->sno)
                                ->where('status', 0)
                                ->sum('paidAmount');
                
                            $grantAmount = $proposal->grant_total_amount;
                
                            // First remove GST from paidAmount (base value in proposal's currency)
                            $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                
                            if ($proposal->currency_id == 70) {
                                // INR: add directly
                                $total_paid_payment += $paidAmount;
                                $total_payment += $grantAmount;
                                $base_amount_paid += $basePaidLocal;
                            } else {
                                // Non-INR: convert both amounts and base value
                                $currency_code = $proposal->currency_code;
                                $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                            }
                        }
                    }
                }
                
                // Averages
                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;

                $totalAllPayment +=$total_payment;
                $totalAllPaidPayment +=$base_amount_paid;
            }

            $staff->allLeadCount           = $allLeadCount;
            $staff->monthLeadCount       = $monthLeadCount;
            $staff->hotLeadCount        = $hotLeadCount;
            $staff->customerConvertCount      = $customerConvertCount;
            $staff->spamLeadCount            = $spamLeadCount;
            $staff->deadLeadCount      = $deadLeadCount;
            $staff->spam_lead_ratio            = $spam_lead_ratio;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->convertion_rate   = $convertion_rate;
            $staff->averager_convertion_rate   = $averager_convertion_rate;
            $staff->averageBusinessValue = $averageBusinessValue;
            $staff->averageCollectionValue    = $averageCollectionValue;

            // total cal
            $totalAllLead             += $allLeadCount;
            $totalMonthLead            += $monthLeadCount;
            $totalHotLead        += $hotLeadCount;
            $totalconvertCustomer            += $customerConvertCount;
            $totalSpamLead      += $spamLeadCount;
            $totalDeadLead    += $deadLeadCount;


        }

        // Calculate total ratio
        // Spam Ratio 
        $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
        $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);

        // Dead ratio
        $totalDeadLeadRatio      = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
        $totalDeadLeadRatio      = number_format($totalDeadLeadRatio, 2);

        // customer ratio
        $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
        $totalconvertRatio = number_format($totalconvertRatio, 2);

        //acr
        $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
        $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

        $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
        $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.team_management.team_lead_post', [
            'salesStaff'       => $salesStaff,
            'totalAverageBusinessValue'       => $totalAverageBusinessValue,
            'totalAverageCollectionValue'       => $totalAverageCollectionValue,
            'totalAverageconvertRatio'       => $totalAverageconvertRatio,
            'totalconvertRatio'       => $totalconvertRatio,
            'totalDeadLeadRatio'       => $totalDeadLeadRatio,
            'totalSpamLeadRatio'       => $totalSpamLeadRatio,
            'totalDeadLead'       => $totalDeadLead,
            'totalSpamLead'       => $totalSpamLead,
            'totalHotLead'       => $totalHotLead,
            'totalconvertCustomer'       => $totalconvertCustomer,
            'totalMonthLead'       => $totalMonthLead,
            'totalAllLead'       => $totalAllLead,
            'month_chk'        => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
            'month_filter' => $month_filter,

        ]);
    }
    
   public function getStaffLocations($id, Request $request)
{
    $today = Carbon::now()->toDateString();

    // Fetch single staff by ID
    $staff = DB::table('et_cug_management')
        ->whereNotNull('staff_mobile')
        ->where('staff_id', $id)
        ->first();

    $locations = [];

    if ($staff) {
        // Get all call_tracker entries for the staff's mobile for today
        
        $phoneWithCountryCode = '+91' . $staff->staff_mobile;
        $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $staff->staff_mobile);
        $calls = DB::table('et_call_tracker')
        ->where(function ($query) use ($phoneWithCountryCode, $phoneWithoutCountryCode) {
            $query->where('staff_phone_no', $phoneWithCountryCode)
                  ->orWhere('staff_phone_no', $phoneWithoutCountryCode);
        })
        ->whereDate('call_start_date', $today)
        ->orderByDesc('call_start_date')
        ->get();


        foreach ($calls as $call) {
            $cal_time = date('H:i A',strtotime($call->call_start_time ));
            if ($call->latitude && $call->longitude) {
                $locations[] = [
                    'lat'   => (float) $call->latitude,
                    'lng'   => (float) $call->longitude,
                    'label' => $call->customer_name . ' (' . $call->customer_phone_no . ')'. ' (' . $cal_time . ')',
                ];
            }
        }
    }

    return response()->json($locations);
}


    // Team Follow Up
    public function TeamFollowup(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id ?? 1;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 50);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }
        
         $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;

      

        $lead_fill = $request->input('lead_fill', '');

        // $salesStaff = DB::table('et_staff')
        //     ->select('et_staff.sno', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_staff.lead_bank_count')
        //     ->where('et_staff.status', 0)
        //     ->where('et_staff.department_id', 1)
        //     ->where('et_staff.branch_id', $branch_id);
         $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $year)
                            ->whereMonth('et_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $year)
                            ->whereMonth('et_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('et_staff.status', 0);
            });
        

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $totalStaff=$salesStaff->count();

        $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);

        $totalSuccessRate=0;
        $totalFailureRate=0;

        $totalAllFollowup=0;
        $totalMonthCount=0;
        $totalCompleted=0;
        $totalRescheduleFollowupCount=0;
        $totalPendingFollowupCount=0;
        $totalAverageFollowup=0;

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        if ($currentDate->year == $year && $currentDate->month == $month) {
            $endDate = $currentDate;
        } else {
            $endDate = $startDate->copy()->endOfMonth();
        }
        $dayCount = $startDate->diffInDays($endDate) + 1;

        foreach ($salesStaff as $staff) {

            $allFollowupCount = DB::table('et_appointment')
                ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                ->whereIn('et_lead.status', [0,4])
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.created_by', $staff->sno)
                ->count();

            $monthFollowupCount = DB::table('et_appointment')
                ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
               ->whereIn('et_lead.status', [0,4])
                ->where('et_appointment.created_by', $staff->sno)
                ->whereYear('et_appointment.appointment_date', $year)
                ->whereMonth('et_appointment.appointment_date', $month)
                ->count();

              
            $completedFollowupCount = DB::table('et_appointment')
                ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_appointment.status', 4)
                ->whereNotIn('et_lead.status', [2, 5, 6,7])
                ->where('et_appointment.created_by', $staff->sno)
                ->whereYear('et_appointment.appointment_date', $year)
                ->whereMonth('et_appointment.appointment_date', $month)
                ->where('et_appointment.branch_id', $branch_id)->count();
            $rescheduleFollowupCount = DB::table('et_appointment')
                ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)
                ->whereNotIn('et_lead.status', [2, 5, 6,7])
                ->where('et_appointment.created_by', $staff->sno)
                ->where('et_appointment.branch_id', $branch_id)
                ->whereYear('et_appointment.appointment_date', $year)
                ->whereMonth('et_appointment.appointment_date', $month)
                ->count();
            $pendingFollowupCount = DB::table('et_appointment')
                ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                // ->where('et_appointment.progressed', null)
                ->where('et_appointment.status', 1)
               ->whereNotIn('et_lead.status', [2, 5, 6,7])
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.created_by', $staff->sno)
                ->whereYear('et_appointment.appointment_date', $year)
                ->whereMonth('et_appointment.appointment_date', $month)
                ->where('et_appointment.appointment_date', '<=', now()->format('Y-m-d'))
                ->where('et_appointment.appointment_time', '<=', now()->format('H:i'))     
                ->count();

                $successAppointmentRate=0;
                $failAppointmentRate=0;
    
                $successFollowupRate=$monthFollowupCount>0 ? ($completedFollowupCount/$monthFollowupCount)*100 : 0;
                $failFollowupRate=$monthFollowupCount>0 ? ($rescheduleFollowupCount/$monthFollowupCount)*100 : 0;
                $average_followup_rate=$dayCount>0 ? $monthFollowupCount/$dayCount : 0;                       
    
    

            $staff->allFollowupCount     = $allFollowupCount;
            $staff->monthFollowupCount      = $monthFollowupCount;
            $staff->completedFollowupCount   = $completedFollowupCount;
            $staff->rescheduleFollowupCount    = $rescheduleFollowupCount;
            $staff->pendingFollowupCount        = $pendingFollowupCount;
            $staff->successFollowupRate = $successFollowupRate;
            $staff->failFollowupRate = $failFollowupRate;
            $staff->average_followup_rate = $average_followup_rate;

            $totalAllFollowup+=$allFollowupCount;
            $totalMonthCount+=$monthFollowupCount;
            $totalCompleted+=$completedFollowupCount;
            $totalRescheduleFollowupCount+=$rescheduleFollowupCount;
            $totalPendingFollowupCount+=$pendingFollowupCount;
         
        }
        $totalSuccess=$totalMonthCount>0 ? ($totalCompleted/$totalMonthCount)*100 : 0;
        $totalFailure=$totalMonthCount>0 ? ($totalRescheduleFollowupCount/$totalMonthCount)*100 : 0;
        $totalAverageFollowup=$dayCount>0 ? $totalMonthCount/$dayCount : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.team_management.team_followup', [
            'salesStaff'       => $salesStaff,
            'totalSuccess'       => $totalSuccess,
            'totalStaff'       => $totalStaff,
            'totalFailure'       => $totalFailure,
            'totalAllFollowup'       => $totalAllFollowup,
            'totalMonthCount'       => $totalMonthCount,
            'totalCompleted'       => $totalCompleted,
            'totalRescheduleFollowupCount'       => $totalRescheduleFollowupCount,
            'totalPendingFollowupCount'       => $totalPendingFollowupCount,
            'dayCount'       => $dayCount,
            'totalAverageFollowup'       => $totalAverageFollowup,
            'month_chk'        => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
            'month_filter' => $month_filter,
        ]);
    }

    // Team Appointment
    public function TeamAppointment(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id ?? 1;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 50);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }
         $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;


        $lead_fill = $request->input('lead_fill', '');

        // $salesStaff = DB::table('et_staff')
        //     ->select('et_staff.sno', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_staff.lead_bank_count')
        //     ->where('et_staff.status', 0)
        //     ->where('et_staff.department_id', 1)
        //     ->where('et_staff.branch_id', $branch_id);
        
         $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->where(function($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $year)
                            ->whereMonth('et_staff.notice_end_date', '>=', $month);
                    })
                    // Add conditions for status 5
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $year)
                            ->whereMonth('et_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function($query) use ($year, $month) {
                        $query->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('et_staff.status', 0);
            });
        

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $totalStaff= $salesStaff->count();
        $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);
        $totalSuccessRate=0;
        $totalFailureRate=0;

        $totalAllCount=0;
        $totalMonthCount=0;
        $totalCompleted=0;
        $totalcancelled=0;
        $totalPending=0;
        $totalAverageAppointment=0;

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        if ($currentDate->year == $year && $currentDate->month == $month) {
            $endDate = $currentDate;
        } else {
            $endDate = $startDate->copy()->endOfMonth();
        }
        $dayCount = $startDate->diffInDays($endDate) + 1;

        foreach ($salesStaff as $staff) {

            $allAppointmentCount = DB::table('et_lead_appointment')->select('et_lead_appointment.sno')
                ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_lead_appointment.status', 0)
                ->whereIn('et_lead.status', [0,4])
                ->where('et_lead_appointment.branch_id', $branch_id)
                ->where('et_lead_appointment.staff_id', $staff->sno)
                ->count();

            $monthAppointmentCount = DB::table('et_lead_appointment')->select('et_lead_appointment.sno')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.status', 0)
            ->whereIn('et_lead.status', [0,4])
                ->where('et_lead_appointment.branch_id', $branch_id)
                   ->where('et_lead_appointment.staff_id', $staff->sno)
                ->whereYear('et_lead_appointment.appointment_date', $year)
                ->whereMonth('et_lead_appointment.appointment_date', $month)
                ->count();

            $completedAppointementCount = DB::table('et_lead_appointment')->select('et_lead_appointment.sno')
                ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_lead_appointment.appointment_status', 2)
                ->where('et_lead_appointment.status', 0)
                ->whereIn('et_lead.status', [0,4])
                   ->where('et_lead_appointment.staff_id', $staff->sno)
                ->where('et_lead_appointment.branch_id', $branch_id)
                ->whereYear('et_lead_appointment.appointment_date', $year)
                ->whereMonth('et_lead_appointment.appointment_date', $month)
                ->count();
                $pendingAppointmentCount = DB::table('et_lead_appointment')->select('et_lead_appointment.sno')
                ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_lead_appointment.appointment_status', 1)
                ->where('et_lead_appointment.status', 0)
                ->whereIn('et_lead.status', [0,4])
                   ->where('et_lead_appointment.staff_id', $staff->sno)
                ->where('et_lead_appointment.branch_id', $branch_id)
                ->whereYear('et_lead_appointment.appointment_date', $year)
                ->whereMonth('et_lead_appointment.appointment_date', $month)
                ->where('et_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now())
                ->count();
            $cancelledAppointmentCount = DB::table('et_lead_appointment')->select('et_lead_appointment.sno')
                ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                ->where('et_lead_appointment.appointment_status', 3)
                ->where('et_lead_appointment.status', 0)
                ->whereIn('et_lead.status', [0,4])
                ->where('et_lead_appointment.branch_id', $branch_id)
                 ->where('et_lead_appointment.staff_id', $staff->sno)
                ->whereYear('et_lead_appointment.appointment_date', $year)
                ->whereMonth('et_lead_appointment.appointment_date', $month)
                ->count();

                $successAppointmentRate=0;
                $failAppointmentRate=0;

                $average_Appointment_rate=$dayCount>0 ? $monthAppointmentCount/$dayCount : 0;

               

                $successAppointmentRate=$monthAppointmentCount>0 ? ($completedAppointementCount/$monthAppointmentCount)*100 : 0;
                $failAppointmentRate=$monthAppointmentCount>0 ? ($cancelledAppointmentCount/$monthAppointmentCount)*100 : 0;


                $staff->allAppointmentCount     = $allAppointmentCount;
                $staff->monthAppointmentCount      = $monthAppointmentCount;
                $staff->completedAppointementCount   = $completedAppointementCount;
                $staff->pendingAppointmentCount    = $pendingAppointmentCount;
                $staff->cancelledAppointmentCount        = $cancelledAppointmentCount;
                $staff->successAppointmentRate = $successAppointmentRate;
                $staff->failAppointmentRate = $failAppointmentRate;
                $staff->average_Appointment_rate = $average_Appointment_rate;

            $totalAllCount+=$allAppointmentCount;
            $totalMonthCount+=$monthAppointmentCount;
            $totalCompleted+=$completedAppointementCount;
            $totalcancelled+=$cancelledAppointmentCount;
            $totalPending+=$pendingAppointmentCount;
         
            
            // $totalSuccessRate+=$successAppointmentRate;
            // $totalFailureRate+=$failAppointmentRate;
            
        }

                $totalSuccess=$totalMonthCount>0 ? ($totalCompleted/$totalMonthCount)*100 : 0;
                $totalFailure=$totalMonthCount>0 ? ($totalcancelled/$totalMonthCount)*100 : 0;
                $totalAverageAppointment=$dayCount>0 ? $totalMonthCount/$dayCount : 0;

        // $totalSuccess=$totalStaffCount>0 ? $totalSuccessRate/$totalStaffCount : 0;
        // $totalFailure=$totalStaffCount>0 ? $totalFailureRate/$totalStaffCount : 0;

        // return $salesStaff;
        return view('content.team_management.team_appointment', [
            'salesStaff'       => $salesStaff,
            'totalStaff'       => $totalStaff,
            'totalAllCount'       => $totalAllCount,
            'totalMonthCount'       => $totalMonthCount,
            'totalCompleted'       => $totalCompleted,
            'totalcancelled'       => $totalcancelled,
            'totalPending'       => $totalPending,
            'totalSuccess'       => $totalSuccess,
            'totalFailure'       => $totalFailure,
            'dayCount'       => $dayCount,
            'totalAverageAppointment'       => $totalAverageAppointment,
            'month_chk'        => $month_chk,
            'perpage'          => $perpage,
            'lead_fill'        => $lead_fill,
            'month_filter' => $month_filter,
        ]);
    }


    public function TeamCall(Request $request, $month = null, $year = null)
    {

        // $startTime = microtime(true);
        $branch_id = $request->user()->branch_id ?? 1;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 50);
        $offset = ($page - 1) * $perpage;

        $year = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        
        $lead_fill = $request->input('lead_fill', '');
        $department_fill = $request->input('department_fill', '');
        $staff_fill = $request->input('staff_fill', '');
        
         $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;

        // Fetch staff data efficiently
        // $salesStaff = DB::table('et_staff')
        //     ->select('sno', 'staff_name', 'staff_image', 'gender', 'mobile_no', 'lead_bank_count')
        //     ->where('status', 0)
        //     ->where('department_id', 1)
        //     ->where('branch_id', $branch_id);
        
        $salesStaff = DB::table('et_staff')
                ->select(
                    'et_staff.sno',
                    'et_staff.staff_name',
                    'et_staff.staff_image',
                    'et_staff.gender',
                    'et_staff.mobile_no',
                    'et_department.department_name',
                    'et_job_position.job_position_name',
                    'et_staff.lead_bank_count',
                    'et_staff.status as staff_status',
                    'et_cug_management.staff_mobile as cug_mobile'
                )
                ->join('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
                ->join('et_department','et_staff.department_id', '=', 'et_department.sno')
                ->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->where(function($query) use ($year, $month) {
                    // Add conditions for status 4
                    $query->where(function($query) use ($year, $month) {
                            $query->where('et_staff.status', 4)
                                ->whereYear('et_staff.notice_end_date', '>=', $year)
                                ->whereMonth('et_staff.notice_end_date', '>=', $month);
                        })
                        // Add conditions for status 5
                        ->orWhere(function($query) use ($year, $month) {
                            $query->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $year)
                                ->whereMonth('et_staff.updated_at', '>=', $month);
                        })
                        // Add conditions for status 6
                        ->orWhere(function($query) use ($year, $month) {
                            $query->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $year)
                                ->whereMonth('et_staff.staff_last_date', '>=', $month);
                        })
                        // Add conditions for status 7
                        ->orWhere(function($query) use ($year, $month) {
                            $query->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $year)
                                ->whereMonth('et_staff.updated_at', '>=', $month);
                        })
                        // Include status 0 regardless of date
                        ->orWhere('et_staff.status', 0);
                });
            

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        
        if ($department_fill != '') {
            $salesStaff->where('et_staff.department_id', $department_fill);
        }
        if ($staff_fill != '') {
            $salesStaff->where('et_staff.sno', $staff_fill);
        }

        $salesStaff = $salesStaff->orderBy('sno', 'desc')->paginate($perpage);

        // Date range calculation
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
                    ? $currentDate 
                    : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
$startTime = microtime(true);
        // Fetch all call stats in ONE query to prevent N+1 queries
        $callData = DB::table('et_call_tracker')
            ->select(
                'branch_staff_id',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count")
                
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray()) // Fetch only relevant staff
            ->groupBy('branch_staff_id')
            ->get()
            ->keyBy('branch_staff_id'); // Index by staff ID for fast lookup

        // Initialize total counts
        $total_incoming_call_count = 0;
        $total_outgoingcall_count = 0;
        $total_missedcall_count = 0;
        $total_rejected_call_count = 0;
        $total_unknown_count = 0;
        $total_dialedcall_count = 0;

        // Assign call data to staff
        foreach ($salesStaff as $staff) {
            $data = $callData[$staff->sno] ?? (object) [
                'incoming_call_count' => 0,
                'outgoingcall_count' => 0,
                'missedcall_count' => 0,
                'rejected_call_count' => 0,
                'dialedcall_count' => 0,
            ];

            $staff->incoming_call_count = $data->incoming_call_count;
            $staff->outgoingcall_count = $data->outgoingcall_count;
            $staff->missedcall_count = $data->missedcall_count;
            $staff->rejected_call_count = $data->rejected_call_count;
            $staff->dialedcall_count = $data->dialedcall_count;

            // Ratios
            $staff->outgoing_call_ratio = $dayCount > 0 ? round($data->outgoingcall_count / $dayCount) : 0;
            $staff->incoming_call_ratio = $dayCount > 0 ? round($data->incoming_call_count / $dayCount) : 0;
            $staff->missed_call_rate = $dayCount > 0 ? round($data->missedcall_count / $dayCount) : 0;

            // Missed call ratio
            $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
            $staff->missed_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

            // Update total counters
            $total_incoming_call_count += $data->incoming_call_count;
            $total_outgoingcall_count += $data->outgoingcall_count;
            $total_missedcall_count += $data->missedcall_count;
            $total_rejected_call_count += $data->rejected_call_count;
            $total_dialedcall_count += $data->dialedcall_count;
        }

        // Compute overall ratios
        $total_staff = count($salesStaff) ?? 0;
        $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_outgoingcall_count / ($total_staff * $dayCount)) : 0;
        $total_incoming_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_incoming_call_count / ($total_staff * $dayCount)) : 0;
        $total_missed_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_missedcall_count / ($total_staff * $dayCount)) : 0;
            
        // $total_outgoing_call_ratio = $dayCount > 0 ? round($total_outgoingcall_count / $dayCount) : 0;
        // $total_incoming_call_ratio = $dayCount > 0 ? round($total_incoming_call_count / $dayCount) : 0;
        // $total_missed_call_ratio   = $dayCount > 0 ? round($total_missedcall_count / $dayCount) : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // $endTime       = microtime(true);
        //     $executionTime = $endTime - $startTime;

        //     return($executionTime);
        
        $department_list = DB::table('et_department')
            ->where('et_department.status', 0)
            ->where('et_department.branch_id', $branch_id)
            ->get();
            
            $staff_list = DB::table('et_cug_management')
            ->select('et_cug_management.staff_id', 'et_staff.staff_name', 'et_department.department_name','et_job_position.job_position_name')
            ->join('et_staff', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->distinct()
            ->where('et_staff.status', 0)
            ->get();
        

        return view('content.team_management.team_call', [
            'salesStaff' => $salesStaff,
            'total_incoming_call_count' => $total_incoming_call_count,
            'total_outgoingcall_count' => $total_outgoingcall_count,
            'total_missedcall_count' => $total_missedcall_count,
            'total_rejected_call_count' => $total_rejected_call_count,
            'total_unknown_count' => $total_unknown_count,
            'total_unknown_count' => $total_unknown_count,
            'total_dialedcall_count' => $total_dialedcall_count,
            'total_outgoing_call_ratio' => $total_outgoing_call_ratio,
            'total_incoming_call_ratio' => $total_incoming_call_ratio,
            'total_missed_call_ratio' => $total_missed_call_ratio,
            'dayCount' => $dayCount,
            'month_chk' => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage' => $perpage,
            'lead_fill' => $lead_fill,
            'month' => $month,
            'year' => $year,
            'month_filter' => $month_filter,
            'staff_fill' => $staff_fill,
            'department_fill' => $department_fill,
            'staff_list' => $staff_list,
            'department_list' => $department_list,
        ]);
    }
   

    public function TeamCloudCall(Request $request, $month = null, $year = null)
    {
        $startTime = microtime(true);
        $branch_id = $request->user()->branch_id ?? 1;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 50);
        $offset = ($page - 1) * $perpage;

        $year = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        $lead_fill = $request->input('lead_fill', '');
        
         $month_filter = $request->get('month_filter', date('M-Y'));
         $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;


        // // Fetch staff data efficiently
        // $salesStaff = DB::table('et_staff')
        //     ->select('sno', 'staff_name', 'staff_image', 'gender', 'mobile_no', 'lead_bank_count')
        //                 ->where('branch_id', $branch_id);

        // if ($lead_fill != '') {
        //     $salesStaff->where(function ($query) use ($lead_fill) {
        //         $query->where('staff_name', 'LIKE', "%{$lead_fill}%")
        //             ->orWhere('nick_name', 'LIKE', "%{$lead_fill}%")
        //             ->orWhere('mobile_no', 'LIKE', "%{$lead_fill}%")
        //             ->orWhere('email_id', 'LIKE', "%{$lead_fill}%");
        //     });
        // }

        // $salesStaff = $salesStaff->orderBy('sno', 'desc')->paginate($perpage);

        // Date range calculation
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) 
                    ? $currentDate 
                    : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $salesStaff = DB::table('et_cug_management')
            ->select('et_cug_management.staff_id','et_staff.sno', 'et_staff.staff_name','et_staff.mobile_no', 'et_staff.staff_image', 'et_staff.gender', 'et_cug_management.staff_mobile', 'et_department.department_name')
            ->join('et_staff', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->leftJoin('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->distinct('et_cug_management.staff_id')
            ->where('et_staff.status', '!=', 2)
            ->where('et_staff.branch_id',$branch_id)
            ->where('et_department.sno', 1);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_cug_management.staff_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('et_cug_management.sno', 'desc')->paginate($perpage);

        $staffMobiles = $salesStaff->pluck('staff_mobile')->toArray();


            // $callData = DB::table('et_cloud_call')
            //     ->select(
            //         DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$.received_by[0].contact_number_raw') ) as contact_number_raw"),
            //         DB::raw("SUM(CASE WHEN action = 'received' THEN 1 ELSE 0 END) AS received_call_count"),
            //         DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
            //     )
            //     ->whereYear('start_time', $year)
            //     ->whereMonth('start_time', $month)
            //     ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$.received_by[0].contact_number_raw') )"), $staffMobiles) // Use $staffMobiles array here
            //     ->groupBy(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$.received_by[0].contact_number_raw') )"))
            //     ->get()
            //     ->keyBy('contact_number_raw'); // Key by contact_number_raw


            // $callData = DB::table('et_cloud_call')
            // ->select(
            //     DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw')) AS contact_number_raw"),
            //     DB::raw("SUM(CASE WHEN action = 'received' THEN 1 ELSE 0 END) AS received_call_count"),
            //     DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
            // )
            // ->whereYear('start_time', $year)
            // ->whereMonth('start_time', $month)
            // ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))") // Make sure we filter out null results
            // ->groupBy(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"))
            // ->get()
            // ->keyBy('contact_number_raw');

            $callData = DB::table('et_cloud_call')
                ->select(
                    DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw')) AS contact_number_raw"),
                    DB::raw("SUM(CASE WHEN action = 'received' THEN 1 ELSE 0 END) AS received_call_count"),
                    DB::raw("SUM(CASE WHEN action = 'missed' THEN 1 ELSE 0 END) AS missed_call_count")
                )
                ->whereYear('start_time', $year)
                ->whereMonth('start_time', $month)
                ->whereNotNull(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))")) // Ensure no NULL values
                ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"), $staffMobiles) // Filtering by staff mobiles
                ->groupBy(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(log_details, '$[0].received_by[0].contact_number_raw'))"))
                ->get()
                ->keyBy('contact_number_raw');


                $unattend_count = DB::table('et_cloud_call')
                ->whereYear('start_time', $year)
                ->whereMonth('start_time', $month)
                ->whereNull('action') // Correct way to check NULL in Laravel
                ->where('status', 2)
                ->where('branch_id',$branch_id)
                ->whereNotExists(function ($query) {
                    $query->select(DB::raw(1))
                        ->from('et_lead')
                        ->whereRaw("RIGHT(et_cloud_call.caller_number, 10) = et_lead.lead_mobile");
                })
                ->count();
        

        // return $callData;

        // Initialize total counts
        $total_received_call_count = 0;
        $total_missed_call_count = 0;
        $total_staff_call_count = 0;
        $total_received_call_rate = 0;
        $total_missed_call_rate = 0;

        // Assign call data to staff
        foreach ($salesStaff as $staff) {
            $data = $callData[$staff->staff_mobile] ?? (object) [
                'received_call_count' => 0,
                'missed_call_count' => 0,
            ];
        
            $staff_total_calls=($data->received_call_count + $data->missed_call_count);
            $staff->month_total_call_count = $staff_total_calls;
            $staff->received_call_count = $data->received_call_count;
            $staff->missed_call_count = $data->missed_call_count;
            $staff->missed_call_ratio = 0;
            $staff->received_call_ratio = 0;
            $staff->missed_call_rate = 0;
            $staff->received_call_rate = 0;

            // Answer Rate = (Received Calls / Total Calls) * 100
            // Missed Call Rate = (Missed Calls / Total Calls) * 100
            $staff->missed_call_rate = $staff_total_calls > 0 ? ($data->missed_call_count / $staff_total_calls)*100 : 0;
            $staff->received_call_rate =  $staff_total_calls > 0 ? ($data->received_call_count / $staff_total_calls)*100 : 0;
            // $staff->missed_call_rate = $dayCount > 0 ? $data->missedcall_count / $dayCount : 0;

            // // Missed call ratio
            // $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
            // $staff->missed_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

            // Update total counters
            $total_received_call_count += $data->received_call_count;
            $total_missed_call_count += $data->missed_call_count;
            $total_staff_call_count += $staff_total_calls;
        }
        // return $salesStaff;
        // Compute overall ratios
        // $total_outgoing_call_ratio = $dayCount > 0 ? $total_outgoingcall_count / $dayCount : 0;
        $total_received_call_rate =  $total_staff_call_count > 0 ? ($total_received_call_count/ $total_staff_call_count)*100 : 0;
        $total_missed_call_rate =  $total_staff_call_count > 0 ? ($total_missed_call_count / $total_staff_call_count)*100 : 0;

        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        $endTime       = microtime(true);
        $executionTime = $endTime - $startTime;

        return view('content.team_management.team_cloud_call', [
            'salesStaff' => $salesStaff,
            'unattend_count' => $unattend_count,
            'total_received_call_count' => $total_received_call_count,
            'total_missed_call_count' => $total_missed_call_count,
            'total_received_call_rate' => $total_received_call_rate,
            'total_missed_call_rate' => $total_missed_call_rate,
            'total_staff_call_count' => $total_staff_call_count,
            'dayCount' => $dayCount,
            'month_chk' => $month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage' => $perpage,
            'lead_fill' => $lead_fill,
            'year' => $year,
            'month' => $month,
            'month_filter' => $month_filter,
        ]);
    }
    public function leadLimitSet($id, Request $request)
    {
        $user_id = $request->user()->user_id;
        $staff   = StaffModel::where('sno', $id)->first();
        $helper  = new \App\Helpers\Helpers();

        if ($staff) {
            $staff->lead_bank_count = $request->lead_count;
            $staff->updated_by      = $user_id;
            $staff->update();
            if ($staff->update()) {
                return response([
                    'status'    => 200,
                    'message'   => 'Successfully Limit Set!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);

            }
        }
        return response([
            'status'    => 200,
            'message'   => 'Successfully Limit Set!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
 

}