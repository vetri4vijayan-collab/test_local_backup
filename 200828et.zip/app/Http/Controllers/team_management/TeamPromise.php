<?php

namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\DefaultGoalSetModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\CustomerModel;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
class TeamPromise extends Controller
{


   public function index(Request $request, $day = null, $month = null, $year = null)
    {
      $branch_id = $request->user()->branch_id;
      $page      = $request->input('page', 1);
      $perpage   = (int) $request->input('sorting_filter', 10);
      $offset    = ($page - 1) * $perpage;

      $year  = $request->get('year', $year ?? date('Y'));
      $month = $request->get('month', $month ?? date('m'));
      $day   = $request->get('day', $day ?? date('d'));

      if ($month . $year == date('mY') || $year > date('Y')) {
          $month_chk = 0;
      } else {
          $month_chk = 1;
      }
      if ($day . $month . $year == date('dmY') || $year > date('Y')) {
          $day_chk = 0; // Current or future day
      } else {
          $day_chk = 1; // Previous day
      }

      $lead_fill = $request->input('lead_fill', '');



       $salesStaff = DB::table('et_staff')
          ->select(
              'et_staff.sno',
              'et_staff.staff_name',
              'et_staff.staff_image',
              'et_staff.gender',
              'et_staff.mobile_no',
              // 'et_staff.lead_bank_count',
              'et_staff.status as staff_status',
              'et_job_position.job_position_name',
              'et_cug_management.staff_mobile as cug_mobile'
          )
          ->where('et_staff.department_id', 1)
          ->where('et_staff.role_id','!=', 12)
          ->where('et_cug_management.status',0)
           ->join('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
           ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
          ->where('et_staff.branch_id', $branch_id)
          ->where(function($query) use ($year, $month,$day) {
              // Add conditions for status 4
              $query->where(function($query) use ($year, $month,$day) {
                      $query->where('et_staff.status', 4)
                          ->whereYear('et_staff.notice_end_date', '>=', $year)
                           ->whereDay('et_staff.notice_end_date','>=', $day)
                          ->whereMonth('et_staff.notice_end_date', '>=', $month);
                  })
                  // Add conditions for status 5
                  ->orWhere(function($query) use ($year, $month,$day) {
                      $query->where('et_staff.status', 5)
                          ->whereYear('et_staff.updated_at', '>=', $year)
                           ->whereDay('et_staff.updated_at','>=', $day)
                          ->whereMonth('et_staff.updated_at', '>=', $month);
                  })
                  // Add conditions for status 6
                  ->orWhere(function($query) use ($year, $month,$day) {
                      $query->where('et_staff.status', 6)
                          ->whereYear('et_staff.staff_last_date', '>=', $year)
                          ->whereDay('et_staff.staff_last_date','>=', $day)
                          ->whereMonth('et_staff.staff_last_date', '>=', $month);
                  })
                  // Add conditions for status 7
                  ->orWhere(function($query) use ($year, $month,$day) {
                      $query->where('et_staff.status', 7)
                          ->whereYear('et_staff.updated_at', '>=', $year)
                          ->whereDay('et_staff.updated_at','>=', $day)
                          ->whereMonth('et_staff.updated_at', '>=', $month);
                  })
                  // Include status 0 regardless of date
                  ->orWhere('et_staff.status', 0);
          });

      if ($lead_fill != '') {
          $salesStaff->where(function ($query) use ($lead_fill) {
              $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
          });
      }
      $total_staff=$salesStaff->count();
      $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);


      $totalAverageBusinessValue = 0;
      $totalAverageCollectionValue     = 0;
      $totalAverageconvertRatio     = 0;
      $totalconvertRatio     = 0;
      $totalSpamLeadRatio     = 0;
      $totalDeadLeadRatio     = 0;
      $totalAllLead             = 0;
      $totalMonthLead            = 0;
      $totalconvertCustomer            = 0;
      $totalHotLead        = 0;
      $totalSpamLead      = 0;
      $totalDeadLead    = 0;

      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      foreach ($salesStaff as $staff) {

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.internal_status',0)
            ->count();

          $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
          ->where('et_lead.created_by', $staff->sno)
          ->where('et_lead.branch_id', $branch_id)
          ->whereYear('et_lead.registered_date', $year)
          ->whereMonth('et_lead.registered_date', $month)
        //   ->whereDay('et_lead.registered_date', $day) // Use `whereDay` instead of `whereDate`
          ->whereNotIn('et_lead.status',[2,6])
          ->where('et_lead.spam_verified',0)
          ->where('et_lead.internal_status',0)
          ->count();

          $PromiseCount = DB::table('et_sales_promise')->select('promise_count') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->whereDay('et_sales_promise.promise_date', $day) // Use `whereDay` instead of `whereDate`
        //   ->where('et_sales_promise.status',0)
          ->sum('promise_count');
            
            
          $customerConvertCount =  DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $staff->sno)
            ->whereYear('et_payment.transaction_date', $year)
             ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->count();


        //   $customerConvertCount = CustomerModel::select('et_customer.sno')
        //   ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //   ->where('et_customer.branch_id', $branch_id)
        //   ->where('et_lead.created_by', $staff->sno)
        //   ->whereYear('et_customer.created_at', $year)
        //   ->whereDay('et_customer.created_at', $day) // Use `whereDay` instead of `whereDate`
        //   ->whereMonth('et_customer.created_at', $month)
        //   ->count();
          
            $dateandtime = DB::table('et_sales_promise')
            ->select('failer_date_time') // Selecting failer_date_time instead of sno
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
             ->whereDay('promise_date', $day) // Use `whereDay` instead of `whereDate`
            ->where('status', 2)
            ->get();
            $promise_date = DB::table('et_sales_promise')
            ->select('promise_date') // Selecting promise_date
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
            ->whereDay('promise_date', $day - 1) // Use `whereDay` for the previous day
            ->where('status', 0)
            ->get();
            // dd($promise_date); 
          $reasondetails = DB::table('et_sales_promise')
            ->select('reason') // Selecting failer_date_time instead of sno
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
             ->whereDay('promise_date', $day) // Use `whereDay` instead of `whereDate`
            ->where('status', 2)
            ->get();
            
        $statuscount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->whereDay('et_sales_promise.promise_date', $day) // Use `whereDay` instead of `whereDate`
          ->sum('status');
          
          
          $successcount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->whereDay('et_sales_promise.promise_date', $day) // Use `whereDay` instead of `whereDate`
          ->where('status', 1)
          ->sum('status');
          
          $failedcount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->whereDay('et_sales_promise.promise_date', $day) // Use `whereDay` instead of `whereDate`
          ->where('status', 2)
          ->count();

          $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
          ->whereYear('et_lead.registered_date', $year)
          ->whereMonth('et_lead.registered_date', $month)
          ->where('et_lead.created_by', $staff->sno)
          ->where('et_lead.spam_verified',1)
          ->where('et_lead.branch_id', $branch_id)
          ->where('et_lead.status', 7)->count();

          $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.branch_id', $branch_id)
              ->where('et_lead.status', 5)->count();

          // Spam Ratio
          $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
          $spam_lead_ratio = number_format($spam_lead_ratio, 2);

          // Dead ratio
          $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
          $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

          // customer ratio
          $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
          $convertion_rate = number_format($convertion_rate, 2);

          //acr
          $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
          $averager_convertion_rate = number_format($averager_convertion_rate, 2);

          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
          $averageBusinessValue      = 0;
          $averageCollectionValue    = 0;

        

          if ($customerConvertCount > 0) {

              $currentMonthCustomer = CustomerModel::select('et_customer.sno')
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                  ->where('et_customer.branch_id', $branch_id)
                  ->where('et_lead.created_by', $staff->sno)
                  ->whereYear('et_customer.created_at', $year)
                  ->whereMonth('et_customer.created_at', $month)
                  ->get();

                  if ($currentMonthCustomer->isNotEmpty()) {
                    foreach ($currentMonthCustomer as $customer) {

                    //     $payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
                    //                 ->where('et_training.customer_id', $customer->sno)
                    //                 ->sum('et_training.overall_fees');

                    //   $total_payment += $payment;

                    //   $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
                    //                     ->where('et_training.customer_id', $customer->sno)
                    //                     ->sum('et_training.paid_amount');

                      $total_paid_payment += 0;

                    }

                }

              // average
              $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
              $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
              $totalAllPayment +=$total_payment;
              $totalAllPaidPayment +=$total_paid_payment;
          }

          $staff->allLeadCount           = $allLeadCount;
          $staff->monthLeadCount       = $monthLeadCount;
          $staff->PromiseCount        = $PromiseCount;
          $staff->promise_date        = $promise_date;
            $staff->dateandtime        = $dateandtime;
            $staff->reasondetails        = $reasondetails;
            $staff->statuscount        = $statuscount;
          $staff->customerConvertCount      = $customerConvertCount;
          $staff->spamLeadCount            = $spamLeadCount;
          $staff->deadLeadCount      = $deadLeadCount;
          $staff->spam_lead_ratio            = $spam_lead_ratio;
          $staff->dead_lead_ratio      = $dead_lead_ratio;
          $staff->convertion_rate   = $convertion_rate;
          $staff->averager_convertion_rate   = $averager_convertion_rate;
          $staff->averageBusinessValue = $averageBusinessValue;
          $staff->averageCollectionValue    = $averageCollectionValue;

          // total cal
          $totalAllLead             += $allLeadCount;
          $totalMonthLead            += $monthLeadCount;
          $totalHotLead        += $PromiseCount;
          $totalconvertCustomer            += $customerConvertCount;
          $totalSpamLead      += $successcount;
          $totalDeadLead    += $failedcount;


      }

      // Calculate total ratio
      // Spam Ratio
      $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
      $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);

      // Dead ratio
      $totalDeadLeadRatio      = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
      $totalDeadLeadRatio      = number_format($totalDeadLeadRatio, 2);

      // customer ratio
      $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
      $totalconvertRatio = number_format($totalconvertRatio, 2);

      //acr
      $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
      $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

      $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
      $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;


      // return $salesStaff;
      return view('content.team_management.team_promise.team_promise', [
          'salesStaff'       => $salesStaff,
          'totalAverageBusinessValue'       => $totalAverageBusinessValue,
          'totalAverageCollectionValue'       => $totalAverageCollectionValue,
          'totalAverageconvertRatio'       => $totalAverageconvertRatio,
          'totalconvertRatio'       => $totalconvertRatio,
          'totalDeadLeadRatio'       => $totalDeadLeadRatio,
          'totalSpamLeadRatio'       => $totalSpamLeadRatio,
          'totalDeadLead'       => $totalDeadLead,
          'totalSpamLead'       => $totalSpamLead,
          'totalHotLead'       => $totalHotLead,
          'totalconvertCustomer'       => $totalconvertCustomer,
          'totalMonthLead'       => $totalMonthLead,
          'totalAllLead'       => $totalAllLead,
          // 'month_chk'        => $month_chk,
          'day_chk'        => $day_chk,
          'perpage'          => $perpage,
          'lead_fill'        => $lead_fill,

      ]);
  }
   public function teamMonth(Request $request,$month = null, $year = null)
    {
      $branch_id = $request->user()->branch_id;
      $page      = $request->input('page', 1);
      $perpage   = (int) $request->input('sorting_filter', 10);
      $offset    = ($page - 1) * $perpage;

      $year  = $request->get('year', $year ?? date('Y'));
      $month = $request->get('month', $month ?? date('m'));
      $day   = $request->get('day', $day ?? date('d'));

      if ($month . $year == date('mY') || $year > date('Y')) {
          $month_chk = 0;
      } else {
          $month_chk = 1;
      }
     
      $lead_fill = $request->input('lead_fill', '');



       $salesStaff = DB::table('et_staff')
          ->select(
              'et_staff.sno',
              'et_staff.staff_name',
              'et_staff.staff_image',
              'et_staff.gender',
              'et_staff.mobile_no',
              // 'et_staff.lead_bank_count',
              'et_staff.status as staff_status',
              'et_job_position.job_position_name',
              'et_cug_management.staff_mobile as cug_mobile'
          )
          ->where('et_staff.department_id', 1)
          ->where('et_staff.role_id','!=', 12)
          ->where('et_cug_management.status',0)
           ->join('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
           ->leftJoin('et_cug_management','et_staff.sno', '=', 'et_cug_management.staff_id')
          ->where('et_staff.branch_id', $branch_id)
          ->where(function($query) use ($year, $month) {
              // Add conditions for status 4
              $query->where(function($query) use ($year, $month) {
                      $query->where('et_staff.status', 4)
                          ->whereYear('et_staff.notice_end_date', '>=', $year)
                          ->whereMonth('et_staff.notice_end_date', '>=', $month);
                  })
                  // Add conditions for status 5
                  ->orWhere(function($query) use ($year, $month) {
                      $query->where('et_staff.status', 5)
                          ->whereYear('et_staff.updated_at', '>=', $year)
                          ->whereMonth('et_staff.updated_at', '>=', $month);
                  })
                  // Add conditions for status 6
                  ->orWhere(function($query) use ($year, $month) {
                      $query->where('et_staff.status', 6)
                          ->whereYear('et_staff.staff_last_date', '>=', $year)
                          ->whereMonth('et_staff.staff_last_date', '>=', $month);
                  })
                  // Add conditions for status 7
                  ->orWhere(function($query) use ($year, $month) {
                      $query->where('et_staff.status', 7)
                          ->whereYear('et_staff.updated_at', '>=', $year)
                          ->whereMonth('et_staff.updated_at', '>=', $month);
                  })
                  // Include status 0 regardless of date
                  ->orWhere('et_staff.status', 0);
          });

      if ($lead_fill != '') {
          $salesStaff->where(function ($query) use ($lead_fill) {
              $query->where('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                  ->orWhere('et_staff.email_id', 'LIKE', "%{$lead_fill}%");
          });
      }
      $total_staff=$salesStaff->count();
      $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($perpage);


      $totalAverageBusinessValue = 0;
      $totalAverageCollectionValue     = 0;
      $totalAverageconvertRatio     = 0;
      $totalconvertRatio     = 0;
      $totalSpamLeadRatio     = 0;
      $totalDeadLeadRatio     = 0;
      $totalAllLead             = 0;
      $totalMonthLead            = 0;
      $totalconvertCustomer            = 0;
      $totalHotLead        = 0;
      $totalSpamLead      = 0;
      $totalDeadLead    = 0;

      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      foreach ($salesStaff as $staff) {

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereNotIn('et_lead.status',[2,6])
            ->where('et_lead.spam_verified',0)
            ->where('et_lead.internal_status',0)
            ->count();

          $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
          ->where('et_lead.created_by', $staff->sno)
          ->where('et_lead.branch_id', $branch_id)
          ->whereYear('et_lead.registered_date', $year)
          ->whereMonth('et_lead.registered_date', $month)
          ->whereNotIn('et_lead.status',[2,6])
          ->where('et_lead.spam_verified',0)
          ->where('et_lead.internal_status',0)
          ->count();

          $PromiseCount = DB::table('et_sales_promise')->select('promise_count') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
           //   ->where('et_sales_promise.status',0)
          ->sum('promise_count');
          
          // 🔧 PromiseData grouped by date, filtered by this staff
            $promiseData = DB::table('et_sales_promise')
                ->where('staff_id', $staff->sno)
                ->where('branch_id', $branch_id)
                ->whereYear('promise_date', $year)
                ->whereMonth('promise_date', $month)
                ->get()
                ->groupBy(function ($item) {
                    return Carbon::parse($item->promise_date)->format('Y-m-d');
                });
                
                
                // $customerConvertCount =  DB::table('et_customer')
                //     ->select('et_customer.sno', 'et_customer.proposal_ids')
                //     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                //     ->join('et_payment', function($join) {
                //         $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                //              ->whereRaw('et_payment.transaction_date = (
                //                  SELECT MIN(ep.transaction_date)
                //                  FROM et_payment ep
                //                  WHERE ep.customer_id = et_customer.sno
                //              )');
                //     })
                //     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                //     ->where('et_customer.status', 0)
                //     ->where('et_customer.branch_id', $branch_id)
                //     ->where('et_lead.created_by', $staff->sno)
                //     ->whereYear('et_payment.transaction_date', $year)
                //      ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
                //     ->whereMonth('et_payment.transaction_date', $month)
                //     ->where('et_transaction.payment_status', 1)
                //     ->orderBy('et_customer.sno', 'asc')
                //     ->count();
        
            // 🔧 Customer conversions grouped by date, filtered by this staff
            $customerConvertData = CustomerModel::select('et_customer.sno', 'et_payment.transaction_date as created_at')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by', $staff->sno) // 👈 this was missing
                 ->whereYear('et_payment.transaction_date', $year)
                     ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
                    ->whereMonth('et_payment.transaction_date', $month)
                ->get()
                ->groupBy(function ($item) {
                    return Carbon::parse($item->created_at)->format('Y-m-d');
                });
        
            $allDates = collect($promiseData->keys())
                ->merge($customerConvertData->keys())
                ->unique()
                ->sort();
        
            $chartData = [];
        
            foreach ($allDates as $date) {
                $promises = $promiseData[$date] ?? collect();
                $converts = $customerConvertData[$date] ?? collect();
        
                $chartData[] = [
                    'promise_date' => $date,
                    'promise' => $promises->count(),
                    'convert' => $converts->count()
                ];
            }
        
            // 👇 assign to the staff object
            $staff->promiseChartData = $chartData;
    

        //   $customerConvertCount = CustomerModel::select('et_customer.sno')
        //   ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //   ->where('et_customer.branch_id', $branch_id)
        //   ->where('et_lead.created_by', $staff->sno)
        //   ->whereYear('et_customer.created_at', $year)
        //   ->whereMonth('et_customer.created_at', $month)
        //   ->count();
          
          $customerConvertCount =  DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    // ->where('et_customer.status', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                     ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    // ->orderBy('et_customer.sno', 'asc')
                    ->count();
          
           $customerConvertCountdata = CustomerModel::select('et_customer.sno')
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $branch_id)
          ->where('et_lead.created_by', $staff->sno)
          ->whereYear('et_customer.created_at', $year)
          ->whereMonth('et_customer.created_at', $month)
          ->get();
        //   return $customerConvertCountdata;
          
            $dateandtime = DB::table('et_sales_promise')
            ->select('failer_date_time') // Selecting failer_date_time instead of sno
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
            ->where('status', 2)
            ->get();
            $promise_date = DB::table('et_sales_promise')
            ->select('promise_date') // Selecting promise_date
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
            ->whereDay('promise_date', $day - 1) // Use `whereDay` for the previous day
            ->where('status', 0)
            ->get();
            // dd($promise_date); 
          $reasondetails = DB::table('et_sales_promise')
            ->select('reason') // Selecting failer_date_time instead of sno
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
            ->where('status', 2)
            ->get();
            
        $statuscount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->sum('status');
          
          
          $successcount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->where('status', 1)
          ->sum('status');
          
          $failedcount = DB::table('et_sales_promise')->select('status') // Selecting failer_date_time instead of sno
          ->where('et_sales_promise.staff_id', $staff->sno)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->whereDay('et_sales_promise.promise_date', $day) // Use `whereDay` instead of `whereDate`
          ->where('status', 2)
          ->count();

          $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
          ->whereYear('et_lead.registered_date', $year)
          ->whereMonth('et_lead.registered_date', $month)
          ->where('et_lead.created_by', $staff->sno)
          ->where('et_lead.spam_verified',1)
          ->where('et_lead.branch_id', $branch_id)
          ->where('et_lead.status', 7)->count();

          $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.branch_id', $branch_id)
              ->where('et_lead.status', 5)->count();
              
        // $successcount = DB::table('et_sales_promise')->select('et_sales_promise.sno') // Selecting failer_date_time instead of sno
        //   ->where('et_sales_promise.staff_id', $staff->sno)
        //   ->where('et_sales_promise.branch_id', $branch_id)
        //   ->whereYear('et_sales_promise.promise_date', $year)
        //   ->whereMonth('et_sales_promise.promise_date', $month)
        //   ->where('status', 1)
        //   ->count();


          // promise success Ratio
          $success_ratio   = $successcount > 0 ? ($successcount / $PromiseCount) * 100 : 0;
          $success_ratio = number_format($success_ratio, 2);
          // Spam Ratio
          $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
          $spam_lead_ratio = number_format($spam_lead_ratio, 2);

          // Dead ratio
          $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
          $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

          // customer ratio
          $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
          $convertion_rate = number_format($convertion_rate, 2);

          //acr
          $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
          $averager_convertion_rate = number_format($averager_convertion_rate, 2);

          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
          $averageBusinessValue      = 0;
          $averageCollectionValue    = 0;

        

          if ($customerConvertCount > 0) {

              $currentMonthCustomer = CustomerModel::select('et_customer.sno')
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                  ->where('et_customer.branch_id', $branch_id)
                  ->where('et_lead.created_by', $staff->sno)
                  ->whereYear('et_customer.created_at', $year)
                  ->whereMonth('et_customer.created_at', $month)
                  ->get();

                  if ($currentMonthCustomer->isNotEmpty()) {
                    foreach ($currentMonthCustomer as $customer) {

                    //     $payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
                    //                 ->where('et_training.customer_id', $customer->sno)
                    //                 ->sum('et_training.overall_fees');

                    //   $total_payment += $payment;

                    //   $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
                    //                     ->where('et_training.customer_id', $customer->sno)
                    //                     ->sum('et_training.paid_amount');

                      $total_paid_payment += 0;

                    }

                }

              // average
              $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
              $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
              $totalAllPayment +=$total_payment;
              $totalAllPaidPayment +=$total_paid_payment;
          }
          
     
          $staff->allLeadCount           = $allLeadCount;
          $staff->monthLeadCount       = $monthLeadCount;
          $staff->PromiseCount        = $PromiseCount;
          $staff->promise_date        = $promise_date;
            $staff->dateandtime        = $dateandtime;
            $staff->reasondetails        = $reasondetails;
            $staff->statuscount        = $statuscount;
            $staff->successcount        = $successcount;
            $staff->success_ratio        = $success_ratio;
          $staff->customerConvertCount      = $customerConvertCount;
          $staff->spamLeadCount            = $spamLeadCount;
          $staff->deadLeadCount      = $deadLeadCount;
          $staff->spam_lead_ratio            = $spam_lead_ratio;
          $staff->dead_lead_ratio      = $dead_lead_ratio;
          $staff->convertion_rate   = $convertion_rate;
          $staff->averager_convertion_rate   = $averager_convertion_rate;
          $staff->averageBusinessValue = $averageBusinessValue;
          $staff->averageCollectionValue    = $averageCollectionValue;

          // total cal
          $totalAllLead             += $allLeadCount;
          $success_ratio             += $success_ratio;
          $totalMonthLead            += $monthLeadCount;
          $totalHotLead        += $PromiseCount;
          $totalconvertCustomer            += $customerConvertCount;
          $totalSpamLead      += $successcount;
          $totalDeadLead    += $failedcount;


      }

      // Calculate total ratio
      // Spam Ratio
      $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
      $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);
      
      // promise success Ratio
          $totalsuccessratio   = $totalSpamLead > 0 ? ($totalSpamLead / $totalHotLead) * 100 : 0;
          $totalsuccessratio = number_format($totalsuccessratio, 2);

      // Dead ratio
      $totalDeadLeadRatio      = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
      $totalDeadLeadRatio      = number_format($totalDeadLeadRatio, 2);

      // customer ratio
      $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
      $totalconvertRatio = number_format($totalconvertRatio, 2);

      //acr
      $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
      $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

      $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
      $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;


    //   return $salesStaff;
      return view('content.team_management.team_promise.team_promise_month', [
          'salesStaff'       => $salesStaff,
          'totalAverageBusinessValue'       => $totalAverageBusinessValue,
          'totalAverageCollectionValue'       => $totalAverageCollectionValue,
          'totalAverageconvertRatio'       => $totalAverageconvertRatio,
          'totalconvertRatio'       => $totalconvertRatio,
          'totalDeadLeadRatio'       => $totalDeadLeadRatio,
          'totalSpamLeadRatio'       => $totalSpamLeadRatio,
          'totalDeadLead'       => $totalDeadLead,
          'totalSpamLead'       => $totalSpamLead,
          'totalsuccessratio'       => $totalsuccessratio,
          'totalHotLead'       => $totalHotLead,
          'totalconvertCustomer'       => $totalconvertCustomer,
          'totalMonthLead'       => $totalMonthLead,
          'totalAllLead'       => $totalAllLead,
           'month_chk'        => $month_chk,
        //   'day_chk'        => $day_chk,
          'perpage'          => $perpage,
          'lead_fill'        => $lead_fill,

      ]);
  }
   // Fetch Departments based on Branch
   public function getDepartmentsGoal(Request $request)
    {
       $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
       return response()->json(['status' => 200, 'data' => $departments]);
   }
   
   public function staffpromiseList(Request $request)
   {
    $branch_id = $request->user()->branch_id;
    $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
    [$year, $month] = explode('-', $selectedMonth);
  

    $startOfMonth = \Carbon\Carbon::create($year, $month, 1);
    $endOfMonth = $startOfMonth->copy()->endOfMonth();

    $dates = [];
    while ($startOfMonth <= $endOfMonth) {
        $dates[] = $startOfMonth->toDateString();
        $startOfMonth->addDay();
    }

    $salesStaff = DB::table('et_staff')
        ->select(
            'et_staff.sno',
            'et_staff.staff_name',
            'et_staff.staff_image',
            'et_staff.gender',
            'et_staff.mobile_no',
            'et_staff.status as staff_status',
            'et_job_position.job_position_name'
        )
        ->where('et_staff.department_id', 1)
        ->where('et_staff.role_id', '!=', 12)
        ->where('et_staff.branch_id', $branch_id)
        ->join('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
        ->where(function ($query) use ($year, $month) {
            $query->where(function ($query) use ($year, $month) {
                $query->where('et_staff.status', 4)
                    ->whereYear('et_staff.notice_end_date', '>=', $year)
                    ->whereMonth('et_staff.notice_end_date', '>=', $month);
            })->orWhere(function ($query) use ($year, $month) {
                $query->where('et_staff.status', 5)
                    ->whereYear('et_staff.updated_at', '>=', $year)
                    ->whereMonth('et_staff.updated_at', '>=', $month);
            })->orWhere(function ($query) use ($year, $month) {
                $query->where('et_staff.status', 6)
                    ->whereYear('et_staff.staff_last_date', '>=', $year)
                    ->whereMonth('et_staff.staff_last_date', '>=', $month);
            })->orWhere(function ($query) use ($year, $month) {
                $query->where('et_staff.status', 7)
                    ->whereYear('et_staff.updated_at', '>=', $year)
                    ->whereMonth('et_staff.updated_at', '>=', $month);
            })->orWhere('et_staff.status', 0);
        })
        ->get();

    $staffData = [];

    foreach ($salesStaff as $staff) {


           // each staff Promises
          // 🔧 PromiseData grouped by date, filtered by this staff
            $promiseData = DB::table('et_sales_promise')
                ->where('staff_id', $staff->sno)
                ->where('branch_id', $branch_id)
                ->whereYear('promise_date', $year)
                ->whereMonth('promise_date', $month)
                ->get()
                ->groupBy(function ($item) {
                    return Carbon::parse($item->promise_date)->format('Y-m-d');
                });
        
            // 🔧 Customer conversions grouped by date, filtered by this staff
            $customerConvertData = CustomerModel::select('et_customer.sno','et_payment.transaction_date as created_at')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by', $staff->sno) // 👈 this was missing
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->get()
                ->groupBy(function ($item) {
                    return Carbon::parse($item->created_at)->format('Y-m-d');
                });
        
        //  $customerConvertDatass =  DB::table('et_customer')
        //     ->select('et_customer.sno', 'et_customer.proposal_ids')
        //     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //     ->join('et_payment', function($join) {
        //         $join->on('et_payment.customer_id', '=', 'et_customer.sno')
        //              ->whereRaw('et_payment.transaction_date = (
        //                  SELECT MIN(ep.transaction_date)
        //                  FROM et_payment ep
        //                  WHERE ep.customer_id = et_customer.sno
        //              )');
        //     })
        //     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        //     ->where('et_customer.status', 0)
        //     ->where('et_customer.branch_id', $branch_id)
        //     ->where('et_lead.created_by', $staff->sno)
        //     ->whereYear('et_payment.transaction_date', $year)
        //      ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
        //     ->whereMonth('et_payment.transaction_date', $month)
        //     ->where('et_transaction.payment_status', 1)
        //     ->orderBy('et_customer.sno', 'asc')
        //     ->count();
            
            $allDates = collect($promiseData->keys())
                ->merge($customerConvertData->keys())
                ->unique()
                ->sort();
        
            $chartData = [];
        
            foreach ($allDates as $date) {
                $promises = $promiseData[$date] ?? collect();
                $converts = $customerConvertData[$date] ?? collect();
        
                $chartData[] = [
                    'promise_date' => $date,
                    'promise' => $promises->count(),
                    'convert' => $converts->count()
                ];
            }
        // Total Promises
        $total_promise = DB::table('et_sales_promise')
            ->where('staff_id', $staff->sno)
            ->where('branch_id', $branch_id)
            ->whereYear('promise_date', $year)
            ->whereMonth('promise_date', $month)
            ->count();

        // Total Conversions
        $total_convertion = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $staff->sno)
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month)
            ->count();

        $total_percentage = ($total_promise > 0) 
            ? round(($total_convertion / $total_promise) * 100) 
            : 0;

       // Filter chartData: keep only rows where promise or convrt is > 0
        $filteredChartData = array_filter($chartData, function ($row) {
            return $row['promise'] > 0 || $row['convert'] > 0;
        });
        
        $staffData[] = [
            'staff_id' => $staff->sno,
            'staff_name' => $staff->staff_name,
            'staff_image' => $staff->staff_image,
            'gender' => $staff->gender,
            'job_position' => $staff->job_position_name,
            'total_promise' => $total_promise,
            'total_convertion' => $total_convertion,
            'total_percentage' => $total_percentage . '%',
            'daily_data' => array_values($filteredChartData), // include filtered per-day data
        ];
    }

    return response()->json([
        'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
        'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
        'dates' => $dates,
        'managestaffDatalist' => $staffData,
    ]);
}



}
