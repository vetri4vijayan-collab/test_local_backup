<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\LeadTrackerModel;
use App\Models\ProductModel;
use App\Models\LeadSourceModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LeadTracker extends Controller
{
  public function index(Request $request)
  {
    return view('content.lead_management.manage_lead.lead_tracker_list');
  }

  public function leadTracker(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    //filter section
    $search    = $request->search;
    $productId = $request->product_id;
    $sourceId  = $request->source_id;
    $stafId  = $request->staff_id;
    $month  = $request->month;
    $valueOperator = $request->value_operator;
    $value1 = $request->value1;
    $value2 = $request->value2;
    try{

    $query = LeadTrackerModel::query()
      ->where('et_lead_tracker.branch_id', $branch_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_lead_tracker.lead_id')
      ->join('et_product', 'et_product.sno', '=', 'et_lead_tracker.product_id')
      ->join('et_staff', 'et_staff.sno', '=', 'et_lead_tracker.created_by')
      ->select(
        'et_lead.sno as lead_id',
        'et_lead.lead_name',
        // 'et_lead.company_name',
        'et_lead.lead_mobile',
        'et_lead.lead_status_id',
        'et_lead.status',
        'et_lead.is_hot_lead',
        'et_product.product_name',
        'et_lead_tracker.value',
        'et_staff.staff_name',
      );

    // 🔍 Search filter
    if ($search) {
      $query->where(function ($q) use ($search) {
        $q->where('et_lead.lead_name', 'like', "%$search%")
          ->orWhere('et_lead.lead_mobile', 'like', "%$search%");
          // ->orWhere('et_lead.company_name', 'like', "%$search%");
      });
    }

    if ($productId) {
      $query->where('et_lead_tracker.product_id', $productId);
    }

    if ($sourceId) {
      $query->where('et_lead.lead_source_id', $sourceId);
    }

    if ($stafId) {
      $query->where('et_lead_tracker.created_by', $stafId);
    }



    if ($month) {
      try {
        $date = Carbon::createFromFormat('M-Y', $month);

        $start = $date->startOfMonth()->format('Y-m-d');
        $end   = $date->endOfMonth()->format('Y-m-d');

        $query->whereBetween('et_lead_tracker.created_at', [$start, $end]);
      } catch (\Exception $e) {
        // ignore invalid month format
      }
    }


    if ($valueOperator && $value1 !== '') {

      if ($valueOperator == '>') {
        $query->where('et_lead_tracker.value', '>', $value1);
      } elseif ($valueOperator == '<') {
        $query->where('et_lead_tracker.value', '<', $value1);
      } elseif ($valueOperator == '=') {
        $query->where('et_lead_tracker.value', $value1);
      } elseif ($valueOperator == 'between' && $value2 !== '') {
        $query->whereBetween('et_lead_tracker.value', [$value1, $value2]);
      }
    }
    $leads = $query->orderByDesc('et_lead_tracker.updated_at')->get();

    //  Kanban Mapping
    $kanban = [
      'qualified' => [],
      'followup'  => [],
      'level3'    => [],
      'level2'    => [],
      'level1'    => [],
      'closing'   => [],
    ];

    foreach ($leads as $lead) {

      if ($lead->status == 0 && $lead->lead_status_id == 3 && $lead->is_hot_lead == 2) {
        $kanban['qualified'][] = $lead;
      } elseif ($lead->status == 0 && $lead->lead_status_id == 2) {
        $kanban['followup'][] = $lead;
      } elseif ($lead->status_id == 1 && $lead->status != 4) {
        $kanban['level3'][] = $lead;
      } elseif ($lead->status_id == 2 && $lead->status != 4) {
        $kanban['level2'][] = $lead;
      } elseif ($lead->status_id == 3 && $lead->status != 4) {
        $kanban['level1'][] = $lead;
      } elseif ($lead->status == 4) {
        $kanban['closing'][] = $lead;
      }
    }

    // Count + Sum
    $summary = [];
    foreach ($kanban as $key => $items) {
      $summary[$key] = [
        'count' => count($items),
        'value' => collect($items)->sum('value')
      ];
    }
    $totalValue = collect($summary)->sum('value');
    return response()->json([
      'status'  => 200,
      'data'    => $kanban,
      'summary' => $summary,
      'total'   => $totalValue
    ]);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'An error occurred while fetching lead tracker data.',
        'error' => $e->getMessage()
      ]);
    }
  }

  public function productList(Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $products = ProductModel::where('status', 0)
      ->select('sno', 'product_name')
      ->get()
      ->map(function ($p) use ($helper) {
        return [
          'sno' => $p->sno,
          'product_name' => $p->product_name,
        ];
      });

    return response()->json([
      'status' => 200,
      'data' => $products
    ]);
  }
  public function SourceList(Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $products = LeadSourceModel::where('status', 0)
      ->select('sno', 'lead_source_name')
      ->get()
      ->map(function ($p) use ($helper) {
        return [
          'sno' => $p->sno,
          'lead_source' => $p->lead_source_name,
        ];
      });

    return response()->json([
      'status' => 200,
      'data' => $products
    ]);
  }
  public function StaffList(Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $products = StaffModel::where('status', 0)->where('department_id', 1)
      ->select('sno', 'staff_name')
      ->get()
      ->map(function ($p) use ($helper) {
        return [
          'sno' => $p->sno,
          'staff_name' => $p->staff_name,
        ];
      });

    return response()->json([
      'status' => 200,
      'data' => $products
    ]);
  }
}
