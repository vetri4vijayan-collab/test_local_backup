<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\ProductModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadExportModel;
use App\Models\StudentpointsModel;
use App\Models\ContactDetailsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadsExport;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\WhatsappApiConfigureModel;
use App\Services\DoubletickService;
use App\Models\LeadAppointmentModel;
use App\Models\SmsTemplateModel;
use DateTime;
use App\Models\FollowupReasonModel;
use App\Models\LeadExportExcel;
use App\Mail\DynamicTemplateEmail;
use App\Models\PointsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Pagination\CursorPaginator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\SlotModel;
use App\Models\StaffpointsModel;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadTransferLogModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class ManageLeadSource extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        if ($year == date('Y') || $year > date('Y')) {
            $year_chk = 0;
        } else {
            $year_chk = 1;
        }

        $months = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ];

        $results = LeadSourceModel::select(
            DB::raw("COALESCE(et_lead_source.lead_source_name, 'No Source') as lead_source_name"),
            DB::raw("months.month_name")
        )
            ->crossJoin(DB::raw("(SELECT 'January' as month_name UNION ALL SELECT 'February'
            UNION ALL SELECT 'March' UNION ALL SELECT 'April' UNION ALL SELECT 'May'
            UNION ALL SELECT 'June' UNION ALL SELECT 'July' UNION ALL SELECT 'August'
            UNION ALL SELECT 'September' UNION ALL SELECT 'October' UNION ALL SELECT 'November'
            UNION ALL SELECT 'December') as months"))
            ->groupBy('et_lead_source.lead_source_name', 'months.month_name')
            ->orderBy('et_lead_source.lead_source_name', 'ASC')
            ->orderBy(DB::raw("FIELD(months.month_name, '" . implode("','", $months) . "')"))
            ->get();

        $results = $results->map(function ($single) use ($year, $request) {
            $currentMonth = $single->month_name;
            $branch_id = $request->user()->branch_id;
            $helper = new \App\Helpers\Helpers();

            // Initialize variables
            $total_payment = 0;
            $total_paid_payment = 0;
            $All_base_amount_paid = 0;
            $All_total_payment = 0;
            $gst_percent = 18;

            // Get lead details
            $leadDetails = DB::table('et_lead')
                ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                ->whereYear('et_lead.registered_date', $year)
                ->whereRaw("MONTHNAME(et_lead.registered_date) = ?", [$currentMonth])
                ->where('et_lead.internal_status', '!=', 1)
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.created_by', '>', 0)
                ->where('et_lead.branch_id', '=', $branch_id)
                ->where('et_lead_source.lead_source_name', $single->lead_source_name)
                ->select(
                    'et_lead.lead_name',
                    'et_lead.lead_email_id',
                    'et_lead.lead_mobile',
                    'et_lead.lead_id',
                    'et_lead_source.lead_source_name'
                )
                ->get();

            $lead_count = $leadDetails->count();

            // Get customer details (converted from leads)
            $customerData = DB::table('et_customer')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                ->join('et_payment', function ($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereRaw("MONTHNAME(et_payment.transaction_date) = ?", [$currentMonth])
                ->where('et_transaction.payment_status', 1)
                ->where('et_lead.created_by', '>', 0)
                ->where('et_lead_source.lead_source_name', $single->lead_source_name)
                ->select(
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.cus_email_id',
                    'et_customer.cus_mobile',
                    'et_customer.lead_id',
                    'et_customer.customer_id',
                    'et_lead_source.lead_source_name'
                )
                ->get();

            $customer_count = $customerData->count();

            // Calculate payments if customers exist
            if ($customer_count > 0) {
                foreach ($customerData as $customer) {
                    $proposal_ids = DB::table('et_proposal')
                        ->where('et_proposal.customer_id', $customer->sno)
                        ->where('et_proposal.status', 0)
                        ->whereNot('et_proposal.post_sale_check', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->pluck('sno')
                        ->toArray();

                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposal_ids)
                        ->get();

                    foreach ($proposals as $proposal) {
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');

                        $grantAmount = $proposal->grant_total_amount;
                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                        if ($proposal->currency_id == 70) {
                            $total_paid_payment = $paidAmount;
                            $total_payment = $grantAmount;
                            $base_amount_paid = $basePaidLocal;
                            $All_total_payment += $grantAmount;
                            $All_base_amount_paid += $basePaidLocal;
                        } else {
                            $currency_code = $proposal->currency_code;
                            $total_paid_payment = $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $total_payment = $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $base_amount_paid = $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                            $All_total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $All_base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                        }
                    }
                    $customer->averageBusinessValue = $total_payment;
                    $customer->averageCollectionValue = $base_amount_paid;
                }
            }

            // Calculate averages
            $TotalaverageBusinessValue  = $customer_count > 0 ? $All_total_payment / $customer_count : 0;
            $TotalaveragCollectionValue = $customer_count > 0 ? $All_base_amount_paid / $customer_count : 0;

            // Add calculated values to customerData collection
            $customerDataCollection = collect($customerData);
            $customerDataCollection->put('TotalaverageBusinessValue', $TotalaverageBusinessValue);
            $customerDataCollection->put('TotalaveragCollectionValue', $TotalaveragCollectionValue);

            // Set return values
            $single->customer_details = $customerDataCollection->toArray();
            $single->customer_count = $customer_count;
            $single->leaddata_details = $leadDetails->toArray();
            $single->total_lead = $lead_count;

            return $single;
        });

        $results = collect($results);

        return view('content.lead_management.manage_lead_source.lead_source_list', [
            'perpage' => $perpage,
            'year_chk' => $year_chk,
            'results' => $results,
        ])->with('filter_on', false);
    }
}