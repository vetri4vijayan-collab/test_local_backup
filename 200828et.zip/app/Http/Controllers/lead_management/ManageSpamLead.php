<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use App\Models\StaffpointsModel;
use App\Models\LeadBankReasonModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class ManageSpamLead extends Controller
{
    // verify confirm spam
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;

        // Filters
        $lead_fill = $request->input('lead_fill', '');

        $leads = LeadModel::select(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.spam_reason',
            'et_lead.spam_tl_verified',
            'et_lead.spam_tl_reason',
            'et_lead.spam_bh_reason',
            'et_lead.inter_calls',
            'et_lead.raw_lead_check',
            'et_lead.raw_lead_group',
            'et_lead.is_hot_lead',
            'et_lead.spam_comments',
            'et_lead.spam_verified',
            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.call_tracker_id',
            'et_lead.website_id',
            'et_lead.registered_date',
            'et_lead.created_at',
            'et_lead.lead_mobile',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.sno as staff_id',
            'et_staff.nick_name as sales_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno as lead_type_id',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno as lead_source_id'


        )
            ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->where('et_lead.status', 7)->where('lead_bank_status', '!=', 1);

        // Branch-specific filter
        if ($branch_id != 0) {
            $leads->where('et_lead.branch_id', $branch_id);
        }

        // Add groupBy
        $leads = $leads->groupBy(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.spam_reason',
            'et_lead.spam_tl_verified',
            'et_lead.spam_comments',
            'et_lead.spam_verified',
            'et_lead.spam_tl_reason',
            'et_lead.is_hot_lead',
            'et_lead.spam_bh_reason',
            'et_lead.inter_calls',
            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.call_tracker_id',
            'et_lead.website_id',
            'et_lead.raw_lead_check',
            'et_lead.raw_lead_group',
            'et_lead.registered_date',
            'et_lead.lead_mobile',
            'et_lead.created_at',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.sno',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno'
        );




        if ($lead_fill != '') {
            $leads->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $leads = $leads->orderBy('et_lead.spam_verified', 'asc')->paginate($perpage);

        $verified_spam_count     = 0;
        $not_verified_spam_count = 0;

        $verified_drop_count     = 0;
        $not_verified_drop_count = 0;

        $verified_spam_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
        $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

        $verified_drop_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
        $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

        // return $reasonList_internal;
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->where('et_appointment.created_by', $user_id)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "global_lead";
        }
        // $totalFollowup = DB::table('et_appointment')
        //     ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        //     ->where('et_appointment.branch_id', $branch_id)
        //     ->where('et_appointment.status', '!=', 4)
        //     ->where('et_lead.status', '=', 0)
        //     ->whereDate('et_appointment.appointment_date', '=', today())
        //     ->count();

        $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();

        $walletCount = DB::table('et_lead')
            ->where('et_lead.created_by', $user_id)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.wallet_status', '=', 1)
            ->count();

        $leadOriginal = DB::table('et_lead')
            ->where('et_lead.branch_id', $branch_id)->whereNotIn('et_lead.status', [2, 6])->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified', 0)->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
            ->distinct('et_lead.sno');
        // Apply permission-based filtering
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $leadOriginalCount = $leadOriginal->count();
        $totalLeadCount = RawLeadModel::where('status', 6)->where('et_raw_lead.branch_id', $branch_id)->count();
        $internal_calls_count = DB::table('et_lead')
            ->where('et_lead.internal_status', 1)
            ->where('et_lead.potential_verify', 0)
            ->where('et_lead.lead_bank_status', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.internal_verify', 0)
            ->count();

        $reasonList_lead_bank = LeadBankReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();


        // return $leads;
        return view('content.lead_management.manage_lead.spam_lead_list', compact(
            'leads',
            'leadOriginalCount',
            'internal_calls_count',
            'perpage',
            'totalFollowup',
            'walletCount',
            'verified_spam_count',
            'not_verified_spam_count',
            'verified_drop_count',
            'leadbankCount',
            'totalLeadCount',
            'not_verified_drop_count',
            'lead_fill',
            'reasonList_lead_bank'
        ));
    }
    public function SpamLeadList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;

        // Filters
        $lead_fill = $request->input('lead_fill', '');

        $leads = LeadModel::select(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.spam_reason',
            'et_lead.spam_tl_verified',
            'et_lead.spam_tl_reason',
            'et_lead.spam_bh_reason',
            'et_lead.inter_calls',
            'et_lead.raw_lead_check',
            'et_lead.raw_lead_group',
            'et_lead.is_hot_lead',
            'et_lead.spam_comments',
            'et_lead.spam_verified',
            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.call_tracker_id',
            'et_lead.website_id',
            'et_lead.registered_date',
            'et_lead.created_at',
            'et_lead.lead_mobile',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.sno as staff_id',
            'et_staff.nick_name as sales_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno as lead_type_id',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno as lead_source_id'


        )
            ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->where('et_lead.status', 7)->where('lead_bank_status', '!=', 1);

        // Add groupBy
        $leads = $leads->groupBy(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.spam_reason',
            'et_lead.spam_tl_verified',
            'et_lead.spam_comments',
            'et_lead.spam_verified',
            'et_lead.spam_tl_reason',
            'et_lead.is_hot_lead',
            'et_lead.spam_bh_reason',
            'et_lead.inter_calls',
            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.call_tracker_id',
            'et_lead.website_id',
            'et_lead.raw_lead_check',
            'et_lead.raw_lead_group',
            'et_lead.registered_date',
            'et_lead.lead_mobile',
            'et_lead.created_at',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.sno',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno'
        );




        if ($lead_fill != '') {
            $leads->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $leads = $leads->orderBy('et_lead.spam_verified', 'asc')->paginate($perpage);

        $verified_spam_count     = 0;
        $not_verified_spam_count = 0;

        $verified_drop_count     = 0;
        $not_verified_drop_count = 0;

        $verified_spam_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
        $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

        $verified_drop_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
        $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

        // return $reasonList_internal;
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->where('et_appointment.created_by', $user_id)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "global_lead";
        }
        // $totalFollowup = DB::table('et_appointment')
        //     ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        //     ->where('et_appointment.branch_id', $branch_id)
        //     ->where('et_appointment.status', '!=', 4)
        //     ->where('et_lead.status', '=', 0)
        //     ->whereDate('et_appointment.appointment_date', '=', today())
        //     ->count();

        $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();

        $walletCount = DB::table('et_lead')
            ->where('et_lead.created_by', $user_id)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.wallet_status', '=', 1)
            ->count();

        $leadOriginal = DB::table('et_lead')
            ->where('et_lead.branch_id', $branch_id)->whereNotIn('et_lead.status', [2, 6])->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified', 0)->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
            ->distinct('et_lead.sno');
        // Apply permission-based filtering
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $leadOriginalCount = $leadOriginal->count();
        $totalLeadCount = RawLeadModel::where('status', 6)->where('et_raw_lead.branch_id', $branch_id)->count();
        $internal_calls_count = DB::table('et_lead')
            ->where('et_lead.internal_status', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.internal_verify', 0)
            ->where('et_lead.potential_verify', 0)
            ->where('et_lead.lead_bank_status', 0)
            ->count();

        $reasonList_lead_bank = LeadBankReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();


        // return $leads;
        return view('content.lead_management.manage_lead.new_spam_lead_list', compact(
            'leads',
            'leadOriginalCount',
            'internal_calls_count',
            'perpage',
            'totalFollowup',
            'walletCount',
            'verified_spam_count',
            'not_verified_spam_count',
            'verified_drop_count',
            'leadbankCount',
            'totalLeadCount',
            'not_verified_drop_count',
            'lead_fill',
            'reasonList_lead_bank'
        ));
    }
    public function ConfirmSpamLead(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $id = $request->lead_id;
        $verify_reason_spam = $request->verify_reason_spam;
        $user_id = $request->user()->user_id;

        $spam_lead_upd = LeadModel::where('sno', $id)->first();

        if (!$spam_lead_upd) {
            return response([
                'status'    => 404,
                'message'   => 'Lead not found',
                'data'      => null,
            ], 200);
        }
        if ($request->verified_by == 1) {
            $spam_lead_upd->spam_tl_verified = 1;
            $spam_lead_upd->spam_tl_reason = $verify_reason_spam;
        } elseif ($request->verified_by == 2) {
            $spam_lead_upd->spam_verified = 1;
            $spam_lead_upd->spam_bh_reason = $verify_reason_spam;
        }
        $spam_lead_upd->updated_by = $user_id;

        // return $spam_lead_upd;
        // return $spam_lead_upd;
        $spam_lead_upd->save();

        // Check if the update was successful
        if ($spam_lead_upd->wasChanged()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Spam Verified Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not verify the Spam',
            ]);
        }

        // Return the updated lead or redirect
        return redirect()->back();
    }
    // convert spam to lead branch
    public function ConvertSpamToLead($id, Request $request)
    {
        // return $request;
        // Get user info from the request
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $old_staff_id = $request->old_staff_id;
        $lead = LeadModel::where('sno', $id)->first();
        $helper = new \App\Helpers\Helpers();

        // Check if lead exists
        if ($lead) {
            // Get lead history and check if it exists
            $lead_history = LeadTransferLogModel::where('lead_id', $id)
                ->where('current_staff_id', $old_staff_id)
                ->first();

            // If there's a lead history, update it
            if ($lead_history) {
                $lead_history->end_date = date('Y-m-d');
                $lead_history->change_staff_id = $request->convert_staff_id;
                $lead_history->transferred_from = 2; // from spam transfer
                $lead_history->update(); // Actually update the record
            }

            // Add a new history record for Spam conversion
            $add_history = new LeadTransferLogModel();
            $add_history->lead_id = $lead->sno;
            $add_history->branch_id = $lead->branch_id;
            $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
            $add_history->current_staff_id = $old_staff_id;
            $add_history->change_staff_id = 0; // Indicating it's a spam transfer  
            $add_history->transferred_from = 2; // Spam transfer  
            $add_history->created_by = $user_id;
            $add_history->updated_by = $user_id;
            $add_history->save(); // Save the new history entry
            //   return response([
            //     'status' => 200,
            //     'message' => 'Successfully Lead Converted!',
            //     'error_msg' => null,
            //     'data' => $add_history,
            // ], 200);



            // Update lead details
            $lead->status = 0;
            $lead->spam_verified = 0;
            $lead->lead_status_id = 1;
            $lead->created_by = $request->convert_staff_id;
            $lead->updated_by = $user_id;
            $lead->converted_by = $user_id;
            // return $lead;
            // Update the lead in the database
            if ($lead->update()) {
                // Define point category and calculate points
                $pointsData = $helper->get_points_by_id(11);
                $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
                $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string

                // Save new points for the staff
                $newPoints = new StaffpointsModel();
                $newPoints->branch_id = $branch_id;
                $newPoints->staff_id = $old_staff_id;
                $newPoints->points_by = $lead->sno;
                $newPoints->points_id = 1; // Assuming 1 represents the category for Lead Conversion
                $newPoints->points = $point;
                $newPoints->reason = $reason;
                $newPoints->save();

                // Update staff's available points
                $staff_points = StaffModel::where('sno', $old_staff_id)->first();
                if ($staff_points) {
                    $staff_points->avaiable_points += $point; // Increment the available points
                    $staff_points->save();
                }

                // Return success response
                return response([
                    'status' => 200,
                    'message' => 'Successfully Lead Converted!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            }
        }

        // If no lead was found or the update failed, return an error
        return response([
            'status' => 400, // 400 Bad Request as the lead was not found or could not be updated
            'message' => 'Failed to convert lead. Lead not found or an error occurred.',
            'error_msg' => 'No lead found with the given ID.',
            'data' => null,
        ], 400);
    }
    public function trans_spam_to_lead(Request $request)
    {
        $id = $request->lead_id;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        DB::beginTransaction();
        try {

            $lead = LeadModel::where('sno', $id)->first();

            if (!$lead) {
                return response([
                    'status' => 400,
                    'message' => 'Lead not found.',
                    'error_msg' => 'Invalid lead ID.',
                    'data' => null,
                ], 400);
            }

            $old_staff_id = $lead->created_by;

            // Close previous transfer history
            $lead_history = LeadTransferLogModel::where('lead_id', $id)
                ->whereNull('end_date')
                ->where('current_staff_id', $old_staff_id)
                ->first();

            if ($lead_history) {
                $lead_history->end_date = date('Y-m-d');
                $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
                // $lead_history->transferred_from = 14; // spam transfer
                $lead_history->save();
            }

            // New transfer history entry
            $add_history = new LeadTransferLogModel();
            $add_history->lead_id = $lead->sno;
            $add_history->branch_id = $lead->branch_id;
            $add_history->start_date = date('Y-m-d'); // new start date = today
            $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
            $add_history->change_staff_id = 0;
            $add_history->transferred_from = 14;
            $add_history->created_by = $user_id;
            $add_history->updated_by = $user_id;
            $add_history->save();

            // Update lead details
            $lead->status = 0;
            $lead->spam_verified = 0;
            $lead->lead_status_id = 1;
            $lead->transfer_status = 1;
            $lead->is_spam = 1;
            $lead->created_by = $request->convert_staff_id ?? $user_id;
            $lead->updated_by = $user_id;
            $lead->converted_by = $user_id;
            $lead->save();

            DB::commit();

                if ($lead) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Successfully Lead Converted!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Convert the Lead!'
                    ]);
                }
            // return $result;
            return redirect('/lead_management/spam_lead');
        } catch (\Exception $e) {
            DB::rollBack();

            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not Convert the Lead!' . $e->getMessage()
            ]);
            return redirect('/lead_management/spam_lead');
        }
    }


public function bulkConvertSpamToLead(Request $request)
{
    $request->validate([
        'convert_staff_id' => 'required|integer',
        'leads' => 'required|array|min:1',
        'leads.*.lead_id' => 'required|integer',
        'leads.*.old_staff_id' => 'required|integer',
    ]);

    DB::beginTransaction();

    try {

        $user_id = auth()->user()->user_id;
        $branch_id = auth()->user()->branch_id;

        $helper = new \App\Helpers\Helpers();

        $pointsData = $helper->get_points_by_id(11);

        $point = $pointsData ? $pointsData->points : 0;

        $reason = $pointsData
            ? $pointsData->points_name
            : '';

        foreach ($request->leads as $item) {

            $lead_id = $item['lead_id'];
            $old_staff_id = $item['old_staff_id'];
            $lead = LeadModel::where('sno', $lead_id)->first();
            if (!$lead) {
                continue;
            }
            // close previous history
            LeadTransferLogModel::where('lead_id', $lead_id)
                ->where('current_staff_id', $old_staff_id)
                ->whereNull('end_date')
                ->update([
                    'end_date' => now()->format('Y-m-d'),
                    'change_staff_id' => $request->convert_staff_id,
                    'transferred_from' => 2
                ]);

            // add history
            LeadTransferLogModel::create([
                'lead_id' => $lead->sno,
                'branch_id' => $lead->branch_id,
                'start_date' => now()->format('Y-m-d'),
                'current_staff_id' => $request->convert_staff_id,
                'change_staff_id' => 0,
                'transferred_from' => 2,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            // update lead
            $lead->update([
                'status' => 0,
                'internal_status' => 0,
                'is_potential' => 0,
                'potential_verify' => 0,
                'spam_verified' => 0,
                'lead_status_id' => 1,
                'transfer_status' => 1,
                'created_by' => $request->convert_staff_id,
                'updated_by' => $user_id,
                'converted_by' => $user_id,
            ]);

            // add points
            StaffpointsModel::create([
                'branch_id' => $branch_id,
                'staff_id' => $old_staff_id,
                'points_by' => $lead->sno,
                'points_id' => 1,
                'points' => $point,
                'reason' => $reason,
            ]);

            // update available points
            StaffModel::where('sno', $old_staff_id)
                ->increment('avaiable_points', $point);
        }

        DB::commit();

        return response()->json([
            'status' => 200,
            'message' => 'Bulk Lead Conversion Successful'
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'status' => 500,
            'message' => $e->getMessage()
        ], 500);
    }
}
}
