<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use App\Models\LeadBankReasonModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class ManageRawLead extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $lead_grp_fill = $request->lead_grp_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    // return $login_branch_data;

    $rawLeadQuery = RawLeadModel::select('et_raw_lead.sno', 'et_raw_lead.lead_name', 'et_raw_lead.registered_date', 'et_raw_lead.lead_gender', 'et_raw_lead.lead_dob', 'et_raw_lead.lead_email_id', 'et_raw_lead.lead_mobile', 'et_lead_source.lead_source_name', 'et_raw_lead.lead_group', 'et_lead_source.sno as lead_source_id')
      ->where('et_raw_lead.status', 6)
      // ->join('et_lead_type', 'et_raw_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->where('et_raw_lead.branch_id', $branch_id)
      ->where('et_raw_lead.entity_id', $entity_id)
      ->where('et_raw_lead.lead_bank_status', '!=' , 1)
      ->leftjoin('et_lead_source', 'et_raw_lead.lead_source_id', '=', 'et_lead_source.sno');

    if ($lead_grp_fill  != '') {
      $rawLeadQuery->where(function ($query) use ($lead_grp_fill) {
        $query->where('et_raw_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('et_raw_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('et_raw_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('et_raw_lead.lead_email_id', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('et_lead_source.lead_source_name', 'LIKE', "%{$lead_grp_fill}%");
      });
    }

    // Paginate the results
    $rawLeads = $rawLeadQuery->orderBy('et_raw_lead.sno', 'desc')->paginate($perpage);
    
    // Get all lead mobile numbers from raw leads
    $leadMobiles = $rawLeads->pluck('lead_mobile')->toArray();

    // Check which mobile numbers exist in za_lead table
    $existingMobiles = LeadModel::whereIn('lead_mobile', $leadMobiles)->pluck('lead_mobile')->toArray();

    // Map to add lead_initial and mobile_exists
    $rawLeads->getCollection()->transform(function ($item) use ($existingMobiles) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
      $item->mobile_exists = in_array($item->lead_mobile, $existingMobiles) ? true : false;
      return $item;
    });

    $totalLeadCount = RawLeadModel::where('status', 6)->where('et_raw_lead.branch_id', $branch_id)->where('et_raw_lead.entity_id', $entity_id)->count();

    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('et_appointment')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        ->where('et_appointment.branch_id', $branch_id)
        ->where('et_appointment.status', '!=', 4)
        ->where('et_lead.status', '=', 0)
        ->where('et_appointment.created_by', $user_id)
        ->whereDate('et_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('et_appointment')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        ->where('et_appointment.branch_id', $branch_id)
        ->where('et_appointment.entity_id', $entity_id)
        ->where('et_appointment.status', '!=', 4)
        ->where('et_lead.status', '=', 0)
        ->whereDate('et_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();
    $walletCount = DB::table('et_lead')
      ->where('et_lead.created_by', $user_id)
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)
      ->where('et_lead.wallet_status', '=', 1)
      ->count();
    $internal_calls_count = DB::table('et_lead')
      ->where('et_lead.internal_status', 1)
      ->where('et_lead.potential_verify', 0)
      ->where('et_lead.lead_bank_status', 0)
      ->where('et_lead.branch_id', $branch_id)
      ->count();

    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('entity_id', $entity_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('entity_id', $entity_id)->where('status', 5)->where('drop_verified', 0)->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $leadOriginal = DB::table('et_lead')
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)
      ->whereNotIn('et_lead.status', [ 2, 6])->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified',0)->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
      ->distinct('et_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    $reasonList_lead_bank = LeadBankReasonModel::select('*')
          ->where('status', 0)
          ->orderBy('sno', 'desc')->get();
    // Return view with data
    return view('content.lead_management.manage_lead.rawlead_list', compact('rawLeads','reasonList_lead_bank', 'internal_calls_count','leadOriginalCount', 'walletCount', 'leadbankCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'totalLeadCount', 'login_branch_data', 'perpage', 'totalFollowup', 'lead_grp_fill'))->with('filter_on', true);
    // return view('content.lead_management.manage_lead.lead_list');
  }
  public function bank_lead_conversion(Request $request)
  {
    // return $request;
    $lead_id = $request->lead_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id = $request->user()->user_id;

    $raw_lead = RawLeadModel::where('sno', $lead_id)->first();
    // return $raw_lead;

    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status' => 400,
          'message' => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data' => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile = $raw_lead->lead_mobile;
      // $add_category->lead_source_id = $lead_source_id;
      $add_category->lead_group = $raw_lead->lead_group;
      $add_category->created_by = $assign_staff_id; // Same for updated_by
      $add_category->branch_id = $branch_check->sno; // Correct branch ID
      $add_category->entity_id = $request->user->entity_id; // Correct branch ID
      $add_category->updated_by = $user_id; // Same for updated_by
      $add_category->lead_status_id = 1; // new lead
      $add_category->lead_condition = 1; // standard lead
      // return $add_category;
      if (!$add_category->save()) {
        $success = false; // Mark as unsuccessful if save fails
      }
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $add_category->sno;
      $add_history->branch_id = $add_category->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
      $add_history->current_staff_id = $add_category->created_by;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 6; // from Bulk transfer  
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save();

      $raw_lead->status = 2;
      $raw_lead->save(); // Save changes to raw lead
    }

    return redirect('manage_lead');
  }
  public function exportExcel(Request $request)
  {
    // return $request;
    $branchId = $request->user()->branch_id;
    $filters = $request->all();
    return Excel::download(new LeadExportExcel($branchId, $filters), 'leads-export.xlsx');
  }

  public function LeadExportExcel()
  {
    return Excel::download(new LeadExportModel, 'leads-sample-export.xlsx'); // Adjust filename and extension as needed
  }

  public function LeadImport(Request $requestData)
  {
    $validator = Validator::make($requestData->all(), [
      'file_import' => 'required|file|mimes:xls,xlsx|max:5120',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->all(),
        'data' => null,
      ], 400);
    }

    $file_import = $requestData->file('file_import');
    $lead_source_id = $requestData->input('lead_source_id');
    $lead_group = $requestData->input('lead_group');

    // Check if the lead group already exists
    // $chk = RawLeadModel::where('lead_group', $lead_group)->where('status', '!=', 2)->first();
    // if ($chk) {
    //   return response()->json([
    //     'status' => 'error',
    //     'message' => 'Group name already exists!',
    //     'error_msg' => ['Group name already exists!'],
    //   ], 207);
    // }

    $data = Excel::toCollection(new RawLeadModel, $file_import);

    if ($data->isEmpty() || $data[0]->isEmpty()) {
      return response()->json([
        'status' => 401,
        'message' => 'The uploaded file is empty.',
        'error_msg' => ['The uploaded file is empty.'],
        'data' => null,
      ], 400);
    }

    $errors = [];
    $successfulImports = 0;
    $branch_data = BranchModel::where('sno', $requestData->user()->branch_id)->first();
    $branch_name = " ";
    if ($branch_data->branch_type == 1) {
      $branch_name = $branch_data->branch_name;
    } elseif ($branch_data->branch_type == 2) {
      $branch_name = $branch_data->franchise_name;
    }


    foreach ($data[0] as $key => $row) {
      if ($key > 0) {  // Skip the header row

        $lead_name = $row[0];
        $lead_mobile = $row[1];
        $lead_mail = $row[2];
        $lead_date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row[3])->format('Y-m-d');
        // || empty($lead_mobile)
        if (empty($lead_name)  || empty($lead_date)) {
          $errors[] = 'Missing required field in row ' . ($key + 1);
          continue;
        }
        // if (is_numeric($lead_date)) {
        //   $lead_date = Date::excelToDateTimeObject($lead_date)->format('Y-m-d');
        // }

        if (isset($lead_date) && strtotime($lead_date)) {
          // Check if it's a valid date string before formatting
          $lead_date = date('Y-m-d', strtotime($lead_date));
        } else {
          // Default to today's date
          $lead_date = date('Y-m-d');
        }
        if (!$lead_date) {
          // Default to today's date
          $lead_date = date('Y-m-d');
        }

        // $lead_mobile = str_replace(' ', '', $lead_mobile);
        // Convert encoding to remove hidden characters
        $lead_mobile = mb_convert_encoding($lead_mobile, 'UTF-8', 'UTF-8');

        // Remove all non-numeric characters (including hidden spaces and special chars)
        $lead_mobile = preg_replace('/\D/', '', $lead_mobile);

        // Check for existing mobile number
        $chk = RawLeadModel::where('lead_mobile', $lead_mobile)->first();
        if ($chk) {
          $errors[] = 'Row ' . ($key + 1) . ': Mobile number ' . $lead_mobile . ' already exists! <br>';
          continue;
        }

        // Generate new lead ID
        $branch_check = BranchModel::where('sno', $requestData->user()->branch_id)->first();
        $branch_code = $branch_check->city_short_code;

        $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "RL0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = $year . '/' . $branch_code . '/' . sprintf("RL%04d", $next_number);
        }

        $user_id = $requestData->user()->user_id;
        $branch_id = $requestData->user()->branch_id;
        $entity_id = $requestData->user()->entity_id ?? 1;

        // Create new lead
        $new_lead = new RawLeadModel();
        $new_lead->lead_id = $lead_id;
        $new_lead->lead_name = $lead_name;
        $new_lead->lead_mobile = $lead_mobile;
        $new_lead->lead_email_id = $lead_mail;
        $new_lead->lead_source_id = $lead_source_id;
        $new_lead->lead_group = $lead_group;
        $new_lead->registered_date = $lead_date;
        $new_lead->status = 6;
        $new_lead->branch_id = $branch_id;
        $new_lead->entity_id = $entity_id;
        $new_lead->created_by = $user_id;
        $new_lead->updated_by = $user_id;

        // return $new_lead;

        if ($new_lead->save()) {
          $successfulImports++;
        } else {
          $errors[] = 'Row ' . ($key + 1) . ': Could not import the lead ' . $lead_name . '!<br>';
        }
      }
    }

    $responseMessage = $successfulImports . ' lead(s) imported successfully.';

    if (!empty($errors)) {
      return response()->json([
        'status' => 'partial_success',
        'message' => $responseMessage,
        'error_msg' => $errors,
      ], 207);
    }

    return response()->json([
      'status' => 'success',
      'message' => $responseMessage,
      'data' => null,
    ], 200);
  }
  public function Rawspam(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->rawlead_id_spam;
    $raw_lead = RawLeadModel::where('sno', $id)->first();


    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->registered_date         = $raw_lead->registered_date??date('Y-m-d');
      $add_category->branch_id               = $branch_check->sno;
      $add_category->created_by              = $request->user()->user_id;
      $add_category->updated_by              = $request->user()->user_id;
      $add_category->lead_status_id          = 6; // new lead
      $add_category->status                  = 7; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $spam_reason_edit = $request->spam_reason_edit;
      $add_category->spam_reason = $spam_reason_edit;
      // return $spam_reason_edit;
      if ($spam_reason_edit == 1) {
        $add_category->spam_reason = $request->spam_reason_text;
      } else {
        $spam = SpamReasonModel::where('reason_name', $spam_reason_edit)->first();
        // return $spam;
        if ($spam->comments_check ?? 0 == 1) {
          $add_category->spam_comments = $request->spam_comments_text;
        }
      }
      // return $add_category;
      $add_category->save();

      if ($add_category) {
        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save();
      }
    }

    if ($add_category) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function Rawdrop(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->rawlead_id_drop;
    $raw_lead = RawLeadModel::where('sno', $id)->first();


    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->registered_date         = $raw_lead->registered_date??date('Y-m-d');
      $add_category->branch_id               = $branch_check->sno;
      $add_category->created_by              = $request->user()->user_id;
      $add_category->updated_by              = $request->user()->user_id;
      $add_category->lead_status_id          = 4; // new lead
      $add_category->status                  = 5; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $reason_edit = $request->reason_edit;
      $add_category->drop_reason = $reason_edit;
      // return $reason_edit;
      if ($reason_edit == 1) {
        $add_category->drop_reason = $request->drop_reason_text;
      } else {
        $drop = DropReasonModel::where('reason_name', $reason_edit)->first();
        // return $drop;
        if ($drop->comments_check == 1) {
          $add_category->drop_comments = $request->drop_comments_text;
        }
      }
      // return $add_category;
      $add_category->save();

      if ($add_category) {
        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save();
      }
    }

    if ($add_category) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function FutureLead($id, Request $request)
  {
    // return $id;
    $lead =  RawLeadModel::where('sno', $id)->first();
    $lead->status = $request->status;
    // return $lead;
    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully converted to Future Lead!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  public function checkMobileExists(Request $request)
  {
    $lead_mobile = $request->input('mobile');

    // Assuming you have a Lead model with a mobile field
    $exists = LeadModel::where('lead_mobile', $lead_mobile)->exists();

    return response()->json(['exists' => $exists]);
  }
  public function ConvertRawtoLead($id, Request $request)
  {
    // return $id;

    $raw_lead = RawLeadModel::where('sno', $id)->first();

    $lead_source_id = $request->lead_source_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id  = $request->user()->user_id;

    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->registered_date              = $raw_lead->registered_date??date('Y-m-d');
      $add_category->lead_source_id          = $lead_source_id;
      $add_category->created_by              = $assign_staff_id; // Same for updated_by
      $add_category->branch_id               = $branch_check->sno; // Ensure correct branch ID
      $add_category->updated_by              = $request->user()->user_id; // Same for updated_by
      $add_category->lead_status_id          = 1; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $add_category->save();

      if ($add_category) {

        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save(); // Save the changes to the raw lead

        $add_history = new LeadTransferLogModel();
        $add_history->lead_id = $add_category->sno;
        $add_history->branch_id = $add_category->branch_id;
        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
        $add_history->current_staff_id = $add_category->created_by;
        $add_history->change_staff_id = 0;
        $add_history->transferred_from = 4; // from Bulk transfer  
        $add_history->created_by = $user_id;
        $add_history->updated_by = $user_id;
        // return $add_history;
        $add_history->save();

        //   return $add_history;

      }

      return response([
        'status'    => 200,
        'message'   => 'Successfully converted the Raw Lead!',
        'error_msg' => null,
        'data'      => [
          'lead_id' => $add_category->sno, // Return new lead ID
        ]
      ], 200);
    }

    return response([
      'status'    => 404,
      'message'   => 'Raw lead not found.',
      'error_msg' => null,
      'data'      => null
    ], 404);
  }
  public function phone_no_raw_lead_update($id, Request $request)
  {
    // return $id;

    $raw_lead = RawLeadModel::where('sno', $id)->first();
    $phone_no = $request->mobile_no;
    $user_id  = $request->user()->user_id;

    if ($raw_lead) {
     
        // Update raw lead status
        $raw_lead->lead_mobile = $phone_no;
        $raw_lead->save();
        
      return response([
        'status'    => 200,
        'message'   => 'Successfully converted the Raw Lead!',
        'error_msg' => null,
        'data'      => [
          'lead_id' => $id, // Return new lead ID
        ]
      ], 200);
    }

    return response([
      'status'    => 404,
      'message'   => 'Raw lead not found.',
      'error_msg' => null,
      'data'      => null
    ], 404);
  }
  public function SalesStaffList(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $dept_id = 1;
    $staff     = StaffModel::select('et_staff.sno', 'et_staff.staff_name', 'et_staff.department_id', 'et_staff.nick_name', 'et_job_position.job_position_name as position_name')
              ->where('et_staff.status', 0)
              ->where('et_staff.sno', '>',1)
              ->where('et_staff.branch_id', $branch_id)
              ->whereIn('et_staff.department_id', [1])
              ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
              ->orderBy('et_staff.staff_name', 'ASC')
              ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff,
    ], 200);
  }
  public function bulk_raw_lead_conversion(Request $request)
  {
    $checked = $request->checked;
    $lead_source_id = $request->bulk_lead_source_id;
    $assign_staff_id = $request->bulk_assign_staff_id;
    $user_id = $request->user()->user_id;
    $count = isset($checked) ? count($checked) : 0;
    if (isset($checked) && !empty($checked)) {
      $success = true; // Flag for successful lead conversion

      foreach ($checked as $id) {
        $raw_lead = RawLeadModel::where('sno', $id)->first();
        // return $raw_lead;

        if ($raw_lead) {
          // Get the branch information
          $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

          if (!$branch_check) {
            return response([
              'status' => 400,
              'message' => 'Branch not found.',
              'error_msg' => 'Invalid branch ID.',
              'data' => null
            ], 400);
          }

          $branch_code = $branch_check->city_short_code;

          // Generate lead ID
          $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
          $year = date("Y");

          if (!$category_check) {
            $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
          } else {
            $data = $category_check->lead_id;
            $slice = explode("/", $data);
            $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_number = (int)$resultcus + 1;
            $request_pay = sprintf("LED%04d", $next_number);
            $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
          }

          // Create new lead
          $add_category = new LeadModel();
          $add_category->lead_id = $lead_id;
          $add_category->lead_name = ucfirst($raw_lead->lead_name);
          $add_category->lead_mobile = $raw_lead->lead_mobile;
          $add_category->registered_date = $raw_lead->registered_date??date('Y-m-d');
          $add_category->lead_source_id = $lead_source_id;
          $add_category->lead_group = $raw_lead->lead_group;
          $add_category->created_by = $assign_staff_id; // Same for updated_by
          $add_category->branch_id = $branch_check->sno; // Correct branch ID
          $add_category->updated_by = $user_id; // Same for updated_by
          $add_category->lead_status_id = 1; // new lead
          $add_category->lead_condition = 1; // standard lead
          // return $add_category;
          if (!$add_category->save()) {
            $success = false; // Mark as unsuccessful if save fails
          }
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 5; // from Bulk transfer  
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
          // Update raw lead status
          //   $staff = StaffModel::where('sno', $add_category->created_by)->first();
          //   if ($staff) {
          //     $staff->actual_lead_count += 1;
          //     $staff->original_lead_count += 1;
          //     // return $staff;
          //     $staff->save();
          //   }

          // Update raw lead status
          $raw_lead->status = 2;
          $raw_lead->save(); // Save changes to raw lead
        }
      }

      // Set flash message based on success flag
      if ($success) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => $count . ' Leads Converted Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add some leads conversion!'
        ]);
      }
    }

    return redirect('/manage_lead');
  }
}