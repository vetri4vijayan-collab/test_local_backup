<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\ManageCouponModel;
use Illuminate\Support\Facades\DB;
use App\Models\ManageCouponHistoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ManageCoupon extends Controller
{




  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $coupon_fill = $request->coupon_fill ?? '';
    $coupon_type_fill = $request->coupon_type_fill ?? '';
    $max_usg_count_fill = $request->max_usg_count_fill;
    $multiple_check_fill = $request->multiple_check_fill ?? '';
    $public_check_fill = $request->public_check_fill ?? '';
    $fill_chk = $request->fill_chk ?? 0;
    // $lead_fill = $request->lead_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    // return $request;

    // $lead = LeadModel::select('sno','lead_name', 'lead_mobile')->where('status', '!=', 2)->get();

    $query =  ManageCouponModel::select(
      'et_manage_coupon.*',
      'et_manage_coupon.status as coupon_status'
    )
      // ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_manage_coupon.assign_lead_id')
      // 'et_lead.lead_name','et_lead.lead_mobile',
      ->where('et_manage_coupon.status', '!=', "2");

    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('et_manage_coupon.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('et_manage_coupon.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('et_manage_coupon.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('et_manage_coupon.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('et_manage_coupon.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('et_manage_coupon.created_at', '<=', $toDate);
      }
    }

    if ($branch_id != 0) {
      $query->where('et_manage_coupon.branch_id', $branch_id);
    }

    if ($coupon_fill) {
      $query->where('et_manage_coupon.coupon_name', 'LIKE', "%{$coupon_fill}%");
    }
    if ($coupon_type_fill) {
      $query->where('et_manage_coupon.coupon_type', 'LIKE', "%{$coupon_type_fill}%");
    }
    if ($max_usg_count_fill) {
      $query->where('et_manage_coupon.max_usage_count', 'LIKE', "%{$max_usg_count_fill}%");
    }
    if ($multiple_check_fill) {
      $query->where('et_manage_coupon.multiple_check', $multiple_check_fill);
    }
    if ($public_check_fill) {
      $query->where('et_manage_coupon.public_check', $public_check_fill);
    }
    // // Lead filter logic (corrected)
    // if ($lead_fill != '') {
    //   $query->where(function ($query) use ($lead_fill) {
    //       $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
    //           ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
    //           ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
    //   });
    // }

    // Fetch Branch list ordered by sno in descending order
    $coupon_list = $query->orderBy('et_manage_coupon.sno', 'desc')->distinct()->paginate($perpage);
    // return $lead_fill;

    $pageConfigs = ['myLayout' => 'default'];
    if ($fill_chk == 1) {
      $fill = true;
    } else {
      $fill = false;
    }
    // return $fill;
    return view('content.lead_management.manage_coupon.coupon_list', [
      'coupon_list' => $coupon_list,
      // 'lead' => $lead,
      'date_filter' => $date_filter,
      'coupon_fill' => $coupon_fill,
      'coupon_type_fill' => $coupon_type_fill,
      'max_usg_count_fill' => $max_usg_count_fill,
      'multiple_check_fill' => $multiple_check_fill,
      'public_check_fill' => $public_check_fill,
      'perpage'           => $perpage,
      'fill_chk' => $fill_chk,
      'pageConfigs' => $pageConfigs,
    ])->with('filter_on', $fill);
  }

  public function autocomplete_coupon(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $search = $request->get('term');
    $coupon = ManageCouponModel::select(
      'et_manage_coupon.sno',
      'et_manage_coupon.coupon_name',
      'et_manage_coupon.coupon_value',
      'et_manage_coupon.coupon_code',
      'et_manage_coupon.coupon_type',
      'et_manage_coupon.end_date',
      'et_manage_coupon.branch_id',
      'et_manage_coupon.max_usage_count',
      'et_manage_coupon.used_count',
      'et_coupon_usage_history.coupon_id',
      'et_coupon_usage_history.used_by',
      'et_coupon_usage_history.amount',
      'et_coupon_usage_history.modal_id',
      'et_coupon_usage_history.used_date',
      DB::raw('CASE 
                    WHEN et_coupon_usage_history.modal_id = 1 THEN et_lead.lead_name 
                    WHEN et_coupon_usage_history.modal_id = 2 THEN et_customer.cus_name 
                    ELSE NULL 
                 END AS user_name')
    )
      ->leftJoin('et_coupon_usage_history', 'et_coupon_usage_history.coupon_id', '=', 'et_manage_coupon.sno')
      ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_coupon_usage_history.used_by')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_coupon_usage_history.used_by')
      ->where(function ($query) use ($search) {
        $query->where('et_manage_coupon.coupon_name', 'LIKE', '%' . $search . '%')
          ->orWhere('et_manage_coupon.coupon_value', 'LIKE', '%' . $search . '%')
          ->orWhere('et_manage_coupon.coupon_code', 'LIKE', '%' . $search . '%');
      })
      ->where('et_manage_coupon.branch_id', $branch_id)
      ->get();

    // return $coupon;
    return response()->json($coupon);
  }
  public function usage_history(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    // $usage_history_list_fill = ManageCouponHistoryModel::select('*')
    // ->leftJoin('et_manage_coupon','et_manage_coupon.sno','et_coupon_usage_history.coupon_id')      
    //   ->where('et_coupon_usage_history.status',0)
    //   ->orderBy('et_coupon_usage_history.sno', 'desc')
    //   ->get();

    // return $request;
    $coupon_name_fill = $request->coupon_name_fill ?? '';
    $coupon_type_fill = $request->coupon_type_fill ?? '';
    $multi_check_fill = $request->multi_check_fill ?? '';
    $public_check_fill = $request->public_check_fill ?? '';
    $search_fill = $request->search_fill ?? '';
    $lead_fill = $request->lead_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fill_chk = $request->fill_chk ?? 0;

    $usage_history_list = DB::table('et_manage_coupon')->select(
      'et_manage_coupon.*',
      'et_manage_coupon.coupon_name',
      'et_manage_coupon.coupon_code',
      'et_manage_coupon.public_check',
      'et_manage_coupon.multiple_check',
      'et_manage_coupon.branch_id',
      'et_proposal.proposal_id',
      'et_proposal.currency_id',
      'et_country_currencies.currency_symbol',
      'et_proposal.created_at as used_date',
      'et_proposal.discount_amount as amount',
      'et_lead.lead_name',
    )
      ->leftJoin('et_proposal', 'et_manage_coupon.sno', '=', 'et_proposal.discount_id')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->leftJoin('et_lead', 'et_proposal.lead_id', '=', 'et_lead.sno')
      ->where('et_manage_coupon.status', 0)
      ->where('et_manage_coupon.branch_id', $branch_id)
      ->orderBy('et_manage_coupon.sno', 'desc');

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $usage_history_list->whereDate('et_manage_coupon.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $usage_history_list->whereBetween('et_manage_coupon.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $usage_history_list->whereBetween('et_manage_coupon.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $usage_history_list->whereBetween('et_manage_coupon.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $usage_history_list->where('et_manage_coupon.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $usage_history_list->where('et_manage_coupon.created_at', '<=', $toDate);
      }
    }


    if (!empty($search_fill)) {
      $usage_history_list->where(function ($q) use ($search_fill) {
        $q->where('et_lead.lead_name', 'like', '%' . $search_fill . '%')
          ->orWhere('et_manage_coupon.coupon_name', 'like', '%' . $search_fill . '%')
          ->orWhere('et_lead.lead_mobile', 'like', '%' . $search_fill . '%')
          ->orWhere('et_manage_coupon.created_at', 'like', '%' . $search_fill . '%')
          ->orWhere('et_proposal.created_at', 'like', '%' . $search_fill . '%')
          ->orWhere('et_proposal.proposal_id', 'like', '%' . $search_fill . '%')
          ->orWhere('et_manage_coupon.coupon_code', 'like', '%' . $search_fill . '%');
      });
    }


    if ($coupon_name_fill != '') {
      $usage_history_list->where('et_manage_coupon.coupon_name', $coupon_name_fill);
    }

    if ($multi_check_fill != '') {
      $usage_history_list->where('et_manage_coupon.multiple_check', $multi_check_fill);
    }
    if ($public_check_fill != '') {
      $usage_history_list->where('et_manage_coupon.public_check', $public_check_fill);
    }

    $usage_history_list = $usage_history_list->paginate($perpage);
    if ($fill_chk == 1) {
      $fill = true;
    } else {
      $fill = false;
    }

    // return $fill;
    return view('content.lead_management.manage_coupon.usage_history', [
      'usage_history_list' => $usage_history_list,
      'coupon_name_fill' => $coupon_name_fill,
      'multi_check_fill' => $multi_check_fill,
      'search_fill' => $search_fill,
      'coupon_type_fill' => $coupon_type_fill,
      'date_filter' => $date_filter,
      'public_check_fill' => $public_check_fill,
      'perpage'           => $perpage,
      'fill_chk' => $fill_chk,
    ])->with('filter_on', $fill);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  ManageCouponModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Delete($id, Request $request)
  {
    // return $request;

    $user_id              = $request->user()->user_id;
    $branch_id            = $request->user()->branch_id;
    $coupon =  ManageCouponModel::where('sno', $id)->first();
    $coupon->status  = 2;
    // return $coupon;

    $coupon->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Add(Request $request)
  {
    // Validate the request
    $validator = Validator::make($request->all(), [
      'coupon_name' => 'required|max:255',
      'branch_id'   => 'required|array', // Ensure branch_id is an array
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }

    // Extracting values from the request
    $coupon_name     = $request->coupon_name;
    $coupon_value    = $request->coupon_value;
    $coupon_type     = $request->coupon_type;
    $coup_code_val   = $request->coup_code_val;
    $coupon_code_cust = $request->coupon_code_cust;
    $max_usg_count   = $request->max_usg_count;
    $multiple_check  = $request->multiple_check ?? 0;
    $coupon_dur      = $request->coupon_dur;
    $coupon_dur_type = $request->coupon_dur_type;
    $public_check    = $request->public_check ?? 0;
    $unexpired_check = $request->unexpired_check ?? 0;
    $coupon_end_dt   = !empty($request->coupon_end_dt) ? date('Y-m-d', strtotime($request->coupon_end_dt)) : null;
    $branch_ids      = $request->branch_id; // This is an array
    $user_id         = $request->user()->user_id;

    // Ensure that if multiple_check is 1, max_usage_count should be 0
    if ($multiple_check == 1) {
      $max_usg_count = 0;
    }

    foreach ($branch_ids as $branch_id) {
      // Check if coupon already exists for this branch
      $chk = ManageCouponModel::where('coupon_name', ucwords($coupon_name))
        ->where('coupon_code', $coup_code_val)
        ->where('branch_id', $branch_id) // Now checking per branch
        ->where('status', '!=', 2)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => "Coupon for Branch ID $branch_id is already Created!"
        ]);
        continue; // Skip creating duplicate
      }

      // Generate coupon ID
      $category_check = ManageCouponModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')->first();

      if (!$category_check) {
        $year = substr(date("y"), -2);
        $coupon_id = "COU-0001/" . $year;
      } else {
        $data = $category_check->coupon_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request_id = sprintf("COU-%04d", $next_number);

        $year = substr(date("y"), -2);
        $coupon_id = $request_id . '/' . $year;
      }

      // Create new Coupon record for each branch
      $add_category = new ManageCouponModel();

      $add_category->coupon_code      = $coup_code_val ?: $coupon_code_cust;
      $add_category->coupon_id        = $coupon_id;
      $add_category->coupon_name      = ucfirst($coupon_name);
      $add_category->coupon_value     = $coupon_value;
      $add_category->coupon_type      = $coupon_type;
      $add_category->max_usage_count  = $max_usg_count ?? 1;
      $add_category->multiple_check   = $multiple_check;
      $add_category->duration         = $coupon_dur;
      $add_category->duration_type    = $coupon_dur_type;
      $add_category->public_check     = $public_check;
      $add_category->unexpired_check  = $unexpired_check;
      $add_category->end_date         = $coupon_end_dt;
      $add_category->branch_id        = $branch_id; // Save per branch entry
      $add_category->created_by       = $user_id;
      $add_category->updated_by       = $user_id;

      // Save the coupon
      if ($add_category->save()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => "Coupon added Successfully!"
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => "Could not add the Coupon!"
        ]);
      }
    }

    return redirect()->back();
  }
}
