<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use App\Models\LeadBankReasonModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class ManageInternalLead extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;

        // Filters
        $lead_fill = $request->input('lead_fill', '');

        $leads = LeadModel::select(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.inter_calls',
            'et_lead.internal_status',
            'et_lead.internal_verify',
            'et_lead.internal_veri_reason',
            'et_lead.spam_reason',
            'et_lead.internal_comments',
            'et_lead.internal_reason',
            'et_lead.registered_date',
            'et_lead.created_at',
            'et_lead.lead_mobile',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_staff.sno as staff_id',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno as lead_type_id',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno as lead_source_id'
        )
            ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->where('internal_verify', '!=', 2)
            ->where('internal_status', 1)
            ->where('potential_verify', 0)
            ->where('lead_bank_status', '!=', 1);


        // Add groupBy
        $leads = $leads->groupBy(
            'et_lead.sno',
            'et_lead.created_by',
            'et_lead.lead_id',
            'et_lead.spam_reason',
            'et_lead.internal_status',
            'et_lead.internal_verify',
            'et_lead.internal_veri_reason',
            'et_lead.internal_reason',
            'et_lead.internal_comments',
            'et_lead.inter_calls',
            'et_lead.registered_date',
            'et_lead.lead_mobile',
            'et_lead.created_at',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_staff.sno',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno'
        );

        if ($lead_fill != '') {
            $leads->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $leads = $leads->orderBy('et_lead.sno', 'desc')->paginate($perpage);

        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.entity_id', $entity_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->where('et_appointment.created_by', $user_id)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.entity_id', $entity_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "global_lead";
        }

        $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();

        $walletCount = DB::table('et_lead')
            ->where('et_lead.created_by', $user_id)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.wallet_status', '=', 1)
            ->count();
        $not_verified_spam_count = 0;
        $not_verified_drop_count = 0;

        $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

        $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

        $leadOriginal = DB::table('et_lead')
            ->where('et_lead.branch_id', $branch_id)->whereNotIn('et_lead.status', [2, 6])->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
            ->distinct('et_lead.sno')->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified', 0);
        // Apply permission-based filtering
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $leadOriginalCount = $leadOriginal->count();
        $totalLeadCount = RawLeadModel::where('status', 6)->where('et_raw_lead.branch_id', $branch_id)->count();

        $reasonList_lead_bank = LeadBankReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();

        // return $leads;
        return view('content.lead_management.manage_lead.internal_lead_list', compact(
            'leads',
            'totalFollowup',
            'walletCount',
            'leadbankCount',
            'totalLeadCount',
            'not_verified_spam_count',
            'not_verified_drop_count',
            'perpage',
            'lead_fill',
            'leadOriginalCount',
            'reasonList_lead_bank'
        ));
    }
    public function ConfirmInternalCalls(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $id = $request->lead_id;
        $internal_veri_reason = $request->verify_reason_spam;
        $user_id = $request->user()->user_id;

        $spam_lead_upd = LeadModel::where('sno', $id)->first();

        if (!$spam_lead_upd) {
            return response([
                'status'    => 404,
                'message'   => 'Lead not found',
                'data'      => null,
            ], 200);
        }
        $spam_lead_upd->internal_verify = 1;
        $spam_lead_upd->internal_veri_reason = $internal_veri_reason;

        $spam_lead_upd->updated_by = $user_id;

        // return $spam_lead_upd;
        // return $spam_lead_upd;
        $spam_lead_upd->save();

        // Check if the update was successful
        if ($spam_lead_upd->wasChanged()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Internal calls Verified Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not verify the Internal calls',
            ]);
        }

        // Return the updated lead or redirect
        return redirect()->back();
    }

    public function ConvertInternalToLead($id, Request $request)
    {
        // return $request;
        // Get user info from the request
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $old_staff_id = $request->old_staff_id ?? 0;
        $reject_reason_spam = $request->reject_reason_spam;
        $lead = LeadModel::where('sno', $id)->first();
        // Update lead details
        $lead->status = 0;
        $lead->internal_verify = 2;
        $lead->internal_reject_reason = $reject_reason_spam;
        $lead->lead_status_id = 1;
        $lead->internal_status = 0;
        $lead->created_by = $request->old_staff_id ?? 0;
        $lead->updated_by = $user_id;
        $lead->converted_by = $user_id;
        // return $lead;
        // Update the lead in the database
        if ($lead->update()) {

            // Return success response
            return response([
                'status' => 200,
                'message' => 'Successfully Lead Converted!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }


        // If no lead was found or the update failed, return an error
        return response([
            'status' => 400, // 400 Bad Request as the lead was not found or could not be updated
            'message' => 'Failed to convert lead. Lead not found or an error occurred.',
            'error_msg' => 'No lead found with the given ID.',
            'data' => null,
        ], 400);
    }
}
