<?php

namespace App\Http\Controllers\authentications;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\IpConfigModel;
use Jenssegers\Agent\Agent;

class LoginBasic extends Controller
{
  public function index()
  {
    $pageConfigs = ['myLayout' => 'blank'];
    return view('content.authentications.auth-login-basic', ['pageConfigs' => $pageConfigs]);
  }


  // public function login(Request $request)
  // {
  //   // Validate the request
  //   $validator = Validator::make($request->all(), [
  //     'email' => 'required|email|max:255',
  //     'password' => 'required|min:4',
  //   ]);

  //   // Check if validation fails
  //   if ($validator->fails()) {
  //     return response()->json([
  //       'status' => 422,
  //       'message' => 'Validation Error',
  //       'error_msg' => $validator->errors(),
  //       'data' => null
  //     ], 422);
  //   }
  //      // i want to check  here ip address and device type how 
  //       if(){
  //         // Attempt to find the user by email
  //         $user = User::where('email', $request->email)->first();

  //         // Check if user exists and password is correct
  //         if ($user && Hash::check($request->password, $user->password)) {
  //           // Create a new token for the user
  //           $token = $user->createToken('token')->plainTextToken;
  //           session()->flash('toastr', [
  //             'type' => 'success',
  //             'message' => 'Login Successfully!'
  //           ]);

  //           if ($request->expectsJson()) {
  //             return response()->json([
  //               'accessToken' => $token,
  //               'token_type' => 'Bearer',
  //             ]);
  //           }
  //           return redirect()->intended('/settings/general_settings');
  //           // return redirect('/settings-general_settings');
  //         } else {
  //           // Handle invalid credentials
  //           if ($request->expectsJson()) {
  //             return response()->json([
  //               'status' => 401,
  //               'message' => 'Invalid credentials',
  //               'data' => null
  //             ], 401);
  //           } else {
  //             // Redirect back with error message for web requests
  //             return back()->withErrors(['message' => 'Invalid credentials']);
  //           }
  //         }
  //       }else{
  //         return response()->json([
  //           'status' => 401,
  //           'message' => 'Invalid Ip Address',
  //           'data' => null
  //         ], 401);
  //       }

  // }



  public function login(Request $request)
  {
    // Validate the request
    $validator = Validator::make($request->all(), [
      'email' => 'required|email|max:255',
      'password' => 'required|min:4',
    ]);

    // Check if validation fails
    if ($validator->fails()) {
      return response()->json([
        'status' => 422,
        'message' => 'Validation Error',
        'error_msg' => $validator->errors(),
        'data' => null
      ], 422);
    }

    // Retrieve the user's IP address
    $userIp = $request->ip();

    // Check if the IP address is allowed
    $ipAllowed = IpConfigModel::where('ip_address', $userIp)->exists();

    if ($ipAllowed) {
      // Attempt to find the user by email
      $user = User::where('email', $request->email)->first();

      // Check if user exists and password is correct
      if ($user && Hash::check($request->password, $user->password)) {
        // Determine the device type
        $agent = new Agent();
        $deviceType = $agent->isMobile() ? 'Mobile' : ($agent->isTablet() ? 'Tablet' : 'Desktop');

        // Create a new token for the user
        $token = $user->createToken('token')->plainTextToken;

        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Login Successfully! (' . $deviceType . ')'
        ]);

        if ($request->expectsJson()) {
          return response()->json([
            'accessToken' => $token,
            'token_type' => 'Bearer',
            'device_type' => $deviceType,
          ]);
        }
        return redirect()->intended('/settings/general_settings');
      } else {
        // Handle invalid credentials
        if ($request->expectsJson()) {
          return response()->json([
            'status' => 401,
            'message' => 'Invalid credentials',
            'data' => null
          ], 401);
        } else {
          // Redirect back with error message for web requests
          return back()->withErrors(['message' => 'Invalid credentials']);
        }
      }
    } else {
      return response()->json([
        'status' => 401,
        'message' => 'Invalid IP Address',
        'data' => null
      ], 401);
    }
  }










  // public function Logout(Request $request)
  // {
  //   try {
  //     $user = $request->user()->token()->revoke();

  //     // return $user;
  //     //$user->revoke();

  //     //$authUserId = $request->auth()->user_id;
  //     if ($user) {

  //       //     $update = User::where('user_id', $authUserId)->update(['verification_code' => '']);
  //       $response = ['status' => 200, 'message' => 'You have been successfully logged out!', 'error_msg' => null, 'data' => null];
  //       return response($response, 200);
  //     } else {
  //       return response()->json(['status' => 500, 'message' => 'User Not Found', 'error_msg' => null, 'data' => null], 500);
  //     }
  //   } catch (\Throwable $th) {
  //     return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
  //   }
  // }
  public function logout(Request $request)
  {
    Auth::logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect('/auth/login-basic');
  }
  public function Verify(Request $request)
  {
    // Retrieve the bearer token from the request
    $token = $request->bearerToken();

    // Retrieve the authenticated user based on the token
    $user = $request->user();

    if ($user) {
      // Retrieve user's role if available
      // $role = Role::find($user->role_id);

      // Return user details in the response
      return response()->json([
        'api_token'         => $token,
        'created_at'        => $user->created_at,
        'email'             => $user->email,
        'email_verified_at' => $user->email_verified_at,
        'first_name'        => $user->name,
        'id'                => $user->id,
        'last_name'         => $user->last_name,
        // 'role_id'           => $user->role_id,
        // 'role_name'         => $role ? $role->role_name : '',
        'notify_count'      => 0
      ], 200);
    } else {
      // If user is not found or token is invalid
      $response = [
        'status' => 401,
        'message' => 'Unauthorized'
      ];
      return response()->json($response, 401);
    }
  }
}