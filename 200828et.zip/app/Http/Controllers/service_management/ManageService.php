<?php

namespace App\Http\Controllers\service_management;

use App\Http\Controllers\Controller;
use App\Models\CorrectionModel;
use App\Models\DailyTaskModel;
use App\Models\ManageAppointmentsModel;
use App\Models\ManageTaskModel;
use App\Models\ProductionMilestoneStaffModel;
use App\Models\StaffModel;
use App\Models\UploadSession;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ManageService extends Controller
{
    public function index(Request $request)
    {
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $search_fill = $request->search_fill ?? '';
        $cat_fill = $request->cat_fill ?? '';
        $product_fill = $request->product_fill ?? '';
        $status_fill = $request->status_fill ?? '';
        $filter_on = $request->filter_on ?? '';

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);

        // return $ListTable;
        // Dropdown data
        $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
        $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
        $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
        $staffs = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->select('et_staff.*', 'et_job_position.job_position_name')
            ->get();

        // MAIN QUERY
        $List = DB::table('et_milestone_mapping')
            ->select(
                'et_customer_services.sno',
                'et_customer_services.customer_id',
                'et_customer_services.service_check',
                'et_customer_services.cre_id',
                'et_customer_services.pc_id',
                'et_customer_services.product_id',
                'et_customer_services.package_id',
                'et_customer_services.product_package',
                'et_customer_services.production_staffs_id',
                'et_customer_services.branch_id',
                'et_customer_services.work_order_check',
                'et_customer_services.created_at',
                'et_customer_services.published_status',
                'et_customer_services.status',
                'et_customer_services.proposal_id',
                'et_customer_services.variant_variable_ids',
                'et_product.product_name',

                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer.country_code',
                'et_customer.customer_id AS cus_id',

                'et_product.duration',
                'et_product.duration_in',

                'et_customer_services.journal_check',
                'et_package.actual_duration',

                'cre.staff_name as cre_name',
                'cre.staff_image as cre_image',

                'pc.staff_name as pc_name',
                'pc.staff_image as pc_image',

                DB::raw("GROUP_CONCAT(pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
                DB::raw("GROUP_CONCAT(pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),

                'et_product_category.product_category_name',
                'et_product_category.sno as prd_cat_id',
                'et_product_category.jouranal_check'
            )
            ->where('et_customer_services.branch_id', $branch_id)
            ->where('et_customer_services.work_order_check', 3)
            ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
            ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
            ->leftJoin('et_staff as pro_staff', function ($join) {
                $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno');
        $user_role_id = $request->user()->role_id;

        if (in_array($user_role_id, [15, 33])) {
            $List->where('et_customer_services.pc_id', $user_id);
        }
        if ($user_role_id == 16) {
            $List->where('et_customer_services.cre_id', $user_id);
        }

        if (auth()->user()->hasPermissionradio('Production Management', 'Manage Work Order', 'view_self_work_order')) {
            // User can only view their own data
            $userRole = $request->user()->role_id;

            if ($userRole == 16) {
                $List->where('et_customer_services.cre_id', $user_id);
            } elseif ($userRole == 15) {
                $List->where('et_customer_services.pc_id', $user_id);
            }

            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Work Order', 'global_work_order')) {
        } else {
            abort(403, 'Unauthorized');
        }

        // Filters
        if ($search_fill != '') {
            $List->where(function ($query) use ($search_fill) {
                $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
            });
        }

        if ($cat_fill) {
            $List->where('et_product_category.sno', $cat_fill);
        }
        if ($product_fill) {
            $List->where('et_product.sno', $product_fill);
        }
        if ($status_fill || $status_fill === '0') {
            $List->where('et_customer_services.status', $status_fill);
        }

        $List->groupBy(
            'et_customer_services.sno',
            'et_customer_services.customer_id',
            'et_customer_services.cre_id',
            'et_customer_services.pc_id',
            'et_customer_services.product_id',
            'et_customer_services.package_id',
            'et_customer_services.product_package',
            'et_customer_services.service_check',
            'et_customer_services.production_staffs_id',
            'et_customer_services.branch_id',
            'et_customer_services.work_order_check',
            'et_customer_services.created_at',
            'et_customer_services.published_status',
            'et_customer_services.status',
            'et_customer_services.proposal_id',
            'et_customer_services.variant_variable_ids',

            'et_customer.cus_name',
            'et_customer.cus_mobile',
            'et_customer.cus_email_id',
            'et_customer.country_code',
            'et_customer.customer_id',

            'et_product.duration',
            'et_product.duration_in',
            'et_product.product_name',

            'et_package.actual_duration',

            'et_customer_services.journal_check',
            'cre.staff_name',
            'cre.staff_image',
            'pc.staff_name',
            'pc.staff_image',

            'et_product_category.product_category_name',
            'et_product_category.sno',
            'et_product_category.jouranal_check'
        )
            ->orderBy('et_customer_services.sno', 'DESC');

        // Clone query for service IDs
        $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();

        // If no services → show blank page
        if (empty($serviceIds)) {
            $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
                'path' => $request->url(),
                'query' => $request->query(),
            ]);

            return view('content.service_management.manage_service.list', [
                'ListTable' => $emptyPaginator,
                'perpage' => $perpage,
                'search_fill' => $search_fill,
                'Product_cat_list' => $Product_cat_list,
                'Product_ist' => $Product_list,
                'staffs' => $staffs,
                'Check_list' => $Check_list,
                'cat_fill' => $cat_fill,
                'product_fill' => $product_fill,
                'status_fill' => $status_fill,
                'Total_Services' =>  0,
                'staffNotAssignedCount' =>  0,
                'TasksNotAssignedCount' => 0,
            ]);
        }

        // Task count per service
        $taskCounts = DB::table('et_milestone_mapping')
            ->whereIn('service_id', $serviceIds)
            ->where('status', '!=', 2)
            ->select('service_id', 'task_ids')
            ->get()
            ->groupBy('service_id');

        // Collect all task IDs
        $allTaskIds = [];
        foreach ($taskCounts as $serviceTasks) {
            foreach ($serviceTasks as $m) {
                $ids = json_decode($m->task_ids, true);
                if (is_array($ids)) {
                    $allTaskIds = array_merge($allTaskIds, $ids);
                }
            }
        }
        $allTaskIds = array_unique($allTaskIds);

        // Get task names
        $taskNames = [];
        if (! empty($allTaskIds)) {
            $taskNames = DB::table('et_product_task')
                ->whereIn('sno', $allTaskIds)
                ->pluck('task_name', 'sno')
                ->toArray();
        }

        // Milestone data
        $milestoneData = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.services_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->whereIn('et_milestone_mapping.service_id', $serviceIds)
            ->where('et_milestone_mapping.status', '!=', 2)
            //   ->where('et_milestone_mapping.milestone_status', 1)
            ->get()
            ->groupBy('service_id');

        $Total_Services = count($milestoneData) ?? 0;

        $milestoneIds = DB::table('et_milestone_mapping')
            ->whereIn('service_id', $serviceIds)
            ->where('status', '!=', 2)
            ->pluck('sno'); // milestone ids

        $assignedMilestoneIds = DB::table('et_pro_milestone_staffs')
            ->whereIn('milestone_id', $milestoneIds)
            ->pluck('milestone_id');

        // Staff NOT assigned milestones count
        $staffNotAssignedCount = $milestoneIds
            ->diff($assignedMilestoneIds)
            ->count();

        $allServiceIds = collect($serviceIds);

        $taskAssignedServiceIds = DB::table('et_daily_tasks')
            ->whereIn('service_id', $serviceIds)
            ->pluck('service_id');

        $TasksNotAssignedCount = $allServiceIds
            ->diff($taskAssignedServiceIds)
            ->count();

        // APPLY PAGINATION
        $ListTable = $List->paginate($perpage);

        // ADD task & milestone data to each row
        foreach ($ListTable as $list) {

            // Total tasks
            $serviceTaskIds = [];
            if (isset($taskCounts[$list->sno])) {
                foreach ($taskCounts[$list->sno] as $milestone) {
                    $ids = json_decode($milestone->task_ids, true);
                    if (is_array($ids)) {
                        $serviceTaskIds = array_merge($serviceTaskIds, $ids);
                    }
                }
            }
            $list->total_task_count = count(array_unique($serviceTaskIds));

            // Milestone details
            $milestoneDataWithTasks = [];

            if (isset($milestoneData[$list->sno])) {

                foreach ($milestoneData[$list->sno] as $m) {

                    // 1️⃣ Get product-task IDs from milestone JSON
                    $productTaskIds = json_decode($m->task_ids, true) ?? [];

                    // 2️⃣ Get task names
                    $productTasks = DB::table('et_product_task')
                        ->whereIn('sno', $productTaskIds)
                        ->pluck('task_name')
                        ->toArray();

                    // 3️⃣ Map to et_task IDs
                    $etTaskIds = DB::table('et_task')
                        ->where('service_id', $list->sno)
                        ->whereIn('task_name', $productTaskIds)
                        ->pluck('sno')
                        ->toArray();

                    // 4️⃣ Get daily tasks
                    $dailyTasks = DB::table('et_daily_tasks')
                        ->where('service_id', $list->sno)
                        ->whereIn('task_id', $etTaskIds)
                        ->get();

                    $totalDaily = $dailyTasks->count();

                    $completedDaily = $dailyTasks->where('status', 4)->count();

                    $percentage = ($totalDaily > 0)
                        ? round(($completedDaily / $totalDaily) * 100, 2)
                        : 0;

                    // ---------------------------------------------------
                    // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
                    // ---------------------------------------------------
                    $staffIdsRaw = DB::table('et_pro_milestone_staffs')
                        ->where('service_id', $list->sno)
                        ->where('milestone_id', $m->sno)
                        ->pluck('staff_ids')
                        ->toArray();

                    $staffIds = [];

                    foreach ($staffIdsRaw as $row) {
                        // Decode JSON array string like ["25","58"]
                        $decoded = json_decode($row, true);

                        if (is_array($decoded)) {
                            $staffIds = array_merge($staffIds, $decoded);
                        }
                    }

                    // Remove duplicates & reindex
                    $staffIds = array_unique($staffIds);

                    $staffDetails = [];

                    if (! empty($staffIds)) {
                        $staffDetails = DB::table('et_staff')
                            ->whereIn('sno', $staffIds)
                            ->where('status', 0)
                            ->select('sno', 'staff_name', 'staff_image')
                            ->get()
                            ->toArray();
                    }

                    // ---------------------------------------------------
                    // FINAL STRUCTURE
                    // ---------------------------------------------------
                    $milestoneDataWithTasks[] = (object) [
                        'mile_stone_name' => $m->payment_slot_name,
                        'payable_amount' => $m->payable_amount,
                        'paidAmount' => $m->paidAmount,
                        'task_ids' => $m->task_ids,
                        'mile_sno' => $m->sno,
                        'status' => $m->milestone_status,
                        'services_status' => $m->services_status,

                        // TASKS
                        'task_names' => $productTasks,
                        'task_count' => count($productTasks),

                        // DAILY
                        'total_daily_tasks' => $totalDaily,
                        'completed_daily_tasks' => $completedDaily,
                        'milestone_percentage' => $percentage,

                        // STAFF
                        'assigned_staff' => $staffDetails,  // array of {sno, staff_name, staff_image}
                        'staff_count' => count($staffDetails),
                    ];
                }
            }

            $list->milestone_data = $milestoneDataWithTasks;
        }

        // return $ListTable;
        // Dropdown data
        $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
        $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
        $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
        $staffs = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->select('et_staff.*', 'et_job_position.job_position_name')
            ->get();

        return view('content.service_management.manage_service.list', [
            'ListTable' => $ListTable,
            'perpage' => $perpage,
            'search_fill' => $search_fill,
            'Product_cat_list' => $Product_cat_list,
            'Total_Services' => $Total_Services ?? 0,
            'staffNotAssignedCount' => $staffNotAssignedCount ?? 0,
            'TasksNotAssignedCount' => $TasksNotAssignedCount ?? 0,
            'Product_ist' => $Product_list,
            'staffs' => $staffs,
            'Check_list' => $Check_list,
            'cat_fill' => $cat_fill,
            'product_fill' => $product_fill,
            'status_fill' => $status_fill,
            'filter_on' => $filter_on,
        ]);
    }

    public function status_change(Request $request)
    {
        $sno = $request->sno;
        $status = $request->status;

        // Base update array
        $updateData = ['status' => $status];

        // If status = 8, update jc_id as well
        if ($status == 8 && $request->has('jc_id')) {
            $updateData['jc_id'] = $request->jc_id;
        }

        $update = DB::table('et_customer_services')
            ->where('sno', $sno)
            ->update($updateData);

        return response()->json([
            'status' => true,
            'message' => 'Service Updated successfully.',
            'data' => $update,
        ]);
    }

    public function Add_task(Request $request)
    {
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $sucess = false;

        $tasks = $request->input('tasks', []);

        if (empty($tasks)) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'No tasks found to add!',
            ]);

            return redirect()->back();
        }

        $service_id = $request->input('tsk_sno');
        $milestone_id = $request->input('mile_sno');

        DB::beginTransaction();

        try {

            /** ✅ GENERATE SINGLE TASK ID */
            $category_check = ManageTaskModel::orderBy('sno', 'desc')->first();

            if (! $category_check) {
                $year = substr(date('y'), -2);
                $task_id = 'TSK-0001/' . $year;
            } else {
                $data = $category_check->task_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int) $result + 1;
                $request_id = sprintf('TSK-%04d', $next_number);
                $year = substr(date('y'), -2);
                $task_id = $request_id . '/' . $year;
            }

            /** ✅ LOOP EACH TASK */
            foreach ($tasks as $taskUniqueId => $taskData) {

                $task_name_id = $taskData['task_name'];

                $product_task = DB::table('et_product_task')
                    ->where('sno', $task_name_id)
                    ->first();

                $cat = $product_task ? $product_task->category_check : 0;

                $task_check_list = DB::table('et_task_checklist')
                    ->where('product_task_id', $task_name_id)
                    ->where('status', 0)
                    ->pluck('sno')
                    ->toArray();

                $task_staffs = $taskData['task_staffs'] ?? [];
                $addMoreIds = $taskData['addMoreIds'] ?? [];

                /** ✅ LOOP STAFF USING addMoreIds (THIS IS THE REAL KEY FIX) */
                foreach ($addMoreIds as $index => $addMoreId) {

                    $staff_id = $task_staffs[$index] ?? null;
                    if (! $staff_id) {
                        continue;
                    }

                    $staff_data = DB::table('et_staff')->where('sno', $staff_id)->first();
                    $per_hour_cost = $staff_data->per_hour_cost ?? 0;

                    /** ✅ ✅ ✅ EXACT DYNAMIC KEY MATCHING */
                    $pages_percentage = (float) ($taskData["pages_percentage_{$taskUniqueId}_{$addMoreId}"] ?? 0);
                    $base_working_hours = (float) ($taskData["workingHours{$taskUniqueId}_{$addMoreId}"] ?? 0);
                    $working_hours = $taskData["workingHours_Hidden{$taskUniqueId}_{$addMoreId}"] ?? 0;
                    $task_per_hr = (float) ($taskData["task_per_hr_task_{$taskUniqueId}_{$addMoreId}"] ?? 0);

                    /** ✅ HARD VALIDATION */
                    if ($working_hours <= 0 || $base_working_hours <= 0) {
                        // \Log::error("Invalid working hours", [
                        //   'taskUniqueId' => $taskUniqueId,
                        //   'addMoreId' => $addMoreId,
                        //   'taskData' => $taskData
                        // ]);
                        continue;
                    }

                    /** ✅ SAVE TASK */
                    $Add = new ManageTaskModel();

                    $Add->task_id = $task_id;
                    $Add->task_category = $cat;
                    $Add->branch_id = $branch_id;
                    $Add->milestone_id = $milestone_id;
                    $Add->created_by = $user_id;
                    $Add->updated_by = $user_id;
                    $Add->service_id = $service_id;
                    $Add->task_name = $task_name_id;

                    $Add->assign_staffs = json_encode([$staff_id]);
                    $Add->per_hour_cost = $per_hour_cost;
                    $Add->working_hours = number_format($working_hours, 2, '.', '');
                    $Add->total_working_hours = number_format($base_working_hours, 2, '.', '');
                    $Add->pages_percentage = $pages_percentage;

                    $Add->task_check_list_ids = json_encode($task_check_list);
                    $Add->task_desc = $taskData['task_desc'] ?? '';
                    $Add->billable = 0;

                    if ($Add->save()) {
                        $this->updateMilestoneHistory(
                            $milestone_id,
                            $task_name_id,
                            $pages_percentage,
                            $user_id
                        );
                        $sucess = true;
                    }
                }
            }

            DB::commit();

            session()->flash('toastr', [
                'type' => $sucess ? 'success' : 'error',
                'message' => $sucess ? 'Tasks added Successfully!' : 'Could not add the Tasks!',
            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            return $e->getMessage();

            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Error adding tasks: ' . $e->getMessage(),
            ]);
        }

        return redirect('/manage_work_order');
    }

    // Updated function to update milestone history by task_id and milestone_id
    private function updateMilestoneHistory($milestone_id, $task_id, $new_allocation, $user_id)
    {
        // Get current milestone history for this specific task
        $milestoneHistory = DB::table('et_milestone_history')
            ->where('milestone_id', $milestone_id)
            ->where('task_id', $task_id)
            ->first();

        if ($milestoneHistory) {
            // Calculate new values
            $current_allocated = $milestoneHistory->allocated ?? 0;
            $total_pages = $milestoneHistory->page_or_per ?? 0;

            $updated_allocated = $current_allocated + $new_allocation;
            $updated_balance = $total_pages - $updated_allocated;

            // Ensure balance doesn't go negative
            if ($updated_balance < 0) {
                $updated_balance = 0;
                // You might want to adjust the allocation or throw an error here
            }

            // Update milestone history for this specific task
            DB::table('et_milestone_history')
                ->where('milestone_id', $milestone_id)
                ->where('task_id', $task_id)
                ->update([
                    'allocated' => $updated_allocated,
                    'balance' => $updated_balance,
                    'updated_by' => $user_id,
                    'updated_at' => now(),
                ]);
        } else {
            // If no record exists, you might want to create one or handle this case
            // For now, we'll log this situation
            // \Log::warning("No milestone history found for milestone_id: $milestone_id and task_id: $task_id");
        }
    }

    public function View($id = '')
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $view = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.sno as cus_id',
                'et_customer.cus_email_id',
                'et_customer.lead_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_customer.door_no',
                'et_customer.address',
                'et_countries.name',
                'et_customer.pincode',
                'et_states.name as state_name',
                'et_cities.name as city_name',
                'et_product.duration',
                'et_product.duration_in',
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                      WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                      ELSE NULL
                  END as service_name'),
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                      ELSE NULL
                  END as category_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $decryptedValue)->first();

        $requirements = DB::table('et_lead_requirement_doc')->where('lead_id', $view->lead_id)->where('status', '!=', 2)->get();

        return view('content.service_management.manage_service.service_view_requirements', [
            'view' => $view,
            'id' => $decryptedValue,
            'requirements' => $requirements,
        ]);
    }

    public function service_view_appointments($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $view = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_email_id',
                'et_customer.sno as cus_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_customer.door_no',
                'et_customer.address',
                'et_countries.name',
                'et_customer.pincode',
                'et_states.name as state_name',
                'et_cities.name as city_name',
                'et_product.duration',
                'et_product.duration_in',
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                      WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                      ELSE NULL
                  END as service_name'),
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                      ELSE NULL
                  END as category_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $decryptedValue)->first();

        $appointments = ManageAppointmentsModel::where('et_manage_appointments.status', '!=', 2)
            ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_staff.nick_name', 'et_staff.gender')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
            ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
            ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_appointments.staff_id')
            ->where('et_manage_appointments.customer_id', $view->cus_id)
            ->where('et_manage_appointments.branch_id', $branch_id)
            ->orderBy('et_manage_appointments.sno', 'desc')->get();

        return view('content.service_management.manage_service.service_view_appointment', [
            'view' => $view,
            'id' => $decryptedValue,
            'appointments' => $appointments,
        ]);
    }

    public function service_view_payments($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $view = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_email_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_customer.sno as cus_sno',
                'et_customer.door_no',
                'et_customer.address',
                'et_countries.name',
                'et_customer.pincode',
                'et_states.name as state_name',
                'et_cities.name as city_name',
                'et_product.duration',
                'et_product.duration_in',
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                      WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                      ELSE NULL
                  END as service_name'),
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                      ELSE NULL
                  END as category_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $decryptedValue)->first();

        $payments = DB::table('et_payment')->select(
            'et_payment.*',
            'et_transaction.payment_status as trans_status'
        )
            ->join('et_customer_services', 'et_customer_services.proposal_id', '=', 'et_payment.proposal_id')
            ->join('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer_services.customer_id', $view->cus_sno)
            ->get();

        return view('content.service_management.manage_service.service_view_payments', [
            'view' => $view,
            'id' => $decryptedValue,
            'payments' => $payments,
        ]);
    }

    public function service_view_tasks($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $view = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_email_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_customer.door_no',
                'et_customer.address',
                'et_countries.name',
                'et_customer.pincode',
                'et_states.name as state_name',
                'et_cities.name as city_name',
                'et_product.duration',
                'et_product.duration_in',
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                      WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                      ELSE NULL
                  END as service_name'),
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                      ELSE NULL
                  END as category_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $decryptedValue)
            ->first();

        $List = ManageTaskModel::select(
            'et_task.*',
            'et_customer.cus_name',
            'et_customer.cus_mobile',
            'et_customer.cus_email_id',
            'et_customer.country_code',
            'et_customer.customer_id AS cus_id',
            'et_product.duration',
            'et_product.duration_in',
            'et_product_category.product_category_name',
            'et_product_category.jouranal_check',
            DB::raw('CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name')
        )
            ->where('et_task.status', '!=', 2)
            ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_task.service_id', $view->sno)
            ->orderBy('et_task.sno', 'desc')->get();

        $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name', 'ASC')->get();
        $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name', 'ASC')->get();
        $staff_list = DB::table('et_staff')->where('status', 0)->where('sno', '>', 1)->where('branch_id', $branch_id)->orderBy('staff_name', 'ASC')->get();
        $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist', 'ASC')->get();

        return view('content.service_management.manage_service.service_view_tasks', [
            'view' => $view,
            'id' => $decryptedValue,
            'List' => $List,
            'Product_cat_list' => $Product_cat_list,
            'Product_ist' => $Product_list,
            'Staff_list' => $staff_list,
            'Check_list' => $Check_list,
        ]);
    }

    public function service_view_delivarables($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $view = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.sno as cus_id',
                'et_customer.cus_email_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_customer.door_no',
                'et_customer.address',
                'et_countries.name',
                'et_customer.pincode',
                'et_states.name as state_name',
                'et_cities.name as city_name',
                'et_product.duration',
                'et_product.duration_in',
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                      WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                      ELSE NULL
                  END as service_name'),
                DB::raw('CASE 
                      WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                      ELSE NULL
                  END as category_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $decryptedValue)->first();

        $List = DB::table('et_deliverables')->select(
            'et_deliverables.*',
            'et_customer.cus_name',
            'et_customer.cus_mobile',
            'et_customer.cus_email_id',
            'et_customer.country_code',
            'et_customer.customer_id as cus_id',
            'et_product.duration',
            'et_product.duration_in',
            'et_product_category.product_category_name',
            'et_product_category.jouranal_check',
            'et_payment_slot.payment_slot_name',
            DB::raw('CASE 
              WHEN et_customer_services.product_package = 1 THEN et_product.product_name
              WHEN et_customer_services.product_package = 2 THEN et_package.package_name
              ELSE NULL
          END as product_name')
        )
            ->where('et_deliverables.status', '!=', 2)
            ->leftJoin('et_payment_slot', 'et_deliverables.slot_id', 'et_payment_slot.sno')
            ->leftJoin('et_customer_services', 'et_deliverables.service_id', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_deliverables.customer_id', $view->cus_id)
            ->where('et_deliverables.branch_id', $branch_id)
            ->orderBy('et_deliverables.sno', 'desc')->get();

        return view('content.service_management.manage_service.service_view_delivarables', [
            'view' => $view,
            'id' => $decryptedValue,
            'List' => $List,
        ]);
    }
    // public function fetch_add_tasks($id = '')
    // {
    //   $data = DB::table('et_customer_services')
    //     ->select(
    //       'et_customer_services.*',
    //       'et_customer.cus_name',
    //       'et_customer.cus_mobile',
    //       'et_product.product_name',
    //       // DB::raw("CASE
    //       //           WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //       //           WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //       //           ELSE NULL
    //       //       END as product_name"),
    //       // Product category
    //       'et_product_category.product_category_name',
    //       'et_product_category.sno as cat_sno'
    //     )
    //     ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    //     ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
    //     ->where('et_customer_services.sno', $id)
    //     // ->leftJoin('et_product', function ($join) {
    //     //   $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //     //     ->where('et_customer_services.product_package', '=', 1);
    //     // })
    //     // ->leftJoin('et_package', function ($join) {
    //     //   $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //     //     ->where('et_customer_services.product_package', '=', 2);
    //     // })
    //     ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
    //     ->first();

    //   // Decode staff IDs
    //   $staffIds = json_decode($data->production_staffs_id, true);
    //   if (!is_array($staffIds)) {
    //     $staffIds = explode(',', $data->production_staffs_id);
    //   }
    //   $staffIds = array_filter(array_map('intval', $staffIds));

    //   // Fetch staff
    //   $staffs = [];
    //   if (!empty($staffIds)) {
    //     $staffs = DB::table('et_staff')
    //       ->select('sno', 'staff_name', 'per_hour_cost')
    //       ->whereIn('sno', $staffIds)
    //       ->get();
    //   }

    //   // Attach to response
    //   $data->production_staffs = $staffs;

    //   if ($data->product_package == 1) {
    //     // $proposaldata = DB::table('et_proposal_product_cart')
    //     // ->select('*')
    //     // ->where('product_id', $data->product_id)
    //     // ->where('status', 0)
    //     // ->where('proposal_sno', $data->proposal_id)
    //     // ->first();

    //     $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);

    //     $variant_name = '-';
    //     $variable_name = '-';
    //     $variable_id = 0;
    //     $variant_id = 0;

    //     // Loop through the variant_variable_data if it contains multiple variants/variables
    //     foreach ($variant_variable_data as $pair) {
    //       // Fetch variant and variable data
    //       $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
    //       $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

    //       // If a variant or variable is found, assign them
    //       if ($variant) {
    //         $variant_id = $variant->sno;
    //         $variant_name = $variant->product_variant_name ?? '';
    //       }

    //       if ($variable) {
    //         $variable_id = $variable->sno;
    //         $variable_name = $variable->variable_name ?? '';
    //       }
    //     }
    //     $data->variant_name = $variant_name;
    //     $data->variable_name = $variable_name;
    //     // OLD Fetch task list based on the variant and variable IDs
    //     // $task_list = DB::table('et_product_task_mapping')
    //     //   ->leftJoin('et_product_task', 'et_product_task_mapping.sno', '=', 'et_product_task.map_id')
    //     //   ->where('et_product_task.product_id', $data->product_id)
    //     //   ->where('et_product_task_mapping.variant_id', $variant_id)
    //     //   ->where('et_product_task_mapping.variable_id', $variable_id)
    //     //   ->where('et_product_task_mapping.status', 0)
    //     //   ->get();

    //     $milestone_mapping = DB::table('et_milestone_mapping')
    //       ->where('customer_id', $data->customer_id)
    //       ->where('service_id', $data->sno)
    //       ->where('status', 0)
    //       ->where('milestone_status', 1)
    //       ->first();

    //     if ($milestone_mapping) {
    //       // Decode JSON string into array if stored as JSON
    //       $task_ids = json_decode($milestone_mapping->task_ids, true);

    //       if (!empty($task_ids)) {
    //         $task_list = DB::table('et_product_task')
    //           ->whereIn('et_product_task.sno', $task_ids)
    //           ->where('et_product_task.status', 0)
    //           ->get();
    //       } else {
    //         $task_list = collect(); // empty collection
    //       }
    //     } else {
    //       $task_list = collect(); // empty collection if no milestone found
    //     }
    //   } else {
    //     $packageProducts = DB::table('et_package_product')
    //       ->where('package_id', $data->package_id)
    //       ->where('status', 0)
    //       ->pluck('product_id');

    //     // $proposaldata = DB::table('et_proposal_package_cart')
    //     //     ->select('*')
    //     //     ->where('product_id', $data->product_id)
    //     //     ->where('status', 0)
    //     //     ->where('proposal_sno', $data->proposal_id)
    //     //     ->first();

    //     $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);

    //     $variant_name = '-';
    //     $variable_name = '-';
    //     $variable_id = 0;
    //     $variant_id = 0;

    //     // Loop through the variant_variable_data if it contains multiple variants/variables
    //     foreach ($variant_variable_data as $pair) {
    //       // Fetch variant and variable data
    //       $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
    //       $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

    //       // If a variant or variable is found, assign them
    //       if ($variant) {
    //         $variant_id = $variant->sno;
    //         $variant_name = $variant->product_variant_name ?? '';
    //       }

    //       if ($variable) {
    //         $variable_id = $variable->sno;
    //         $variable_name = $variable->variable_name ?? '';
    //       }
    //     }
    //     $data->variant_name = $variant_name;
    //     $data->variable_name = $variable_name;
    //     // OLd Fetch task list based on the variant and variable IDs
    //     // $task_list = DB::table('et_product_task_mapping')
    //     //   ->leftJoin('et_product_task', 'et_product_task_mapping.sno', '=', 'et_product_task.map_id')
    //     //   ->where('et_product_task_mapping.variant_id', $variant_id)
    //     //   ->where('et_product_task_mapping.variable_id', $variable_id)
    //     //   ->whereIn('et_product_task_mapping.product_id', $packageProducts)
    //     //   ->where('et_product_task_mapping.status', 0)
    //     //   ->get();

    //     $milestone_mapping = DB::table('et_milestone_mapping')
    //       ->where('customer_id', $data->customer_id)
    //       ->where('proposal_id', $data->proposal_id)
    //       ->where('status', 0)
    //       ->first();

    //     if ($milestone_mapping) {
    //       // Decode JSON string into array if stored as JSON
    //       $task_ids = json_decode($milestone_mapping->unlock_task_ids, true);

    //       if (!empty($task_ids)) {
    //         $task_list = DB::table('et_product_task')
    //           ->whereIn('et_product_task.sno', $task_ids)
    //           ->where('et_product_task.status', 0)
    //           ->get();
    //       } else {
    //         $task_list = collect(); // empty collection
    //       }
    //     } else {
    //       $task_list = collect(); // empty collection if no milestone found
    //     }

    //     // $task_list = DB::table('et_product_task_mapping')
    //     //   ->leftJoin('et_product_task', 'et_product_task_mapping.sno', '=', 'et_product_task.map_id')
    //     //   ->where('et_product_task_mapping.variant_id', $variant_id)
    //     //   ->where('et_product_task_mapping.variable_id', $variable_id)
    //     //   ->whereIn('et_product_task_mapping.product_id', $packageProducts)
    //     //   ->where('et_product_task_mapping.status', 0)
    //     //   ->get();
    //   }

    //   $data->task_list = $task_list;

    //   // return $data;

    //   if (!$data) {
    //     return response([
    //       'status' => 200,
    //       'message' => 'Data Fetching Failed',
    //       'error_msg' => null,
    //       'data' => null
    //     ], 200);
    //   }

    //   return response([
    //     'status' => 200,
    //     'message' => 'Data Fetched Successfully',
    //     'error_msg' => null,
    //     'data' => $data
    //   ], 200);
    // }

    public function Add_task_page($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // ✅ Split the values
        $data = explode('~', $decryptedValue);

        if (count($data) != 2) {
            return redirect()->back()->with('error', 'Invalid Data Format');
        }

        $SNO = $data[0];
        $MILESNO = $data[1];

        return view('content.service_management.manage_service.add_task', [
            'id' => $SNO,
            'mile_id' => $MILESNO,
        ]);
    }

    public function fetch_add_tasks($id, $mileId)
    {
        $data = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->where('et_customer_services.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $items = json_decode($data->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {

            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $data->variant_name = $variantName;
        $data->variable_name = $variableName;

        $tasks = DB::table('et_milestone_history')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_milestone_history.task_id')
            ->leftJoin('et_milestone_mapping', 'et_milestone_mapping.sno', '=', 'et_milestone_history.milestone_id')
            ->select(
                'et_product_task.task_name',
                'et_milestone_history.page_or_per',
                'et_milestone_history.allocated',
                'et_milestone_history.balance',
                'et_product_task.sno',
            )
            ->where('et_milestone_history.milestone_id', $mileId)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->where('et_milestone_history.balance', '>', 0)
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
            'tasks' => $tasks,
        ], 200);
    }

    // public function fetch_add_tasks_pages_percen($task_id, $id = null)
    // {
    //   $data = DB::table('et_customer_services')
    //     ->select(
    //       'et_customer_services.*',
    //       'et_customer.cus_name',
    //       'et_customer.cus_mobile',
    //       'et_product.product_name',
    //       'et_product_category.product_category_name',
    //       'et_product_category.sno as cat_sno'
    //     )
    //     ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    //     ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
    //     ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
    //     ->where('et_customer_services.sno', $id)
    //     ->first();
    //   // Decode staff IDs
    //   $staffIds = json_decode($data->production_staffs_id, true);
    //   if (!is_array($staffIds)) {
    //     $staffIds = explode(',', $data->production_staffs_id);
    //   }
    //   $staffIds = array_filter(array_map('intval', $staffIds));

    //   // Fetch staff
    //   $staffs = [];
    //   if (!empty($staffIds)) {
    //     $staffs = DB::table('et_staff')
    //       ->select('sno', 'staff_name', 'per_hour_cost')
    //       ->whereIn('sno', $staffIds)
    //       ->get();
    //   }

    //   // Attach to response
    //   $data->production_staffs = $staffs;

    //   $task_data = DB::table('et_product_task')
    //     ->select('category_check', 'task_percentage', 'sno as task_sno')
    //     ->where('sno', $task_id)
    //     ->first();

    //   if (!$data || !$task_data) {
    //     return response([
    //       'status' => 404,
    //       'message' => 'Data Fetching Failed',
    //       'error_msg' => null,
    //       'data' => null
    //     ], 404);
    //   }

    //   return response([
    //     'status' => 200,
    //     'message' => 'Data Fetched Successfully',
    //     'error_msg' => null,
    //     'data' => $data,
    //     'task_data' => $task_data
    //   ], 200);
    // }

    public function fetch_add_tasks_pages_percen($task_id, $id, $mileId)
    {
        $data = DB::table('et_milestone_history')
            ->leftJoin('et_milestone_mapping', 'et_milestone_mapping.sno', '=', 'et_milestone_history.milestone_id')
            ->where('et_milestone_history.milestone_id', $mileId)
            ->where('et_milestone_history.task_id', $task_id)
            ->where('et_milestone_mapping.service_id', $id)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->select(
                'et_milestone_history.page_or_per',
                'et_milestone_history.allocated',
                'et_milestone_history.balance'
            )
            ->first();

        $task_data = DB::table('et_product_task')
            ->select('category_check', 'task_percentage', 'sno as task_sno')
            ->where('sno', $task_id)
            ->first();

        $staffRow = DB::table('et_pro_milestone_staffs')
            ->where('service_id', $id)
            ->where('milestone_id', $mileId)
            ->select('staff_ids')
            ->first();

        $staffIds = [];
        if ($staffRow) {
            $staffIds = json_decode($staffRow->staff_ids, true);

            if (! is_array($staffIds)) {
                $staffIds = explode(',', $staffRow->staff_ids);
            }

            $staffIds = array_filter(array_map('intval', $staffIds));
        }

        // Fetch staff
        $staffs = [];
        if (! empty($staffIds)) {
            $staffs = DB::table('et_staff')
                ->select('sno', 'staff_name', 'per_hour_cost')
                ->where('status', 0)
                ->whereIn('sno', $staffIds)
                ->get();
        }

        // Attach to response
        $data->production_staffs = $staffs;

        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
            'task_data' => $task_data,
        ], 200);
    }

    public function fetch_task_check_list($id, $staff_id)
    {
        // Fetch staff data and handle case where staff is not found
        $staff_data = DB::table('et_staff')
            ->where('et_staff.sno', $staff_id)
            ->select('et_staff.employee_skill_id', 'es.employee_skill')
            ->leftJoin('et_employee_skill as es', 'et_staff.employee_skill_id', '=', 'es.sno')
            ->first();

        if (! $staff_data) {
            return response([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Invalid staff ID provided.',
                'data' => null,
            ], 404);
        }

        // Fetch task data and handle case where task is not found
        $data = DB::table('et_product_task')
            ->where('sno', $id)
            ->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Task not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        // Assign employee skill name (default to 'Junior' if not found)
        $data->employee_skill = $staff_data->employee_skill ?? 'Junior';

        // Decode emp_skill JSON data safely
        $emp_skill_data = json_decode($data->emp_skill, true) ?? [];
        // return $emp_skill_data;
        // Determine hours based on skill ID
        $data->hours_id = $this->getHoursBasedOnSkill($emp_skill_data, $staff_data->employee_skill_id);

        // Fetch checklist for the task
        // $task_check_list = DB::table('et_task_checklist')
        //   ->where('product_task_id', $data->sno)
        //   ->where('status', 0)
        //   ->get();

        // $data->task_check_list = $task_check_list;

        $data->task_check_list = [];

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    /**
     * Helper function to determine the hours based on the skill ID.
     *
     * @param  array  $emp_skill_data
     * @param  int  $skill_id
     * @return int
     */
    private function getHoursBasedOnSkill($emp_skill_data, $skill_id)
    {
        if ($skill_id == 0) {
            $skill_id = 1;
        }
        if (isset($emp_skill_data[$skill_id])) {
            return $emp_skill_data[$skill_id]['hours'];
        } elseif (! empty($emp_skill_data)) {
            // Default to the first record if skill ID does not match
            $first = reset($emp_skill_data);

            return $first['hours'];
        } else {
            return 0; // Default value if no skills are available
        }
    }

    public function customerDeliverables($id = '')
    {
        $data = DB::table('et_customer_services')
            ->select(
                'et_customer.cus_name',
                'et_customer.sno as cus_id',
                DB::raw('CASE 
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as service_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_customer_services.sno', $id)
            ->first();

        if (! $data) {
            return response([
                'status' => 302,
                'message' => 'Journal not found',
                'error_msg' => null,
                'data' => null,
            ], 302);
        } else {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        }
    }

    public function get_assign_staff_details($id, $mile)
    {
        $data = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer.customer_id as cus_id',
                'et_staff.staff_name',
                'et_product_category.product_category_name',
                DB::raw('CASE 
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as product_name')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_customer_services.pc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->where('et_customer_services.sno', $id)
            ->first();

        if ($data) {
            $mile_data = DB::table('et_pro_milestone_staffs')->where('service_id', $id)->where('milestone_id', $mile)->first();
            if ($mile_data) {
                $data->production_staffs_id = $mile_data->staff_ids;
            } else {
                $data->production_staffs_id = [];
            }
        }

        if (! $data) {
            return response([
                'status' => 302,
                'message' => 'Data not found',
                'error_msg' => null,
                'data' => null,
            ], 302);
        } else {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        }
    }

    public function update_assign_staff_details(Request $request)
    {
        $request->validate([
            'assignStaffIds' => 'required|array',
        ]);

        $staffIds = $request->input('assignStaffIds');
        $sno = $request->input('customerServicesId');
        $mile = $request->input('customerMileStoneId');
        $user_id = $request->user()->user_id;

        $Update = DB::table('et_customer_services')->where('sno', $sno)->update(['production_staffs_id' => json_encode($staffIds)]);

        $update_mile_staffs = ProductionMilestoneStaffModel::where('service_id', $sno)
            ->where('milestone_id', $mile)
            ->first();

        if ($update_mile_staffs) {
            // Update existing
            $update_mile_staffs->staff_ids = json_encode($staffIds);
            $update_mile_staffs->save();
        } else {
            // Create new
            $new_mile_staff = new ProductionMilestoneStaffModel();
            $new_mile_staff->service_id = $sno;
            $new_mile_staff->milestone_id = $mile;
            $new_mile_staff->created_by = $user_id;
            $new_mile_staff->updated_by = $user_id;
            $new_mile_staff->staff_ids = json_encode($staffIds);
            $new_mile_staff->save();
        }

        if (! $Update) {
            return response()->json(['message' => 'Data Not Found'], 404);
        }

        return response()->json(['message' => 'Staff assigned successfully.']);
    }

    public function get_journal_coordinator(Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $data = StaffModel::where('status', 0)->where('sno', '>', 1)->where('branch_id', $branch_id)->where('role_id', 34)->get();

        if (! $data) {
            return response([
                'status' => 302,
                'message' => 'No Such Staffs !',
                'error_msg' => null,
                'data' => null,
            ], 302);
        } else {
            return response([
                'status' => 200,
                'message' => 'Staff Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        }
    }

    public function readyToDeliver($id, $mileId)
    {
        $data = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids',
                'cre.staff_name as cre_name',
                'pc.staff_name as pc_name',
                'cre.staff_image as cre_image',
                'pc.staff_image as pc_image',
                'et_customer_services.created_at'
            )
            ->first();

        $variantVariableIds = json_decode($data->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($variantVariableIds)) {
            foreach ($variantVariableIds as $v) {
                $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
                $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

                if ($variant) {
                    $variantName = $variant->product_variant_name ?? '';
                }
                if ($variable) {
                    $variableName = $variable->variable_name ?? '';
                }
            }
        }

        $year = date('Y', strtotime($data->created_at));
        $formattedId = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
        $data->formatted_service_id = "SR-{$formattedId}/{$year}";

        $data->variant_name = $variantName;
        $data->variable_name = $variableName;

        $milestoneData = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->where('et_milestone_mapping.sno', $mileId)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->first();

        $productTaskIds = json_decode($milestoneData->task_ids, true) ?? [];

        // ^ TASK NAMES
        $productTasks = DB::table('et_product_task')
            ->whereIn('sno', $productTaskIds)
            ->pluck('task_name')
            ->toArray();

        // ^ STAFF DETAILS
        $staffIdsRaw = DB::table('et_pro_milestone_staffs')
            ->where('service_id', $id)
            ->where('milestone_id', $mileId)
            ->pluck('staff_ids')
            ->toArray();

        $staffIds = [];

        foreach ($staffIdsRaw as $row) {
            $decoded = json_decode($row, true);

            if (is_array($decoded)) {
                $staffIds = array_merge($staffIds, $decoded);
            }
        }

        // Remove duplicates & reindex
        $staffIds = array_unique($staffIds);

        $staffDetails = [];

        if (! empty($staffIds)) {
            $staffDetails = DB::table('et_staff')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->whereIn('et_staff.sno', $staffIds)
                ->where('et_staff.status', 0)
                ->select('et_staff.sno', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
                ->get()
                ->toArray();
        }

        $milestoneData->taskNames = $productTasks;
        $milestoneData->taskCount = count($productTasks);
        $milestoneData->assignedStaffs = $staffDetails;
        $milestoneData->staffCount = count($staffDetails);

        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
            'milestone_data' => $milestoneData,
        ], 200);
    }

    public function submit_verify_completion(Request $request)
    {
        $id = $request->id;
        $mileId = $request->mile_id;
        $deliveryCheck = $request->delivery_checklist;
        $user_id = $request->user()->user_id;

        $deliveryCheckJson = json_encode($deliveryCheck);

        DB::table('et_milestone_mapping')
            ->where('sno', $mileId)
            ->where('service_id', $id)
            ->where('milestone_status', 1)
            ->update([
                'services_status' => 1,
                'delivery_status' => 1,
                'delivery_checklist' => $deliveryCheckJson,
                'updated_by' => $user_id,
            ]);

        return response()->json(['status' => 200, 'message' => 'Checklist updated successfully']);
    }

    public function submit_deliver_completion(Request $request)
    {
        $id = $request->service_id;
        $mileId = $request->milestone_id;
        $user_id = $request->user()->user_id;
        DB::table('et_milestone_mapping')
            ->where('sno', $mileId)
            ->where('service_id', $id)
            ->where('milestone_status', 1)
            ->update([
                'delivery_status' => 1,
                'updated_by' => $user_id,
            ]);

        $updated = DB::table('et_customer_services')
            ->where('sno', $id)
            ->update([
                'service_check' => 2,
                'updated_by' => $user_id,
            ]);

        if ($updated) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Service Delivery Updated Successfully!',
            ]);

            return redirect('/manage_work_order');
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Service Delivery Update Failed!',
            ]);

            return redirect('/manage_work_order');
        }
    }

    public function getCorrectionStaffs($id)
    {
        $milestoneStaffs = DB::table('et_pro_milestone_staffs')
            ->where('milestone_id', $id)
            ->where('status', 0)
            ->select(
                'staff_ids'
            )
            ->first();

        $decodeStaffs = json_decode($milestoneStaffs->staff_ids, true);

        $staffs = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->whereIn('et_staff.sno', $decodeStaffs)
            ->where('et_staff.status', 0)
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_job_position.job_position_name'
            )
            ->get();

        return response([
            'status' => 200,
            'message' => 'Staffs Fetched Successfully!',
            'error_msg' => null,
            'data' => $staffs,
        ], 200);
    }

    public function correctionDataSubmit(Request $request)
    {
        try {
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->user_id;
            $service_id = $request->service_id;
            $milestone_id = $request->milestone_id;
            $tasks = $request->task_data;
            $staffs = $request->staff_data;
            $hours = $request->hours_data ?? [];

            $validator = Validator::make($request->all(), [
                'service_id' => 'required|integer',
                'milestone_id' => 'required|integer',
                'task_data' => 'required|array',
                'task_data.*' => 'required|string',
                'staff_data' => 'required|array',
                'staff_data.*' => 'required|string',
                'hours_data' => 'nullable|array',
                'hours_data.*' => 'nullable|string',
            ]);

            if ($validator->fails()) {
                return response([
                    'status' => 422,
                    'message' => 'Validation Failed',
                    'error_msg' => $validator->errors()->first(),
                    'data' => null,
                ], 422);
            }

            DB::beginTransaction();

            foreach ($tasks as $index => $task) {

                $correction = new CorrectionModel();
                $correction->task_name = $task;
                $correction->staff_id = $staffs[$index];
                $correction->hours = $hours[$index] ?? 0;

                if ($correction->hours == 0) {
                    $correction->is_freedom = 1;
                }

                $correction->service_id = $service_id;
                $correction->milestone_id = $milestone_id;
                $correction->created_by = $user_id;
                $correction->updated_by = $user_id;
                $correction->save();

                if (! $correction->wasRecentlyCreated) {
                    throw new Exception('Failed to create correction.');
                }

                $newCorrection = new DailyTaskModel();
                $newCorrection->service_id = $service_id;
                $newCorrection->task_id = $correction->sno;
                $newCorrection->is_correction = 1;
                $newCorrection->staff_id = $staffs[$index];
                $newCorrection->task_date = now();
                $newCorrection->task_hours = $correction->hours ?? 0;
                $newCorrection->created_by = $user_id;
                $newCorrection->updated_by = $user_id;
                $newCorrection->save();

                if (! $newCorrection->wasRecentlyCreated) {
                    throw new Exception('Failed to create new task.');
                }
            }

            DB::commit();

            return response([
                'status' => 200,
                'message' => 'Correction Saved Successfully!',
                'error_msg' => null,
                'data' => 'null',
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Failed to map milestone',
                'error_msg' => $e->getMessage(),
                'data' => null,
            ], 500);
        }
    }

    public function submit_rework(Request $request)
    {
        $user_id = $request->user()->user_id;
        $serviceId = $request->id;
        $milestoneId = $request->mile_id;
        $tasks = $request->task_ids;
        $reasons = $request->task_reasons;

        $etTasks = DB::table('et_task')
            ->where('service_id', $serviceId)
            ->where('milestone_id', $milestoneId)
            ->whereIn('task_name', $tasks)
            ->get();

        $taskIds = $etTasks->pluck('sno')->toArray();

        $dailyTask = DB::table('et_daily_tasks')
            ->whereIn('task_id', $taskIds)
            ->where('service_id', $serviceId)
            ->where('status', 4)
            ->get();

        $newDailyTasks = [];

        foreach ($dailyTask as $task) {
            // return $task->task_id;
            $newDailyTasks[] = [
                'service_id' => $task->service_id,
                'task_id' => $task->task_id,
                'staff_id' => $task->staff_id,
                'task_date' => now(),
                'min_page_or_per' => 0,
                'max_page_or_per' => $task->max_page_or_per,
                'rework_reason' => $reasons[$task->task_id] ?? null,
                'rework_check' => 1,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ];
        }
        DB::table('et_daily_tasks')->insert($newDailyTasks);

        return response([
            'status' => 200,
            'message' => 'Rework Added Successfully!',
            'error_msg' => 'Rework Adding Failed!',
            'data' => null,
        ], 200);
    }

    private function token()
    {
        $client_id = config('services.google_drive.client_id');
        $client_secret = config('services.google_drive.client_secret');
        $refresh_token = config('services.google_drive.refresh_token');

        try {
            $google_response = Http::post('https://oauth2.googleapis.com/token', [
                'client_id' => $client_id,
                'client_secret' => $client_secret,
                'refresh_token' => $refresh_token,
                'grant_type' => 'refresh_token',
            ]);

            if ($google_response->successful()) {
                return $google_response->json()['access_token'];
            }

            throw new \Exception('Failed to get Google Drive access token');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function createSession(Request $request)
    {
        $request->validate([
            'file_name' => 'required|string',
            'file_size' => 'required|integer|min:1',
            'mime_type' => 'required|string',
            'chunk_size' => 'sometimes|integer',
        ]);

        try {
            $accessToken = $this->token();
            $folder_id = config('services.google_drive.folder_id');

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Type' => 'application/json; charset=UTF-8',
                'X-Upload-Content-Type' => $request->mime_type,
                'X-Upload-Content-Length' => $request->file_size,
            ])->timeout(30)->post(
                'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable',
                [
                    'name' => $request->file_name,
                    'parents' => [$folder_id],
                ]
            );

            if (! $response->successful()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to create Google Drive session',
                ], 500);
            }

            $uploadUrl = $response->header('Location');
            $sessionId = md5($uploadUrl . time() . $request->file_name);
            $chunkSize = $request->chunk_size ?: (5 * 1024 * 1024); // Default 5MB

            // Store session with chunk info
            $uploadSession = UploadSession::create([
                'session_id' => $sessionId,
                'upload_url' => $uploadUrl,
                'file_name' => $request->file_name,
                'file_size' => $request->file_size,
                'mime_type' => $request->mime_type,
                'chunk_size' => $chunkSize,
                'expires_at' => Carbon::now()->addHours(24), // Longer expiry for large files
                'metadata' => [
                    'folder_id' => $folder_id,
                    'total_chunks' => ceil($request->file_size / $chunkSize),
                    'uploaded_chunks' => [],
                    'created_at' => now()->toISOString(),
                ],
            ]);

            return response()->json([
                'success' => true,
                'upload_url' => route('drive.upload.chunk'),
                'session_id' => $sessionId,
                'file_name' => $request->file_name,
                'chunk_size' => $chunkSize,
                'total_chunks' => ceil($request->file_size / $chunkSize),
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to create upload session', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Server error: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function uploadChunk(Request $request)
    {
        $request->validate([
            'chunk' => 'required|file',
            'session_id' => 'required|string',
            'file_name' => 'required|string',
            'chunk_index' => 'required|integer',
            'range_start' => 'required|integer',
            'range_end' => 'required|integer',
            'total_size' => 'required|integer',
            'total_chunks' => 'required|integer',
        ]);

        // Validate session
        $session = UploadSession::where('session_id', $request->session_id)
            ->valid()
            ->first();

        if (! $session) {
            return response()->json([
                'success' => false,
                'message' => 'Upload session not found or expired',
            ], 404);
        }

        try {
            $accessToken = $this->token();

            // Read chunk content
            $chunkContent = file_get_contents($request->file('chunk')->path());
            $chunkSize = strlen($chunkContent);

            // Upload to Google Drive
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Length' => $chunkSize,
                'Content-Range' => sprintf(
                    'bytes %d-%d/%d',
                    $request->range_start,
                    $request->range_end,
                    $request->total_size
                ),
            ])->withBody($chunkContent, 'application/octet-stream')
                ->timeout(180) // 3 minutes timeout for large chunks
                ->put($session->upload_url);

            if ($response->status() === 200 || $response->status() === 201) {
                // Chunk uploaded successfully
                $result = $response->json();

                // Update session with uploaded chunk
                $metadata = $session->metadata;
                $metadata['uploaded_chunks'][] = $request->chunk_index;
                $metadata['uploaded_chunks'] = array_unique($metadata['uploaded_chunks']);
                sort($metadata['uploaded_chunks']);

                $session->update([
                    'metadata' => $metadata,
                    'expires_at' => Carbon::now()->addHours(24),
                ]);

                return response()->json([
                    'success' => true,
                    'chunk_index' => $request->chunk_index,
                    'uploaded_chunks' => $metadata['uploaded_chunks'],
                ]);
            } elseif ($response->status() === 308) {
                // Partial success
                $metadata = $session->metadata;
                $metadata['uploaded_chunks'][] = $request->chunk_index;
                $metadata['uploaded_chunks'] = array_unique($metadata['uploaded_chunks']);
                sort($metadata['uploaded_chunks']);

                $session->update([
                    'metadata' => $metadata,
                    'expires_at' => Carbon::now()->addHours(24),
                ]);

                return response()->json([
                    'success' => true,
                    'chunk_index' => $request->chunk_index,
                    'uploaded_chunks' => $metadata['uploaded_chunks'],
                ]);
            } else {
                Log::error('Google Drive upload failed', [
                    'status' => $response->status(),
                    'error' => $response->body(),
                ]);

                return response()->json([
                    'success' => false,
                    'message' => 'Upload failed with status: ' . $response->status(),
                ], $response->status());
            }
        } catch (\Exception $e) {
            Log::error('Chunk upload error', [
                'error' => $e->getMessage(),
                'chunk_index' => $request->chunk_index,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Server error: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function getUploadStatus(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
            'file_name' => 'required|string',
            'total_size' => 'required|integer',
        ]);

        $session = UploadSession::where('session_id', $request->session_id)
            ->valid()
            ->first();

        if (! $session) {
            return response()->json([
                'success' => false,
                'message' => 'Upload session not found or expired',
            ], 404);
        }

        try {
            // Check Google Drive status
            $accessToken = $this->token();
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Range' => 'bytes */' . $request->total_size,
                'Content-Length' => '0',
            ])->timeout(30)->put($session->upload_url);

            $metadata = $session->metadata;
            $uploadedChunks = $metadata['uploaded_chunks'] ?? [];

            if ($response->status() === 308) {
                $rangeHeader = $response->header('Range');
                $bytesReceived = 0;

                if ($rangeHeader) {
                    preg_match('/bytes=0-(\d+)/', $rangeHeader, $matches);
                    if ($matches && isset($matches[1])) {
                        $bytesReceived = (int) $matches[1];
                    }
                }

                return response()->json([
                    'success' => true,
                    'bytes_received' => $bytesReceived,
                    'uploaded_chunks' => $uploadedChunks,
                    'total_chunks' => $metadata['total_chunks'] ?? 0,
                ]);
            } elseif ($response->status() === 200 || $response->status() === 201) {
                $result = $response->json();

                // Clean up
                $session->delete();

                return response()->json([
                    'success' => true,
                    'complete' => true,
                    'file_id' => $result['id'] ?? null,
                    'uploaded_chunks' => range(0, $metadata['total_chunks'] - 1),
                ]);
            } else {
                return response()->json([
                    'success' => true,
                    'uploaded_chunks' => $uploadedChunks,
                    'total_chunks' => $metadata['total_chunks'] ?? 0,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Status check error', ['error' => $e->getMessage()]);

            $metadata = $session->metadata;

            return response()->json([
                'success' => true,
                'uploaded_chunks' => $metadata['uploaded_chunks'] ?? [],
                'total_chunks' => $metadata['total_chunks'] ?? 0,
            ]);
        }
    }

    public function finalizeUpload(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
            'file_name' => 'required|string',
        ]);

        $session = UploadSession::where('session_id', $request->session_id)
            ->valid()
            ->first();

        if (! $session) {
            return response()->json([
                'success' => false,
                'message' => 'Upload session not found',
            ], 404);
        }

        try {
            $accessToken = $this->token();

            // Final check with Google Drive
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Range' => 'bytes */' . $session->file_size,
                'Content-Length' => '0',
            ])->timeout(30)->put($session->upload_url);

            if ($response->status() === 200 || $response->status() === 201) {
                $result = $response->json();

                $session->delete();

                return response()->json([
                    'success' => true,
                    'file_id' => $result['id'] ?? null,
                    'name' => $result['name'] ?? $session->file_name,
                    'message' => 'Upload completed successfully',
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Upload not complete yet',
                ], 400);
            }
        } catch (\Exception $e) {
            Log::error('Finalize error', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Server error: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function pauseUpload(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
        ]);

        $session = UploadSession::where('session_id', $request->session_id)->first();

        if ($session) {
            // Extend expiry to 7 days when paused
            $session->update(['expires_at' => Carbon::now()->addDays(7)]);

            return response()->json([
                'success' => true,
                'message' => 'Upload paused. You can resume within 7 days.',
                'resume_url' => route('drive.upload.status', ['session_id' => $session->session_id]),
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Session not found',
        ], 404);
    }

    public function getUploadProgress(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
        ]);

        $session = UploadSession::where('session_id', $request->session_id)
            ->valid()
            ->first();

        if (! $session) {
            return response()->json([
                'success' => false,
                'message' => 'Session not found or expired',
            ], 404);
        }

        $metadata = $session->metadata;
        $uploadedChunks = $metadata['uploaded_chunks'] ?? [];
        $totalChunks = $metadata['total_chunks'] ?? 0;
        $uploadedBytes = count($uploadedChunks) * $session->chunk_size;

        if ($uploadedBytes > $session->file_size) {
            $uploadedBytes = $session->file_size;
        }

        return response()->json([
            'success' => true,
            'file_name' => $session->file_name,
            'file_size' => $session->file_size,
            'uploaded_bytes' => $uploadedBytes,
            'percentage' => $session->file_size > 0 ? round(($uploadedBytes / $session->file_size) * 100, 2) : 0,
            'uploaded_chunks' => $uploadedChunks,
            'total_chunks' => $totalChunks,
            'chunk_size' => $session->chunk_size,
            'expires_at' => $session->expires_at->toISOString(),
            'can_resume' => $uploadedBytes < $session->file_size,
        ]);
    }

    // Clean up expired sessions (run this via scheduler)
    public static function cleanupExpiredSessions()
    {
        $deleted = UploadSession::where('expires_at', '<', now())->delete();
        Log::info('Cleaned up expired upload sessions', ['count' => $deleted]);

        return $deleted;
    }
}