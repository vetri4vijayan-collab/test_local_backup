<?php

namespace App\Http\Controllers\requirement_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ManageRequirementModel;
use App\Models\ManageRequirementDocs;
use App\Models\RequirementReasonModel;
use App\Models\LeadModel;
use App\Models\RequirementDocModel;
use Illuminate\Support\Facades\Validator;

class RequirementManage extends Controller
{

  public function index(Request $request)
  {
    $page         = $request->input('page', 1);
    $perpage      = (int) $request->input('sorting_filter', 25);
    $offset       = ($page - 1) * $perpage;
    $branch_id    = $request->user()->branch_id ?? 1;
    $entity_id    = $request->user()->entity_id ?? 1;
    $currentMonth = date('m');
    $currentYear = date('Y');
    $user_id    = $request->user()->user_id ?? 1;

    // ----------------------- BASIC PARAMS -----------------------
    $entity_id = $request->user()->entity_id;
    $branch_id = $request->user()->branch_id;

    // ----------------------- FILTER ------------------------------
    $lead_fill = $request->lead_fill;

    $user_role_id = $request->user()->role_id;


    // ************************************************************
    // 1️⃣ REQUIREMENT TYPE = 1 (LEAD BASED)
    // ************************************************************
    $lead_req = ManageRequirementModel::select(
      'et_manage_requirement.*',
      'et_lead.lead_name',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_id AS lead_ai_id',
      'et_lead.registered_date',
      'et_lead.service_id',
      'et_lead.lead_mobile',
      DB::raw("NULL as cus_name"),
      DB::raw("NULL as cus_mobile"),
      DB::raw("NULL as cus_email_id"),
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      'created_staff.staff_name as created_staff_name',
      'created_staff_job.job_position_name as created_staff_job_name',
      DB::raw('(SELECT COUNT(*) 
              FROM et_manage_requirement_docs 
              WHERE et_manage_requirement_docs.requirement_id = et_manage_requirement.sno 
              AND status != 2) AS requirement_count')
    )
      ->leftJoin('et_lead', 'et_manage_requirement.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
      ->leftJoin('et_staff as created_staff', 'et_manage_requirement.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_job_position as created_staff_job', 'created_staff_job.sno', '=', 'created_staff.position_role')
      ->where('et_manage_requirement.requirement_type', 1)
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id);

    // Search Filter
    if (!empty($lead_fill)) {
      $lead_req->where(function ($q) use ($lead_fill) {
        $q->where('et_lead.lead_name', 'LIKE', "%$lead_fill%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%$lead_fill%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%$lead_fill%");
      });
    }
    $user_role_id = $request->user()->role_id;
    if (in_array($user_role_id, [15, 33])) {
      $lead_req->where('et_manage_requirement.pc_id', $user_id);
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $lead_req->where('et_manage_requirement.staff_id', $user_id);
    } elseif (in_array($user_role_id, [11, 16, 35])) {
      $lead_req->where('et_manage_requirement.created_by', $user_id);
    }

    $lead_results = $lead_req->get();



    // ************************************************************
    // 2️⃣ REQUIREMENT TYPE = 2 (CUSTOMER BASED)
    // ************************************************************
    $customer_req = ManageRequirementModel::select(
      'et_manage_requirement.*',
      'et_manage_requirement.service_id AS Req_service_id',
      DB::raw("NULL as lead_name"),
      DB::raw("NULL as lead_email_id"),
      DB::raw("NULL as lead_gender"),
      DB::raw("NULL as lead_id"),
      DB::raw("NULL as service_id"),
      DB::raw("NULL as lead_mobile"),
      'et_lead.registered_date',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.customer_id AS cus_ai_id',
      'et_customer.cus_email_id',
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      'created_staff.staff_name as created_staff_name',
      'created_staff_job.job_position_name as created_staff_job_name',
      DB::raw('(SELECT COUNT(*) 
              FROM et_manage_requirement_docs 
              WHERE et_manage_requirement_docs.requirement_id = et_manage_requirement.sno 
              AND status != 2) AS requirement_count')
    )
      ->leftJoin('et_customer', 'et_manage_requirement.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
      ->leftJoin('et_staff as created_staff', 'et_manage_requirement.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_job_position as created_staff_job', 'created_staff_job.sno', '=', 'created_staff.position_role')
      ->whereIn('et_manage_requirement.requirement_type', [2, 3])
      ->where('et_customer.branch_id', $branch_id);

    // Search Filter
    if (!empty($lead_fill)) {
      $customer_req->where(function ($q) use ($lead_fill) {
        $q->where('et_customer.cus_name', 'LIKE', "%$lead_fill%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%$lead_fill%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%$lead_fill%");
      });
    }

    // PC & Jtl
    if (in_array($user_role_id, [15, 33])) {
      $customer_req->where('et_manage_requirement.pc_id', $user_id);
      //staff
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $customer_req->where('et_manage_requirement.staff_id', $user_id);
      // Sale 
    } elseif (in_array($user_role_id, [11, 16, 35])) {
      $customer_req->where('et_manage_requirement.created_by', $user_id);
    }

    $customer_results = $customer_req->get();

    // ************************************************************
    // 3️⃣ MERGE BOTH ARRAYS
    // ************************************************************
    $final = $lead_results->merge($customer_results);

    // SORT DESCENDING BY REQUIREMENT ID
    $final = $final->sortByDesc('sno')->values();



    // PAGINATE MANUALLY
    $page = request()->get('page', 1);
    $paginated = new \Illuminate\Pagination\LengthAwarePaginator(
      $final->slice(($page - 1) * $perpage, $perpage)->values(),
      $final->count(),
      $perpage,
      $page,
      ['path' => request()->url(), 'query' => request()->query()]
    );


    foreach ($paginated as $req) {
      if ($req->requirement_type == 1) {
        $serviceIds = json_decode($req->service_id, true);
        if (!is_array($serviceIds)) {
          continue;
        }
        $products = DB::table('et_product')->select('et_product_category.product_category_name', 'et_product.product_name')
          ->whereIn('et_product.sno', $serviceIds)->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')->get();
        // Extract product names 
        $productNames = $products->pluck('product_name')->toArray();
        $req->product_name = implode(', ', $productNames);
        // e.g., "product1, product2" 
        // Extract unique category names 
        $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
        $req->product_category_name = implode(', ', $uniqueCategories);
        // e.g., "Category1, Category2" 
      }
      if ($req->requirement_type == 2 || $req->requirement_type == 3) {
        $serviceId =  $req->Req_service_id;
        $services = DB::table('et_customer_services')->where('sno', $serviceId)->pluck('product_id');
        $serviceIds = json_decode($services, true);
        if (!is_array($serviceIds)) {
          continue;
        }
        $products   = DB::table('et_product')->select('et_product_category.product_category_name', 'et_product.product_name')
          ->whereIn('et_product.sno', $serviceIds)
          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
          ->get();
        // Extract product names 
        $productNames = $products->pluck('product_name')->toArray();
        $req->product_name = implode(', ', $productNames);
        // e.g., "product1, product2" // Extract unique category names 
        $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
        $req->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
      }
    }


    // ************************************************************
    // 4️⃣ RETURN FINAL COMBINED DATA
    // ************************************************************
    // return $paginated;



    $reasonList_reject = DB::table('et_requirement_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    $dbcounts = DB::table('et_manage_requirement')
      ->selectRaw('
        SUM(CASE WHEN requirement_type = 1 THEN 1 ELSE 0 END) as leads,
        SUM(CASE WHEN requirement_type = 2 THEN 1 ELSE 0 END) as customers,
        SUM(CASE WHEN requirement_type = 3 THEN 1 ELSE 0 END) as journals,
        SUM(CASE WHEN rc_chk = 1 THEN 1 ELSE 0 END) as rc,
        SUM(CASE WHEN correction_chk = 1 THEN 1 ELSE 0 END) as corrections
    ');

    // PC & Jtl
    if (in_array($user_role_id, [15, 33])) {
      $dbcounts->where('et_manage_requirement.pc_id', $user_id);
      //staff
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $dbcounts->where('et_manage_requirement.staff_id', $user_id);
      // Sale 
    } elseif (in_array($user_role_id, [11, 35])) {
      $dbcounts->where('et_manage_requirement.created_by', $user_id);
    }
    $dbcounts = $dbcounts->first();

    return view('content.requirement_management.requirements_list', [
      'perpage'           => $perpage,
      'lead_requirements'      => $paginated,
      'reasonList_reject'      => $reasonList_reject,
      'lead_fill'         => $lead_fill,
      'dbcounts'         => $dbcounts,
      'requirement_management_filter'  => '',
    ]);
  }

  public function filter($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $ids = $helper->encrypt_decrypt($id, 'decrypt');
    if ($ids === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $requirement_management_filter = $ids;


    $page         = $request->input('page', 1);
    $perpage      = (int) $request->input('sorting_filter', 25);
    $offset       = ($page - 1) * $perpage;
    $branch_id    = $request->user()->branch_id ?? 1;
    $entity_id    = $request->user()->entity_id ?? 1;
    $currentMonth = date('m');
    $currentYear = date('Y');
    $user_id    = $request->user()->user_id ?? 1;

    // ----------------------- BASIC PARAMS -----------------------
    $entity_id = $request->user()->entity_id;
    $branch_id = $request->user()->branch_id;

    // ----------------------- FILTER ------------------------------
    $lead_fill = $request->lead_fill;

    $user_role_id = $request->user()->role_id;


    // ************************************************************
    // 1️⃣ REQUIREMENT TYPE = 1 (LEAD BASED)
    // ************************************************************
    $lead_req = ManageRequirementModel::select(
      'et_manage_requirement.*',
      'et_lead.lead_name',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_id AS lead_ai_id',
      'et_lead.registered_date',
      'et_lead.service_id',
      'et_lead.lead_mobile',
      DB::raw("NULL as cus_name"),
      DB::raw("NULL as cus_mobile"),
      DB::raw("NULL as cus_email_id"),
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      'created_staff.staff_name as created_staff_name',
      'created_staff_job.job_position_name as created_staff_job_name',
      DB::raw('(SELECT COUNT(*) 
              FROM et_manage_requirement_docs 
              WHERE et_manage_requirement_docs.requirement_id = et_manage_requirement.sno 
              AND status != 2) AS requirement_count')
    )
      ->leftJoin('et_lead', 'et_manage_requirement.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
      ->leftJoin('et_staff as created_staff', 'et_manage_requirement.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_job_position as created_staff_job', 'created_staff_job.sno', '=', 'created_staff.position_role')
      ->where('et_manage_requirement.requirement_type', 1)
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id);

    // Search Filter
    if (!empty($lead_fill)) {
      $lead_req->where(function ($q) use ($lead_fill) {
        $q->where('et_lead.lead_name', 'LIKE', "%$lead_fill%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%$lead_fill%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%$lead_fill%");
      });
    }

    if ($requirement_management_filter == 1) {
      $lead_req->where('et_manage_requirement.requirement_type', 1);
    }


    if (in_array($user_role_id, [15, 33])) {
      $lead_req->where('et_manage_requirement.pc_id', $user_id);
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $lead_req->where('et_manage_requirement.staff_id', $user_id);
    } elseif (in_array($user_role_id, [11, 35])) {
      $lead_req->where('et_manage_requirement.created_by', $user_id);
    }

    $lead_results = $lead_req->get();



    // ************************************************************
    // 2️⃣ REQUIREMENT TYPE = 2 (CUSTOMER BASED)
    // ************************************************************
    $customer_req = ManageRequirementModel::select(
      'et_manage_requirement.*',
      'et_manage_requirement.service_id AS Req_service_id',
      DB::raw("NULL as lead_name"),
      DB::raw("NULL as lead_email_id"),
      DB::raw("NULL as lead_gender"),
      DB::raw("NULL as lead_id"),
      DB::raw("NULL as service_id"),
      DB::raw("NULL as lead_mobile"),
      'et_lead.registered_date',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.customer_id AS cus_ai_id',
      'et_customer.cus_email_id',
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      'created_staff.staff_name as created_staff_name',
      'created_staff_job.job_position_name as created_staff_job_name',
      DB::raw('(SELECT COUNT(*) 
              FROM et_manage_requirement_docs 
              WHERE et_manage_requirement_docs.requirement_id = et_manage_requirement.sno 
              AND status != 2) AS requirement_count')
    )
      ->leftJoin('et_customer', 'et_manage_requirement.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
      ->leftJoin('et_staff as created_staff', 'et_manage_requirement.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_job_position as created_staff_job', 'created_staff_job.sno', '=', 'created_staff.position_role')
      ->whereIn('et_manage_requirement.requirement_type', [2, 3])
      ->where('et_customer.branch_id', $branch_id);

    // Search Filter
    if (!empty($lead_fill)) {
      $customer_req->where(function ($q) use ($lead_fill) {
        $q->where('et_customer.cus_name', 'LIKE', "%$lead_fill%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%$lead_fill%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%$lead_fill%");
      });
    }

    if (in_array($requirement_management_filter, [2, 3])) {
      $customer_req->where('et_manage_requirement.requirement_type', $requirement_management_filter);
    }

    if ($requirement_management_filter == 5) {
      $customer_req->where('et_manage_requirement.correction_chk', 1);
    }

    if ($requirement_management_filter == 4) {
      $customer_req->where('et_manage_requirement.rc_chk', 1);
    }



    // PC & Jtl
    if (in_array($user_role_id, [15, 33])) {
      $customer_req->where('et_manage_requirement.pc_id', $user_id);
      //staff
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $customer_req->where('et_manage_requirement.staff_id', $user_id);
      // Sale 
    } elseif (in_array($user_role_id, [11, 35])) {
      $customer_req->where('et_manage_requirement.created_by', $user_id);
    }

    // $customer_results = $customer_req->get();

    if ($requirement_management_filter == 1) {

      // ONLY LEADS
      $final = $lead_req->get();
    } elseif (in_array($requirement_management_filter, [2, 3, 4, 5])) {

      // ONLY CUSTOMER BASED
      $final = $customer_req->get();
    } else {

      // NO FILTER → ALL
      $final = $lead_req->get()->merge($customer_req->get());
    }




    // ************************************************************
    // 3️⃣ MERGE BOTH ARRAYS
    // ************************************************************
    $final = $final->sortByDesc('sno')->values();



    // PAGINATE MANUALLY
    $page = request()->get('page', 1);
    $paginated = new \Illuminate\Pagination\LengthAwarePaginator(
      $final->slice(($page - 1) * $perpage, $perpage)->values(),
      $final->count(),
      $perpage,
      $page,
      ['path' => request()->url(), 'query' => request()->query()]
    );


    foreach ($paginated as $req) {
      if ($req->requirement_type == 1) {
        $serviceIds = json_decode($req->service_id, true);
        if (!is_array($serviceIds)) {
          continue;
        }
        $products = DB::table('et_product')->select('et_product_category.product_category_name', 'et_product.product_name')
          ->whereIn('et_product.sno', $serviceIds)->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')->get();
        // Extract product names 
        $productNames = $products->pluck('product_name')->toArray();
        $req->product_name = implode(', ', $productNames);
        // e.g., "product1, product2" 
        // Extract unique category names 
        $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
        $req->product_category_name = implode(', ', $uniqueCategories);
        // e.g., "Category1, Category2" 
      }
      if ($req->requirement_type == 2 || $req->requirement_type == 3) {
        $serviceId =  $req->Req_service_id;
        $services = DB::table('et_customer_services')->where('sno', $serviceId)->pluck('product_id');
        $serviceIds = json_decode($services, true);
        if (!is_array($serviceIds)) {
          continue;
        }
        $products   = DB::table('et_product')->select('et_product_category.product_category_name', 'et_product.product_name')
          ->whereIn('et_product.sno', $serviceIds)
          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
          ->get();
        // Extract product names 
        $productNames = $products->pluck('product_name')->toArray();
        $req->product_name = implode(', ', $productNames);
        // e.g., "product1, product2" // Extract unique category names 
        $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
        $req->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
      }
    }


    // ************************************************************
    // 4️⃣ RETURN FINAL COMBINED DATA
    // ************************************************************
    // return $paginated;



    $reasonList_reject = DB::table('et_requirement_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    $dbcounts = DB::table('et_manage_requirement')
      ->selectRaw('
        SUM(CASE WHEN requirement_type = 1 THEN 1 ELSE 0 END) as leads,
        SUM(CASE WHEN requirement_type = 2 THEN 1 ELSE 0 END) as customers,
        SUM(CASE WHEN requirement_type = 3 THEN 1 ELSE 0 END) as journals,
        SUM(CASE WHEN rc_chk = 1 THEN 1 ELSE 0 END) as rc,
        SUM(CASE WHEN correction_chk = 1 THEN 1 ELSE 0 END) as corrections
    ');

    // PC & Jtl
    if (in_array($user_role_id, [15, 33])) {
      $dbcounts->where('et_manage_requirement.pc_id', $user_id);
      //staff
    } elseif (in_array($user_role_id, [32, 34, 36])) {
      $dbcounts->where('et_manage_requirement.staff_id', $user_id);
      // Sale 
    } elseif (in_array($user_role_id, [11, 35])) {
      $dbcounts->where('et_manage_requirement.created_by', $user_id);
    }
    $dbcounts = $dbcounts->first();

    return view('content.requirement_management.requirements_list', [
      'perpage'           => $perpage,
      'lead_requirements'      => $paginated,
      'reasonList_reject'      => $reasonList_reject,
      'lead_fill'         => $lead_fill,
      'dbcounts'         => $dbcounts,
      'requirement_management_filter'  => $requirement_management_filter,
    ]);
  }

  // App\Http\Controllers\RequirementController.php or relevant controller

  public function getAjaxData(Request $request)
  {
    $type = $request->input('type');
    $cus_id = $request->input('cus_id');

    try {
      switch ($type) {

        case 'pc_staff':

          $pcStaff = DB::table('et_staff')
            ->select(
              'et_staff.sno',
              'et_staff.staff_name',
              'et_staff.nick_name',
              'et_job_position.job_position_name'
            )
            ->leftJoin(
              'et_job_position',
              'et_job_position.sno',
              '=',
              'et_staff.position_role'
            )
            ->where('et_staff.role_id', 15)
            ->where('et_staff.status', 0)
            ->orderBy('et_staff.staff_name', 'asc')
            ->get();

          return response()->json([
            'success' => true,
            'data'    => $pcStaff
          ]);


          // ======================================================

        case 'customer_services':

          // Fetch customer services with product & category
          $services = DB::table('et_customer_services')
            ->join('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
            ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->where('et_customer_services.customer_id', $cus_id)
            ->select(
              'et_customer_services.sno',
              'et_customer_services.created_at',
              'et_product.product_name as name',
              'et_product_category.product_category_name'
            )
            ->orderBy('et_product.product_name', 'asc')
            ->get();

          // Format Service ID
          $services = $services->map(function ($service) {
            $year = date('Y', strtotime($service->created_at));
            $srid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$srid}/{$year}";
            return $service;
          });

          return response()->json([
            'success' => true,
            'data' => $services
          ]);



        case 'jtl_staff':
          $jtlStaff = DB::table('et_staff')
            ->select('et_staff.sno', 'et_staff.staff_name',  'et_staff.nick_name', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.role_id', 33)
            ->where('et_staff.status', 0)
            ->orderBy('et_staff.staff_name', 'asc')
            ->get();

          return response()->json([
            'success' => true,
            'data' => $jtlStaff
          ]);

        default:
          return response()->json([
            'success' => false,
            'message' => 'Invalid request type'
          ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => 'Error fetching data: ' . $e->getMessage()
      ], 500);
    }
  }

  public function addUpdateRequirement(Request $request)
  {

    $validated = $request->validate([
      'type' => 'required|in:1,2', // 1=Lead, 2=Customer
      'department' => 'required|exists:departments,sno', // Adjust table name as needed
      'reason' => 'nullable|string|max:500',
      'requirement_name' => 'required|array|min:1',
      'requirement_name.*' => 'required|string|max:255',
      'document_upload.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,csv|max:5120', // 5MB max
    ]);

    // Additional validation based on type
    if ($request->type == 1) {
      $request->validate([
        'lead_id' => 'required|exists:et_lead,sno'
      ]);
    } else {
      $request->validate([
        'customer_id' => 'required|exists:et_customer,sno',
        'service_id' => 'required|exists:et_customer_services,sno'
      ]);
    }

    // Validation based on department
    if ($request->department == 3) { // Journal
      $request->validate([
        'jtl_staff_id' => 'required|exists:et_staff,sno'
      ]);
    } else {
      $request->validate([
        'pc_staff_id' => 'required|exists:et_staff,sno'
      ]);
    }

    try {
      DB::beginTransaction();

      // Save requirement data
      $requirementId = DB::table('et_requirements')->insertGetId([
        'type' => $request->type,
        'lead_id' => $request->type == 1 ? $request->lead_id : null,
        'customer_id' => $request->type == 2 ? $request->customer_id : null,
        'service_id' => $request->type == 2 ? $request->service_id : null,
        'department_id' => $request->department,
        'pc_staff_id' => $request->department != 3 ? $request->pc_staff_id : null,
        'jtl_staff_id' => $request->department == 3 ? $request->jtl_staff_id : null,
        'reason' => $request->reason,
        'status' => 1,
        'created_by' => $request->user()->user_id,
        'created_at' => now(),
      ]);

      // Save requirement points
      foreach ($request->requirement_name as $index => $requirementName) {
        $requirementPointId = DB::table('et_requirement_points')->insertGetId([
          'requirement_id' => $requirementId,
          'point_name' => $requirementName,
          'point_order' => $index + 1,
          'status' => 1,
          'created_at' => now(),
        ]);

        // Handle file uploads
        if ($request->hasFile("document_upload.$index")) {
          $file = $request->file("document_upload.$index");
          $fileName = time() . '_' . $file->getClientOriginalName();
          $filePath = $file->storeAs('requirements', $fileName, 'public');

          DB::table('et_requirement_attachments')->insert([
            'requirement_point_id' => $requirementPointId,
            'file_name' => $fileName,
            'file_path' => $filePath,
            'file_type' => $file->getClientMimeType(),
            'status' => 1,
            'created_at' => now(),
          ]);
        }
      }

      DB::commit();

      return response()->json([
        'success' => true,
        'message' => 'Requirement added successfully!'
      ]);
    } catch (\Exception $e) {
      DB::rollBack();

      return response()->json([
        'success' => false,
        'message' => 'Error adding requirement: ' . $e->getMessage()
      ], 500);
    }
  }

  public function RequirementDetails($id)
  {

    $requirements = ManageRequirementDocs::where('lead_id', $id)->where('status', '!=', 2)->get();
    $leadData = DB::table('et_lead')->select('et_lead.*', 'et_product_category.product_category_name', 'et_product.product_name')->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')->where('et_lead.sno', $id)->first();

    $serviceIds = json_decode($leadData->service_id, true);

    if (is_array($serviceIds) && count($serviceIds) > 0) {
      $products = DB::table('et_product')
        ->select('et_product_category.product_category_name', 'et_product.product_name')
        ->whereIn('et_product.sno', $serviceIds)
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->get();

      // Extract product names
      $productNames = $products->pluck('product_name')->toArray();
      $leadData->product_name = implode(', ', $productNames); // e.g., "product1, product2"

      // Extract unique category names
      $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
      $leadData->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
    } else {
      // Fallback values to avoid further errors
      $leadData->product_name = '';
      $leadData->product_category_name = '';
    }

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'lead'      => $leadData
    ], 200);
  }

  public function RequirementDetailsLead($id)
  {
    $requirements = [];
    $leadData = DB::table('et_lead')->select('et_lead.*', 'et_product_category.product_category_name', 'et_product.product_name')->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')->where('et_lead.sno', $id)->first();

    $serviceIds = json_decode($leadData->service_id, true);

    if (is_array($serviceIds) && count($serviceIds) > 0) {
      $products = DB::table('et_product')
        ->select('et_product.product_name', 'et_product_category.product_category_name')
        ->whereIn('et_product.sno', $serviceIds)
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->get();

      // Create array: "product_name - product_category_name"
      $productNames = [];
      foreach ($products as $item) {
        $productNames[] = $item->product_name . ' - ' . $item->product_category_name;
      }

      $leadData->product_name = implode(', ', $productNames);

      $productBadges = '<ul>'; // Start the unordered list
      foreach ($productNames as $p) {
        $productBadges .= '<li>' . $p . '</li>'; // Add each product as a list item
      }
      $productBadges .= '</ul>';
    } else {
      // Fallback values to avoid further errors
      $productBadges = '';
    }

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'productBadges'      => $productBadges,
      'lead'      => $leadData
    ], 200);
  }

  public function RequirementDetailCustomer($id)
  {
    // Uncomment the following line if the $id should be passed as a parameter
    // $id = 423;
    $requirements = [];
    // Fetch customer data
    $CustomerData = DB::table('et_customer')
      ->select('sno', 'cus_name', 'cus_mobile', 'cus_email_id')
      ->where('sno', $id)
      ->first();

    // Get customer services excluding those with service_check == 2
    $services = DB::table('et_customer_services')
      ->where('customer_id', $id)
      // ->where('service_check', '!=', 2)
      ->get();

    $productNames = [];
    $productBadges = '<ul class="list-group list-group-flush">'; // Initialize the product badges list

    foreach ($services as $si => $service) {
      // Fetch product details and join with categories
      $products = DB::table('et_product')
        ->select('et_product.product_name', 'et_product_category.product_category_name')
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->where('et_product.sno', $service->product_id)
        ->first();

      // Loop through each product to fetch the variant and variable details
      $variantVariableIds = json_decode($service->variant_variable_ids, true);

      $variantName = '';
      $variableName = '';

      // Get variant and variable details if present
      if (is_array($variantVariableIds)) {
        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }
          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }
      }

      // Add product information to the product names list
      $productNames[] = [
        'product_name' => $products->product_name,
        'category' => $products->product_category_name,
        'variant' => $variantName,
        'variable' => $variableName
      ];

      $year = date('Y', strtotime($service->created_at));
      $srid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
      $service_id = "SR-{$srid}/{$year}";

      // Build the product badges list
      $productBadges .= '<li class="list-group-item px-0 pt-0 pb-3 border-bottom">
                              <div>' . ($si + 1) . '. <span class="fw-bold text-primary">' . $service_id . '</span></div>
                              <div class="text-muted fs-7">Product: ' . $products->product_name . ',Category: ' . $products->product_category_name . ', Variant: ' . ($variantName ? $variantName : 'N/A') . ', Variable: ' . ($variableName ? $variableName : 'N/A') . '</div>
                          </li>';
    }

    // Close the unordered list
    $productBadges .= '</ul>';

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'productBadges' => $productBadges,
      'service_count' => count($services) ? count($services) : '0',
      'customer'      => $CustomerData
    ], 200);
  }


  public function StaffList(Request $request)
  {
    $branch_id = $request->user()->branch_id ?? 1;
    $entity_id = $request->user()->entity_id ?? 1;

    $staff =   $staff     = DB::table('et_staff')
      ->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->whereIN('et_staff.role_id', [32, 34, 36])
      ->where('et_staff.branch_id', $branch_id)
      ->orderBy('et_staff.staff_name', 'asc')
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff,
    ], 200);
  }

  public function RequirementView($id)
  {
    $requireData = DB::table('et_manage_requirement')->where('sno', $id)->first();

    if (!$requireData) {
      return response([
        'status' => 404,
        'message' => 'Requirement not found',
      ], 404);
    }

    // ============================================================
    // 1️⃣ REQUIREMENT TYPE = 1  (LEAD BASED)
    // ============================================================
    if ($requireData->requirement_type == 1) {

      $data = ManageRequirementModel::select(
        'et_manage_requirement.*',
        'et_lead.lead_name',
        'et_lead.lead_email_id',
        'et_lead.lead_gender',
        'et_lead.lead_id AS lead_ai_id',
        'et_lead.service_id',
        'et_lead.lead_mobile',
        DB::raw("NULL as cus_name"),
        DB::raw("NULL as cus_mobile"),
        DB::raw("NULL as cus_email_id"),
        'pc_staff.staff_name as pc_name',
        'assign_staff.staff_name as assign_staff_name',
        'pc_job.job_position_name as pc_job_name',
        'assign_staff_job.job_position_name as assign_staff_job_name',
        DB::raw('(SELECT COUNT(*) FROM et_manage_requirement_docs 
                  WHERE requirement_id = et_manage_requirement.sno 
                  AND status != 2) AS requirement_count')
      )
        ->leftJoin('et_lead', 'et_manage_requirement.lead_id', '=', 'et_lead.sno')
        ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
        ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
        ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
        ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
        ->where('et_manage_requirement.sno', $id)
        ->first();

      // Extract Lead Services
      $serviceIds = json_decode($data->service_id, true);

      if (is_array($serviceIds) && count($serviceIds) > 0) {
        $products = DB::table('et_product')
          ->select('et_product_category.product_category_name', 'et_product.product_name')
          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
          ->whereIn('et_product.sno', $serviceIds)
          ->get();

        $data->product_name         = implode(', ', $products->pluck('product_name')->toArray());
        $data->product_category_name = implode(', ', $products->pluck('product_category_name')->unique()->toArray());
      } else {
        $data->product_name = '';
        $data->product_category_name = '';
      }
    }
    // ============================================================
    // 2️⃣ REQUIREMENT TYPE = 2  (CUSTOMER BASED)
    // ============================================================
    else {

      $data = ManageRequirementModel::select(
        'et_manage_requirement.*',
        'et_manage_requirement.service_id as Req_service_id',
        'et_customer.cus_name as lead_name',
        'et_customer.cus_mobile AS lead_mobile',
        'et_customer.cus_email_id',
        'et_customer.customer_id AS lead_ai_id',
        'pc_staff.staff_name as pc_name',
        'assign_staff.staff_name as assign_staff_name',
        'pc_job.job_position_name as pc_job_name',
        'assign_staff_job.job_position_name as assign_staff_job_name',
        DB::raw('(SELECT COUNT(*) FROM et_manage_requirement_docs 
                    WHERE requirement_id = et_manage_requirement.sno 
                    AND status != 2) AS requirement_count')
      )
        ->leftJoin('et_customer', 'et_manage_requirement.customer_id', '=', 'et_customer.sno')
        ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
        ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
        ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
        ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
        ->where('et_manage_requirement.sno', $id)
        ->first();

      $serviceId =  $data->Req_service_id;

      // Fetch Customer Services
      $serviceIds = DB::table('et_customer_services')
        ->where('sno', $serviceId)
        ->pluck('product_id')
        ->toArray();

      if ($serviceIds) {
        $products = DB::table('et_product')
          ->select('et_product_category.product_category_name', 'et_product.product_name')
          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
          ->where('et_product.sno', $serviceIds)
          ->get();

        $data->product_name         = implode(', ', $products->pluck('product_name')->toArray());
        $data->product_category_name = implode(', ', $products->pluck('product_category_name')->unique()->toArray());
      } else {
        $data->product_name = '';
        $data->product_category_name = '';
      }
    }

    // ============================================================
    // REQUIREMENT DOCUMENTS
    // ============================================================
    $requirementsDocument = DB::table('et_manage_requirement_docs')
      ->where('requirement_id', $id)
      ->where('status', '!=', 2)
      ->get();

    return response([
      'status'  => 200,
      'message' => null,
      'data'    => $requirementsDocument,
      'requireData'    => $requireData,
      'details' => $data
    ], 200);
  }

  public function RequirementReject(Request $request)
  {

    // return $request;
    $id     = $request->requirement_id_reject;
    $type   = $request->requirement_approval_type;
    $userId = $request->user()->user_id ?? 1;
    $user_id = $request->user()->user_id ?? 1;
    $branch_id = $request->user()->branch_id ?? 1;

    $lead = ManageRequirementModel::where('sno', $id)->first();

    if (!$lead) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Requirement not found!'
      ]);
      return redirect()->back();
    }

    // DELIVERY REJECTION
    if ($type === 'delivery') {
      $lead->delivery_status = 2;
      $lead->updated_by = $userId;
      $lead->save();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement Cancelled Successfully!'
      ]);

      return redirect()->back();
    }

    // STAFF / PC REJECTION
    if ($type === 'staff') {
      $lead->staff_approval = 2;
    } elseif ($type === 'pc') {
      $lead->pc_approval = 2;
    }

    // REASON HANDLING
    if ($request->reason_reject_select == 1) {
      // Custom reason text
      if ($type === 'staff') {
        $lead->reason = $request->reject_reason_text;
      } elseif ($type === 'pc') {
        $lead->pc_reason = $request->reject_reason_text;
      }
    } else {
      $rejectReason = RequirementReasonModel::where(
        'reason_name',
        $request->reason_reject_select
      )->first();

      if ($type === 'staff') {
        $lead->reason = $request->reason_reject_select;
        if ($rejectReason && $rejectReason->comments_check == 1) {
          $lead->comments = $request->reject_comments_text;
        }
      } elseif ($type === 'pc') {
        $lead->pc_reason = $request->reason_reject_select;
        if ($rejectReason && $rejectReason->comments_check == 1) {
          $lead->pc_comments = $request->reject_comments_text;
        }
      }
    }

    $lead->updated_by = $userId;
    $lead->save();

    // Add Notification By staff
    if ($lead) {
      if ($type == 'staff') {
        $meassage = 'By Staff ';
        $who = $lead->pc_id;
      } else if ($type == 'pc') {
        $meassage = 'By PC';
        $who = $lead->created_by;
      }
      if ($lead->requirement_type == 1) {

        $leadData = DB::table('et_lead')
          ->where('sno', $lead->lead_id)
          ->first();

        $name = $leadData->lead_name ?? '';
      } elseif (in_array($lead->requirement_type, [2, 3])) {

        $leadData = DB::table('et_customer')
          ->where('sno', $lead->customer_id)
          ->first();

        $name = $leadData->cus_name ?? '';
      }
      $notificationData = [
        'branch_id' => $branch_id,
        'notification_content' => ' <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge bg-gray-300"><i class="mdi mdi mdi-file-arrow-left-right-outline fs-3 text-black"></i></span>
                    </div>
                    <div class="me-2">
                        <a href="javascript:;" class="fs-7 text-primary fw-bold">Requirement Rejected</a>
                        <div class="text-secondary fs-8  fw-bold">' . $name . ' - ' . $meassage . '</div>
                    </div>
                  </div>',
        'who' => $who,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'status' => 0
      ];
      $notificationtype = 'Requirement';
      $newNotification = new \App\Helpers\Helpers();
      $newNotification->createNotificationAssessment($notificationData, $notificationtype, $who);
    }

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Requirement Rejected Successfully!'
    ]);

    return redirect()->back();
  }


  public function RequirementApprove(Request $request)
  {

    // return $request;
    $id = $request->requirement_id_reject;
    $type = $request->requirement_approval_type;
    $docIds = $request->input('require_doc_id');

    $lead = ManageRequirementModel::where('sno', $id)->first();

    $user_id = $request->user()->user_id ?? 1;
    $branch_id = $request->user()->branch_id ?? 1;

    if ($type == "delivery") {
      $lead->delivery_status = 1;
      $lead->updated_by = $user_id;
      $lead->update();
      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Requirement Delivered Successfully!'
        ]);
      }
    } else {
      foreach ($docIds as $docId) {
        $checkbox = $request->input("chck_req_$docId");
        $reason   = $request->input("reason_req_$docId");
        $status   = $checkbox ? 1 : 0;
        $updateData = [
          'requirement_doc_status' => $status,
          'updated_by' => $user_id,
        ];
        $updateData['reason'] = $reason;
        if (!$checkbox && $reason) {
          $updateData['reason'] = $reason;
        }
        $docUpdate = ManageRequirementDocs::where('sno', $docId)->update($updateData);
      }

      if ($type == 'staff') {
        $lead->staff_approval = 1;
        $lead->updated_by = $user_id;
      } else if ($type == 'pc') {
        $lead->pc_approval = 1;
        $lead->updated_by = $user_id;
      }
      $lead->update();

      // Add Notification By staff
      if ($lead) {
        if ($type == 'staff') {
          $meassage = 'By Staff';
          $who = $lead->pc_id;
        } else if ($type == 'pc') {
          $meassage = 'By PC';
          $who = $lead->created_by;
        }
        if ($lead->requirement_type == 1) {

          $leadData = DB::table('et_lead')
            ->where('sno', $lead->lead_id)
            ->first();

          $name = $leadData->lead_name ?? '';
        } elseif (in_array($lead->requirement_type, [2, 3])) {

          $leadData = DB::table('et_customer')
            ->where('sno', $lead->customer_id)
            ->first();

          $name = $leadData->cus_name ?? '';
        }
        $notificationData = [
          'branch_id' => $branch_id,
          'notification_content' => ' <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge bg-gray-300"><i class="mdi mdi mdi-file-arrow-left-right-outline fs-3 text-black"></i></span>
                    </div>
                    <div class="me-2">
                        <a href="javascript:;" class="fs-7 text-primary fw-bold">Requirement Accepted</a>
                        <div class="text-secondary fs-8  fw-bold">' . $name . ' - ' . $meassage . '</div>
                    </div>
                  </div>',
          'who' => $who,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 0
        ];
        $notificationtype = 'Requirement';
        $newNotification = new \App\Helpers\Helpers();
        $newNotification->createNotificationAssessment($notificationData, $notificationtype, $who);
      }

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement Approved Successfully!'
      ]);
    }



    return redirect()->back();
  }

  private function handleFileUpload($file)
  {
    // Get all existing filenames in the requirement_documents directory
    $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);
    $maxIndex = 0;
    foreach ($existingFiles as $existingFile) {
      $basename = pathinfo($existingFile, PATHINFO_FILENAME);
      if (preg_match('/requirement_doc_(\d+)/', $basename, $matches)) {
        $num = (int)$matches[1];
        if ($num > $maxIndex) {
          $maxIndex = $num;
        }
      }
    }

    $nextFileIndex = $maxIndex + 1;
    $extension = $file->getClientOriginalExtension();
    $filename = 'requirement_doc_' . $nextFileIndex . '.' . $extension;
    $file->move(public_path('requirement_documents'), $filename);

    return $filename;
  }

  // Customer Add Requirement
  public function addOrUpdateRequirement_customer(Request $request)
  {

    // return $request;

    //  return $request;
    $validator = Validator::make(
      $request->all(),
      [
        'requirement_lead_id' => 'required|integer',
        'requirement_name' => 'nullable|array',
      ]
    );

    if ($validator->fails()) {
      // return $validator;
      // return 'vali';
      return redirect()->back()->withErrors($validator)->withInput();
    }


    $data = $validator->validated();

    DB::beginTransaction();

    try {
      $leadId      = $data['requirement_lead_id'];
      $leaddata = DB::table('et_customer')->where('sno', $leadId)->select('sno', 'lead_id')->first();
      $branch_id   = $request->user()->branch_id ?? 1;
      $user_id     = $request->user()->user_id ?? 1;
      $entity_id   = $request->user()->entity_id ?? 1;

      // -------- CREATE MAIN REQUIREMENT -------- //
      $leadRequirement = new ManageRequirementModel();
      $leadRequirement->requirement_type = 2;
      $leadRequirement->lead_id          = $leaddata->lead_id ?? 0;
      $leadRequirement->deparment_id     = 1;
      $leadRequirement->customer_id      = $leadId;
      $leadRequirement->pc_id            = $request->pc_staff;
      $leadRequirement->service_id       = $request->customer_services;
      $leadRequirement->correction_chk       = $request->correction_chk ?? 0;
      $leadRequirement->branch_id        = $branch_id;
      $leadRequirement->entity_id        = $entity_id;
      $leadRequirement->created_by       = $user_id;
      $leadRequirement->updated_by       = $user_id;
      $leadRequirement->save();

      // -------- HANDLE MULTIPLE REQUIREMENTS + DOCUMENTS -------- //
      if (!empty($data['requirement_name'])) {

        foreach ($data['requirement_name'] as $index => $reqName) {

          $documentUrl = null;

          // If file exists for this index
          if (!empty($request->document_upload[$index])) {

            $file = $request->document_upload[$index];

            // Get next incremental file name
            $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);

            $maxIndex = 0;
            foreach ($existingFiles as $existingFile) {
              if (preg_match('/requirement_doc_(\d+)/', $existingFile, $matches)) {
                $maxIndex = max($maxIndex, (int)$matches[1]);
              }
            }

            $nextIndex = $maxIndex + 1;
            $extension = $file->getClientOriginalExtension();
            $filename  = "requirement_doc_{$nextIndex}.{$extension}";

            // Move File
            $file->move(public_path('requirement_documents'), $filename);

            $documentUrl = $filename;
          }

          // INSERT INTO DOCUMENT TABLE
          ManageRequirementDocs::create([
            'requirement_id' => $leadRequirement->sno,
            'requirement_name' => $reqName,
            'document_url' => $documentUrl,
            'created_by' => $user_id,
            'updated_by' => $user_id,
          ]);
        }
      }

      DB::commit();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement added successfully!'
      ]);

      return redirect('requirement_management/manage_requirement');
    } catch (\Exception $e) {

      DB::rollBack();
      // return 'else'.$e->getMessage();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Error: ' . $e->getMessage()
      ]);

      return redirect()->back()->withInput();
    }
  }

  public function RequirementDetails_customer($id)
  {
    // Get lead + customer + product + category details
    $leadData = DB::table('et_customer_services')
      ->select(
        'et_customer_services.*',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id AS cus_id',
        'et_product.product_name',
        'et_product.duration',
        'et_product.duration_in',
        'et_product_category.product_category_name'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->where('et_customer_services.sno', $id)
      ->first();

    // Handle missing data gracefully
    if (!$leadData) {
      return response([
        'status'    => 404,
        'message'   => 'Customer service record not found',
        'error_msg' => 'Invalid ID or data not found',
        'data'      => null,
        'lead'      => null
      ], 404);
    }

    // Fetch requirement documents using lead_id
    $requirements = ManageRequirementDocs::where('lead_id', $leadData->lead_id)
      ->where('status', '!=', 2)
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'lead'      => $leadData
    ], 200);
  }

  // Lead Add requirement
  public function addOrUpdateRequirement(Request $request)
  {
    //  return $request;
    $validator = Validator::make(
      $request->all(),
      [
        'requirement_lead_id' => 'required|integer',
        'requirement_name' => 'nullable|array',
        'requirement_name_*' => 'nullable|array',
        'requirement_name.*' => 'nullable|string',
        'requirement_name_.*' => 'nullable|string',
        // 'document_upload' => 'nullable|array', 
        // 'document_upload.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx'
      ]
    );

    if ($validator->fails()) {
      // return $validator;
      // return 'vali';
      return redirect()->back()->withErrors($validator)->withInput();
    }


    $data = $validator->validated();

    DB::beginTransaction();

    try {
      $leadId      = $data['requirement_lead_id'];
      $branch_id   = $request->user()->branch_id ?? 1;
      $user_id     = $request->user()->user_id ?? 1;
      $entity_id   = $request->user()->entity_id ?? 1;

      // -------- CREATE MAIN REQUIREMENT -------- //
      $leadRequirement = new ManageRequirementModel();
      $leadRequirement->requirement_type = 1;
      $leadRequirement->lead_id          = $leadId;
      $leadRequirement->deparment_id     = 1;
      $leadRequirement->customer_id      = 0;
      $leadRequirement->pc_id            = $request->pc_staff;
      $leadRequirement->service_id       = $branch_id;
      $leadRequirement->branch_id        = $branch_id;
      $leadRequirement->entity_id        = $entity_id;
      $leadRequirement->created_by       = $user_id;
      $leadRequirement->updated_by       = $user_id;
      $leadRequirement->save();

      // -------- HANDLE MULTIPLE REQUIREMENTS + DOCUMENTS -------- //
      if (!empty($data['requirement_name'])) {

        foreach ($data['requirement_name'] as $index => $reqName) {

          $documentUrl = null;

          // If file exists for this index
          if (!empty($request->document_upload[$index])) {

            $file = $request->document_upload[$index];

            // Get next incremental file name
            $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);

            $maxIndex = 0;
            foreach ($existingFiles as $existingFile) {
              if (preg_match('/requirement_doc_(\d+)/', $existingFile, $matches)) {
                $maxIndex = max($maxIndex, (int)$matches[1]);
              }
            }

            $nextIndex = $maxIndex + 1;
            $extension = $file->getClientOriginalExtension();
            $filename  = "requirement_doc_{$nextIndex}.{$extension}";

            // Move File
            $file->move(public_path('requirement_documents'), $filename);

            $documentUrl = $filename;
          }

          // INSERT INTO DOCUMENT TABLE
          ManageRequirementDocs::create([
            'requirement_id' => $leadRequirement->sno,
            'requirement_name' => $reqName,
            'document_url' => $documentUrl,
            'created_by' => $user_id,
            'updated_by' => $user_id,
          ]);
        }
      }

      // Add Notification By staff
      if ($leadRequirement) {

        $leadData = DB::table('et_lead')->where('sno', $leadRequirement->lead_id)->first();
        $notificationData = [
          'branch_id' => $branch_id,
          'notification_content' => ' <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge bg-gray-300"><i class="mdi mdi mdi-file-arrow-left-right-outline fs-3 text-black"></i></span>
                    </div>
                    <div class="me-2">
                        <a href="javascript:;" class="fs-7 text-primary fw-bold">New Lead Requirement</a>
                        <div class="text-secondary fs-8  fw-bold">' . $leadData->lead_name . '</div>
                    </div>
                  </div>',
          'who' => $leadRequirement->pc_id,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 0
        ];
        $notificationtype = 'Requirement';
        $newNotification = new \App\Helpers\Helpers();

        $newNotification->createNotificationAssessment($notificationData, $notificationtype, $leadRequirement->pc_id);
      }

      DB::commit();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement added successfully!'
      ]);

      return redirect('requirement_management/manage_requirement');
    } catch (\Exception $e) {

      DB::rollBack();
      // return 'else'.$e->getMessage();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Error: ' . $e->getMessage()
      ]);

      return redirect()->back()->withInput();
    }
  }

  public function ManageRequirementIndex(Request $request)
  {
    $page         = $request->input('page', 1);
    $perpage      = (int) $request->input('sorting_filter', 25);
    $offset       = ($page - 1) * $perpage;
    $branch_id    = $request->user()->branch_id ?? 1;
    $entity_id    = $request->user()->entity_id ?? 1;
    $currentMonth = date('m');
    $currentYear = date('Y');
    $user_id    = $request->user()->user_id ?? 1;

    $lead_fill        = $request->lead_fill ?? '';


    $lead_requirements = ManageRequirementModel::select(
      'et_manage_requirement.*',
      'et_lead.lead_name',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_id',
      'et_lead.service_id',
      'et_lead.lead_mobile',
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'et_product_category.product_category_name',
      'et_product.product_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      DB::raw('(SELECT COUNT(*) FROM et_manage_requirement_docs WHERE et_manage_requirement_docs.lead_id = et_manage_requirement.lead_id and status !=2) AS requirement_count')
    )

      ->join('et_lead', 'et_manage_requirement.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')
      ->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', "=", "pc_staff.position_role")
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', "=", "assign_staff.position_role")
      ->whereNotIn('et_lead.status', [2, 4])
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)
      ->orderBy('et_manage_requirement.sno', 'desc');

    if ($lead_fill != '') {
      $lead_requirements->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }


    // if (auth()->user()->hasPermissionradio('P Management', 'Manage Requirments', 'view_self_lead')) {
    //   // User can only view their own data
    //   $lead_requirements = $lead_requirements->where('et_manage_requirement.staff_id', $user_id);
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Requirments', 'global_lead')) {
    //   // User can view all data
    //   $lead_requirements = $lead_requirements;
    //   // return "global_lead";
    // } else {
    //   // No permission
    //   abort(403, 'Unauthorized');
    // }

    $lead_requirements = $lead_requirements->paginate($perpage);

    foreach ($lead_requirements as $req) {
      $serviceIds = json_decode($req->service_id, true);
      if (!is_array($serviceIds)) {
        continue;
      }
      $products = DB::table('et_product')
        ->select('et_product_category.product_category_name', 'et_product.product_name')
        ->whereIn('et_product.sno', $serviceIds)
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->get();

      // Extract product names
      $productNames = $products->pluck('product_name')->toArray();
      $req->product_name = implode(', ', $productNames); // e.g., "product1, product2"

      // Extract unique category names
      $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
      $req->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
    }

    $reasonList_reject = DB::table('et_requirement_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    return view('content.production_management.manage_requirement.manage_requirement', [
      'perpage'           => $perpage,
      'lead_requirements'      => $lead_requirements,
      'reasonList_reject'      => $reasonList_reject,
      'lead_fill'         => $lead_fill,
    ]);
  }

  public function AssignPCRequirement(Request $request)
  {
    $id = $request->assign_requirement_id;
    $user_id = $request->user()->user_id ?? 1;
    $branch_id = $request->user()->branch_id ?? 1;
    $lead    = ManageRequirementModel::where('sno', $id)->first();

    if ($lead) {
      $lead->staff_id    = $request->assign_staff_id;
      $lead->updated_by   = $user_id;
      $lead->update();
      if ($lead->update()) {
        // Add Notification By staff
        if ($lead) {
          if ($lead->requirement_type == 1) {

            $leadData = DB::table('et_lead')
              ->where('sno', $lead->lead_id)
              ->first();

            $name = $leadData->lead_name ?? '';
          } elseif (in_array($lead->requirement_type, [2, 3])) {

            $leadData = DB::table('et_customer')
              ->where('sno', $lead->customer_id)
              ->first();

            $name = $leadData->cus_name ?? '';
          }
          $notificationData = [
            'branch_id' => $branch_id,
            'notification_content' => ' <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge bg-gray-300"><i class="mdi mdi mdi-file-arrow-left-right-outline fs-3 text-black"></i></span>
                    </div>
                    <div class="me-2">
                        <a href="javascript:;" class="fs-7 text-primary fw-bold">New Requirement Assigned</a>
                        <div class="text-secondary fs-8  fw-bold">' . $name . '</div>
                    </div>
                  </div>',
            'who' => $lead->staff_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status' => 0
          ];
          $notificationtype = 'Requirement';
          $newNotification = new \App\Helpers\Helpers();
          $newNotification->createNotificationAssessment($notificationData, $notificationtype, $lead->staff_id);
        }
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Staff Assigned Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Could Not Update Staff!'
        ]);
      }
    }
    return redirect()->back();
  }

  public function AssignStaffUpdateRequirement(Request $request)
  {
    $id = $request->assign_requirement_id;
    $user_id = $request->user()->user_id ?? 1;
    $lead    = ManageRequirementModel::where('sno', $id)->first();

    if ($lead) {
      $lead->staff_id    = $request->assign_staff_id;
      $lead->updated_by   = $user_id;
      $lead->update();
      if ($lead->update()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => ' Staff Updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Could Not Update!'
        ]);
      }
    }
    return redirect()->back();
  }

  public function RequirementViewSts($id)
  {
    // ============================================================
    // Fetch main requirement data
    // ============================================================
    $requireData = DB::table('et_manage_requirement')->where('sno', $id)->first();

    if (!$requireData) {
      return response([
        'status' => 404,
        'message' => 'Requirement not found'
      ], 404);
    }

    // ============================================================
    // Fetch Requirement Documents
    // ============================================================
    $requirementsDocument = DB::table('et_manage_requirement_docs')
      ->where('requirement_id', $id)
      ->where('status', '!=', 2)
      ->get();

    // ============================================================
    // REQUIREMENT TYPE = 1 (LEAD BASED)
    // ============================================================
    if ($requireData->requirement_type == 1) {

      $data = ManageRequirementModel::select(
        'et_manage_requirement.*',
        'et_lead.lead_name',
        'et_lead.lead_email_id',
        'et_lead.lead_id As lead_ai_id',
        'et_lead.lead_gender',
        'et_lead.lead_mobile',
        'et_lead.service_id',
        'pc_staff.staff_name as pc_name',
        'assign_staff.staff_name as assign_staff_name',
        'pc_job.job_position_name as pc_job_name',
        'assign_staff_job.job_position_name as assign_staff_job_name',
        DB::raw('(SELECT COUNT(*) FROM et_manage_requirement_docs 
                      WHERE requirement_id = et_manage_requirement.sno 
                      AND status != 2) AS requirement_count')
      )
        ->leftJoin('et_lead', 'et_manage_requirement.lead_id', '=', 'et_lead.sno')
        ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
        ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
        ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
        ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
        ->where('et_manage_requirement.sno', $id)
        ->first();

      $serviceIds = json_decode($data->service_id, true) ?? [];
    }
    // ============================================================
    // REQUIREMENT TYPE = 2 (CUSTOMER BASED)
    // ============================================================
    else {

      $data = ManageRequirementModel::select(
        'et_manage_requirement.*',
        'et_manage_requirement.service_id AS Req_service_id',
        'et_customer.cus_name as lead_name',
        'et_customer.cus_mobile as lead_mobile',
        'et_customer.cus_email_id as lead_email_id',
        'et_customer.customer_id As lead_ai_id',
        'pc_staff.staff_name as pc_name',
        'assign_staff.staff_name as assign_staff_name',
        'pc_job.job_position_name as pc_job_name',
        'assign_staff_job.job_position_name as assign_staff_job_name',
        DB::raw('(SELECT COUNT(*) FROM et_manage_requirement_docs 
                      WHERE requirement_id = et_manage_requirement.sno 
                      AND status != 2) AS requirement_count')
      )
        ->leftJoin('et_customer', 'et_manage_requirement.customer_id', '=', 'et_customer.sno')
        ->leftJoin('et_staff as assign_staff', 'et_manage_requirement.staff_id', '=', 'assign_staff.sno')
        ->leftJoin('et_staff as pc_staff', 'et_manage_requirement.pc_id', '=', 'pc_staff.sno')
        ->leftJoin('et_job_position as pc_job', 'pc_job.sno', '=', 'pc_staff.position_role')
        ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', '=', 'assign_staff.position_role')
        ->where('et_manage_requirement.sno', $id)
        ->first();
      $serviceId =  $data->Req_service_id;
      $serviceIds = DB::table('et_customer_services')
        ->where('sno', $serviceId)
        ->pluck('product_id')
        ->toArray();
    }

    // $serviceIds;
    // ============================================================
    // Fetch Product Names
    // ============================================================
    if (!empty($serviceIds)) {
      $products = DB::table('et_product')
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->whereIn('et_product.sno', $serviceIds)
        ->get();

      $data->product_name = $products->pluck('product_name')->implode(', ');
      $data->product_category_name = $products->pluck('product_category_name')->unique()->implode(', ');
    } else {
      $data->product_name = '';
      $data->product_category_name = '';
    }
    // ============================================================
    // Final Response
    // ============================================================
    return response([
      'status' => 200,
      'documents' => $requirementsDocument,
      'lead' => $data
    ], 200);
  }

  // Customer Add Requirement
  public function addOrUpdateRequirement_jnlcustomer(Request $request)
  {

    // return $request;

    $validator = Validator::make(
      $request->all(),
      [
        'requirement_lead_id' => 'required|integer',
        'requirement_name' => 'nullable|array',
      ]
    );

    if ($validator->fails()) {
      // return $validator;
      // return 'vali';
      return redirect()->back()->withErrors($validator)->withInput();
    }


    $data = $validator->validated();

    DB::beginTransaction();

    try {
      $leadId      = $data['requirement_lead_id'];
      $leaddata = DB::table('et_customer')->where('sno', $leadId)->select('sno', 'lead_id')->first();
      $branch_id   = $request->user()->branch_id ?? 1;
      $user_id     = $request->user()->user_id ?? 1;
      $entity_id   = $request->user()->entity_id ?? 1;

      // -------- CREATE MAIN REQUIREMENT -------- //
      $leadRequirement = new ManageRequirementModel();
      $leadRequirement->requirement_type = 3;
      $leadRequirement->lead_id          = $leaddata->lead_id ?? 0;
      $leadRequirement->deparment_id     = 1;
      $leadRequirement->customer_id      = $leadId;
      $leadRequirement->pc_id            = $request->pc_staff;
      $leadRequirement->service_id       = $request->requirement_service_id;
      $leadRequirement->rc_chk           = $request->rc_chk ?? 0;
      $leadRequirement->branch_id        = $branch_id;
      $leadRequirement->entity_id        = $entity_id;
      $leadRequirement->created_by       = $user_id;
      $leadRequirement->updated_by       = $user_id;
      $leadRequirement->save();

      // -------- HANDLE MULTIPLE REQUIREMENTS + DOCUMENTS -------- //
      if (!empty($data['requirement_name'])) {

        foreach ($data['requirement_name'] as $index => $reqName) {

          $documentUrl = null;

          // If file exists for this index
          if (!empty($request->document_upload[$index])) {

            $file = $request->document_upload[$index];

            // Get next incremental file name
            $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);

            $maxIndex = 0;
            foreach ($existingFiles as $existingFile) {
              if (preg_match('/requirement_doc_(\d+)/', $existingFile, $matches)) {
                $maxIndex = max($maxIndex, (int)$matches[1]);
              }
            }

            $nextIndex = $maxIndex + 1;
            $extension = $file->getClientOriginalExtension();
            $filename  = "requirement_doc_{$nextIndex}.{$extension}";

            // Move File
            $file->move(public_path('requirement_documents'), $filename);

            $documentUrl = $filename;
          }

          // INSERT INTO DOCUMENT TABLE
          ManageRequirementDocs::create([
            'requirement_id' => $leadRequirement->sno,
            'requirement_name' => $reqName,
            'document_url' => $documentUrl,
            'created_by' => $user_id,
            'updated_by' => $user_id,
          ]);
        }
      }

      DB::commit();
      //  return 'if';
      //  return $leadRequirement;

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement added successfully!'
      ]);

      return redirect('requirement_management/manage_requirement');
    } catch (\Exception $e) {

      DB::rollBack();
      return 'else' . $e->getMessage();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Error: ' . $e->getMessage()
      ]);

      return redirect()->back()->withInput();
    }
  }

  public function RequirementDetails_jnlcustomer($id)
  {
    // Uncomment the following line if the $id should be passed as a parameter
    // $id = 423;
    $requirements = [];

    // return $journal = DB::table('et_manage_journal')->where('sno', $id)->first();

    $services = DB::table('et_customer_services')
      ->where('sno', $id)
      // ->where('service_check', '!=', 2)
      ->get();

    // Fetch customer data
    $CustomerData = DB::table('et_customer')
      ->select('sno', 'cus_name', 'cus_mobile')
      ->where('sno', $services[0]->customer_id)
      ->first();

    // Get customer services excluding those with service_check == 2


    $productNames = [];
    $productBadges = '<ul class="list-group list-group-flush">'; // Initialize the product badges list

    foreach ($services as $si => $service) {
      // Fetch product details and join with categories
      $products = DB::table('et_product')
        ->select('et_product.product_name', 'et_product_category.product_category_name')
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->where('et_product.sno', $service->product_id)
        ->first();

      // Loop through each product to fetch the variant and variable details
      $variantVariableIds = json_decode($service->variant_variable_ids, true);

      $variantName = '';
      $variableName = '';

      // Get variant and variable details if present
      if (is_array($variantVariableIds)) {
        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }
          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }
      }

      // Add product information to the product names list
      $productNames[] = [
        'product_name' => $products->product_name,
        'category' => $products->product_category_name,
        'variant' => $variantName,
        'variable' => $variableName
      ];

      $year = date('Y', strtotime($service->created_at));
      $srid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
      $service_id = "SR-{$srid}/{$year}";

      // Build the product badges list
      $productBadges .= '
                        <li class="list-group-item px-0 pt-0 pb-3 border-bottom">
                            <div>
                                <span class="fw-bold text-primary">' . $service_id . '</span>
                            </div>

                            <div class="fw-bold text-gray-600">Product:</div>
                            <div class="fw-semibold text-primary">
                                ' . ($products->product_name ?? 'N/A') . '
                            </div>

                            <div class="fw-bold text-gray-600">Category:</div>
                            <div class="fw-semibold text-primary">
                                ' . ($products->product_category_name ?? 'N/A') . '
                            </div>

                            <div class="fw-bold text-gray-600">Variant:</div>
                            <div class="fw-semibold text-primary">
                                ' . (!empty($variantName) ? $variantName : 'N/A') . '
                            </div>

                            <div class="fw-bold text-gray-600">Variable:</div>
                            <div class="fw-semibold text-primary">
                                ' . (!empty($variableName) ? $variableName : 'N/A') . '
                            </div>
                        </li>';
    }

    // Close the unordered list
    $productBadges .= '</ul>';

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'productBadges' => $productBadges,
      'customer'      => $CustomerData
    ], 200);
  }
}
