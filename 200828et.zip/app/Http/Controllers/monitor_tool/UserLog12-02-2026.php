<?php

namespace App\Http\Controllers\monitor_tool;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
class UserLog extends Controller
{
  public function index()
  {
    
    return view('content.monitor_tool.user_log.user_log');
  }

public function List(Request $request)
{
    $query = DB::table('user_login_logs as ull')
        ->leftJoin('users as u', 'u.id', '=', 'ull.user_id')
         ->where('ull.user_id', '>', 0)
        ->leftJoin('et_branch as b', function ($join) {
            $join->on('b.sno', '=', 'u.branch_id')
                 ->where('b.status', '=', 0);
        })
        ->select('ull.*', 'u.branch_id', 'b.branch_name', 'b.franchise_name');

    // 🔍 Search filter (IP or username)
    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('ull.ip_address', 'LIKE', "%{$search}%")
              ->orWhere('ull.user_name', 'LIKE', "%{$search}%");
        });
    }

    // ⚙️ Type filter (Success / Failed)
    if ($request->filled('type') && $request->type !== '') {
        $query->where('ull.type', $request->type);
    }

    // 🏢 Branch filter
    if ($request->filled('branch_id') && $request->branch_id != '0') {
        $query->where('u.branch_id', $request->branch_id);
    }
    else
    {
        $query->where('u.branch_id', $request->branch_id);
    }

    // 🧩 Department filter
    if ($request->filled('department_id') && $request->department_id != '0') {
        $departmentId = $request->department_id;

        $query->whereExists(function ($sub) use ($departmentId) {
            $sub->select(DB::raw(1))
                ->from('et_staff as st')
                ->join('users as su', 'su.user_id', '=', 'st.sno')
                ->whereColumn('su.id', 'ull.user_id')
                ->where('st.department_id', $departmentId)
                ->where('st.status', 0);
        });
    }

    // ✅ Sort by latest login
    $query->orderBy('ull.login_at', 'desc');

    // ✅ Paginate + format
    $logs = $query->paginate(20)->through(function ($log) {
        $dateTime = \Carbon\Carbon::parse($log->login_at)
            ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');

        $branchName = 'Unknown';
        $branchId = null;

        if (!empty($log->branch_id)) {
            $branchId = $log->branch_id;
            $branchName = $log->franchise_name ?: $log->branch_name;
        } else {
            // fallback: lookup last success for IP
            $lastSuccess = DB::table('user_login_logs')
                ->where('ip_address', $log->ip_address)
                ->where('type', 0)
                ->orderBy('login_at', 'desc')
                ->first();

            if ($lastSuccess && $lastSuccess->user_id) {
                $user = \App\Models\User::select('branch_id')->find($lastSuccess->user_id);
                if ($user && $user->branch_id) {
                    $branch = \App\Models\BranchModel::where('status', 0)
                        ->where('sno', $user->branch_id)
                        ->first();
                    if ($branch) {
                        $branchId = $branch->sno;
                        $branchName = $branch->franchise_name ?: $branch->branch_name;
                    }
                }
            }
        }

        return [
            'ip_address'  => $log->ip_address,
            'date_time'   => $dateTime,
            'user_name'   => $log->user_name,
            'password'    => $log->password,
            'login_type'  => $log->type == 0 ? 'Success' : 'Failed',
            'branch_id'   => $branchId,
            'branch_name' => $branchName,
        ];
    });

    return response()->json([
        'status'  => 200,
        'message' => 'User login logs list',
        'data'    => $logs
    ]);
}


public function clearOldLogs(Request $request)
{
    $months = (int) $request->input('months', 0);

    if ($months <= 0) {
        return response()->json([
            'status' => 400,
            'message' => 'Invalid duration selected.'
        ], 400);
    }

    $thresholdDate = now()->subMonths($months);

    $deleted = DB::table('user_login_logs')
        ->where('login_at', '<', $thresholdDate)
        ->delete();

    return response()->json([
        'status' => 200,
        'message' => "Logs older than {$months} month(s) cleared successfully. ({$deleted} records deleted)"
    ]);
}



    

}