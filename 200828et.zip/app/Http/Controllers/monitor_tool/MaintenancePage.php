<?php

namespace App\Http\Controllers\monitor_tool;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\MaintenanceModeModel;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
class MaintenancePage extends Controller
{

 public function show(Request $request)
    {
        $maintenanceData = [
            'slug' => session('maintenance_slug', 'Unknown'),
            'since' => session('maintenance_since', now()),
        ];
        
         return view('content.monitor_tool.maintenance_mode.maintenance_page', $maintenanceData);
    }


    

}