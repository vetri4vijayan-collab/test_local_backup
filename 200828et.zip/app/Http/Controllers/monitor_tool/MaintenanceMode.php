<?php

namespace App\Http\Controllers\monitor_tool;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\MaintenanceModeModel;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
class MaintenanceMode extends Controller
{
 public function index()
{
    $path = resource_path('menu/verticalMenu.json');
    $json = File::get($path);
    $menu = json_decode($json, true);
    
    $branch_id = auth()->user()->branch_id;

    // Get latest status and maintenance date for each slug
    $latestRecords = MaintenanceModeModel::where('branch_id', $branch_id)
        ->select('slug', 'status', 'maintenance_date')
        ->whereIn('sno', function($query) use ($branch_id) {
            $query->selectRaw('MAX(sno)')
                  ->from('et_maintenance_mode')
                  ->groupBy('slug');
        })
        ->get()
        ->keyBy('slug')
        ->toArray();

    // Merge status and date with menu
    $this->addMaintenanceDataToMenu($menu, $latestRecords);

    return view('content.monitor_tool.maintenance_mode.maintenance_mode', compact('menu'));
}

private function addMaintenanceDataToMenu(&$menu, $records)
{
    foreach ($menu['menu'] as &$item) {
        if (isset($item['slug'])) {
            // Using null coalescing operator
            $item['status'] = $records[$item['slug']]['status'] ?? 0;
            $item['maintenance_date'] = $records[$item['slug']]['maintenance_date'] ?? null;
        } else {
            $item['status'] = 0;
            $item['maintenance_date'] = null;
        }

        if (isset($item['submenu'])) {
            $this->addMaintenanceDataToSubmenu($item['submenu'], $records);
        }
    }
}

private function addMaintenanceDataToSubmenu(&$submenu, $records)
{
    foreach ($submenu as &$item) {
        if (isset($item['slug'])) {
            // Using null coalescing operator
            $item['status'] = $records[$item['slug']]['status'] ?? 0;
            $item['maintenance_date'] = $records[$item['slug']]['maintenance_date'] ?? null;
        } else {
            $item['status'] = 0;
            $item['maintenance_date'] = null;
        }

        if (isset($item['submenu'])) {
            $this->addMaintenanceDataToSubmenu($item['submenu'], $records);
        }
    }
}
  
// MaintenanceModeController.php
public function toggle(Request $request)
{
    $slug = $request->slug;
    $status = $request->status;
    $branch_id = $request->user()->branch_id;
    
    // Find existing record
        $existingRecord = MaintenanceModeModel::where('slug', $slug)
                                             ->where('branch_id', $branch_id)
                                             ->latest('sno')
                                             ->first();
        
        $maintenance_date = null;
        
        if ($existingRecord) {
            // Check if both dates are present (complete cycle: maintenance → live)
            $hasBothDates = $existingRecord->maintenance_date && $existingRecord->live_date;
            
            if ($hasBothDates) {
                // Complete cycle exists, create new record
                $record = MaintenanceModeModel::create([
                    'branch_id' => $branch_id,
                    'slug' => $slug,
                    'status' => $status,
                    'maintenance_date' => $status == 1 ? now() : null,
                    'live_date' => $status == 0 ? now() : null
                ]);
                $maintenance_date = $record->maintenance_date;
            } else {
                // Incomplete cycle, update existing record
                if ($status == 1) {
                    $existingRecord->update([
                        'status' => $status,
                        'maintenance_date' => now(),
                        'live_date' => null
                    ]);
                    $maintenance_date = $existingRecord->maintenance_date;
                } else {
                    $existingRecord->update([
                        'status' => $status,
                        'live_date' => now()
                    ]);
                    // Get the current maintenance start time even when switching to live
                    $maintenance_date = $existingRecord->maintenance_date;
                }
            }
        } else {
            // No record exists, create first one
            $record = MaintenanceModeModel::create([
                'branch_id' => $branch_id,
                'slug' => $slug,
                'status' => $status,
                'maintenance_date' => $status == 1 ? now() : null,
                'live_date' => $status == 0 ? now() : null
            ]);
            $maintenance_date = $record->maintenance_date;
        }


    return response()->json([
        'success' => true,
        'message' => $status ? 'Maintenance mode enabled' : 'Live mode enabled',
        'maintenance_date' => $maintenance_date
    ]);
}


public function List(Request $request)
{
    $query = DB::table('user_login_logs as ull')
        ->leftJoin('users as u', 'u.id', '=', 'ull.user_id')
        ->leftJoin('et_branch as b', function ($join) {
            $join->on('b.sno', '=', 'u.branch_id')
                 ->where('b.status', '=', 0);
        })
        ->select('ull.*', 'u.branch_id', 'b.branch_name', 'b.franchise_name');

    // 🔍 Search filter (IP or username)
    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('ull.ip_address', 'LIKE', "%{$search}%")
              ->orWhere('ull.user_name', 'LIKE', "%{$search}%");
        });
    }

    // ⚙️ Type filter (Success / Failed)
    if ($request->filled('type') && $request->type !== '') {
        $query->where('ull.type', $request->type);
    }

    // 🏢 Branch filter
    if ($request->filled('branch_id') && $request->branch_id != '0') {
        $query->where('u.branch_id', $request->branch_id);
    }

    // 🧩 Department filter
    if ($request->filled('department_id') && $request->department_id != '0') {
        $departmentId = $request->department_id;

        $query->whereExists(function ($sub) use ($departmentId) {
            $sub->select(DB::raw(1))
                ->from('et_staff as st')
                ->join('users as su', 'su.user_id', '=', 'st.sno')
                ->whereColumn('su.id', 'ull.user_id')
                ->where('st.department_id', $departmentId)
                ->where('st.status', 0);
        });
    }

    // ✅ Sort by latest login
    $query->orderBy('ull.login_at', 'desc');

    // ✅ Paginate + format
    $logs = $query->paginate(20)->through(function ($log) {
        $dateTime = \Carbon\Carbon::parse($log->login_at)
            ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');

        $branchName = 'Unknown';
        $branchId = null;

        if (!empty($log->branch_id)) {
            $branchId = $log->branch_id;
            $branchName = $log->franchise_name ?: $log->branch_name;
        } else {
            // fallback: lookup last success for IP
            $lastSuccess = DB::table('user_login_logs')
                ->where('ip_address', $log->ip_address)
                ->where('type', 0)
                ->orderBy('login_at', 'desc')
                ->first();

            if ($lastSuccess && $lastSuccess->user_id) {
                $user = \App\Models\User::select('branch_id')->find($lastSuccess->user_id);
                if ($user && $user->branch_id) {
                    $branch = \App\Models\BranchModel::where('status', 0)
                        ->where('sno', $user->branch_id)
                        ->first();
                    if ($branch) {
                        $branchId = $branch->sno;
                        $branchName = $branch->franchise_name ?: $branch->branch_name;
                    }
                }
            }
        }

        return [
            'ip_address'  => $log->ip_address,
            'date_time'   => $dateTime,
            'user_name'   => $log->user_name,
            'password'    => $log->password,
            'login_type'  => $log->type == 0 ? 'Success' : 'Failed',
            'branch_id'   => $branchId,
            'branch_name' => $branchName,
        ];
    });

    return response()->json([
        'status'  => 200,
        'message' => 'User login logs list',
        'data'    => $logs
    ]);
}


public function clearOldLogs(Request $request)
{
    $months = (int) $request->input('months', 0);

    if ($months <= 0) {
        return response()->json([
            'status' => 400,
            'message' => 'Invalid duration selected.'
        ], 400);
    }

    $thresholdDate = now()->subMonths($months);

    $deleted = DB::table('user_login_logs')
        ->where('login_at', '<', $thresholdDate)
        ->delete();

    return response()->json([
        'status' => 200,
        'message' => "Logs older than {$months} month(s) cleared successfully. ({$deleted} records deleted)"
    ]);
}



    

}