<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use App\Models\PriceBookModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PriceBook extends Controller
{
  public function index(Request $request)

    {

        $page = $request->input('page', 1);

        $perpage = (int) $request->input('sorting_filter', 25);

        $offset = ($page - 1) * $perpage;

        $search_fill = $request->search_fill ?? '';

        $branch_id = $request->user()->branch_id;

 

        $latestSnoSubquery = PriceBookModel::select(DB::raw('MAX(sno) as latest_sno'))

            ->where('status', '!=', 2)

            ->groupBy('product_id');

 

        $query = PriceBookModel::select(

            'et_price_book.*',

            'et_product.product_name',

            'et_product_category.product_category_name',

            'et_product.base_price as base_price',

            'et_product.min_amount as min_amount',

            'et_product.max_amount as max_amount'

        )

            ->joinSub($latestSnoSubquery, 'latest_price_book', function ($join) {

                $join->on('et_price_book.sno', '=', 'latest_price_book.latest_sno');

            })

            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')

            ->leftJoin('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')

            ->where('et_product.branch_id', $branch_id)

            ->where('et_price_book.status', 0);

 

        $currencyId = DB::table('et_general_settings')

            ->select('et_general_settings.branch_product_currency')

            ->first();

 

        $currency_codes = json_decode($currencyId->branch_product_currency, true);

 

        $data = DB::table('et_country_currencies')

            ->whereIn('sno', $currency_codes)

            ->get();

 

        if (!empty($search_fill)) {

            $query->where(function ($list) use ($search_fill) {

                $list->where('et_product.product_name', 'LIKE', "%{$search_fill}%");

            });

        }

 

        $ListTable = $query->orderBy('et_price_book.sno', 'desc')

            ->paginate($perpage);

 

        return view('content.product_management.manage_price_book.price_book', [

            'ListTable' => $ListTable,

            'perpage' => $perpage,

            'search_fill' => $search_fill,

            'data' => $data

        ]);

    }

 

    public function currency_accordion (Request $request) {

        $branch_id = $request->user()->branch_id;
        $branch = DB::table('et_general_settings')
            ->select('et_general_settings.branch_product_currency')
            ->first();

        $currency_codes = json_decode($branch->branch_product_currency, true);

        $data = DB::table('et_country_currencies')
            ->whereIn('sno', $currency_codes)
            ->get();

        if($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

    }

    public function product_data_fetch(Request $request) {

 

        $branch_id = $request->user()->branch_id;

 

        $data = DB::table('et_product')

            ->select(

                'et_product.sno',

                'et_product.product_name'

            )

            ->leftJoin('et_price_book', 'et_price_book.product_id', '=', 'et_product.sno')

            ->whereNull('et_price_book.product_id')

            ->where('et_product.branch_id', $branch_id)

            ->where('et_product.status', 0)

            ->get();

 

        if ($data) {

            return response([

                'status' => 200,

                'message' => 'Data Fetched Successfully !',

                'error_msg' => null,

                'data' => $data

            ], 200);

        } else {

            return response([

                'status' => 402,

                'message' => 'Data Fetching Failed!',

                'error_msg' => null,

                'data' => null

            ], 402);

        }

    }


    public function product_variant_data_fetch($id) {
        $data = DB::table('et_manage_product_variable')
            ->select(
                'et_manage_product_variable.*',
                'et_product.base_price',
                'et_product.min_amount',
                'et_product.max_amount'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_manage_product_variable.product_id')
            ->where('et_manage_product_variable.status', 0)
            ->where('et_product.sno', $id)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function store(Request $request)
    {
        $productId = $request->input('product_id');
        $branchId = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $allData = $request->input('data');

        if (empty($productId) || empty($allData)) {
            return response()->json([
                'status' => 400,
                'message' => 'Missing required data',
            ]);
        }

        foreach ($allData as $currencyId => $values) {
            $basePrice = $values['base_price'] ?? 0;
            $minAmount = $values['min_amount'] ?? 0;
            $maxAmount = $values['max_amount'] ?? 0;

            $variantDetails = [];

            if (isset($values['variants']) && is_array($values['variants'])) {
                foreach ($values['variants'] as $variantId => $amount) {
                    $variantDetails[] = [
                        'variable_id' => $variantId,
                        'amount' => $amount,
                    ];
                }
            }

            $create = new PriceBookModel();
            $create->branch_id = $branchId;
            $create->product_id = $productId;
            $create->currency_id = $currencyId;
            $create->base_price = $basePrice;
            $create->min_amount = $minAmount;
            $create->max_amount = $maxAmount;
            $create->varient_details = json_encode($variantDetails);
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->save();
        }

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Price Book Added Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Price Book Adding Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $dataList = PriceBookModel::where('et_price_book.product_id', $id)
            ->select(
                'et_price_book.*',
                'et_product.product_name',
                'et_country_currencies.currency_symbol',
                'et_country_currencies.currency_name',
                'et_product.base_price as product_base',
                'et_product.min_amount as product_min',
                'et_product.max_amount as product_max'
        )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_price_book.currency_id')
            ->get();

        if ($dataList->isEmpty()) {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

        $responseData = $dataList->map(function ($data) {
            $variantDetails = json_decode($data->varient_details, true) ?? [];

            $allVariants = DB::table('et_manage_product_variable')
                ->where('product_id', $data->product_id)
                ->where('status', 0)
                ->get()
                ->keyBy('sno');

            $priceBookVariantAmounts = [];
            foreach ($variantDetails as $v) {
                $priceBookVariantAmounts[$v['variable_id']] = $v['amount'];
            }

            $variantsWithNames = $allVariants->map(function ($variant) use ($priceBookVariantAmounts) {
                return [
                    'variant_id' => $variant->sno,
                    'variant_name' => $variant->variable_name,
                    'amount' => $priceBookVariantAmounts[$variant->sno] ?? '',  // use saved amount or 0 if new
                    'variable_amount' => $variant->variable_amount ?? 0,
                ];
            })->values()->all();


            $arrayData = $data->toArray();
            $arrayData['variants'] = $variantsWithNames;

            return $arrayData;
        });

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully !',
            'error_msg' => null,
            'data' => $responseData
        ], 200);
    }

    public function Update(Request $request)
    {
        $user_id = $request->user()->user_id;
        $allData = $request->input('data');

        foreach ($allData as $currencyData) {
            $sno = $currencyData['sno'] ?? null;
            if (!$sno) {
                continue; 
            }

            $basePrice = $currencyData['base_price'] ?? 0;
            $minAmount = $currencyData['min_amount'] ?? 0;
            $maxAmount = $currencyData['max_amount'] ?? 0;

            $variantDetails = [];
            if (isset($currencyData['variants']) && is_array($currencyData['variants'])) {
                foreach ($currencyData['variants'] as $variantId => $amount) {
                    $variantDetails[] = [
                        'variable_id' => $variantId,
                        'amount' => $amount,
                    ];
                }
            }

            $priceBook = PriceBookModel::where('sno', $sno)->where('status', '!=', 2)->first();
            if (!$priceBook) {
                // Optionally skip or handle missing record
                continue;
            }

            $priceBook->base_price = $basePrice;
            $priceBook->min_amount = $minAmount;
            $priceBook->max_amount = $maxAmount;
            $priceBook->varient_details = json_encode($variantDetails);
            $priceBook->updated_by = $user_id;
            $priceBook->save();
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Price Book Updated Successfully!',
        ]);

        return redirect()->back();
    }

    public function View($id)
    {
        $dataList = PriceBookModel::where('et_price_book.product_id', $id)
            ->select(
                'et_price_book.*',
                'et_product.product_name',
                'et_country_currencies.currency_symbol',
                'et_country_currencies.currency_name',
                'et_product.base_price as product_base',
                'et_product.min_amount as product_min',
                'et_product.max_amount as product_max'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_price_book.currency_id')
            ->get();

        if ($dataList->isEmpty()) {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

        $responseData = $dataList->map(function ($data) {
            $variantDetails = json_decode($data->varient_details, true) ?? [];

            $allVariants = DB::table('et_manage_product_variable')
                ->where('product_id', $data->product_id)
                ->where('status', 0)
                ->get()
                ->keyBy('sno');

            $priceBookVariantAmounts = [];
            foreach ($variantDetails as $v) {
                $priceBookVariantAmounts[$v['variable_id']] = $v['amount'];
            }

            $variantsWithNames = $allVariants->map(function ($variant) use ($priceBookVariantAmounts) {
                return [
                    'variant_id' => $variant->sno,
                    'variant_name' => $variant->variable_name,
                    'amount' => $priceBookVariantAmounts[$variant->sno] ?? '-',  
                    'variable_amount' => $variant->variable_amount ?? 0,
                ];
            })->values()->all();

            $arrayData = $data->toArray();
            $arrayData['variants'] = $variantsWithNames;

            return $arrayData;
        });

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully !',
            'error_msg' => null,
            'data' => $responseData
        ], 200);
    }


 public function package_index(Request $request)

    {

        $page = $request->input('page', 1);

        $perpage = (int) $request->input('sorting_filter', 25);

        $offset = ($page - 1) * $perpage;

        $search_fill = $request->search_fill ?? '';

 

        $latestSnoSubquery = PriceBookModel::select(DB::raw('MAX(sno) as latest_sno'))

            ->where('status', '!=', 2)

            ->groupBy('package_id');

 

        $currencyId = DB::table('et_general_settings')

            ->select('et_general_settings.branch_product_currency')

            ->first();

 

        $currency_codes = json_decode($currencyId->branch_product_currency, true);

 

        $data = DB::table('et_country_currencies')

            ->whereIn('sno', $currency_codes)

            ->get();

 

        $query = PriceBookModel::select(

            'et_price_book.*',

            'et_package.package_name',

            'et_package.base_price as package_base',

            'et_package.min_amount as package_min',

            'et_package.max_amount as package_max'

        )

            ->joinSub($latestSnoSubquery, 'latest_price_book', function ($join) {

                $join->on('et_price_book.sno', '=', 'latest_price_book.latest_sno');

            })

            ->leftJoin('et_package', 'et_package.sno', '=', 'et_price_book.package_id')

            ->where('et_package.branch_id', $request->user()->branch_id)

            ->where('et_price_book.status', 1);

           

 

        if (!empty($search_fill)) {

            $query->where(function ($list) use ($search_fill) {

                $list->where('et_package.package_name', 'LIKE', "%{$search_fill}%");

            });

        }

 

        $ListTable = $query->orderBy('et_price_book.sno', 'desc')

            ->paginate($perpage);

 

        return view('content.product_management.manage_price_book.package_price_book', [

            'ListTable' => $ListTable,

            'perpage' => $perpage,

            'search_fill' => $search_fill,

            'data' => $data

        ]);

    }


   public function package_data_fetch (Request $request) {

        $data = DB::table('et_package')

            ->select(

                'et_package.sno',

                'et_package.package_name'

            )

            ->leftJoin('et_price_book', 'et_price_book.package_id', '=', 'et_package.sno')

            ->whereNull('et_price_book.package_id')

            ->where('et_package.status', 0)

            ->where('et_package.branch_id', $request->user()->branch_id)

            ->get();

 

        if ($data) {

            return response([

                'status' => 200,

                'message' => 'Data Fetched Successfully !',

                'error_msg' => null,

                'data' => $data

            ], 200);

        } else {

            return response([

                'status' => 402,

                'message' => 'Data Fetching Failed!',

                'error_msg' => null,

                'data' => null

            ], 402);

        }

    }

 

    public function package_product_data_fetch($id)
    {
        $packageData = DB::table('et_package_product')
            ->select(
                'et_package_product.*',
                'et_package.base_price',
                'et_package.min_amount',
                'et_package.max_amount',
                'et_package.actual_amount',
                'et_product.product_name',
                'et_product.base_price as product_base_price'
            )
            ->leftJoin('et_package', 'et_package.sno', '=', 'et_package_product.package_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_package_product.product_id')
            ->where('et_package_product.status', 0)
            ->where('et_package.sno', $id)
            ->get();

        $data = [];

        foreach($packageData as $package) {
            $variantData = [];
            $variantJSON = json_decode($package->variant_variable_ids, true);

            if($variantJSON && is_array($variantJSON)) {
                foreach($variantJSON as $variant) {
                    $variantDetails = DB::table('et_manage_product_variant')
                        ->where('sno', $variant['variant_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    $variableDetails = DB::table('et_manage_product_variable')
                        ->where('sno', $variant['variable_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    if($variantDetails && $variableDetails) {
                        $variantData[] = [
                            'variant_id' => $variant['variant_id'],
                            'variable_id' => $variant['variable_id'],
                            'amount' => $variant['amount'],
                            'variant_name' => $variantDetails->product_variant_name,
                            'variable_name' => $variableDetails->variable_name
                        ];
                    }
                }
            }

            $data[] = [
                'product_name' => $package->product_name,
                'product_id' => $package->product_id,
                'package_id' => $package->package_id,
                'base_price' => $package->base_price,
                'min_amount' => $package->min_amount,
                'max_amount' => $package->max_amount,
                'actual_amount' => $package->actual_amount,
                'product_base_price' => $package->product_base_price,
                'variants' => $variantData
            ];
        }

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function add_package_price_book (Request $request) {

        $base_prices = $request->input('base_price');
        $min_amounts = $request->input('min_amount');
        $max_amounts = $request->input('max_amount');
        $currency_ids = $request->input('currency_id');
        $variant_ids = $request->input('variant_id');
        $variable_ids = $request->input('variable_id');
        $actual_amounts = $request->input('actual_amount');
        $product_ids = $request->input('product_id');
        $package_id = $request->package_id;
        $amounts = $request->input('amount');
        $product_base_prices = $request->input('product_base_price');
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        foreach($base_prices as $index => $base_price) {
            $min_amount = $min_amounts[$index] ?? 0;
            $max_amount = $max_amounts[$index] ?? 0;
            $currency_id = $currency_ids[$index] ?? null;
            $actual_amount = $actual_amounts[$index] ?? 0;
            $details = [];

            if(isset($variable_ids[$currency_id])) {
                foreach ($variant_ids[$currency_id] as $i => $variant_id) {
                    $variable_id = $variable_ids[$currency_id][$i] ?? null;
                    $amount = $amounts[$currency_id][$i] ?? null;
                    $product_base_price = $product_base_prices[$currency_id][$i] ?? null;
                    $product_id = $product_ids[$currency_id][$i] ?? null;

                    if ($variant_id && $variable_id && $amount !== null) {
                        $details[] = [
                            'variant_id' => $variant_id,
                            'variable_id' => $variable_id,
                            'amount' => $amount,
                            'base_price' => $product_base_price,
                            'product_id' => $product_id
                        ];
                    }
                }
            }        

            $create = new PriceBookModel();
            $create->branch_id = $branch_id;
            $create->currency_id = $currency_id;
            $create->base_price = $base_price;
            $create->min_amount = $min_amount;
            $create->max_amount = $max_amount;
            $create->actual_price = $actual_amount; 
            $create->package_id = $package_id;
            $create->varient_details = json_encode($details);
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->status = 1;
            $create->save();
        }

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Package Price Book Created Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message'=> 'Package Prize Creation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function package_edit($id)
    {
        $packageData = DB::table('et_package_product')
            ->select(
                'et_package_product.*',
                'et_package.base_price',
                'et_package.min_amount',
                'et_package.max_amount',
                'et_package.actual_amount',
                'et_product.product_name',
                'et_package.package_name',
                'et_product.base_price as product_base_price',
            )
            ->leftJoin('et_package', 'et_package.sno', '=', 'et_package_product.package_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_package_product.product_id')
            ->where('et_package_product.status', 0)
            ->where('et_package.sno', $id)
            ->get();

        $data = [];

        foreach ($packageData as $package) {
            $variantData = [];
            $variantJSON = json_decode($package->variant_variable_ids, true);

            if ($variantJSON && is_array($variantJSON)) {
                foreach ($variantJSON as $variant) {
                    $variantDetails = DB::table('et_manage_product_variant')
                        ->where('sno', $variant['variant_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    $variableDetails = DB::table('et_manage_product_variable')
                        ->where('sno', $variant['variable_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    if ($variantDetails && $variableDetails) {
                        $variantData[] = [
                            'variant_id' => $variant['variant_id'],
                            'variable_id' => $variant['variable_id'],
                            'amount' => $variant['amount'],
                            'variant_name' => $variantDetails->product_variant_name,
                            'variable_name' => $variableDetails->variable_name
                        ];
                    }
                }
            }

            $data[] = [
                'product_name' => $package->product_name,
                'product_id' => $package->product_id,
                'package_id' => $package->package_id,
                'base_price' => $package->base_price,
                'min_amount' => $package->min_amount,
                'max_amount' => $package->max_amount,
                'actual_amount' => $package->actual_amount,
                'package_name' => $package->package_name,
                'product_base_price' => $package->product_base_price,
                'variants' => $variantData
            ];
        }

        $prizeBookData = PriceBookModel::where('package_id', $id)->where('status', 1)->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
                'prizeBook' => $prizeBookData
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function package_update(Request $request) {
        
        $base_prices = $request->input('edit_base_price');
        $min_amounts = $request->input('edit_min_amount');
        $max_amounts = $request->input('edit_max_amount');
        $currency_ids = $request->input('edit_currency_id');
        $variant_ids = $request->input('edit_variant_id');
        $product_ids = $request->input('edit_product_id');
        $variable_ids = $request->input('edit_variable_id');
        $actual_amounts = $request->input('edit_actual_amount');
        $snos = $request->input('edit_id');
        $product_base_prices = $request->input('product_base_price');
        $package_id = $request->edit_package_id;
        $amounts = $request->input('edit_amount');
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        // return $request; 

        foreach ($base_prices as $index => $base_price) {
            $min_amount = $min_amounts[$index] ?? 0;
            $max_amount = $max_amounts[$index] ?? 0;
            $actual_amount = $actual_amounts[$index] ?? 0;
            $currency_id = $currency_ids[$index] ?? null;
            $sno = $snos[$index];
            $details = [];

            if (isset($variable_ids[$currency_id])) {
                foreach ($variant_ids[$currency_id] as $i => $variant_id) {
                    $variable_id = $variable_ids[$currency_id][$i] ?? null;
                    $product_id = $product_ids[$currency_id][$i] ?? null;
                    $amount = $amounts[$currency_id][$i] ?? null;
                    $product_base_price = $product_base_prices[$currency_id][$i] ?? null;

                    if ($variant_id && $variable_id && $amount !== null) {
                        $details[] = [
                            'variant_id' => $variant_id,
                            'variable_id' => $variable_id,
                            'amount' => $amount,
                            'base_price' => $product_base_price,
                            'product_id' => $product_id
                        ];
                    }
                }
            }

            $update = PriceBookModel::where('sno', $sno)->where('status', 1)->first();
            $update->branch_id = $branch_id;
            $update->currency_id = $currency_id;
            $update->base_price = $base_price;
            $update->actual_price = $actual_amount;
            $update->min_amount = $min_amount;
            $update->max_amount = $max_amount;
            $update->package_id = $package_id;
            $update->varient_details = json_encode($details);
            $update->created_by = $user_id;
            $update->updated_by = $user_id;
            $update->save();
        }

        if ($update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Package Price Book Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Package Prize Updation Failed!'
            ]);
        }

        return redirect()->back();
    }
    
    public function package_view($id) {
        $packageData = DB::table('et_package_product')
            ->select(
                'et_package_product.*',
                'et_package.base_price',
                'et_package.min_amount',
                'et_package.max_amount',
                'et_product.product_name',
                'et_package.package_name',
                'et_product.base_price as product_base_price',
            )
            ->leftJoin('et_package', 'et_package.sno', '=', 'et_package_product.package_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_package_product.product_id')
            ->where('et_package_product.status', 0)
            ->where('et_package.sno', $id)
            ->get();

        $data = [];

        foreach ($packageData as $package) {
            $variantData = [];
            $variantJSON = json_decode($package->variant_variable_ids, true);

            if ($variantJSON && is_array($variantJSON)) {
                foreach ($variantJSON as $variant) {
                    $variantDetails = DB::table('et_manage_product_variant')
                        ->where('sno', $variant['variant_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    $variableDetails = DB::table('et_manage_product_variable')
                        ->where('sno', $variant['variable_id'])
                        ->where('status', '!=', 2)
                        ->first();

                    if ($variantDetails && $variableDetails) {
                        $variantData[] = [
                            'variant_id' => $variant['variant_id'],
                            'variable_id' => $variant['variable_id'],
                            'amount' => $variant['amount'],
                            'variant_name' => $variantDetails->product_variant_name,
                            'variable_name' => $variableDetails->variable_name
                        ];
                    }
                }
            }

            $data[] = [
                'product_name' => $package->product_name,
                'product_id' => $package->product_id,
                'package_id' => $package->package_id,
                'base_price' => $package->base_price,
                'min_amount' => $package->min_amount,
                'max_amount' => $package->max_amount,
                'package_name' => $package->package_name,
                'product_base_price' => $package->product_base_price,
                'variants' => $variantData
            ];
        }

        $prizeBookData = PriceBookModel::where('package_id', $id)->where('status', 1)->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
                'prizeBook' => $prizeBookData
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

  public function addon_index(Request $request)

    {

        $page = $request->input('page', 1);

        $perpage = (int) $request->input('sorting_filter', 25);

        $offset = ($page - 1) * $perpage;

        $search_fill = $request->search_fill ?? '';

 

        $latestSnoSubquery = PriceBookModel::select(DB::raw('MAX(sno) as latest_sno'))

            ->where('status', '!=', 2)

            ->groupBy('addon_id');

 

        $currencyId = DB::table('et_general_settings')

            ->select('et_general_settings.branch_product_currency')

            ->first();

 

        $currency_codes = json_decode($currencyId->branch_product_currency, true);

 

        $data = DB::table('et_country_currencies')

            ->whereIn('sno', $currency_codes)

            ->get();

 

        $query = PriceBookModel::select(

            'et_price_book.*',

            'et_manage_addon.addon_name',

            'et_manage_addon.freevariant_count',

            'et_manage_addon.paidvariant_count',

        )

            ->joinSub($latestSnoSubquery, 'latest_price_book', function ($join) {

                $join->on('et_price_book.sno', '=', 'latest_price_book.latest_sno');

            })

            ->leftJoin('et_manage_addon', 'et_manage_addon.sno', '=', 'et_price_book.addon_id')

            ->where('et_price_book.status', 3);

 

        if (!empty($search_fill)) {

            $query->where(function ($list) use ($search_fill) {

                $list->where('et_manage_addon.addon_name', 'LIKE', "%{$search_fill}%");

            });

        }

 

        $ListTable = $query->orderBy('et_price_book.sno', 'desc')

            ->where('et_manage_addon.branch_id', $request->user()->branch_id)

            ->paginate($perpage);

 

        return view('content.product_management.manage_price_book.addon_price_book', [

            'ListTable' => $ListTable,

            'perpage' => $perpage,

            'search_fill' => $search_fill,

            'data' => $data,

        ]);

    }




    public function add_on_data_fetch (Request $request) {

        $data = DB::table('et_manage_addon')

            ->select(

                'et_manage_addon.sno',

                'et_manage_addon.addon_name'

            )

            ->leftJoin('et_price_book', 'et_price_book.addon_id', '=', 'et_manage_addon.sno')

            ->whereNull('et_price_book.addon_id')

            ->where('et_manage_addon.status', 0)

            ->where('et_manage_addon.branch_id', $request->user()->branch_id)

            ->get();

 

        if ($data) {

            return response([

                'status' => 200,

                'message' => 'Data Fetched Successfully !',

                'error_msg' => null,

                'data' => $data

            ], 200);

        } else {

            return response([

                'status' => 402,

                'message' => 'Data Fetching Failed!',

                'error_msg' => null,

                'data' => null

            ], 402);

        }

    }

    public function addon_variant_data_fetch($id)
    {
        $data = DB::table('et_manage_addon_variant')
            ->select(
                'et_manage_addon_variant.amount',
                'et_manage_addon_variant.free_paid',
                'et_addon_variable.addon_variablename as variable_name',
                'et_addon_variable.sno as variable_id',
                'et_addon_varient.addon_varientname as varient_name',
                'et_manage_addon_variant.sno as varient_id',
            )
            ->leftJoin('et_addon_variable', 'et_addon_variable.sno', '=', 'et_manage_addon_variant.variable_id')
            ->leftJoin('et_addon_varient', 'et_addon_varient.sno', '=', 'et_addon_variable.addon_varientid')
            ->where('et_manage_addon_variant.addon_id', $id)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function save_addon_price_book(Request $request)
    {

        $currency_ids = $request->input('currency_id');
        $variant_ids = $request->input('varient_ids');
        $variable_ids = $request->input('variable_ids');
        $addon_id = $request->addon_id;
        $amounts = $request->input('amounts');
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        // return $request;

        foreach ($currency_ids as $index => $currency_id) {
            $details = [];

            if (
                isset($variant_ids[$currency_id]) && is_array($variant_ids[$currency_id]) &&
                isset($variable_ids[$currency_id]) && is_array($variable_ids[$currency_id]) &&
                isset($amounts[$currency_id]) && is_array($amounts[$currency_id])
            ) {
                foreach ($variant_ids[$currency_id] as $i => $variant_id) {
                    $variable_id = $variable_ids[$currency_id][$i] ?? null;
                    $amount = $amounts[$currency_id][$i] ?? null;

                    if ($variant_id && $variable_id && $amount !== null) {
                        $details[] = [
                            'variant_id' => $variant_id,
                            'variable_id' => $variable_id,
                            'amount' => $amount
                        ];
                    }
                }
            }

            $create = new PriceBookModel();
            $create->branch_id = $branch_id;
            $create->currency_id = $currency_id;
            $create->addon_id = $addon_id;
            $create->varient_details = json_encode($details);
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->status = 3;
            $create->save();
        }

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Add On Price Book Created Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Add On Prize Creation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function addon_edit_data($id)
    {
        $data = DB::table('et_manage_addon_variant')
            ->select(
                'et_manage_addon_variant.amount',
                'et_manage_addon_variant.free_paid',
                'et_manage_addon.addon_name',
                'et_addon_variable.addon_variablename as variable_name',
                'et_addon_variable.sno as variable_id',
                'et_addon_varient.addon_varientname as varient_name',
                'et_manage_addon_variant.sno as varient_id',
            )
            ->leftJoin('et_addon_variable', 'et_addon_variable.sno', '=', 'et_manage_addon_variant.variable_id')
            ->leftJoin('et_addon_varient', 'et_addon_varient.sno', '=', 'et_addon_variable.addon_varientid')
            ->leftJoin('et_manage_addon', 'et_manage_addon.sno', '=', 'et_manage_addon_variant.addon_id')
            ->where('et_manage_addon_variant.addon_id', $id)
            ->get();

        $priceBook = PriceBookModel::where('addon_id', $id)->where('status', 3)->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data, 
            'currencies' => $priceBook
        ], 200);
    }

    public function update_addon_price_book(Request $request)
    {

        $currency_ids = $request->input('edit_currency_id');
        $variant_ids = $request->input('edit_varient_ids');
        $variable_ids = $request->input('edit_variable_ids');
        $amounts = $request->input('edit_amounts');
        $user_id = $request->user()->user_id;
        $snos = $request->input('edit_id');

        // return $request;

        foreach ($currency_ids as $index => $currency_id) {
            $details = [];

            if (
                isset($variant_ids[$currency_id]) && is_array($variant_ids[$currency_id]) &&
                isset($variable_ids[$currency_id]) && is_array($variable_ids[$currency_id]) &&
                isset($amounts[$currency_id]) && is_array($amounts[$currency_id])
            ) {
                foreach ($variant_ids[$currency_id] as $i => $variant_id) {
                    $variable_id = $variable_ids[$currency_id][$i] ?? null;
                    $amount = $amounts[$currency_id][$i] ?? null;
                    $sno = $snos[$currency_id] ?? 0;


                    if ($variant_id && $variable_id && $amount !== null) {
                        $details[] = [
                            'variant_id' => $variant_id,
                            'variable_id' => $variable_id,
                            'amount' => $amount
                        ];
                    }
                }
            }

            $create = PriceBookModel::where('sno', $sno)->where('status', 3)->first();
            $create->currency_id = $currency_id;
            $create->varient_details = json_encode($details);
            $create->updated_by = $user_id;
            $create->update();
        }

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Add On Price Book Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Add On Prize Updation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function addon_view_data($id)
    {
        $data = DB::table('et_manage_addon_variant')
            ->select(
                'et_manage_addon_variant.amount',
                'et_manage_addon_variant.free_paid',
                'et_manage_addon.addon_name',
                'et_addon_variable.addon_variablename as variable_name',
                'et_addon_variable.sno as variable_id',
                'et_addon_varient.addon_varientname as varient_name',
                'et_manage_addon_variant.sno as varient_id',
            )
            ->leftJoin('et_addon_variable', 'et_addon_variable.sno', '=', 'et_manage_addon_variant.variable_id')
            ->leftJoin('et_addon_varient', 'et_addon_varient.sno', '=', 'et_addon_variable.addon_varientid')
            ->leftJoin('et_manage_addon', 'et_manage_addon.sno', '=', 'et_manage_addon_variant.addon_id')
            ->where('et_manage_addon_variant.addon_id', $id)
            ->get();

        $priceBook = PriceBookModel::where('addon_id', $id)->where('status', 3)->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data,
            'currencies' => $priceBook
        ], 200);
    }
}
