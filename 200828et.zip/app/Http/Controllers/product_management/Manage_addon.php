<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\ManageAddOnModel;
use App\Models\AddOnModel;
use App\Models\ManageAddOnVariantModel;
use Illuminate\Support\Facades\Validator;


class Manage_addon extends Controller
{

    public function index( Request $request ){
        
        // return $request;
        // Filter
        $page = $request->input('page', 1);
        $search_fill = $request->search_fill ?? '';
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        // Data fetching
        $variants = ManageAddOnVariantModel::where('status', '!=', 2)->first();

        $productVariables = DB::table('et_addon_variable')->where('status', '!=', 2)
        ->select('addon_variablename', 'sno', 'addon_varientid', 'min_cost', 'max_cost')
        ->get();
        $productVariants = DB::table('et_addon_varient')->where('status', '!=', 2)->select('sno', 'addon_varientname')->get();

        // Return the blade
        $addons = ManageAddOnModel::where('status', '!=', 2);
        if ($search_fill  != '') {
            $addons->where(function ($query) use ($search_fill) {
            $query->where('addon_name', 'LIKE', "%{$search_fill}%");
          });
        }
    
        $addons =  $addons->orderBy('sno', 'desc')->get();
        return view('content.product_management.manage_addon.list', compact('addons', 'perpage', 'variants', 'productVariables', 'productVariants','search_fill'));
    }

    public function Edit($id)
    {
        $knowledge = ManageAddOnModel::where('sno', $id)->first();

        if(!$knowledge){
            return response([
                'status' => 404,
                'message' => 'Add-On Data Not Found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        // Get all variant entries for the add on
        $variants = ManageAddOnVariantModel::where('addon_id', $id)->where('status', '!=', 2)->get();

        $pages = DB::table('et_addon_variable')->select('sno as id', 'addon_variablename as name', 'addon_varientid', 'min_cost', 'max_cost')->where('status', '!=', 2)->get();
        $persons = DB::table('et_addon_varient')->select('sno as id', 'addon_varientname as name')->where('status', '!=', 2)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge,
            'variants' => $variants,
            'options' => [
                'pages' => $pages,
                'persons' => $persons,
            ], 
        ], 200);
    }

    public function Update(Request $request)
    {
        $user_id = $request->user()->user_id;

        // Validate main inputs
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|integer|exists:et_manage_addon,sno',
            'edit_addon_name' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $addonId = $request->input('edit_id');
        $addonName = $request->input('edit_addon_name');

        $addon = ManageAddOnModel::find($addonId);
        if (!$addon) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Add-On Record Not Found',
            ]);
            return redirect()->back();
        }

        // Update addon name if changed
        if ($addon->addon_name !== $addonName) {
            $addon->addon_name = $addonName;
            $addon->updated_by = $user_id;
            $addon->save();
        }

        $inputs = $request->all();
        $variantsInput = [];

        // Group variant data by index
        foreach ($inputs as $key => $value) {
            if (preg_match('/^(variant_select|free_price|amount|variant_id)_(\d+)$/', $key, $matches)) {
                $field = $matches[1];
                $index = $matches[2];
                $variantsInput[$index][$field] = $value;
            }
        }

        // Fetch existing active variants
        $existingVariants = ManageAddOnVariantModel::where('addon_id', $addonId)
            ->where('status', '!=', 2)
            ->get()
            ->keyBy('sno');

        $processedVariantIds = [];

        foreach ($variantsInput as $index => $variantData) {
            // Skip incomplete variant entries
            if (empty($variantData['variant_select']) || !isset($variantData['free_price'])) {
                continue;
            }

            $variantId = isset($variantData['variant_id']) && is_numeric($variantData['variant_id']) ? (int)$variantData['variant_id'] : null;
            $variableId = $variantData['variant_select'];
            $freePaid = strtolower($variantData['free_price']) === 'paid' ? 1 : 0;
            $amount = isset($variantData['amount']) ? (float)$variantData['amount'] : 0;

            if ($variantId && $existingVariants->has($variantId)) {
                // Update existing variant
                $variant = $existingVariants[$variantId];

                // Only update if any value has changed
                if ($variantId && $existingVariants->has($variantId)) {
                    $variant = $existingVariants[$variantId];
                    $variant->variable_id = $variableId;
                    $variant->free_paid = $freePaid;
                    $variant->amount = $amount;
                    $variant->updated_by = $user_id;
                    $variant->status = 1;
                    $variant->save();

                    $processedVariantIds[] = $variantId;
                }


                $processedVariantIds[] = $variantId;
            } else {
                // Insert new variant
                $newVariant = new ManageAddOnVariantModel();
                $newVariant->addon_id = $addonId;
                $newVariant->variable_id = $variableId;
                $newVariant->free_paid = $freePaid;
                $newVariant->amount = $amount;
                $newVariant->created_by = $user_id;
                $newVariant->updated_by = $user_id;
                $newVariant->status = 1;
                $newVariant->save();

                $processedVariantIds[] = $newVariant->sno;
            }
        }

        // Soft-delete variants not included in processed list
        ManageAddOnVariantModel::where('addon_id', $addonId)
            ->whereNotIn('sno', $processedVariantIds)
            ->where('status', '!=', 2)
            ->update([
                'status' => 2,
                'updated_by' => $user_id,
            ]);

        // Update variant counts
        $addon->variant_count = ManageAddOnVariantModel::where('addon_id', $addonId)->where('status', '!=', 2)->count();
        $addon->freevariant_count = ManageAddOnVariantModel::where('addon_id', $addonId)->where('free_paid', 0)->where('status', '!=', 2)->count();
        $addon->paidvariant_count = ManageAddOnVariantModel::where('addon_id', $addonId)->where('free_paid', 1)->where('status', '!=', 2)->count();
        $addon->updated_by = $user_id;
        $addon->save();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Add-On Updated Successfully!',
        ]);

        return redirect()->back();
    }

    public function Status($id, Request $request){
        $Status = ManageAddOnModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = $request->input('status', 0);
        $Status->update();

        if($Status){
            return response([
                'status' => 200,
                'message' => 'Status Updated Successfully !',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 401,
                'message' => 'Status Updation Failed !',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 401);
        }
    }

    public function Delete($id){
        $Status = ManageAddOnModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = 2;
        $Status->update();

        return response([
            'status' => 200,
            'message' => 'Status Deleted Successfully !',
            'error_msg' => 'Status Deletion Failed !',
            'data' => null,
        ], 200);
    }

    public function Create(Request $request)
    {
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        // Validate addon name
        $validator = Validator::make($request->all(), [
            'add_on_name' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $addonName = $request->input('add_on_name');

        // Check if name already exists
        $exists = ManageAddOnModel::where('addon_name', $addonName)->where('status', '!=', 2)->exists();
        if ($exists) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Add-On Name Already Exists',
            ]);
            return redirect()->back();
        }

        // Create main addon record
        $addon = new ManageAddOnModel();
        $addon->addon_name = $addonName;
        $addon->created_by = $user_id;
        $addon->updated_by = $user_id;
        $addon->branch_id = $branch_id;
        $addon->variant_count = 0;
        $addon->freevariant_count = 0;
        $addon->paidvariant_count = 0;


        $addon->save();
        $addon->status = 0; // Active
        $addon->save();

        $inputs = $request->all();
        $variantsInput = [];

        // Group variant data by dynamic index (e.g., variant_select_0, free_price_0, amount_0)
        foreach ($request->all() as $key => $value) {
            if (preg_match('/^(variant_select|free_price|amount)_(\d+)$/', $key, $matches)) {
                $field = $matches[1];  // e.g., 'variant_select'
                $index = $matches[2];  // e.g., 0, 1, 2...
                $variantsInput[$index][$field] = $value;
            }
        }

        $variantCount = 0;
        $freeCount = 0;
        $paidCount = 0;

        foreach ($variantsInput as $variantData) {
            // Skip invalid/incomplete data
            if (empty($variantData['variant_select']) || !isset($variantData['free_price'])) {
                continue;
            }

            $variableId = $variantData['variant_select'];
            $freePaid = strtolower($variantData['free_price']) === 'paid' ? 1 : 0;
            $amount = isset($variantData['amount']) && is_numeric($variantData['amount']) ? (float)$variantData['amount'] : 0;

            // Store variant
            $variant = new ManageAddOnVariantModel();
            $variant->addon_id = $addon->sno;
            $variant->variable_id = $variableId;
            $variant->free_paid = $freePaid;
            $variant->amount = $amount;
            $variant->created_by = $user_id;
            $variant->updated_by = $user_id;
            $variant->status = 1;
            $variant->save();

            // Tally stats
            $variantCount++;
            if ($freePaid === 0) $freeCount++;
            if ($freePaid === 1) $paidCount++;
        }

        // Update variant counts in main addon
        $addon->variant_count = $variantCount;
        $addon->freevariant_count = $freeCount;
        $addon->paidvariant_count = $paidCount;
        $addon->updated_by = $user_id;
        $addon->save();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Add-On Created Successfully!',
        ]);

        return redirect()->back();
    }

    public function addon_variant_variable() {
        $data = DB::table('et_addon_varient')
            ->leftJoin('et_addon_variable', 'et_addon_variable.addon_varientid', '=', 'et_addon_varient.sno')
            ->where('et_addon_varient.status', 0)
            ->where('et_addon_variable.status', 0)
            ->select(
                'et_addon_varient.addon_varientname',
                'et_addon_variable.addon_variablename',
                'et_addon_variable.sno',
                'et_addon_variable.min_cost',
                'et_addon_variable.max_cost'
            )
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data 
        ], 200);
    }

    public function update_min_max($id)
    {
        $data = DB::table('et_addon_variable')
            ->where('et_addon_variable.status', 0)
            ->where('et_addon_variable.sno', $id)
            ->select(
                'et_addon_variable.min_cost',
                'et_addon_variable.max_cost'
            )
            ->first();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }
}
