<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use App\Models\FacilityModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use Illuminate\Http\Request;
use App\Models\Package_Model;
use App\Models\New_Package_Model;
use App\Models\Package_addon_Model;
use App\Models\Package_product_Model;
use App\Models\ProductModel;
use App\Models\Temp_package_product_Model;
use Illuminate\Support\Facades\DB;

class ManagePackages extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $search_fill = $request->search_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $Package = Package_Model::where('status', '!=', 2)->where('branch_id', $branch_id);
    if ($search_fill  != '') {
      $Package->where(function ($query) use ($search_fill) {
        $query->where('package_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('package_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('base_price', 'LIKE', "%{$search_fill}%")
          ->orWhere('actual_duration', 'LIKE', "%{$search_fill}%");
      });
    }
    $Package = $Package->orderBy('sno', 'desc')->paginate($perpage);

    return view('content.product_management.manage_packages.list', [
      'ListTable' => $Package,
      'perpage' => $perpage,
      'search_fill' => $search_fill
    ]);
  }
  public function package_add(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
       DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();
    $create_chk = New_Package_Model::where('created_by', $user_id)->where('status', 0)->first();
    if ($create_chk) {
      $Inserted_id = $create_chk->sno;
    } else {
      $category_check = New_Package_Model::orderBy('sno', 'desc')->first();

      if (!$category_check) {
        $year = substr(date('y'), -2);
        $new_package_id = 'PP-0001/' . $year;
      } else {
        $data = $category_check->new_package_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int) $result + 1;
        $request_id = sprintf('PP-%04d', $next_number);
        $year = substr(date('y'), -2);
        $new_package_id = $request_id . '/' . $year;
      }
      $new_package_create = new New_Package_Model();
      $new_package_create->new_package_id = $new_package_id;
      $new_package_create->created_by = $user_id;
      $new_package_create->updated_by = $user_id;
      $new_package_create->save();
      $Inserted_id = $new_package_create->sno;
    }

    $addOnProductList = DB::table('et_manage_addon')
      ->select(
        'et_manage_addon.sno',
        'et_manage_addon.addon_name',
      )
      ->where('et_manage_addon.status', 0)
      ->where('et_manage_addon.branch_id', $branch_id)
      ->get();

    foreach ($addOnProductList as $addOn) {
      $manageVarient = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename',
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.addon_id', $addOn->sno)
        ->get();

      $addOn->add_varients = $manageVarient;
    }


    return view('content.product_management.manage_packages.add', [
      'Product_cat_list' => $Product_cat_list,
      'Inserted_id' => $Inserted_id,
      'Branch_id' => $branch_id,
      'addOnProductList' => $addOnProductList,
    ]);
  }
  public function package_product_add(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Get raw JSON input
    $payload = $request->all(); // use $request->getContent() and json_decode if content-type is not handled automatically

    $Inserted_id = $payload['inserted_id'] ?? null;
    $product_id  = $payload['product_id'] ?? null;
    $product_amount  = $payload['product_amount'] ?? null;
    $variants    = $payload['variants'] ?? [];

    if (!$Inserted_id || !$product_id) {
      return response()->json([
        'status' => false,
        'message' => 'Missing required data.',
        'data' => null
      ]);
    }

    // Store variants as JSON for now (you can normalize later if needed)
    $variant_variable_ids = !empty($variants) ? json_encode($variants) : null;

    // Check if record already exists
    $existing = Temp_package_product_Model::where('temp_package_id', $Inserted_id)
      ->where('product_id', $product_id)
      ->first();

    if ($existing) {
      $existing->variant_variable_ids = $variant_variable_ids;
      $existing->updated_by = $user_id;
      $existing->product_amount = $product_amount;
      $existing->status = 0;
      $existing->save();
      $record = $existing;
    } else {
      $record = new Temp_package_product_Model();
      $record->temp_package_id = $Inserted_id;
      $record->product_id = $product_id;
      $record->product_amount = $product_amount;
      $record->variant_variable_ids = $variant_variable_ids;
      $record->created_by = $user_id;
      $record->updated_by = $user_id;
      $record->status = 0;
      $record->save();
    }

    return response()->json([
      'status' => true,
      'message' => 'Product variant(s) added to package successfully.',
      'data' => $record
    ]);
  }
  public function Add(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $Inserted_id = $request->Inserted_id;
    $category_check = Package_Model::orderBy('sno', 'desc')->first();
    if (!$category_check) {
      $year = substr(date('y'), -2);
      $new_package_id = 'PP-0001/' . $year;
    } else {
      $data = $category_check->package_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);
      $next_number = (int) $result + 1;
      $request_id = sprintf('PP-%04d', $next_number);
      $year = substr(date('y'), -2);
      $new_package_id = $request_id . '/' . $year;
    }

    $package_create = new Package_Model();
    $package_create->package_id = $new_package_id;
    $package_create->branch_id = $branch_id;
    $package_create->temp_package_id = $Inserted_id;
    $package_create->package_name = $request->package_name;
    $package_create->base_price = $request->base_price;
    $package_create->min_amount = $request->min_amount;
    $package_create->max_amount = $request->max_amount;
    $package_create->package_desc = $request->pack_desc;
    $package_create->actual_amount = $request->grant_total_amount;
    $package_create->actual_add_on_amount = $request->addon_total_amount_value ?? 0;
    $package_create->actual_duration = $request->overall_total_Duration;
    $package_create->created_by = $user_id;
    $package_create->updated_by = $user_id;
    $package_create->save();
    $package_sno = $package_create->sno;

    if ($package_sno) {

      $get_temp_data = Temp_package_product_Model::where('status', 0)->where('temp_package_id', $Inserted_id)->get();
      foreach ($get_temp_data as $list) {
        $product_data =  ProductModel::where('sno', $list->product_id)->first();
        $duration    = $product_data->duration ?? 0;
        $duration_in = $product_data->duration_in;

        $in = match ($duration_in) {
          0 => 'Minute',
          1 => 'Hours',
          2 => 'Days',
          default => '',
        };
        $dura = $duration . ' ' . $in;

        $pro_package_create = new Package_product_Model();
        $pro_package_create->package_id = $package_sno;
        $pro_package_create->branch_id = $branch_id;
        $pro_package_create->product_id = $list->product_id;
        $pro_package_create->product_amount = $list->product_amount;
        $pro_package_create->product_duration = $dura;
        $pro_package_create->variant_variable_ids = $list->variant_variable_ids;
        $pro_package_create->created_by = $user_id;
        $pro_package_create->updated_by = $user_id;
        $pro_package_create->save();
      }
      $temp_data = New_Package_Model::where('sno', $Inserted_id)->where('status', 0)->first();
      if ($temp_data) {
        $temp_data->status = 2;
        $temp_data->updated_by = $user_id;
        $temp_data->save();
      }
      if ($request->prod_add_on == 1) {
        $add_on_chk = $request->addOn_chk ?? [];
        foreach ($add_on_chk as $addon_id => $val) {
          $variant_id = $request->{'addOn_varient_' . $addon_id};
          $free_paid = $request->free_paid[$variant_id] ?? 0;
          if ($free_paid == 1) {
            $amount = $request->addon_amount[$variant_id] ?? 0;
          } else {
            $amount = $request->addon_amount_free[$variant_id] ?? 0;
          }

          $addon_package_create = new Package_addon_Model();
          $addon_package_create->package_id = $package_sno;
          $addon_package_create->addon_id = $addon_id;
          $addon_package_create->addon_variant_id = $variant_id;
          $addon_package_create->addon_amount = $amount;
          $addon_package_create->free_paid  = $free_paid;
          $addon_package_create->created_by = $user_id;
          $addon_package_create->updated_by = $user_id;
          $addon_package_create->save();
        }
      }
    }

    if ($package_sno) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Package Added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add Package!'
      ]);
    }
    return redirect('/manage_package');
  }
  public function product_list_package($id)
  {
    $data = Temp_package_product_Model::where('status', 0)
      ->where('temp_package_id', $id)
      ->orderBy('sno', 'asc')
      ->get();
    $html = '';
    $over_all_total = 0;
    $totalMinutes = 0;
    foreach ($data as $inx => $list) {
      $product_id = $list->product_id;

      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
      $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      $product_price = $product_data->base_price ?? 0;
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };

      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
      $variant = '';
      $variable_amount = 0;
      $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);
      $variant_variable_ids = is_array($variant_variable_ids) ? $variant_variable_ids : [];
      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
        $selected_pairs[$v['variant_id']] = $v['variable_id'];
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
        $variant .= '
                  <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                  <div class="d-flex align-items-center justify-content-between">
                      <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                      <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                  <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                              </svg>
                          </span>
                      </a>
                  </div>
                  <!-- Modal -->
                   <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" id="kt_modal_choose_me_triger_edit' . htmlspecialchars($product_id) . '">
                  <div class="modal fade" id="kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content rounded">
                              <div class="modal-header justify-content-end border-0 pb-0">
                                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                      <span class="svg-icon svg-icon-1">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                          </svg>
                                      </span>
                                  </div>
                              </div>

                              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                  <div class="mb-8 text-center">
                                      <h3 class="text-center mb-4 text-black">Update Product</h3>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_name) . '</div>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_category_name) . '</div>
                                  </div>
                                  <div class="row mb-4">
                                          <label class="col-3 text-dark fs-6 fw-semibold">Base Price</label>
                                          <label class="col-1 text-black fs-6 fw-bold">:</label>
                                          <div class="col-8 text-black fs-6 fw-bold"> <span class="badge bg-success px-2 py-2">' . number_format($product_data->base_price) . '</span></div>
                                  </div>

                                  <div class="divider mt-1 mb-1">
                                      <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                  </div>
                                  <input type="hidden"id="Inserted_id_product_edit" name="Inserted_id_product_edit" value="' . htmlspecialchars($list->temp_package_id) . '">
                                  <input type="hidden" name="product_id_edit" value="' . htmlspecialchars($product_id) . '">
                                  <input type="hidden" id="product_amount_edit' . htmlspecialchars($list->product_id) . '" value="' . htmlspecialchars($product_price) . '">
                                  <div class="row">
                                      <div class="col-lg-12 mb-1">
                                          <div class="bg-gray-200i rounded">
                                              <div class="scroll-y max-h-400px py-2 px-3">';

        $get_variants_loop = ManageProductVaiantModel::where('product_id', $product_id)->get();

        if ($get_variants_loop->count()) {
          foreach ($get_variants_loop as $vari) {
            $variant_checked = in_array($vari->sno, $selected_variants);
            $show_div = $variant_checked ? 'block' : 'none';
            $get_variables_loop = ManageProductVariableModel::where('product_variant_id', $vari->sno)->get();
            $variant .= '<div class="px-3 pt-1">
                                                                    <div class="form-check form-check-inline mb-1 mt-1">
                                                                        <input class="form-check-input" type="checkbox" id="variant_check_box_edit' . htmlspecialchars($vari->sno) . '" onclick="variant_check_func_edit(' . htmlspecialchars($vari->sno) . ');" ' . ($variant_checked ? 'checked' : '') . ' />
                                                                        <label class="text-black mb-1 fs-6 fw-semibold">' . htmlspecialchars($vari->product_variant_name) . '</label>
                                                                    </div>
                                                                    <div id="variant_check_div_edit' . htmlspecialchars($vari->sno) . '" style="display: ' . $show_div . ';">
                                                                        <div class="row mt-2">';

            foreach ($get_variables_loop as $vrlist) {
              $is_selected = (isset($selected_pairs[$vari->sno]) && $selected_pairs[$vari->sno] == $vrlist->sno);
              $variant .= '<div class="col-lg-4 mb-1">
                                                                      <div class="form-check">
                                                                          <input class="form-check-input me-0 variable_radio_edit' . htmlspecialchars($vari->sno) . '" type="radio" data-amount="' . htmlspecialchars($vrlist->variable_amount) . '" name="variable_radio_[' . htmlspecialchars($vari->sno) . ']" value="' . htmlspecialchars($vrlist->sno) . '" ' . ($variant_checked ? '' : 'disabled') . ' ' . ($is_selected ? 'checked' : '') . ' />
                                                                          <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                              <span>' . htmlspecialchars($vrlist->variable_name) . '</span>
                                                                              <span class="ms-1 me-1">-</span>
                                                                              <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; ' . number_format($vrlist->variable_amount) . '</span>
                                                                          </label>
                                                                      </div>
                                                                  </div>';
            }

            $variant .= '</div>
                                                                  <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                              </div>
                                                          </div>';
          }
        } else {
          $variant .= '<label class="row text-center">
                                                                <span class="text-danger fs-5">No Variant found for this <b class="text-black">' . htmlspecialchars($product_data->product_name) . '</b> Product</span>
                                                            </label>';
        }

        $variant .= '
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="d-flex justify-content-center align-items-center mt-8">
                                      <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                      <button type="button" class="btn btn-primary" onclick="edit_product(' . htmlspecialchars($product_id) . ')" id="product_button_edit_' . htmlspecialchars($product_id) . '">Update Product</button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }



      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();

          if ($get_variants && $get_variables) {
            $variable_amount += $get_variables->variable_amount;

            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">&#8377; ' . number_format($get_variables->variable_amount) . '</label>
                  </div>
              </div>';
          }
        }
      }


      $total_amount = $variable_amount + $product_data->base_price;
      $over_all_total += $total_amount;


      $html .= '<div class="mb-1" id="cal_prod_az_' . $inx . '">
                      <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_hd_' . $inx . '">
                        <div class="d-flex align-items-center">
                          <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_on_of(' . $inx . ');" id="cal_prod_tlp_' . $inx . '">
                              <i class="mdi mdi-plus fs-4" id="cal_prod_plus_btton_' . $inx . '"></i>
                            </a>
                          </div>
                          <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                            <div class="d-block">
                              <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                            </div>
                          </div>
                        </div>
                        <div class="mb-0">
                          <label class="fs-4 fw-semibold text-black">&#8377; ' . number_format($total_amount) . '</label>
                          <a href=" javascript:;" class="ms-1 fw-semibold fs-5" onclick="remove_product(' . intval($list->sno) . ',' . $product_id . ')">
                            <span title="Remove">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                  <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                    <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                      <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                      <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                    </g>
                                  </g>
                                </g>
                              </svg>
                            </span>
                          </a>
                        </div>
                      </div>
                      <div class="px-3 py-1 mb-0" id="cal_prod_tbox_' . $inx . '" style="display: none;">
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Products</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">&#8377; ' . htmlspecialchars(number_format($product_data->base_price)) . '</label>
                          </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Durations</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                          </div>
                        </div>
                        ' . $variant . '
                      </div>
                    </div>';
    }
    // Time unit conversions
    $minutesInMonth = 30 * 1440; // 43,200
    $minutesInDay = 1440;
    $minutesInHour = 60;

    // Breakdown
    $months = floor($totalMinutes / $minutesInMonth);
    $remainingAfterMonths = $totalMinutes % $minutesInMonth;

    $days = floor($remainingAfterMonths / $minutesInDay);
    $remainingAfterDays = $remainingAfterMonths % $minutesInDay;

    $hours = floor($remainingAfterDays / $minutesInHour);
    $minutes = round($remainingAfterDays % $minutesInHour);

    // Build result string conditionally
    $durationParts = [];

    if ($months > 0) {
      $durationParts[] = "{$months} Month" . ($months != 1 ? 's' : '');
    }
    if ($days > 0 || $months > 0) {
      $durationParts[] = "{$days} Day" . ($days != 1 ? 's' : '');
    }
    if ($hours > 0 || $days > 0 || $months > 0) {
      if ($hours > 0) {
        $durationParts[] = "{$hours} Hour" . ($hours != 1 ? 's' : '');
      }
    }

    if ($minutes > 0 || empty($durationParts)) {
      $durationParts[] = "{$minutes} Minute" . ($minutes != 1 ? 's' : '');
    }

    $totalDuration = implode(' ', $durationParts);
    $overall_totalDuration = $totalDuration ?: '0';




    $product_ids = $data->pluck('product_id')->toArray();
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $html,
      'product_ids' => $product_ids,
      'over_all_total' => $over_all_total,
      'overall_totalDuration' => $overall_totalDuration,
    ]);
  }
  public function package_edit($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
        DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();
    $Inserted_id = $id;

    $addOnProductList = DB::table('et_manage_addon')
      ->select(
        'et_manage_addon.sno',
        'et_manage_addon.addon_name',
      )
      ->where('et_manage_addon.status', 0)
      ->where('et_manage_addon.branch_id', $branch_id)
      ->get();

    foreach ($addOnProductList as $addOn) {
      $manageVarient = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename',
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.addon_id', $addOn->sno)
        ->get();

      $addOn->add_varients = $manageVarient;
    }

    $package_data = Package_Model::where('sno', $id)->first();


    return view('content.product_management.manage_packages.edit', [
      'Product_cat_list' => $Product_cat_list,
      'Inserted_id' => $Inserted_id,
      'Branch_id' => $branch_id,
      'addOnProductList' => $addOnProductList,
      'package_data' => $package_data,
    ]);
  }
  public function product_list_package_edit($id)
  {
    $data = Package_product_Model::where('status', 0)
      ->where('package_id', $id)
      ->orderBy('sno', 'asc')
      ->get();
    $html = '';
    $over_all_total = 0;
    $totalMinutes = 0;
    foreach ($data as $inx => $list) {
      $product_id = $list->product_id;

      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
      $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      $product_price = $product_data->base_price ?? 0;
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };

      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
      $variant = '';
      $variable_amount = 0;
      $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);
      $variant_variable_ids = is_array($variant_variable_ids) ? $variant_variable_ids : [];
      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
        $selected_pairs[$v['variant_id']] = $v['variable_id'];
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
        $variant .= '
                  <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                  <div class="d-flex align-items-center justify-content-between">
                      <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                      <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                  <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                              </svg>
                          </span>
                      </a>
                  </div>
                  <!-- Modal -->
                   <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" id="kt_modal_choose_me_triger_edit' . htmlspecialchars($product_id) . '">
                  <div class="modal fade" id="kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content rounded">
                              <div class="modal-header justify-content-end border-0 pb-0">
                                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                      <span class="svg-icon svg-icon-1">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                          </svg>
                                      </span>
                                  </div>
                              </div>

                              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                  <div class="mb-8 text-center">
                                      <h3 class="text-center mb-4 text-black">Update Product</h3>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_name) . '</div>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_category_name) . '</div>
                                  </div>
                                  <div class="row mb-4">
                                          <label class="col-3 text-dark fs-6 fw-semibold">Base Price</label>
                                          <label class="col-1 text-black fs-6 fw-bold">:</label>
                                          <div class="col-8 text-black fs-6 fw-bold"><span class="badge bg-success px-2 py-2">' . number_format($product_data->base_price) . '</span></div>
                                  </div>

                                  <div class="divider mt-1 mb-1">
                                      <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                  </div>
                                  <input type="hidden"id="Inserted_id_product_edit" name="Inserted_id_product_edit" value="' . htmlspecialchars($list->temp_package_id) . '">
                                  <input type="hidden" name="product_id_edit" value="' . htmlspecialchars($product_id) . '">
                                  <input type="hidden" id="product_amount_edit' . htmlspecialchars($list->product_id) . '" value="' . htmlspecialchars($product_price) . '">
                                  <div class="row">
                                      <div class="col-lg-12 mb-1">
                                          <div class="bg-gray-200i rounded">
                                              <div class="scroll-y max-h-400px py-2 px-3">';

        $get_variants_loop = ManageProductVaiantModel::where('product_id', $product_id)->get();

        if ($get_variants_loop->count()) {
          foreach ($get_variants_loop as $vari) {
            $variant_checked = in_array($vari->sno, $selected_variants);
            $show_div = $variant_checked ? 'block' : 'none';
            $get_variables_loop = ManageProductVariableModel::where('product_variant_id', $vari->sno)->get();
            $variant .= '<div class="px-3 pt-1">
                                                                    <div class="form-check form-check-inline mb-1 mt-1">
                                                                        <input class="form-check-input" type="checkbox" id="variant_check_box_edit' . htmlspecialchars($vari->sno) . '" onclick="variant_check_func_edit(' . htmlspecialchars($vari->sno) . ');" ' . ($variant_checked ? 'checked' : '') . ' />
                                                                        <label class="text-black mb-1 fs-6 fw-semibold">' . htmlspecialchars($vari->product_variant_name) . '</label>
                                                                    </div>
                                                                    <div id="variant_check_div_edit' . htmlspecialchars($vari->sno) . '" style="display: ' . $show_div . ';">
                                                                        <div class="row mt-2">';

            foreach ($get_variables_loop as $vrlist) {
              $is_selected = (isset($selected_pairs[$vari->sno]) && $selected_pairs[$vari->sno] == $vrlist->sno);
              $variant .= '<div class="col-lg-4 mb-1">
                                                                      <div class="form-check">
                                                                          <input class="form-check-input me-0 variable_radio_edit' . htmlspecialchars($vari->sno) . '" type="radio" data-amount="' . htmlspecialchars($vrlist->variable_amount) . '" name="variable_radio_[' . htmlspecialchars($vari->sno) . ']" value="' . htmlspecialchars($vrlist->sno) . '" ' . ($variant_checked ? '' : 'disabled') . ' ' . ($is_selected ? 'checked' : '') . ' />
                                                                          <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                              <span>' . htmlspecialchars($vrlist->variable_name) . '</span>
                                                                              <span class="ms-1 me-1">-</span>
                                                                              <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; ' . number_format($vrlist->variable_amount) . '</span>
                                                                          </label>
                                                                      </div>
                                                                  </div>';
            }

            $variant .= '</div>
                                                                  <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                              </div>
                                                          </div>';
          }
        } else {
          $variant .= '<label class="row text-center">
                                                                <span class="text-danger fs-5">No Variant found for this <b class="text-black">' . htmlspecialchars($product_data->product_name) . '</b> Product</span>
                                                            </label>';
        }

        $variant .= '
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="d-flex justify-content-center align-items-center mt-8">
                                      <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                      <button type="button" class="btn btn-primary" onclick="edit_product(' . htmlspecialchars($product_id) . ')" id="product_button_edit_' . htmlspecialchars($product_id) . '">Update Product</button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }



      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();

          if ($get_variants && $get_variables) {
            $variable_amount += $get_variables->variable_amount;

            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">&#8377; ' . number_format($get_variables->variable_amount) . '</label>
                  </div>
              </div>';
          }
        }
      }


      $total_amount = $variable_amount + $product_data->base_price;
      $over_all_total += $total_amount;


      $html .= '<div class="mb-1" id="cal_prod_az_' . $inx . '">
                      <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_hd_' . $inx . '">
                        <div class="d-flex align-items-center">
                          <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_on_of(' . $inx . ');" id="cal_prod_tlp_' . $inx . '">
                              <i class="mdi mdi-plus fs-4" id="cal_prod_plus_btton_' . $inx . '"></i>
                            </a>
                          </div>
                          <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                            <div class="d-block">
                              <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                            </div>
                          </div>
                        </div>
                        <div class="mb-0">
                          <label class="fs-4 fw-semibold text-black">&#8377; ' . number_format($total_amount) . '</label>
                          <a href=" javascript:;" class="ms-1 fw-semibold fs-5" onclick="remove_product(' . intval($list->sno) . ',' . $product_id . ')">
                            <span title="Remove">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                  <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                    <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                      <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                      <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                    </g>
                                  </g>
                                </g>
                              </svg>
                            </span>
                          </a>
                        </div>
                      </div>
                      <div class="px-3 py-1 mb-0" id="cal_prod_tbox_' . $inx . '" style="display: none;">
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Products</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">&#8377; ' . htmlspecialchars(number_format($product_data->base_price)) . '</label>
                          </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Durations</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                          </div>
                        </div>
                        ' . $variant . '
                      </div>
                    </div>';
    }
    // Time unit conversions
    $minutesInMonth = 30 * 1440; // 43,200
    $minutesInDay = 1440;
    $minutesInHour = 60;

    // Breakdown
    $months = floor($totalMinutes / $minutesInMonth);
    $remainingAfterMonths = $totalMinutes % $minutesInMonth;

    $days = floor($remainingAfterMonths / $minutesInDay);
    $remainingAfterDays = $remainingAfterMonths % $minutesInDay;

    $hours = floor($remainingAfterDays / $minutesInHour);
    $minutes = round($remainingAfterDays % $minutesInHour);

    // Build result string conditionally
    $durationParts = [];

    if ($months > 0) {
      $durationParts[] = "{$months} Month" . ($months != 1 ? 's' : '');
    }
    if ($days > 0 || $months > 0) {
      $durationParts[] = "{$days} Day" . ($days != 1 ? 's' : '');
    }
    if ($hours > 0 || $days > 0 || $months > 0) {
      if ($hours > 0) {
        $durationParts[] = "{$hours} Hour" . ($hours != 1 ? 's' : '');
      }
    }

    if ($minutes > 0 || empty($durationParts)) {
      $durationParts[] = "{$minutes} Minute" . ($minutes != 1 ? 's' : '');
    }

    $totalDuration = implode(' ', $durationParts);
    $overall_totalDuration = $totalDuration ?: '0';




    $product_ids = $data->pluck('product_id')->toArray();
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $html,
      'product_ids' => $product_ids,
      'over_all_total' => $over_all_total,
      'overall_totalDuration' => $overall_totalDuration,
    ]);
  }
  public function package_product_edit(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Get raw JSON input
    $payload = $request->all(); // use $request->getContent() and json_decode if content-type is not handled automatically

    $Inserted_id = $payload['inserted_id'] ?? null;
    $product_id  = $payload['product_id'] ?? null;
    $product_amount  = $payload['product_amount'] ?? null;
    $variants    = $payload['variants'] ?? [];

    if (!$Inserted_id || !$product_id) {
      return response()->json([
        'status' => false,
        'message' => 'Missing required data.',
        'data' => null
      ]);
    }

    // Store variants as JSON for now (you can normalize later if needed)
    $variant_variable_ids = !empty($variants) ? json_encode($variants) : null;

    // Check if record already exists
    $existing = Package_product_Model::where('package_id', $Inserted_id)
      ->where('product_id', $product_id)
      ->first();

    if ($existing) {
      $existing->variant_variable_ids = $variant_variable_ids;
      $existing->updated_by = $user_id;
      $existing->product_amount = $product_amount;
      $existing->status = 0;
      $existing->save();
      $record = $existing;
    } else {
      $record = new Package_product_Model();
      $record->branch_id = $branch_id;
      $record->package_id = $Inserted_id;
      $record->product_id = $product_id;
      $record->product_amount = $product_amount;
      $record->variant_variable_ids = $variant_variable_ids;
      $record->created_by = $user_id;
      $record->updated_by = $user_id;
      $record->status = 0;
      $record->save();
    }

    return response()->json([
      'status' => true,
      'message' => 'Product variant(s) added to package successfully.',
      'data' => $record
    ]);
  }
  public function product_list_package_edit_delete($id)
  {

    $upd_DepartmentModel = Package_product_Model::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Update(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $Inserted_id = $request->Inserted_id;

    $package_create = Package_Model::where('sno', $Inserted_id)->first();
    $package_create->branch_id = $branch_id;
    $package_create->temp_package_id = $Inserted_id;
    $package_create->package_name = $request->package_name;
    $package_create->base_price = $request->base_price;
    $package_create->min_amount = $request->min_amount;
    $package_create->max_amount = $request->max_amount;
    $package_create->package_desc = $request->pack_desc;
    $package_create->actual_amount = $request->grant_total_amount;
    $package_create->actual_add_on_amount = $request->addon_total_amount_value ?? 0;
    $package_create->actual_duration = $request->overall_total_Duration;
    $package_create->created_by = $user_id;
    $package_create->updated_by = $user_id;
    $package_create->save();
    $package_sno = $package_create->sno;
    // return $request;
    if ($package_sno) {

      if ($request->prod_add_on == 1) {

        $old_add_on_ids = $request->old_add_on_ids ?? [];

        foreach ($old_add_on_ids as $addon_id => $val) {
          $is_checked = $request->addOn_chk[$addon_id] ?? false;
          if ($is_checked) {
            $variant_id = $request->{'addOn_varient_' . $addon_id} ?? 0;
            $free_paid = (int)($request->free_paid[$variant_id] ?? 0);
            $amount = $free_paid == 1
              ? ($request->addon_amount[$variant_id] ?? 0)
              : ($request->addon_amount_free[$variant_id] ?? 0);

            $old_id = $request->old_add_on_ids[$addon_id] ?? 0;
            $addon_package_create = $old_id < 1
              ? new Package_addon_Model()
              : Package_addon_Model::find($old_id);

            if ($addon_package_create) {
              $addon_package_create->package_id = $package_sno;
              $addon_package_create->addon_id = $addon_id;
              $addon_package_create->addon_variant_id = $variant_id;
              $addon_package_create->addon_amount = $amount;
              $addon_package_create->free_paid = $free_paid;
              $addon_package_create->updated_by = $user_id;
              if ($old_id < 1) {
                $addon_package_create->created_by = $user_id;
              }
              $addon_package_create->save();
            }
          } else {
            $update = Package_addon_Model::find($val);
            if ($update) {
              $update->status = 2;
              $update->save();
            }
          }
        }
      }

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Package updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update Package!'
      ]);
    }
    return redirect('/manage_package');
  }
  public function product_list_package_delete($id)
  {

    $upd_DepartmentModel = Temp_package_product_Model::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function View($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;
    $data = Package_Model::where('sno', $id)->where('branch_id', $branch_id)->first();


    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Product not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    $html = '<div class="row">
              <div class="col-lg-6 mt-2">
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Package</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7">
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" >' . htmlspecialchars($data->package_name) . '</div>
                  </div>
                </div>
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Duration</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7">
                    <div class="badge bg-warning rounded text-black fs-6 fw-semibold">' . htmlspecialchars($data->actual_duration) . '</div>
                  </div>
                </div>
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Min. Amount</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7">
                    <label class="badge bg-info fs-6 fw-semibold">&#8377; ' . number_format($data->min_amount) . '</label>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 mt-2">
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Base Price</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7 text-black fs-6 fw-bold">&#8377; ' . number_format($data->base_price) . '</div>
                </div>
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Actual Price</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7">
                    <label class="badge bg-success rounded text-white fs-6 fw-semibold">&#8377; ' . number_format($data->actual_amount) . '</label>
                  </div>
                </div>
                <div class="row mb-4">
                  <label class="col-4 text-dark fs-6 fw-semibold">Max. Amount</label>
                  <label class="col-1 text-black fs-6 fw-bold">:</label>
                  <div class="col-7">
                    <label class="badge bg-danger text-white fs-6 fw-semibold">&#8377; ' . number_format($data->max_amount) . '</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="row mb-8">
              <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
              <label class="col-12 text-black text-justify fs-6 fw-bold">&emsp;&emsp;&emsp; ' . htmlspecialchars($data->package_desc) . '</label>
            </div>
            <div class="divider mb-1">
              <div class="text-black mb-0 fs-3 fw-semibold divider-text">Products Details</div>
            </div>
            <div class="row" >
              <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                  <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                      <th class="min-w-150px">Products</th>
                      <th class="min-w-80px">Duration</th>
                      <th class="min-w-100px text-end">Product Price</th>
                      <th class="min-w-50px text-center">Facility</th>
                      <th class="min-w-50px text-center">Variants</th>
                      <th class="min-w-100px text-end">Variants Price</th>
                      <th class="min-w-100px text-end">Total Price</th>
                    </tr>
                  </thead>
                  <tbody class="text-black fw-semibold fs-7">';
    $product = DB::table('et_package_product')
      ->select('et_package_product.*', 'et_product.product_name', 'et_product.facility_ids', 'et_product_category.product_category_name')
      ->leftJoin('et_product', 'et_product.sno', 'et_package_product.product_id')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_package_product.status', 0)
      ->where('package_id', $data->sno)
      ->get();
    foreach ($product as $pr => $plist) {
      $html .= '
              <tr>
                <td>
                  <div class="text-truncate max-w-200px fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($plist->product_name) . '">' . htmlspecialchars($plist->product_name) . '</div>
                  <div class="d-block">
                    <div class="text-dark fs-8 text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($plist->product_category_name) . '">' . htmlspecialchars($plist->product_category_name) . '</div>
                  </div>
                </td>
                <td>
                  <label class="badge bg-warning rounded text-black fs-8 fw-semibold">' . htmlspecialchars($plist->product_duration) . '</label>
                </td>
                <td align="right">
                  <label class="text-black fs-7 fw-semibold">&#8377; ' . number_format($plist->product_amount) . '</label>
                </td>';
      $facilities = json_decode($plist->facility_ids ?? '[]', true);
      $facilities = is_array($facilities) ? $facilities : [];
      $facilities_count = count($facilities);

      $html .= '<td class="text-center">
                  <a href="javascript:;" class="badge bg-secondary rounded-pill text-white fs-8 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show Facility">' . number_format($facilities_count) . '</span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end w-350px">
                    <div class="text-black fs-6 text-center my-2 fw-semibold">Facility</div>
                    <hr class="mt-0 mb-2 border-dark">
                    <div class="scroll-y max-h-150px px-4 py-1 mb-2">';
      $fac_div = '';
      foreach ($facilities as $fid) {
        $fac_data = FacilityModel::where('sno', $fid)->first();
        if ($fac_data) {
          $fac_name    = $fac_data->facility_name;
          // Append HTML                    
          $html .= '<div class="d-flex align-items-start text-start mb-2">
                                <label class="text-info fw-semibold fs-7 me-2">#</label>
                                <label class="text-black fw-semibold text-justify fs-7">' . htmlspecialchars($fac_name) . '</label>
                              </div>
                            <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 mb-2"></div>';
        }
      }

      $variant_variable_ids = json_decode($plist->variant_variable_ids ?? '[]', true);
      $variant_variable_ids = is_array($variant_variable_ids) ? $variant_variable_ids : [];
      $variant_variable_count = count($variant_variable_ids);
      $totalAmount = 0;
      foreach ($variant_variable_ids as $item) {
        $totalAmount += isset($item['amount']) ? (float)$item['amount'] : 0;
      }

      $grand_total =  $plist->product_amount + $totalAmount;

      $html .= '</div>
                    </div>
                  </td>
                  <td class="text-center">
                  <a href="javascript:;" class="fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="badge bg-info rounded-circle text-white fs-8 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Variants Count">' . number_format($variant_variable_count) . '</span>
                  </a>
                </td>
                <td align="right">
                  <label class="text-black fs-7 fw-semibold">&#8377; ' . number_format($totalAmount) . '</label>
                </td>
                <td align="right">
                  <label class="text-black fs-7 fw-semibold">&#8377; ' . number_format($grand_total) . '</label>
                </td>
              </tr>';
    }
    $html .= '</tbody>
            </table>
          </div>
        </div>';

    $html .= ' <div class="divider mb-1">
                <div class="text-black mb-0 fs-3 fw-semibold divider-text">Add-on Products Details</div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                    <thead>
                      <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="min-w-200px">Products</th>
                        <th class="min-w-150px">Mode</th>
                        <th class="min-w-150px">Variants</th>
                        <th class="min-w-150px text-end">Total Price</th>
                      </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">';
    $add_on_data = Package_addon_Model::where('package_id', $data->sno)->where('status', 0)->get();

    foreach ($add_on_data as $add_on) {
      // Paid/Free badge
      $free_paid = ($add_on->free_paid > 0)
        ? '<label class="badge bg-info text-white fs-8 fw-semibold">Paid</label>'
        : '<label class="badge bg-danger text-white fs-8 fw-semibold">Free</label>';

      // Get addon name
      $manage_addon = DB::table('et_manage_addon')
        ->select('sno', 'addon_name')
        ->where('sno', $add_on->addon_id)
        ->first();

      // Get addon variant name and amount
      $manage_variant = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename'
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.sno', $add_on->addon_variant_id)
        ->first();

      // Safeguard for missing data
      $addon_name = $manage_addon->addon_name ?? '-';
      $variant_name = $manage_variant->addon_variablename ?? '-';
      $amount = number_format($add_on->addon_amount ?? 0);
      $amount_lab = ($add_on->free_paid > 0) ? '<label class="text-black fs-7 fw-semibold">&#8377; ' . $amount . '</label>' : '<label class="text-black fs-7 fw-semibold"><strike>&#8377; ' . $amount . '</label></strike>';
      $html .= '<tr>
        <td>
            <div class="fs-7 text-black fw-semibold">' . htmlspecialchars($addon_name) . '</div>
        </td>
        <td>' . $free_paid . '</td>
        <td>
            <div class="fs-7 text-black fw-semibold">' . htmlspecialchars($variant_name) . '</div>
        </td>
        <td align="right">
            ' . $amount_lab . '
        </td>
    </tr>';
    }



    $html .= '</tbody>
                  </table>
                </div>
              </div>';

    $total_grand_amount = number_format($data->actual_amount);

    return response([
      'status' => 200,
      'message' => 'Product fetched successfully',
      'error_msg' => null,
      'data' => $html,
      'total_grand_amount' => $total_grand_amount,
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $upd_DepartmentModel = Package_Model::where('sno', $id)->first();
    $upd_DepartmentModel->status = $request->input('status', 0);
    $upd_DepartmentModel->update();
    if ($upd_DepartmentModel) {
      return response([
        'status' => 200,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 400,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 400);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = Package_Model::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function checkDuplicatePackages(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('et_package')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }

}
