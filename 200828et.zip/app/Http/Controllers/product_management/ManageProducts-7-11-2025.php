<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\FacilityModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Models\ProductDelivarablesModel;
use App\Models\ProductTaskModel;
use App\Models\ProductToolsModel;
use App\Models\SlotNotesModel;
use App\Models\TaskChecklistModel;
use Illuminate\Support\Facades\DB;

class ManageProducts extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $search_fill = $request->search_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    
    // if($user_id != 0){
    //     return view('content.working_on_progress');
    // }

    $Product = ProductModel::where('et_product.status', '!=', 2)
      ->select('et_product.*', 'et_product_category.product_category_name','et_product_category.jouranal_check')
      ->where('et_product.branch_id', $branch_id)
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno');
    if ($search_fill  != '') {
      $Product->where(function ($query) use ($search_fill) {
        $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product.duration', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
      });
    }
    $Product = $Product->orderBy('et_product.sno', 'desc')->paginate($perpage);
    // return $Product;

    $Product_cat_list  = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name', 'ASC')->get();
    $Product_unit_list  = DB::table('et_unit')->where('status', 0)->orderBy('unit_name', 'ASC')->get();
    $Facility_list     = FacilityModel::where('status', 0)->orderBy('facility_name', 'ASC')->get();
    $Deliverables_list = ProductDelivarablesModel::where('status', 0)->orderBy('delivarable_name', 'ASC')->get();
    $Slot_Notes_list   = SlotNotesModel::where('status', 0)->orderBy('slot_notes_name', 'ASC')->get();
    $Tools_list        = ProductToolsModel::where('status', 0)->orderBy('product_tools_name', 'ASC')->get();

    return view('content.product_management.manage_products.list', [
      'ListTable' => $Product,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'Product_cat_list' => $Product_cat_list,
      'Product_unit_list' => $Product_unit_list,
      'Facility_list' => $Facility_list,
      'Deliverables_list' => $Deliverables_list,
      'Slot_Notes_list' => $Slot_Notes_list,
      'Tools_list' => $Tools_list,
    ]);
  }
  public function Product_by_category(Request $request)
  {
    $id = $request->input('category_id');
    $data = ProductModel::where('status', 0)->where('product_category_id', $id)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  public function Add(Request $request)
  {
    $category_check = ProductModel::orderBy('sno', 'desc')->first();

    if (!$category_check) {

      $year = substr(date('y'), -2);
      $product_id = 'PRD-0001/' . $year;
    } else {

      $data = $category_check->product_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);

      $next_number = (int) $result + 1;
      $request_id = sprintf('PRD-%04d', $next_number);
      $year = substr(date('y'), -2);
      $product_id = $request_id . '/' . $year;
    }
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $Add = new ProductModel();

    $Add->product_id = $product_id;
    $Add->product_name = $request->product_name;
    $Add->product_category_id = $request->product_cat_id;
    $Add->duration = $request->duration;
    $Add->duration_in = $request->duration_in;
    $Add->base_price = $request->base_price;
    $Add->min_amount = $request->min_amount;
    $Add->max_amount = $request->max_amount;
    $Add->facility_ids = json_encode($request->facility_ids);
    $Add->deliverables_ids = json_encode($request->deliverables_ids);
    $Add->slot_notes_ids = json_encode($request->slot_notes_ids);
    $Add->tools_ids = json_encode($request->tools_ids);
    $Add->product_desc = $request->desc;
    $Add->branch_id = $branch_id;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Product added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Product!'
      ]);
    }

    return redirect()->back();
  }

  public function View($id)
  {
    $data =  ProductModel::where('et_product.status', '!=', 2)
      ->select('et_product.*', 'et_product_category.product_category_name')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_product.sno', $id)->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Product not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    $facilities = json_decode($data->facility_ids ?? '[]', true);
    $facilities = is_array($facilities) ? $facilities : [];

    $fac_div = '';

    foreach ($facilities as $i => $list) {
      $fac_data = FacilityModel::where('sno', $list)->first();
      if ($fac_data) {
        $fac_name    = $fac_data->facility_name;
        $duration    = $fac_data->duration ?? 0;
        $duration_in = $fac_data->duration_in;

        // Set unit
        $in = match ($duration_in) {
          0 => 'Minute',
          1 => 'Hours',
          2 => 'Days',
          default => '',
        };

        $dura = $duration . ' ' . $in;

        // Append HTML
        $fac_div .= '<div class="col-lg-12">
                        <div class="d-flex align-items-start justify-content-between border border-dashed border-gray-400i rounded px-3 py-1 mb-3">
                            <div class="text-black fs-7 fw-semibold text-justify facility_txt w-75 h-20px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($fac_name) . '">' . htmlspecialchars($fac_name) . '</div>
                            <div class="text-dark fs-7 fw-semibold">' . htmlspecialchars($dura) . '</div>
                        </div>
                    </div>';
      }
    }


    $var_div = '';

    $get_variants = ManageProductVaiantModel::where('product_id', $data->sno)->where('status','!=',2)->get();

    foreach ($get_variants as $variant) {
      $var_div .= '<div class="col-lg-12">
                        <div class="text-dark mb-1 fs-7 text-justify fw-semibold">
                            <span class="fs-5 me-1">🔅</span>
                            <span>' . htmlspecialchars($variant->product_variant_name ?? '-') . '</span>
                        </div>';

      // Fetch variables for the current variant
      $variables = ManageProductVariableModel::where('product_variant_id', $variant->sno)->where('status', '!=', 2)->get();
      if ($variables->count()) {
        $var_div .= '<div class="d-block">';
        foreach ($variables as $variable) {
          $status = '';
          if ($variable->status == 1) {
            $status = '<label class="cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Status Off" data-bs-original-title="Status Off"><i class="mdi mdi-eye-off text-danger fs-5 ms-2"></i></label>';
          }
          $var_div .= '<div class="ms-5">
                                <label><i class="mdi mdi-circle-small text-info fs-3 me-n1"></i></label>
                                <label class="text-danger mb-1 fs-7 text-justify fw-semibold">
                                    <span>' . htmlspecialchars($variable->variable_name) . '</span>
                                    <span class="me-1 ms-1">-</span>
                                    <span class="text-dark fs-7">₹ ' . number_format($variable->variable_amount) . '</span>
                                </label>
                                ' . $status . '
                            </div>';
        }
        $var_div .= '</div>';
      }

      $var_div .= '<div class="border-bottom border-dashed border-gray-400i border-start-0 border-end-0 border-top-0 mt-2 mb-2"></div>
                    </div>';
    }

    $deliverables = json_decode($data->deliverables_ids ?? '[]', true);
    $deliverables = is_array($deliverables) ? $deliverables : [];

    $deli_div = '';

    foreach ($deliverables as $i => $dlist) {
      $deli_data = ProductDelivarablesModel::where('sno', $dlist)->first();
      if ($deli_data) {
        $deli_name    = $deli_data->delivarable_name;

        // Append HTML
        $deli_div .= '<div class="col-lg-12">
                    <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                      <div class="fs-6 text-warning me-1">🌟</div>
                      <div class="text-black fs-7 fw-semibold text-justify text-wrap">' . htmlspecialchars($deli_name ?? '-') . '</div>
                    </div>
                  </div>';
      }
    }

    $slot_notes = json_decode($data->slot_notes_ids ?? '[]', true);
    $slot_notes = is_array($slot_notes) ? $slot_notes : [];

    $s_notes_div = '';

    foreach ($slot_notes as $i => $slist) {
      $s_notes_data = SlotNotesModel::where('sno', $slist)->first();
      if ($s_notes_data) {
        $s_notes_name    = $s_notes_data->slot_notes_name;

        // Append HTML
        $s_notes_div .= '<div class="col-lg-12">
                    <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                      <div class="fs-6 text-info me-1 h-0">📃</div>
                      <div class="text-black fs-7 fw-semibold text-justify text-wrap">' . htmlspecialchars($s_notes_name ?? '-') . '</div>
                    </div>
                  </div>';
      }
    }

    $tools_view = '';
    $Tools = json_decode($data->tools_ids ?? '[]', true);
    $Tools = is_array($Tools) ? $Tools : [];
    
    $role = [];
    
    foreach ($Tools as $Tlist) {
        $tools_data = ProductToolsModel::where('sno', $Tlist)->first();
        if ($tools_data) {
            $name = $tools_data->product_tools_name ?? '';
            $tool_name[] = trim($name, ','); // use trim to remove both left and right commas if needed
        }
    }
    
    if (!empty($tool_name)) {
        $tools_view_name = implode(', ', $tool_name);
        
        $tools_view = '<div class="border border-gray-700 rounded pb-2">
                <div class="d-flex align-items-center justify-content-between border-bottom" style="background-color: #cde0f7 !important;">
                    <div class="mb-0 ps-3 py-2">
                      <label class="text-black fw-semibold fs-6">Tools Details</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex align-items-start justify-content-between px-3 py-1">
                            <div class="text-black fs-7 fw-semibold text-justify" id="">' . htmlspecialchars($tools_view_name ?? '-') . '</div>
                        </div>
                    </div>
                </div>
            </div>';
    }


    $data->var_div = $var_div;
    $data->deli_div = $deli_div;
    $data->s_notes_div = $s_notes_div;
    $data->fac_div = $fac_div;
    $data->tools_view = $tools_view;
    $data->fac_count = count($facilities);
    $data->var_count = count($get_variants);
    $data->deli_count = count($deliverables);
    $data->s_notes_count = count($slot_notes);





    return response([
      'status' => 200,
      'message' => 'Product fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Edit($id)
  {
    $data =  ProductModel::where('et_product.status', '!=', 2)
      ->select('et_product.*', 'et_product_category.product_category_name')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_product.sno', $id)->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Product not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Product fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update(Request $request)
  {

    $edit_id = $request->edit_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $update = ProductModel::where('sno', $edit_id)->first();
    $update->product_name = $request->product_name;
    $update->product_category_id = $request->product_cat_id;
    $update->duration = $request->duration;
    $update->duration_in = $request->duration_in;
    $update->base_price = $request->base_price;
    $update->min_amount = $request->min_amount;
    $update->max_amount = $request->max_amount;
    $update->facility_ids = json_encode($request->facility_ids);
    $update->deliverables_ids = json_encode($request->deliverables_ids);
    $update->slot_notes_ids = json_encode($request->slot_notes_ids);
    $update->tools_ids = json_encode($request->tools_ids);
    $update->product_desc = $request->desc;
    $update->branch_id = $branch_id;
    $update->updated_by = $user_id;
    $update->save();

    if ($update) {
      // If category updated successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Product updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Product!'
      ]);
    }

    return redirect()->back();
  }

  public function AddVariant(Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $product_id = $request->add_variant_sno;

    $variant_names = $request->variant_name;         // 2D array
    $variable_names = $request->variable_name;       // 2D array
    $amounts = $request->amount;                     // 2D array
    $min_pages = $request->min_pages;                // 2D array
    $max_pages = $request->max_pages;                // 2D array

    $isSaved = false;

    foreach ($variant_names as $index => $variantArr) {
      $variantName = $variantArr[0]; // Variant name is single string in an array
      // Save variant
      $variant = new ManageProductVaiantModel();
      $variant->branch_id = $branch_id;
      $variant->product_id = $product_id;
      $variant->product_variant_name = $variantName;
      $variant->created_by = $user_id;
      $variant->updated_by = $user_id;
      $variant->save();

      if ($variant && $variant->sno) {
        $variant_sno = $variant->sno;

        // Save variables for this variant
        $variables = $variable_names[$index];
        $prices = $amounts[$index];
        $min = $min_pages[$index];
        $max = $max_pages[$index];

        foreach ($variables as $i => $varName) {
          $varAmount = $prices[$i] ?? 0;
          $min_pages = $min[$i] ?? 0;
          $max_pages = $max[$i] ?? 0;

          $variable = new ManageProductVariableModel();
          $variable->branch_id = $branch_id;
          $variable->product_id = $product_id;
          $variable->product_variant_id = $variant_sno;
          $variable->variable_name = $varName;
          $variable->variable_amount = $varAmount;
          $variable->min_pages = $min_pages;
          $variable->max_pages = $max_pages;
          $variable->created_by = $user_id;
          $variable->updated_by = $user_id;
          $variable->save();
        }

        $isSaved = true;
      }
    }

    if ($isSaved) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Product Variant added successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the product Variant!'
      ]);
    }

    return redirect()->back();
  }


  public function Product_variant_data(Request $request)
  {
    $product_id = $request->id;


    $product = ProductModel::where('et_product.status', '!=', 2)
      ->select('et_product.*', 'et_product_category.product_category_name')
      ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->where('et_product.sno', $product_id)
      ->first();

    $variants  = ManageProductVaiantModel::where('product_id', $product_id)->where('status', 0)->get();

    return view('content.product_management.manage_products.edit_variant', [
      'variants' => $variants,
      'product' => $product
    ]);
  }

  public function Status_variable($id, Request $request)
  {

    $upd_DepartmentModel = ManageProductVariableModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = $request->input('status', 0);
    $upd_DepartmentModel->update();
    if ($upd_DepartmentModel) {
      return response([
        'status' => 200,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 400,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 400);
    }
  }
  public function Variant_Delete($id)
  {
    $upd_DepartmentModel = ManageProductVaiantModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Variable_Delete($id)
  {
    $upd_DepartmentModel = ManageProductVariableModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  
  public function Product_task_Delete($id)
  {
    $upd_DepartmentModel = ProductTaskModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();
//   return $upd_DepartmentModel;
    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Product_task_checklist_Delete($id) 
  {
    $upd_DepartmentModel = TaskChecklistModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function UpdateVariant(Request $request)
  {
    // return $request;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $product_id = $request->edit_variant_sno;

    $variant_names = $request->variant_name_edit;       // 2D array
    $variant_ids = $request->variant_id_edit ?? [];      // flat array
    $variable_names = $request->variable_name_edit;      // 2D array
    $variable_ids = $request->variable_id_edit ?? [];    // flat array
    $amounts = $request->amount_edit;                    // 2D array

    $min_pages = $request->edit_min_pages;                // 2D array
    $max_pages = $request->edit_max_pages;                // 2D array

    $isSaved = false;

    foreach ($variant_names as $index => $variantArr) {
      $variantName = $variantArr[0] ?? '';
      $variant_id  = $variant_ids[$index] ?? 0;

      // Update or Insert Variant
      if ($variant_id > 0) {
        $variant = ManageProductVaiantModel::find($variant_id);
        if (!$variant) continue;
        $variant->updated_by = $user_id;
      } else {
        $variant = new ManageProductVaiantModel();
        $variant->branch_id = $branch_id;
        $variant->product_id = $product_id;
        $variant->created_by = $user_id;
        $variant->updated_by = $user_id;
      }

      $variant->product_variant_name = $variantName;
      $variant->save();

      if ($variant && $variant->sno) {
        $variant_sno = $variant->sno;
        // Loop through variables for this variant
        $variables = $variable_names[$index] ?? [];
        $prices = $amounts[$index] ?? [];
        $min = $min_pages[$index];
        $max = $max_pages[$index];

        foreach ($variables as $i => $varName) {
          $varAmount = $prices[$i] ?? 0;
          $variable_id = $variable_ids[$index][$i] ?? 0;

          $min_pages = $min[$i] ?? 0;
          $max_pages = $max[$i] ?? 0;

          // Update or Insert Variable
          if ($variable_id > 0) {
            $variable = ManageProductVariableModel::find($variable_id);
            if (!$variable) continue;
            $variable->updated_by = $user_id;
          } else {
            $variable = new ManageProductVariableModel();
            $variable->branch_id = $branch_id;
            $variable->product_id = $product_id;
            $variable->product_variant_id = $variant_sno;
            $variable->created_by = $user_id;
            $variable->updated_by = $user_id;
          }

          $variable->variable_name = $varName;
          $variable->variable_amount = $varAmount;
          $variable->min_pages = $min_pages;
          $variable->max_pages = $max_pages;
          
          $variable->save();

          $isSaved = true;
        }
      }
    }

    if ($isSaved) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Product Variant updated successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the product Variant!',
      ]);
    }

    return redirect()->back();
  }


  public function Status($id, Request $request)
  {

    $upd_DepartmentModel = ProductModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = $request->input('status', 0);
    $upd_DepartmentModel->update();
    if ($upd_DepartmentModel) {
      return response([
        'status' => 200,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 400,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 400);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = ProductModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function update_product_variant()
  {
    return view('content.product_management.manage_products.update_product_variant');
  }
  public function checkDuplicateProduct(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('et_product')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }

    public function addProductTask(Request $request) {
        
        $taskNames = $request->input('task_name', []);
        $units = $request->input('unit', []);
        $hours = $request->input('hours', []);
        $checkLists = $request->input('checklist', []);
        $checklist_sno = $request->input('checklist_sno', []);
        $task_sno = $request->input('task_sno', []);
        $productId = $request->product_task_id;
        $task_to = $request->task_to_hidden;
    
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
    
        $anySaved = false;
        foreach($taskNames as $index => $taskName) {
            
            if(isset($task_sno[$index]) && $task_sno[$index] > 0) {
                $tasks = ProductTaskModel::where('sno', $task_sno[$index])->first();
                if($tasks) {
                    $tasks->task_name  = $taskName;
                    $tasks->unit_id    = $units[$index] ?? null;
                    $tasks->hours_id   = $hours[$index] ?? null;
                    $tasks->updated_by = $user_id;
                    $tasks->save();
                }
            } else {
                
                $tasks = new ProductTaskModel();
                $tasks->product_id = $productId;
                $tasks->task_name  = $taskName;
                $tasks->unit_id    = $units[$index] ?? null;
                $tasks->hours_id   = $hours[$index] ?? null;
                $tasks->created_by = $user_id;
                $tasks->branch_id  = $branch_id;
                $tasks->updated_by = $user_id;
                $tasks->save();
            }
    
            if(isset($checkLists[$index])) {
                foreach($checkLists[$index] as $ch_index => $item) {
                    if(isset($checklist_sno[$index][$ch_index]) && $checklist_sno[$index][$ch_index] > 0) {
                        $check = TaskChecklistModel::where('sno', $checklist_sno[$index][$ch_index])->first();
                        if($check) {
                            $check->task_checklist = $item;
                            $check->updated_by = $user_id;
                            $check->save();
                            $anySaved = true;
                        }
                    } else {
                        $check = new TaskChecklistModel();
                        $check->product_id = $productId;
                        $check->product_task_id = $tasks->sno;
                        $check->task_checklist = $item;
                        $check->created_by = $user_id;
                        $check->updated_by = $user_id;
                        $check->save();
                        $anySaved = true;
                    }
                    
                }
            }
        }
        
    
        if($anySaved) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Product Task '.$task_to.'d Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Product Task '.$task_to.'d  Failed!'
            ]);
        }
    
        return redirect()->back();
    }


    public function getProductTasks($id) {
      
    $tasks = DB::table('et_product_task')
      ->where('product_id', $id)
      ->where('status',0)
      ->get();
      
    foreach ($tasks as &$task) {
      $task->checklists = DB::table('et_task_checklist')
      ->where('product_id', $id)
      ->where('product_task_id', $task->sno)
      ->where('status', 0)
      ->get();
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $tasks
    ], 200);
  }
}
