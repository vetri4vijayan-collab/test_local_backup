<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class MenuCountController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'counts' => [],
            ], 401);
        }

        return response()->json([
            'success' => true,
            'counts' =>   app(\App\Services\MenuCountService::class)->getCounts($request->user()),
        ]);
    }
}