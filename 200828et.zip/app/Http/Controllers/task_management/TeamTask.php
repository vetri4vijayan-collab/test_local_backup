<?php

namespace App\Http\Controllers\task_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\UserRoleModel;
class TeamTask extends Controller
{
  public function index()
  {
    return view('content.task_management.team_task.task_list');
  }
  
    public function ViewTask(Request $request)
    {
        $id = $request->role_id ?? 11;
    
        // 🔹 Fetch the task details
        $tasks = DB::table('et_task_master')
            ->where('role_id', $id)
            ->get();
        
        if (!$tasks) {
            return redirect()->back()->with('error', 'Task not found.');
        }
    
        // 🔹 Fetch the related role
        $roledetails = UserRoleModel::where('sno', $id)->first();
         return response()->json([
            'status' => 'success',
            'tasks' => $tasks,
            'roledetails' => $roledetails
        ]);
        
    }


public function addTask(Request $request)
 {
    $request->validate([
        'role_id' => 'required',
        'task_type' => 'required',
        'task_name' => 'required|string',
        'measurement_metric' => 'required|string',
    ]);

    try {
        $exists = DB::table('et_task_master')
            ->where('role_id', $request->role_id)
            ->where('task_type', $request->task_type)
            ->where('task_name', $request->task_name)
            ->exists();

        if ($exists) {
            return response()->json(['status' => false, 'message' => 'Duplicate task — already exists!']);
        }

        DB::table('et_task_master')->insert([
            'role_id' => $request->role_id,
            'task_type' => $request->task_type,
            'date_or_range' => $request->task_type === 'monthly_schedule' ? $request->date_or_range : null,
            'task_name' => $request->task_name,
            'measurement_metric' => $request->measurement_metric,
            'created_by' => auth()->id(),
            'created_at' => now(),
        ]);


        // 🔹 Fetch the task details
        $tasks = DB::table('et_task_master')
            ->where('role_id', $request->role_id)
            ->get();
        
        if (!$tasks) {
            return redirect()->back()->with('error', 'Task not found.');
        }
        // 🔹 Fetch the related role
        $roledetails = UserRoleModel::where('sno', $request->role_id)->first();
        
        return response()->json([
            'status' => true,
            'message' => 'Task added successfully!',
            'tasks' => $tasks,
            'roledetails' => $roledetails
        ]);
    } catch (\Exception $e) {
        return response()->json(['status' => false, 'message' => $e->getMessage()]);
    }
}
}
