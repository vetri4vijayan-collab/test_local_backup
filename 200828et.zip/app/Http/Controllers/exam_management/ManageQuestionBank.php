<?php

namespace App\Http\Controllers\exam_management;

use App\Http\Controllers\Controller;
use App\Models\ExamQuestionsModel;
use App\Models\QuestionBankModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageQuestionBank extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        
        
        $query = DB::table('et_question_bank')->select(
                'et_question_bank.*',
                'et_exam_category.category_name',
                DB::raw('(SELECT COUNT(sno) FROM et_exam_questions WHERE et_exam_questions.bank_id = et_question_bank.sno AND et_exam_questions.status=0) as question_count')
            )
            ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_question_bank.category_id')
            ->where('et_question_bank.status', '!=', 2);
        // Apply search filter
        if (!empty($search_fill)) {
          $query->where(function ($query) use ($search_fill) {
            $query->where('et_question_bank.bank_name', 'LIKE', "%{$search_fill}%")
              ->orWhere('et_exam_category.category_name', 'LIKE', "%{$search_fill}%");
          });
        }

        $lists = $query->where('et_question_bank.branch_id', $branch_id)->orderBy('sno','DESC')->paginate($perpage);
        
            
        $Cat_list = DB::table('et_exam_category')->where('status',0)->orderBy('category_name','ASC')->get();
           

        return view('content.exam_management.manage_question_bank.list', [
            'lists' => $lists,
            'search_fill' => $search_fill,
            'Cat_list' => $Cat_list,
            'perpage' => $perpage
        ]);
    }
    public function Add(Request $request)
    {
        $entity_id = $request->user()->entity_id;
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
    
        $chk = QuestionBankModel::where('bank_name', ucwords($request->bank_name))
            ->where('branch_id', $branch_id)
            ->where('category_id', $request->category_id)
            ->where('level_id', $request->level_id)
            ->where('status', '!=', 2)
            ->first();
    
        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Already exists!'
            ]);
        } else {
            try {
                $Add = new QuestionBankModel();
                $Add->bank_name   = ucwords($request->bank_name);
                $Add->category_id = $request->category_id;
                $Add->level_id    = $request->level_id;
                $Add->description = $request->description;
                $Add->created_by  = $user_id; 
                $Add->updated_by  = $user_id; 
                $Add->branch_id   = $branch_id;
                $Add->save();
    
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Question Bank added successfully!'
                ]);
            } catch (\Exception $e) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Question Bank. Error: ' . $e->getMessage()
                ]);
            }
        }
    
        return redirect()->back();
    }
    public function Edit($id)
    {
        $data = QuestionBankModel::where('et_question_bank.sno', $id)->select(
                    'et_question_bank.*',
                    'et_exam_category.category_name'
                )
                ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_question_bank.category_id')->first();
                
        $sections = DB::table('et_exam_questions')
            ->select(
                'et_exam_section.sno as section_id',
                'et_exam_section.section_name'
            )
            ->leftJoin('et_exam_section', 'et_exam_section.sno', '=', 'et_exam_questions.section_id')
            ->where('et_exam_questions.bank_id', $data->sno)
            ->groupBy('et_exam_section.sno', 'et_exam_section.section_name')
            ->get();

            
        return response([
          'status' => 200,
          'message' => null,
          'error_msg' => null,
          'data' => $data,
          'sections' => $sections,
        ], 200);
    }
    public function Update(Request $request)
    {
        $entity_id = $request->user()->entity_id;
        $user_id   = $request->user()->user_id;
        $sno   = $request->edit_id;
        $branch_id = $request->user()->branch_id;
    
        $chk = QuestionBankModel::where('bank_name', ucwords($request->bank_name))
            ->where('branch_id', $branch_id)
            ->where('category_id', $request->category_id)
            ->where('level_id', $request->level_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();
    
        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Already exists!'
            ]);
        } else {
            try {
                $Add = QuestionBankModel::where('sno', $sno)->first();
                $Add->bank_name   = ucwords($request->bank_name);
                $Add->category_id = $request->category_id;
                $Add->level_id    = $request->level_id;
                $Add->description = $request->description;
                $Add->created_by  = $user_id; 
                $Add->updated_by  = $user_id; 
                $Add->branch_id   = $branch_id;
                $Add->save();
    
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Question Bank updated successfully!'
                ]);
            } catch (\Exception $e) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Question Bank. Error: ' . $e->getMessage()
                ]);
            }
        }
    
        return redirect()->back();
    }
    
    public function question_add($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;
        $data = QuestionBankModel::where('et_question_bank.sno', $id)
                ->select(
                        'et_question_bank.*',
                        'et_exam_category.category_name'
                    )
                ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_question_bank.category_id')
                ->first();
        $section = DB::table('et_exam_section')->where('question_bank_id', $data->sno)->where('status',0)->orderBy('section_name','ASC')->get();   
   
        return view('content.exam_management.manage_question_bank.add', [
            'view' => $data,
            'Section' =>$section
        ]);
    }
    public function AddQuestion(Request $request)
    {
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
    
        DB::beginTransaction(); // Start transaction
        try {
            $questions = $request->question ?? [];
    
            foreach ($questions as $i => $q_name) {
                $Add = new ExamQuestionsModel();
                $Add->section_id        = $request->section_id ?? 0;
                $Add->bank_id           = $request->bank_id ?? 0;
                $Add->case_study_check  = $request->input("addcasestudy_$i") ?? 0;
                $Add->case_study        = $request->input("caseStudy_$i") ?? null;
                $Add->question          = ucwords($q_name);
                $Add->option_type       = $request->input("option_type_$i");
                $Add->option            = json_encode($request->input("options_$i"));
                $Add->option_answer     = json_encode($request->input("answer_$i"));
                $Add->tips              = $request->input("tips_editor_hidden_$i");
                $Add->explanation       = $request->input("exp_editor_hidden_$i");
                $Add->created_by        = $user_id;
                $Add->updated_by        = $user_id;
                $Add->branch_id         = $branch_id;
                $Add->save();
            }
    
            DB::commit(); // Commit transaction
    
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Section Question added Successfully!'
            ]);
            
            // return $request;
    
            return redirect('/question-bank');
    
        } catch (\Exception $e) {
            DB::rollBack(); // Roll back on error
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to add section question. Please try again.'
            ]);
            // return $request;
            // return $e->getMessage();
    
            // Optional: Log the error for debugging
            // Log::error('AddQuestion Error: '.$e->getMessage());
    
            return redirect('/question-bank');
        }
    }
    public function UpdateQuestion(Request $request)
    {
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        return $request;
        DB::beginTransaction(); // Start transaction
        try {
            $questions = $request->question ?? [];
            
            $update_ids = $request->edit_question_ids ?? [];
            // return $update_ids[1];
            $OldIds = ExamQuestionsModel::where('sno', $request->bank_id)->where('status', '!=', 2)->get();
            $existingIds  = $OldIds->pluck('sno')->toArray();
            $ToDeleteDiff = array_diff($existingIds, $update_ids);
            $ToDelete     = array_values($ToDeleteDiff);
            
            if (!empty($ToDelete)) {
                $deleteTask= DB::table('et_exam_questions')->whereIn('sno', $ToDelete)->update(['status' => 2]);
            }
    
    
            foreach ($questions as $i => $q_name) {
                
                $ques_sno = $update_ids[$i];
                
                if ($ques_sno > 0) {
                    $Add = ExamQuestionsModel::where('sno', $ques_sno)->first();
                    $Add->case_study_check  = $request->input("addcasestudy_$i") ?? 0;
                    if($Add->case_study_check == 1){
                        $Add->case_study        = $request->input("caseStudy_$i") ?? null;
                    }
                    $Add->question          = ucwords($q_name);
                    $Add->option_type       = $request->input("option_type_$i");
                    $Add->option            = json_encode($request->input("options_$i"));
                    $Add->option_answer     = json_encode($request->input("answer_$i"));
                    $Add->tips              = $request->input("tips_editor_hidden_$i");
                    $Add->explanation       = $request->input("exp_editor_hidden_$i");
                    $Add->updated_by        = $user_id;
                    $Add->save();
                }
                else{
                    $Add = new ExamQuestionsModel();
                    $Add->section_id        = $request->section_id ?? 0;
                    $Add->bank_id           = $request->bank_id ?? 0;
                    $Add->case_study_check  = $request->input("addcasestudy_$i") ?? 0;
                    if($Add->case_study_check == 1){
                        $Add->case_study        = $request->input("caseStudy_$i") ?? null;
                    }
                    
                    $Add->question          = ucwords($q_name);
                   return $Add->option_type       = $request->input("option_type_$i");
                    $Add->option            = json_encode($request->input("options_$i"));
                    $Add->option_answer     = json_encode($request->input("answer_$i"));
                    $Add->tips              = $request->input("tips_editor_hidden_$i");
                    $Add->explanation       = $request->input("exp_editor_hidden_$i");
                    $Add->created_by        = $user_id;
                    $Add->updated_by        = $user_id;
                    $Add->branch_id         = $branch_id;
                    $Add->save();
                }
                
            }
    
            DB::commit(); // Commit transaction
    
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Section Question added Successfully!'
            ]);
            
            // return $request;
    
            return redirect('/question-bank');
    
        } catch (\Exception $e) {
            DB::rollBack(); // Roll back on error
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to add section question. Please try again.'
            ]);
            // return $request;
            return $e->getMessage();
    
            // Optional: Log the error for debugging
            // Log::error('AddQuestion Error: '.$e->getMessage());
    
            return redirect('/question-bank');
        }
    }

    public function question_edit($id)
    {
        // Initialize helper
        $helper = new \App\Helpers\Helpers();

        // Decrypt the ID
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Split the decrypted value using '~' (don't escape it, use '~')
        list($sec, $bank) = explode('~', $decryptedValue);
        
        $data = QuestionBankModel::where('et_question_bank.sno', $bank)
                ->select(
                        'et_question_bank.*',
                        'et_exam_category.category_name'
                    )
                ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_question_bank.category_id')
                ->first();
                
        $section = DB::table('et_exam_section')->where('sno',$sec)->first();
        
        
        $section_list = DB::table('et_exam_questions')
            ->where('bank_id', $bank)
            ->where('section_id', $sec)
            ->where('status',0)
            ->get();
        

        // Pass the variables to the view if you need them there
        return view('content.exam_management.manage_question_bank.edit', [
            'Section' => $section,
            'Section_list' => $section_list,
            'view' => $data
        ]);
    }

    public function Status($id, Request $request)
    {
        $status = QuestionBankModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function View($id = '')
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;
        $view = QuestionBankModel::select(
            'et_question_bank.*',
            'et_exam_category.category_name'
        )
            ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_question_bank.category_id')
            ->where('et_question_bank.sno', $decryptedValue)->first();

        if ($view) {
            $questions = ExamQuestionsModel::select(
                'et_exam_questions.*',
                'et_exam_section.section_name'
            )
                ->leftJoin('et_exam_section', 'et_exam_section.sno', '=', 'et_exam_questions.section_id')
                ->where('et_exam_questions.status', 0)
                ->where('et_exam_questions.bank_id', $id)
                ->get()
                ->groupBy('section_id');
        }

        // return $questions;

        return view('content.exam_management.manage_question_bank.view', [
            'view' => $view,
            'id' => $decryptedValue,
            'questions' => $questions
        ]);
    }
    public function ImportQuestion(Request $request)
    {
        // Validate request
        $validator = Validator::make($request->all(), [
            'bank_id_import' => 'required',
            'file'           => 'required|file|mimes:json,txt'
        ]);
    
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
    
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $bankId    = $request->input('bank_id_import');
    
        try {
            // Read file content directly
            $fileContent = file_get_contents($request->file('file')->getRealPath());
            $data = json_decode($fileContent, true);
    
            // Check JSON validity
            if (!$data || !is_array($data)) {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Invalid JSON file structure'
                ]);
                return redirect('/question-bank');
            }
    
            // Track counts
            $inserted = 0;
            $skipped  = 0;
    
            foreach ($data as $sectionName => $questions) {
                if (!is_array($questions)) {
                    session()->flash('toastr', [
                        'type'    => 'error',
                        'message' => "Invalid section format for: {$sectionName}"
                    ]);
                    return redirect('/question-bank');
                }
    
                // Check or insert section
                $section = DB::table('et_exam_section')
                    ->where('section_name', $sectionName)
                    ->where('status','!=',2)
                    ->first();
    
                $sectionId = $section
                    ? $section->sno
                    : DB::table('et_exam_section')->insertGetId([
                        'question_bank_id' => $bankId,
                        'section_name'     => $sectionName,
                        'created_by'       => $user_id,
                        'updated_by'       => $user_id,
                        'created_at'       => now(),
                        'updated_at'       => now(),
                    ]);
    
                foreach ($questions as $q) {
                    // Validate each question
                    if (!is_array($q) || !isset($q['question'], $q['options'], $q['answer'])) {
                        session()->flash('toastr', [
                            'type'    => 'error',
                            'message' => "Invalid question format in section: {$sectionName}"
                        ]);
                        return redirect('/question-bank');
                    }
    
                    // Skip duplicate
                    $exists = DB::table('et_exam_questions')
                        ->where('question', $q['question'])
                        ->where('section_id', $sectionId)
                        ->where('bank_id', $bankId)
                        ->where('status','!=',2)
                        ->exists();
    
                    if ($exists) {
                        $skipped++;
                        continue;
                    }
    
                    // Insert new
                    DB::table('et_exam_questions')->insert([
                        'branch_id'        => $branch_id,
                        'section_id'       => $sectionId,
                        'bank_id'          => $bankId,
                        'case_study_check' => 0,
                        'option_type'      => 0,
                        'question'         => $q['question'],
                        'option'           => json_encode($q['options']),
                        'option_answer'    => json_encode([array_search($q['answer'], $q['options'])]),
                        'tips'             => $q['tip'] ?? null,
                        'explanation'      => $q['explanation'] ?? null,
                        'created_by'       => $user_id,
                        'updated_by'       => $user_id,
                        'created_at'       => now(),
                        'updated_at'       => now(),
                    ]);
    
                    $inserted++;
                }
            }
    
            // Final toastr flash
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => "Question Import completed! Inserted: {$inserted}, Skipped: {$skipped}"
            ]);
        } catch (\Exception $e) {
            // On any error, flash message
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Import failed! Error: ' . $e->getMessage()
            ]);
        }
    
        return redirect('/question-bank');
    }
}
