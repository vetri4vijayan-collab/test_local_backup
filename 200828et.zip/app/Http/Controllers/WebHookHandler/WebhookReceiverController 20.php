<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel;
use App\Models\SubDepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\JobpositionModel;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\UserRolePermissionModel;
use App\Events\StaffExistUpdated;
use App\Models\TransactionModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\GoalSetStaffModel;
use App\Models\IncentiveModel;
use App\Models\BranchModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;



class WebhookReceiverController extends Controller
{

   public function broadcastMessage(Request $request)
        {
           
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }
 
                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);
 
                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
               
            $updateBroadcast = NewsBroadcastModel::updateOrCreate(
                ['external_uuid' => $payload['sno']],
                [
 
                    'template_name' => $payload['template_name'] ?? NULL,
                    'broadcast_message' => $payload['broadcast_message'] ?? NULL,
                    'branch_id' => $payload['branch_id'] ?? NULL,
                    'role_ids' => $payload['role_ids'] ?? NULL,
                    'start_date' => $payload['start_date'] ?? NULL,
                    'end_date' => $payload['end_date'] ?? NULL,
                    'information' => $payload['information'] ?? NULL,
                    'theme_id' => $payload['theme_id'] ?? 0,
                    'theme_style' => $payload['theme_style'] ?? NULL,
                    'created_by' => $request->user()->user_id ?? 0,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]
            );
 
           
 
            return response()->json([
                'ok' => true,
                'sno' => $updateBroadcast->sno,
            ], 200);
        }



    // Deparment Webhook Start
    public function DepartmentList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
       $departmentList=DB::table('za_department')
       ->select('za_department.*')
       ->where('za_department.status',0)
       ->get();
       $lastId = DB::table('za_department')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function DepartmentHook(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $department = DepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],
            [
                'department_id'    => $payload['department_id'] ?? null,
                'entity_id'        => 1,
                'branch_id'        =>  1,
                'department_name'  => $payload['department_name'],
                'department_desc'  => $payload['department_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'uuid' => $uuid,
        ], 200);
    }

    public function UpdateDepartmentUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_department_id'];
        if($erpId){
            $department = DepartmentModel::where('sno', $erpId)->first();

            if ($department) {
                $department->external_uuid = $uuid;
                $department->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'department Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'department id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }
    // Deparment Webhook End



     // Division Webhook Start
    public function DivisionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $depart_id = $request->department_id;
        // return $depart_id;
       $departmentList=DB::table('za_sub_department')
       ->select('za_sub_department.*','za_sub_department.sub_department_name as division_name');
       if($depart_id){
         $departmentList->where('za_sub_department.department_id',$depart_id);
       }
      
       $departmentList=$departmentList->where('za_sub_department.status',0)
       ->get();

       $lastId = DB::table('za_sub_department')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

     public function DivisionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

        $department = SubDepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'department_id'    => $payload['erp_department_id'],
                'branch_id'        => 1,
                'sub_department_name'  => $payload['division_name'],
                'sub_department_desc'  => $payload['division_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

     public function UpdateDivisionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_division_id'];
        if($erpId){
            $division = SubDepartmentModel::where('sno', $erpId)->first();

            if ($division) {
                $division->external_uuid = $uuid;
                $division->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Division Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Division id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $division->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

     // Division Webhook End

    // Job Position Webhook Start
    public function JobPostionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $division_id = $request->division_id;
        // return $depart_id;
       $departmentList=DB::table('za_job_position')
       ->select('za_job_position.*','za_job_position.sub_department_id as division_id');
       if($division_id){
         $departmentList->where('za_job_position.sub_department_id',$division_id);
       }
       $departmentList=$departmentList->where('za_job_position.status',0)
       ->get();
       $lastId = DB::table('za_job_position')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function JobPositionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

         $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {

              $year = substr(date("y"), -2);
              $job_position_id = "JP-0001/" . $year;
            } else {

              $data = $category_check->job_position_id;
              $slice = explode("/", $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);

              $next_number = (int) $result + 1;
              $request = sprintf("JP-%04d", $next_number);

              $year = substr(date("y"), -2);
              $job_position_id = $request . '/' . $year;
            }

        $department = JobpositionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'job_position_id'    => $job_position_id,
                'department_id'    => $payload['erp_department_id'],
                'division_id'    => $payload['erp_division_id'],
                'branch_id'        => 1,
                'job_position_name'  => $payload['job_position_name'],
                'job_position_desc'  => $payload['job_position_desc'] ?? null,
                'per_hour_cost'  => $payload['per_hour_cost'] ?? 0,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }
    public function UpdateJobPositionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_job_role_id'];
        if($erpId){
            $jobPosition = JobpositionModel::where('sno', $erpId)->first();

            if ($jobPosition) {
                $jobPosition->external_uuid = $uuid;
                $jobPosition->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $jobPosition->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Job Position Webhook End



    // UserRole Webhook Start
    public function userRoleList(Request $request)
    {
        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $departmentList = DB::table('za_user_role')
            ->select('za_user_role.*')
            ->where('za_user_role.status', 0)
            ->get();

        $lastId = DB::table('za_user_role')
            ->orderBy('sno', 'desc')
            ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;

        return response()->json([
            'status' => 200,
            'data' => $departmentList,
            'nextId' => $nextId
        ], 200);
    }

    public function UpdateUserRoleUUID(Request $request)
    {
        // Get UUID (idempotency key or generate a new UUID if not provided)
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        // Get the erp_role_id from the payload
        $erpId = $payload['erp_role_id'] ?? null;

        if ($erpId) {
            // Find the user role by erp_role_id
            $userRole = DB::table('za_user_role')->where('sno', $erpId)->first();

            if ($userRole) {
                // Update the external_uuid for the found user role
                DB::table('za_user_role')
                    ->where('sno', $erpId)
                    ->update(['external_uuid' => $uuid]);

                return response()->json([
                    'ok' => true,
                    'sno' => $userRole->sno,
                    'message' => 'External UUID updated successfully',
                    'uuid' => $uuid,
                ], 200);
            } else {
                // If user role is not found
                return response()->json([
                    'ok' => false,
                    'message' => 'User Role not found',
                    'uuid' => $uuid,
                ], 200); // Use 404 for not found error
            }
        } else {
            // If erp_role_id is not provided
            return response()->json([
                'ok' => false,
                'message' => 'User Role ID not provided',
                'uuid' => $uuid,
            ], 200); // Use 400 for bad request error
        }
    }
    // UserRole Webhook End

    // Staff Webhook Start

        public function StaffData(Request $request){

            $auth_key = $request->auth_key;
            $verify_key = 'egcsecret2030datagetapierp';

            if ($auth_key !== $verify_key) {
                return response()->json([
                    'status' => 410,
                    'data' => null,
                    'message' => 'Unauthorized Entry'
                ], 410);
            }

            $staffdata=DB::table('za_staff')
                ->select('za_staff.*','za_department.department_name','za_sub_department.sub_department_name as division_name','za_user_role.role_name')
                ->where('za_staff.branch_id',6)
                // ->where('za_staff.branch_id',11)
                ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
                ->join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->where('za_staff.status',0)
                ->where('za_staff.sno','>',1)
                // ->whereIN('za_staff.sno',[162,164,188])
                // ->where('za_staff.department_id','!=',10)
                ->get();

            foreach($staffdata as $staff){
                if($staff->staff_image){
                    $staff->staff_image= url('staff_images/' . $staff->staff_image);
                }else{
                    $staff->staff_image='';
                }
                $staff->staff_work_info=[];
                if($staff->exp_type == 2){
                    $WorkDetails = StaffWorkInfoModel::where('staff_id', $staff->sno)->where('status',0)
                            ->get();
                    $staff->staff_work_info = $WorkDetails ?? [];

                }
                 $staff->staff_education_info=[];

                  $existingQualification = StaffEducationInfoModel::where('staff_id', $staff->sno)
                                    ->get();
                  $staff->staff_education_info = $existingQualification ?? [];


            }

            return response()->json(['status' => 200, 'data' => $staffdata], 200);
        }

        public function StaffAddHook(Request $request)
        {

            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }
                
                $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff already exists'
                    ], 200);
                }
                
                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }

                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
              $add_staff = StaffModel::updateOrCreate(
                  ['external_uuid' => $uuid],
                  [
                      'staff_id' => $payload['staff_id'],
                      'branch_id' => 6,
                      'branch_franchise' => 1,
                      'entity_id' => 1,
                      'shift_time_id' => 1,
                      'multi_branch_access' => null,
                      'sub_department_id' => $payload['sub_department_id'] ?? 0,
                      'department_id' => $payload['department_id'] ?? 0,
                      'role_id' => $payload['role_id'],
                      'exp_type' => $payload['exp_type'],
                      'staff_name' => $payload['staff_name'],
                      'mobile_no' => $payload['mobile_no'],
                      'alternative_no' => $payload['alternative_no'] ?? null,
                      'email_id' => $payload['email_id'],
                      'gender' => $payload['gender'],
                      'dob' => $payload['dob'],
                      'date_of_joining' => $payload['date_of_joining'],
                      'contact_person_name' => $payload['contact_person_name'] ?? null,
                      'contact_person_no' => $payload['contact_person_no'] ?? null,
                      'martial_status' => $payload['martial_status'],
                      'address' => $payload['address'] ?? null,
                      'staff_image' => $staff_image ?? null,
                      'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): json_encode([]),
                      'nick_name' => $payload['nick_name'] ?? null,
                      'position_role' => $payload['position_role'] ?? null,
                      'description' => $payload['description'] ?? null,
                      'basic_salary' => $payload['basic_salary'] ?? null,
                      'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                      'login_access' => $payload['login_access'] ?? 0,
                      'user_name' => $payload['user_name'],
                      'password' => $payload['password'],
                      'created_by' => $request->user()->user_id ?? 1,
                      'updated_by' => $request->user()->user_id ?? 1,
                  ]
              );
            if ($add_staff) {
                    // Create user credentials if not exists
                    $existingUser = User::where('user_id', $add_staff->sno)->first();
                    if (!$existingUser) {
                        if($payload['login_access'] == 1){
                        User::create([
                            'user_id' => $add_staff->sno,
                            'role_id' => $add_staff->role_id ?? 0,
                            'branch_id' => $add_staff->branch_id,
                            'entity_id' => $add_staff->entity_id,
                            'name' => $add_staff->user_name,
                            'password' => Hash::make($add_staff->password),
                            'email' => $add_staff->email_id,
                            'created_by' => $request->user()->user_id ?? 1,
                            'updated_by' => $request->user()->user_id ?? 1,
                        ]);
                        }
                    }


                        // if (!empty($payload['qualification_type'])) {
                        //     foreach ($payload['qualification_type'] as $key => $qualification_type) {
                        //         // Avoid duplicate work entries for same staff
                        //         $existingQualification = StaffEducationInfoModel::where('staff_id', $add_staff->sno)
                        //             ->where('qualification_type', $qualification_type)
                        //             ->where('degree_name', $payload['degree_name'][$key] ?? '')
                        //             ->first();

                        //         if (!$existingQualification) {
                        //             StaffEducationInfoModel::create([
                        //                 'staff_id' => $add_staff->sno,
                        //                 'qualification_type' => $qualificationType,
                        //                 'degree_name' => $payload['degree_name'][$key] ?? null,
                        //                 'major' => $payload['major'][$key] ?? null,
                        //                 'university_name' => $payload['university_name'][$key] ?? null,
                        //                 'created_by' => 1,
                        //                 'updated_by' => 1,
                        //             ]);
                        //         }
                        //     }
                        // }

                    // Handle work experience (if applicable)
                    if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                        foreach ($payload['work_company_name'] as $key => $company) {
                            // Avoid duplicate work entries for same staff
                            $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                                ->where('company_name', $company)
                                ->where('position', $payload['work_position'][$key] ?? '')
                                ->first();

                            if (!$existingWork) {
                                StaffWorkInfoModel::create([
                                    'staff_id' => $add_staff->sno,
                                    'staff_type' => $payload['exp_type'],
                                    'position' => $payload['work_position'][$key] ?? null,
                                    'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                    'company_name' => $company,
                                    // 'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                    // 'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                    'created_by' => $request->user()->user_id ?? 1,
                                    'updated_by' => $request->user()->user_id ?? 1,
                                ]);
                            }
                        }
                    }
                }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }

        public function UpdateStaffUUID(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) Str::uuid();

            $payload = $request->all();

            $erpId = $payload['erp_staff_id'];
            if($erpId){
                $staff = StaffModel::where('sno', $erpId)->first();

                if ($staff) {
                    $staff->external_uuid = $uuid;
                    $staff->save();
                }else{
                    return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff Not Found',
                    'uuid' => $uuid,
                ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
            return response()->json([
                'ok'  => true,
                'sno' => $staff->sno,
                'meassage'=>'external uuid updated',
                'uuid' => $uuid,
            ], 200);
        }

    // Staff Webhook End

    // Staff Attendance Webhook Start
        public function StaffAddAttendanceHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }


                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                $staffData = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
                
                 $alreadyExists = StaffAttendanceModel::where([
                    ['staff_id', '=', $staffData->sno],
                    ['date', '=', $payload['date']],
                    ['status', '!=', 2], 
                ])->first();
            $year = date("Y");
            $month = date("m");
            $addStaff = null;
            if (in_array($payload['attendance'], ['OD', 'PR','P'])) {
                
            if ($alreadyExists) {
                $alreadyExists->attendance = $payload['attendance'];
                $alreadyExists->time_start = $payload['time_start'] ?? null;
                $alreadyExists->time_end = $payload['time_end'] ?? null;
                $alreadyExists->reason = $payload['reason'] ?? null;
                $alreadyExists->external_uuid = $uuid ;
                $alreadyExists->update();
                $addStaff=$alreadyExists;
            }else{
                // Generate a new staff attendance ID
                    $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                    $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

                    // Save new attendance record
                $addStaff= StaffAttendanceModel::updateOrCreate(
                        ['external_uuid' => $uuid],
                        [
                        'staff_attendance_id' => $staff_attendance_id,
                        'branch_id'           => $staffData->branch_id ?? 6,
                        'staff_id'            => $staffData->sno,
                        'date'                => $payload['date'],
                        'attendance'          => $payload['attendance'],
                        'type'                => $payload['type'] ?? null,
                        'time_start'          => $payload['time_start'] ?? null,
                        'time_end'            => $payload['time_end'] ?? null,
                        'reason'              => $payload['reason'] ?? null,
                        'created_by'          => 0,
                        'updated_by'          => 0,
                        ]
                );
            }  
            
                
            }

            return response()->json([
                'ok' => true,
                'sno' => $addStaff ? $addStaff->sno : 0,
            ], 200);
        }

    
         public function StaffAddAttendanceHookEssl(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('batch_uuid')
                ?? (string) Str::uuid();
 
           $rawContent = $request->getContent();

                $payload = json_decode($rawContent, true);

                // If double encoded JSON string
                if (is_string($payload)) {
                    $payload = json_decode($payload, true);
                }

                // Final fallback
                if (!$payload || !is_array($payload)) {
                    $payload = $request->all();
                }

            if (empty($payload['records']) || !is_array($payload['records'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Attendance records required',
                    "data" => $payload ?? "-"
                ], 400);
            }


 
            DB::beginTransaction();
 
            try {
 
                foreach ($payload['records'] as $record) {
 
                    $staffData = StaffModel::where('external_uuid', $record['staff_id'])->first();
 
                    if (!$staffData) {
                        continue; // skip if staff not found
                    }
 
                    $alreadyExists = StaffAttendanceModel::where([
                        ['staff_id', '=', $staffData->sno],
                        ['date', '=', $record['date']],
                        ['status', '!=', 2],
                    ])->first();
 
                    if ($alreadyExists) {
 
                        if (in_array($alreadyExists, ['OD', 'PR', 'L','P'])) {
                                $alreadyExists->update([
                                    'in_time'    => $record['in_time'] ?? null,
                                    'out_time'   => $record['out_time'] ?? null,
                                ]);
                        }else{
                            $alreadyExists->update([
                                'attendance' => $record['attendance'],
                                'in_time'    => $record['in_time'] ?? null,
                                'out_time'   => $record['out_time'] ?? null,
                                'reason'     => $record['reason'] ?? null,
                                'external_uuid' => $record['sno'],
                            ]);
                        }
 
                    } else {
 
                        $category_check = StaffAttendanceModel::where('status','!=',2)
                            ->orderBy('sno','desc')
                            ->first();
 
                        $staff_attendance_id = $this->generateStaffAttendanceId(
                            $category_check,
                            date("m"),
                            date("Y")
                        );
                        
                        if($record['attendance'] != 'A'){
 
                        StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'branch_id'           => $staffData->branch_id ?? 6,
                            'staff_id'            => $staffData->sno,
                            'date'                => $record['date'],
                            'attendance'          => $record['attendance'],
                            'in_time'             => $record['in_time'] ?? null,
                            'out_time'            => $record['out_time'] ?? null,
                            'reason'              => $record['reason'] ?? null,
                            'external_uuid'       => $record['sno'],
                            'created_by'          => 0,
                            'updated_by'          => 0,
                        ]);
                    }
                    }
                }
 
                DB::commit();
 
                return response()->json([
                    'ok' => true,
                    'message' => 'Attendance processed successfully'
                ], 200);
 
            } catch (\Throwable $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'ok' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
        }
        private function generateStaffAttendanceId($category_check, $month, $year)
        {
            if (!$category_check) {
                return 'ATT0001/' . $month . '/' . $year;
            }

            // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
            $data = $category_check->staff_attendance_id;
            $slice = explode("/", $data);

            // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
            $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$resultcus + 1;

            // Return the formatted ID (e.g., "ATT0002/11/2025")
            return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
        }
    // Staff Attendance Webhook End


// user Credential Check Api
    public function userCrendentialCheck(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        $user = User::select('users.*', 'za_staff.status as staff_status')
        ->where('users.name', $request->name)
        ->leftJoin('za_staff', 'users.user_id', '=', 'za_staff.sno')
        ->leftJoin('za_branch', 'users.branch_id', '=', 'za_branch.sno')
        // ->where('za_staff.status', 0)
        ->where('za_branch.status', 0)
        ->first();
        
        if (!$user) {
            return response()->json([
                'type' => 'error',
                'message' => 'User not found.'
            ]);
        }

        if ($user->staff_status == 1) {

            return response()->json([
                'type' => 'error',
                'message' => 'This user is inactive. Please contact the administrator.'
            ], 200);

        } elseif ($user->staff_status == 2) {
            return response()->json([
                'type' => 'error',
                'message' => 'This user is deactivated. Please contact the administrator.'
            ], 200);
        }
        if ($user->name !== $request->name) {
            return response()->json([
                'type' => 'error',
                'message' => 'Username is case-sensitive. Please enter the correct case.'
            ], 200);
        }

        // if (!Hash::check($request->password, $user->password)) {
        //     return response()->json([
        //         'type' => 'error',
        //         'message' => 'Invalid credentials'
        //     ], 200);
        // }

        $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();
    
        if (!$permissions) {
            return response()->json([
                'type' => 'error',
                'message' => 'Role Permission Not Set in EAPL ERP'
            ], 200);
        }

        return response()->json([
        'type' => 'Success',
        'message' => 'User Found'
        ], 200);
        
    }


public function updateTargets(Request $request)
    {
        DB::beginTransaction();
 
        try {
 
            //  Idempotency
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) \Str::uuid();
 
            $payload = $request->all();
 
            // Handle string payload
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);
            }
 
            \Log::info('Decoded Payload:', $payload);
 
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
 
            $targets = $payload['targets'] ?? [];
 
            foreach ($targets as $target) {
 
                DB::table('branch_target')->updateOrInsert(
                    [
                        'branch_id' => $target['branch_id'],
                        'date'      => $target['date'],
                    ],
                    [
                        'quarter' => $target['quarter'],
                        'no_of_registrations' => $target['pre_sale'],
                        'post_sale' => $target['post_sale'],
                        'monthly_target' => $target['monthly_target'],
                        'updated_by' => 1,
                        'created_by' => 1,
                        'updated_at' => now(),
                    ]
                );
 
                $targetId = DB::table('branch_target')
                    ->where('branch_id', $target['branch_id'])
                    ->where('date', $target['date'])
                    ->value('sno');
 
                foreach ($target['weeks'] as $week) {
 
                    // [$startDay, $endDay] = $this->getWeekRange($week['week'], $target['date']);
 
                    DB::table('za_weekly_metrics')->updateOrInsert(
                        [
                            'target_id' => $targetId,
                            'week_name' => 'Week ' . $week['week'],
                        ],
                        [
                            'start_day' => \Carbon\Carbon::parse($week['start_day'])->format('d'),
                            'end_day'   => \Carbon\Carbon::parse($week['end_day'])->format('d'),
                            'percentage' => $week['percentage'],
                            'target_amount' => $week['target_amount'],
                            'pre_sale' => $week['pre_sale'],
                            'post_sale' => $week['post_sale'],
                            'updated_by' => 1,
                            'created_by' => 1,
                            'updated_at' => now(),
                        ]
                    );
                }
            }
            DB::commit();
 
            return response()->json([
                'ok' => true,
                'message' => 'Target synced successfully'
            ], 200);
 
        } catch (\Exception $e) {
 
            DB::rollBack();
 
            \Log::error('Target Sync Failed: ' . $e->getMessage());
 
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
 
  public function UpdateExistStaff(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) Str::uuid();
 
            $payload = $request->all();
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }
 
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
            try{
 
            if($payload['staff_id']){
                // $staff = StaffModel::where('sno', $erpId)->first();
                $staff = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
 
                if ($staff) {
                    $staff->status = 1;
                    $staff->is_exist_egc = $payload['status'] ?? 1;;
                    $staff->dep_reason = $payload['dep_reason'] ?? null;
                    $staff->notice_start_date = $payload['notice_start_date'] ?? null;
                    $staff->notice_end_date = $payload['notice_end_date'] ?? null;
                    $staff->staff_last_date = $payload['staff_last_date'] ?? null;
                    $staff->save();
 
                    event(new StaffExistUpdated($staff));
 
                     return response()->json([
                        'ok'  => true,
                        'sno' => $staff->sno,
                        'meassage'=>'Exit Staff Updated',
                        'uuid' => $uuid,
                    ], 200);
                   
 
                }else{
                    return response()->json([
                        'ok'  => true,
                        'meassage'=>'Staff Not Found',
                        'uuid' => $uuid,
                    ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
 
            }catch(\Throwable $e){
                    return response()->json([
                        'ok'  => false,
                        'message' => $e->getMessage(),
                    ], 500);
            }
            // $erpId = $payload['erp_staff_id'];
           
 
           
        }
 
        public function existStaffCount()
    {
        $count = StaffModel::where('is_exist_egc', '!=',0)
            ->where('status', 1)
            ->count();
 
        return response()->json([
            'count' => $count
        ]);
    }
 
       public function existStaffList()
    {
        $staff = StaffModel::where('za_staff.is_exist_egc','!=',0)
            ->where('za_staff.status', 1)
            ->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->select(
                'za_staff.staff_name',
                'za_staff.sno as id',
                'za_staff.staff_image',
                'za_staff.is_exist_egc',
                'za_staff.staff_last_date',
                'za_staff.notice_start_date',
                'za_staff.notice_end_date',
                'za_staff.dep_reason',
                'za_department.department_name',
                'za_job_position.job_position_name'
            )
            ->get();
 
        return response()->json($staff);
    }

public function getAchieveData(Request $request)
    {
        try {
 
            $verify_key = 'egcsecret2030datagetapierp';
 
            if ($request->verify_key !== $verify_key) {
 
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized'
                ], 401);
            }
 
            $branchId = $request->branch_id;
 
            $fromDate = Carbon::parse($request->from_date)->format('Y-m-d');
            $toDate   = Carbon::parse($request->to_date)->format('Y-m-d');
 
            $dates = [];
 
            $period = CarbonPeriod::create($fromDate, $toDate);
            $helper = new \App\Helpers\Helpers();
 
            $branch_common = DB::table('za_branch')->select('za_branch.*')
            ->where('za_branch.sno', $branchId)
            ->first();
 
            foreach ($period as $dateObj) {
 
                $date = $dateObj->format('Y-m-d');
 
                $dailyCredit = TransactionModel::where('branch_id', $branchId)
                    ->whereDate('transaction_date', $date)
                    ->sum('credit');
               
                $total_collection_value = round($dailyCredit);
 
                // PRE SALE
                $preSale = DB::table('za_customer')->whereIn('status', [0, 6])
                    ->where('post_sale_check', '!=', 1)
                    ->where('branch_id', $branchId)
                    ->whereDate('created_at', $date)
                    ->count();
 
                // POST SALE
                // $postSale = DB::table('za_customer')->whereIn('status', [0, 6])
                //     ->where('post_sale_check', 1)
                //     ->where('branch_id', $branchId)
                //     ->whereDate('created_at', $date)
                //     ->count();
 
                $postSale =DB::table('za_customer')->whereIn('za_customer.status',[0,6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->where('za_customer.branch_id', $branchId)
                    ->where('za_customer.post_sale_check', 1)
                    ->where('za_training.post_sale_check', 1)
                    ->whereIn('za_customer.status',[0,6])
                    ->whereDate('za_training.created_at', $date)
                    ->count();
 
                $dates[] = [
                    'date' => $date,
                    'amount' => $total_collection_value,
                    'pre_sale' => (int)$preSale,
                    'post_sale' => (int)$postSale
                ];
            }
 
            return response()->json([
                'status' => true,
                'data' => $dates
            ]);
 
        } catch (\Exception $e) {
 
            \Log::error('Achieve API Error : ' . $e->getMessage());
 
            return response()->json([
                'status' => false,
                'message' => 'Server Error'
            ]);
        }
    }
    
   public function GetIncentive(Request $request)
{
    try {

        if ($request->verify_key !== 'egcsecret2030datagetapierp') {

            return response()->json([
                'status'  => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $request->validate([
            'branch_id' => 'required|integer',
            'role_id'   => 'required',
            'month_year'=> 'nullable|string'
        ]);

        $branchId = (int) $request->branch_id;
        $roleId   = trim($request->role_id);

        $monthFilter = $request->get('month_year', date('M-Y'));
        try {

            $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);

        } catch (\Exception $e) {

            $parsedDate = now();
        }

        $month = (int) $parsedDate->month;
        $year  = (int) $parsedDate->year;

        $cacheVersion = 'v3';

        $cacheKey = implode('_', [
            'incentive',
            $cacheVersion,
            'branch', $branchId,
            'role', $roleId,
            'year', $year,
            'month', $month
        ]);

        $responseData = Cache::remember(
            $cacheKey,
            now()->addMinutes(30),
            function () use (
                $branchId,
                $roleId,
                $year,
                $month
            ) {
                $staffs = DB::table('za_staff')
                    ->select([
                        'sno',
                        'staff_name',
                        'external_uuid',
                        'role_id'
                    ])
                    ->where('role_id', $roleId)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->orderBy('staff_name')
                    ->get();

                if ($staffs->isEmpty()) {

                    return [
                        'generated_at' => now()->format('Y-m-d H:i:s'),
                        'next_refresh' => now()->addMinutes(30)->format('Y-m-d H:i:s'),
                        'count'        => 0,
                        'data'         => []
                    ];
                }

                $incentiveData = [];

                foreach ($staffs as $staff) {
                    try {
                        $result = self::calculateIncentiveValue(
                            $staff->sno,
                            $branchId,
                            $roleId,
                            $year,
                            $month
                        );
                        $totalAward = (float) ($result['total_award'] ?? 0);
                        $breakdown = $result['breakdown'] ?? [];

                        foreach ($breakdown as $key => $value) {
                            $breakdown[$key] = (float) $value;
                        }

                        $incentiveData[] = [
                            'staff_id' => (int) $staff->sno,
                            'external_uuid' => (int) $staff->external_uuid,
                            'staff_name' => $result['staff_name']
                                ?? $staff->staff_name,
                            'role_id' => $result['role_id']
                                ?? $staff->role_id,
                            'total_award' => round($totalAward, 2),
                            'currency' => 'INR',
                            'breakdown' => $breakdown,
                            'last_updated' => now()
                                ->format('Y-m-d H:i:s'),
                            'next_update' => now()
                                ->addMinutes(30)
                                ->format('Y-m-d H:i:s'),
                        ];

                    } catch (\Throwable $e) {
                        Log::error('Incentive Staff Error', [
                            'staff_id' => $staff->sno,
                            'message'  => $e->getMessage()
                        ]);

                        $incentiveData[] = [
                            'staff_id'      => (int) $staff->sno,
                            'external_uuid'      => (int) $staff->external_uuid,
                            'staff_name'    => $staff->staff_name,
                            'external_uuid'    => $staff->external_uuid,
                            'role_id'       => $staff->role_id,
                            'total_award'   => 0,
                            'currency'      => 'INR',
                            'breakdown'     => [],
                            'last_updated'  => now()->format('Y-m-d H:i:s'),
                            'next_update'   => now()->addMinutes(30)
                                ->format('Y-m-d H:i:s'),
                        ];
                    }
                }
                usort($incentiveData, function ($a, $b) {
                    return $b['total_award'] <=> $a['total_award'];
                });
                return [
                    'generated_at' => now()
                        ->format('Y-m-d H:i:s'),
                    'next_refresh' => now()
                        ->addMinutes(30)
                        ->format('Y-m-d H:i:s'),
                    'count' => count($incentiveData),
                    'data' => $incentiveData
                ];
            }
        );
        return response()->json([
            'status'  => true,
            'message' => 'Incentive data fetched successfully',
            'cached' => true,
            'cache_expires_in_minutes' => 30,
            'generated_at' => $responseData['generated_at'] ?? null,
            'next_refresh' => $responseData['next_refresh'] ?? null,
            'total_staff' => $responseData['count'] ?? 0,
            'data' => $responseData['data'] ?? []
        ]);

    } catch (\Throwable $e) {
        Log::error('Get Incentive API Error', [
            'message' => $e->getMessage(),
            'line'    => $e->getLine(),
            'file'    => $e->getFile(),
        ]);
        return response()->json([

            'status'  => false,
            'message' => 'Server Error'
        ], 500);
    }
}

  private static function calculateIncentiveValue($userId, $branchId, $roleId, $year, $month)
  {
    $staff = StaffModel::find($userId);
    if (!$staff) {
      return self::getEmptyResponse();
    }

    // Get incentive settings
    $incentive = IncentiveModel::where('role_id', $roleId)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $year)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      // Try fallback date
      $fallbackDate = '2025-06-01';
      $incentive = IncentiveModel::where('role_id', $roleId)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
        ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
        ->where('status', 0)
        ->first();
    }

    if (!$incentive) {
      return self::getEmptyResponse();
    }

    // Get goal data
    $goalData = GoalSetStaffModel::where('staff_id', $userId)
      ->where('goal_month', $month)
      ->whereYear('goal_date', $year)
      ->first();

    // Calculate based on role
    $totalReward = 0;
    $breakdown = [];

    switch ($roleId) {
      case 11: // Sales Executive
        $result = self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 12: // Team Lead
        $result = self::calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 14: // Collection
        $result = self::calculateCollectionReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 15: // PC
        $result = self::calculatePCReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 16: // CRE
        $result = self::calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 22: // Production
        $result = self::calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 17: // Production
        $result = self::calculatePlacementExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 19: // Production
        $result = self::calculatePlacementLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      default:
        return self::getEmptyResponse();
    }

    return [
      'total_award' => $totalReward,
      'breakdown' => $breakdown,
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'staff_name' => $staff->staff_name,
      'staff_id' => $staff->sno,
      'egc_staff_id' => $staff->external_uuid,
      'role_id' => $roleId
    ];
  }

  /**
   * Calculate Sales Executive Reward (Exact logic from your code)
   */
  private static function calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get previous month for calculations
    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    // 1. Get customer conversion count for the month
    $customerConvertCountthismonth = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    // 2. Get previous month converted customers for bad customer deduction
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // 3. Calculate bad customers (dropouts, low payment, no second payment)
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully paid customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second payment customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Low payment customers
    $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->select('za_customer.sno as customer_sno', 'za_training.paid_amount as total_paid_amount')
      ->get()
      ->unique('payment_id');

    $lowMbcCustomerIds = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < ($branch->min_prd_cost ?? 0);
    })->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    $actualConversion = max(0, $customerConvertCountthismonth - count($badCustomerIds));

    // 4. Get target from goal data
    $targetConversion = $goalData->conversion ?? 0;
    $targetABV = $goalData->ABV ?? 0;
    $targetACV = $goalData->ACV ?? 0;

    // 5. Calculate business values
    $total_payment = 0;
    $total_paid_payment = 0;

    if ($actualConversion > 0) {
      $currentMonthCustomer = CustomerModel::select('za_customer.sno')
        ->whereIn('za_customer.status', [0, 6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->get();

      foreach ($currentMonthCustomer as $customer) {
        $payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 0)
          ->sum('overall_fees');
        $total_payment += $payment;

        $latestTraining = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 2)
          ->orderByDesc('sno')
          ->first();

        if ($latestTraining) {
          $total_payment += $latestTraining->overall_fees;
        }

        $paid_payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->sum('paid_amount');
        $total_paid_payment += $paid_payment;
      }
    }

    $averageBusinessValue = $actualConversion > 0 ? $total_payment / $actualConversion : 0;
    $averageCollectionValue = $actualConversion > 0 ? $total_paid_payment / $actualConversion : 0;

    // 6. Check 10X Award status
    $tenxStatus = (
      $targetConversion > 0 &&
      $targetABV > 0 &&
      $targetACV > 0 &&
      $actualConversion >= $targetConversion
    );

    if ($tenxStatus) {
      $tenxReward = $incentive->tenx_award ?? 0;
      $totalReward += $tenxReward;
      $breakdown['10X Award'] = $tenxReward;
    }else{
         $breakdown['10X Award'] = 0;
    }

    // 7. ECI Award (Early Conversion before 15th)
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->count();

    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciStatus = $tenxStatus && ($eciActualPercentage >= $eciTargetPercentage);

    if ($eciStatus) {
      $eciReward = $incentive->eci_reward ?? 0;
      $totalReward += $eciReward;
      $breakdown['ECI Award'] = $eciReward;
    }else{
        $breakdown['ECI Award'] = 0;
    }

    // 8. BI Award (Beyond Incentive)
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $actualConversion - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $tenxStatus && ($biAchievedCount > 0);

    if ($biStatus) {
      $totalReward += $biReward;
      $breakdown['BI Award'] = $biReward;
    }else{
        $breakdown['BI Award'] = 0;
    }

    // 9. SI Award (Spot Incentive)
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;

    if ($actualConversion > 0) {
      $currentMonthCustomer = CustomerModel::select('za_customer.sno')
        ->whereIn('za_customer.status', [0, 6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->get();

      foreach ($currentMonthCustomer as $customer) {
        $hasTesbo = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('branch_id', $branchId)
          ->whereMonth('created_at', $month)
          ->whereYear('created_at', $year)
          ->where('tesbo_check', 2)
          ->where('post_sale_check', '!=', 1)
          ->exists();

        if ($hasTesbo) {
          $tesboCount++;
          continue;
        }

        $nonTesboTrainings = DB::table('za_training')
          ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
          ->where('za_training.customer_id', $customer->sno)
          ->where('za_training.branch_id', $branchId)
          ->whereMonth('za_training.created_at', $month)
          ->whereYear('za_training.created_at', $year)
          ->where('za_training.post_sale_check', '!=', 1)
          ->where('za_training.tesbo_check', '!=', 2)
          ->whereIn('za_course.course_type_id', [3, 4])
          ->get();

        $hasCrash = false;
        $hasProfession = false;

        foreach ($nonTesboTrainings as $training) {
          if ($training->course_type_id == 3) $hasProfession = true;
          if ($training->course_type_id == 4) $hasCrash = true;
        }

        if ($hasCrash) $crashCount++;
        if ($hasProfession) $professionCount++;
      }
    }

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $incentive->si_crash_course);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $incentive->si_profession_course);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $incentive->si_tesbo_course);
      }
    }

    if ($tenxStatus && $siStatus) {
      $siReward = 3000;
      $totalReward += $siReward;
      $breakdown['SI Award'] = $siReward;
    }else{
        $breakdown['SI Award'] = 0;
    }

    // 10. SP Award (Spot Award)

    $startOfMonth = Carbon::create($year, $month, 1)->startOfMonth();
    $endOfMonth   = Carbon::create($year, $month, 1)->endOfMonth();

    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->select(
        'za_customer.created_at',
        'za_lead.created_at as lead_created_at',
        'za_lead.lead_mobile'
      )
      ->get();

    $convertedToday = 0;
    $convertedMonth = 0;

    foreach ($allConverted as $row) {

      //  Get all calls for this mobile
      $calls = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staff->sno)
        ->where('customer_phone_no', 'like', "%{$row->lead_mobile}")
        ->select('call_start_date')
        ->get();

      $totalCallCount = $calls->count();

      //  Check if any call is within selected month
      $hasValidCall = $calls->contains(function ($call) use ($startOfMonth, $endOfMonth) {
        $callDate = Carbon::parse($call->call_start_date);
        return $callDate->between($startOfMonth, $endOfMonth);
      });

      $customerDate = Carbon::parse($row->created_at);
      $leadDate     = Carbon::parse($row->lead_created_at);

      //  SAME DAY CONVERSION
      if (
        $customerDate->isSameDay($leadDate) &&
        $totalCallCount === 1
      ) {
        $convertedToday++;
      }

      //  SAME MONTH VALID CONVERSION
      elseif (
        $customerDate->between($startOfMonth, $endOfMonth) &&
        $leadDate->between($startOfMonth, $endOfMonth) &&
        $hasValidCall
      ) {
        $convertedMonth++;
      }
    }

    $spotIncentiveDayAmount   = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward          = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    if ($tenxStatus && $spotTotalReward > 0) {
      $totalReward += $spotTotalReward;
      $breakdown['SP Award'] = $spotTotalReward;
    }else{
        $breakdown['SP Award'] = 0;
    }


    // 11. PI Award (Profit Incentive)
    $pi_slabs = json_decode($incentive->pi_slab_json ?? '[]', true);
    $originalAmount = 0;
    $slabPercentage = 0;

    if ($actualConversion > 0) {
      $currentMonthCustomer = CustomerModel::select('za_customer.sno')
        ->whereIn('za_customer.status', [0, 6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->get();

      foreach ($currentMonthCustomer as $customer) {
        $trainings = DB::table('za_training as t1')
          ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
          ->where('t1.customer_id', $customer->sno)
          ->get();

        foreach ($trainings as $training) {
          $course_id = $training->tesbo_check > 0
            ? optional(PaymentModel::where('payment_id', $training->payment_id)->first())->course_id
            : $training->course_id;

          if (!$course_id) continue;

          $course = ManageCoursesModel::where('sno', $course_id)
            ->whereIn('course_type_id', [2, 3])
            ->first();

          if ($course) {
            $profitAmount = $training->overall_fees - $course->course_min_price;
            $originalAmount += $profitAmount;

            $profitPercent = ($course->course_min_price != 0) ? ($profitAmount / $course->course_min_price) * 100 : 0;

            foreach ($pi_slabs as $slab) {
              if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                $slabPercentage = $slab['percentage'];
                break;
              }
            }
          }
        }
      }
    }

    $piReward = $slabPercentage > 0 ? ($originalAmount * $slabPercentage) / 100 : 0;

    if ($tenxStatus && $piReward > 0) {
      $totalReward += $piReward;
      $breakdown['PI Award'] = $piReward;
    }else{
        $breakdown['PI Award'] = 0;
    }

    // 12. LI Award (Luxury Incentive)
    $luxury = json_decode($incentive->luxury_incentive ?? '{}', true);
    $allIncentivesAchieved = ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward > 0);

    if ($allIncentivesAchieved) {
      $liReward = $luxury['reward'] ?? 0;
      $totalReward += $liReward;
      $breakdown['LI Award'] = $liReward;
    }else{
        $breakdown['LI Award'] = 0;
    }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'conversion_rate' => $actualConversion,
        'target_conversion' => $targetConversion,
        'tenx_status' => $tenxStatus
      ]
    ];
  }

  /**
   * Calculate Team Lead Reward
   */
  private static function calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    // Check if sales lead check is enabled
    $checkRecord = GoalSetStaffModel::where('branch_id', $branchId)
      ->where('goal_month', $month)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->where('staff_id', $staff->sno)
      ->first();

    if ($checkRecord && $checkRecord->sales_lead_check == 1) {
      // Sales Team Lead - use sales executive logic but aggregated for team
      return self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
    } else {
      // Regular Team Lead - aggregate from executives
      $executives = StaffModel::where('branch_id', $branchId)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $totalTeamReward = 0;
      $teamBreakdown = [];

      foreach ($executives as $executive) {
        $executiveGoalData = GoalSetStaffModel::where('staff_id', $executive->sno)
          ->where('goal_month', $month)
          ->whereYear('goal_date', $year)
          ->first();

        if ($executiveGoalData && ($executiveGoalData->conversion ?? 0) > 0) {
          $result = self::calculateSalesExecutiveReward($executive, $incentive, $executiveGoalData, $branchId, $year, $month);

          if ($result['metrics']['tenx_status'] ?? false) {
            $totalTeamReward += $incentive->tenx_award ?? 0;
            $teamBreakdown[$executive->staff_name] = $incentive->tenx_award ?? 0;
          }
        }
      }

      return [
        'total' => $totalTeamReward,
        'breakdown' => $teamBreakdown,
        'metrics' => ['team_size' => count($executives)]
      ];
    }
  }

//   /**
//   * Calculate Collection Reward
//   */
//   private static function calculateCollectionReward($staff, $incentive, $goalData, $branchId, $year, $month)
//   {
//     $totalReward = 0;
//     $breakdown = [];

//     // Get HAC amount
//     $dropoutCustomers = DB::table('za_training')->where('status', 2)->pluck('customer_id')->toArray();

//     $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth();
//     $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
//       ->whereIn('za_customer.status', [0, 6])
//       ->where('za_customer.branch_id', $branchId)
//       ->whereNotIn('za_customer.sno', $dropoutCustomers)
//       ->whereBetween('za_customer.created_at', [
//         $prevMonth->copy()->startOfMonth(),
//         $prevMonth->copy()->endOfMonth()
//       ])
//       ->pluck('za_customer.sno')
//       ->toArray();

//     $hacAmount = DB::table('za_payment')
//       ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
//       ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
//       ->where('za_payment.status', 1)
//       ->whereYear('za_payment.initialPayDate', $year)
//       ->whereMonth('za_payment.initialPayDate', $month)
//       ->where('za_payment.branch_id', $branchId)
//       ->sum('za_payment.paidAmount');

//     // Get team goals
//     $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
//       ->where('department_id', 7)
//       ->where('team_goal_month', $month)
//       ->where('team_goal_year', $year)
//       ->first();

//     $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
//     $isHacCostingRequired = ($ten_x['hac_10x'] ?? '0') == "1";

//     if ($goalData->hac) {
//       $targetTenx = $goalData->hac ?? 0;
//       $actaulTenx = $hacAmount;
//       $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

//       if ($tenxStatus) {
//         $tenxReward = $incentive->tenx_award ?? 0;
//         $totalReward += $tenxReward;
//         $breakdown['10X Award'] = $tenxReward;
//       }else{
//         $breakdown['10X Award'] = 0;
//       }

//       // Excess Incentive (EI)
//       if ($tenxStatus && ($incentive->excess_incentive ?? 0) > 0) {
//         $excessAmount = $actaulTenx - $targetTenx;
//         if ($excessAmount > 0) {
//           $eiReward = $excessAmount * ($incentive->excess_incentive / 100);
//           $totalReward += $eiReward;
//           $breakdown['EI Award'] = $eiReward;
//         }else{
//             $breakdown['EI Award'] = 0;
//         }
//       }else{
//             $breakdown['EI Award'] = 0;
//         }
//     }else{
//       $breakdown['10X Award'] = 0;
//       $breakdown['EI Award'] = 0;
//     }

//     // Reference Incentive (REI)
//     $refferal_count = DB::table('za_referral_persons')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
//       ->where('za_referral_persons.branch_id', $branchId)
//       ->where('za_referral_persons.referral_id', $staff->sno)
//       ->where('za_referral_persons.status', 0)
//       ->where('za_referral_persons.referral_type', 2)
//       ->where('za_customer.post_sale_check', 1)
//       ->whereYear('za_referral_persons.created_at', $year)
//       ->whereMonth('za_referral_persons.created_at', $month)
//       ->count();

//     $targetREI = $goalData->reference_sales ?? 0;
//     // $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;
//     $REIStatus = $targetREI != 0;

//     // if ($REIStatus) {
//     $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
//     $totalReward += $reiReward;
//     $breakdown['REI Award'] = $reiReward;
//     // }

//     return [
//       'total' => $totalReward,
//       'breakdown' => $breakdown,
//       'metrics' => [
//         'hac_amount' => $hacAmount,
//         'referral_count' => $refferal_count
//       ]
//     ];
//   }

private static function calculateCollectionReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];
    $current = Carbon::create($year, $month, 1);
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
    // Get HAC amount
    $dropoutCustomers = DB::table('za_training')->where('status', 2)->pluck('customer_id')->toArray();
 
    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth();
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->pluck('za_customer.sno')
      ->toArray();
 
    $hacAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->where('za_payment.status', 1)
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->where('za_payment.branch_id', $branchId)
      ->sum('za_payment.paidAmount');
 
    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();
 
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isHacCostingRequired = ($ten_x['hac_10x'] ?? '0') == "1";
 
    // 10X and EI Calculation (same as working code)
    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;
 
      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }
 
      // Excess Incentive (EI)
      if ($tenxStatus && ($incentive->excess_incentive ?? 0) > 0) {
        $excessAmount = $actaulTenx - $targetTenx;
        if ($excessAmount > 0) {
          $eiReward = $excessAmount * ($incentive->excess_incentive / 100);
          $totalReward += $eiReward;
          $breakdown['EI Award'] = $eiReward;
        }
      }
    }
 
    // Reference Incentive (REI) - KEEP THE SAME AS WORKING CODE
    // No conditions, always calculate exactly like the working version
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();
 
    // WORKING CODE LOGIC - ALWAYS calculate REI (no conditions)
    $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;
 
    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'hac_amount' => $hacAmount,
        'referral_count' => $refferal_count
      ]
    ];
  }
 
 

  /**
   * Calculate PC (Process Coordinator) Reward
   */
  private static function calculatePCReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    return self::calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month);
  }

  /**
   * Calculate CRE (Customer Relationship Executive) Reward
   */
  private static function calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get reviews count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staff->sno)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Get referrals count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('department_id', 6)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = ($ten_x['no_of_reviews_10x'] ?? '0') == "1";

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalData->no_of_reviews ?? 0;
      $actaulTenx = $review_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }else{
            $breakdown['10X Award'] = 0;
        }
    } else {
      $targetTenx = $goalData->reference_sales ?? 0;
      $actaulTenx = $refferal_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }else{
        $breakdown['10X Award'] = 0;
      }
    }

    // Reference Incentive
    $targetREI = $goalData->reference_sales ?? 0;
    $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;

    // if ($REIStatus) {
    $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;
    // }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'reviews' => $review_count,
        'referrals' => $refferal_count
      ]
    ];
  }

  /**
   * Calculate Production Reward
   */
  private static function calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Calculate earned amount from attendance
    $earned_amount = 0;
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $staff->sno)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    foreach ($batchIds as $batchId) {
      $batch = DB::table('za_batch')->find($batchId);
      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = DB::table('za_attendance')
          ->where('batch_id', $batchId)
          ->where('staff_id', $staff->sno)
          ->where('attendance', 'P')
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $studentCount = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $staff->sno)
      ->whereMonth('start_date', '<=', $month)
      ->whereYear('start_date', '<=', $year)
      ->whereMonth('end_date', '>=', $month)
      ->whereYear('end_date', '>=', $year)
      ->distinct('customer_id')
      ->count('customer_id');

    // Get referrals
    $refferal_count = DB::table('za_referral_persons')
      ->where('branch_id', $branchId)
      ->where('referral_id', $staff->sno)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = ($ten_x['production_costing_10x'] ?? '0') == "1";

    if ($isProductionCostingRequired) {
      $basic_pay = ($staff->basic_salary ?? 0) * 10;
      $costing_amount_asign = $goalData->production_costing ?? 0;
      $costing_amount = $basic_pay > 0 ? ($earned_amount / $basic_pay) * $costing_amount_asign : 0;

      $targetTenx = $costing_amount_asign;
      $actaulTenx = $costing_amount;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;
    } else {
      $targetTenx = $goalData->reference_sales ?? 0;
      $actaulTenx = $refferal_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;
    }

    if ($tenxStatus) {
      $tenxReward = $incentive->tenx_award ?? 0;
      $totalReward += $tenxReward;
      $breakdown['10X Award'] = $tenxReward;
    }else{
        $breakdown['10X Award'] = 0;
    }

    // PDI Award (Production Incentive)
    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
    $slabPercentage = 0;

    foreach ($slabs as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    if ($tenxStatus && $slabPercentage > 0) {
      $totalReward += $slabPercentage;
      $breakdown['PDI Award'] = $slabPercentage;
    }else{
        $breakdown['PDI Award'] = 0;
    }

    // Reference Incentive
    $targetREI = $goalData->reference_sales ?? 0;
    $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;

    if ($REIStatus) {
      $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
      $totalReward += $reiReward;
      $breakdown['REI Award'] = $reiReward;
    }else{
        $breakdown['REI Award'] = 0;
    }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'earned_amount' => $earned_amount,
        'student_count' => $studentCount,
        'referral_count' => $refferal_count
      ]
    ];
  }

  /**
   * Calculate PE (Placement Executive) Reward
   */
  private static function calculatePlacementExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get team goals with validation
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('department_id', $staff->department_id)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    if (!$goalsetteam) {
      return ['total' => 0, 'breakdown' => [], 'metrics' => []];
    }

    // Optimize queries - get counts in one go if possible
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staff->staff_id)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staff->staff_id)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    $referralCount = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // 10X Award
    if ($goalsetteam->no_of_placements_check == 1) {
      $targetTenx = $goalData->no_of_reviews ?? 0;
      $actualTenx = $tesboCount;

      if ($targetTenx > 0 && $actualTenx >= $targetTenx) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }else{
        $breakdown['10X Award'] = 0;
      }
    }else{
        $breakdown['10X Award'] = 0;
    }

    // REI Award (Reference Incentive)
    $targetREI = $goalData->reference_sales ?? 0;
    $reiReward = $referralCount * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;

    // PDI Award (Tesbo students)
    $pieSlabs = json_decode($incentive->pie_slab_json ?? '[]', true);
    $slabPercentage = 0;

    foreach ($pieSlabs as $slab) {
      if ($tesboCount >= $slab['min'] && $tesboCount <= $slab['max']) {
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Calculate PDI reward - FIX: Need proper calculation based on your business logic
    $pdiReward = $tesboCount * ($slabPercentage / 100); // Example: percentage of count
    // Or if it's a fixed amount based on slab: $pdiReward = $slabPercentage;
    $totalReward += $pdiReward;
    $breakdown['PDI Award'] = $pdiReward;

    // Others Award (Non-Tesbo students)
    $oieSlabs = json_decode($incentive->oie_slab_json ?? '[]', true);
    $slabPercentageOi = 0;

    foreach ($oieSlabs as $slab) {
      if ($othersSlab >= $slab['min'] && $othersSlab <= $slab['max']) {
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    // Calculate Others reward - FIX: Need proper calculation
    $othersReward = $othersSlab * ($slabPercentageOi / 100); // Example calculation
    $totalReward += $othersReward;
    $breakdown['Others Award'] = $othersReward;

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'placement' => $tenxReward,
        'referrals' => $reiReward,
        'pdi'       => $pdiReward,      // Fixed: show actual reward or count?
        'others'    => $othersSlab,   // Fixed: show actual count
      ]
    ];
  }


  /**
   * Calculate PL (Placement Lead) Reward
   */
  private static function calculatePlacementLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get reviews count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staff->sno)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Get referrals count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('department_id', $staff->department_id)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = ($ten_x['no_of_reviews_10x'] ?? '0') == "1";

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalData->no_of_reviews ?? 0;
      $actaulTenx = $review_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }else{
         $breakdown['10X Award'] = 0;
      }
    } else {
      $targetTenx = $goalData->reference_sales ?? 0;
      $actaulTenx = $refferal_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }else{
         $breakdown['10X Award'] = 0;
      }
    }

    // Reference Incentive
    $targetREI = $goalData->reference_sales ?? 0;
    $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;

    // if ($REIStatus) {
    $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;
    // }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'reviews' => $review_count,
        'referrals' => $refferal_count
      ]
    ];
  }

  /**
   * Get empty response
   */
  private static function getEmptyResponse()
  {
    return [
      'total_award' => 0,
      'breakdown' => [],
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'error' => 'No incentive configuration found'
    ];
  }
  
   public function AddTransferStaff(Request $request)
    {
 
        // Generate or get UUID
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                // Retrieve the payload and decode it
            $payload = $request->all();
                    // Check if the payload contains a JSON-encoded string (as your logs suggest)
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }
 
            // Log the decoded payload
            \Log::info('Decoded Payload:', $payload);
 
            // Validate payload
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
 
       
            // Check if mobile number exists
            if (empty($payload['mobile_no'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Mobile number is missing'
                ], 400);
            }
            $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff Rejoin Successfully'
                    ], 200);
                }
 
            // Check if mobile number already exists
            $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
            if ($existingStaff) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Mobile Number already exists'
                ], 200);
            }
 
            // Handle staff image upload (if any)
            $staff_image_url = $payload['staff_image'] ?? null;
            $staff_image = null;
 
            if ($staff_image_url) {
                $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                $folderPath = public_path("staff_images");
 
                // Create directory if it doesn't exist
                if (!File::exists($folderPath)) {
                    File::makeDirectory($folderPath, 0777, true, true);
                }
 
                // Find the next available image number
                $existingFiles = File::files($folderPath);
                $maxNumber = 0;
                foreach ($existingFiles as $file) {
                    if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                        $num = (int) $matches[1];
                        if ($num > $maxNumber) $maxNumber = $num;
                    }
                }
                $nextNumber = $maxNumber + 1;
                $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                $savePath = $folderPath . '/' . $staff_image_name;
 
                // Save image
                try {
                    $imageData = @file_get_contents($staff_image_url);
                    if ($imageData !== false) {
                        file_put_contents($savePath, $imageData);
                        $staff_image = $staff_image_name;
                    }
                } catch (\Exception $e) {
                    $staff_image = null;
                }
            }
 
        // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 6,
                    'branch_franchise' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => is_array($payload['contact_person_name'] ?? null)
                                    ? json_encode($payload['contact_person_name'])
                                    : ($payload['contact_person_name'] ?? null),
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])
                                ? json_encode($payload['attachment'])
                                : '[]',
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );
        if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }
            }
 
        return response()->json([
            'ok' => true,
            'sno' => $add_staff->sno,
        ], 200);
    }
    
        
    
}
