<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Services\IncentiveCacheService;
use App\Models\IncentiveCriteriaModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;

class ManageMetrics extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;



    return view('content.metrics.manage_metrics');
  }
  public function incentive(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    return view('content.metrics.manage_incentive');
  }
  public function MyIncentive(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    return view('content.metrics.manage_my_incentive');
  }
  public function fetchIncentive(Request $request)
  {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id') ?? $request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('za_staff.staff_name')
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.role_id', $role_id)
      ->where('za_staff.status', 0)
      ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
      return response()->json([
        'status' => false,
        'message' => 'Staff not found'
      ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
      'status' => true,
      'staff_names' => $staffNames,
      'types' => $types
    ]);
  }

  public function getMetrics(Request $request)
  {
    $monthNumber = date('m', strtotime("1 " . $request->month));
    $targetDate = $request->year . '-' . $monthNumber . '-01';
    $year = $request->year;
    $month = $monthNumber;
    $branch_id = $request->user()->branch_id;
    // Fetch target
    $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
      ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
      ->where('branch_target.date', $targetDate)
      ->select('branch_target.*') // Ensure you're returning only target column
      ->first();


    $firstIds = DB::table('za_payment')
      ->where('za_payment.branch_id', $branch_id)
      ->select(DB::raw('MIN(za_payment.sno) as first_id'))
      ->groupBy('za_payment.payment_id')
      ->orderBy('first_id', 'asc')
      ->pluck('first_id');

    // Old payments
    $totalPaidAmountOld = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->where('za_old_customer.branch_id', $branch_id)
      ->where('za_old_payments.status', '!=', 2)
      ->whereIn('za_old_customer.status', [1, 4])
      ->where('za_old_payments.amount', '>', 0)
      ->whereYear('za_old_payments.created_at', $year)
      ->whereMonth('za_old_payments.created_at', $month)
      ->sum('za_old_payments.paidAmount');

    // New payments
    $totalPaidAmountNew = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.status', 1)
      ->where('za_customer.status', 0)
      ->where('za_payment.amount', '>', 0)
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->sum('za_payment.paidAmount');

    $transaction = DB::table('za_transaction')
      ->where('za_transaction.branch_id', $branch_id)
      ->whereYear('za_transaction.transaction_date', $year)
      ->whereMonth('za_transaction.transaction_date', $month)
      ->sum('za_transaction.credit');

    // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
    $targetActual = $transaction;

    // Post-sale & pre-sale actuals (count only)
    $postSaleActual = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branch_id)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.sno')
      ->count('za_training.sno');

    $preSaleActual = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', 0)
      ->where('branch_id', $branch_id)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();       // Carbon with time
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->endOfDay(); // Carbon with time
    // Initialize Carbon dates
    $start = Carbon::parse($startDate);
    $end = Carbon::parse($endDate);


    //  harvestingscheduleamount

    $expectedNewByDate = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->selectRaw('DATE(za_payment.nextPayDate) as date, SUM(za_payment.paidAmount) as total_expected')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.status', 1)
      ->where('za_customer.status', 0)
      ->whereNotIn('za_payment.sno', $firstIds)
      ->where('za_payment.paidAmount', '>', 0)
      ->whereBetween('za_payment.nextPayDate', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_payment.nextPayDate)'))
      ->pluck('total_expected', 'date')
      ->toArray();
    $totalPaidAmountoldNewByDate = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->selectRaw('DATE(za_old_payments.created_at) as date, SUM(za_old_payments.paidAmount) as total_expected')
      ->where('za_old_customer.branch_id', $branch_id)
      ->whereIn('za_old_customer.status', [1, 4])
      ->where('za_old_payments.amount', '>', 0)
      ->whereBetween('za_old_payments.created_at', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_old_payments.created_at)'))
      ->pluck('total_expected', 'date')
      ->toArray();

    $harvestingsNotPaidByDate = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->selectRaw('DATE(za_payment.nextPayDate) as date, SUM(za_payment.amount) as total_expected')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.status', 0) // paid amount
      ->where('za_customer.status', 0)
      ->whereNotIn('za_payment.sno', $firstIds)
      ->where('za_payment.amount', '>', 0)
      ->whereBetween('za_payment.nextPayDate', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_payment.nextPayDate)'))
      ->pluck('total_expected', 'date')
      ->toArray();




    $harvestings = collect($expectedNewByDate)
      ->mergeRecursive($totalPaidAmountoldNewByDate)
      ->map(function ($val) {
        return is_array($val) ? array_sum($val) : $val;
      });

    $harvestingscheduleamount = collect($harvestingsNotPaidByDate)
      ->mergeRecursive($harvestings)
      ->map(function ($val) {
        return is_array($val) ? array_sum($val) : $val;
      })
      ->toArray();

    // here we found harvesting Paid amount
    $paidAmountNewByDate = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->selectRaw('DATE(za_payment.initialPayDate) as date, SUM(za_payment.paidAmount) as total_paid')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.status', 1)
      ->whereNotIn('za_payment.sno', $firstIds)
      ->where('za_customer.status', 0)
      ->where('za_payment.amount', '>', 0)
      ->whereBetween('za_payment.initialPayDate', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_payment.initialPayDate)'))
      ->pluck('total_paid', 'date')
      ->toArray();

    $paidAmountOldByDate = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->selectRaw('DATE(za_old_payments.created_at) as date, SUM(za_old_payments.paidAmount) as total_paid')
      ->where('za_old_customer.branch_id', $branch_id)
      ->where('za_old_payments.status', '!=', 2)
      ->whereIn('za_old_customer.status', [1, 4])
      ->where('za_old_payments.amount', '>', 0)
      ->whereBetween('za_old_payments.created_at', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_old_payments.created_at)'))
      ->pluck('total_paid', 'date')
      ->toArray();

    $harvestingPaidAmountIn = $paidAmountNewByDate + $paidAmountOldByDate;

    $monthlyTargetActualsByDate = TransactionModel::selectRaw('DATE(transaction_date) as date, SUM(credit) as credit')
      ->where('branch_id', $branch_id)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(transaction_date)'))
      ->pluck('credit', 'date')
      ->toArray();

    // Fetch pre-sale actuals per day
    $preSaleActualsByDate = CustomerModel::selectRaw('DATE(created_at) as date, COUNT(*) as count')
      ->whereIn('status', [0, 6])
      ->where('post_sale_check', 0)
      ->where('branch_id', $branch_id)
      ->whereBetween('created_at', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(created_at)'))
      ->pluck('count', 'date')
      ->toArray();

    $preSaleActual = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', 0)
      ->where('branch_id', $branch_id)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Fetch post-sale actuals per day


    $postSaleActualsByDate = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->selectRaw('DATE(za_training.created_at) as date, COUNT(DISTINCT za_training.sno) as count')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branch_id)
      ->whereBetween('za_training.created_at', [$startDate, $endDate])
      ->groupBy(DB::raw('DATE(za_training.created_at)'))
      ->pluck('count', 'date')
      ->toArray();

    // Fetch pre-sale customer IDs
    $preSaleCustomerIds = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', 0)
      ->where('branch_id', $branch_id)
      ->whereBetween('created_at', [$startDate, $endDate])
      ->pluck('sno')
      ->toArray();

    $preSaleCustomerOldIds = OldCustomerModel::whereIn('status', [0, 6])
      ->where('branch_id', $branch_id)
      ->whereBetween('created_at', [$startDate, $endDate])
      ->pluck('sno')
      ->toArray();

    // Fetch post-sale customer IDs
    $postSaleCustomerIds = CustomerModel::whereIn('za_customer.status', [0, 6])
      ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branch_id)
      ->whereBetween('za_training.created_at', [$startDate, $endDate])
      ->pluck('za_training.sno')
      ->toArray();

    // Daily paid amounts for post-sale
    $dailyPaidAmountsPost = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_payment.status', 1)
      ->whereIn('za_customer.sno', $postSaleCustomerIds)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.amount', '>', 0)
      ->whereBetween('za_payment.initialPayDate', [$startDate, $endDate])
      ->selectRaw('DATE(za_payment.initialPayDate) as date, SUM(za_payment.paidAmount) as total_amount')
      ->groupBy(DB::raw('DATE(za_payment.initialPayDate)'))
      ->pluck('total_amount', 'date')
      ->toArray();

    // Daily paid amounts for pre-sale
    $dailyPaidAmountsPre = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_payment.status', 1)
      ->whereIn('za_customer.sno', $preSaleCustomerIds)
      ->where('za_customer.post_sale_check', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.amount', '>', 0)
      ->whereBetween('za_payment.initialPayDate', [$startDate, $endDate])
      ->selectRaw('DATE(za_payment.initialPayDate) as date, SUM(za_payment.paidAmount) as total_amount')
      ->groupBy(DB::raw('DATE(za_payment.initialPayDate)'))
      ->pluck('total_amount', 'date')
      ->toArray();



    // STEP 1: Get all pre-sale + post-sale payment invoice_ids to exclude
    $excludedInvoiceIds = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_payment.status', 1)
      ->whereIn('za_customer.sno', array_merge($preSaleCustomerIds, $postSaleCustomerIds))
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_payment.amount', '>', 0)
      ->whereBetween('za_payment.initialPayDate', [$startDate, $endDate])
      ->pluck('za_payment.invoice_id')
      ->filter() // remove nulls
      ->unique() // ensure uniqueness
      ->toArray();

    $dailyPaidAmountOther = DB::table('za_transaction')
      ->where('za_transaction.branch_id', $branch_id)
      ->whereBetween('za_transaction.transaction_date', [$startDate, $endDate])
      ->when(!empty($excludedInvoiceIds), function ($query) use ($excludedInvoiceIds) {
        $query->where(function ($subQuery) use ($excludedInvoiceIds) {
          $subQuery->whereNotIn('za_transaction.invoice_id', $excludedInvoiceIds)
            ->orWhereNull('za_transaction.invoice_id'); // include NULLs
        });
      })
      ->selectRaw('DATE(za_transaction.transaction_date) as date, SUM(za_transaction.credit) as total_amount')
      ->groupBy(DB::raw('DATE(za_transaction.transaction_date)'))
      ->pluck('total_amount', 'date')
      ->toArray();


    // Pre-sale cumulative per day
    $preSaleActualPerDay = [];
    $current = $start->copy();
    $cumulativePreSale = 0;
    $today = now()->format('Y-m-d');

    while ($current->lte($end)) {
      $dateStr = $current->format('Y-m-d');
      $dailyValue = $preSaleActualsByDate[$dateStr] ?? 0;

      if ($dateStr <= $today) {
        $cumulativePreSale += $dailyValue;
        $preSaleActualPerDay[$dateStr] = $cumulativePreSale;
      } else {
        $preSaleActualPerDay[$dateStr] = 0;
      }

      $current->addDay();
    }

    // Post-sale cumulative per day
    $postSaleActualPerDay = [];
    $current = $start->copy(); // reset date pointer
    $cumulativePostSale = 0;

    while ($current->lte($end)) {
      $dateStr = $current->format('Y-m-d');
      $dailyValue = $postSaleActualsByDate[$dateStr] ?? 0;

      if ($dateStr <= $today) {
        $cumulativePostSale += $dailyValue;
        $postSaleActualPerDay[$dateStr] = $cumulativePostSale;
      } else {
        $postSaleActualPerDay[$dateStr] = 0;
      }

      $current->addDay();
    }


    $monthlyTargetActualPerDay = [];
    $cumulativeTarget = 0;
    $current = $start->copy();
    $today = now()->format('Y-m-d');

    while ($current->lte($end)) {
      $dateStr = $current->format('Y-m-d');
      $dailyTarget = $monthlyTargetActualsByDate[$dateStr] ?? 0;

      if ($dateStr <= $today) {
        $cumulativeTarget += $dailyTarget;
        $monthlyTargetActualPerDay[$dateStr] = $cumulativeTarget;
      } else {
        $monthlyTargetActualPerDay[$dateStr] = 0;
      }

      $current->addDay();
    }


    $dailyPaidAmountPerDay = [];
    $cumulativePaid = 0;
    $current = \Carbon\Carbon::parse($startDate)->copy();
    $end = \Carbon\Carbon::parse($endDate);
    $today = now()->format('Y-m-d');

    while ($current->lte($end)) {
      $dateStr = $current->format('Y-m-d');

      $paidNew = $paidAmountNewByDate[$dateStr] ?? 0;
      $paidOld = $paidAmountOldByDate[$dateStr] ?? 0;

      $dailyTotalPaid = $paidNew + $paidOld;

      if ($dateStr <= $today) {
        $cumulativePaid += $dailyTotalPaid;
        $dailyPaidAmountPerDay[$dateStr] = $cumulativePaid;
      } else {
        $dailyPaidAmountPerDay[$dateStr] = 0;
      }

      $current->addDay();
    }

    $preSaleTarget      = $targets->no_of_registrations ?? 0;
    $postSaleTarget     = $targets->post_sale ?? 0;
    $monthlyTarget      = $targets->monthly_target ?? 0;
    $harvestingschedule = $harvestingscheduleamount;

    // $harvestingsExpectedByDate = $this->distributeIndividuallyPerDay($harvestingsExpectedByDate, $startDate, $endDate);
    $monthlyTargetExpectedByDate = $this->distributePerDay($monthlyTarget, $startDate, $endDate);
    $preSaleExpectedByDate = $this->distributePerDay($preSaleTarget, $startDate, $endDate);
    $postSaleExpectedByDate = $this->distributePerDay($postSaleTarget, $startDate, $endDate);

    $dates = array_keys($preSaleExpectedByDate);

    return response()->json([
      'status' => 200,
      'data' => $targets,
      'actuals' => [
        'target_actual' => $targetActual,
        'post_sale_actual' => $postSaleActual,
        'pre_sale_actual' => $preSaleActual,

      ],
      'distribution' => [
        'dates' => $dates,
        'harvestings_expected' => $harvestingschedule,
        'monthly_target_expected' => $monthlyTargetExpectedByDate,
        'pre_sale_expected' => $preSaleExpectedByDate,
        'post_sale_expected' => $postSaleExpectedByDate,
        // 'harvestings_actual_per_day' => $dailyPaidAmountPerDay,
        'harvestings_actual_per_day' => $harvestingPaidAmountIn,
        'monthly_target_actual_per_day' => $monthlyTargetActualPerDay,
        'pre_sale_actual_per_day' => $preSaleActualPerDay,
        'post_sale_actual_per_day' => $postSaleActualPerDay,
        'dailyPaidAmountsPre' => $dailyPaidAmountsPre,
        'dailyPaidAmountsPost' => $dailyPaidAmountsPost,
        'dailyPaidAmountsOther' => $dailyPaidAmountOther,
        // 'preSaleInvoiceIds' => $preSaleInvoiceDateMap,
      ],
    ]);
  }

  private function distributePerDay($total, $startDate)
  {
    $days = [];

    $start = \Carbon\Carbon::parse($startDate)->startOfDay();
    $end = $start->copy()->endOfMonth();
    $diffDays = $start->diffInDays($end) + 1;

    if ($diffDays <= 0) return [];

    $step = $total / $diffDays;
    $sum = 0;
    $currentDate = $start->copy();

    for ($i = 0; $i < $diffDays; $i++) {
      $sum += $step;
      $rounded = round($sum);

      // Ensure last day hits exact total (e.g., 100)
      if ($i == $diffDays - 1) {
        $rounded = $total;
      }

      $days[$currentDate->format('Y-m-d')] = $rounded;
      $currentDate->addDay();
    }

    return $days;
  }

  private function distributeIndividuallyPerDay($total, $startDate, $endDate)
  {
    $days = [];

    $start = \Carbon\Carbon::parse($startDate)->startOfDay();
    $end = \Carbon\Carbon::parse($endDate)->endOfDay();
    $diffDays = $start->diffInDays($end) + 1;

    if ($diffDays <= 0) return [];

    $step = $total / $diffDays;
    $currentDate = $start->copy();
    $sum = 0;

    for ($i = 0; $i < $diffDays; $i++) {
      $remainingDays = $diffDays - $i;
      $value = round(($total - $sum) / $remainingDays); // distribute remainder properly
      $days[$currentDate->format('Y-m-d')] = $value;
      $sum += $value;
      $currentDate->addDay();
    }

    return $days;
  }

  public function getConvertion(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $date = $request->date; // format: Y-m-d

    $startOfMonth = Carbon::parse($date)->startOfMonth()->format('Y-m-d');
    $endOfMonth = Carbon::parse($date)->endOfMonth()->format('Y-m-d');

    // Total converted customers from start of month to selected date
    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branch_id)
      ->whereRaw('DATE(za_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $date])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at'
      )
      ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');

      if ($customerDate === $date && $leadDate === $date) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $date &&
        $leadDate >= $startOfMonth && $leadDate <= $date
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $date &&
        ($leadDate < $startOfMonth || $leadDate > $date)
      ) {
        $convertedOldMonth++;
      }
    }

    // Unclassified = total - (today + month + old)
    $convertedUnclassified = $allConverted->count() - ($convertedToday + $convertedMonth + $convertedOldMonth);

    return response()->json([
      'status' => 200,
      'data' => [
        'converted_today' => $convertedToday,
        'converted_month' => $convertedMonth,
        'converted_old_month' => $convertedOldMonth,
        'converted_unclassified' => $convertedUnclassified,
        'converted_total' => $allConverted->count(),
        'converted_total_list' => $allConverted,
      ]
    ]);
  }

    // start incentive main

  public function getIncentiveMetrics(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $role_id = $request->role_id ?? 11;
    $year = $request->year ?? 2026;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $current = Carbon::create($year, $month, 1);
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth();

    $checkRole = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $request->month)
      ->whereMonth('za_goal_set_staff.goal_date', $request->month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->where('staff_id', 123)
      ->first();

    $query = StaffModel::join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
      ->where('za_staff.branch_id', $branchId);

    if ($checkRole && $checkRole->sales_lead_check == 1 && $role_id == 11) {
      $query->whereIn('za_staff.role_id', [11, 12]);
    } else {
      $query->where('za_staff.role_id', $role_id);
    }

    $staffList = $query->where('za_staff.status', 0)
      ->select(
        'za_staff.sno as staff_id',
        'za_staff.staff_name',
        'za_staff.role_id',
        'za_staff.department_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.branch_id',
        'za_branch.branch_name',
        'za_branch.franchise_name',
        'za_branch.cert_auth_sign',
        'za_staff.avaiable_points',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_sub_department.sub_department_id',
        'za_sub_department.sub_department_name',
        'za_department.department_name'
      )
      ->get();

    $departmentIds = $staffList->pluck('department_id')->unique()->toArray();

    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::whereIn('za_goal_set_staff.department_id', $departmentIds)
      ->where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $request->month)
      ->whereMonth('za_goal_set_staff.goal_date', $request->month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->get();

    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    $goalsetteam = GoalSetTeamModel::whereIn('za_goal_set_team.department_id', $departmentIds)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $request->month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    // Process each staff
    $result = [];
    foreach ($staffList as $staff) {
      $checkRecord = GoalSetStaffModel::where('za_goal_set_staff.department_id', $departmentIds)
        ->where('za_goal_set_staff.branch_id', $branchId)
        ->where('za_goal_set_staff.goal_month', $request->month)
        ->whereMonth('za_goal_set_staff.goal_date', $request->month)
        ->whereYear('za_goal_set_staff.goal_date', $year)
        ->where('staff_id', $staff->staff_id)
        ->first();

      $isProduction = $staff->role_id == 22;
      $isSalesEx    = $staff->role_id == 11;
      $isTeamLead   = $staff->role_id == 12;
      $isCollection = $staff->role_id == 14;
      $isCRE        = $staff->role_id == 16;
      $isPC         = $staff->role_id == 15;
      $isplacementEx = $staff->role_id == 17;
      $isplacementLead = $staff->role_id == 19;
      $isBDM        = $staff->role_id == 36;

      $current_date = date('Y-m-d');

      // Get incentive
      $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $request->year)
        ->where('status', 0)
        ->first();

      if (!$incentive) {
        $fallbackDate = '2025-06-01';
        $incentive = IncentiveModel::where('role_id', $staff->role_id)
          ->where('branch_id', $branchId)
          ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
          ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
          ->where('status', 0)
          ->first();
      }

      if ($isTeamLead) {
        $result[] = $this->processTeamLead(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetRecords,
          $branchId,
          $month,
          $year,
          $startDate,
          $endDate,
          $startOfMonth,
          $endOfMonth,
          $prevMonth,
          $prevYear,
          $dates,
          $checkRole,
          $goalsetData,
          $departmentIds
        );
      } elseif ($isSalesEx) {
        $result[] = $this->processSalesExecutive(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetData,
          $branchId,
          $month,
          $year,
          $startDate,
          $endDate,
          $startOfMonth,
          $endOfMonth,
          $prevMonth,
          $prevYear,
          $dates
        );
      } elseif ($isCollection) {
        $result[] = $this->processCollection(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year,
          $startDateold,
          $endDateold,
          $startDate,
          $endDate
        );
      } elseif ($isCRE) {
        $result[] = $this->processCRE(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year
        );
      } elseif ($isProduction) {
        $result[] = $this->processProduction(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year,
          $current_date
        );
      } elseif ($isPC) {
        $result[] = $this->processPC(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year,
          $current_date
        );
      } elseif ($isplacementEx) {
        $result[] = $this->processPlacementEx(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year
        );
      } elseif ($isplacementLead) {
        $result[] = $this->processPlacementLead(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year
        );
      } elseif ($isBDM) {
        $result[] = $this->processBDM(
          $staff,
          $incentive,
          $checkRecord,
          $goalsetteam,
          $goalsetData,
          $branchId,
          $month,
          $year,
          $startDate,
          $endDate,
          $startDateold,
          $endDateold,
          $prevMonth,
          $prevYear,
          $dates,
          $startOfMonth,
          $endOfMonth
        );
      }
    }

    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }

  /**
   * Process Team Lead - EXACT same as original
   */
  private function processTeamLead($staff, $incentive, $checkRecord, $goalsetteam, $goalsetRecords, $branchId, $month, $year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates, $checkRole, $goalsetData, $departmentIds)
  {
    if ($checkRecord && $checkRecord->sales_lead_check == 0) {
      $executives = StaffModel::where('branch_id', $staff->branch_id)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $executiveIds = $executives->pluck('sno')->toArray();
      $executiveGoalSet = $goalsetRecords
        ->whereIn('staff_id', $executiveIds)
        ->where('conversion', '>', 0)
        ->pluck('staff_id')
        ->unique()
        ->toArray();

      $incentive = IncentiveModel::where('role_id', 11)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->first();

      if (!$incentive) {
        return [];
      }

      $filteredExecutives = $executives->whereIn('sno', $executiveGoalSet);
      $allExecutiveIncentives = [];
      foreach ($filteredExecutives as $executive) {
        $allExecutiveIncentives['staff_' . $executive->sno] = $this->calculateIncentivesForStaff(
          $executive,
          $branchId,
          $month,
          $year,
          $goalsetData
        );
      }

      $finalStatus = $this->getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives);
      $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->whereMonth('branch_target.date', $month)
        ->whereYear('branch_target.date', $year)
        ->select('branch_target.*')
        ->first();

      $preSaleActual = CustomerModel::whereIn('status', [0, 6])
        ->where('branch_id', $branchId)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;

      return [
        'staff_id' => $staff->staff_id,
        'staff_name' => $staff->staff_name,
        'branch_name' => $staff->branch_name,
        'bh_signature' => $staff->cert_auth_sign,
        'staff_image' => $staff->staff_image,
        'role_id' => $staff->role_id,
        'nick_name' => $staff->nick_name,
        'sub_department_name' => $staff->sub_department_name,
        'department_name' => $staff->department_name,
        'incentives' => [
          'tenx_award' => [
            'target' => 'All Executives Achieved 10x',
            'actual' => $individual10x ? 'Achieved' : 'Not Achieved',
            'status' => $individual10x,
            'reward' => $individual10x ? ($incentive->tenx_award ?? 0) : 0,
          ],
          'eci' => [
            'target' => 'All Executives Achieved ECI',
            'actual' => $finalStatus['eci'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['eci'],
            'reward' => $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0,
          ],
          'bi' => [
            'target' => 'All Executives Achieved BI',
            'actual' => $finalStatus['bi'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['bi'],
            'reward' => $finalStatus['bi'] ? ($incentive->bi_amount ?? 0) : 0,
          ],
          'si' => [
            'target' => 'All Executives Achieved SI',
            'actual' => $finalStatus['si'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['si'],
            'reward' => $finalStatus['si'] ? 3000 : 0,
          ],
          'pi' => [
            'target' => 'All Executives Achieved PI',
            'actual' => $finalStatus['pi'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['pi'],
            'reward' => $finalStatus['pi'] ? ($incentive->pi_reward ?? 0) : 0,
          ],
          'sp' => [
            'target' => 'All Executives Achieved SP',
            'actual' => $finalStatus['sp'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['sp'],
            'reward' => $finalStatus['sp'] ? ($incentive->spot_total_reward ?? 0) : 0,
          ],
          'li' => [
            'target' => 'All Incentives Achieved by Team',
            'actual' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
              ? 'Achieved' : 'Not Achieved',
            'status' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']),
            'reward' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
              ? ($incentive->luxury_reward ?? 0) : 0,
          ]
        ],
      ];
    } else {
      return $this->processSalesExecutive(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startOfMonth,
        $endOfMonth,
        $prevMonth,
        $prevYear,
        $dates
      );
    }
  }

  /**
   * Process Sales Executive - EXACT same as original
   */
  private function processSalesExecutive($staff, $incentive, $checkRecord, $goalsetData, $branchId, $month, $year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates)
  {
    $staffId = $staff->staff_id;

    // All Lead Count
    $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Month Lead Count
    $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereYear('za_lead.registered_date', $year)
      ->whereMonth('za_lead.registered_date', $month)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Customer Convert Count This Month
    $customerConvertCountthismonth = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Branch
    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    // Drop Refund
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    // Paid Under Payment
    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $totalItems = $finalResult->count();
    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));

    // Month Call Out
    $monthcall_out = DB::table('za_call_tracker')
      ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('za_call_tracker.branch_id', $branchId)
      ->where('za_call_tracker.branch_staff_id', $staffId)
      ->first();
    $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;

    // Conversion Rate
    $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
    $convertion_rate = number_format($convertion_rate, 2);

    // Average Conversion Rate
    $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
    $averager_convertion_rate = number_format($averager_convertion_rate, 2);

    $luxury = json_decode($incentive->luxury_incentive, true);
    $pi_slabs = json_decode($incentive->pi_slab_json, true);

    $targetConversion = $goalsetData[$staffId]->conversion ?? 0;
    $targetABV = $goalsetData[$staffId]->ABV ?? 0;
    $targetACV = $goalsetData[$staffId]->ACV ?? 0;

    // Initialize variables
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;
    $total_payment = 0;
    $total_paid_payment = 0;
    $eciCustomerConvertCount = 0;

    // Get Current Month Customers
    $currentMonthCustomer = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    // ECI Count
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->count();

    // Calculate Training Counts
    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $hasTesbo = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('branch_id', $branchId)
          ->whereMonth('created_at', $month)
          ->whereYear('created_at', $year)
          ->where('tesbo_check', 2)
          ->where('post_sale_check', '!=', 1)
          ->exists();

        if ($hasTesbo) {
          $tesboCount++;
          continue;
        }

        $nonTesboTrainings = DB::table('za_training')
          ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
          ->where('za_training.customer_id', $customer->sno)
          ->where('za_training.branch_id', $branchId)
          ->whereMonth('za_training.created_at', $month)
          ->whereYear('za_training.created_at', $year)
          ->where('za_training.post_sale_check', '!=', 1)
          ->where('za_training.tesbo_check', '!=', 2)
          ->whereIn('za_course.course_type_id', [3, 4])
          ->select('za_course.course_type_id')
          ->get();

        $hasCrash = false;
        $hasProfession = false;

        foreach ($nonTesboTrainings as $training) {
          if ($training->course_type_id == 3) {
            $hasProfession = true;
          } elseif ($training->course_type_id == 4) {
            $hasCrash = true;
          }
        }

        if ($hasCrash) $crashCount++;
        if ($hasProfession) $professionCount++;
      }
    }

    // Calculate Payments
    if ($currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 0)
          ->sum('overall_fees');
        $total_payment += $payment;

        $latestTraining = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 2)
          ->orderByDesc('sno')
          ->first();

        if ($latestTraining) {
          $total_payment += $latestTraining->overall_fees;
        }

        $paid_payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->sum('paid_amount');
        $total_paid_payment += $paid_payment;
      }
    }

    // SP Calculation
    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereBetween('za_customer.created_at', [$startDate, $endDate])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at',
        'za_lead.lead_mobile as lead_mobile'
      )
      ->get();

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $lastCall = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->orderByDesc('call_start_date')
        ->first();

      $totalCallCount = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->count();

      $row->call_created_at = $lastCall->call_start_date ?? null;
      $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
      $row->call_count = $totalCallCount;
    }

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $totalCalldata = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->select('call_start_date')
        ->get();

      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
      $call_count = $row->call_count;

      if ($customerDate === $leadDate && $call_count === 1) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        $leadDate >= $startOfMonth && $leadDate <= $endOfMonth &&
        $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
          $callDate = Carbon::parse($call->call_start_date);
          return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
        })
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        ($leadDate < $startOfMonth || $leadDate > $endOfMonth)
      ) {
        $convertedOldMonth++;
      }
    }

    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    // PI Calculation
    $originalAmount = 0;
    $piPercentage = 0;
    $slabPercentage = 0;
    $matchedSlab = null;
    $piReward = 0;

    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $trainings = DB::table('za_training as t1')
          ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
          ->where('t1.customer_id', $customer->sno)
          ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
          ->get();

        foreach ($trainings as $training) {
          $course_id = null;

          if ($training->tesbo_check > 0) {
            $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
            if ($payment && $payment->course_id) {
              $course_id = $payment->course_id;
            }
          } else {
            $course_id = $training->course_id;
          }

          if (!$course_id) continue;

          $course = ManageCoursesModel::where('sno', $course_id)
            ->whereIn('course_type_id', [2, 3])
            ->first();

          if (!$course) continue;

          $basePrice = $course->course_min_price;
          $soldPrice = $training->overall_fees;
          $profitAmount = $soldPrice - $basePrice;
          $originalAmount += $profitAmount;

          $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;

          foreach ($pi_slabs as $slab) {
            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
              $slabPercentage = $slab['percentage'];
              $piReward = ($originalAmount * $slabPercentage) / 100;
              $piPercentage = $profitPercent;
              $matchedSlab = "{$slab['min']} < {$slab['max']}%";
              break;
            }
          }
        }
      }
    }

    // SI Calculation
    $crashTarget = $incentive->si_crash_course ?? 0;
    $professionTarget = $incentive->si_profession_course ?? 0;
    $tesboTarget = $incentive->si_tesbo_course ?? 0;

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $crashTarget || $crashPercent <= $crashTarget);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $professionTarget);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
      }
    }

    // ECI Logic
    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciActualPercentage = number_format($eciActualPercentage, 2);
    $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

    // Averages
    $averageBusinessValue = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;

    // 10X Status
    $tenxStatus = $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 && $customerConvertCount >= $targetConversion;

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $customerConvertCount - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $biAchievedCount > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'branch_name' => $staff->branch_name,
      'bh_signature' => $staff->cert_auth_sign,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        'tenx_award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $customerConvertCountthismonth . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $customerConvertCount . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary">' . round($averageBusinessValue) . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary">' . round($averageCollectionValue) . '</span>
                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staffId . ')" >Details</span>
                             <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                 <i class="mdi mdi-help-circle text-dark"></i>
                             </label>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'eci' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staffId . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
          'status' => $tenxStatus && $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
        ],
        'bi' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($targetConversion . ' - ' . $customerConvertCount . ' = (' . $biAchievedCount . ')') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($biAchievedCount . ' × ' . $biPerConversion) . '</span>',
          'status' => $tenxStatus && $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
        ],
        'si' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . "{$crashTarget}:{$professionTarget}:{$tesboTarget}" . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . number_format($crashPercent, 1) . ' : ' . number_format($professionPercent, 1) . ' : ' . number_format($tesboPercent, 1) . ' = ' . number_format($crashPercent + $professionPercent + $tesboPercent) . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus && $siStatus,
          'reward' => ($tenxStatus && $siStatus) ? ($incentive->si_reward ?? 0) : 0,
        ],
        'pi' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus && $piReward > 0,
          'reward' => ($tenxStatus && $piReward > 0) ? round($piReward) : 0,
        ],
        'sp' => [
          'target' => '<table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . '</span>
                                    </td>
                                </tr>
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . '</span>
                                    </td>
                                </tr>
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedOldMonth . '
                                    </td>
                                </tr>
                            </table>',
          'actual' => '<table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</span>
                                    </td>
                                </tr>
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</span>
                                    </td>
                                </tr>
                                <tr style="border: none !important;">
                                    <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                    <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                    <td style="border: none !important; background: transparent !important;">
                                        <span class="badge bg-label-secondary fw-bold fs-3">₹0</span></span> </span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openManageCallModal(' . $staffId . ')" >Details</span>
                                    </td>
                                </tr>
                            </table>',
          'status' => $tenxStatus && $spotTotalReward > 0,
          'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
        ],
        'li' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? 'Achieved' : 'Not Achieved') . '</span>',
          'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
          'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? ($luxury['reward'] ?? 0) : 0,
        ]
      ]
    ];
  }

  // Additional helper methods for getTeamIncentiveStatus and calculateIncentivesForStaff
//   private function getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives)
//   {
//     $status = [
//       'tenx_award' => true,
//       'eci' => true,
//       'bi' => true,
//       'si' => true,
//       'pi' => true,
//       'sp' => true
//     ];

//     foreach ($executiveGoalSet as $staffId) {
//       $key = 'staff_' . $staffId;
//       if (!isset($allExecutiveIncentives[$key])) {
//         $status['tenx_award'] = false;
//         $status['eci'] = false;
//         $status['bi'] = false;
//         $status['si'] = false;
//         $status['pi'] = false;
//         $status['sp'] = false;
//         continue;
//       }

//       $data = $allExecutiveIncentives[$key];
//       if (!$data['tenx_status']) $status['tenx_award'] = false;
//       if (!$data['eci_status']) $status['eci'] = false;
//       if (!$data['bi_status']) $status['bi'] = false;
//       if (!$data['si_status']) $status['si'] = false;
//       if (!$data['pi_status']) $status['pi'] = false;
//       if (!$data['sp_status']) $status['sp'] = false;
//     }

//     return $status;
//   }

  /**
   * Process Collection - EXACT same as original
   */
  private function processCollection($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDateold, $endDateold, $startDate, $endDate)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->pluck('za_customer.sno')
      ->toArray();

    // HAC Amount
    $hacAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->where('za_payment.status', 1)
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->where('za_payment.branch_id', $branchId)
      ->sum('za_payment.paidAmount');

    // Actual Month Customer Post
    $actualMonthCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno As training_id')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->whereIn('za_customer.status', [0, 6, 4])
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
    $isoutstandingRequired = $ten_x['no_of_outstanding_10x'] == "1";
    $isPostsaleRequired = $ten_x['no_of_post_sale_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Harvesting Amount";
    } elseif ($isoutstandingRequired) {
      $targetTenx = $goalsetData[$staffId]->student_count ?? 0;
      $actaulTenx = $goalsetData[$staffId]->student_count_actual ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Outstanding Count";
    } elseif ($isPostsaleRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_post_sale ?? 0;
      $actaulTenx = $actualMonthCustomerPost ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Post Sale Count";
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // EI Calculation
    $EIaward = 0;
    $EIStatus = false;
    $targetEI = 0;
    $actaulEI = 0;

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;

      if ($tenxStatus && ($incentive->excess_incentive ?? 0) > 0) {
        $excessAmount = $actaulTenx - $targetTenx;
        if ($excessAmount > 0) {
          $targetEI = $incentive->excess_incentive . '%';
          $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
          $EIaward = $actaulEI;
          $EIStatus = true;
        }
      }
    }

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $tenxTolltip . '">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCollectionModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'EI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetEI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . number_format($actaulEI, 2) . '</span>',
          'status' => $EIStatus,
        //   'reward' => number_format($EIaward, 2),
        'reward' => $EIaward,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
      ]
    ];
  }

  /**
   * Process CRE - EXACT same as original
   */
  private function processCRE($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Review Count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staffId)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = $ten_x['no_of_reviews_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_reviews ?? 0;
      $actaulTenx = $review_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        // '10X Warrior' => [
        //   'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' . '</span>',
        //   'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staffId . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
        //   'status' => $tenxStatus && $incentive->tenx_warrior,
        //   'reward' => ($tenxStatus && $incentive->tenx_warrior) ? ($incentive->tenx_warrior_reward ?? 0) : 0,
        // ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
      ]
    ];
  }

  /**
   * Process Production - EXACT same as original
   */
  private function processProduction($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {
    $staffId = $staff->staff_id;

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->staff_id)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->staff_id],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

    // PDI Slabs
    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
    $studentCount = $staffproduction->student_count ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($slabs as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->where('branch_id', $branchId)
      ->where('referral_id', $staffId)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    $costing_amount_asign = $goalsetData[$staffId]->production_costing ?? 0;
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
    $isStudentMinRequired = $ten_x['min_no_of_students_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isProductionCostingRequired) {
      $targetTenx = $goalsetData[$staffId]->production_costing ?? 0;
      $actaulTenx = round($costing_amount);
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Production Costing";
    } elseif ($isStudentMinRequired) {
      $targetTenx = $goalsetData[$staffId]->min_no_of_students ?? 0;
      $actaulTenx = $goalsetData[$staffId]->min_no_of_students_actual ?? $staffproduction->student_count;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Min No. of Students Handling";
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Reference Sales Count";
    }

    // PDI
    $pdiReward = $slabPercentage;
    $pdiStatus = $tenxStatus && $pdiReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $tenxTolltip . '">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($slabPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process PC - EXACT same as original
   */
  private function processPC($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->staff_id)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->staff_id],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    $costing_amount_asign = $goalsetData[$staffId]->production_costing ?? 0;
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isProductionCostingRequired) {
      $targetTenx = $costing_amount_asign ?? 0;
      $actaulTenx = $costing_amount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . round($actaulTenx) . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => $REIStatus,
          'reward' => $REIStatus ? ($REIaward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process Placement Executive - EXACT same as original
   */
  private function processPlacementEx($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIE Slab
    $pie_slab_json = json_decode($incentive->pie_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pie_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // OIE Slab
    $oie_slab_json = json_decode($incentive->oie_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oie_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
        'Others' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlabOi ? $matchedSlabOi . ' = ' . round($slabPercentageOi, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentageOi, 2) . '</span>',
          'status' => $otherStatus,
          'reward' => $tenxStatus && $OthersReward ? round($OthersReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process Placement Lead - EXACT same as original
   */
  private function processPlacementLead($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIL Slab
    $pil_slab_json = json_decode($incentive->pil_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pil_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Double X Slab
    $double_x_slab_json = json_decode($incentive->double_x_slab_json ?? '[]', true);
    $matchedX = null;
    $slabPercentageX = 0;
    $DoubleReward = 0;

    $multiplier = $targetTenx > 0 ? floor($tesboCount / $targetTenx) : 0;

    foreach ($double_x_slab_json as $slab) {
      if ($multiplier >= $slab['min'] && $multiplier <= $slab['max']) {
        if ($multiplier == 2) {
          $matchedX = 'Double X';
        } elseif ($multiplier == 3) {
          $matchedX = 'Triple X';
        } else {
          $matchedX = $multiplier . 'X';
        }
        $slabPercentageX = $slab['percentage'];
        $DoubleReward = $slabPercentageX;
        break;
      }
    }

    // OIL Slab
    $oil_slab_json = json_decode($incentive->oil_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oil_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $DoubleStatus = $tenxStatus && $DoubleReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
        'Double or Triple X' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedX ? $matchedX . ' = ' . round($slabPercentageX, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($slabPercentageX, 2) . '</span>',
          'status' => $DoubleStatus,
          'reward' => $tenxStatus && $DoubleReward ? round($DoubleReward) : 0,
        ],
        'Others' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlabOi ? $matchedSlabOi . ' = ' . round($piPercentageOi, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentageOi, 2) . '</span>',
          'status' => $otherStatus,
          'reward' => $tenxStatus && $OthersReward ? round($OthersReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process BDM - EXACT same as original
   */
  private function processBDM($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDate, $endDate, $startDateold, $endDateold, $prevMonth, $prevYear, $dates, $startOfMonth, $endOfMonth)
  {
    $staffId = $staff->staff_id;

    // Targets
    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
      ->whereMonth('branch_target.date', $month)
      ->whereYear('branch_target.date', $year)
      ->select('branch_target.*')
      ->first();

    $pregoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $postgoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $financialYear = (int)$year;
    if ($month >= 1 && $month <= 3) {
      $financialYear = $financialYear - 1;
    }

    $fyStart = Carbon::create($financialYear, 4, 1)->startOfDay();
    $fyEnd = Carbon::create($financialYear + 1, 3, 31)->endOfDay();

    $yearlyTargets = ManageTargetModel::query()
      ->where('branch_target.branch_id', $branchId)
      ->whereBetween('branch_target.date', [$fyStart, $fyEnd])
      ->selectRaw("
            SUM(no_of_registrations) as total_pre_target,
            SUM(post_sale) as total_post_target
        ")
      ->first();

    $yearlyPreTarget = (int) ($yearlyTargets->total_pre_target ?? 0);
    $yearlyPostTarget = (int) ($yearlyTargets->total_post_target ?? 0);

    $target_collection = $targets->monthly_target ?? 0;
    $target_pre = $targets->no_of_registrations ?? 0;
    $target_post = $targets->post_sale ?? 0;
    $targetPreABV = $pregoalsetteam ? $pregoalsetteam->abv_over_all : 0;
    $targetPreACV = $pregoalsetteam ? $pregoalsetteam->acv_over_all : 0;
    $targetPostABV = $postgoalsetteam ? $postgoalsetteam->abv_over_all : 0;
    $targetPostACV = $postgoalsetteam ? $postgoalsetteam->acv_over_all : 0;

    // Total Credit
    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Branch
    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    // Drop Refund
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    // Paid Under Payment
    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    // Presale Count
    $presaleCount = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->count();

    // Post Sale Count
    $postSaleCount = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->count('za_training.sno');

    // Presale Customers
    $presaleCustomers = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->pluck('customer_id')
      ->toArray();

    // Postsale Customers
    $postsaleCustomers = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->pluck('za_training.sno')
      ->toArray();

    // ECI Counts
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', '!=', 1)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->count();

    $eciCustomerConvertCountPost = DB::table('za_customer')
      ->select('za_customer.sno', 'za_customer.proposal_ids', 'za_customer.cus_name')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.status', 0)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_customer.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->whereNotIn('za_training.status', [0, 1, 2])
      ->where('za_training.status', 0)
      ->orderBy('za_training.sno', 'asc')
      ->whereDay('za_training.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->distinct('za_customer.sno')
      ->count();

    // Team Targets
    $teamTargets = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
      ->join('za_staff', 'za_staff.sno', '=', 'za_goal_set_staff.staff_id')
      ->whereIn('za_staff.role_id', [11])
      ->where('za_staff.status', 0)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->select(
        'za_goal_set_staff.staff_id',
        'za_goal_set_staff.conversion',
        'za_staff.role_id',
        'za_staff.staff_name'
      )
      ->distinct('za_staff.sno')
      ->get();

    // Pre and Post Actuals
    $preActuals = CustomerModel::where('branch_id', $branchId)
      ->whereIn('status', [0, 6])
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->groupBy('lead_id')
      ->select('lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    $postActuals = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->groupBy('za_customer.lead_id')
      ->select('za_customer.lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    // Yearly Pre Actual
    $yearlyPreActualOriginal = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_transaction', 'za_transaction.trans_source_id', '=', 'za_customer.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereBetween('za_transaction.transaction_date', [$fyStart, $fyEnd])
      ->orderBy('za_customer.sno', 'asc')
      ->count();

    $lowMbcCustomerIdsYear = $badCustomerIds;
    $badCustomerIdsYear = array_unique($lowMbcCustomerIdsYear);
    $yearlyPreActual = max(0, $yearlyPreActualOriginal - count($badCustomerIdsYear));

    // Yearly Post Actual
    $yearlyPostActualOriginal = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereBetween('za_training.created_at', [$fyStart, $fyEnd])
      ->count();

    $yearlyPostActual = max(0, $yearlyPostActualOriginal - count($badCustomerIdsYear));

    // Yearly Achievements
    $yearlyPreAchievement = 0;
    if ($yearlyPreTarget > 0) {
      $yearlyPreAchievement = round(($yearlyPreActual / $yearlyPreTarget) * 100, 1);
    }

    $yearlyPostAchievement = 0;
    if ($yearlyPostTarget > 0) {
      $yearlyPostAchievement = round(($yearlyPostActual / $yearlyPostTarget) * 100, 1);
    }

    // Team Breakdown
    $teamTotalMembers = 0;
    $teamAchievedMembers = 0;
    $teamBreakdown = [];
    $preTotal = 0;
    $preAchieved = 0;

    foreach ($teamTargets as $target) {
      $teamTotalMembers++;
      $actual = 0;

      if ($target->role_id == 11) {
        $actual = $preActuals[$target->staff_id] ?? 0;
      }

      if ($target->role_id == 35) {
        $actual = $postActuals[$target->staff_id] ?? 0;
      }

      $achieved = $target->conversion > 0 && $actual >= $target->conversion;

      if ($achieved) {
        $teamAchievedMembers++;
        if ($target->role_id == 11) {
          $preAchieved++;
        }
      }

      if ($target->role_id == 11) {
        $preTotal++;
      }

      $teamBreakdown[] = [
        'staff_name' => $target->staff_name,
        'role_id' => $target->role_id,
        'target' => $target->conversion,
        'actual' => $actual,
        'status' => $achieved,
      ];
    }

    $teamAchievementStatus = $teamTotalMembers > 0 && $teamAchievedMembers === $teamTotalMembers;
    $teamAchievementReward = $teamAchievementStatus ? ($incentive->team_target ?? 0) : 0;

    // TenX Monthly Status
    $fyStartYear = $financialYear;
    $currentMonth = now()->month;
    $currentYear = now()->year;
    $achievedMonths = 0;
    $monthIcons = '';

    for ($i = 0; $i < 12; $i++) {
      $date = Carbon::create($fyStartYear, 4, 1)->addMonths($i);
      $m = $date->month;
      $y = $date->year;
      $label = $date->format('M');

      if ($y > $currentYear || ($y == $currentYear && $m > $currentMonth)) {
        $status = 'upcoming';
      } elseif ($y == $currentYear && $m == $currentMonth) {
        $status = 'progress';
      } else {
        $actualPre = CustomerModel::whereIn('status', [0, 6])
          ->where('post_sale_check', '!=', 1)
          ->where('branch_id', $branchId)
          ->whereYear('created_at', $y)
          ->whereMonth('created_at', $m)
          ->whereNotIn('sno', $badCustomerIds)
          ->count();

        if ($target_pre > 0 && $target_post > 0 && $actualPre >= $target_pre) {
          $status = 'achieved';
          $achievedMonths++;
        } else {
          $status = 'failed';
        }
      }

      $icon = '';
      switch ($status) {
        case 'achieved':
          $icon = '<div class="text-center"><span class="badge bg-label-success rounded"><i class="mdi mdi-check-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'failed':
          $icon = '<div class="text-center"><span class="badge bg-label-danger rounded"><i class="mdi mdi-close-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'progress':
          $icon = '<div class="text-center"><span class="badge bg-label-info rounded"><i class="mdi mdi-timer-sand fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        default:
          $icon = '<div class="text-center"><span class="badge bg-label-secondary rounded"><i class="mdi mdi-clock-outline fs-7"></i></span><div>' . $label . '</div></div>';
      }
      $monthIcons .= $icon;
    }

    $nineMonthStatus = $achievedMonths >= 9;
    $nineMonthReward = $incentive->nine_monthadd ?? '-';

    // Actual ABV and ACV Calculations
    $actualABV = 0;
    $actualACV = 0;
    $actualABVPost = 0;
    $actualACVPost = 0;

    if (!empty($presaleCustomers)) {
      $presaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_customer.customer_id', $presaleCustomers)
        ->whereNotIn('za_customer.sno', $badCustomerIds)
        ->sum('za_training.overall_fees');

      $presaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('trans_source_id', $presaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABV = ($presaleCount > 0) ? $presaleTotalOverallFees / $presaleCount : 0;
      $actualACV = ($presaleCount > 0) ? $presaleTotalCredit / $presaleCount : 0;
    }

    if (!empty($postsaleCustomers)) {
      $postsaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_training.sno', $postsaleCustomers)
        ->sum('za_training.overall_fees');

      $postsaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('training_id', $postsaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABVPost = ($postSaleCount > 0) ? $postsaleTotalOverallFees / $postSaleCount : 0;
      $actualACVPost = ($postSaleCount > 0) ? $postsaleTotalCredit / $postSaleCount : 0;
    }

    // TenX Status
    $tenxStatus = (
      $target_collection > 0 && $target_pre > 0 && $target_post > 0 &&
      $targetPreABV > 0 && $targetPreACV > 0 && $targetPostABV > 0 && $targetPostACV > 0 &&
      $totalCredit >= $target_collection &&
      $presaleCount >= $target_pre &&
      $postSaleCount >= $target_post &&
      $actualABV >= $targetPreABV &&
      $actualACV >= $targetPreACV &&
      $actualABVPost >= $targetPostABV &&
      $actualACVPost >= $targetPostACV
    );

    // ECI Logic
    $totalTarget = ($target_pre ?? 0) + ($target_post ?? 0);
    $totalConversion15 = ($eciCustomerConvertCount ?? 0) + ($eciCustomerConvertCountPost ?? 0);
    $eciAchievement15 = 0;
    if ($totalTarget > 0) {
      $eciAchievement15 = round(($totalConversion15 / $totalTarget) * 100, 1);
    }

    $slabs = json_decode($incentive->closing_slab_json ?? '[]', true);
    $eciStatus = false;
    $eciReward = 0;
    $eciRewardType = '';

    if (!empty($slabs)) {
      usort($slabs, function ($a, $b) {
        return $b['max'] <=> $a['max'];
      });

      foreach ($slabs as $slab) {
        if ($eciAchievement15 >= $slab['min'] && $eciAchievement15 <= $slab['max']) {
          $eciStatus = true;
          $eciReward = $slab['percentage'];
          $eciRewardType = $slab['max'] . 'th Achievement';
          break;
        }
      }
    }

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCountPre = max(0, $presaleCount - $target_pre);
    $biRewardPre = $biAchievedCountPre * $biPerConversion;
    $biAchievedCountPost = max(0, $postSaleCount - $target_post);
    $biRewardPost = $biAchievedCountPost * $biPerConversion;
    $biReward = $biRewardPre + $biRewardPost;
    $biStatus = ($biAchievedCountPre > 0 || $biAchievedCountPost > 0);

    // Double X
    $doublexTargetPre = ($target_pre * 2);
    $doublexTargetPost = ($target_post * 2);
    $doubleXStatus = (
      $doublexTargetPre > 0 && $doublexTargetPost > 0 &&
      $presaleCount >= $doublexTargetPre &&
      $postSaleCount >= $doublexTargetPost
    );
    $doubleXReward = $incentive->double_x_reward ?? 0;

    // ABV 150%
    $preABVAchievement = 0;
    if (($targetPreABV ?? 0) > 0) {
      $preABVAchievement = round((($actualABV ?? 0) / $targetPreABV) * 100, 1);
    }

    $postABVAchievement = 0;
    if (($targetPostABV ?? 0) > 0) {
      $postABVAchievement = round((($actualABVPost ?? 0) / $targetPostABV) * 100, 1);
    }

    $abvStatus = $preABVAchievement >= 150 && $postABVAchievement >= 150;
    $abvReward = ($tenxStatus && $abvStatus) ? ($incentive->abv_incentive ?? 0) : 0;

    // Yearly 150%
    $yearly150Status = $yearlyPreAchievement >= 150 && $yearlyPostAchievement >= 150;
    $yearly150Reward = $yearly150Status ? ($incentive->yearly_count ?? 0) : 0;

    // Get criteria data
    $criteriaKeys = [
      '10x_award',
      'acv_abv',
      'team_target',
      'closing',
      'add_incentive',
      'double_x_bdm',
      'abv',
      'yearly_count',
      'any_nine_month'
    ];

    $criteriaData = [];
    foreach ($criteriaKeys as $key) {
      $criteria = IncentiveCriteriaModel::where([
        'incentive_key' => $key,
        'role_id' => $staff->role_id,
        'branch_id' => $branchId,
      ])->first();

      $criteriaData[$key] = $criteria ? json_decode($criteria->criteria_points, true) : [];
    }

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'branch_name' => $staff->branch_name,
      'bh_signature' => $staff->cert_auth_sign ?? '1755151615_2.png',
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        'tenx_award' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Pre Sale">
                            <span class="fw-bold fs-9">Pre Sale</span>
                            <span class="fw-bold fs-3">' . ($target_pre ?? 0) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Post Sale">
                            <span class="fw-bold fs-9">Post Sale</span>
                            <span class="fw-bold fs-3">' . ($target_post ?? 0) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Pre ABV">
                            <span class="fw-bold fs-9">Pre ABV</span>
                            <span class="fw-bold fs-3">₹' . number_format($targetPreABV) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Pre ACV">
                            <span class="fw-bold fs-9">Pre ACV</span>
                            <span class="fw-bold fs-3">₹' . number_format($targetPreACV) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Post ABV">
                            <span class="fw-bold fs-9">Post ABV</span>
                            <span class="fw-bold fs-3">₹' . number_format($targetPostABV) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Post ACV">
                            <span class="fw-bold fs-9">Post ACV</span>
                            <span class="fw-bold fs-3">₹' . number_format($targetPostACV) . '</span>
                        </span>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($presaleCount >= $target_pre ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Pre Sale">
                            <span class="fw-bold fs-9">Pre Sale</span>
                            <span class="fw-bold fs-3">' . $presaleCount . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($postSaleCount >= $target_post ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Post Sale">
                            <span class="fw-bold fs-9">Post Sale</span>
                            <span class="fw-bold fs-3">' . $postSaleCount . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($actualABV >= $targetPreABV ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Pre ABV">
                            <span class="fw-bold fs-9">Pre ABV</span>
                            <span class="fw-bold fs-3">₹' . number_format($actualABV) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($actualACV >= $targetPreACV ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Pre ACV">
                            <span class="fw-bold fs-9">Pre ACV</span>
                            <span class="fw-bold fs-3">₹' . number_format($actualACV) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($actualABVPost >= $targetPostABV ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Post ABV">
                            <span class="fw-bold fs-9">Post ABV</span>
                            <span class="fw-bold fs-3">₹' . number_format($actualABVPost) . '</span>
                        </span>
                        <span class="d-flex flex-column align-items-center gap-1 badge ' . ($actualACVPost >= $targetPostACV ? 'bg-label-success' : 'bg-label-danger') . '"
                            data-bs-toggle="tooltip" title="Actual Post ACV">
                            <span class="fw-bold fs-9">Post ACV</span>
                            <span class="fw-bold fs-3">₹' . number_format($actualACVPost) . '</span>
                        </span>
                    </div>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
          'incentive_reward' => $incentive->tenx_award ?? 1000,
          'reward_type' => 'amount',
          'rules' => $criteriaData['10x_award'] ?? [],
        ],
        'abv_incentive' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge bg-label-info fs-3">Pre Target: ₹' . number_format($targetPreABV) . '</span>
                        <span class="badge bg-label-warning fs-3">Post Target: ₹' . number_format($targetPostABV) . '</span>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge ' . ($actualABV >= $targetPreABV ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Pre: ' . number_format($actualABV) . '
                        </span>
                        <span class="badge ' . ($actualABVPost >= $targetPostABV ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Post: ' . number_format($actualABVPost) . '
                        </span>
                    </div>',
          'status' => $tenxStatus && $abvStatus,
          'reward' => $tenxStatus && $abvStatus ? $abvReward : 0,
          'incentive_reward' => $incentive->abv_incentive ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['abv_incentive'] ?? [],
        ],
        'team_achievement_incentive' => [
          'target' => '
                    <div class="d-flex gap-2 flex-wrap">
                        <span class="badge bg-label-primary fs-3">Team: ' . $teamTotalMembers . '</span>
                        <span class="badge bg-label-info fs-3">Pre Sale: ' . $preTotal . '</span>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-2 flex-wrap fs-3">
                        <span class="d-flex align-items-center badge ' . ($preAchieved >= $preTotal ? 'bg-label-success' : 'bg-label-danger') . '">
                            Pre: ' . $preAchieved . ' / ' . $preTotal . '
                        </span>
                        <span class="fw-bold ms-1 fs-3 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openTeamDetailsModal(' . $staffId . ')">Details</span>
                    </div>',
          'status' => $tenxStatus && $teamAchievementStatus,
          'reward' => $tenxStatus && $teamAchievementStatus ? $teamAchievementReward : 0,
          'incentive_reward' => $incentive->team_target ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['team_target'] ?? [],
        ],
        'eci' => [
          'target' => '
                    <div class="d-flex gap-1">
                        <span class="badge bg-label-primary fs-3">Target: ' . ($incentive->eci_count ?? 0) . '%</span>
                        <span class="badge bg-label-secondary fs-3">Total Target: ' . ($totalTarget ?? 0) . '</span>
                    </div>',
          'actual' => '
                    <div class="d-flex flex-wrap gap-1">
                        <span class="badge bg-label-info fs-3">15th: ' . round($eciAchievement15 ?? 0, 1) . '%</span>
                        <span class="badge ' . ($eciStatus ? 'bg-label-success' : 'bg-label-info') . ' fs-3">' . $eciRewardType . '</span>
                    </div>',
          'status' => $tenxStatus && $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? $eciReward : 0,
          'incentive_reward' => 5000,
          'reward_type' => 'amount',
          'rules' => $criteriaData['closing'] ?? [],
        ],
        'bi' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <div class="d-flex flex-column gap-1 badge bg-label-secondary fw-bold fs-3 text-center">
                            <span>Pre Sale</span>
                            <span>' . (($target_pre ?? 0) . ' - ' . ($presaleCount ?? 0) . ' = (' . ($biAchievedCountPre ?? 0) . ')') . '</span>
                        </div>
                        <div class="d-flex flex-column gap-1 badge bg-label-secondary fw-bold fs-3 text-center">
                            <span>Post Sale</span>
                            <span>' . (($target_post ?? 0) . ' - ' . ($postSaleCount ?? 0) . ' = (' . ($biAchievedCountPost ?? 0) . ')') . '</span>
                        </div>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <div class="d-flex flex-column gap-1 fw-bold fs-3 badge ' . ($biAchievedCountPre > 0 ? 'bg-label-success' : 'bg-label-danger') . ' text-center">
                            <span>Pre Sale</span>
                            <span>' . (($biAchievedCountPre ?? 0) . ' × ' . ($biPerConversion ?? 0)) . '</span>
                        </div>
                        <div class="d-flex flex-column gap-1 fw-bold fs-3 badge ' . ($biAchievedCountPost > 0 ? 'bg-label-success' : 'bg-label-danger') . ' text-center">
                            <span>Post Sale</span>
                            <span>' . (($biAchievedCountPost ?? 0) . ' × ' . ($biPerConversion ?? 0)) . '</span>
                        </div>
                    </div>',
          'status' => $tenxStatus && $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
          'incentive_reward' => $incentive->add_incentive ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['add_incentive'] ?? [],
        ],
        'doublex' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="2X Pre Sale">' . ($doublexTargetPre) . '</span>
                        <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="2X Post Sale">' . ($doublexTargetPost) . '</span>
                    </div>',
          'actual' => '
                    <span class="fw-bold fs-2 badge ' . ($presaleCount >= $doublexTargetPre ? 'bg-label-success' : 'bg-label-danger') . '" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Pre Sale">' . ($presaleCount ?? 0) . '</span>
                    <span class="fw-bold fs-2 badge ' . ($postSaleCount >= $doublexTargetPost ? 'bg-label-success' : 'bg-label-danger') . '" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Post Sale">' . ($postSaleCount ?? 0) . '</span>',
          'status' => $tenxStatus && $doubleXStatus,
          'reward' => ($tenxStatus && $doubleXStatus) ? $doubleXReward : 0,
          'incentive_reward' => $incentive->double_x_bdm ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['double_x_bdm'] ?? [],
        ],
        'abv_150_incentive' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge bg-label-primary fs-3">Required: 150%</span>
                        <span class="badge bg-label-info fs-3">Pre Target: ₹' . number_format($targetPreABV) . '</span>
                        <span class="badge bg-label-warning fs-3">Post Target: ₹' . number_format($targetPostABV) . '</span>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge ' . ($preABVAchievement >= 150 ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Pre: ' . number_format($actualABV) . ' (' . $preABVAchievement . '%)
                        </span>
                        <span class="badge ' . ($postABVAchievement >= 150 ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Post: ' . number_format($actualABVPost) . ' (' . $postABVAchievement . '%)
                        </span>
                    </div>',
          'status' => $tenxStatus && $abvStatus,
          'reward' => ($tenxStatus && $abvStatus) ? $abvReward : 0,
          'incentive_reward' => $incentive->abv ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['abv'] ?? [],
        ],
        'yearly_150_incentive' => [
          'target' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge bg-label-primary fs-3">Required: 150%</span>
                        <span class="badge bg-label-info fs-3">FY Pre Target: ' . round($yearlyPreTarget * 1.5) . '</span>
                        <span class="badge bg-label-warning fs-3">FY Post Target: ' . round($yearlyPostTarget * 1.5) . '</span>
                    </div>',
          'actual' => '
                    <div class="d-flex gap-1 flex-wrap">
                        <span class="badge ' . ($yearlyPreAchievement >= 150 ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Pre: ' . $yearlyPreActual . ' (' . $yearlyPreAchievement . '%)
                        </span>
                        <span class="badge ' . ($yearlyPostAchievement >= 150 ? 'bg-label-success' : 'bg-label-danger') . ' fs-3">
                            Post: ' . $yearlyPostActual . ' (' . $yearlyPostAchievement . '%)
                        </span>
                    </div>',
          'status' => $tenxStatus && $yearly150Status,
          'reward' => $tenxStatus && $yearly150Status ? $yearly150Reward : 0,
          'incentive_reward' => $incentive->yearly_count ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['yearly_count'] ?? [],
        ],
        'nine_month_consistency_incentive' => [
          'target' => '
                    <div class="d-flex gap-2 flex-wrap">
                        <span class="badge bg-label-primary fs-3">Required: 9 Months</span>
                        <span class="badge bg-label-info fs-3">Achieved: ' . $achievedMonths . '/9</span>
                    </div>',
          'actual' => '<div class="d-flex justify-content-center flex-wrap gap-2">' . $monthIcons . '</div>',
          'status' => ($tenxStatus && $nineMonthStatus),
          'reward' => $tenxStatus && $nineMonthStatus ? $nineMonthReward : '-',
          'incentive_reward' => $incentive->any_nine_month ?? 0,
          'reward_type' => 'gift',
          'rules' => $criteriaData['any_nine_month'] ?? [],
        ],
      ]
    ];
  }


  // end incentive main


  private function getTeamIncentiveStatus(array $executiveIds, array $allExecutiveIncentives): array
  {
    $finalStatus = [
      'tenx_award' => true,
      'eci' => true,
      'bi' => true,
      'si' => true,
      'pi' => true,
      'sp' => true,
    ];

    foreach ($executiveIds as $execId) {
      $key = 'staff_' . $execId;

      if (!isset($allExecutiveIncentives[$key])) {
        // If data missing, fail all
        foreach ($finalStatus as $type => $_) {
          $finalStatus[$type] = false;
        }
        continue;
      }

      $incentiveSet = $allExecutiveIncentives[$key]['incentives'] ?? [];

      foreach ($finalStatus as $type => $_) {
        // If not true, then mark team as not fully achieved
        if (!isset($incentiveSet[$type]['status']) || $incentiveSet[$type]['status'] !== true) {
          $finalStatus[$type] = false;
        }
      }
    }

    return $finalStatus;
  }

  private function calculateIncentivesForStaff($staff, $branchId, $month, $year, $goalsetData)
  {
    $finalStatus = [
      'tenx_award' => true,
      'eci' => true,
      'bi' => true,
      'si' => true,
      'pi' => true,
      'sp' => true,
    ];

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    // Generate all dates in the month
    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    // Directly use startDate and endDate for formatting
    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');
    // $finalStatus  = [];

    // foreach ($staff as $staff) {

    $current_date = date('Y-m-d'); // Define the current date
    //Sales Team

    $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staff->sno)
      ->where('za_lead.branch_id', $branchId)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staff->sno)
      ->where('za_lead.branch_id', $branchId)
      ->whereYear('za_lead.registered_date', $year)
      ->whereMonth('za_lead.registered_date', $month)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    $monthcall_out = DB::table('za_call_tracker')
      ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('za_call_tracker.branch_id', $branchId)
      ->where('za_call_tracker.branch_staff_id', $staff->staff_id)
      ->first();
    $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;


    // customer ratio
    $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
    $convertion_rate = number_format($convertion_rate, 2);

    //acr
    $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
    $averager_convertion_rate = number_format($averager_convertion_rate, 2);

    $incentive = IncentiveModel::where('role_id', 11)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      return []; // or return null or false based on your method return type
    }

    $luxury = json_decode($incentive->luxury_incentive, true);
    $pi_slabs = json_decode($incentive->pi_slab_json, true);

    $currentMonthCustomerCount = 0;
    $total_business_amount     = 0;
    $total_payment             = 0;
    $total_paid_payment        = 0;
    $averageBusinessValue      = 0;
    $averageCollectionValue    = 0;
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;
    $courseTypeTotal = 0;
    $eciCustomerConvertCount = 0;
    $eciActualPercentage = 0;
    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciStatus = false;

    $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
    $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
    $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;
    $crashTarget = 0;
    $professionTarget = 0;
    $tesboTarget = 0;
    $crashPercent = 0;
    $professionPercent = 0;
    $tesboPercent = 0;
    $piPercentage = 0;
    $originalAmount = 0;
    $piReward = 0;
    $matchedSlab = null;
    $slabPercentage = 0;

    // Total Professional and Crash courses
    $groupedData = DB::table('za_training')
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->select(
        'za_course.course_type_id',
        DB::raw('COUNT(DISTINCT za_training.payment_id) AS total_trainings')
      )
      ->where('za_training.branch_id', $branchId)
      ->whereMonth('za_training.created_at', $month)
      ->whereYear('za_training.created_at', $year)
      ->whereIn('za_course.course_type_id', [3, 4])
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_training.post_sale_check', '!=', 1)
      ->groupBy('za_course.course_type_id')
      ->get();

    // Get valid TESBO count separately
    $teshobo_coures_total = DB::table('za_training')
      ->where('branch_id', $branchId)
      ->whereMonth('created_at', $month)
      ->whereYear('created_at', $year)
      ->where('tesbo_check', 2)
      ->where('post_sale_check', '!=', 1)
      ->distinct('payment_id')
      ->count('payment_id');

    // Prepare tree output
    $crash_coures_total = 0;
    $professinal_coures_total = 0;

    foreach ($groupedData as $row) {
      if ($row->course_type_id == 3) {
        $professinal_coures_total = (int) $row->total_trainings;
      } elseif ($row->course_type_id == 4) {
        $crash_coures_total = (int) $row->total_trainings;
      }
    }

    $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;

    if ($customerConvertCount > 0) {
      $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->whereIn('za_customer.status', [0, 6])
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->get();


      // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total
      // ECI early conversion before 15th
      $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->whereIn('za_customer.status', [0, 6])
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->whereDay('za_customer.created_at', '<=', 15)
        ->count();
      //   return $currentMonthCustomer;
      if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {

          // First: check if this customer has TESBO training
          $hasTesbo = DB::table('za_training')
            ->where('customer_id', $customer->sno)
            ->where('branch_id', $branchId)
            ->whereMonth('created_at', $month)
            ->whereYear('created_at', $year)
            ->where('tesbo_check', 2)
            ->where('post_sale_check', '!=', 1)
            ->exists();

          if ($hasTesbo) {
            $tesboCount++;
            continue; // skip crash/professional check if TESBO already counted
          }

          // Then: check if customer has valid Professional or Crash training (not tesbo)
          $nonTesboTrainings = DB::table('za_training')
            ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
            ->where('za_training.customer_id', $customer->sno)
            ->where('za_training.branch_id', $branchId)
            ->whereMonth('za_training.created_at', $month)
            ->whereYear('za_training.created_at', $year)
            ->where('za_training.post_sale_check', '!=', 1)
            ->where('za_training.tesbo_check', '!=', 2)
            ->whereIn('za_course.course_type_id', [3, 4])
            ->select('za_course.course_type_id')
            ->get();

          $hasCrash = false;
          $hasProfession = false;

          foreach ($nonTesboTrainings as $training) {
            if ($training->course_type_id == 3) {
              $hasProfession = true;
            } elseif ($training->course_type_id == 4) {
              $hasCrash = true;
            }
          }

          if ($hasCrash) $crashCount++;
          if ($hasProfession) $professionCount++;
        }

        $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
      }
      // return $crashCount;
      // spot incentive
      $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalcours) * 100 : 0;
      $professionPercent = $incentive->si_profession_course > 0 ? ($totalcours / $professinal_coures_total) * 100 : 0;
      $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalcours) * 100 : 0;

      $crashTarget = $incentive->si_crash_course ?? 0;
      $professionTarget = $incentive->si_profession_course ?? 0;
      $tesboTarget = $incentive->si_tesbo_course ?? 0;

      // only condition: Crash must be ≤ target
      $siStatus = $crashPercent <= $crashTarget;



      if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {
          // $trainings = DB::table('za_training')
          //     ->where('customer_id', $customer->sno)
          //       ->where('post_sale_check', 0)
          //     ->get();
          $trainings = DB::table('za_training as t1')
            ->join(DB::raw('(
                                        SELECT MIN(sno) as min_sno
                                        FROM za_training
                                        WHERE post_sale_check = 0
                                        GROUP BY customer_id
                                    ) as t2'), 't1.sno', '=', 't2.min_sno')
            ->where('t1.customer_id', $customer->sno)
            ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
            ->get();

          foreach ($trainings as $training) {
            // Determine course_id based on tesbo_check
            $course_id = null;

            if ($training->tesbo_check > 0) {
              $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
              if ($payment && $payment->course_id) {
                $course_id = $payment->course_id;
              }
            } else {
              $course_id = $training->course_id;
            }

            if (!$course_id) continue; // Skip if no course_id

            $course = ManageCoursesModel::where('sno', $course_id)
              ->whereIn('course_type_id', [2, 3])
              ->first();

            if (!$course) continue;

            $basePrice = $course->course_min_price;
            $soldPrice = $training->overall_fees;


            $profitAmount = $soldPrice - $basePrice;
            $originalAmount += $profitAmount; // always include both + and -

            $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;

            // Match against PI slabs
            foreach ($pi_slabs as $slab) {
              if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                $slabPercentage = $slab['percentage'];
                $rewardFromThis = ($profitAmount * $slabPercentage) / 100;

                $piReward += $rewardFromThis;
                $piPercentage = $profitPercent;
                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                break; // first matching slab
              }
            }
          }
        }
      }

      if ($currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {

          $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
            ->where('za_training.customer_id', $customer->sno)
            ->where('za_training.tesbo_check', 0)
            ->sum('za_training.overall_fees');

          $total_payment += $payment;


          $latestTraining = DB::table('za_training')
            ->where('customer_id', $customer->sno)
            ->where('tesbo_check', 2)
            ->orderByDesc('sno')
            ->first();

          if ($latestTraining) {
            $total_payment += $latestTraining->overall_fees;
          }

          $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
            ->where('za_training.customer_id', $customer->sno)
            ->sum('za_training.paid_amount');

          $total_paid_payment += $paid_payment;
        }
      }
      // ECI Logic
      $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
      $eciActualPercentage = number_format($eciActualPercentage, 2);
      $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

      // average
      $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
      $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

      // $totalAllPayment += $total_payment;
      // $totalAllPaidPayment += $total_paid_payment;
    }

    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereRaw('DATE(za_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at'
      )
      ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');

      if ($customerDate ===  $leadDate) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $dates &&
        $leadDate >= $startOfMonth && $leadDate <= $dates
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $dates &&
        ($leadDate < $startOfMonth || $leadDate > $dates)
      ) {
        $convertedOldMonth++;
      }
    }

    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    // Old month = always 0
    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    // 10x award calculation
    $actualConversion      = $customerConvertCount;
    $actualABV             = $averageBusinessValue ?? 0;
    $actualACV             = $averageCollectionValue ?? 0;


    $tenxStatus = (
      $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
      $actualConversion >= $targetConversion
    );
    // bi award calculation
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus

    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $biAchievedCount > 0;


    return [

      'incentives' => [
        'tenx_award' => [
          'target' => "{$targetConversion}, {$targetABV}, {$targetACV}",
          'actual' => " {$actualConversion}, " . round($actualABV) . ", " . round($actualACV) .
            ' <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                    <i class="mdi mdi-help-circle text-dark"></i>
                                </label>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],

        'eci' => [
          'target' => $eciTargetPercentage . '%',
          'actual' => round($eciActualPercentage, 1) . '%' . ' <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
          'status' => $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
        ],

        'bi' => [
          'target' => "{$targetConversion} - {$actualConversion} = ({$biAchievedCount})",
          'actual' => "{$biAchievedCount} × {$biPerConversion}",
          'status' =>  $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
        ],

        'si' => [
          'target' => "{$crashTarget}:{$professionTarget}:{$tesboTarget}",
          'actual' => round($crashPercent) . '%' . ':' . round($professionPercent) . '%' . ':' . round($tesboPercent) . '%',
          'status' => $tenxStatus && $siStatus,
          'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
        ],

        'pi' => [
          'target' => $matchedSlab . round($slabPercentage, 2) . '%' ?? 'No Matching Slab',
          'actual' => round($piPercentage, 2) . '%' . '₹' . $originalAmount,
          'status' => $piReward > 0,
          'reward' => ($tenxStatus && $piReward > 0)
            ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
            : 0,
        ],

        'sp' => [
          'target' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>' . $convertedOldMonth . '</td></tr>
                                </table>
                            ',
          'actual' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>₹0</td></tr>
                                </table>
                            ',
          'status' => $tenxStatus && $spotTotalReward > 0,
          'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
        ],


        'li' => [
          'target' => 'All Incentives Achieved',
          'actual' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
            ? 'Achieved'
            : 'Not Achieved',
          'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus),
          'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
            ? ($luxury['reward'] ?? 0)
            : 0,
        ]
      ]
    ];
  }

    //single my incentive get start

  public function getMyIncentiveMetrics(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $user_id = $request->user()->user_id;
    $year = $request->year;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    // Generate all dates in the month
    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $current = Carbon::create($year, $month, 1);
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth();

    // Get staff details
    $staff = StaffModel::join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.sno', $user_id)
      ->where('za_staff.status', 0)
      ->select(
        'za_staff.sno as staff_id',
        'za_staff.staff_name',
        'za_staff.role_id',
        'za_staff.department_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.branch_id',
        'za_branch.branch_name',
        'za_branch.franchise_name',
        'za_branch.cert_auth_sign',
        'za_staff.avaiable_points',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_sub_department.sub_department_id',
        'za_sub_department.sub_department_name',
        'za_department.department_name'
      )
      ->first();

    if (!$staff) {
      return response()->json([
        'status' => 404,
        'message' => 'Staff not found'
      ]);
    }

    $role_id = $staff->role_id;

    // Get goal records
    $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', $staff->department_id)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $request->month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $staff->department_id)
      ->where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $request->month)
      ->whereMonth('za_goal_set_staff.goal_date', $request->month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->get();

    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    // Check if staff has goal record
    $checkRecord = GoalSetStaffModel::where('za_goal_set_staff.department_id', $staff->department_id)
      ->where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $request->month)
      ->whereMonth('za_goal_set_staff.goal_date', $request->month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->where('staff_id', $staff->staff_id)
      ->first();

    $current_date = date('Y-m-d');

    // Get incentive
    $incentive = IncentiveModel::where('role_id', $staff->role_id)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $request->year)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      $fallbackDate = '2025-06-01';
      $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
        ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
        ->where('status', 0)
        ->first();
    }

    // Check role and process
    $isProduction = $staff->role_id == 22;
    $isSalesEx    = $staff->role_id == 11;
    $isTeamLead   = $staff->role_id == 12;
    $isCollection = $staff->role_id == 14;
    $isCRE        = $staff->role_id == 16;
    $isPC         = $staff->role_id == 15;
    $isplacementEx = $staff->role_id == 17;
    $isplacementLead = $staff->role_id == 19;
    $isBDM        = $staff->role_id == 36;

    $result = [];

    // Process based on role - use the same methods as getIncentiveMetrics
    if ($isTeamLead) {
      // For team lead, we need to check if they have sales_lead_check
      $checkRole = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
        ->where('za_goal_set_staff.goal_month', $request->month)
        ->whereMonth('za_goal_set_staff.goal_date', $request->month)
        ->whereYear('za_goal_set_staff.goal_date', $year)
        ->where('staff_id', 123)
        ->first();

      // Get all goalset records for team lead calculation
      $allGoalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $staff->department_id)
        ->where('za_goal_set_staff.branch_id', $branchId)
        ->where('za_goal_set_staff.goal_month', $request->month)
        ->whereMonth('za_goal_set_staff.goal_date', $request->month)
        ->whereYear('za_goal_set_staff.goal_date', $year)
        ->get();

      $result[] = $this->processTeamLeadSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $allGoalsetRecords,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startOfMonth,
        $endOfMonth,
        $prevMonth,
        $prevYear,
        $dates,
        $checkRole,
        $goalsetData
      );
    } elseif ($isSalesEx) {
      $result[] = $this->processSalesExecutiveSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startOfMonth,
        $endOfMonth,
        $prevMonth,
        $prevYear,
        $dates
      );
    } elseif ($isCollection) {
      $result[] = $this->processCollectionSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDateold,
        $endDateold,
        $startDate,
        $endDate
      );
    } elseif ($isCRE) {
      $result[] = $this->processCRESingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year
      );
    } elseif ($isProduction) {
      $result[] = $this->processProductionSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $current_date
      );
    } elseif ($isPC) {
      $result[] = $this->processPCSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $current_date
      );
    } elseif ($isplacementEx) {
      $result[] = $this->processPlacementExSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year
      );
    } elseif ($isplacementLead) {
      $result[] = $this->processPlacementLeadSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year
      );
    } elseif ($isBDM) {
      $result[] = $this->processBDMSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetteam,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startDateold,
        $endDateold,
        $prevMonth,
        $prevYear,
        $dates,
        $startOfMonth,
        $endOfMonth
      );
    }

    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }

  /**
   * Process Sales Executive - Single Staff (same as original but optimized)
   */
  private function processSalesExecutiveSingle($staff, $incentive, $checkRecord, $goalsetData, $branchId, $month, $year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates)
  {
    $staffId = $staff->staff_id;

    // All Lead Count
    $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Month Lead Count
    $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereYear('za_lead.registered_date', $year)
      ->whereMonth('za_lead.registered_date', $month)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Customer Convert Count This Month
    $customerConvertCountthismonth = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));

    // Month Call Out
    $monthcall_out = DB::table('za_call_tracker')
      ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('za_call_tracker.branch_id', $branchId)
      ->where('za_call_tracker.branch_staff_id', $staffId)
      ->first();
    $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;

    // Conversion Rate
    $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
    $convertion_rate = number_format($convertion_rate, 2);

    // Average Conversion Rate
    $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
    $averager_convertion_rate = number_format($averager_convertion_rate, 2);

    $luxury = json_decode($incentive->luxury_incentive, true);
    $pi_slabs = json_decode($incentive->pi_slab_json, true);

    $targetConversion = $goalsetData[$staffId]->conversion ?? 0;
    $targetABV = $goalsetData[$staffId]->ABV ?? 0;
    $targetACV = $goalsetData[$staffId]->ACV ?? 0;

    // Initialize variables
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;
    $total_payment = 0;
    $total_paid_payment = 0;
    $eciCustomerConvertCount = 0;

    // Get Current Month Customers
    $currentMonthCustomer = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    // ECI Count
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->count();

    // Calculate Training Counts
    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $hasTesbo = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('branch_id', $branchId)
          ->whereMonth('created_at', $month)
          ->whereYear('created_at', $year)
          ->where('tesbo_check', 2)
          ->where('post_sale_check', '!=', 1)
          ->exists();

        if ($hasTesbo) {
          $tesboCount++;
          continue;
        }

        $nonTesboTrainings = DB::table('za_training')
          ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
          ->where('za_training.customer_id', $customer->sno)
          ->where('za_training.branch_id', $branchId)
          ->whereMonth('za_training.created_at', $month)
          ->whereYear('za_training.created_at', $year)
          ->where('za_training.post_sale_check', '!=', 1)
          ->where('za_training.tesbo_check', '!=', 2)
          ->whereIn('za_course.course_type_id', [3, 4])
          ->select('za_course.course_type_id')
          ->get();

        $hasCrash = false;
        $hasProfession = false;

        foreach ($nonTesboTrainings as $training) {
          if ($training->course_type_id == 3) {
            $hasProfession = true;
          } elseif ($training->course_type_id == 4) {
            $hasCrash = true;
          }
        }

        if ($hasCrash) $crashCount++;
        if ($hasProfession) $professionCount++;
      }
    }

    // Calculate Payments
    if ($currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 0)
          ->sum('overall_fees');
        $total_payment += $payment;

        $latestTraining = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 2)
          ->orderByDesc('sno')
          ->first();

        if ($latestTraining) {
          $total_payment += $latestTraining->overall_fees;
        }

        $paid_payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->sum('paid_amount');
        $total_paid_payment += $paid_payment;
      }
    }

    // SP Calculation
    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereBetween('za_customer.created_at', [$startDate, $endDate])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at',
        'za_lead.lead_mobile as lead_mobile'
      )
      ->get();

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $lastCall = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->orderByDesc('call_start_date')
        ->first();

      $totalCallCount = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->count();

      $row->call_created_at = $lastCall->call_start_date ?? null;
      $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
      $row->call_count = $totalCallCount;
    }

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $totalCalldata = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->select('call_start_date')
        ->get();

      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
      $call_count = $row->call_count;

      if ($customerDate === $leadDate && $call_count === 1) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        $leadDate >= $startOfMonth && $leadDate <= $endOfMonth &&
        $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
          $callDate = Carbon::parse($call->call_start_date);
          return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
        })
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        ($leadDate < $startOfMonth || $leadDate > $endOfMonth)
      ) {
        $convertedOldMonth++;
      }
    }

    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    // PI Calculation
    $originalAmount = 0;
    $piPercentage = 0;
    $slabPercentage = 0;
    $matchedSlab = null;
    $piReward = 0;

    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $trainings = DB::table('za_training as t1')
          ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
          ->where('t1.customer_id', $customer->sno)
          ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
          ->get();

        foreach ($trainings as $training) {
          $course_id = null;

          if ($training->tesbo_check > 0) {
            $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
            if ($payment && $payment->course_id) {
              $course_id = $payment->course_id;
            }
          } else {
            $course_id = $training->course_id;
          }

          if (!$course_id) continue;

          $course = ManageCoursesModel::where('sno', $course_id)
            ->whereIn('course_type_id', [2, 3])
            ->first();

          if (!$course) continue;

          $basePrice = $course->course_min_price;
          $soldPrice = $training->overall_fees;
          $profitAmount = $soldPrice - $basePrice;
          $originalAmount += $profitAmount;

          $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;

          foreach ($pi_slabs as $slab) {
            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
              $slabPercentage = $slab['percentage'];
              $piReward = ($originalAmount * $slabPercentage) / 100;
              $piPercentage = $profitPercent;
              $matchedSlab = "{$slab['min']} < {$slab['max']}%";
              break;
            }
          }
        }
      }
    }

    // SI Calculation
    $crashTarget = $incentive->si_crash_course ?? 0;
    $professionTarget = $incentive->si_profession_course ?? 0;
    $tesboTarget = $incentive->si_tesbo_course ?? 0;

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $crashTarget || $crashPercent <= $crashTarget);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $professionTarget);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
      }
    }

    // ECI Logic
    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciActualPercentage = number_format($eciActualPercentage, 2);
    $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

    // Averages
    $averageBusinessValue = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;

    // 10X Status
    $tenxStatus = $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 && $customerConvertCount >= $targetConversion;

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $customerConvertCount - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $biAchievedCount > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'branch_name' => $staff->branch_name,
      'bh_signature' => $staff->cert_auth_sign,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        'tenx_award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $customerConvertCountthismonth . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary">' . $customerConvertCount . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary">' . round($averageBusinessValue) . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary">' . round($averageCollectionValue) . '</span>
                              <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staffId . ')" >Details</span>
                              <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                  <i class="mdi mdi-help-circle text-dark"></i>
                              </label>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'eci' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staffId . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
          'status' => $tenxStatus && $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
        ],
        'bi' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($targetConversion . ' - ' . $customerConvertCount . ' = (' . $biAchievedCount . ')') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($biAchievedCount . ' × ' . $biPerConversion) . '</span>',
          'status' => $tenxStatus && $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
        ],
        'si' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . "{$crashTarget}:{$professionTarget}:{$tesboTarget}" . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . number_format($crashPercent, 1) . ' : ' . number_format($professionPercent, 1) . ' : ' . number_format($tesboPercent, 1) . ' = ' . number_format($crashPercent + $professionPercent + $tesboPercent) . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus && $siStatus,
          'reward' => ($tenxStatus && $siStatus) ? ($incentive->si_reward ?? 0) : 0,
        ],
        'pi' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus && $piReward > 0,
          'reward' => ($tenxStatus && $piReward > 0) ? round($piReward) : 0,
        ],
        'sp' => [
          'target' => '<table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . '</span>
                                      </td>
                                  </tr>
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . '</span>
                                      </td>
                                  </tr>
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedOldMonth . '
                                      </td>
                                  </tr>
                              </table>',
          'actual' => '<table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</span>
                                      </td>
                                  </tr>
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</span>
                                      </td>
                                  </tr>
                                  <tr style="border: none !important;">
                                      <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                      <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                      <td style="border: none !important; background: transparent !important;">
                                          <span class="badge bg-label-secondary fw-bold fs-3">₹0</span></span> </span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openManageCallModal(' . $staffId . ')" >Details</span>
                                      </td>
                                  </tr>
                              </table>',
          'status' => $tenxStatus && $spotTotalReward > 0,
          'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
        ],
        'li' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? 'Achieved' : 'Not Achieved') . '</span>',
          'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
          'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? ($luxury['reward'] ?? 0) : 0,
        ]
      ]
    ];
  }

  /**
   * Process Team Lead - Single Staff (same as original)
   */
  private function processTeamLeadSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetRecords, $branchId, $month, $year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates, $checkRole, $goalsetData)
  {
    if ($checkRecord && $checkRecord->sales_lead_check == 0) {
      $executives = StaffModel::where('branch_id', $staff->branch_id)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $executiveIds = $executives->pluck('sno')->toArray();
      $executiveGoalSet = $goalsetRecords
        ->whereIn('staff_id', $executiveIds)
        ->where('conversion', '>', 0)
        ->pluck('staff_id')
        ->unique()
        ->toArray();

      $incentive = IncentiveModel::where('role_id', 11)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->first();

      if (!$incentive) {
        return [];
      }

      // For single staff, we only need to check if they are a team lead
      // and return their team status
      $allExecutiveIncentives = [];
      foreach ($executives->whereIn('sno', $executiveGoalSet) as $executive) {
        // Simplified - just get counts
        $execCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->whereIn('za_customer.status', [0, 6])
          ->where('za_customer.branch_id', $branchId)
          ->where('za_lead.created_by', $executive->sno)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->count();

        $allExecutiveIncentives['staff_' . $executive->sno] = [
          'tenx_status' => $execCount >= ($goalsetData[$executive->sno]->conversion ?? 0),
          'eci_status' => true,
          'bi_status' => true,
          'si_status' => true,
          'pi_status' => true,
          'sp_status' => true,
        ];
      }

      $finalStatus = $this->getTeamIncentiveStatusSingle($executiveGoalSet, $allExecutiveIncentives);
      $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->whereMonth('branch_target.date', $month)
        ->whereYear('branch_target.date', $year)
        ->select('branch_target.*')
        ->first();

      $preSaleActual = CustomerModel::whereIn('status', [0, 6])
        ->where('branch_id', $branchId)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;

      return [
        'staff_id' => $staff->staff_id,
        'staff_name' => $staff->staff_name,
        'branch_name' => $staff->branch_name,
        'bh_signature' => $staff->cert_auth_sign,
        'staff_image' => $staff->staff_image,
        'role_id' => $staff->role_id,
        'nick_name' => $staff->nick_name,
        'sub_department_name' => $staff->sub_department_name,
        'department_name' => $staff->department_name,
        'incentives' => [
          'tenx_award' => [
            'target' => 'All Executives Achieved 10x',
            'actual' => $individual10x ? 'Achieved' : 'Not Achieved',
            'status' => $individual10x,
            'reward' => $individual10x ? ($incentive->tenx_award ?? 0) : 0,
          ],
          'eci' => [
            'target' => 'All Executives Achieved ECI',
            'actual' => $finalStatus['eci'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['eci'],
            'reward' => $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0,
          ],
          'bi' => [
            'target' => 'All Executives Achieved BI',
            'actual' => $finalStatus['bi'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['bi'],
            'reward' => $finalStatus['bi'] ? ($incentive->bi_amount ?? 0) : 0,
          ],
          'si' => [
            'target' => 'All Executives Achieved SI',
            'actual' => $finalStatus['si'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['si'],
            'reward' => $finalStatus['si'] ? 3000 : 0,
          ],
          'pi' => [
            'target' => 'All Executives Achieved PI',
            'actual' => $finalStatus['pi'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['pi'],
            'reward' => $finalStatus['pi'] ? ($incentive->pi_reward ?? 0) : 0,
          ],
          'sp' => [
            'target' => 'All Executives Achieved SP',
            'actual' => $finalStatus['sp'] ? 'Achieved' : 'Not Achieved',
            'status' => $finalStatus['sp'],
            'reward' => $finalStatus['sp'] ? ($incentive->spot_total_reward ?? 0) : 0,
          ],
          'li' => [
            'target' => 'All Incentives Achieved by Team',
            'actual' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
              ? 'Achieved' : 'Not Achieved',
            'status' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']),
            'reward' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
              ? ($incentive->luxury_reward ?? 0) : 0,
          ]
        ],
      ];
    } else {
      return $this->processSalesExecutiveSingle(
        $staff,
        $incentive,
        $checkRecord,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startOfMonth,
        $endOfMonth,
        $prevMonth,
        $prevYear,
        $dates
      );
    }
  }

  /**
   * Get Team Incentive Status - Single
   */
  private function getTeamIncentiveStatusSingle($executiveGoalSet, $allExecutiveIncentives)
  {
    $status = [
      'tenx_award' => true,
      'eci' => true,
      'bi' => true,
      'si' => true,
      'pi' => true,
      'sp' => true
    ];

    foreach ($executiveGoalSet as $staffId) {
      $key = 'staff_' . $staffId;
      if (!isset($allExecutiveIncentives[$key])) {
        $status['tenx_award'] = false;
        $status['eci'] = false;
        $status['bi'] = false;
        $status['si'] = false;
        $status['pi'] = false;
        $status['sp'] = false;
        continue;
      }

      $data = $allExecutiveIncentives[$key];
      if (!$data['tenx_status']) $status['tenx_award'] = false;
      if (!$data['eci_status']) $status['eci'] = false;
      if (!$data['bi_status']) $status['bi'] = false;
      if (!$data['si_status']) $status['si'] = false;
      if (!$data['pi_status']) $status['pi'] = false;
      if (!$data['sp_status']) $status['sp'] = false;
    }

    return $status;
  }

  /**
   * Process Collection - Single Staff (EXACT same as original)
   */
  private function processCollectionSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDateold, $endDateold, $startDate, $endDate)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->pluck('za_customer.sno')
      ->toArray();

    // HAC Amount
    $hacAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->where('za_payment.status', 1)
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->where('za_payment.branch_id', $branchId)
      ->sum('za_payment.paidAmount');

    // Actual Month Customer Post
    $actualMonthCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno As training_id')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->whereIn('za_customer.status', [0, 6, 4])
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
    $isoutstandingRequired = $ten_x['no_of_outstanding_10x'] == "1";
    $isPostsaleRequired = $ten_x['no_of_post_sale_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Harvesting Amount";
    } elseif ($isoutstandingRequired) {
      $targetTenx = $goalsetData[$staffId]->student_count ?? 0;
      $actaulTenx = $goalsetData[$staffId]->student_count_actual ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Outstanding Count";
    } elseif ($isPostsaleRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_post_sale ?? 0;
      $actaulTenx = $actualMonthCustomerPost ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Post Sale Count";
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // EI Calculation
    $EIaward = 0;
    $EIStatus = false;
    $targetEI = 0;
    $actaulEI = 0;

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;

      if ($tenxStatus && ($incentive->excess_incentive ?? 0) > 0) {
        $excessAmount = $actaulTenx - $targetTenx;
        if ($excessAmount > 0) {
          $targetEI = $incentive->excess_incentive . '%';
          $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
          $EIaward = $actaulEI;
          $EIStatus = true;
        }
      }
    }

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $tenxTolltip . '">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCollectionModal(' . $staffId . ')" >Details</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'EI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetEI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . number_format($actaulEI, 2) . '</span>',
          'status' => $EIStatus,
          'reward' => number_format($EIaward, 2),
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
      ]
    ];
  }

  /**
   * Process CRE - Single Staff (EXACT same as original)
   */
  private function processCRESingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Review Count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staffId)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = $ten_x['no_of_reviews_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_reviews ?? 0;
      $actaulTenx = $review_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        '10X Warrior' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staffId . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
          'status' => $tenxStatus && $incentive->tenx_warrior,
          'reward' => ($tenxStatus && $incentive->tenx_warrior) ? ($incentive->tenx_warrior_reward ?? 0) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
      ]
    ];
  }

  /**
   * Process Production - Single Staff (EXACT same as original)
   */
  private function processProductionSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {
    $staffId = $staff->staff_id;

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->staff_id)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->staff_id],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

    // PDI Slabs
    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
    $studentCount = $staffproduction->student_count ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($slabs as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->where('branch_id', $branchId)
      ->where('referral_id', $staffId)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    $costing_amount_asign = $goalsetData[$staffId]->production_costing ?? 0;
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
    $isStudentMinRequired = $ten_x['min_no_of_students_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isProductionCostingRequired) {
      $targetTenx = $goalsetData[$staffId]->production_costing ?? 0;
      $actaulTenx = $costing_amount;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Production Costing";
    } elseif ($isStudentMinRequired) {
      $targetTenx = $goalsetData[$staffId]->min_no_of_students ?? 0;
      $actaulTenx = $goalsetData[$staffId]->min_no_of_students_actual ?? $staffproduction->student_count;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Min No. of Students Handling";
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Reference Sales Count";
    }

    // PDI
    $pdiReward = $slabPercentage;
    $pdiStatus = $tenxStatus && $pdiReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $tenxTolltip . '">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . round($actaulTenx) . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($slabPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process PC - Single Staff (EXACT same as original)
   */
  private function processPCSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {
    $staffId = $staff->staff_id;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->staff_id)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->staff_id],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->staff_id)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    $costing_amount_asign = $goalsetData[$staffId]->production_costing ?? 0;
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isProductionCostingRequired) {
      $targetTenx = $costing_amount_asign ?? 0;
      $actaulTenx = $costing_amount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . round($actaulTenx) . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => $REIStatus,
          'reward' => $REIStatus ? ($REIaward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process Placement Executive - Single Staff (EXACT same as original)
   */
  private function processPlacementExSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIE Slab
    $pie_slab_json = json_decode($incentive->pie_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pie_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // OIE Slab
    $oie_slab_json = json_decode($incentive->oie_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oie_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
        'Others' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlabOi ? $matchedSlabOi . ' = ' . round($slabPercentageOi, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentageOi, 2) . '</span>',
          'status' => $otherStatus,
          'reward' => $tenxStatus && $OthersReward ? round($OthersReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process Placement Lead - Single Staff (EXACT same as original)
   */
  private function processPlacementLeadSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
    $staffId = $staff->staff_id;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData[$staffId]->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData[$staffId]->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIL Slab
    $pil_slab_json = json_decode($incentive->pil_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pil_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Double X Slab
    $double_x_slab_json = json_decode($incentive->double_x_slab_json ?? '[]', true);
    $matchedX = null;
    $slabPercentageX = 0;
    $DoubleReward = 0;

    $multiplier = $targetTenx > 0 ? floor($tesboCount / $targetTenx) : 0;

    foreach ($double_x_slab_json as $slab) {
      if ($multiplier >= $slab['min'] && $multiplier <= $slab['max']) {
        if ($multiplier == 2) {
          $matchedX = 'Double X';
        } elseif ($multiplier == 3) {
          $matchedX = 'Triple X';
        } else {
          $matchedX = $multiplier . 'X';
        }
        $slabPercentageX = $slab['percentage'];
        $DoubleReward = $slabPercentageX;
        break;
      }
    }

    // OIL Slab
    $oil_slab_json = json_decode($incentive->oil_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oil_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $DoubleStatus = $tenxStatus && $DoubleReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        '10X Award' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulTenx . '</span>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],
        'PDI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentage, 2) . '</span>',
          'status' => $pdiStatus,
          'reward' => $tenxStatus && $pdiReward ? round($pdiReward) : 0,
        ],
        'REI' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . $actaulREI . '</span>',
          'status' => ($tenxStatus && $REIStatus) ? ($REIStatus ?? false) : false,
          'reward' => $REIaward ?? 0,
        ],
        'Double or Triple X' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedX ? $matchedX . ' = ' . round($slabPercentageX, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($slabPercentageX, 2) . '</span>',
          'status' => $DoubleStatus,
          'reward' => $tenxStatus && $DoubleReward ? round($DoubleReward) : 0,
        ],
        'Others' => [
          'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($matchedSlabOi ? $matchedSlabOi . ' = ' . round($piPercentageOi, 2) : 'No Matching Slab') . '</span>',
          'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . round($piPercentageOi, 2) . '</span>',
          'status' => $otherStatus,
          'reward' => $tenxStatus && $OthersReward ? round($OthersReward) : 0,
        ],
      ]
    ];
  }

  /**
   * Process BDM - Single Staff (EXACT same as original but simplified for single staff)
   */
  private function processBDMSingle($staff, $incentive, $checkRecord, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDate, $endDate, $startDateold, $endDateold, $prevMonth, $prevYear, $dates, $startOfMonth, $endOfMonth)
  {
    $staffId = $staff->staff_id;

    // Targets
    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
      ->whereMonth('branch_target.date', $month)
      ->whereYear('branch_target.date', $year)
      ->select('branch_target.*')
      ->first();

    $pregoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $postgoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $financialYear = (int)$year;
    if ($month >= 1 && $month <= 3) {
      $financialYear = $financialYear - 1;
    }

    $fyStart = Carbon::create($financialYear, 4, 1)->startOfDay();
    $fyEnd = Carbon::create($financialYear + 1, 3, 31)->endOfDay();

    $yearlyTargets = ManageTargetModel::query()
      ->where('branch_target.branch_id', $branchId)
      ->whereBetween('branch_target.date', [$fyStart, $fyEnd])
      ->selectRaw("
              SUM(no_of_registrations) as total_pre_target,
              SUM(post_sale) as total_post_target
          ")
      ->first();

    $yearlyPreTarget = (int) ($yearlyTargets->total_pre_target ?? 0);
    $yearlyPostTarget = (int) ($yearlyTargets->total_post_target ?? 0);

    $target_collection = $targets->monthly_target ?? 0;
    $target_pre = $targets->no_of_registrations ?? 0;
    $target_post = $targets->post_sale ?? 0;
    $targetPreABV = $pregoalsetteam ? $pregoalsetteam->abv_over_all : 0;
    $targetPreACV = $pregoalsetteam ? $pregoalsetteam->acv_over_all : 0;
    $targetPostABV = $postgoalsetteam ? $postgoalsetteam->abv_over_all : 0;
    $targetPostACV = $postgoalsetteam ? $postgoalsetteam->acv_over_all : 0;

    // Total Credit
    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    // For single staff BDM, we don't filter by staff_id in customer queries
    // since BDM is branch-level

    // Previous Month Converted Customers (all staff)
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    // Presale Count
    $presaleCount = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->count();

    // Post Sale Count
    $postSaleCount = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->count('za_training.sno');

    // Presale Customers
    $presaleCustomers = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->pluck('customer_id')
      ->toArray();

    // Postsale Customers
    $postsaleCustomers = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->pluck('za_training.sno')
      ->toArray();

    // ECI Counts
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', '!=', 1)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->count();

    $eciCustomerConvertCountPost = DB::table('za_customer')
      ->select('za_customer.sno', 'za_customer.proposal_ids', 'za_customer.cus_name')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.status', 0)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_customer.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->whereNotIn('za_training.status', [0, 1, 2])
      ->where('za_training.status', 0)
      ->orderBy('za_training.sno', 'asc')
      ->whereDay('za_training.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->distinct('za_customer.sno')
      ->count();

    // Team Targets (for BDM - all sales staff)
    $teamTargets = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
      ->join('za_staff', 'za_staff.sno', '=', 'za_goal_set_staff.staff_id')
      ->whereIn('za_staff.role_id', [11])
      ->where('za_staff.status', 0)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->select(
        'za_goal_set_staff.staff_id',
        'za_goal_set_staff.conversion',
        'za_staff.role_id',
        'za_staff.staff_name'
      )
      ->distinct('za_staff.sno')
      ->get();

    // Pre and Post Actuals
    $preActuals = CustomerModel::where('branch_id', $branchId)
      ->whereIn('status', [0, 6])
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->groupBy('lead_id')
      ->select('lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    $postActuals = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->groupBy('za_customer.lead_id')
      ->select('za_customer.lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    // Yearly Pre Actual
    $yearlyPreActualOriginal = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_transaction', 'za_transaction.trans_source_id', '=', 'za_customer.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereBetween('za_transaction.transaction_date', [$fyStart, $fyEnd])
      ->orderBy('za_customer.sno', 'asc')
      ->count();

    $lowMbcCustomerIdsYear = $badCustomerIds;
    $badCustomerIdsYear = array_unique($lowMbcCustomerIdsYear);
    $yearlyPreActual = max(0, $yearlyPreActualOriginal - count($badCustomerIdsYear));

    // Yearly Post Actual
    $yearlyPostActualOriginal = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereBetween('za_training.created_at', [$fyStart, $fyEnd])
      ->count();

    $yearlyPostActual = max(0, $yearlyPostActualOriginal - count($badCustomerIdsYear));

    // Yearly Achievements
    $yearlyPreAchievement = 0;
    if ($yearlyPreTarget > 0) {
      $yearlyPreAchievement = round(($yearlyPreActual / $yearlyPreTarget) * 100, 1);
    }

    $yearlyPostAchievement = 0;
    if ($yearlyPostTarget > 0) {
      $yearlyPostAchievement = round(($yearlyPostActual / $yearlyPostTarget) * 100, 1);
    }

    // Team Breakdown
    $teamTotalMembers = 0;
    $teamAchievedMembers = 0;
    $teamBreakdown = [];
    $preTotal = 0;
    $preAchieved = 0;

    foreach ($teamTargets as $target) {
      $teamTotalMembers++;
      $actual = 0;

      if ($target->role_id == 11) {
        $actual = $preActuals[$target->staff_id] ?? 0;
      }

      if ($target->role_id == 35) {
        $actual = $postActuals[$target->staff_id] ?? 0;
      }

      $achieved = $target->conversion > 0 && $actual >= $target->conversion;

      if ($achieved) {
        $teamAchievedMembers++;
        if ($target->role_id == 11) {
          $preAchieved++;
        }
      }

      if ($target->role_id == 11) {
        $preTotal++;
      }

      $teamBreakdown[] = [
        'staff_name' => $target->staff_name,
        'role_id' => $target->role_id,
        'target' => $target->conversion,
        'actual' => $actual,
        'status' => $achieved,
      ];
    }

    $teamAchievementStatus = $teamTotalMembers > 0 && $teamAchievedMembers === $teamTotalMembers;
    $teamAchievementReward = $teamAchievementStatus ? ($incentive->team_target ?? 0) : 0;

    // TenX Monthly Status
    $fyStartYear = $financialYear;
    $currentMonth = now()->month;
    $currentYear = now()->year;
    $achievedMonths = 0;
    $monthIcons = '';

    for ($i = 0; $i < 12; $i++) {
      $date = Carbon::create($fyStartYear, 4, 1)->addMonths($i);
      $m = $date->month;
      $y = $date->year;
      $label = $date->format('M');

      if ($y > $currentYear || ($y == $currentYear && $m > $currentMonth)) {
        $status = 'upcoming';
      } elseif ($y == $currentYear && $m == $currentMonth) {
        $status = 'progress';
      } else {
        $actualPre = CustomerModel::whereIn('status', [0, 6])
          ->where('post_sale_check', '!=', 1)
          ->where('branch_id', $branchId)
          ->whereYear('created_at', $y)
          ->whereMonth('created_at', $m)
          ->whereNotIn('sno', $badCustomerIds)
          ->count();

        if ($target_pre > 0 && $target_post > 0 && $actualPre >= $target_pre) {
          $status = 'achieved';
          $achievedMonths++;
        } else {
          $status = 'failed';
        }
      }

      $icon = '';
      switch ($status) {
        case 'achieved':
          $icon = '<div class="text-center"><span class="badge bg-label-success rounded"><i class="mdi mdi-check-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'failed':
          $icon = '<div class="text-center"><span class="badge bg-label-danger rounded"><i class="mdi mdi-close-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'progress':
          $icon = '<div class="text-center"><span class="badge bg-label-info rounded"><i class="mdi mdi-timer-sand fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        default:
          $icon = '<div class="text-center"><span class="badge bg-label-secondary rounded"><i class="mdi mdi-clock-outline fs-7"></i></span><div>' . $label . '</div></div>';
      }
      $monthIcons .= $icon;
    }

    $nineMonthStatus = $achievedMonths >= 9;
    $nineMonthReward = $incentive->nine_monthadd ?? '-';

    // Actual ABV and ACV Calculations
    $actualABV = 0;
    $actualACV = 0;
    $actualABVPost = 0;
    $actualACVPost = 0;

    if (!empty($presaleCustomers)) {
      $presaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_customer.customer_id', $presaleCustomers)
        ->whereNotIn('za_customer.sno', $badCustomerIds)
        ->sum('za_training.overall_fees');

      $presaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('trans_source_id', $presaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABV = ($presaleCount > 0) ? $presaleTotalOverallFees / $presaleCount : 0;
      $actualACV = ($presaleCount > 0) ? $presaleTotalCredit / $presaleCount : 0;
    }

    if (!empty($postsaleCustomers)) {
      $postsaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_training.sno', $postsaleCustomers)
        ->sum('za_training.overall_fees');

      $postsaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('training_id', $postsaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABVPost = ($postSaleCount > 0) ? $postsaleTotalOverallFees / $postSaleCount : 0;
      $actualACVPost = ($postSaleCount > 0) ? $postsaleTotalCredit / $postSaleCount : 0;
    }

    // TenX Status
    $tenxStatus = (
      $target_collection > 0 && $target_pre > 0 && $target_post > 0 &&
      $targetPreABV > 0 && $targetPreACV > 0 && $targetPostABV > 0 && $targetPostACV > 0 &&
      $totalCredit >= $target_collection &&
      $presaleCount >= $target_pre &&
      $postSaleCount >= $target_post &&
      $actualABV >= $targetPreABV &&
      $actualACV >= $targetPreACV &&
      $actualABVPost >= $targetPostABV &&
      $actualACVPost >= $targetPostACV
    );

    // ECI Logic
    $totalTarget = ($target_pre ?? 0) + ($target_post ?? 0);
    $totalConversion15 = ($eciCustomerConvertCount ?? 0) + ($eciCustomerConvertCountPost ?? 0);
    $eciAchievement15 = 0;
    if ($totalTarget > 0) {
      $eciAchievement15 = round(($totalConversion15 / $totalTarget) * 100, 1);
    }

    $slabs = json_decode($incentive->closing_slab_json ?? '[]', true);
    $eciStatus = false;
    $eciReward = 0;
    $eciRewardType = '';

    if (!empty($slabs)) {
      usort($slabs, function ($a, $b) {
        return $b['max'] <=> $a['max'];
      });

      foreach ($slabs as $slab) {
        if ($eciAchievement15 >= $slab['min'] && $eciAchievement15 <= $slab['max']) {
          $eciStatus = true;
          $eciReward = $slab['percentage'];
          $eciRewardType = $slab['max'] . 'th Achievement';
          break;
        }
      }
    }

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCountPre = max(0, $presaleCount - $target_pre);
    $biRewardPre = $biAchievedCountPre * $biPerConversion;
    $biAchievedCountPost = max(0, $postSaleCount - $target_post);
    $biRewardPost = $biAchievedCountPost * $biPerConversion;
    $biReward = $biRewardPre + $biRewardPost;
    $biStatus = ($biAchievedCountPre > 0 || $biAchievedCountPost > 0);

    // Double X
    $doublexTargetPre = ($target_pre * 2);
    $doublexTargetPost = ($target_post * 2);
    $doubleXStatus = (
      $doublexTargetPre > 0 && $doublexTargetPost > 0 &&
      $presaleCount >= $doublexTargetPre &&
      $postSaleCount >= $doublexTargetPost
    );
    $doubleXReward = $incentive->double_x_reward ?? 0;

    // ABV 150%
    $preABVAchievement = 0;
    if (($targetPreABV ?? 0) > 0) {
      $preABVAchievement = round((($actualABV ?? 0) / $targetPreABV) * 100, 1);
    }

    $postABVAchievement = 0;
    if (($targetPostABV ?? 0) > 0) {
      $postABVAchievement = round((($actualABVPost ?? 0) / $targetPostABV) * 100, 1);
    }

    $abvStatus = $preABVAchievement >= 150 && $postABVAchievement >= 150;
    $abvReward = ($tenxStatus && $abvStatus) ? ($incentive->abv_incentive ?? 0) : 0;

    // Yearly 150%
    $yearly150Status = $yearlyPreAchievement >= 150 && $yearlyPostAchievement >= 150;
    $yearly150Reward = $yearly150Status ? ($incentive->yearly_count ?? 0) : 0;

    // Get criteria data
    $criteriaKeys = [
      '10x_award',
      'acv_abv',
      'team_target',
      'closing',
      'add_incentive',
      'double_x_bdm',
      'abv',
      'yearly_count',
      'any_nine_month'
    ];

    $criteriaData = [];
    foreach ($criteriaKeys as $key) {
      $criteria = IncentiveCriteriaModel::where([
        'incentive_key' => $key,
        'role_id' => $staff->role_id,
        'branch_id' => $branchId,
      ])->first();

      $criteriaData[$key] = $criteria ? json_decode($criteria->criteria_points, true) : [];
    }

    return [
      'staff_id' => $staff->staff_id,
      'staff_name' => $staff->staff_name,
      'staff_image' => $staff->staff_image,
      'branch_name' => $staff->branch_name,
      'bh_signature' => $staff->cert_auth_sign ?? '1755151615_2.png',
      'role_id' => $staff->role_id,
      'nick_name' => $staff->nick_name,
      'sub_department_name' => $staff->sub_department_name,
      'department_name' => $staff->department_name,
      'incentives' => [
        'tenx_award' => [
          'target' => [
            'Pre Sale' => $target_pre,
            'Post Sale' => $target_post,
            'Pre ABV' => $targetPreABV,
            'Pre ACV' => $targetPreACV,
            'Post ABV' => $targetPostABV,
            'Post ACV' => $targetPostACV,
          ],
          'actual' => [
            'Pre Sale' => $presaleCount,
            'Post Sale' => $postSaleCount,
            'Pre ABV' => round($actualABV),
            'Pre ACV' => round($actualACV),
            'Post ABV' => round($actualABVPost),
            'Post ACV' => round($actualACVPost),
          ],
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
          'incentive_reward' => $incentive->tenx_award ?? 1000,
          'reward_type' => 'amount',
          'rules' => $criteriaData['10x_award'] ?? [],
        ],
        'abv_incentive' => [
          'target' => 'Pre Target: ' . number_format($targetPreABV) . ' | Post Target: ' . number_format($targetPostABV),
          'actual' => 'Pre: ' . number_format($actualABV) . ' | Post: ' . number_format($actualABVPost),
          'status' => $tenxStatus && $abvStatus,
          'reward' => $tenxStatus && $abvStatus ? $abvReward : 0,
          'incentive_reward' => $incentive->abv_incentive ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['abv_incentive'] ?? [],
        ],
        'team_achievement_incentive' => [
          'target' => 'Team: ' . $teamTotalMembers . ' | Pre: ' . $preTotal,
          'actual' => 'Pre: ' . $preAchieved . '/' . $preTotal,
          'status' => $tenxStatus && $teamAchievementStatus,
          'reward' => $tenxStatus && $teamAchievementStatus ? $teamAchievementReward : 0,
          'incentive_reward' => $incentive->team_target ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['team_target'] ?? [],
        ],
        'eci' => [
          'target' => $incentive->eci_count ?? 0 . '% | Total: ' . $totalTarget,
          'actual' => '15th: ' . $eciAchievement15 . '% | ' . $eciRewardType,
          'status' => $tenxStatus && $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? $eciReward : 0,
          'incentive_reward' => 5000,
          'reward_type' => 'amount',
          'rules' => $criteriaData['closing'] ?? [],
        ],
        'bi' => [
          'target' => 'Pre: ' . ($target_pre - $presaleCount) . ' | Post: ' . ($target_post - $postSaleCount),
          'actual' => 'Pre: ' . $biAchievedCountPre . ' × ' . $biPerConversion . ' | Post: ' . $biAchievedCountPost . ' × ' . $biPerConversion,
          'status' => $tenxStatus && $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
          'incentive_reward' => $incentive->add_incentive ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['add_incentive'] ?? [],
        ],
        'doublex' => [
          'target' => '2X Pre: ' . $doublexTargetPre . ' | 2X Post: ' . $doublexTargetPost,
          'actual' => 'Pre: ' . $presaleCount . ' | Post: ' . $postSaleCount,
          'status' => $tenxStatus && $doubleXStatus,
          'reward' => ($tenxStatus && $doubleXStatus) ? $doubleXReward : 0,
          'incentive_reward' => $incentive->double_x_bdm ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['double_x_bdm'] ?? [],
        ],
        'abv_150_incentive' => [
          'target' => 'Required: 150% | Pre: ' . number_format($targetPreABV) . ' | Post: ' . number_format($targetPostABV),
          'actual' => 'Pre: ' . number_format($actualABV) . ' (' . $preABVAchievement . '%) | Post: ' . number_format($actualABVPost) . ' (' . $postABVAchievement . '%)',
          'status' => $tenxStatus && $abvStatus,
          'reward' => ($tenxStatus && $abvStatus) ? $abvReward : 0,
          'incentive_reward' => $incentive->abv ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['abv'] ?? [],
        ],
        'yearly_150_incentive' => [
          'target' => 'Required: 150% | Pre: ' . round($yearlyPreTarget * 1.5) . ' | Post: ' . round($yearlyPostTarget * 1.5),
          'actual' => 'Pre: ' . $yearlyPreActual . ' (' . $yearlyPreAchievement . '%) | Post: ' . $yearlyPostActual . ' (' . $yearlyPostAchievement . '%)',
          'status' => $tenxStatus && $yearly150Status,
          'reward' => $tenxStatus && $yearly150Status ? $yearly150Reward : 0,
          'incentive_reward' => $incentive->yearly_count ?? 0,
          'reward_type' => 'amount',
          'rules' => $criteriaData['yearly_count'] ?? [],
        ],
        'nine_month_consistency_incentive' => [
          'target' => 'Required: 9 Months | Achieved: ' . $achievedMonths . '/9',
          'actual' => $monthIcons,
          'status' => ($tenxStatus && $nineMonthStatus),
          'reward' => $tenxStatus && $nineMonthStatus ? $nineMonthReward : '-',
          'incentive_reward' => $incentive->any_nine_month ?? 0,
          'reward_type' => 'gift',
          'rules' => $criteriaData['any_nine_month'] ?? [],
        ],
      ]
    ];
  }

  //single my incentive get end


  public function getConvertedCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    // Convert month name or number into intege
    $month = is_numeric($monthRaw)
      ? (int)$monthRaw
      : (int)date('m', strtotime($monthRaw . ' 1'));

    // Previous month and year
    $currentMonthStart = Carbon::createFromDate($year, $month, 1);
    $prevMonthStart = $currentMonthStart->copy()->subMonth();
    $prevMonth = $prevMonthStart->month;
    $prevYear  = $prevMonthStart->year;

    // 1. Get all converted customers this month (for detailed listing)
    $customerConvertThisMonth = CustomerModel::select('za_customer.sno', 'za_customer.cus_name', 'za_customer.created_at', 'za_customer.cus_mobile')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    // 1a. For current month low MBC checks only take records from 1st to 25th
    // (Assuming your DB supports the DAY() function; adjust if needed)
    $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->pluck('za_customer.sno')
      ->toArray();

    // 2. Get previous month converted customers (with staff details)
    $prevMonthCustomerIdscus = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.created_at',
      'za_customer.cus_mobile',
      'za_staff.staff_name',
      'za_staff.staff_image',
      'za_department.department_name'
    )
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->get();

    // 3. Get previous month converted customer IDs (for further checks)
    $prevMonthCustomerIds = CustomerModel::whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // 4. First Condition: Dropout for previous month
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthCustomerIds)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();
    // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthCustomerIds)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();
    // return $fullPaidCustomerIds;
    // 2. Customers who made a second payment this month
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthCustomerIds)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->toArray();
    //  return $secondPaymentCustomersmulti;


    $secondPaymentCustomers =   array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));
    // return $secondPaymentCustomers;

    // return or use $secondPaymentCustomers


    // 6. Third Condition: Low MBC (min amount not paid) for previous month
    $branch = BranchModel::where('sno', $branchId)->first();
    $dropRefundedIds = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->pluck('za_training.customer_id')
      ->toArray();

    $lowMbcCustomerIds = DB::table('za_training')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->whereIn('za_training.customer_id', $prevMonthCustomerIds)
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_training.customer_id', $dropRefundedIds)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      // ->whereRaw('DAY(za_customer.created_at) <= 25')
      ->groupBy('za_training.customer_id')
      ->havingRaw("SUM(za_training.paid_amount) < ?", [$branch->min_prd_cost ?? 0])
      ->pluck('za_training.customer_id')
      ->toArray();
    // return $lowMbcCustomerIds;

    // 7. Combine all failed (bad) customers for previous month
    $badCustomerIdsPrev = array_unique(array_merge(
      $dropoutCustomers,
      array_diff($prevMonthCustomerIds, $secondPaymentCustomers),
      $lowMbcCustomerIds
    ));

    // Now, for current month details: Using low MBC check for 1st to 25th only.
    // a. Dropout in current month (based on current-customer IDs filtered above)
    $dropoutCustomersCurrent = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthCustomerIdsCurrent)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // b. Low MBC in current month (add the day limitation in the customer join above)
    $lowMbcCustomerIdsCurrent = DB::table('za_training')
      // ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->whereIn('za_training.customer_id', $prevMonthCustomerIdsCurrent)
      // ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_training.customer_id', $dropoutCustomersCurrent)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->whereRaw('DAY(za_training.created_at) <= 25')
      ->groupBy('za_training.customer_id')
      ->havingRaw("SUM(za_training.paid_amount) < ?", [$branch->min_prd_cost])
      ->pluck('za_training.customer_id')
      ->toArray();
    // return $lowMbcCustomerIdsCurrent;
    $lowMbcCustomerIdspay = DB::table('za_training')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->whereIn('za_training.customer_id', $prevMonthCustomerIdsCurrent)
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_training.customer_id', $dropRefundedIds)
      ->where('za_training.status', '!=', 2)
      ->select(
        'za_training.customer_id',
        DB::raw('SUM(DISTINCT za_training.paid_amount) as total_paid_amount')
      )
      ->groupBy('za_training.customer_id')
      ->get()
      ->keyBy('customer_id'); // ← keep this as Collection, NOT array
    // return $lowMbcCustomerIdspay;

    // Combine current month bad customer IDs (only dropout and low MBC are considered)
    $badCustomerIdsCurrent = array_unique(array_merge(
      $dropoutCustomersCurrent,
      $lowMbcCustomerIdsCurrent
    ));

    // 8. Build the final list for previous month with status & reason
    $finalDataPrev = $prevMonthCustomerIdscus->map(function ($cus) use ($dropoutCustomers, $secondPaymentCustomers, $lowMbcCustomerIds) {
      $reason = null;
      // Default: converted (green tick)
      $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';

      if (in_array($cus->sno, $dropoutCustomers)) {
        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
        $reason = 'Dropout in previous month';
      } elseif (!in_array($cus->sno, $secondPaymentCustomers)) {
        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
        $reason = 'No second payment in current month';
      } elseif (in_array($cus->sno, $lowMbcCustomerIds)) {
        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
        $reason = 'Paid below low MBC';
      }

      return [
        'customer_name' => $cus->cus_name,
        'mobile'        => $cus->cus_mobile,
        'month'         => Carbon::parse($cus->created_at)->format('F Y'),
        'status'        => $status,
        'reason'        => $reason ?? 'Successfully Paid MPC And Second Payment',
        'staff_name'    => $cus->staff_name,
        'staff_image'   => $cus->staff_image,
        'department_name' => $cus->department_name,
      ];
    })->values();

    // 9. Build the final list for current month details with status & reason
    $finalDataCurrent = $customerConvertThisMonth->map(function ($cus) use ($dropoutCustomersCurrent, $lowMbcCustomerIdsCurrent, $lowMbcCustomerIdspay) {
      $reason = null;
      // Default status: converted
      $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';
      $amount = $lowMbcCustomerIdspay->get($cus->sno)?->total_paid_amount ?? 0;

      if (in_array($cus->sno, $dropoutCustomersCurrent)) {
        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';
        $reason = 'Dropout in current month';
      } elseif (in_array($cus->sno, $lowMbcCustomerIdsCurrent)) {
        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';
        $reason = 'Paid below low MBC (1st-25th day)';
      }

      return [
        'customer_name' => $cus->cus_name,
        'mobile'        => $cus->cus_mobile,
        'month'         => Carbon::parse($cus->created_at)->format('F Y'),
        'amount'        => $amount,
        'status'        => $status,
        'reason'        => $reason ?? 'Successfully Paid MPC Value'
      ];
    })->values();

    // 10. Build summary counts for display
    $prevMonthSummary = [
      'second_payment_total' => count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($dropoutCustomers) - count($lowMbcCustomerIds),
      'lmbc_total'           => count($lowMbcCustomerIds),
      'drop_count_total'     => count($dropoutCustomers),
      'converted_total'      => count($prevMonthCustomerIds)
    ];


    $minuscustold =  count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($lowMbcCustomerIds) - count($dropoutCustomers);
    $minus_value =  $minuscustold + count($lowMbcCustomerIdsCurrent) + count($dropoutCustomersCurrent) + count($dropoutCustomers);
    $finalCustomer = count($prevMonthCustomerIdsCurrent) - $minus_value;
    $currentMonthSummary = [
      'minus_value'             => $minus_value,
      'final_value'             => $finalCustomer > 0 ? $finalCustomer : 0,
      'lmbc_total_current'   => count($lowMbcCustomerIdsCurrent),
      'drop_count_current'   => count($dropoutCustomersCurrent),
      'converted_total_current' => count($prevMonthCustomerIdsCurrent)
    ];

    return response()->json([
      'data_prev'       => $finalDataPrev,
      'data_current'    => $finalDataCurrent,
      'summary_prev'    => $prevMonthSummary,
      'summary_current' => $currentMonthSummary,
    ]);
  }

  public function getcalculationCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
      ? (int) $monthRaw
      : (int) date('m', strtotime($monthRaw . ' 1'));

    $prevDate = Carbon::createFromDate($year, $month, 1)->subMonth();
    $prevMonth = $prevDate->month;
    $prevYear  = $prevDate->year;

    $pi_slabs = [
      ['min' => 0, 'max' => 10, 'percentage' => 5],
      ['min' => 10, 'max' => 20, 'percentage' => 10],
      ['min' => 20, 'max' => 1000, 'percentage' => 15],
    ];

    $data = [];

    $prevMonthCustomerIdscus = CustomerModel::select('za_customer.sno', 'za_customer.cus_name', 'za_customer.created_at', 'za_customer.cus_mobile', 'za_staff.staff_name', 'za_staff.staff_image', 'za_department.department_name')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();
    $globalIndex = 1;

    foreach ($prevMonthCustomerIdscus as  $customer) {


      $trainings = DB::table('za_training as t1')
        ->join(DB::raw('(
                    SELECT MIN(sno) as min_sno
                    FROM za_training
                    WHERE post_sale_check = 0
                    GROUP BY customer_id
                ) as t2'), 't1.sno', '=', 't2.min_sno')
        ->where('t1.customer_id', $customer->sno)
        ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
        ->get();


      foreach ($trainings as $training) {
        // Determine course_id based on tesbo_check
        $course_id = null;

        if ($training->tesbo_check > 0) {
          $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
          if ($payment && $payment->course_id) {
            $course_id = $payment->course_id;
          }
        } else {
          $course_id = $training->course_id;
        }

        if (!$course_id) continue; // Skip if no course_id

        $course = ManageCoursesModel::where('sno', $course_id)
          ->whereIn('course_type_id', [2, 3])
          ->first();

        if (!$course) continue;

        $basePrice = $course->course_min_price;
        $soldPrice = $training->overall_fees;
        $profitAmount = $soldPrice - $basePrice;

        // Calculate confirmed amount only if there's profit
        $confirmAmount = 0;
        if ($profitAmount > 0) {
          $profitPercent = ($profitAmount / $basePrice) * 100;
          foreach ($pi_slabs as $slab) {
            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
              $confirmAmount = ($profitAmount * $slab['percentage']) / 100;
              break;
            }
          }
        }

        $data[] = [
          'sno'                 => $globalIndex++,
          'customer_name'       => $customer->cus_name,
          'mobile'              => $customer->cus_mobile,
          'month'               => Carbon::parse($customer->created_at)->format('F Y'),
          'course_name'         => $course->course_name,
          'original_amount'     => number_format($basePrice, 2),
          'confirm_amount'      => number_format($soldPrice, 2),
          'profit_loss_amount'  => ($profitAmount >= 0 ? '+' : '-') . number_format(abs($profitAmount), 2),
          'staff_name'          => $customer->staff_name,
          'staff_image'         => $customer->staff_image,
          'department_name'     => $customer->department_name,
        ];
      }
    }

    return response()->json(['data' => $data]);
  }

  public function geteciCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
      ? (int) $monthRaw
      : (int) date('m', strtotime($monthRaw . ' 1'));

    // Define the 1st to 15th range of the selected month/year
    $now = Carbon::createFromDate($year, $month, 1);
    $startOfMonth = $now->copy()->startOfMonth();
    $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th

    $customers = CustomerModel::select('za_customer.sno', 'za_customer.cus_name', 'za_customer.created_at', 'za_customer.cus_mobile', 'za_staff.staff_name', 'za_staff.staff_image', 'za_department.department_name')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    $data = [];
    foreach ($customers as $index => $cus) {
      // Fetch course
      $course = DB::table('za_training')
        ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->where('za_training.customer_id', $cus->sno)
        ->select('za_course.course_name')
        ->first();

      $data[] = [
        'sno'         => $index + 1,
        'name'        => $cus->cus_name,
        'mobile'        => $cus->cus_mobile,
        'course'      => $course->course_name ?? '--',
        'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
        'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
          ? 'Converted'
          : 'Eligible', // you can change this dynamically
        'staff_name'      => $cus->staff_name,
        'staff_image'     => $cus->staff_image,
        'department_name' => $cus->department_name,
      ];
    }

    return response()->json(['data' => $data]);
  }

  public function getCallCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
      ? (int) $monthRaw
      : (int) date('m', strtotime($monthRaw . ' 1'));

    $now = Carbon::createFromDate($year, $month, 1);
    $startOfMonth = $now->copy()->startOfMonth();
    $middleOfMonth = $now->copy()->startOfMonth()->addDays(14);
    $endOfMonth = $now->copy()->endOfMonth(); // 🔧 FIXED
    $incentive = IncentiveModel::where('role_id', 11)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->first();


    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereBetween(DB::raw('DATE(za_customer.created_at)'), [$startOfMonth, $endOfMonth])
      ->select(
        'za_customer.sno',
        'za_lead.lead_mobile',
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.created_at',
        'za_staff.staff_name',
        'za_staff.staff_image',
        'za_department.department_name'
      )
      ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    $data = [];

    foreach ($allConverted as $index => $row) {
      $mobile = $row->lead_mobile;

      // Get the latest call
      $lastCall = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->orderByDesc('call_start_date')
        ->first();

      $totalCallCount = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->count();
      $totalCalldata = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->select(
          'za_call_tracker.call_start_date'
        )
        ->get();

      //   return  $totalCalldata;
      // Date parsing
      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate     = Carbon::parse($row->lead_created_at)->format('Y-m-d');
      $callDate     = $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null;

      $convertedOnDay = $customerDate === $leadDate && $totalCallCount === 1;

      $convertedInMonth = !$convertedOnDay && // only if not already on-day
        $customerDate >= $startOfMonth->format('Y-m-d') &&
        $customerDate <= $endOfMonth->format('Y-m-d') &&
        $leadDate >= $startOfMonth->format('Y-m-d') &&
        $leadDate <= $endOfMonth->format('Y-m-d') &&
        $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
          $callDate = Carbon::parse($call->call_start_date);
          return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
        });

      $convertedOld = !$convertedOnDay && !$convertedInMonth && // only if not on-day or in-month
        $customerDate >= $startOfMonth->format('Y-m-d') &&
        $customerDate <= $endOfMonth->format('Y-m-d') &&
        ($leadDate < $startOfMonth->format('Y-m-d') && $totalCallCount > 1 || $leadDate > $endOfMonth->format('Y-m-d'));

      $otherstaffConvert = !$convertedOnDay && !$convertedInMonth && !$convertedOld && $totalCallCount === 0;



      $statusTick = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';
      $statusWrong = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';

      $spotIncentiveDayAmount = $convertedOnDay ? ($incentive->spot_incentive_day ?? 0) : 0;
      $spotIncentiveMonthAmount = $convertedInMonth ? ($incentive->spot_incentive_month ?? 0) : 0;

      $totalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

      $data[] = [
        'sno' => $index + 1,
        'name' => $row->cus_name,
        'mobile' => $row->cus_mobile,
        'totalCallCount' => $totalCallCount,
        'created_at' => Carbon::parse($row->customer_created_at)->format('d-M-Y'),
        'lead_created_at' => Carbon::parse($row->lead_created_at)->format('d-M-Y'),
        'call_start_date' => $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null,
        'on_day' => $convertedOnDay ? $statusTick : $statusWrong,
        'on_month' => $convertedInMonth ? $statusTick : $statusWrong,
        'old_month' => $convertedOld ? $statusTick : $statusWrong,
        'otherstaff' => $otherstaffConvert,
        'Rewards' => $spotIncentiveDayAmount + $spotIncentiveMonthAmount,
        'staff_name' => $row->staff_name,
        'staff_image' => $row->staff_image,
        'department_name' => $row->department_name
      ];
    }

    return response()->json([
      'data' => $data,
      'summary' => [
        'on_day' => $convertedToday,
        'on_month' => $convertedMonth,
        'old_month' => $convertedOldMonth
      ]
    ]);
  }

  public function getCollectionCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
      ? (int)$monthRaw
      : (int)date('m', strtotime($monthRaw . ' 1'));

    $currentMonthStart = Carbon::createFromDate($year, $month, 1);
    $nextMonthStart = $currentMonthStart->copy()->addMonth();

    $current = Carbon::create($year, $month, 1);
    // 20 years ago from now
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
    $staff = StaffModel::where('sno', $staffId)->first();


    $currentMonthStart = Carbon::create($year, $month, 1)->startOfMonth();
    $currentMonthEnd = Carbon::create($year, $month, 1)->endOfMonth();
    $dropoutCustomers = DB::table('za_training')
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->pluck('za_customer.sno')
      ->toArray();

    // ✅ 2. Get old month collection (scheduled earlier, paid now)
    $oldMonthCollection = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->whereNotBetween('za_customer.created_at', [$currentMonthStart, $currentMonthEnd])
      ->where('za_payment.status', 1)
      ->where('za_customer.status', 0)
      ->where('za_payment.paidAmount', '>', 0)
      ->where('za_payment.nextPayDate', '<', $currentMonthStart)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->whereYear('za_payment.initialPayDate', $year)
      ->select('za_customer.cus_name', 'za_payment.paidAmount', 'za_payment.initialPayDate', 'za_payment.nextPayDate')
      ->get();

    // ✅ 3. Get current month collection (scheduled and paid now)
    $currentMonthCollection = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->whereNotBetween('za_customer.created_at', [$currentMonthStart, $currentMonthEnd])
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->where('za_payment.status', 1)
      ->where('za_customer.status', 0)
      ->where('za_payment.paidAmount', '>', 0)
      ->whereMonth('za_payment.nextPayDate', $month)
      ->whereYear('za_payment.nextPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->whereYear('za_payment.initialPayDate', $year)
      ->select('za_customer.cus_name', 'za_payment.paidAmount', 'za_payment.initialPayDate', 'za_payment.nextPayDate')
      ->get();


    // ✅ 4. Get future month collection (scheduled later, paid now)
    $futureMonthCollection = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->whereNotBetween('za_customer.created_at', [$currentMonthStart, $currentMonthEnd])
      ->where('za_payment.status', 1)
      ->where('za_customer.status', 0)
      ->where('za_payment.paidAmount', '>', 0)
      ->where('za_payment.nextPayDate', '>', $nextMonthStart)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->whereYear('za_payment.initialPayDate', $year)
      ->select('za_customer.cus_name', 'za_payment.paidAmount', 'za_payment.initialPayDate', 'za_payment.nextPayDate')
      ->get();

    // ✅ 5. Calculate totals
    $oldAmountTotal = $oldMonthCollection->sum('paidAmount');
    $currentAmountTotal = $currentMonthCollection->sum('paidAmount');
    $futureAmountTotal = $futureMonthCollection->sum('paidAmount');

    // Optional: You can calculate percentage based on targets if available

    $totalCollection = $oldAmountTotal + $currentAmountTotal + $futureAmountTotal;

    return response()->json([
      'staff' => $staff,

      'old_amount' => [
        'collection' => $oldAmountTotal,
        'percentage' => $totalCollection > 0 ? round(($oldAmountTotal / $totalCollection) * 100, 2) : 0,
        'customers'  => $oldMonthCollection,
      ],

      'current_amount' => [
        'collection' => $currentAmountTotal,
        'percentage' => $totalCollection > 0 ? round(($currentAmountTotal / $totalCollection) * 100, 2) : 0,
        'customers'  => $currentMonthCollection,
      ],

      'future_amount' => [
        'collection' => $futureAmountTotal,
        'percentage' => $totalCollection > 0 ? round(($futureAmountTotal / $totalCollection) * 100, 2) : 0,
        'customers'  => $futureMonthCollection,
      ],
    ]);
  }

  public function getCourseCustomers(Request $request)
  {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
      return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));

    $currentMonthStart = Carbon::createFromDate($year, $month, 1);
    $nextMonthStart = $currentMonthStart->copy()->addMonth();
    $staff = StaffModel::where('sno', $staffId)->first();

    $incentive = IncentiveModel::where('role_id', $staff->role_id)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $request->year)
      ->where('status', 0)
      ->first();
    // Course counts init
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;

    $tesboCustomers = collect();
    $crashCustomers = collect();
    $professionCustomers = collect();

    // Grouped Professional and Crash Courses
    $groupedData = DB::table('za_training')
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->select('za_course.course_type_id', DB::raw('COUNT(DISTINCT za_training.payment_id) AS total_trainings'))
      ->where('za_training.branch_id', $branchId)
      ->whereMonth('za_training.created_at', $month)
      ->whereYear('za_training.created_at', $year)
      ->whereIn('za_course.course_type_id', [3, 4])
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_training.status', 0)
      ->where('za_training.post_sale_check', '!=', 1)
      ->groupBy('za_course.course_type_id')
      ->get();

    $teshobo_coures_total = DB::table('za_training')
      ->where('branch_id', $branchId)
      ->whereMonth('created_at', $month)
      ->whereYear('created_at', $year)
      ->where('tesbo_check', 2)
      ->where('status', 0)
      ->where('post_sale_check', '!=', 1)
      ->distinct('payment_id')
      ->count('payment_id');

    $crash_coures_total = 0;
    $professinal_coures_total = 0;

    foreach ($groupedData as $row) {
      if ($row->course_type_id == 3) {
        $professinal_coures_total = (int)$row->total_trainings;
      } elseif ($row->course_type_id == 4) {
        $crash_coures_total = (int)$row->total_trainings;
      }
    }

    // All customers created this month by staff
    $currentMonthCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    foreach ($currentMonthCustomers as $customer) {
      // TESBO check
      $tesboData = DB::table('za_training')
        ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.customer_id', $customer->sno)
        ->where('za_training.branch_id', $branchId)
        ->whereMonth('za_training.created_at', $month)
        ->whereYear('za_training.created_at', $year)
        ->where('za_training.tesbo_check', 2)
        ->where('za_training.post_sale_check', '!=', 1)
        ->select('za_customer.cus_name', 'za_course.course_name', 'za_course.course_type_id')
        ->first();

      if ($tesboData) {
        $tesboCustomers->push($tesboData);
        $tesboCount++;
        continue;
      }

      // Professional or Crash
      $nonTesboTrainings = DB::table('za_training')
        ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.customer_id', $customer->sno)
        ->where('za_training.branch_id', $branchId)
        ->whereMonth('za_training.created_at', $month)
        ->whereYear('za_training.created_at', $year)
        ->where('za_training.tesbo_check', '!=', 2)
        ->where('za_training.post_sale_check', '!=', 1)
        ->whereIn('za_course.course_type_id', [3, 4])
        ->select('za_customer.cus_name', 'za_course.course_name', 'za_course.course_type_id')
        ->get();

      $hasCrash = false;
      $hasProfession = false;


      foreach ($nonTesboTrainings as $training) {
        if ($training->course_type_id == 3) {
          $professionCustomers->push($training);
          $professionCount++;
        } elseif ($training->course_type_id == 4) {
          $crashCustomers->push($training);
          $crashCount++;
        }
      }

      if ($hasCrash) $crashCount++;
      if ($hasProfession) $professionCount++;
    }



    $totalCustomers = max(1, $currentMonthCustomers->count()); // avoid division by 0

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalCustomers) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $totalCustomers) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalCustomers) * 100 : 0;

    return response()->json([
      'staff' => $staff,

      'crash_course' => [
        'percentage' => $crashPercent,
        'count' => $crashCount,
        'customers' => $crashCustomers,
      ],

      'professional_course' => [
        'percentage' => $professionPercent,
        'count' => $professionCount,
        'customers' => $professionCustomers,
      ],

      'tesbo_course' => [
        'percentage' => $tesboPercent,
        'count' => $tesboCount,
        'customers' => $tesboCustomers,
      ],
    ]);
  }
  
  /**
   * Get incentive data for floating bar
   */
  public function selfIncentiveFloatingBar(Request $request)
  {
    try {
      $user = $request->user();
      $branchId = $request->branch_id ?? $user->branch_id;
      $roleId = $user->role_id;
      $year = $request->year ?? date('Y');
      $month = $request->month ?? date('m');
      // $month = 3;
 
      // Get cached incentive data
      $incentiveData = IncentiveCacheService::getCachedIncentive(
        $user->user_id,
        $branchId,
        $roleId,
        $year,
        $month
      );
 
      return response()->json([
        'success' => true,
        'data' => $incentiveData,
        'message' => 'Incentive data retrieved successfully'
      ]);
    } catch (\Exception $e) {
 
      return response()->json([
        'success' => false,
        'data' => [
          'total_award' => 0,
          'error' => 'Unable to fetch incentive data',
          'user_id' => $request->user()->sno ?? null,
          'trace' => $e->getTraceAsString()
        ],
        'message' => 'Floating bar incentive error: ' . $e->getMessage()
      ], 500);
    }
  }
 
  /**
   * Force refresh cache
   */
  public function refreshIncentiveCache(Request $request)
  {
    try {
      $user = $request->user();
      $branchId = $request->branch_id ?? $user->branch_id;
      $year = $request->year ?? date('Y');
      $month = $request->month ?? date('m');
      // $month = 3;
 
      // Clear cache
      IncentiveCacheService::clearUserCache($user->sno, $branchId, $user->role_id, $year, $month);
 
      // Get fresh data
      $freshData = IncentiveCacheService::getCachedIncentive(
        $user->sno,
        $branchId,
        $user->role_id,
        $year,
        $month
      );
 
      return response()->json([
        'success' => true,
        'data' => $freshData,
        'message' => 'Cache refreshed successfully'
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => 'Error refreshing cache'
      ], 500);
    }
  }
 
  /**
   * Get detailed incentive breakdown (reuse your existing method)
   */
  public function getIncentiveDetails(Request $request)
  {
    // Call your existing getIncentiveMetrics method but filtered for single user
    return $this->getIncentiveMetrics($request);
  }
  
}
