<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel; 
use App\Models\DivisionModel; 
use App\Models\JobpositionModel; 
use App\Models\StaffModel; 
use App\Models\StaffAttendanceModel;
use App\Models\User; 
use App\Models\StaffWorkInfoModel; 
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\UserRolePermissionModel;
use App\Events\StaffExistUpdated;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\IncentiveModel;
use App\Models\CustomerModel;
use App\Models\BranchModel;
use App\Models\ManageTargetModel;

class WebhookReceiverController extends Controller
{

   public function broadcastMessage(Request $request)
        {
           
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }
 
                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);
 
                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
               
            $updateBroadcast = NewsBroadcastModel::updateOrCreate(
                ['external_uuid' => $payload['sno']],
                [
 
                    'template_name' => $payload['template_name'] ?? NULL,
                    'broadcast_message' => $payload['broadcast_message'] ?? NULL,
                    'branch_id' => $payload['branch_id'] ?? NULL,
                    'role_ids' => $payload['role_ids'] ?? NULL,
                    'start_date' => $payload['start_date'] ?? NULL,
                    'end_date' => $payload['end_date'] ?? NULL,
                    'information' => $payload['information'] ?? NULL,
                    'theme_id' => $payload['theme_id'] ?? 0,
                    'theme_style' => $payload['theme_style'] ?? NULL,
                    'created_by' => $request->user()->user_id ?? 0,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]
            );
 
           
 
            return response()->json([
                'ok' => true,
                'sno' => $updateBroadcast->sno,
            ], 200);
        }
    
   
    
    // Deparment Webhook Start
    public function DepartmentList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
       $departmentList=DB::table('et_department')
       ->select('et_department.*')
       ->where('et_department.entity_id',1)
       ->where('et_department.status',0)
       ->get();
       $lastId = DB::table('et_department')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function DepartmentHook(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $department = DepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],  
            [
                'department_id'    => $payload['department_id'] ?? null,
                'entity_id'        => 1,
                'branch_id'        =>  1,
                'department_name'  => $payload['department_name'],
                'department_desc'  => $payload['department_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'uuid' => $uuid,
        ], 200);
    }

    public function UpdateDepartmentUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_department_id'];
        if($erpId){
            $department = DepartmentModel::where('sno', $erpId)->first();

            if ($department) {
                $department->external_uuid = $uuid;
                $department->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'department Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'department id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }
    // Deparment Webhook End


    
     // Division Webhook Start
    public function DivisionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $depart_id = $request->department_id;
        // return $depart_id;
       $departmentList=DB::table('et_division')
       ->select('et_division.*');
       if($depart_id){
         $departmentList->where('et_division.department_id',$depart_id);
       }
       
       $departmentList=$departmentList->where('et_division.status',0)
       ->get();
       $lastId = DB::table('et_division')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

     public function DivisionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

        $department = DivisionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'department_id'    => $payload['erp_department_id'], 
                'entity_id'        => 1,
                'branch_id'        => 1,
                'division_name'  => $payload['division_name'],
                'division_desc'  => $payload['division_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

     public function UpdateDivisionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_division_id'];
        if($erpId){
            $division = DivisionModel::where('sno', $erpId)->first();

            if ($division) {
                $division->external_uuid = $uuid;
                $division->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Division Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Division id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $division->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

     // Division Webhook End

    // Job Position Webhook Start
    public function JobPostionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $division_id = $request->division_id;
        // return $depart_id;
       $departmentList=DB::table('et_job_position')
       ->select('et_job_position.*');
       if($division_id){
         $departmentList->where('et_job_position.division_id',$division_id);
       }
       $departmentList=$departmentList->where('et_job_position.status',0)
       ->get();
       $lastId = DB::table('et_job_position')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function JobPositionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();
         
         $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
    
              $year = substr(date("y"), -2);
              $job_position_id = "JP-0001/" . $year;
            } else {
    
              $data = $category_check->job_position_id;
              $slice = explode("/", $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
              $next_number = (int) $result + 1;
              $request = sprintf("JP-%04d", $next_number);
    
              $year = substr(date("y"), -2);
              $job_position_id = $request . '/' . $year;
            }

        $department = JobpositionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'job_position_id'    => $job_position_id, 
                'department_id'    => $payload['erp_department_id'], 
                'division_id'    => $payload['erp_division_id'], 
                'branch_id'        => 1,
                'job_position_name'  => $payload['job_position_name'],
                'job_position_desc'  => $payload['job_position_desc'] ?? null,
                'per_hour_cost'  => $payload['per_hour_cost'] ?? 0,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }
    public function UpdateJobPositionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_job_role_id'];
        if($erpId){
            $jobPosition = JobpositionModel::where('sno', $erpId)->first();

            if ($jobPosition) {
                $jobPosition->external_uuid = $uuid;
                $jobPosition->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $jobPosition->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Job Position Webhook End

    

    // UserRole Webhook Start
    public function userRoleList(Request $request)
    {
        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $departmentList = DB::table('et_user_role')
            ->select('et_user_role.*')
            ->where('et_user_role.entity_id', 1)
            ->where('et_user_role.status', 0)
            ->get();

        $lastId = DB::table('et_user_role')
            ->orderBy('sno', 'desc')
            ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;

        return response()->json([
            'status' => 200,
            'data' => $departmentList,
            'nextId' => $nextId
        ], 200);
    }

    public function UpdateUserRoleUUID(Request $request)
    {
        // Get UUID (idempotency key or generate a new UUID if not provided)
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        // Get the erp_role_id from the payload
        $erpId = $payload['erp_role_id'] ?? null;

        if ($erpId) {
            // Find the user role by erp_role_id
            $userRole = DB::table('et_user_role')->where('sno', $erpId)->first();

            if ($userRole) {
                // Update the external_uuid for the found user role
                DB::table('et_user_role')
                    ->where('sno', $erpId)
                    ->update(['external_uuid' => $uuid]);

                return response()->json([
                    'ok' => true,
                    'sno' => $userRole->sno,
                    'message' => 'External UUID updated successfully',
                    'uuid' => $uuid,
                ], 200);
            } else {
                // If user role is not found
                return response()->json([
                    'ok' => false,
                    'message' => 'User Role not found',
                    'uuid' => $uuid,
                ], 200); // Use 404 for not found error
            }
        } else {
            // If erp_role_id is not provided
            return response()->json([
                'ok' => false,
                'message' => 'User Role ID not provided',
                'uuid' => $uuid,
            ], 200); // Use 400 for bad request error
        }
    }
    // UserRole Webhook End
  
    // Staff Webhook Start 

        public function StaffData(Request $request){

            $auth_key = $request->auth_key;
            $verify_key = 'egcsecret2030datagetapierp';

            if ($auth_key !== $verify_key) {
                return response()->json([
                    'status' => 410,
                    'data' => null,
                    'message' => 'Unauthorized Entry'
                ], 410);
            }

            $staffdata=DB::table('et_staff')
                ->select('et_staff.*','et_department.department_name','et_division.division_name','et_user_role.role_name')
                ->where('et_staff.branch_id',1)
                ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                ->join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->where('et_staff.status',0)
                ->where('et_staff.sno','>',1)
                ->where('et_staff.department_id','!=',10)
                ->get();
            
            foreach($staffdata as $staff){
                if($staff->staff_image){
                    $staff->staff_image= url('staff_images/' . $staff->staff_image);
                }else{
                    $staff->staff_image='';
                }
                $staff->staff_work_info=[];
                if($staff->exp_type == 2){
                    $WorkDetails = StaffWorkInfoModel::where('staff_id', $staff->sno)->where('status',0)
                            ->get();
                    $staff->staff_work_info = $WorkDetails ?? [];
                }
                
            }
            
            return response()->json(['status' => 200, 'data' => $staffdata], 200);
        }
    
        public function StaffAddHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }
                
                $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff already exists'
                    ], 200);
                }
                

                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }

                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => $payload['contact_person_name'] ?? null,
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): null,
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'employee_skill_id' => 1, // Default value for now
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );

            if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }

                // Handle work experience (if applicable)
                if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                    foreach ($payload['work_company_name'] as $key => $company) {
                        // Avoid duplicate work entries for same staff
                        $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                            ->where('company_name', $company)
                            ->where('position', $payload['work_position'][$key] ?? '')
                            ->first();

                        if (!$existingWork) {
                            StaffWorkInfoModel::create([
                                'staff_id' => $add_staff->sno,
                                'staff_type' => $payload['exp_type'],
                                'position' => $payload['work_position'][$key] ?? null,
                                'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                'company_name' => $company,
                                'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                'created_by' => $request->user()->user_id ?? 1,
                                'updated_by' => $request->user()->user_id ?? 1,
                            ]);
                        }
                    }
                }
            }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }

        public function UpdateStaffUUID(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) Str::uuid();

            $payload = $request->all();

            $erpId = $payload['erp_staff_id'];
            if($erpId){
                $staff = StaffModel::where('sno', $erpId)->first();

                if ($staff) {
                    $staff->external_uuid = $uuid;
                    $staff->save();
                }else{
                    return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff Not Found',
                    'uuid' => $uuid,
                ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
            return response()->json([
                'ok'  => true,
                'sno' => $staff->sno,
                'meassage'=>'external uuid updated',
                'uuid' => $uuid,
            ], 200);
        }
     


    // Staff Webhook End 

     // Staff Attendance Webhook Start
        public function StaffAddAttendanceHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }


                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                $staffData = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
                
                 $alreadyExists = StaffAttendanceModel::where([
                    ['staff_id', '=', $staffData->sno],
                    ['date', '=', $payload['date']],
                    ['status', '!=', 2], 
                ])->first();
            $year = date("Y");
            $month = date("m");
            if ($alreadyExists) {
                $alreadyExists->attendance = $payload['attendance'];
                $alreadyExists->time_start = $payload['time_start'] ?? null;
                $alreadyExists->time_end = $payload['time_end'] ?? null;
                $alreadyExists->reason = $payload['reason'] ?? null;
                $alreadyExists->external_uuid = $uuid ;
                $alreadyExists->update();
                $addStaff=$alreadyExists;
            }else{
                // Generate a new staff attendance ID
                    $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                    $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

                    // Save new attendance record
                $addStaff= StaffAttendanceModel::updateOrCreate(
                        ['external_uuid' => $uuid],
                        [
                        'staff_attendance_id' => $staff_attendance_id,
                        'branch_id'           => $staffData->branch_id ?? 1,
                        'staff_id'            => $staffData->sno,
                        'date'                => $payload['date'],
                        'attendance'          => $payload['attendance'],
                        'type'                => $payload['type'] ?? null,
                        'time_start'          => $payload['time_start'] ?? null,
                        'time_end'            => $payload['time_end'] ?? null,
                        'reason'              => $payload['reason'] ?? null,
                        'created_by'          => 0,
                        'updated_by'          => 0,
                        ]
                );
            }  

            return response()->json([
                'ok' => true,
                'sno' => $addStaff->sno,
            ], 200);
        }

        public function StaffAddAttendanceHookEssl(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('batch_uuid')
                ?? (string) Str::uuid();
 
           $rawContent = $request->getContent();

                $payload = json_decode($rawContent, true);

                // If double encoded JSON string
                if (is_string($payload)) {
                    $payload = json_decode($payload, true);
                }

                // Final fallback
                if (!$payload || !is_array($payload)) {
                    $payload = $request->all();
                }

            if (empty($payload['records']) || !is_array($payload['records'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Attendance records required',
                    "data" => $payload ?? "-"
                ], 400);
            }


 
            DB::beginTransaction();
 
            try {
 
                foreach ($payload['records'] as $record) {
 
                    $staffData = StaffModel::where('external_uuid', $record['staff_id'])->first();
 
                    if (!$staffData) {
                        continue; // skip if staff not found
                    }
 
                    $alreadyExists = StaffAttendanceModel::where([
                        ['staff_id', '=', $staffData->sno],
                        ['date', '=', $record['date']],
                        ['status', '!=', 2],
                    ])->first();
 
                    if ($alreadyExists) {
 
                        if (in_array($alreadyExists, ['OD', 'PR', 'L','P'])) {
                                $alreadyExists->update([
                                    'in_time'    => $record['in_time'] ?? null,
                                    'out_time'   => $record['out_time'] ?? null,
                                ]);
                        }else{
                            $alreadyExists->update([
                                'attendance' => $record['attendance'],
                                'in_time'    => $record['in_time'] ?? null,
                                'out_time'   => $record['out_time'] ?? null,
                                'reason'     => $record['reason'] ?? null,
                                'external_uuid' => $record['sno'],
                            ]);
                        }
 
                    } else {
 
                        $category_check = StaffAttendanceModel::where('status','!=',2)
                            ->orderBy('sno','desc')
                            ->first();
 
                        $staff_attendance_id = $this->generateStaffAttendanceId(
                            $category_check,
                            date("m"),
                            date("Y")
                        );
 
                        StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'branch_id'           => $staffData->branch_id ?? 1,
                            'staff_id'            => $staffData->sno,
                            'date'                => $record['date'],
                            'attendance'          => $record['attendance'],
                            'in_time'             => $record['in_time'] ?? null,
                            'out_time'            => $record['out_time'] ?? null,
                            'reason'              => $record['reason'] ?? null,
                            'external_uuid'       => $record['sno'],
                            'created_by'          => 0,
                            'updated_by'          => 0,
                        ]);
                    }
                }
 
                DB::commit();
 
                return response()->json([
                    'ok' => true,
                    'message' => 'Attendance processed successfully'
                ], 200);
 
            } catch (\Throwable $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'ok' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
        }
        
        private function generateStaffAttendanceId($category_check, $month, $year)
        {
            if (!$category_check) {
                return 'ATT0001/' . $month . '/' . $year;
            }

            // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
            $data = $category_check->staff_attendance_id;
            $slice = explode("/", $data);

            // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
            $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$resultcus + 1;

            // Return the formatted ID (e.g., "ATT0002/11/2025")
            return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
        }
    // Staff Attendance Webhook End

// user Credential Check Api
    public function userCrendentialCheck(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        $user = User::select('users.*', 'et_staff.status as staff_status')
        ->where('users.name', $request->name)
        ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
        ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
        // ->where('et_staff.status', 0)
        ->where('et_branch.status', 0)
        ->first();
        
        if (!$user) {
            return response()->json([
                'type' => 'error',
                'message' => 'User not found.'
            ]);
        }

        if ($user->staff_status == 1) {

            return response()->json([
                'type' => 'error',
                'message' => 'This user is inactive. Please contact the administrator.'
            ], 200);

        } elseif ($user->staff_status == 2) {
            return response()->json([
                'type' => 'error',
                'message' => 'This user is deactivated. Please contact the administrator.'
            ], 200);
        }
        if ($user->name !== $request->name) {
            return response()->json([
                'type' => 'error',
                'message' => 'Username is case-sensitive. Please enter the correct case.'
            ], 200);
        }

        // if (!Hash::check($request->password, $user->password)) {
        //     return response()->json([
        //         'type' => 'error',
        //         'message' => 'Invalid credentials'
        //     ], 200);
        // }

        $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();
    
        if (!$permissions) {
            return response()->json([
                'type' => 'error',
                'message' => 'Role Permission Not Set in EAPL ERP'
            ], 200);
        }

        return response()->json([
        'type' => 'Success',
        'message' => 'User Found'
        ], 200);
        
    }

   public function updateTargets(Request $request)

    {

        DB::beginTransaction();

 

        try {

 

            //  Idempotency

            $uuid = $request->header('X-IDEMPOTENCY-KEY')

                ?? $request->input('uuid')

                ?? (string) \Str::uuid();

 

            $payload = $request->all();

 

            // Handle string payload

            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {

                $payload = json_decode($payload[0], true);

            }

 

            \Log::info('Decoded Payload:', $payload);

 

            if (empty($payload)) {

                return response()->json([

                    'ok' => false,

                    'message' => 'Payload is required'

                ], 400);

            }

 

            $targets = $payload['targets'] ?? [];

 

            foreach ($targets as $target) {

 

                DB::table('branch_target')->updateOrInsert(

                    [

                        'branch_id' => $target['branch_id'],

                        'date'      => $target['date'],

                    ],

                    [

                        'quarter' => $target['quarter'],

                        'no_of_registrations' => $target['pre_sale'],

                        'post_sale' => $target['post_sale'],

                        'monthly_target' => $target['monthly_target'],

                        'updated_by' => 1,

                        'created_by' => 1,

                        'updated_at' => now(),

                    ]

                );

 

                $targetId = DB::table('branch_target')

                    ->where('branch_id', $target['branch_id'])

                    ->where('date', $target['date'])

                    ->value('sno');

 

                foreach ($target['weeks'] as $week) {

 

                    // [$startDay, $endDay] = $this->getWeekRange($week['week'], $target['date']);

 

                    DB::table('et_weekly_metrics')->updateOrInsert(

                        [

                            'target_id' => $targetId,

                            'week_name' => 'Week ' . $week['week'],

                        ],

                        [

                            'start_day' => \Carbon\Carbon::parse($week['start_day'])->format('d'),

                            'end_day'   => \Carbon\Carbon::parse($week['end_day'])->format('d'),

                            'percentage' => $week['percentage'],

                            'target_amount' => $week['target_amount'],

                            'pre_sale' => $week['pre_sale'],

                            'post_sale' => $week['post_sale'],

                            'updated_by' => 1,

                            'created_by' => 1,

                            'updated_at' => now(),

                        ]

                    );

                }

            }

            DB::commit();

 

            return response()->json([

                'ok' => true,

                'message' => 'Target synced successfully'

            ], 200);

 

        } catch (\Exception $e) {

 

            DB::rollBack();

 

            \Log::error('Target Sync Failed: ' . $e->getMessage());

 

            return response()->json([

                'ok' => false,

                'message' => $e->getMessage()

            ], 500);

        }

    }


    
    public function UpdateExistStaff(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) Str::uuid();

            $payload = $request->all();
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }

            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
            try{

            if($payload['staff_id']){
                // $staff = StaffModel::where('sno', $erpId)->first();
                $staff = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();

                if ($staff) {
                    $staff->status = 1;
                    $staff->inactive_status = 1;
                    $staff->is_exist_egc = $payload['status'] ?? 1;;
                    $staff->dep_reason = $payload['dep_reason'] ?? null;
                    $staff->notice_start_date = $payload['notice_start_date'] ?? null;
                    $staff->notice_end_date = $payload['notice_end_date'] ?? null;
                    $staff->staff_last_date = $payload['staff_last_date'] ?? null;
                    $staff->save();

                    event(new StaffExistUpdated($staff));

                     return response()->json([
                        'ok'  => true,
                        'sno' => $staff->sno,
                        'meassage'=>'Exit Staff Updated',
                        'uuid' => $uuid,
                    ], 200);
                    

                }else{
                    return response()->json([
                        'ok'  => true,
                        'meassage'=>'Staff Not Found',
                        'uuid' => $uuid,
                    ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }

            }catch(\Throwable $e){
                    return response()->json([
                        'ok'  => false,
                        'message' => $e->getMessage(),
                    ], 500);
            }
            // $erpId = $payload['erp_staff_id'];
            

            
        }

        public function existStaffCount()
        {
            $count = StaffModel::where('is_exist_egc', '!=',0)
                ->where('status', 1)
                ->count();

            return response()->json([
                'count' => $count
            ]);
        }

       public function existStaffList()
    {
        $staff = StaffModel::where('et_staff.is_exist_egc','!=',0)
            ->where('et_staff.status', 1)
            ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->select(
                'et_staff.staff_name',
                'et_staff.external_uuid',
                'et_staff.sno as id',
                'et_staff.staff_image',
                'et_staff.is_exist_egc',
                'et_staff.staff_last_date',
                'et_staff.notice_start_date',
                'et_staff.notice_end_date',
                'et_staff.dep_reason',
                'et_department.department_name',
                'et_job_position.job_position_name'
            )
            ->get();

        return response()->json($staff);
    } 

    public function getAchieveData(Request $request)
    {
        try {
 
            $verify_key = 'egcsecret2030datagetapierp';
 
            if ($request->verify_key !== $verify_key) {
 
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized'
                ], 401);
            }
 
            $branchId = $request->branch_id;
 
            $fromDate = Carbon::parse($request->from_date)->format('Y-m-d');
            $toDate   = Carbon::parse($request->to_date)->format('Y-m-d');
 
            $dates = [];
 
            $period = CarbonPeriod::create($fromDate, $toDate);
            $helper = new \App\Helpers\Helpers();
 
            $branch_common = DB::table('et_branch')->select('et_branch.*')
            ->where('et_branch.sno', $branchId)
            ->first();
 
            $processedCustomers = [];
 
            foreach ($period as $dateObj) {
 
                $date = $dateObj->format('Y-m-d');
 
                // SALES AMOUNT
             
 
                $total_collection_value = 0;
         
                $allVerified = DB::table('et_transaction')
                    ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->where('et_transaction.payment_status',1)
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_lead.created_by','>',1)
                    ->where('et_lead.status','!=',2)
                    ->where('et_customer.status',0)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                            'et_proposal.gst_perc','et_country_currencies.currency_code',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                            )
                    ->get();
               
                foreach ($allVerified as $row) {
                    // Determine INR value
                    if ($row->total_amount_inr > 0) {
                        $convertedPaidAmountInr = $row->total_amount_inr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
                    }
               
                    // Use transaction GST%
                    $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch_common->gst_percentage/100);

                    if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                        $netAmountInr = $convertedPaidAmountInr ;
                    }else{
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    }
                    
               
                    $total_collection_value += $netAmountInr;
                }
           
           
 
                $total_collection_value = round($total_collection_value);
 
                // PRE SALE
                $preSale = DB::table('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
 
                    ->join('et_payment', function ($join) {
 
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
 
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
 
                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
 
                    ->where('et_customer.status', 0)
                    ->where('et_proposal.post_sale_check', 0)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', '>', 1)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->where('et_transaction.payment_status', 1)
                    ->count();
 
                // POST SALE
                $postSaleData = DB::table('et_customer')
                    ->select('et_customer.sno','et_payment.transaction_date')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
 
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', '>', 1)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->where('et_transaction.payment_status', 1)
                    ->distinct('et_customer.sno')
                    ->get();
                $customerConvertDataPostRaw = DB::table('et_customer')
                ->select(
                    'et_customer.sno',
                    'et_customer.proposal_ids',
                    'et_customer.cus_name',
                    'et_payment.transaction_date'
                )
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
 
                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
 
                ->join('et_payment', function($join) {
 
                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.proposal_id = et_proposal.sno
                        )');
                })
 
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
 
                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', '>', 1)
 
                ->whereDate('et_payment.transaction_date', $date)
 
                ->whereYear('et_payment.transaction_date', Carbon::parse($date)->year)
                ->whereMonth('et_payment.transaction_date', Carbon::parse($date)->month)
 
                ->where('et_transaction.payment_status', 1)
 
                ->orderBy('et_payment.transaction_date', 'asc')
                ->orderBy('et_customer.sno', 'asc')
 
                ->get();
 
                $customerConvertDataPost = collect();
 
                foreach ($customerConvertDataPostRaw as $customer) {
 
                    // Ignore duplicate customer in same month
                    if (in_array($customer->sno, $processedCustomers)) {
                        continue;
                    }
 
                    $processedCustomers[] = $customer->sno;
 
                    $customerConvertDataPost->push($customer);
                }
 
               $postSale = $customerConvertDataPost->count();
 
                $dates[] = [
                    'date' => $date,
                    'amount' => $total_collection_value,
                    'pre_sale' => (int)$preSale,
                    'post_sale' => $postSale,
                    //  'customerConvertDataPost' => $customerConvertDataPost->values(),
                ];
            }
 
            return response()->json([
                'status' => true,
                'data' => $dates
            ]);
 
        } catch (\Exception $e) {
 
            \Log::error('Achieve API Error : ' . $e->getMessage());
 
            return response()->json([
                'status' => false,
                'message' => 'Server Error' . $e->getMessage()
            ]);
        }
    }
    
      public function GetIncentive(Request $request)
    {
        try {

            if ($request->verify_key !== 'egcsecret2030datagetapierp') {

                return response()->json([
                    'status'  => false,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $request->validate([
                'branch_id' => 'required|integer',
                'role_id'   => 'required',
                'month_year'=> 'nullable|string'
            ]);

            $branchId = (int) $request->branch_id;
            $roleId   = trim($request->role_id);

            $monthFilter = $request->get('month_year', date('M-Y'));
            try {

                $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);

            } catch (\Exception $e) {

                $parsedDate = now();
            }

            $month = (int) $parsedDate->month;
            $year  = (int) $parsedDate->year;

            $cacheVersion = 'v2';

            $cacheKey = implode('_', [
                'incentive',
                $cacheVersion,
                'branch', $branchId,
                'role', $roleId,
                'year', $year,
                'month', $month
            ]);

            $responseData = Cache::remember(
                $cacheKey,
                now()->addSeconds(2),
                function () use (
                    $branchId,
                    $roleId,
                    $year,
                    $month
                ) {
                    $staffs = DB::table('et_staff')
                        ->select([
                            'sno',
                            'staff_name',
                            'external_uuid',
                            'role_id'
                        ])
                        ->where('role_id', $roleId)
                        ->where('branch_id', $branchId)
                        ->where('status', 0)
                        ->orderBy('staff_name')
                        ->get();

                    if ($staffs->isEmpty()) {

                        return [
                            'generated_at' => now()->format('Y-m-d H:i:s'),
                            'next_refresh' => now()->addMinutes(30)->format('Y-m-d H:i:s'),
                            'count'        => 0,
                            'data'         => []
                        ];
                    }

                    $incentiveData = [];

                    foreach ($staffs as $staff) {
                        try {
                            $result = self::calculateIncentiveValue(
                                $staff->sno,
                                $branchId,
                                $roleId,
                                $year,
                                $month
                            );
                        //    return $result;
                            
                            $totalAward = (float) ($result['total_award'] ?? 0);
                            $breakdown = $result['breakdown'] ?? [];
                            $metrics = $result['metrics'] ?? [];

                            foreach ($breakdown as $key => $value) {
                                $breakdown[$key] = (float) $value;
                            }
                        

                            $incentiveData[] = [
                                'staff_id' => (int) $staff->sno,
                                'external_uuid' => (int) $staff->external_uuid,
                                'staff_name' => $result['staff_name']
                                    ?? $staff->staff_name,
                                'role_id' => $result['role_id']
                                    ?? $staff->role_id,
                                'total_award' => round($totalAward, 2),
                                'currency' => 'INR',
                                'breakdown' => $breakdown,
                                'metrics' => $metrics,
                                'last_updated' => now()
                                    ->format('Y-m-d H:i:s'),
                                'next_update' => now()
                                    ->addMinutes(30)
                                    ->format('Y-m-d H:i:s'),
                            ];

                        } catch (\Throwable $e) {
                            Log::error('Incentive Staff Error', [
                                'staff_id' => $staff->sno,
                                'message'  => $e->getMessage()
                            ]);

                            $incentiveData[] = [
                                'staff_id'      => (int) $staff->sno,
                                'staff_name'    => $staff->staff_name,
                                'role_id'       => $staff->role_id,
                                'total_award'   => 0,
                                'currency'      => 'INR',
                                'breakdown'     => [],
                                'metrics'     => [],
                                'last_updated'  => now()->format('Y-m-d H:i:s'),
                                'next_update'   => now()->addSeconds(2)
                                    ->format('Y-m-d H:i:s'),
                                    'message'  => $e->getMessage()
                            ];
                        }
                    }
                
                    usort($incentiveData, function ($a, $b) {
                        return $b['total_award'] <=> $a['total_award'];
                    });
                    return [
                        'generated_at' => now()
                            ->format('Y-m-d H:i:s'),
                        'next_refresh' => now()
                            ->addSeconds(2)
                            ->format('Y-m-d H:i:s'),
                        'count' => count($incentiveData),
                        'data' => $incentiveData
                    ];
                }
            );
            return response()->json([
                'status'  => true,
                'message' => 'Incentive data fetched successfully',
                'cached' => true,
                'cache_expires_in_minutes' => 2,
                'generated_at' => $responseData['generated_at'] ?? null,
                'next_refresh' => $responseData['next_refresh'] ?? null,
                'total_staff' => $responseData['count'] ?? 0,
                'data' => $responseData['data'] ?? []
            ]);

        } catch (\Throwable $e) {
            Log::error('Get Incentive API Error', [
                'message' => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ]);
            return response()->json([

                'status'  => false,
                'message' => 'Server Error'.$e->getMessage()
            ], 500);
        }
    }

  /**
   * Calculate incentive value for floating bar
   */
  private static function calculateIncentiveValue($userId, $branchId, $roleId, $year, $month)
  {
    $staff = StaffModel::find($userId);
    // if (!$staff) {
    //   return self::getEmptyResponse();
    // }

    // Get incentive settings
    $incentive = IncentiveModel::where('role_id', $roleId)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $year)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      // Try fallback date
      $fallbackDate = '2025-06-01';
      $incentive = IncentiveModel::where('role_id', $roleId)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
        ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
        ->where('status', 0)
        ->first();
    }

    // if (!$incentive) {
    //   return self::getEmptyResponse();
    // }

    // Get goal data
    $goalData = GoalSetStaffModel::where('staff_id', $userId)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->first();
    // return $goalData;

    // Calculate based on role
    $totalReward = 0;
    $breakdown = [];
    $metrics = [];
   
    switch ($roleId) {
      case 11: // Sales Executive
        $result = self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        //  $totalReward = $result;
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 35: // Sales Executive
        $result = self::calculatePostSaleExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
       
        // $totalReward = $result;
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 12: // Team Lead
        $result = self::calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 34: // Collection
        $result = self::calculateJournalExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 33: // Collection
        $result = self::calculateJournalTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
 
      case 16: // CRE
        $result = self::calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 42: // CRE
        $result = self::calculateCollectionReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 41: // CRE
        $result = self::calculateBDMReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
     
      default:
        return self::getEmptyResponse();
    }
    
    // return $totalReward;

    return [
      'total_award' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => $metrics,
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'staff_name' => $staff->staff_name,
      'staff_id' => $staff->sno,
      'role_id' => $roleId
    ];
  }

  /**
   * Calculate Sales Executive Reward (Exact logic from your code)
   */
  private static function calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];
    
          $helper = new \App\Helpers\Helpers();

    // Get previous month for calculations
    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();


        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }

            $startOfMonth = $startDate->format('Y-m-d');
            $endOfMonth = $endDate->format('Y-m-d');

            $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();

            $startDateChck = Carbon::create($year, $month, 1);
            $currentDateChck = Carbon::now();
            $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month) 
                        ? $currentDateChck 
                        : $startDateChck->copy()->endOfMonth();
        
         $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;

            $tenxStatus = false;
            $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
            $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
            $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;

            $eciStatus = false;
            $eciCustomerConvertCount = 0;
            $eciActualPercentage = 0;
            $eciTargetPercentage = $incentive->eci_count ?? 0;

            $biStatus = false;
            $biPerConversion = $incentive->bi_amount ?? 0;

            $siStatus = false;
            $si_slabs = ($incentive && $incentive->si_incentive_json) ? json_decode($incentive->si_incentive_json, true) : [];

            $prfStatus = false;
            $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            $spStatus = false;
            $piStatus = false;

            $liStatus = false;

            $base_amount_paid=0;
            
            
            $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];

            $currentMonthCustomerCount = 0;

            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            $siCollectionValue =0;
            
            $piPercentage = 0;
            $originalAmount = 0;
            $piReward = 0;
            $matchedSlabSI = null;
            $slabPercentageSI = 0; 
            $siPercentage=0;
            $originalAmountSI = 0;
            $siReward = 0;
            $matchedSlab = null;
            $slabPercentage = 0; 
            // Total Professional and Crash courses
            $matchedSlabPI = null;
            $piRewardPercent = 0;
            $piRewardAmount = 0;
            $profitPercentage=0;
            $siRewardAmount = 0;
            $proposalWiseDetails = [];
            $highestMatchedSlab = '';
            $highestProfitPercentage = 0;
            $highestMatchedSlab = 'No Slab';
            $highestRewardPercent = 0;
            $piHighestreward = 0;
            $piCollectionValue =0;
            $siStatus = false;

            // 1. 10x Reward Start
            
                $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->count();
                        
                      
                    $postProposalFirstIds = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        // ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_proposal.sno')
                        ->toArray();

                    $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        // ->where('et_customer.post_sale_check', 0)
                        ->where('et_proposal.post_sale_check', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_customer.sno')
                        ->toArray();

                    $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
                        ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                        ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                        ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.sno',$prevMonthCustomerIdsCurrent )
                        ->whereIn('et_proposal.sno',$postProposalFirstIds )
                        // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                        ->where('et_proposal.status', '!=', 2)
                        ->whereNotIn('et_proposal.proposal_status',[0, 2])
                        ->where('et_transaction.payment_status', 1)
                        ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                        ->groupBy('et_proposal.customer_id')
                        // ->get();
                        ->having('total_paid','<',(float) $branch->min_prd_cost)
                        ->pluck('customer_id')
                        ->toArray();
                           
                        $badCustomerIds = array_unique(array_merge( $lowMbcCustomerIdsCurrent,));
                          
                        $second_pay_check = $incentive ? $incentive->second_payment_check : 0;
                        
                        if($second_pay_check == 1){
                            $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                        }else{
                            $customerConvertCount = max(0,$customerConvertCountthismonth);
                        }

                        if ($customerConvertCount > 0) {
                             $currentMonthCustomer = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_lead.created_by', $staff->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->orderBy('et_customer.sno', 'asc')
                                ->get();

                            $base_amount_paid=0;
                            $gst_percent = 18;
                            if ($currentMonthCustomer->isNotEmpty()) {
                                foreach ($currentMonthCustomer as $customer) {
                                    $proposal_ids = DB::table('et_proposal')
                                        ->where('et_proposal.customer_id', $customer->sno)
                                        ->where('et_proposal.status', 0)
                                        ->whereNot('et_proposal.post_sale_check', 1)
                                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                        ->pluck('sno')
                                        ->toArray();
                                        // return $proposal_ids;
                            
                                    $proposals = DB::table('et_proposal')
                                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                        ->whereIn('et_proposal.sno', $proposal_ids)
                                        ->get();
                            
                                    foreach ($proposals as $proposal) {
                                        // Paid slots for this proposal
                                        $paidAmount = DB::table('et_proposal_pay_slot')
                                            ->where('proposal_sno', $proposal->sno)
                                            ->where('status', 0)
                                            ->sum('paidAmount');

                                        if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                            $grantAmount = $proposal->total_amount;
                                        }else{
                                            $grantAmount = $proposal->grant_total_amount;
                                        }
                                        // First remove GST from paidAmount (base value in proposal's currency)
                                        if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                            $basePaidLocal = $paidAmount ;
                                        }else{
                                            $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                                        }
                                        
                            
                                        if ($proposal->currency_id == 70) {
                                            // INR: add directly
                                            $total_paid_payment += $paidAmount;
                                            $total_payment += $grantAmount;
                                            $base_amount_paid += $basePaidLocal;
                                        } else {
                                            // Non-INR: convert both amounts and base value
                                            $currency_code = $proposal->currency_code;
                                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                        }
                                    }
                                }
                            }
                        
                        }


                    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;

                    $actualConversion =$customerConvertCount;

                    $targetConversion = $goalData->conversion ?? 0;
                    $targetABV = $goalData->ABV ?? 0;
                    $targetACV = $goalData->ACV ?? 0;

                    
                    
  
                    $tenxStatus = ($targetConversion > 0 && $targetABV > 0 &&$targetACV > 0 && $actualConversion >= $targetConversion );

                    if ($tenxStatus) {
                        $tenxReward = $incentive->tenx_award ?? 0;
                        $totalReward += $tenxReward;
                        $breakdown['10X Award'] = $tenxReward;
                    }else{
                        $tenxReward =  0;
                        $totalReward += $tenxReward;
                        $breakdown['10X Award'] = $tenxReward;
                    }
            //  10x Reward End 

            // ECI Incentive Start

                $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereDay('et_payment.transaction_date', '<=', 15)
                    ->count();

                    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                    $eciActualPercentage = number_format($eciActualPercentage, 2);
                    $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

                    if ($tenxStatus && $eciStatus) {
                        $eciReward = $incentive->eci_reward ?? 0;
                        $totalReward += $eciReward;
                        $breakdown['ECI Award'] = $eciReward;
                    }else{
                        $eciReward =  0;
                        $totalReward += $eciReward;
                        $breakdown['ECI Award'] = $eciReward;
                    }

            // ECI INCentive END

            // Bonus Incentive Start
                $biAchievedCount = max(0, $actualConversion - $targetConversion); 
                $biReward = $biAchievedCount * $biPerConversion;
                $biStatus = $biAchievedCount > 0;

                if ($tenxStatus && $biStatus) {
                    $totalReward += $biReward;
                    $breakdown['BI Award'] = $biReward;
                }else{
                    $biReward =  0;
                    $totalReward += $biReward;
                    $breakdown['BI Award'] = $biReward;
                }
            // Bonus Incentive End

            // Strategic Incentive Start

                    $proposalIds = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        // ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->pluck('et_proposal.sno');

                        $collectionsINR = DB::table('et_transaction')
                            ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->whereIn('et_payment.proposal_id', $proposalIds)
                            ->where('et_transaction.payment_status', 1)
                            ->groupBy('et_payment.proposal_id')
                            ->select(
                                'et_payment.proposal_id',
                                DB::raw('SUM(et_transaction.total_amount_inr) as total_inr')
                            )
                            ->pluck('total_inr', 'proposal_id');

                        $collectionsOriginal = DB::table('et_transaction')
                            ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->whereIn('et_payment.proposal_id', $proposalIds)
                            ->where('et_transaction.payment_status', 1)
                            ->groupBy('et_payment.proposal_id')
                            ->select(
                                'et_payment.proposal_id',
                                DB::raw('SUM(et_transaction.total_amount) as total_original')
                            )
                            ->pluck('total_original', 'proposal_id');

                        $gst_percent = 18;
                        $totalSelling = 0;
                        $totalActual = 0;

                        $totalProfitNet = 0;
                        $totalCollectionNet = 0;

                        $gst_percent = 18;

                        $proposalData = DB::table('et_proposal')
                            ->whereIn('et_proposal.sno', $proposalIds)
                            ->select('et_proposal.sno as proposal_id','et_proposal.discount_amount')
                            ->get();

                        foreach ($proposalData as $row) {
                            $proposalId = $row->proposal_id;
                            $productOriginal = DB::table('et_proposal_product_cart')
                                ->where('proposal_sno', $proposalId)
                                ->sum('original_amount');
                            $productCustom = DB::table('et_proposal_product_cart')
                                ->where('proposal_sno', $proposalId)
                                ->sum('product_amount');
                            $packageOriginal = DB::table('et_proposal_package_cart')
                                ->where('proposal_sno', $proposalId)
                                ->sum('original_product_amount');
                            $packageCustom = DB::table('et_proposal_package_cart')
                                ->where('proposal_sno', $proposalId)
                                ->sum('cust_product_amount');
                            $discountAmount = $row->discount_amount ?? 0 ;
                            $original = $productOriginal + $packageOriginal ;
                            $custom = ($productCustom + $packageCustom) - $discountAmount;
                            if ($custom <= 0 || $original <= 0) {
                                continue;
                            }
                            if ($custom <= $original) {
                                continue;
                            }

                            $proposal = DB::table('et_proposal')
                                ->where('sno', $proposalId)
                                ->first();

                            $profitAmount = $custom - $original;

                            $profitPercentage =($profitAmount / $custom) * 100;

                            $rewardPercent = 0;
                            $matchedSlab = 'No Slab';

                            foreach ($si_slabs as $slab) {

                                $min = (float) $slab['min'];
                                $max = (float) $slab['max'];

                                if ($profitPercentage >= $min && $profitPercentage <= $max) {

                                    $rewardPercent = (float) $slab['percentage'];
                                    $matchedSlab = "{$min}% - {$max}%";
                                    break;
                                }
                                // keep updating to the latest slab.
                                if ($profitPercentage > $max) {
                                    $rewardPercent = (float) $slab['percentage'];
                                    $matchedSlab = "{$min}% - {$max}%";
                                }
                            }

                            if ($profitPercentage > $highestProfitPercentage) {
                                $highestProfitPercentage = $profitPercentage;
                                $highestMatchedSlab = $matchedSlab;
                                $highestRewardPercent = $rewardPercent;
                            }

                            if ($rewardPercent <= 0) {
                                continue;
                            }

                            $profitAmountInr = $profitAmount;

                            if ($proposal->currency_id != 70) {
                                $currency = DB::table('et_country_currencies')
                                    ->where('sno', $proposal->currency_id)
                                    ->value('currency_code');

                                $profitAmountInr = $helper->ConvertedAmountInr($currency,$profitAmount);
                            }

                            $proposalReward = ($profitAmountInr * $rewardPercent) / 100;
                            $siRewardAmount += $proposalReward;

                            $proposalWiseDetails[] = [
                                'proposal_id' => $proposalId,
                                'profit_percent' => round($profitPercentage, 2),
                                'profit_amount' => round($profitAmountInr),
                                'reward_percent' => $rewardPercent,
                                'reward_amount' => round($proposalReward),
                                'slab' => $matchedSlab,
                            ];
                        }


                    $siStatus = $siRewardAmount > 0;
                    $siReward = round($siRewardAmount);

                    if($tenxStatus && $siStatus) {
                        $siReward = $siReward;
                        $totalReward += $siReward;
                        $breakdown['SI Award'] = $siReward;
                    }else{
                        $siReward =  0;
                        $totalReward += $siReward;
                        $breakdown['SI Award'] = $siReward;
                    }

            // Strategic Incentive End

            // Profitable Incentive Start

                $proposalPayslotFirstIds = DB::table('et_proposal_pay_slot')
                        ->whereIn('proposal_sno', $proposalIds)
                        ->where('status', 0)
                        ->where('first_milestone', 1)
                        ->pluck('sno');

                $firstSalesCollection = DB::table('et_payment')
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->whereIn('et_payment.pay_slot_id', $proposalPayslotFirstIds)
                    ->where('et_payment.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->select(
                        'et_transaction.total_amount_inr',
                        'et_proposal.currency_id',
                        DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                        DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                    )
                    ->get();

                $baseFirstSalesCollection = $firstSalesCollection->sum(function ($row) use ($gst_percent) {
                    if ( $row->currency_id != 70 &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                        return $row->total_amount_inr;
                    }else{
                        return $row->total_amount_inr / (1 + ($gst_percent / 100));
                    }
                });
                
                $AveragePiCollectionValue = $customerConvertCount > 0 ? $baseFirstSalesCollection / $customerConvertCount : 0 ;
                $piCollectionValue = $AveragePiCollectionValue;
                $piHighestreward = collect($pi_slabs)->max('reward') ?? 0;

                foreach ($pi_slabs as $slab) {
                    $min = $slab['min'];
                    $max = $slab['max'];

                    if ( $piCollectionValue >= $min && ($max === null || $piCollectionValue <= $max) ) {
                        $matchedSlabSI = $min . ' - ' . ($max ?? 'Above');
                        $piReward = $slab['reward'];
                        $slabMin = $min;
                        $slabMax = $max;
                        break;
                    }
                }

                $prfStatus = $piReward > 0;

                if ($tenxStatus && $prfStatus) {
                    $piReward = $piReward;
                    $totalReward += $piReward;
                    $breakdown['PRF Award'] = $piReward;
                }else{
                    $piReward =  0;
                    $totalReward += $piReward;
                    $breakdown['PRF Award'] = $piReward;
                }

            // Profitable Incentive End

            // Spot Incentive Start
                $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->sno)
                    ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.sno = (
                                        SELECT ep.sno
                                        FROM et_payment ep
                                        WHERE ep.customer_id = et_customer.sno
                                        ORDER BY ep.transaction_date ASC, ep.sno ASC
                                        LIMIT 1
                                    )');
                            })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_transaction.payment_status', 1)
                    ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                    ->select(
                        'et_payment.transaction_date as customer_created_at',
                        'et_lead.registered_date as lead_created_at',
                        'et_lead.lead_mobile as lead_mobile'
                    )
                    ->get();
            

                foreach ($allConverted as $row) {
                
                    $mobile = $row->lead_mobile;
                    // Get the latest call
                    $lastCall = DB::table('et_call_tracker')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staff->sno)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->orderByDesc('call_start_date')
                        ->first();

                    $totalCallCount = DB::table('et_call_tracker')->select('sno')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staff->sno)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->orderByDesc('call_start_date')
                        ->count();
                    // Attach values to row
                    $row->call_created_at = $lastCall->call_start_date ?? null;
                    $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                    $row->call_count = $totalCallCount;
                } 
                    // return $allConverted;
                    
                $convertedToday = 0;
                $convertedMonth = 0;
                $convertedOldMonth = 0;
                $customerDetails=[];
                foreach ($allConverted as $row) {
                    $mobile = $row->lead_mobile;
                    $totalCalldata = DB::table('et_call_tracker')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staff->sno)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->select(
                            'et_call_tracker.call_start_date'
                        )
                        ->get();
                        
                    $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                    $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                    $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                    $call_count = $row->call_count;
                    
                    $customerData = [
                        'customerDate' => $customerDate,
                        'leadDate'     => $leadDate,
                        'mobile'       => $mobile
                    ];
                    if ($customerDate ===  $leadDate) {
                        $convertedToday++;
                    } elseif (
                        $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        $leadDate >= $startOfMonth && $leadDate <= $dates
                    ) {
                        $convertedMonth++;
                    
                    } elseif (
                        $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        ($leadDate < $startOfMonth || $leadDate > $dates)
                    ) {
                        $convertedOldMonth++;
                    }
                }
                
                $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

                $spStatus = $spotTotalReward > 0 ;

                if ($tenxStatus && $spStatus) {
                    $totalReward += $spotTotalReward;
                    $breakdown['SP Award'] = $spotTotalReward;
                }else{
                    $spotTotalReward =  0;
                    $totalReward += $spotTotalReward;
                    $breakdown['SP Award'] = $spotTotalReward;
                }

            // Spot Incentive End

            // Performance Incentive Start

                $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;

                $actualOutgoingCallCount=0;
                $actualMissedCallRate=0;
                $actualMissedCount=0;

                $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->sno)
                    ->first();

                $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                
                $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                $actualOutgoingPerDay=round($actualOutgoingPerDay);

                // Missed call ratio
                $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count + $actualCallCount->rejected_call_count;
                $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                $actualMissedCallRate=round($actualMissedCallRate,1);

                $piStatus = (
                    $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                    $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                );
                $performanceReward = $incentive->performance_incentive_reward ?? 0 ;

                if ($tenxStatus && $piStatus) {
                    $totalReward += $performanceReward;
                    $breakdown['PI Award'] = $performanceReward;
                }else{
                    $performanceReward =  0;
                    $totalReward += $performanceReward;
                    $breakdown['PI Award'] = $performanceReward;
                }

            // Performance Incentive End

            // Luxury Incentive Start
                $luxury = json_decode($incentive->luxury_incentive ?? '{}', true);
                $allIncentivesAchieved = ($tenxStatus && $spStatus  && $siStatus && $eciStatus && $biStatus && $piStatus && $prfStatus);

                if ($allIncentivesAchieved) {
                    $liReward = $luxury['reward'] ?? 0;
                    $totalReward += $liReward;
                    $breakdown['LI Award'] = $liReward;
                }else{
                    $liReward =  0;
                    $totalReward += $liReward;
                    $breakdown['LI Award'] = $liReward;
                }
            // Luxury Incentive End

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetConversion,
        'actual' => $actualConversion,
      ]
    ];
  }
  private static function calculatePostSaleExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month){
            $totalReward = 0;
            $breakdown = [];
    
            $helper = new \App\Helpers\Helpers();

            // Get previous month for calculations
            $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
            $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

            $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
            $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();


            $dates = [];
            $currentDate = $startDate->copy();
            while ($currentDate->lte($endDate)) {
                $dates[] = $currentDate->toDateString();
                $currentDate->addDay();
            }

            $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();
            $startDateChck = Carbon::create($year, $month, 1);
                $currentDateChck = Carbon::now();
                $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month) 
                            ? $currentDateChck 
                            : $startDateChck->copy()->endOfMonth();
            
            $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;

            $tenxStatus = false;
            $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
            $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
            $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;

            $eciStatus = false;
            $eciCustomerConvertCount = 0;
            $eciActualPercentage = 0;
            $eciTargetPercentage = $incentive->eci_count ?? 0;

            $biStatus = false;
            $biPerConversion = $incentive->bi_amount ?? 0;

            $siStatus = false;
            $si_slabs = ($incentive && $incentive->si_incentive_json) ? json_decode($incentive->si_incentive_json, true) : [];

            $prfStatus = false;
            $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            $spStatus = false;
            $piStatus = false;

            $liStatus = false;

            $base_amount_paid=0;
            
            
            $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];

            $currentMonthCustomerCount = 0;

            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            $siCollectionValue =0;
            
            $piPercentage = 0;
            $originalAmount = 0;
            $piReward = 0;
            $matchedSlabSI = null;
            $slabPercentageSI = 0; 
            $siPercentage=0;
            $originalAmountSI = 0;
            $siReward = 0;
            $matchedSlab = null;
            $slabPercentage = 0; 
            // Total Professional and Crash courses
            $matchedSlabPI = null;
            $piRewardPercent = 0;
            $piRewardAmount = 0;
            $profitPercentage=0;
            $siRewardAmount = 0;
            $proposalWiseDetails = [];
            $highestMatchedSlab = '';
            $highestProfitPercentage = 0;
            $highestMatchedSlab = 'No Slab';
            $highestRewardPercent = 0;
            $piHighestreward = 0;
            $piCollectionValue =0;
            $siStatus = false;

            // 1. 10x Reward Start
            
                    $customerConvertCountthismonth = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->count();
                        
                      
                            $postProposalFirstIds = DB::table('et_customer')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.post_sale_check', 1)
                                ->where('et_proposal.post_sale_check', 1)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_proposal.created_by', $staff->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                                ->where('et_proposal.status',0)
                                ->orderBy('et_proposal.sno', 'asc')
                                ->distinct('et_customer.sno')
                                ->pluck('et_proposal.sno')
                                ->toArray();
                      
                    
                        $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                    ->join('et_payment', function($join) {
                                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                            ->whereRaw('et_payment.transaction_date = (
                                                SELECT MIN(ep.transaction_date)
                                                FROM et_payment ep
                                                WHERE ep.proposal_id = et_proposal.sno
                                            )');
                                    })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.post_sale_check', 1)
                            ->where('et_proposal.post_sale_check', 1)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_proposal.created_by', $staff->sno)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                            ->where('et_proposal.status',0)
                            ->orderBy('et_proposal.sno', 'asc')
                            ->distinct('et_customer.sno')
                            ->pluck('et_customer.sno')
                            ->toArray();

                            $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
                            ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                            ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                            ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereIn('et_customer.sno',$prevMonthCustomerIdsCurrent )
                            ->whereIn('et_proposal.sno',$postProposalFirstIds )
                            // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                            ->where('et_proposal.status', '!=', 2)
                            ->whereNotIn('et_proposal.proposal_status',[0, 2])
                            ->where('et_transaction.payment_status', 1)
                            ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                            ->groupBy('et_proposal.customer_id')
                            // ->get();
                            ->having('total_paid','<',(float) $branch->min_prd_cost)
                            ->pluck('customer_id')
                            ->toArray();
                            // return $lowMbcCustomerIds;
                            $badCustomerIds = array_unique(array_merge( $lowMbcCustomerIdsCurrent ));
                        
                            if($incentive->second_payment_check == 1){
                                $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                            }else{
                                $customerConvertCount = max(0,$customerConvertCountthismonth);
                            }

                        if ($customerConvertCount > 0) {
                        
                            $currentMonthCustomer = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_lead.created_by', $staff->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->orderBy('et_customer.sno', 'asc')
                                ->get();

                            $base_amount_paid=0;
                            $gst_percent = 18;
                            if ($currentMonthCustomer->isNotEmpty()) {
                                foreach ($currentMonthCustomer as $customer) {
                                    $proposal_ids = DB::table('et_proposal')
                                        ->where('et_proposal.customer_id', $customer->sno)
                                        ->where('et_proposal.status', 0)
                                        ->whereNot('et_proposal.post_sale_check', 1)
                                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                        ->pluck('sno')
                                        ->toArray();
                                        // return $proposal_ids;
                            
                                    $proposals = DB::table('et_proposal')
                                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                        ->whereIn('et_proposal.sno', $proposal_ids)
                                        ->get();
                            
                                    foreach ($proposals as $proposal) {
                                        // Paid slots for this proposal
                                        $paidAmount = DB::table('et_proposal_pay_slot')
                                            ->where('proposal_sno', $proposal->sno)
                                            ->where('status', 0)
                                            ->sum('paidAmount');
                            
                                        if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                            $grantAmount = $proposal->total_amount;
                                        }else{
                                            $grantAmount = $proposal->grant_total_amount;
                                        }
                            
                                        // First remove GST from paidAmount (base value in proposal's currency)
                                        if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                            $basePaidLocal = $paidAmount;
                                        }else{
                                            $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                                        }
                                        
                            
                                        if ($proposal->currency_id == 70) {
                                            // INR: add directly
                                            $total_paid_payment += $paidAmount;
                                            $total_payment += $grantAmount;
                                            $base_amount_paid += $basePaidLocal;
                                        } else {
                                            // Non-INR: convert both amounts and base value
                                            $currency_code = $proposal->currency_code;
                                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                        }
                                    }
                                }
                            }
                    
                    
                            // average 
                            $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                            $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                           
  
                        }

                  
                    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;

                    $actualConversion =$customerConvertCount;

                    $targetConversion = $goalData->conversion ?? 0;
                    $targetABV = $goalData->ABV ?? 0;
                    $targetACV = $goalData->ACV ?? 0;

                    
                    
  
                    $tenxStatus = ($targetConversion > 0 && $targetABV > 0 && $targetACV > 0 && $actualConversion >= $targetConversion );

                    // return $targetConversion;
                    if ($tenxStatus) {
                        $tenxReward = $incentive->tenx_award ?? 0;
                        $totalReward += $tenxReward;
                        $breakdown['10X Award'] = $tenxReward;
                    }else{
                        $tenxReward =  0;
                        $totalReward += $tenxReward;
                        $breakdown['10X Award'] = $tenxReward;
                    }
            //  10x Reward End 

            // ECI Incentive Start

                $eciCustomerConvertCount = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', $staff->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->whereDay('et_payment.transaction_date', '<=', 15)
                    ->distinct('et_customer.sno')
                    ->count();

                    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                    $eciActualPercentage = number_format($eciActualPercentage, 2);
                    $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

                    if ($tenxStatus && $eciStatus) {
                        $eciReward = $incentive->eci_reward ?? 0;
                        $totalReward += $eciReward;
                        $breakdown['ECI Award'] = $eciReward;
                    }else{
                        $eciReward =  0;
                        $totalReward += $eciReward;
                        $breakdown['ECI Award'] = $eciReward;
                    }

            // ECI INCentive END

            // Bonus Incentive Start
                $biAchievedCount = max(0, $actualConversion - $targetConversion); 
                $biReward = $biAchievedCount * $biPerConversion;
                $biStatus = $biAchievedCount > 0;

                if ($tenxStatus && $biStatus) {
                    $totalReward += $biReward;
                    $breakdown['BI Award'] = $biReward;
                }else{
                    $biReward =  0;
                    $totalReward += $biReward;
                    $breakdown['BI Award'] = $biReward;
                }
            // Bonus Incentive End

            // Strategic Incentive Start

                    $proposalIds = DB::table('et_customer')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function ($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_proposal.post_sale_check', 1)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_proposal.created_by', $staff->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0, 1, 2])
                                ->where('et_proposal.status', 0)
                                ->pluck('et_proposal.sno');

                        $collectionsINR = DB::table('et_transaction')
                                ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->whereIn('et_payment.proposal_id', $proposalIds)
                                ->where('et_transaction.payment_status', 1)
                                ->groupBy('et_payment.proposal_id')
                                ->select(
                                    'et_payment.proposal_id',
                                    DB::raw('SUM(et_transaction.total_amount_inr) as total_inr')
                                )
                                ->pluck('total_inr', 'proposal_id');

                            $collectionsOriginal = DB::table('et_transaction')
                                ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->whereIn('et_payment.proposal_id', $proposalIds)
                                ->where('et_transaction.payment_status', 1)
                                ->groupBy('et_payment.proposal_id')
                                ->select(
                                    'et_payment.proposal_id',
                                    DB::raw('SUM(et_transaction.total_amount) as total_original')
                                )
                                ->pluck('total_original', 'proposal_id');

                            $gst_percent = 18;
                            $totalSelling = 0;
                            $totalActual = 0;

                            $totalProfitNet = 0;
                            $totalCollectionNet = 0;

                            $gst_percent = 18;

                            $proposalData = DB::table('et_proposal')
                                ->whereIn('et_proposal.sno', $proposalIds)
                                ->select('et_proposal.sno as proposal_id','et_proposal.discount_amount')
                                ->get();

                            

                            foreach ($proposalData as $row) {

                                $proposalId = $row->proposal_id;
                                $productOriginal = DB::table('et_proposal_product_cart')
                                    ->where('proposal_sno', $proposalId)
                                    ->sum('original_amount');
                                $productCustom = DB::table('et_proposal_product_cart')
                                    ->where('proposal_sno', $proposalId)
                                    ->sum('product_amount');
                                $packageOriginal = DB::table('et_proposal_package_cart')
                                    ->where('proposal_sno', $proposalId)
                                    ->sum('original_product_amount');
                                $packageCustom = DB::table('et_proposal_package_cart')
                                    ->where('proposal_sno', $proposalId)
                                    ->sum('cust_product_amount');
                                $discountAmount = $row->discount_amount ?? 0 ;
                                $original = $productOriginal + $packageOriginal ;
                                $custom = ($productCustom + $packageCustom) - $discountAmount;
                                if ($custom <= 0 || $original <= 0) {
                                    continue;
                                }
                                if ($custom <= $original) {
                                    continue;
                                }

                                $proposal = DB::table('et_proposal')
                                    ->where('sno', $proposalId)
                                    ->first();

                                $profitAmount = $custom - $original;

                                $profitPercentage =($profitAmount / $custom) * 100;

                                $rewardPercent = 0;
                                $matchedSlab = 'No Slab';

                                foreach ($si_slabs as $slab) {

                                    $min = (float) $slab['min'];
                                    $max = (float) $slab['max'];

                                    if ($profitPercentage >= $min && $profitPercentage <= $max) {

                                        $rewardPercent = (float) $slab['percentage'];
                                        $matchedSlab = "{$min}% - {$max}%";
                                        break;
                                    }
                                    // keep updating to the latest slab.
                                    if ($profitPercentage > $max) {
                                        $rewardPercent = (float) $slab['percentage'];
                                        $matchedSlab = "{$min}% - {$max}%";
                                    }
                                }

                                if ($profitPercentage > $highestProfitPercentage) {
                                    $highestProfitPercentage = $profitPercentage;
                                    $highestMatchedSlab = $matchedSlab;
                                    $highestRewardPercent = $rewardPercent;
                                }

                                if ($rewardPercent <= 0) {
                                    continue;
                                }

                                $profitAmountInr = $profitAmount;

                                if ($proposal->currency_id != 70) {

                                    $currency = DB::table('et_country_currencies')
                                        ->where('sno', $proposal->currency_id)
                                        ->value('currency_code');

                                    $profitAmountInr =
                                        $helper->ConvertedAmountInr(
                                            $currency,
                                            $profitAmount
                                        );
                                }

                                $proposalReward =
                                    ($profitAmountInr * $rewardPercent) / 100;

                                $siRewardAmount += $proposalReward;

                                $proposalWiseDetails[] = [

                                    'proposal_id' => $proposalId,

                                    'profit_percent' =>
                                        round($profitPercentage, 2),

                                    'profit_amount' =>
                                        round($profitAmountInr),

                                    'reward_percent' =>
                                        $rewardPercent,

                                    'reward_amount' =>
                                        round($proposalReward),

                                    'slab' =>
                                        $matchedSlab,
                                ];
                            }


                    $siStatus = $siRewardAmount > 0;
                    $siReward = round($siRewardAmount);

                    if($tenxStatus && $siStatus) {
                        $siReward = $siReward;
                        $totalReward += $siReward;
                        $breakdown['SI Award'] = $siReward;
                    }else{
                        $siReward =  0;
                        $totalReward += $siReward;
                        $breakdown['SI Award'] = $siReward;
                    }

            // Strategic Incentive End

            // Profitable Incentive Start

                $proposalPayslotFirstIds = DB::table('et_proposal_pay_slot')
                        ->whereIn('proposal_sno', $proposalIds)
                        ->where('status', 0)
                        ->where('first_milestone', 1)
                        ->pluck('sno');

                $firstSalesCollection = DB::table('et_payment')
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->whereIn('et_payment.pay_slot_id', $proposalPayslotFirstIds)
                        ->where('et_payment.status', 0)
                        ->where('et_transaction.payment_status', 1)
                        ->select(
                            'et_transaction.total_amount_inr',
                            'et_proposal.currency_id',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                        ->get();

                $baseFirstSalesCollection = $firstSalesCollection->sum(function ($row) use ($gst_percent) {
                    
                    if ( $row->currency_id != 70 &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                        return $row->total_amount_inr;
                    }else{
                        return $row->total_amount_inr / (1 + ($gst_percent / 100));
                    }
                    
                });
                
                $AveragePiCollection = $customerConvertCount > 0 ? $baseFirstSalesCollection / $customerConvertCount : 0;;
                $piCollectionValue = $AveragePiCollection;
                $piHighestreward = collect($pi_slabs)->max('reward') ?? 0;

                foreach ($pi_slabs as $slab) {
                    $min = $slab['min'];
                    $max = $slab['max'];

                    if (
                        $piCollectionValue >= $min &&
                        ($max === null || $piCollectionValue <= $max)
                    ) {
                        $matchedSlabSI = $min . ' - ' . ($max ?? 'Above');
                        $piReward = $slab['reward'];
                        $slabMin = $min;
                        $slabMax = $max;
                        break;
                    }
                }

                $prfStatus = $piReward > 0;

                if ($tenxStatus && $prfStatus) {
                    $piReward = $piReward;
                    $totalReward += $piReward;
                    $breakdown['PRF Award'] = $piReward;
                }else{
                    $piReward =  0;
                    $totalReward += $piReward;
                    $breakdown['PRF Award'] = $piReward;
                }

            // Profitable Incentive End

            // Performance Incentive Start

                $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;

                $actualOutgoingCallCount=0;
                $actualMissedCallRate=0;
                $actualMissedCount=0;

                $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->sno)
                    ->first();

                $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                
                $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                $actualOutgoingPerDay=round($actualOutgoingPerDay);

                // Missed call ratio
                $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count + $actualCallCount->rejected_call_count;
                $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                $actualMissedCallRate=round($actualMissedCallRate,1);

                $piStatus = (
                    $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                    $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                );
                $performanceReward = $incentive->performance_incentive_reward ?? 0 ;

                if ($tenxStatus && $piStatus) {
                    $totalReward += $performanceReward;
                    $breakdown['PI Award'] = $performanceReward;
                }else{
                    $performanceReward =  0;
                    $totalReward += $performanceReward;
                    $breakdown['PI Award'] = $performanceReward;
                }

            // Performance Incentive End

            // Luxury Incentive Start
                $luxury = json_decode($incentive->luxury_incentive ?? '{}', true);
                $allIncentivesAchieved = ($tenxStatus  && $siStatus && $eciStatus && $biStatus && $piStatus && $prfStatus);

                if ($allIncentivesAchieved) {
                    $liReward = $luxury['reward'] ?? 0;
                    $totalReward += $liReward;
                    $breakdown['LI Award'] = $liReward;
                }else{
                    $liReward =  0;
                    $totalReward += $liReward;
                    $breakdown['LI Award'] = $liReward;
                }
            // Luxury Incentive End

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetConversion,
        'actual' => $actualConversion,
      ]
    ];
  }

  /**
   * Calculate Team Lead Reward
   */
  private static function calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    // Check if sales lead check is enabled
    $checkRecord = GoalSetStaffModel::where('branch_id', $branchId)
      ->where('goal_month', $month)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->where('staff_id', $staff->sno)
      ->first();

    if ($checkRecord && $checkRecord->sales_lead_check == 1) {
      // Sales Team Lead - use sales executive logic but aggregated for team
      return self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
    } else {
      // Regular Team Lead - aggregate from executives
      $executives = StaffModel::where('branch_id', $branchId)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $totalTeamReward = 0;
      $teamBreakdown = [];

      foreach ($executives as $executive) {
        $executiveGoalData = GoalSetStaffModel::where('staff_id', $executive->sno)
          ->where('goal_month', $month)
          ->whereYear('goal_date', $year)
          ->first();

        if ($executiveGoalData && ($executiveGoalData->conversion ?? 0) > 0) {
          $result = self::calculateSalesExecutiveReward($executive, $incentive, $executiveGoalData, $branchId, $year, $month);

          if ($result['metrics']['tenx_status'] ?? false) {
            $totalTeamReward += $incentive->tenx_award ?? 0;
            $teamBreakdown[$executive->staff_name] = $incentive->tenx_award ?? 0;
          }
        }
      }

      return [
        'total' => $totalTeamReward,
        'breakdown' => $teamBreakdown,
        'metrics' => ['team_size' => count($executives)]
      ];
    }
  }

  /**
   * Calculate Collection Reward
   */
  private static function calculateJournalExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

  

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth();

      $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
      $lastTwoMonths = [
          $currentMonthJournal->copy()->subMonth(1),
          $currentMonthJournal->copy()->subMonth(2),
      ];
    

      $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->sno)
          ->where('status_10x', 1)
          ->where(function ($query) use ($lastTwoMonths) {
              foreach ($lastTwoMonths as $date) {
                  $query->orWhere(function ($q) use ($date) {
                      $q->whereMonth('goal_date', $date->month)
                      ->whereYear('goal_date', $date->year);
                  });
              }
          })
          ->get();

      $isConsistent = $goalsetteamLast->count() == 2;
             
        $branch = BranchModel::where('sno', $branchId)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
        

      $publish_target= $goalData->no_of_papers ?? 8;

        if( $incentive ){
            $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
            $tenx_amount = $incentive->tenx_award ?? 0;
            $exiTarget = $publish_target ?? 0;
            $exiAcheiveAmount = $incentive->extra_acheive_award ?? 0;
            $doubleXITarget = $publish_target ? $publish_target*2 : 0;
            $doubleXIAmount= $incentive->doublex_award ?? 0;
            $perform_attend_percent= $incentive->perform_incent_attend ?? 0;
            $performance_incentive_reward = $incentive->performance_incentive_reward ?? 0;
        }else{
            $check_accepted_paper=1;
            $tenx_amount =  0;
            $exiTarget = 0;
            $exiAcheiveAmount =  0;
            $doubleXITarget =  0;
            $doubleXIAmount=  0;
            $perform_attend_percent=  0;
            $performance_incentive_reward =  0;
        }
            $publicationCurrentMonthCount = 0;
            
            $tenxStatus = false;
            $exiStatus = false;
            $doubleXIncent = false;
            $permformJCIncent = false;
            $priviousGoalsetAwared = $isConsistent ? true:false;



            $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                ->leftJoin('et_journal_history as jh', function ($join) {
                    $join->on('mj.sno', '=', 'jh.journal_id')
                        ->where('jh.status', 5);
                });

            if ($check_accepted_paper == 1) {
                //  Added 7 here
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
            }

            $publicationCurrentMonthCount = $publicationCurrentMonthCount
                ->where('cs.jc_staff', $staff->sno)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                        $q->whereIn('mj.status', [5, 7]) //  include 7 here also
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month);
                    });

                })
                ->count();

            $publicationCurrentMonthData = DB::table('et_manage_journal as mj')
                ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                ->leftJoin('et_journal_history as jh', function ($join) {
                    $join->on('mj.sno', '=', 'jh.journal_id')
                        ->where('jh.status', 5);
                });

            if ($check_accepted_paper == 1) {
                $publicationCurrentMonthData = $publicationCurrentMonthData->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationCurrentMonthData = $publicationCurrentMonthData->where('mj.status', 8);
            }

            $publicationCurrentMonthData = $publicationCurrentMonthData
                ->where('cs.jc_staff', $staff->sno)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                        $q->whereIn('mj.status', [5, 7])
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month);
                    });

                })
                  ->orderByRaw("
                    CASE 
                        WHEN mj.status IN (5, 7) THEN jh.accepted_date
                        ELSE mj.publish_date
                    END ASC
                ")
                ->limit($exiTarget)
                ->pluck('mj.sno');
                        
        $publicationAfter15thCount = DB::table('et_manage_journal as mj')
            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
            ->leftJoin('et_journal_history as jh', function ($join) {
                $join->on('mj.sno', '=', 'jh.journal_id')
                    ->where('jh.status', 5);
            });
              if ($check_accepted_paper == 1) {
                $publicationAfter15thCount = $publicationAfter15thCount->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationAfter15thCount = $publicationAfter15thCount->where('mj.status', 8);
            }

            $publicationAfter15thCount = $publicationAfter15thCount
                ->where('cs.jc_staff', $staff->sno)
                ->whereNotIn('mj.sno',$publicationCurrentMonthData)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month)
                        ->whereDay('mj.publish_date', '<=', 15);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                          $q->whereIn('mj.status', [5, 7])
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month)
                        ->whereDay('jh.accepted_date', '<=', 15);
                    });

                })
                ->count();
                        
            
            $tenxStatus = ($publicationCurrentMonthCount >=$publish_target);
            $exiStatus = ($publicationCurrentMonthCount >=$exiTarget);
            $exiAmountAward = $publicationAfter15thCount > 0 ? $publicationAfter15thCount *$exiAcheiveAmount : 0;
            $doubleXIncent = ($publicationCurrentMonthCount >=$doubleXITarget);

              $startDate = Carbon::create($year, $month, 1);
            $currentDate = Carbon::now();
            $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

            $dayCounts = 0;
            $dateSrt = $startDate->copy();
            while ($dateSrt->lte($endDate)) {
                if (!$dateSrt->isSunday()) {
                    $dayCounts++;
                }
                $dateSrt->addDay();
            }
            
          
            $presentDays = DB::table('et_staff_attendance')
                ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                ->where('et_staff_attendance.staff_id', $staff->sno) 
                // ->where('et_staff_attendance.staff_id', 62) 
                ->whereYear('et_staff_attendance.date', $year)
                ->whereMonth('et_staff_attendance.date', $month)
                ->count();
            
            $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
          
          $permformJCIncent = (
                $attendance_percent > 0 && 
                $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
            );

            $breakdown['10X Award'] = $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $totalReward +=  $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $breakdown['Bonus Award'] = ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0;
            $totalReward += ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0;
            $breakdown['2X Award'] =  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;
            $totalReward +=  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;
            $breakdown['Performance'] =  ($tenxStatus && $permformJCIncent)? ($performance_incentive_reward) : 0;
            $totalReward +=  ($tenxStatus && $permformJCIncent)? ($performance_incentive_reward) : 0;
           
    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $publish_target,
        'actual' => $publicationCurrentMonthCount,
        'published_amount' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
        'bonus_amount' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
      ]
    ];
  }

  private static function calculateJournalTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

  

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth();

      $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
      $lastTwoMonths = [
          $currentMonthJournal->copy()->subMonth(1),
          $currentMonthJournal->copy()->subMonth(2),
      ];
    

      $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->sno)
          ->where('status_10x', 1)
          ->where(function ($query) use ($lastTwoMonths) {
              foreach ($lastTwoMonths as $date) {
                  $query->orWhere(function ($q) use ($date) {
                      $q->whereMonth('goal_date', $date->month)
                      ->whereYear('goal_date', $date->year);
                  });
              }
          })
          ->get();

      $isConsistent = $goalsetteamLast->count() == 2;
             
        $branch = BranchModel::where('sno', $branchId)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
        

      $publish_target= $goalData->no_of_papers ?? 8;

        if( $incentive ){
            $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
            $tenx_amount = $incentive->tenx_award ?? 0;
            $exiTarget = $publish_target ?? 0;
            $exiAcheiveAmount = $incentive->extra_acheive_award ?? 0;
            $doubleXITarget = $publish_target ? $publish_target*2 : 0;
            $doubleXIAmount= $incentive->doublex_award ?? 0;
            $perform_attend_percent= $incentive->perform_incent_attend ?? 0;
            $performance_incentive_reward = $incentive->performance_incentive_reward ?? 0;
        }else{
            $check_accepted_paper=1;
            $tenx_amount =  0;
            $exiTarget = 0;
            $exiAcheiveAmount =  0;
            $doubleXITarget =  0;
            $doubleXIAmount=  0;
            $perform_attend_percent=  0;
            $performance_incentive_reward =  0;
        }
            $publicationCurrentMonthCount = 0;
            
            $tenxStatus = false;
            $exiStatus = false;
            $doubleXIncent = false;
            $permformJCIncent = false;
            $priviousGoalsetAwared = $isConsistent ? true:false;



            $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                ->leftJoin('et_journal_history as jh', function ($join) {
                    $join->on('mj.sno', '=', 'jh.journal_id')
                        ->where('jh.status', 5);
                });

            if ($check_accepted_paper == 1) {
                //  Added 7 here
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
            }

            $publicationCurrentMonthCount = $publicationCurrentMonthCount
                ->where('cs.jc_id', $staff->sno)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                        $q->whereIn('mj.status', [5, 7]) //  include 7 here also
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month);
                    });

                })
                ->count();
           

            
                        
            
            $tenxStatus = ($publicationCurrentMonthCount >=$publish_target);
            
            $doubleXIncent = ($publicationCurrentMonthCount >=$doubleXITarget);

              $startDate = Carbon::create($year, $month, 1);
            $currentDate = Carbon::now();
            $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

            $dayCounts = 0;
            $dateSrt = $startDate->copy();
            while ($dateSrt->lte($endDate)) {
                if (!$dateSrt->isSunday()) {
                    $dayCounts++;
                }
                $dateSrt->addDay();
            }
            
          
            $presentDays = DB::table('et_staff_attendance')
                ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                ->where('et_staff_attendance.staff_id', $staff->sno) 
                // ->where('et_staff_attendance.staff_id', 62) 
                ->whereYear('et_staff_attendance.date', $year)
                ->whereMonth('et_staff_attendance.date', $month)
                ->count();
            
            $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
          
          $permformJCIncent = (
                $attendance_percent > 0 && 
                $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
            );

            $breakdown['10X Award'] = $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $totalReward +=  $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $breakdown['2X Award'] =  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;
            $totalReward +=  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;              
                       
           
    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $publish_target,
        'actual' => $publicationCurrentMonthCount,
        'published_amount' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
        'bonus_amount' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
      ]
    ];
  }


  /**
   * Calculate CRE (Customer Relationship Executive) Reward
   */
  private static function calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month){
    $totalReward = 0;
    $breakdown = [];

        $helper = new \App\Helpers\Helpers();

        $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $targetTenx = $goalsetData[$staff->sno]->no_of_reviews ?? 0;
        if($incentive){
            $eci_target = $incentive->eci_count ?? 0;
            $bi_target_percent = $incentive->bi_amount ?? 0;
            $bi_target = $targetTenx ?? 0;
            $spot_cre_incentive_target = $incentive->spot_incentive_percent ?? 0;
            $spot_cre_incentive_reward = $incentive->spot_incentive_month ?? 0;
            $ri_reward = $incentive->ri_amount ?? 0;
        }else{
            $eci_target = 70;
            $bi_target = $targetTenx ;
            $bi_target_percent = 2;
            $spot_cre_incentive_target = 80;
            $spot_cre_incentive_reward = 2000;
            $ri_reward = 750;
        }
                
        
                    $helper = new \App\Helpers\Helpers();

                    $review_count = DB::table('et_manage_review')
                            ->where('branch_id', $branchId)
                            ->where('created_by', $staff->sno)
                            ->where('status', 0)
                            ->whereYear('created_at', $year)
                            ->whereMonth('created_at', $month)
                            ->count();
                    
                
                    $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
                    $tenxStatus = false;
                    $actaulTenx = 0;
                    $gstPercentage=18;
                    $actaulTenx = $review_count ?? 0;

                    // Referal Incentive
                    $cre_ref_count =  DB::table('et_proposal')
                        ->select(
                            'et_proposal.service_title',
                            'et_customer.sno',
                            'et_customer.cus_name',
                            'et_customer.country_code',
                            'et_customer.cus_mobile',
                            'et_payment.transaction_date as created_date',
                            'et_payment.transaction_date as created_at',
                            'et_transaction.payment_id',
                            'et_transaction.sno as transaction_id',
                            'et_payment.paid_amount'
                        )
                        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->where('et_proposal.branch_id', $branchId)
                        ->where('et_proposal.referral_id', $staff->sno)
                        ->where('et_proposal.status', 0)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_payment.status', 0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->count();

                    // return $cre_spot;

                
                    $collection = 0;
                   
                    $tenxStatus = $targetTenx > 0 ? $actaulTenx >= $targetTenx : false;
                    
                
                    $bi_achieved = (($bi_target) && $collectionPercentage > $bi_target) ? true : false;
                    $bi_reward = $bi_achieved ? $bonusAmount : 0;

                    // ! Referal Incentive
                    $ri_amount = ($cre_ref_count ?? 0) * $ri_reward;
                    $ri_achieved = $ri_amount > 0;
                    $drop_collection_reward = $incentive ? $incentive->drop_collection_reward : 0;

                    $dropCustomerIds = DB::table('et_customer') ->where('et_customer.drop_refund_id', '!=' ,0) ->where('et_customer.drop_verified' ,1) ->pluck('et_customer.sno');

                    $dropCollection = DB::table('et_payment')
                        ->join('et_transaction','et_transaction.payment_id','=','et_payment.sno')
                        ->join('et_customer','et_customer.sno','=','et_payment.customer_id')
                        ->join('et_proposal','et_proposal.sno','=','et_payment.proposal_id')
                        ->join('et_country_currencies','et_country_currencies.sno','=','et_proposal.currency_id')

                        ->where('et_transaction.payment_status',1)
                        ->where('et_customer.status',0)
                        ->where('et_proposal.status',0)

                        ->where('et_proposal.cre_id',$staff->sno)

                        ->whereIn('et_customer.sno',$dropCustomerIds)

                        ->whereYear('et_payment.transaction_date',$year)
                        ->whereMonth('et_payment.transaction_date',$month)

                        ->select(
                            'et_transaction.total_amount_inr',
                            'et_payment.paid_amount',
                            'et_country_currencies.currency_code',
                            'et_proposal.gst_perc',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )

                        ->get()

                        ->map(function($row) use($helper,$gstPercentage){
                            if($row->total_amount_inr > 0){
                                $amount = $row->total_amount_inr;
                            }elseif($row->currency_code != 'INR'){
                                $amount = $helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->paid_amount
                                );
                            }else{
                                $amount = $row->paid_amount;
                            }

                            $gstRate = $row->gst_perc > 0
                                ? ($row->gst_perc/100)
                                : ($gstPercentage/100);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amount, 2);
                            }

                            return round($amount/(1+$gstRate),2);

                        });

                    $dropCollectionAmount = round($dropCollection->sum(),2);
                    $dropCollectionReward = round( $dropCollectionAmount * (($drop_collection_reward ?? 5)/100),  2 );
                     $dropCollectionAchieved = $dropCollectionAmount > 0;
                     $targetIssueCount=0;
                     $actaulIssueCount=0;
                    $issueFreeStatus = false;

                $totalReward  += $tenxStatus ? $incentive->tenx_award : 0;
                $totalReward  += ($tenxStatus && $dropCollectionAchieved) ? ($incentive->issue_free ?? 0) : 0 ;
                $totalReward  += ( $ri_achieved) ? $ri_amount : 0;
                $totalReward  += ($tenxStatus && $dropCollectionAchieved) ? $dropCollectionReward : 0 ;
           
                $breakdown['10X Award'] = $tenxStatus ? $incentive->tenx_award : 0;
                $breakdown['ISSUE Award'] = ($tenxStatus && $issueFreeStatus) ? ($incentive->issue_free ?? 0) : 0 ;
                $breakdown['REI Award'] = ( $ri_achieved) ? $ri_amount : 0;
                $breakdown['DROP Award'] =($tenxStatus && $dropCollectionAchieved) ? $dropCollectionReward : 0 ;
    
 

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'target_issue' => $targetIssueCount,
        'actual_issue' => $actaulIssueCount,
        'drop_collection' => round($dropCollectionAmount),
        'referrals' => $cre_ref_count
      ]
    ];
  }
  private static function calculateCollectionReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
        $totalReward = 0;
        $breakdown = [];

        $helper = new \App\Helpers\Helpers();

        $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        

            $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
            $tenxStatus = false;
            $actaulTenx = 0;
            $gstPercentage=18;

      

               $collection = 0;

                
               
                    $helper = new \App\Helpers\Helpers();
                    
                    $firstPayIds = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal_pay_slot.status', 0)
                        ->where('et_proposal.collection_id', $staff->sno)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                        ->groupBy('et_proposal_pay_slot.proposal_sno')
                        ->orderBy('first_id', 'asc')
                        ->pluck('first_id');

                    
                    $targetTenx = $goalsetData[$staff->sno]->harvesting_percentage ?? 0;

                    if($incentive){
                        $eci_target = $incentive->eci_count ?? 0;
                        $bi_collection_reward = $incentive->bi_collection_reward ?? 0;
                        $bi_target_percent = $incentive->bi_amount ?? 0;
                        $bi_target = $targetTenx ?? 0;
                        $spot_cre_incentive_target = $incentive->spot_incentive_percent ?? 0;
                        $spot_cre_incentive_reward = $incentive->ondate_collection_reward ?? 0;
                        $ri_reward = $incentive->ri_amount ?? 0;
                        $old_month_collection_reward = $incentive->old_month_collection_reward ?? 0;
                        $drop_collection_reward = $incentive->drop_collection_reward ?? 0;
                        $old_month_per = $incentive->old_month_per ?? 0;
                    }else{
                        $eci_target = 70;
                        $bi_target = $targetTenx ;
                        $bi_target_percent = 2;
                        $spot_cre_incentive_target = 80;
                        $spot_cre_incentive_reward = 2000;
                        $ri_reward = 750;
                        $old_month_collection_reward = 2000;
                        $drop_collection_reward = 5;
                        $old_month_per =  0;
                        $bi_collection_reward =  2000;
                    }
                    
                
                    $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
                    $tenxStatus = false;
                    $actaulTenx = 0;
                    $gstPercentage=18;

                    

                    $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                    ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                    ->where('et_customer.status', 0)
                    ->where('et_proposal.collection_id', $staff->sno)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('pay_slot_id', 'asc')
                    ->pluck('pay_slot_id');

                    $branch = BranchModel::where('sno', $branchId)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->first();
                    
                    $tragetHarvesting = DB::table('et_proposal_pay_slot')
                        ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->where('et_lead.created_by', '>', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                        ->where('et_customer.status', 0)
                        ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                        ->where('et_proposal.collection_id', $staff->sno)
                        ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                        ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                        ->select(
                            "et_proposal_pay_slot.payable_amount as payable_amount",
                            "et_transaction.payment_status",
                            "et_transaction.total_amount_inr",
                            "et_payment.paid_amount",
                            "et_proposal.gst_perc",
                            "et_country_currencies.currency_code as currency_code",
                        )
                        ->get()
                        ->map(function ($row) use ($gstPercentage, $helper, $year, $month, $branch) {

                            $gstRate = $row->gst_perc > 0
                                ? $row->gst_perc / 100
                                : ($branch ? $gstPercentage / 100 : 0.18);

                            $skipGst = (
                                $row->currency_code != 'INR' &&
                                (
                                    $year > 2026 ||
                                    ($year == 2026 && $month >= 6)
                                )
                            );

                            if ($row->payment_status == 1) {

                                if ($row->currency_code != "INR") {
                                    $converted = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                        ? $row->total_amount_inr
                                        : $row->paid_amount;
                                } else {
                                    $converted = $row->paid_amount;
                                }

                                $netAmount = $skipGst
                                    ? $converted
                                    : $converted / (1 + $gstRate);

                            } elseif ($row->currency_code != "INR") {

                                $converted = $helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->payable_amount
                                );

                                $netAmount = $skipGst
                                    ? $converted
                                    : $converted / (1 + $gstRate);

                            } else {

                                $converted = $row->payable_amount;

                                $netAmount = $converted / (1 + $gstRate);
                            }

                            return $netAmount;
                        })
                       
                        ->reduce(function ($carry, $item) {
                            // Sum the values and round to 1 decimal place
                            return $carry + $item;
                        }, 0);
                
        
                    $tragetHarvesting = round($tragetHarvesting);
                
                
                    $collectionHarvesting = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.collection_id', $staff->sno)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    // ->whereYear('et_payment.transaction_date', $year)
                    // ->whereMonth('et_payment.transaction_date', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code",
                        DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                        DB::raw('MONTH(et_payment.transaction_date) as trans_month')

                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                        
                        
                        if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                            return round($amountInr, 2);
                        }
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                    $collectionHarvesting = round($collectionHarvesting, 1);
                    
                    
                    
                    $collectionEci = DB::table('et_proposal_pay_slot')
                        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->where('et_lead.created_by', '>', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                        ->where('et_customer.status', 0)
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_proposal.collection_id', $staff->sno)
                        ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                        ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                        ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                        ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                        ->select(
                            "et_proposal_pay_slot.payable_amount as payable_amount",
                            "et_transaction.payment_status",
                            "et_transaction.total_amount_inr",
                            "et_payment.paid_amount",
                            "et_proposal.gst_perc",
                            "et_country_currencies.currency_code as currency_code",
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                        ->get()
                        ->map(function ($row) use ($gstPercentage, $helper) {
                            // ✅ Prefer INR amount from transaction if available
                            $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                ? $row->total_amount_inr
                                : $row->paid_amount;
                    
                            // ✅ Use proposal-specific GST, fallback to branch GST
                            $gstRate = $row->gst_perc > 0
                                ? $row->gst_perc / 100
                                : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amountInr, 2);
                            }
                    
                            // ✅ Net without GST
                            $netAmount = $amountInr / (1 + $gstRate);
                    
                            // Round the net amount to two decimal places
                            return round($netAmount, 2);
                        })
                        ->reduce(function ($carry, $item) {
                            // Sum the values and round to 2 decimal places
                            return round($carry + $item, 2);
                        }, 0);

                    $collectionEci = round($collectionEci, 1);


                    $previousMonth = Carbon::create($year, $month, 1)->subMonth();

                    $oldCollectionTarget = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_country_currencies', 'et_country_currencies.sno', '=', 'et_proposal.currency_id')
                        ->where('et_customer.status',0)
                        ->where('et_proposal.status',0)
                        ->where('et_proposal.collection_id',$staff->sno)
                        ->where('et_proposal_pay_slot.payable_amount','>',0)
                        ->whereNotExists(function ($q) use ($year , $month) {
                            $q->select(DB::raw(1))
                            ->from('et_payment')
                            ->join('et_transaction','et_transaction.payment_id','=','et_payment.sno')
                            ->whereColumn( 'et_payment.pay_slot_id','et_proposal_pay_slot.sno')
                            ->where('et_transaction.payment_status',1)
                            ->whereYear('et_payment.transaction_date','<=', $year)
                            ->whereMonth('et_payment.transaction_date','<=', $month);
                        })
                        ->where(function ($q) use ($year, $month) {
                            $q->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
                            ->orWhere(function ($q) use ($year, $month) {
                                $q->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                                    ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
                            });
                        })
                        ->select(
                            'et_proposal_pay_slot.sno',
                            'et_proposal_pay_slot.payable_amount',
                            'et_country_currencies.currency_code',
                            'et_proposal.gst_perc',
                            DB::raw('YEAR(et_proposal_pay_slot.nextPayDate) as trans_year'),
                            DB::raw('MONTH(et_proposal_pay_slot.nextPayDate) as trans_month')
                        )
                        ->get()
                        ->map(function ($row) use ($helper,$gstPercentage){

                            if($row->currency_code != 'INR'){
                                $amount = $helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->payable_amount
                                );
                            }else{
                                $amount = $row->payable_amount;
                            }

                            $gstRate = $row->gst_perc>0
                                ? ($row->gst_perc/100)
                                : ($gstPercentage/100);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amount, 2);
                            }

                            return $amount/(1+$gstRate);

                        });

                    $oldCollectionTargetAmount = round($oldCollectionTarget->sum(),2);

                    $oldCollectionActual = DB::table('et_payment')
                        ->join('et_transaction','et_transaction.payment_id','=','et_payment.sno')
                        ->join('et_proposal_pay_slot','et_proposal_pay_slot.sno','=','et_payment.pay_slot_id')
                        ->join('et_proposal','et_proposal.sno','=','et_payment.proposal_id')
                        ->join('et_customer','et_customer.sno','=','et_payment.customer_id')
                        ->join('et_country_currencies','et_country_currencies.sno','=','et_proposal.currency_id')
                        ->where('et_transaction.payment_status',1)
                        ->where('et_customer.status',0)
                        ->where('et_proposal.status',0)
                        ->where('et_proposal.collection_id',$staff->sno)

                        // Previous month pending
                        ->where(function ($q) use ($year, $month) {
                            $q->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
                            ->orWhere(function ($q) use ($year, $month) {
                                $q->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                                    ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
                            });
                        })

                        // Paid this month
                        ->whereYear('et_payment.transaction_date',$year)
                        ->whereMonth('et_payment.transaction_date',$month)

                        ->select(
                            'et_transaction.total_amount_inr',
                            'et_payment.paid_amount',
                            'et_country_currencies.currency_code',
                            'et_proposal.gst_perc',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                        ->get()
                        ->map(function($row) use($helper,$gstPercentage){

                            if($row->total_amount_inr>0){

                                $amount=$row->total_amount_inr;

                            }elseif($row->currency_code!='INR'){

                                $amount=$helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->paid_amount
                                );

                            }else{

                                $amount=$row->paid_amount;

                            }

                            $gstRate=$row->gst_perc>0
                                ? ($row->gst_perc/100)
                                : ($gstPercentage/100);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amount, 2);
                            }

                            return $amount/(1+$gstRate);

                        });

                    $oldCollectionActualAmount=round($oldCollectionActual->sum(),2);
                    $oldCollectionPercentage = 0;

                    if($oldCollectionTargetAmount>0){
                        $oldCollectionPercentage=round( ($oldCollectionActualAmount/$oldCollectionTargetAmount)*100, 2 );
                    }

                    $oldCollectionPendingPercentage = 100 - $oldCollectionPercentage;

                    // Prevent negative values if collection exceeds target
                    $oldCollectionPendingPercentage = max(0, $oldCollectionPendingPercentage);

                    $oldCollectionAchieved = false;

                    if (($old_month_per ?? 0) >= 0) {
                        $oldCollectionAchieved = $oldCollectionPendingPercentage <= $old_month_per;
                    }

                    $oldCollectionReward = $oldCollectionAchieved ? ($old_month_collection_reward ?? 0): 0;

                    $spotCollection = DB::table('et_proposal_pay_slot')
                        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_country_currencies', 'et_country_currencies.sno', '=', 'et_proposal.currency_id')

                        ->where('et_transaction.payment_status',1)
                        ->where('et_customer.status',0)
                        ->where('et_proposal.status',0)
                        ->where('et_proposal.collection_id',$staff->sno)
                        ->whereYear('et_proposal_pay_slot.initialPayDate',$year)
                        ->whereMonth('et_proposal_pay_slot.initialPayDate',$month)
                        ->whereColumn('et_payment.transaction_date','<=','et_proposal_pay_slot.nextPayDate')
                        ->select(
                            'et_transaction.total_amount_inr',
                            'et_payment.paid_amount',
                            'et_country_currencies.currency_code',
                            'et_proposal.gst_perc',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                        ->get()
                        ->map(function($row) use($helper,$gstPercentage){
                            if($row->total_amount_inr>0){
                                $amount=$row->total_amount_inr;
                            }elseif($row->currency_code!='INR'){
                                $amount=$helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->paid_amount
                                );
                            }else{
                                $amount=$row->paid_amount;
                            }

                            $gstRate=$row->gst_perc>0
                                ? ($row->gst_perc/100)
                                : ($gstPercentage/100);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amount, 2);
                            }

                            return round($amount/(1+$gstRate),2);

                        });

                    $spotCollectionAmount = round($spotCollection->sum(),2);

                    $spotPercentage = 0;

                    if($tragetHarvesting > 0){

                        $spotPercentage = round(
                            ($spotCollectionAmount / $tragetHarvesting) * 100,
                            2
                        );

                    }

                    $spotAchieved = $spotPercentage >= ($spot_cre_incentive_target ?? 70);

                    $spotReward = $spotAchieved
                        ? ($spot_cre_incentive_reward ?? 0)
                        : 0;

                    $collectionSpot = DB::table('et_proposal_pay_slot')
                        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->where('et_lead.created_by', '>', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                        ->where('et_customer.status', 0)
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_proposal.collection_id', $staff->sno)
                        ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                        ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                        // ->whereYear('et_payment.transaction_date', $year)
                        // ->whereMonth('et_payment.transaction_date', $month)
                        ->select(
                            "et_proposal_pay_slot.payable_amount as payable_amount",
                            "et_transaction.payment_status",
                            "et_transaction.total_amount_inr",
                            "et_payment.paid_amount",
                            "et_proposal.gst_perc",
                            "et_country_currencies.currency_code as currency_code",
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                        ->get()
                        ->map(function ($row) use ($gstPercentage, $helper) {
                            // ✅ Prefer INR amount from transaction if available
                            $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                ? $row->total_amount_inr
                                : $row->paid_amount;
                    
                            // ✅ Use proposal-specific GST, fallback to branch GST
                            $gstRate = $row->gst_perc > 0
                                ? $row->gst_perc / 100
                                : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amountInr, 2);
                            }
                    
                            // ✅ Net without GST
                            $netAmount = $amountInr / (1 + $gstRate);
                    
                            // Round the net amount to two decimal places
                            
                            return round($netAmount, 2);
                        })
                        ->reduce(function ($carry, $item) {
                            // Sum the values and round to 2 decimal places
                            return round($carry + $item, 2);
                        }, 0);

                    $collectionSpot = round($collectionSpot, 1);
                    
                    $monthlyTargets = [];
                

                    // ! 10x Award
                    $monthlyCollectionsINR = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->groupBy('et_proposal.collection_id')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    $monthlyCollectionsOther = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', '!=', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->groupBy('et_proposal.collection_id', 'et_country_currencies.currency_code')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            'et_country_currencies.currency_code',
                            DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    $convertedCollections = [];
                    foreach ($monthlyCollectionsOther as $staffId => $target1) {
                        $convertedAmount = $helper->ConvertedAmountInr($target1->currency_code, $target1->monthly_collection);
                        if (!isset($convertedCollections[$staffId])) {
                            $convertedCollections[$staffId] = 0;
                        }
                        $convertedCollections[$staffId] += $convertedAmount;
                    }

                    $monthlyCollections = [];
                    foreach ($monthlyCollectionsINR as $staffId => $inrCollection) {
                        $monthlyCollections[$staffId] = [
                            'total_collection_inr' => $inrCollection->monthly_collection,
                        ];
                    }

                    // Add converted non-INR amounts to the collection array
                    foreach ($convertedCollections as $staffId => $convertedAmount) {
                        if (isset($monthlyCollections[$staffId])) {
                            $monthlyCollections[$staffId]['total_collection_inr'] += $convertedAmount;
                        } else {
                            $monthlyCollections[$staffId] = [
                                'total_collection_inr' => $convertedAmount,
                            ];
                        }
                    }

                    // ! Early Cash Incentive
                    $cre_eci_inr = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->groupBy('et_proposal.collection_id')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    $cre_eci_other = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', '!=', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->groupBy('et_proposal.collection_id', 'et_country_currencies.currency_code')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            'et_country_currencies.currency_code',
                            DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    $convertedCollectionsBy15th = [];
                    foreach ($cre_eci_other as $staffId => $target2) {
                        $convertedAmount = $helper->ConvertedAmountInr($target2->currency_code, $target2->collection_by_15th);

                        if (!isset($convertedCollectionsBy15th[$staffId])) {
                            $convertedCollectionsBy15th[$staffId] = 0;
                        }

                        $convertedCollectionsBy15th[$staffId] += $convertedAmount;
                    }

                    $collectionsBy15th = [];
                    foreach ($cre_eci_inr as $staffId => $inrCollection) {
                        $collectionsBy15th[$staffId] = [
                            'total_collection_eci' => $inrCollection->collection_by_15th,
                        ];
                    }

                    // Add converted foreign currency collections
                    foreach ($convertedCollectionsBy15th as $staffId => $convertedAmount) {
                        if (isset($collectionsBy15th[$staffId])) {
                            $collectionsBy15th[$staffId]['total_collection_eci'] += $convertedAmount;
                        } else {
                            $collectionsBy15th[$staffId] = [
                                'total_collection_eci' => $convertedAmount,
                            ];
                        }
                    }

                    // ! Spot Incentive
                    $cre_spot_INR = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                        ->groupBy('et_proposal.collection_id')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    $cre_spot_Other = DB::table('et_payment')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                        ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal.currency_id', 70)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                        ->groupBy('et_proposal.collection_id')
                        ->select(
                            'et_proposal.collection_id as staff_id',
                            DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                        )
                        ->get()
                        ->keyBy('staff_id');

                    // Convert foreign currency collections to INR
                    $convertedCollectionsSpotOther = [];
                    foreach ($cre_spot_Other as $staffId => $collection) {
                        $convertedAmount = $helper->ConvertedAmountInr($collection->currency_code ?? 'default_currency_code', $collection->monthly_collection_before_next_paydate);

                        if (!isset($convertedCollectionsSpotOther[$staffId])) {
                            $convertedCollectionsSpotOther[$staffId] = 0;
                        }

                        $convertedCollectionsSpotOther[$staffId] += $convertedAmount;
                    }

                    // Prepare INR collections
                    $collectionsSpotINR = [];
                    foreach ($cre_spot_INR as $staffId => $collection) {
                        $collectionsSpotINR[$staffId] = [
                            'total_collection_spot' => $collection->monthly_collection_before_next_paydate,
                        ];
                    }

                    // Combine converted foreign collections into INR collections
                    foreach ($convertedCollectionsSpotOther as $staffId => $convertedAmount) {
                        if (isset($collectionsSpotINR[$staffId])) {
                            $collectionsSpotINR[$staffId]['total_collection_spot'] += $convertedAmount;
                        } else {
                            $collectionsSpotINR[$staffId] = [
                                'total_collection_spot' => $convertedAmount,
                            ];
                        }
                    }


                    // Referal Incentive
                    $cre_ref_count =  DB::table('et_proposal')
                    ->select(
                        'et_proposal.service_title',
                        'et_customer.sno',
                        'et_customer.cus_name',
                        'et_customer.country_code',
                        'et_customer.cus_mobile',
                        'et_payment.transaction_date as created_date',
                        'et_payment.transaction_date as created_at',
                        'et_transaction.payment_id',
                        'et_transaction.sno as transaction_id',
                        'et_payment.paid_amount'
                    )
                    ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->where('et_proposal.branch_id', $branchId)
                    ->where('et_proposal.referral_id', $staff->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_payment.status', 0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->count();

                    $dropCustomerIds = DB::table('et_customer') ->where('et_customer.drop_refund_id', '!=' ,0) ->where('et_customer.drop_verified' ,1) ->pluck('et_customer.sno');

                    $dropCollection = DB::table('et_payment')
                        ->join('et_transaction','et_transaction.payment_id','=','et_payment.sno')
                        ->join('et_customer','et_customer.sno','=','et_payment.customer_id')
                        ->join('et_proposal','et_proposal.sno','=','et_payment.proposal_id')
                        ->join('et_country_currencies','et_country_currencies.sno','=','et_proposal.currency_id')

                        ->where('et_transaction.payment_status',1)
                        ->where('et_customer.status',0)
                        ->where('et_proposal.status',0)

                        ->where('et_proposal.cre_id',$staff->sno)

                        ->whereIn('et_customer.sno',$dropCustomerIds)

                        ->whereYear('et_payment.transaction_date',$year)
                        ->whereMonth('et_payment.transaction_date',$month)

                        ->select(
                            'et_transaction.total_amount_inr',
                            'et_payment.paid_amount',
                            'et_country_currencies.currency_code',
                            'et_proposal.gst_perc',
                            DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                            DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )

                        ->get()

                        ->map(function($row) use($helper,$gstPercentage){
                            if($row->total_amount_inr > 0){
                                $amount = $row->total_amount_inr;
                            }elseif($row->currency_code != 'INR'){
                                $amount = $helper->ConvertedAmountInr(
                                    $row->currency_code,
                                    $row->paid_amount
                                );
                            }else{
                                $amount = $row->paid_amount;
                            }

                            $gstRate = $row->gst_perc > 0
                                ? ($row->gst_perc/100)
                                : ($gstPercentage/100);

                            if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                                return round($amount, 2);
                            }

                            return round($amount/(1+$gstRate),2);

                        });

                    $dropCollectionAmount = round($dropCollection->sum(),2);
                    $dropCollectionReward = round(
                        $dropCollectionAmount * (($drop_collection_reward ?? 5)/100),
                        2
                    );

                    $dropCollectionAchieved = $dropCollectionAmount > 0;

                    $collection = 0;

                    // ! 10X Calculation
                    $collection = $collectionHarvesting ?? 0;
                    $collectionPercentage = $tragetHarvesting > 0 ? ($collection / $tragetHarvesting) * 100 : 0;
                    $collectionPercentage=round($collectionPercentage);
                    $tenxStatus = $targetTenx > 0 ? $collectionPercentage >= $targetTenx : false;
                    
                
                    // ! Early Cash Incentive
                    $eci_collection = $collectionEci ?? 0;
                    $eci_percentage = $tragetHarvesting > 0 ? ($eci_collection / $tragetHarvesting) * 100 : 0;
                    $eci_achieved = ($eci_target && $eci_percentage >= $eci_target) ? $eci_target : 0;

                    //  ! Spot Incentive
                    $spot_collection = $collectionSpot ??  0;
                    $spot_percentage = $collection > 0 ? round(($spot_collection / $collection) * 100) : 0;
                    $spot_achieved = $spot_percentage >= ($spot_cre_incentive_target ?? 0);
                    
                    $bi_value =0;
                    $bonusAmount =0;
                    $excessValue =0;
                    if ($collectionPercentage > $bi_target) {
                        $excessPercentage = $collectionPercentage - $bi_target;
                    
                        $excessValue = ($excessPercentage / 100) * $tragetHarvesting;
                        $bi_value =($bi_target_percent / 100);
                        
                        $bonusAmount = round($excessValue * $bi_value); 
                    }
                    // ! Bonus Incentive
                    
                
                    $bi_achieved = (($bi_target) && $collectionPercentage > $bi_target) ? true : false;
                    $bi_reward = $bi_achieved ? $bonusAmount : 0;

                    $biTarget = 150;
                    $biAchieved = $tenxStatus && ($collectionPercentage >= $biTarget);

                    $biReward = $biAchieved? ($incentive->bi_collection_reward ?? 0) : 0;

                    // ! Referal Incentive
                    $ri_amount = ($cre_ref_count ?? 0) * $ri_reward;
                    $ri_achieved = $ri_amount > 0;

                 
                    $totalReward  += $tenxStatus ? $incentive->tenx_award : 0;

                    $totalReward  += ($tenxStatus && $oldCollectionAchieved) ? $oldCollectionReward : 0 ;
                    $totalReward  += ($tenxStatus && $biAchieved) ? $biReward : 0 ;
                    $totalReward  +=  ($tenxStatus && $spot_achieved) ? $spot_cre_incentive_reward : 0  ;
                    $totalReward  += ( $ri_achieved) ? $ri_amount : 0;
                    $totalReward  += ($tenxStatus && $dropCollectionAchieved) ? $dropCollectionReward : 0 ;

                    $breakdown['10X Award'] = $tenxStatus ? $incentive->tenx_award : 0;

                    $breakdown['Old Award'] =($tenxStatus && $oldCollectionAchieved) ? $oldCollectionReward : 0 ;
                    $breakdown['150% Award'] = ($tenxStatus && $biAchieved) ? $biReward : 0 ;
                    $breakdown['SP Award'] = ($tenxStatus && $spot_achieved) ? $spot_cre_incentive_reward : 0 ;
                    $breakdown['REI Award'] = ( $ri_achieved) ? $ri_amount : 0;
                    $breakdown['DROP Award'] = ($tenxStatus && $dropCollectionAchieved) ? $dropCollectionReward : 0 ;
    
 

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => round($targetTenx),
        'actual' => round($collectionPercentage),
        'old_pending_perc' => round($oldCollectionPendingPercentage,1),
        'drop_collection' => round($dropCollectionAmount),
        'bonus_actual_perc' => round($collectionPercentage,1) ,
        'bonus_actual_amount' => round($collection) ,
        'spot_actual' => $spot_percentage ,
        'spot_target' => $spot_cre_incentive_target ,
        'referrals' => $cre_ref_count
      ]
    ];
  }


  private static function calculateBDMReward($staff, $incentive, $goalData, $branchId, $year, $month){
    $totalReward = 0;
    $breakdown = [];
    
        $helper = new \App\Helpers\Helpers();

        // Get previous month for calculations
        $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
        $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();


        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }

            $startOfMonth = $startDate->format('Y-m-d');
            $endOfMonth = $endDate->format('Y-m-d');

            $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();

            $startDateChck = Carbon::create($year, $month, 1);
            $currentDateChck = Carbon::now();
            $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month) 
                        ? $currentDateChck 
                        : $startDateChck->copy()->endOfMonth();
        
            $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;

            $tenxStatus = false;
            $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            $eciCustomerConvertCount = 0;
            $eciActualPercentage = 0;
            $eciTargetPercentage = $incentive->eci_count ?? 0;
            $eciStatus = false;

            $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
                        ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                        ->whereMonth('branch_target.date', $month)
                        ->whereYear('branch_target.date', $year)
                        ->select('branch_target.*') 
                        ->first();
            $branch = BranchModel::where('sno', $branchId)
                ->where('status', 0)
                ->orderBy('sno', 'desc')
                ->first();

            $pregoalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', 1)->where('et_goal_set_team.branch_id', $branchId)
                ->where('et_goal_set_team.team_goal_month', $month)
                ->where('et_goal_set_team.team_goal_year', $year)
                ->first();

            $postgoalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', 15)->where('et_goal_set_team.branch_id', $branchId)
                ->where('et_goal_set_team.team_goal_month', $month)
                ->where('et_goal_set_team.team_goal_year', $year)
                ->first();

            $financialYear = (int)$year; 
            if ($month >= 1 && $month <= 3) {
                $financialYear = $financialYear - 1;
            }


            $fyStart = Carbon::create($financialYear, 4, 1)->startOfDay();
            $fyEnd   = Carbon::create($financialYear + 1, 3, 31)->endOfDay();
            $yearlyTargets = ManageTargetModel::query()
                ->where('branch_target.branch_id', $branchId)
                ->whereBetween('branch_target.date', [$fyStart, $fyEnd])
                ->selectRaw("
                    SUM(no_of_registrations) as total_pre_target,
                    SUM(post_sale) as total_post_target
                ")
                ->first();

            $yearlyPreTarget  = (int) ($yearlyTargets->total_pre_target ?? 0);
            $yearlyPostTarget = (int) ($yearlyTargets->total_post_target ?? 0);

            $target_collection = $targets->monthly_target ?? 0;
            $target_pre = $targets->no_of_registrations ?? 0;
            $target_post = $targets->post_sale ?? 0;
            $targetPreABV = $pregoalsetteam ? $pregoalsetteam->abv_over_all : 0;
            $targetPreACV = $pregoalsetteam ? $pregoalsetteam->acv_over_all : 0;
            $targetPostABV = $postgoalsetteam ? $postgoalsetteam->abv_over_all : 0;
            $targetPostACV = $postgoalsetteam ? $postgoalsetteam->acv_over_all : 0;

            // 1. 10x Reward Start

                $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->whereIn('et_customer.status',[0,6])
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by','>',1)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->count();
        
                
            
                $postProposalFirstIds = DB::table('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    // ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 0)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by','>',1)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                    ->pluck('et_proposal.sno')
                    ->toArray();
            
                // (Assuming your DB supports the DAY() function; adjust if needed)
                $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.customer_id = et_customer.sno
                                    )');
                            })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    // ->where('et_customer.post_sale_check', 0)
                    ->where('et_proposal.post_sale_check', 0)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by','>',1)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                    ->pluck('et_customer.sno')
                    ->toArray();

                    $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
                    ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                    ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                    ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereIn('et_customer.sno',$prevMonthCustomerIdsCurrent )
                    ->whereIn('et_proposal.sno',$postProposalFirstIds )
                    // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                    ->where('et_proposal.status', '!=', 2)
                    ->whereNotIn('et_proposal.proposal_status',[0, 2])
                    ->where('et_transaction.payment_status', 1)
                    ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                    ->groupBy('et_proposal.customer_id')
                    // ->get();
                    ->having('total_paid','<',(float) $branch->min_prd_cost)
                    ->pluck('customer_id')
                    ->toArray();
                    // return $lowMbcCustomerIds;
                    $badCustomerIds = array_unique(array_merge(
                        // $dropoutCustomers,
                        $lowMbcCustomerIdsCurrent,
                    ));
                    // return count($badCustomerIds);
                
                $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));

                if ($customerConvertCount > 0) {
            
                
                    $currentMonthCustomer = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by','>',1)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->get();

                    // ECI early conversion before 15th
                
                    
                    $base_amount_paid=0;
                    $gst_percent = 18;
                    
                    if ($currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                            $proposal_ids = DB::table('et_proposal')
                                ->where('et_proposal.customer_id', $customer->sno)
                                ->where('et_proposal.status', 0)
                                ->whereNot('et_proposal.post_sale_check', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                ->pluck('sno')
                                ->toArray();
                                // return $proposal_ids;
                        
                            $proposals = DB::table('et_proposal')
                                ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                ->whereIn('et_proposal.sno', $proposal_ids)
                                ->get();
                            
                            foreach ($proposals as $proposal) {
                                // Paid slots for this proposal
                                $paidAmount = DB::table('et_proposal_pay_slot')
                                    ->where('proposal_sno', $proposal->sno)
                                    ->where('status', 0)
                                    ->sum('paidAmount');
                    
                                if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                    $grantAmount = $proposal->total_amount;
                                }else{
                                    $grantAmount = $proposal->grant_total_amount;
                                }
                    
                                // First remove GST from paidAmount (base value in proposal's currency)
                                if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                    $basePaidLocal = $paidAmount ;
                                }else{
                                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                                }
                                
                    
                                if ($proposal->currency_id == 70) {
                                    // INR: add directly
                                    $total_paid_payment += $paidAmount;
                                    $total_payment += $grantAmount;
                                    $base_amount_paid += $basePaidLocal;
                                } else {
                                    // Non-INR: convert both amounts and base value
                                    $currency_code = $proposal->currency_code;
                                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                }
                            }
                        }
                    }
                    // average 
                    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                }
                // 10x award calculation       
                $actualConversion      = $customerConvertCount;
                $actualABV             = round($averageBusinessValue) ?? 0;
                $actualACV             = round($averageCollectionValue) ?? 0;

                $customerConvertCountthismonthPost = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', '>',1)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                    ->count();

                $postProposalFirstIdsPost = DB::table('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by','>',1)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                    ->pluck('et_proposal.sno')
                    ->toArray();

                // (Assuming your DB supports the DAY() function; adjust if needed)
                $prevMonthCustomerIdsCurrentPost = CustomerModel::whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', '>',1)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                    ->pluck('et_customer.sno')
                    ->toArray();

                    $lowMbcCustomerIdsCurrentPost = DB::table('et_proposal')
                    ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                    ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                    ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereIn('et_customer.sno',$prevMonthCustomerIdsCurrentPost )
                    ->whereIn('et_proposal.sno',$postProposalFirstIdsPost )
                    // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                    ->where('et_proposal.status', '!=', 2)
                    ->whereNotIn('et_proposal.proposal_status',[0, 2])
                    ->where('et_transaction.payment_status', 1)
                    ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                    ->groupBy('et_proposal.customer_id')
                    // ->get();
                    ->having('total_paid','<',(float) $branch->min_prd_cost)
                    ->pluck('customer_id')
                    ->toArray();

                    $badCustomerIdsPost = array_unique(array_merge(
                        $lowMbcCustomerIdsCurrentPost
                    ));
                    
                $customerConvertCountPost = max(0, $customerConvertCountthismonthPost - count($badCustomerIdsPost));
            
                $currentMonthCustomerCountPost = 0;
                $total_business_amountPost     = 0;
                $total_paymentPost             = 0;
                $total_paid_paymentPost        = 0;
                $averageBusinessValuePost      = 0;
                $averageCollectionValuePost    = 0;
                $eciCustomerConvertCountPost = 0;
                $eciActualPercentagePost = 0;
                $eciTargetPercentagePost = $incentive->eci_count ?? 0;
                $eciStatusPost = false;
                $eciAchievement15 = 0;

            
                if ($customerConvertCountPost > 0) {
                
                    $currentMonthCustomerPost = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', '>',1)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->get();

                        
                    
                    $base_amount_paidPost=0;
                    $gst_percent = 18;

                    if ($currentMonthCustomerPost->isNotEmpty()) {
                        foreach ($currentMonthCustomerPost as $customer) {
                            $proposal_idsPost = DB::table('et_proposal')
                                ->where('et_proposal.customer_id', $customer->sno)
                                ->where('et_proposal.status', 0)
                                ->whereNot('et_proposal.post_sale_check', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                ->pluck('sno')
                                ->toArray();
                                // return $proposal_ids;
                    
                            $proposalsPost = DB::table('et_proposal')
                                ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                ->whereIn('et_proposal.sno', $proposal_idsPost)
                                ->get();
                    
                            foreach ($proposalsPost as $proposal) {
                                // Paid slots for this proposal
                                $paidAmountPost = DB::table('et_proposal_pay_slot')
                                    ->where('proposal_sno', $proposal->sno)
                                    ->where('status', 0)
                                    ->sum('paidAmount');

                                if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                    $grantAmountPost = $proposal->total_amount;
                                }else{
                                    $grantAmountPost = $proposal->grant_total_amount;
                                }
                                
                    
                                // First remove GST from paidAmount (base value in proposal's currency)
                                if ($proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                    $basePaidLocalPost = $paidAmountPost ;
                                }else{
                                    $basePaidLocalPost = $paidAmountPost / (1 + ($gst_percent / 100));
                                }
                                
                    
                                if ($proposal->currency_id == 70) {
                                    // INR: add directly
                                    $total_paid_paymentPost += $paidAmountPost;
                                    $total_paymentPost += $grantAmountPost;
                                    $base_amount_paidPost += $basePaidLocalPost;
                                } else {
                                    // Non-INR: convert both amounts and base value
                                    $currency_codePost = $proposal->currency_code;
                                    $total_paid_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $paidAmountPost);
                                    $total_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $grantAmountPost);
                                    $base_amount_paidPost += $helper->ConvertedAmountInr($currency_codePost, $basePaidLocalPost);
                                }
                            }
                        }
                    }

                    // average 
                    $averageBusinessValuePost   = $customerConvertCountPost > 0 ? $total_paymentPost / $customerConvertCountPost : 0;
                    $averageCollectionValuePost = $customerConvertCountPost > 0 ? $base_amount_paidPost / $customerConvertCountPost : 0;
                
                }

                // 10x award calculation       
                $actualConversionPost      = $customerConvertCountPost;
                $actualABVPost             = round($averageBusinessValuePost) ?? 0;
                $actualACVPost             = round($averageCollectionValuePost) ?? 0;
            
                                   
            //  10x Reward End 

            // ECI Incentive Start

                    $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.sno = (
                                        SELECT ep.sno
                                        FROM et_payment ep
                                        WHERE ep.customer_id = et_customer.sno
                                        ORDER BY ep.transaction_date ASC, ep.sno ASC
                                        LIMIT 1
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.branch_id', $branchId)
                            ->whereIn('et_customer.status', [0, 6])
                            ->where('et_lead.created_by','>',1)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereDay('et_payment.transaction_date', '<=', 15)
                            ->count();

                        $eciCustomerConvertCountPost = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.post_sale_check', 1)
                            ->where('et_proposal.post_sale_check', 1)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_proposal.created_by', '>',1)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                            ->where('et_proposal.status',0)
                            ->orderBy('et_proposal.sno', 'asc')
                            ->whereDay('et_payment.transaction_date', '<=', 15)
                            ->distinct('et_customer.sno')
                            ->count();

                    $eciCustomerConvertCount25 = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.sno = (
                                        SELECT ep.sno
                                        FROM et_payment ep
                                        WHERE ep.customer_id = et_customer.sno
                                        ORDER BY ep.transaction_date ASC, ep.sno ASC
                                        LIMIT 1
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.branch_id', $branchId)
                            ->whereIn('et_customer.status', [0, 6])
                            ->where('et_lead.created_by','>',1)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereDay('et_payment.transaction_date', '<=', 20)
                            ->count();

                        $eciCustomerConvertCountPost25 = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.post_sale_check', 1)
                            ->where('et_proposal.post_sale_check', 1)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_proposal.created_by', '>',1)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                            ->where('et_proposal.status',0)
                            ->orderBy('et_proposal.sno', 'asc')
                            ->whereDay('et_payment.transaction_date', '<=', 20)
                            ->distinct('et_customer.sno')
                            ->count();

            // ECI INCentive END

            // Team 10x Start
                $branch = BranchModel::where('sno', $branchId)
                    ->where('status', 0)
                    ->orderBy('sno', 'desc')
                    ->first();

                $gstPercentage = $branch ? $branch->gst_percentage  : 18;
                $transactionTotalNet = 0; // final net after GST

                $total_collection_value = 0;
                
                $allVerified = DB::table('et_transaction')
                    ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->where('et_transaction.payment_status',1)
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_lead.created_by','>',1)
                    ->where('et_lead.status','!=',2)
                    ->where('et_customer.status',0)
                    ->where('et_customer.branch_id',$branchId)
                    ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
                    ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                            'et_proposal.gst_perc','et_country_currencies.currency_code')
                    ->get();
                
                foreach ($allVerified as $row) {
                    // Determine INR value
                    if ($row->total_amount_inr > 0) {
                        $convertedPaidAmountInr = $row->total_amount_inr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
                    }
                    // Use transaction GST%
                    $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
                    $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    $total_collection_value += $netAmountInr;
                }
                    
                
                
                // Final net collection (matches verified_collection_net style)
                $actualCollection = round($total_collection_value);

                $teamTargets = GoalSetStaffModel::where('et_goal_set_staff.branch_id', $branchId)
                    ->join('et_staff', 'et_staff.sno', '=', 'et_goal_set_staff.staff_id')
                    ->whereIn('et_staff.role_id', [11, 35])
                    ->where('et_staff.status', 0)
                    ->whereMonth('et_goal_set_staff.goal_date', $month)
                    ->whereYear('et_goal_set_staff.goal_date', $year)
                    ->select(
                        'et_goal_set_staff.staff_id',
                        'et_goal_set_staff.conversion',
                        'et_staff.role_id',
                        'et_staff.staff_name'
                    )
                    ->distinct('et_staff.sno')
                    ->get();
            

                $preActuals = DB::table('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->whereNotIn('et_customer.sno', $lowMbcCustomerIdsCurrent)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->groupBy('et_lead.created_by')
                ->selectRaw('
                    et_lead.created_by as staff_id,
                    COUNT(DISTINCT et_customer.sno) as total_conversion
                ')
                ->pluck('total_conversion', 'staff_id');

            


                    $postActuals = DB::table('et_customer')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.post_sale_check', 1)
                            ->where('et_proposal.post_sale_check', 1)
                            ->where('et_proposal.created_by', '>',1)
                            ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                            ->whereNotIn('et_customer.sno', $lowMbcCustomerIdsCurrentPost)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->groupBy('et_proposal.created_by')
                            ->selectRaw('
                                et_proposal.created_by as staff_id,
                                COUNT(DISTINCT et_customer.sno) as total_conversion
                            ')
                            ->distinct('et_customer.sno')
                            ->pluck('total_conversion', 'staff_id');


                        $teamTotalMembers = 0;
                        $teamAchievedMembers = 0;
                        $teamBreakdown = [];

                        foreach ($teamTargets as $target) {

                            $teamTotalMembers++;

                            $actual = 0;

                            if ($target->role_id == 11) {
                                $actual = $preActuals[$target->staff_id] ?? 0;
                            }

                            if ($target->role_id == 35) {
                                $actual = $postActuals[$target->staff_id] ?? 0;
                            }

                            $achieved = $target->conversion > 0 && $actual >= $target->conversion;

                            if ($achieved) {
                                $teamAchievedMembers++;
                            }

                            $teamBreakdown[] = [
                                'staff_name' => $target->staff_name,
                                'role_id' => $target->role_id,
                                'target' => $target->conversion,
                                'actual' => $actual,
                                'status' => $achieved,
                            ];
                        }

                        $preTeamMembers = collect($teamBreakdown)
                                ->where('role_id', 11)
                                ->values();

                            $postTeamMembers = collect($teamBreakdown)
                                ->where('role_id', 35)
                                ->values();

                            $preTotal = $preTeamMembers->count();
                            $postTotal = $postTeamMembers->count();

                            $preAchieved = $preTeamMembers->where('status', true)->count();
                            $postAchieved = $postTeamMembers->where('status', true)->count();

                        $teamAchievementStatus =
                            $teamTotalMembers > 0 &&
                            $teamAchievedMembers === $teamTotalMembers;

                        $teamAchievementReward =  $incentive->team_target ?? 0;
            // Team 10x End

            // Year Incentive Start

                $yearlyPreActualOriginal  = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->whereIn('et_customer.status',[0,6])
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by','>',1)
                        ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->count();

                    $postProposalFirstIdsYear = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        // ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by','>',1)
                        ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_proposal.sno')
                        ->toArray();
                    // return $customerConvertThisMonth;
                    // (Assuming your DB supports the DAY() function; adjust if needed)
                    $prevMonthCustomerIdsYear = CustomerModel::whereIn('et_customer.status',[0,6])
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        // ->where('et_customer.post_sale_check', 0)
                        ->where('et_proposal.post_sale_check', 0)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by','>',1)
                        ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_customer.sno')
                        ->toArray();

                        $lowMbcCustomerIdsYear = DB::table('et_proposal')
                        ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                        ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                        ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.sno',$prevMonthCustomerIdsYear )
                        ->whereIn('et_proposal.sno',$postProposalFirstIdsYear )
                        // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                        ->where('et_proposal.status', '!=', 2)
                        ->whereNotIn('et_proposal.proposal_status',[0, 2])
                        ->where('et_transaction.payment_status', 1)
                        ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                        ->groupBy('et_proposal.customer_id')
                        // ->get();
                        ->having('total_paid','<',(float) $branch->min_prd_cost)
                        ->pluck('customer_id')
                        ->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIdsYear = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIdsYear,
                        ));
                        // return count($badCustomerIds);
                    
                    $yearlyPreActual = max(0, $yearlyPreActualOriginal - count($badCustomerIdsYear));

                    $yearlyPostActualOriginal = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', '>',1)
                    ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->distinct('et_customer.sno')
                        ->count();

                    $postProposalFirstIdsPostYear = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by','>',1)
                        ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_proposal.sno')
                        ->toArray();
                

                    // (Assuming your DB supports the DAY() function; adjust if needed)
                    $prevMonthCustomerIdsYearPost = CustomerModel::whereIn('et_customer.status',[0,6])
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', '>',1)
                        ->whereBetween('et_payment.transaction_date', [$fyStart, $fyEnd])
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_customer.sno')
                        ->toArray();

                        $lowMbcCustomerIdsYearPost = DB::table('et_proposal')
                        ->join('et_proposal_pay_slot','et_proposal_pay_slot.proposal_sno','=','et_proposal.sno')
                        ->join('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
                        ->join('et_transaction','et_transaction.payment_id','=', 'et_payment.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.sno',$prevMonthCustomerIdsYearPost )
                        ->whereIn('et_proposal.sno',$postProposalFirstIdsPostYear )
                        // ->whereRaw('DAY(et_payment.transaction_date) <= 25')
                        ->where('et_proposal.status', '!=', 2)
                        ->whereNotIn('et_proposal.proposal_status',[0, 2])
                        ->where('et_transaction.payment_status', 1)
                        ->select('et_proposal.customer_id',DB::raw('SUM(COALESCE(et_transaction.total_amount_inr,0)) as total_paid'))
                        ->groupBy('et_proposal.customer_id')
                        // ->get();
                        ->having('total_paid','<',(float) $branch->min_prd_cost)
                        ->pluck('customer_id')
                        ->toArray();

                        $badCustomerIdsPostYear = array_unique(array_merge(
                            $lowMbcCustomerIdsYearPost
                        ));
                        
                    $yearlyPostActual  = max(0, $yearlyPostActualOriginal  - count($badCustomerIdsPostYear));
            // Year Incentive End

                $yearlyPreAchievement = 0;
                if ($yearlyPreTarget > 0) {
                    $yearlyPreAchievement = round( ($yearlyPreActual / $yearlyPreTarget) * 100, 1 );
                }

                $yearlyPostAchievement = 0;
                if ($yearlyPostTarget > 0) {
                    $yearlyPostAchievement = round(($yearlyPostActual / $yearlyPostTarget) * 100, 1 );
                }

                $yearly150Status = $yearlyPreAchievement >= 150 &&  $yearlyPostAchievement >= 150;

                $yearly150Reward = $yearly150Status ? ($incentive->overall_year ?? 0) : 0;

                $fyStartYear = (int)$year;
                $fyStartYear = $financialYear;

                $months = [];

                for ($i = 0; $i < 12; $i++) {
                    $date = Carbon::create($fyStartYear, 4, 1)->addMonths($i);
                    $months[] = [
                        'month' => $date->month,
                        'year' => $date->year,
                        'label' => $date->format('M'),
                    ];
                }

                $tenxMonthlyStatus = [];
                $achievedMonths = 0;

                $currentMonth = now()->month;
                $currentYear = now()->year;

                foreach ($months as $fyMonth) {

                    $m = $fyMonth['month'];
                    $y = $fyMonth['year'];

                    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
                        ->whereMonth('branch_target.date', $m)
                        ->whereYear('branch_target.date', $y)
                        ->first();

                    $targetPre  = $targets->no_of_registrations ?? 0;
                    $targetPost = $targets->post_sale ?? 0;

                    if ( $y > $currentYear || ($y == $currentYear && $m > $currentMonth) ) {
                        $status = 'upcoming';
                    }
                    elseif ( $y == $currentYear && $m == $currentMonth) {
                        $status = 'progress';
                    }
                    else {
                        $actualPre  = self::getMonthlyPreSale( $branchId, $m, $y, $lowMbcCustomerIdsCurrent );
                        $actualPost = self::getMonthlyPostSale( $branchId, $m, $y, $lowMbcCustomerIdsCurrentPost );

                        $tenxStatus =
                            $targetPre > 0 &&
                            $targetPost > 0 &&
                            $actualPre >= $targetPre &&
                            $actualPost >= $targetPost;

                        if ($tenxStatus) {
                            $status = 'achieved';
                            $achievedMonths++;
                        } else {
                            $status = 'failed';
                        }
                    }

                    $tenxMonthlyStatus[] = [
                        'month' => $fyMonth['label'],
                        'status' => $status,
                        'target_pre' => $targetPre,
                        'target_post' => $targetPost,
                    ];
                }

                $nineMonthStatus = $achievedMonths >= 9;
                $nineMonthReward = $incentive->nine_monthadd ?? '-';

                $tenxStatus = (
                    $target_collection > 0 && $target_pre > 0 && $target_post > 0 && $targetPreABV > 0 && $targetPreACV > 0 && $targetPostABV > 0 && $targetPostACV > 0 &&
                    $target_collection >= $actualCollection &&
                    $actualConversion >= $target_pre &&
                    $actualConversionPost >= $target_post &&
                    $actualABV >= $targetPreABV &&
                    $actualACV >= $targetPreACV &&
                    $actualABVPost >= $targetPostABV &&
                    $actualACVPost >= $targetPostACV 
                );
                

                $eciReward = 0;
                $eciStatus = false;
                $eciRewardType = 'Not Achieved';

                $totalTarget = ($target_pre ?? 0) + ($target_post ?? 0);

                $totalConversion15 = ($eciCustomerConvertCount ?? 0)  + ($eciCustomerConvertCountPost ?? 0);

                if ($totalTarget > 0) {
                    $eciAchievement15 = round( ($totalConversion15 / $totalTarget) * 100, 1);
                }

                $totalConversion25 = ($eciCustomerConvertCount25 ?? 0) + ($eciCustomerConvertCountPost25 ?? 0);
                $eciAchievement25 = 0;
                if ($totalTarget > 0) {
                    $eciAchievement25 = round(($totalConversion25 / $totalTarget) * 100, 1);
                }

                $requiredPercentage = $incentive->eci_count ?? 100;

                if ($eciAchievement15 >= $requiredPercentage) {
                    $eciStatus = true;
                    $eciReward = $incentive->eci_reward ?? 0;
                    $eciRewardType = '15th Achievement';
                } elseif ($eciAchievement25 >= $requiredPercentage) {
                    $eciStatus = true;
                    $eciReward = $incentive->eci_second_reward ?? 0;
                    $eciRewardType = '20th Achievement';
                }
                    // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $target_pre); // No negative bonus
                
                    $biRewardPre = $biAchievedCount * $biPerConversion;
                    $biStatusPre = $biAchievedCount > 0;
            
                    // bi award calculation  
                    $biPerConversionPost = $incentive->bi_amount ?? 0;
                    $biAchievedCountPost = max(0, $actualConversionPost - $target_post); // No negative bonus
                
                    $biRewardPost = $biAchievedCountPost * $biPerConversionPost;
                    $biStatusPost = $biAchievedCountPost > 0;

                    $biReward =  $biRewardPre + $biRewardPost;
                    $biStatus = ($biStatusPre || $biStatusPost);

                    $doubleXStatus =false;
                    $doublexTargetPre = ($target_pre*2);
                    $doublexTargetPost = ($target_post*2);

                    $doubleXStatus = (
                        $doublexTargetPre > 0 && $doublexTargetPost > 0  &&
                    ( $actualConversion >= $doublexTargetPre || $actualConversionPost >= $doublexTargetPost )
                    );
            
                    $doubleXRewardPre = ($actualConversion >= $doublexTargetPre) ? ($incentive->double_x_reward ?? 0) : 0;
                    $doubleXRewardPost = ($actualConversionPost >= $doublexTargetPost) ? ($incentive->double_x_reward ?? 0) : 0;

                    $doubleXReward = $doubleXRewardPre + $doubleXRewardPost ;

                    $abvStatus =false;
                    $abvReward = $incentive->abv_reward ??  0;

                    $abvAchivedStatus =false;
                    $abvAchivedReward = $incentive->abv_achieved_reward ??  0;

                    $abvAchivedStatus = (
                        $targetPreABV > 0 && $targetPostABV > 0  &&
                        $actualABV >= $targetPreABV &&
                        $actualABVPost >= $targetPostABV 
                    );

                    $abvTargetPercentage = 150;
                    // Pre ABV Achievement
                    $preABVAchievement = 0;
                    if (($targetPreABV ?? 0) > 0) {
                        $preABVAchievement = round( (($actualABV ?? 0) / $targetPreABV) * 100,1);
                    }

                    // Post ABV Achievement
                    $postABVAchievement = 0;
                    if (($targetPostABV ?? 0) > 0) {
                        $postABVAchievement = round( (($actualABVPost ?? 0) / $targetPostABV) * 100, 1 );
                    }
                    $requiredPreABV  = $targetPreABV * 1.5;
                    $requiredPostABV = $targetPostABV * 1.5;
                    // Both must achieve 150%
                    $abvStatus = $preABVAchievement >= $abvTargetPercentage && $postABVAchievement >= $abvTargetPercentage;

                    $abvReward = ($tenxStatus && $abvStatus)? ($incentive->abv_reward ?? 0) : 0;

                        // 10x Reward
                        if ($tenxStatus) {
                            $tenxReward = $incentive->tenx_award ?? 0;
                            $totalReward += $tenxReward;
                            $breakdown['10X Award'] = $tenxReward;
                        }else{
                            $tenxReward =  0;
                            $totalReward += $tenxReward;
                            $breakdown['10X Award'] = $tenxReward;
                        }

                        // ABV Incentive Reward
                        if ($tenxStatus && $abvAchivedStatus) {
                            $abvAchivedReward = $abvAchivedReward ?? 0;
                            $totalReward += $abvAchivedReward;
                            $breakdown['ABV Award'] = $abvAchivedReward;
                        }else{
                            $abvAchivedReward =  0;
                            $totalReward += $abvAchivedReward;
                            $breakdown['ABV Award'] = $abvAchivedReward;
                        }

                        // Team 10x Incentive Reward
                        if ($tenxStatus && $teamAchievementStatus) {
                            $teamAchievementReward = $teamAchievementReward ?? 0;
                            $totalReward += $teamAchievementReward;
                            $breakdown['Team 10X Award'] = $teamAchievementReward;
                        }else{
                            $teamAchievementReward =  0;
                            $totalReward += $teamAchievementReward;
                            $breakdown['Team 10X Award'] = $teamAchievementReward;
                        }

                        // ECI Incentive Reward
                        if ($tenxStatus && $eciStatus) {
                            $eciReward = $eciReward ?? 0;
                            $totalReward += $eciReward;
                            $breakdown['ECI Award'] = $eciReward;
                        }else{
                            $eciReward =  0;
                            $totalReward += $eciReward;
                            $breakdown['ECI Award'] = $eciReward;
                        }

                        // BI Incentive Reward
                        if ($tenxStatus && $biStatus) {
                            $biReward = $biReward ?? 0;
                            $totalReward += $biReward;
                            $breakdown['BI Award'] = $biReward;
                        }else{
                            $biReward =  0;
                            $totalReward += $biReward;
                            $breakdown['BI Award'] = $biReward;
                        }
                        // 2x Incentive Reward
                        if ($tenxStatus && $doubleXStatus) {
                            $doubleXReward = $doubleXReward ?? 0;
                            $totalReward += $doubleXReward;
                            $breakdown['2X Award'] = $doubleXReward;
                        }else{
                            $doubleXReward =  0;
                            $totalReward += $doubleXReward;
                            $breakdown['2X Award'] = $doubleXReward;
                        }

                        // ABV 150% Incentive Reward
                        if ($tenxStatus && $abvStatus) {
                            $abvReward = $abvReward ?? 0;
                            $totalReward += $abvReward;
                            $breakdown['ABV 150% Award'] = $abvReward;
                        }else{
                            $abvReward =  0;
                            $totalReward += $abvReward;
                            $breakdown['ABV 150% Award'] = $abvReward;
                        }

                        // Yearly 150% Incentive Reward
                        if ($tenxStatus && $yearly150Reward) {
                            $yearly150Reward = $yearly150Reward ?? 0;
                            $totalReward += $yearly150Reward;
                            $breakdown['Yearly 150% Award'] = $yearly150Reward;
                        }else{
                            $yearly150Reward =  0;
                            $totalReward += $yearly150Reward;
                            $breakdown['Yearly 150% Award'] = $yearly150Reward;
                        }
                        // Yearly 150% Incentive Reward
                        if ($tenxStatus && $nineMonthStatus) {
                            $nineMonthReward = $nineMonthReward ?? '-';
                            $totalReward += $nineMonthReward;
                            $breakdown['9 Month Award'] = $nineMonthReward;
                        }else{
                            $nineMonthReward =  0;
                            $totalReward += $nineMonthReward;
                            $breakdown['9 Month Award'] = $nineMonthReward;
                        }
        
                

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target_pre' => $target_pre,
        'actual_pre' => $actualConversion,
        'target_post' => $target_post,
        'actual_post' => $actualConversionPost,
        
        'target_pre_abv' => $targetPreABV,
        'actual_pre_abv' => $actualABV,

        'target_pre_acv' => $targetPreACV,
        'actual_pre_acv' => $actualACV,

        'target_post_abv' => $targetPostABV,
        'actual_post_abv' => $actualABVPost,

        'target_post_acv' => $targetPostACV,
        'actual_post_acv' => $actualACVPost,

        'team_pre_target' => $preTotal,
        'team_pre_actual' => $preAchieved,

        'team_post_target' => $postTotal,
        'team_post_actual' => $postAchieved,
        'abv_150_pre' => $preABVAchievement,
        'abv_150_post' => $postABVAchievement,
        'yearly_150_acheived_pre' => $yearlyPreAchievement,
        'yearly_150_acheived_pre' => $yearlyPreAchievement,
        'yearly_150_acheived_post' => $yearlyPostAchievement,
        'nine_month_acheived' => $achievedMonths,
      ]
    ];
  }


    private static  function getMonthlyPreSale(
        int $branchId,
        int $month,
        int $year,
        array $excludeCustomerIds = []
    ): int {

        return DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {

                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join(
                'et_transaction',
                'et_transaction.payment_id',
                '=',
                'et_payment.sno'
            )
            ->where('et_customer.branch_id', $branchId)
            ->where('et_transaction.payment_status', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->when(
                !empty($excludeCustomerIds),
                fn($q) => $q->whereNotIn(
                    'et_customer.sno',
                    $excludeCustomerIds
                )
            )
            ->distinct('et_customer.sno')
            ->count('et_customer.sno');
    }

    private static  function getMonthlyPostSale(
        int $branchId,
        int $month,
        int $year,
        array $excludeCustomerIds = []
    ): int {

        return DB::table('et_customer')
            ->join(
                'et_lead',
                'et_lead.sno',
                '=',
                'et_customer.lead_id'
            )
            ->join(
                'et_proposal',
                'et_customer.sno',
                '=',
                'et_proposal.customer_id'
            )
            ->join('et_payment', function ($join) {

                $join->on(
                    'et_payment.proposal_id',
                    '=',
                    'et_proposal.sno'
                )
                ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.proposal_id = et_proposal.sno
                )');
            })
            ->join(
                'et_transaction',
                'et_transaction.payment_id',
                '=',
                'et_payment.sno'
            )
            ->where('et_customer.branch_id', $branchId)
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_proposal.created_by', '>', 1)
            ->whereNotIn(
                'et_proposal.proposal_status',
                [0, 1, 2]
            )
            ->where('et_transaction.payment_status', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->when(
                !empty($excludeCustomerIds),
                fn($q) => $q->whereNotIn(
                    'et_customer.sno',
                    $excludeCustomerIds
                )
            )
            ->distinct('et_customer.sno')
            ->count('et_customer.sno');
    }

  /**
   * Get empty response
   */
  private static function getEmptyResponse()
  {
    return [
      'total_award' => 0,
      'breakdown' => [],
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'error' => 'No incentive configuration found'
    ];
  }
  
     public function AddTransferStaff(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }
                
                $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                  if ($existingExternalStaff) {
                      $existingExternalStaff->status = 0;
                      $existingExternalStaff->inactive_status = 0;
                      $existingExternalStaff->update();
                      return response()->json([
                          'ok' => true,
                          'message' => 'Staff Rejoin Successfully'
                      ], 200);
                  }
                

                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }

                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => $payload['contact_person_name'] ?? null,
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): null,
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'employee_skill_id' => 1, // Default value for now
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );

            if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }

                // Handle work experience (if applicable)
                if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                    foreach ($payload['work_company_name'] as $key => $company) {
                        // Avoid duplicate work entries for same staff
                        $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                            ->where('company_name', $company)
                            ->where('position', $payload['work_position'][$key] ?? '')
                            ->first();

                        if (!$existingWork) {
                            StaffWorkInfoModel::create([
                                'staff_id' => $add_staff->sno,
                                'staff_type' => $payload['exp_type'],
                                'position' => $payload['work_position'][$key] ?? null,
                                'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                'company_name' => $company,
                                'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                'created_by' => $request->user()->user_id ?? 1,
                                'updated_by' => $request->user()->user_id ?? 1,
                            ]);
                        }
                    }
                }
            }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }
        
}