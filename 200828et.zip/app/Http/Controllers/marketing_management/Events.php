<?php

namespace App\Http\Controllers\marketing_management;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\EventCategoryModel;
use App\Models\EventExports;
use App\Models\EventModel;
use App\Models\ParticipantModel;
use App\Models\EventPosterModel;
use App\Models\EventTypeModel;
use App\Models\ParticipantTransferModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Models\RawLeadModel;
use App\Models\EventQRScannerModel;
use App\Models\WhatsappApiConfigureModel;
use Illuminate\Support\Facades\Http;
use App\Models\EmailTemplateModel;
use App\Mail\ETPLMail;
use Illuminate\Support\Facades\Mail;
use PDF;
use Carbon\Carbon;

class Events extends Controller
{

    

    public function index(Request $request)
    {

         $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id;
        $role_id = $request->user()->role_id;
        // if($role_id ==12){
        //     if($branch_id != 6 ){
        //         abort(403, 'Unauthorized');
        //     }
        // }
       
        $search_fill = $request->search_fill ?? '';
        $branch_fill = $request->branch_fill ?? '';
        $event_name = $request->event_name ?? '';
        $person_name = $request->person_name ?? '';
        $person_mobile = $request->person_mobile ?? '';
        $event_status_fill = $request->event_status_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->from_date_fillter_textbox ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';
        
        $event_list = EventModel::select('et_event_category.event_category_name as event_category_name', 'et_event.*','et_branch.branch_name','et_branch.franchise_name')
            ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
            ->leftJoin('et_branch', 'et_event.branch_id', '=', 'et_branch.sno')
            ->where('et_event.status', '!=', 2);
        if ($role_id != 1) {
            $event_list->where('et_event.branch_id', $branch_id);
        }else{
            
        }
        
        
         // Date Filtering Logic
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $event_list->whereDate('et_event.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $event_list->whereBetween('et_event.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $event_list->whereBetween('et_event.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $event_list->whereBetween('et_event.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $event_list->where('et_event.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $event_list->where('et_event.created_at', '<=', $toDate);
            }
        }

        // Apply filters
     
        if ($event_name) {
            $event_list->where('et_event.event_name', 'LIKE', "%{$event_name}%");
        }
        if ($person_name) {
            $event_list->where('et_event.contact_person_name', 'LIKE', "%{$person_name}%");
        }
        if ($person_mobile) {
            $event_list->where('et_event.contact_person_mob_no', 'LIKE', "%{$person_mobile}%");
        }
        
        if($branch_fill){
            $event_list->where('et_event.branch_id',$branch_fill);
        }

        if ($event_status_fill) {
            if($event_status_fill == 'Schedule'){
                $event_list->whereNotIn('et_event.status', [3,4])->whereDate('et_event.event_date','>',  date("Y-m-d"));
            }elseif($event_status_fill == 'Live'){
               $event_list->whereDate('et_event.event_date',  date("Y-m-d"));
            }elseif($event_status_fill == 'not_completed'){
                 $event_list->whereNotIn('et_event.status', [3,4])->where('attendance_status',0);
            }elseif($event_status_fill == 'Attendance'){
                $event_list->where('et_event.status', 4)->where('attendance_status',0);
            }elseif($event_status_fill == 'Completed'){
                 $event_list->where('et_event.status', 4)->where('attendance_status',1);
            }elseif($event_status_fill == 'Cancelled'){
                 $event_list->where('et_event.status', 3);
            }
        }

        if ($search_fill != '') {
            $event_list->where(function ($subquery) use ($search_fill) {
                $subquery->where('et_event.event_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_event.event_date', 'LIKE', "%{$search_fill}%");  
            });
        }
        
        $event_list = $event_list->orderBy('et_event.sno', 'desc')
            ->distinct() // Ensure unique rows
            ->paginate($perpage);
            
            foreach($event_list as $event){
                
                $certificateData = ParticipantModel::where('event_id', $event->sno)->where('attendance_check', 1)->get();
                $appliedData = ParticipantModel::where('event_id', $event->sno)->get();
                $applied_count=count($appliedData);
                $attend_count=count($certificateData);
                $allCertificatesSent=0;
                $certificateIssued=0;
                if($attend_count > 0){
                    $allCertificatesSent = $certificateData->every(function ($participant) {
                        return $participant->certificate_status == 1;
                    });
                    
                    $certificateIssued = $certificateData->contains(function ($participant) {
                        return $participant->certificate_status == 1;
                    });
                }
                
                
                $event->certificateSendAll = $allCertificatesSent ? 1 : 0;
                $event->certificateIssued  = $certificateIssued ? 1 : 0;
                            
                $event->applied_count=$applied_count ? $applied_count : 0;
                $event->attend_count=$attend_count ? $attend_count : 0;
                
                 $eventScannerCount = DB::table('et_event_qr_scanner')
                    ->where('et_event_qr_scanner.status', '!=', 2)
                    ->where('et_event_qr_scanner.event_id', $event->sno)
                    ->count();
                $event->eventScannerCount=$eventScannerCount ? $eventScannerCount : 0;
                
            }

        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        
        $branch_list = BranchModel::where('status', 0)->orderBy('sno', 'desc')->get();
        
        $event_category_list = EventCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();
        return view('content.marketing_management.events.list', [
            'event_list' => $event_list,
            'pageConfigs' => $pageConfigs,
            'branch_list' => $branch_list,
            'event_category_list' => $event_category_list,
            'event_name' => $event_name,
            'person_name' => $person_name,
            'person_mobile' => $person_mobile,
            'event_status_fill' => $event_status_fill,
            'date_filter' => $date_filter,
            'branch_fill' => $branch_fill,
            'perpage' => $perpage,
            'search_fill' => $search_fill,

        ]);
       
    }



    public function list_filter(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id;
        $helper = new \App\Helpers\Helpers();

        // return $request;
        // Determine branch type
        $get_branch_type = $branch_id ? $helper->get_branch_id($branch_id)->branch_type ?? 0 : 0;

        // Retrieve filter parameters from request
        $event_name = $request->event_name ?? '';
        $person_name = $request->person_name ?? '';
        $person_mobile = $request->person_mobile ?? '';
        $event_category_fill = $request->event_category_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;

        // Build the query
        $query = EventModel::select('et_event_category.event_category_name as event_category_name', 'et_event.*')
            ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
            ->where('et_event.status', '!=', 2);

        // Date Filtering Logic
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('et_event.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('et_event.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('et_event.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('et_event.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('et_event.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('et_event.created_at', '<=', $toDate);
            }
        }

        // Apply filters
        if ($branch_id > 0) {
            $query->where('et_event.branch_id', $branch_id);
        }
        if ($event_name) {
            $query->where('et_event.event_name', 'LIKE', "%{$event_name}%");
        }
        if ($person_name) {
            $query->where('et_event.contact_person_name', 'LIKE', "%{$person_name}%");
        }
        if ($person_mobile) {
            $query->where('et_event.contact_person_mob_no', 'LIKE', "%{$person_mobile}%");
        }

        if ($event_category_fill) {
            $query->where('et_event_category.sno', $event_category_fill);
        }

        // Fetch events ordered by sno in descending order
        $event_list = $query->orderBy('et_event.sno', 'desc')->distinct()->paginate($perpage);

         foreach($event_list as $event){
                
                $certificateData = ParticipantModel::where('event_id', $event->sno)->where('attendance_check', 1)->get();
                $appliedData = ParticipantModel::where('event_id', $event->sno)->get();
                $applied_count=count($appliedData);
                $attend_count=count($certificateData);
                $allCertificatesSent=0;
                $certificateIssued=0;
                if($attend_count > 0){
                    $allCertificatesSent = $certificateData->every(function ($participant) {
                        return $participant->certificate_status == 1;
                    });
                    
                    $certificateIssued = $certificateData->contains(function ($participant) {
                        return $participant->certificate_status == 1;
                    });
                }
                
                
                $event->certificateSendAll = $allCertificatesSent ? 1 : 0;
                $event->certificateIssued  = $certificateIssued ? 1 : 0;
                            
                $event->applied_count=$applied_count ? $applied_count : 0;
                $event->attend_count=$attend_count ? $attend_count : 0;
                
                 $eventScannerCount = DB::table('et_event_qr_scanner')
                    ->where('et_event_qr_scanner.status', '!=', 2)
                    ->where('et_event_qr_scanner.event_id', $event->sno)
                    ->count();
                $event->eventScannerCount=$eventScannerCount ? $eventScannerCount : 0;
                
            }
        // Fetch other data for view
        $branch_list = BranchModel::where('status', 0)->orderBy('sno', 'desc')->get();
        $event_category_list = EventCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();
        $event_type_list = EventTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        // Return the view with the necessary data
        return view('content.marketing_management.events.events', [
            'event_list' => $event_list,
            'branch_list' => $branch_list,
            'event_category_list' => $event_category_list,
            'event_type_list' => $event_type_list,
            'login_branch_id' => $branch_id,
            'login_branch_type' => $get_branch_type,
            'event_name' => $event_name,
            'person_name' => $person_name,
            'person_mobile' => $person_mobile,
            'event_category_fill' => $event_category_fill,
            'date_filter' => $date_filter,
        ])->with('filter_on', true);
    }

    public function list()
    {
        $event = EventModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $event,
        ], 200);
    }
    public function event_add()
    {

        return view('content.marketing_management.events.event_add');
    }

    public function event_edit(Request $request, $id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $branch_id = $request->user()->branch_id;
        $event_data = EventModel::select('et_event.*')
            ->where('et_event.sno', $decryptedValue)
            ->first();
        $event_data->event_key_tag = json_decode($event_data->event_key_tag, true);
       
      
        // Use `get()` to retrieve all branches, not just one
        $branches = BranchModel::select('et_branch.*')
            ->where('et_branch.status', '!=', 2);

        if ($branch_id != 0) {
            $branches->where('et_branch.sno', $branch_id);
        }
        $branches = $branches->orderBy('et_branch.sno', 'desc')
            ->distinct() // Ensure unique rows
            ->get();

        $event_categories = EventCategoryModel::select('et_event_category.*')
            ->where('et_event_category.status', '!=', 2)
            ->get();

        $event_types = EventTypeModel::select('et_event_type.*')
            ->where('et_event_type.status', '!=', 2)
            ->get();
        // Pass the correct data to the view
        return view('content.marketing_management.events.event_edit', [
            'event_data' => $event_data,
            'branches' => $branches,
            'event_categories' => $event_categories,
            'event_types' => $event_types,

        ]);
    }

    public function Add(Request $request)
    {
        // return $request;
        // $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'event_category' => 'required',
            'event_type' => 'required',
            'event_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields',
            ]);
            return redirect()->back();
        }
        $branch_id = $request->branch_name;
        $event_category = $request->event_category;
        $event_type = $request->event_type;
        $handle_type = $request->handle_type;
        $event_key_tag = is_array($request->event_Key_tag) ? json_encode($request->event_Key_tag) : $request->event_Key_tag;
        if ($handle_type == "Inhouse") {
            $handle_staff_id = $request->handle_person;
            $handle_others_name = null;
            $handle_others_mobile =null;
        } else {
            $handle_staff_id=null;
            $handle_others_name = $request->other_person_name;
            $handle_others_mobile = $request->other_person_mobile;
        }
        $event_name = $request->event_name;
        if ($event_type == "Offline") {
            $location_url = $request->location_url;
            $event_address = $request->event_address;
            $zoom_link = "";
        } else {
            $location_url = "";
            $event_address = "";
            $zoom_link = "";
        }
        // $zoom_link = $request->zoom_link;
        $event_date = date('Y-m-d', strtotime($request->input('event_date')));
        $start_time = date('H:i:s', strtotime($request->input('start_time')));
        $end_time   = date('H:i:s', strtotime($request->input('end_time')));
        $event_offer = $request->event_offer;
        if ($event_offer == 'paid') {
            $event_amount = $request->event_amount;
            $coupon_code = "";
        } elseif ($event_offer == 'redeem') {
            $coupon_code = $request->coupon_code;
            $event_amount = 0;
        } else {
            $coupon_code = "";
            $event_amount = 0;
        }
        $participants = $request->participants;
        if ($participants == "Limited") {
            $no_of_participants = $request->no_of_participants;
        } else {
            $no_of_participants = "";
        }
        $contact_person_name = $request->contact_person_name;
        $contact_person_number = $request->contact_person_number;
        $certificate_check = $request->certificate_check;
        if ($certificate_check == "yes") {
            $certificate_type = $request->certificate_type;
        } else {
            $certificate_type = "";
        }

        $event_desc = $request->event_desc;

        $user_id = 1;

        $event_check = EventModel::orderBy('sno', 'desc')->first();

        if (!$event_check) {
            $year = date('y');
            $event_id = 'EV-0001/' . $year;
        } else {
            $data = $event_check->event_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[ ^0-9 ]/', '', $slice[0]);
            $next_number = (int) $result + 1;
            $requestId = sprintf('EV-%04d', $next_number);
            $year = date('y');
            $event_id = $requestId . '/' . $year;
        }

        $event = new EventModel();
        // Assuming 'event' is your model
        $event->event_id = $event_id;
        $event->event_category = $event_category;
        $event->event_type_id = $event_type;
        $event->event_name = $event_name;
        $event->location_url = $location_url ? $location_url : null;
        $event->event_address = $event_address ? $event_address : null;
        $event->zoom_link = $zoom_link ? $zoom_link : null;
        $event->event_date = $event_date;
        $event->start_time = $start_time;
        $event->end_time = $end_time;
        $event->event_key_tag = $event_key_tag;
        $event->event_offer = $event_offer;
        $event->coupon_code = $coupon_code ? $coupon_code : null;
        $event->event_amount = $event_amount ? $event_amount : 0;
        $event->participants = $participants;
        $event->no_of_participants = $no_of_participants ? $no_of_participants : null;
        $event->contact_person_name = $contact_person_name;
        $event->contact_person_mob_no = $contact_person_number;
        $event->certificate = $certificate_check;
        $event->handle_type = $handle_type;
        $event->handle_staff_id = $handle_staff_id;
        $event->handle_others_name = $handle_others_name;
        $event->handle_others_mobile = $handle_others_mobile;
        $event->certificate_type = $certificate_type;
        $event->event_description = $request->event_desc;
        $event->branch_id = $branch_id;

        $event->created_by = $user_id;
        $event->updated_by = $user_id;

        // Save the event
        $saved = $event->save();

        // Optionally, you can flash a success message
        if ($saved) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Event added Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Event !',
            ]);
        }
        // }
        // Redirect to a success page or any other page as needed
        return redirect('events');
    }

    public function Status($id, Request $request)
    {

        $upd_EventModel = EventModel::where('sno', $id)->first();
        $upd_EventModel->status = $request->input('status', 0);
        $upd_EventModel->update();
        if ($upd_EventModel) {
            return response([
                'status' => 200,
                'message' => 'Event  Status Successfully Updated!',
                'error_msg' => 'Could not, update  Event  Status!',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'Could not update Event  Status!',
                'error_msg' => 'Could not, update  Event  Status!',
                'data' => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_EventModel = EventModel::where('sno', $id)->first();
        $upd_EventModel->status = 2;
        $upd_EventModel->Update();
        if ($upd_EventModel) {
            return response([
                'status' => 200,
                'message' => 'Event Successfully Deleted!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'Could not delete Event !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }

    public function edit($id)
    {
        $data = EventModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function update(Request $request)
    {
        // return $request;
        // Validate input data
        $validator = Validator::make($request->all(), [
            'event_name' => 'required', // Assuming branch_franc is numeric
            'event_category' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->errors()->all(),
                'data' => null,
            ], 200);
        }
        $branch_id = $request->branch_name;
        $event_category = $request->event_category;
        $event_type = $request->event_type;
        $event_name = $request->event_name;
        $handle_type = $request->handle_type;
        $event_key_tag = is_array($request->event_Key_tag) ? json_encode($request->event_Key_tag) : $request->event_Key_tag;
        if ($handle_type == "Inhouse") {
            $handle_staff_id = $request->handle_person;
            $handle_others_name = null;
            $handle_others_mobile =null;
        } else {
            $handle_staff_id=null;
            $handle_others_name = $request->other_person_name;
            $handle_others_mobile = $request->other_person_mobile;
        }
       
        
        if ($event_type == "Offline") {
            $location_url = $request->location_url;
            $event_address = $request->event_address;
            $zoom_link = "";
        } else {
            $location_url = "";
            $event_address = "";
            $zoom_link = "";
        }
        // $zoom_link = $request->zoom_link;
        $event_date = date('Y-m-d', strtotime($request->input('event_date')));
        $start_time = date('H:i:s', strtotime($request->input('start_time')));
        $end_time   = date('H:i:s', strtotime($request->input('end_time')));
        $event_offer = $request->event_offer;
        if ($event_offer == 'paid') {
            $event_amount = $request->event_amount;
            $coupon_code = "";
        } elseif ($event_offer == 'redeem') {
            $coupon_code = $request->coupon_code;
            $event_amount = 0;
        } else {
            $coupon_code = "";
            $event_amount = 0;
        }
        $participants = $request->participants;
        if ($participants == "Limited") {
            $no_of_participants = $request->no_of_participants;
        } else {
            $no_of_participants = "";
        }
        $contact_person_name = $request->contact_person_name;
        $contact_person_number = $request->contact_person_number;
        $certificate_check = $request->certificate_check;
        if ($certificate_check == "yes") {
            $certificate_type = $request->certificate_type;
        } else {
            $certificate_type = "";
        }

        $event_desc = $request->event_desc;

        $edit_sno = $request->input('edit_sno');
        $event = EventModel::find($edit_sno);
        if (!$event) {
            return response()->json([
                'status' => 404,
                'message' => 'Event not found',
                'data' => null,
            ], 404);
        }

        // Set common fields
        $event->event_date = $event_date;
        $event->start_time = $start_time;
        $event->end_time = $end_time;
        $event->event_name = $event_name;
        $event->event_key_tag = $event_key_tag;
        $event->event_type_id = $event_type;
        $event->event_category = $event_category;
        $event->location_url = $location_url;
        $event->event_address = $event_address;
        // $event->zoom_link = $request->input('zoom_link');
        $event->event_offer = $event_offer;
        $event->event_amount = $event_amount ? $event_amount : 0;
        $event->coupon_code = $coupon_code ? $coupon_code : null;
        $event->participants = $participants;
        $event->no_of_participants = $no_of_participants ? $no_of_participants : null;
        $event->contact_person_name = $contact_person_name;
        $event->contact_person_mob_no = $contact_person_number;
        $event->certificate = $certificate_check;
        $event->certificate_type = $certificate_type ? $certificate_type : null;

        $event->branch_id = $branch_id;
        $event->handle_type = $handle_type;
        $event->handle_staff_id = $handle_staff_id;
        $event->handle_others_name = $handle_others_name;
        $event->handle_others_mobile = $handle_others_mobile;

        $event->event_description = $event_desc;

        // Set audit fields
        // $user_id = 1;
        // Replace with actual authenticated user ID
        $event->updated_by = $request->user()->user_id;

        // Save updated event details
        $event->update();
        // return $request;

        // Flash message based on save result
        if ($event) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'event updated Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the event!',
            ]);
        }
        // return $request;
        // Redirect to event list page
        return redirect('events');
    }

    public function ActiveEvent($id, Request $request)
    {
        $upd_EventModel = EventModel::where('sno', $id)->first();
        $upd_EventModel->active_Event = $request->input('active_Event', 0);
        $upd_EventModel->update();
        if ($upd_EventModel) {
            return response([
                'status' => 200,
                'message' => 'Event Active Successfully !',
                'error_msg' => 'Could not, Active Event !',
                'data' => $upd_EventModel->active_Event,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'Could not Active Event !',
                'error_msg' => 'Could not, Active  Event !',
                'data' => null,
            ], 200);
        }
    }

    public function EventExportExcel()
    {
        return Excel::download(new EventExports, 'event-export.xlsx'); // Adjust filename and extension as needed
    }

    public function DropEvent(Request $request)
    {
        $id = $request->input('event_drop_sno');
        $drop_reason = $request->input('drp_reason');
        $upd_EventModel = EventModel::where('sno', $id)->first();
        $upd_EventModel->status = 3;
        $upd_EventModel->drop_reason = $drop_reason;
        $upd_EventModel->Update();
        if ($upd_EventModel) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Event Dropped Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not Drop the Event!',
            ]);
        }
        return redirect('events');
    }

     public function AddEventParticipant(Request $request)
    {
        //  return $request;
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'participant_event_id' => 'required|integer',  
            'participant_name' => 'required',  
        ]);
    
        // Check if validation fails
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format in input fields.'
            ]);
            return redirect()->back();
        }
    
        // Get the user information and request data
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $event_id = $request->participant_event_id;
        $participant_name = $request->participant_name;
        $mobile_no = $request->participant_mobile;
        $alter_mobile_no = $request->participant_alter_mobile;
        $participant_email = $request->participant_email;
        $participant_type = $request->partpts_type ;
        $other_value  = $participant_type =='Others' ? $request->participant_other_value : null;
        $college_name  =$participant_type =='Student' ? $request->participant_college : null;
   
        $chk = ParticipantModel::where('event_id', $event_id)
            ->where('mobile_no', $mobile_no)
            ->where('branch_id', $branch_id)
            ->first();
            if($chk){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Participant Mobile Number is Already Exists!',
            ]);
            return redirect()->back();
            }
            else{
                $last_participant_entry = ParticipantModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();
                    
                if (!$last_participant_entry) {
                    $year = substr(date('y'), -2);
                    $participant_id = 'EPT-0001/' . $year;
                } else {
                    $data = $last_participant_entry->participant_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $participant_id = sprintf('EPT-%04d', $next_number) . '/' . substr(date('y'), -2);
                }
    
                // Create a new participant entry for the student
                $add = new ParticipantModel();
                $add->participant_id = $participant_id;
                $add->participant_name = $participant_name;
                $add->event_id = $event_id;
                $add->mobile_no = $mobile_no;
                $add->alter_mobile_no = $alter_mobile_no;
                $add->participant_email = $participant_email;
                $add->participant_type = $participant_type;
                $add->other_value = $other_value;
                $add->college_name = $college_name;
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                // raw lead save
                if ($add->save()) {  
                    $eventdata = DB::table('et_event')
                    ->select('et_event.event_name', 'et_lead_source.sno as lead_source_id')
                    ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
                    ->leftJoin('et_lead_source', function ($join) {
                        $join->on('et_lead_source.lead_source_name', 'like', DB::raw('CONCAT("%", et_event_category.event_category_name, "%")'));
                    })
                    ->where('et_event.sno', $event_id)
                    ->first();

                    $lead_name = $participant_name;
                    $lead_mobile =  $mobile_no;
                    $lead_date     = date('Y-m-d');
                    $lead_source_id=$eventdata->lead_source_id ?? 21;
                    $lead_group=$eventdata->event_name ?? 'Event';
                    // Check for existing mobile number
                    $chk_raw = RawLeadModel::where('lead_mobile', $lead_mobile)->first();
                    if ($chk_raw) {
                        session()->flash('toastr', [
                            'type' => 'success',
                            'message' => 'Participant added successfully!'
                        ]);
                    }else{
                        $chk_lead = DB::table('et_lead')->where('lead_mobile', $lead_mobile)->first();
                        if ($chk_lead) {
                            session()->flash('toastr', [
                                'type' => 'success',
                                'message' => 'Participant added successfully!'
                            ]);
                        }else{
                            $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();
                            $branch_code = $branch_check->city_short_code;
                    
                            $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                            $year = date("Y");
                            if (!$category_check) {
                                $lead_id = $year . '/' . $branch_code . '/' . "RL0001";
                            } else {
                                $data = $category_check->lead_id;
                                $slice = explode("/", $data);
                                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                                $next_number = (int)$resultcus + 1;
                                $lead_id = $year . '/' . $branch_code . '/' . sprintf("RL%04d", $next_number);
                            }
                    
                            $user_id = $request->user()->user_id;
                            $branch_id = $request->user()->branch_id;
                            // Create new lead
                            $new_lead = new RawLeadModel();
                            $new_lead->lead_id = $lead_id;
                            $new_lead->lead_name = $lead_name;
                            $new_lead->lead_mobile = $lead_mobile;
                            $new_lead->lead_source_id = $lead_source_id;
                            $new_lead->lead_group = $lead_group;
                            $new_lead->registered_date = $lead_date;
                            $new_lead->status = 6;
                            $new_lead->branch_id = $branch_id;
                            $new_lead->created_by = $user_id;
                            $new_lead->updated_by = $user_id;
                            if( $new_lead->save()){
                                session()->flash('toastr', [
                                    'type' => 'success',
                                    'message' => 'Participant added successfully!'
                                ]);
                            }
                        }

                    }   
                }
                    
    
            
        } 
    
        return redirect('events');
    }   

    public function View($id,Request $request)
    {   
        $branch_id = $request->user()->branch_id;
        $event_data = EventModel::select('et_event_category.event_category_name as event_category_name', 'et_event.*','et_staff.staff_name as conducted_staff_name','et_staff.nick_name as conducted_nick_name','et_branch.branch_name','et_branch.franchise_name')
        ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
        ->leftJoin('et_staff', 'et_event.handle_staff_id', '=', 'et_staff.sno')
        ->leftJoin('et_branch', 'et_event.branch_id', '=', 'et_branch.sno')
        ->where('et_event.status', '!=', 2)
        ->where('et_event.sno', $id)
        ->first(); 
      
        $applied_count = ParticipantModel::where('event_id',$id)
                            ->count();
                $event_data->applied_count=$applied_count ? $applied_count : 0;
           
        $students = DB::table('et_event_participant')
            ->select('et_event_participant.*')
            ->join('et_event','et_event.sno','=','et_event_participant.event_id')
            ->where('et_event.status', '!=', 2)
            ->where('et_event_participant.event_id', $id)
            ->orderBy('et_event_participant.participant_name', 'asc')
            ->get();

            $helper = new \App\Helpers\Helpers();
        foreach ($students as $index => $student) {
            $student->encrypted_sno = $helper->encrypt_decrypt($student->sno, 'encrypt');
            $student->encrypted_index = $helper->encrypt_decrypt($index + 1, 'encrypt'); // Encrypt index + 1
        }
        $event_data->student_list = $students;  
        
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $event_data ,
        ], 200);
    }


    public function eventStatusChange($id,Request $request)
    {
      $upd_eventModel =  EventModel::where('sno', $id)->first();
  
      $event_status = $request->status;
  
      $upd_eventModel->status  =  $event_status;
      $upd_eventModel->Update();
      if ($upd_eventModel) {
          return response([
          'status'    => 200,
          'message'   => 'Event Status Update Successfully',
          'error_msg' => null,
          'data'      => null,
          ], 200);
      } else {
          return response([
          'status'    => 200,
          'message'   => 'Could not Update Event Status!',
          'error_msg' => null,
          'data'      => null,
          ], 200);
      }
    }

    public function AllBranchStaffList(Request $request)
    {
      $branch_id = $request->input('branch_id');
      $staff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                      ->where('et_staff.status', 0)
                      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                      ->where('et_staff.branch_id', $branch_id);
      $staff = $staff->orderBy('et_staff.staff_name', 'asc')
        ->distinct() // Ensure unique rows
        ->get();
  
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $staff,
      ], 200);

    }

      //event_certificate_print
  public function EventCertificate($id = '',Request $request)
  {
    
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

      $event_certificate = DB::table('et_event_participant')
      ->select(
        'et_event_participant.*',
        'bh.staff_name as bh_staff_name',
        'bh.nick_name as bh_nick_name',
        'bh.mobile_no as bh_mobile_no',
        'et_event.event_name',
        'et_event.event_date',
        'et_branch.franchise_name',
        'et_event_category.event_category_name as event_category_name',
        'et_branch.branch_name',
        'et_branch.cert_auth_name',
        'et_branch.cert_auth_sign',
        'et_branch.branch_head_sign'
        )
          ->Join('et_event', 'et_event_participant.event_id', '=', 'et_event.sno')
           ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
          ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_event.branch_id')
          ->leftJoin('et_staff as bh', 'bh.sno', '=', 'et_branch.authority_id')
          ->where('et_event_participant.sno', $decryptedValue)
          ->first();
          
         

      return view('content.marketing_management.events.participants_certificate', [
          'event_certificate' => $event_certificate,
      ]);
  }
  
  
     public function EventCertificateDownload($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    
                
                                
    $event_certificate = DB::table('et_event_participant')
      ->select(
        'et_event_participant.*',
        'bh.staff_name as bh_staff_name',
        'bh.nick_name as bh_nick_name',
        'bh.mobile_no as bh_mobile_no',
        'et_event.event_name',
        'et_event.event_date',
        'et_branch.franchise_name',
        'et_event_category.event_category_name as event_category_name',
        'et_branch.branch_name',
        'et_branch.cert_auth_name',
        'et_branch.cert_auth_sign',
        'et_branch.branch_head_sign'
        )
          ->Join('et_event', 'et_event_participant.event_id', '=', 'et_event.sno')
           ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
          ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_event.branch_id')
          ->leftJoin('et_staff as bh', 'bh.sno', '=', 'et_branch.authority_id')
          ->where('et_event_participant.sno', $decryptedValue)
          ->first();
          $options = new \Dompdf\Options();
        $options->set('defaultFont', 'sofia');
    // return view('content.customer_management.manage_nda.nda_download', compact('edit', 'id','terms'));
    $pdf = PDF::loadView('content.marketing_management.events.event_certificate_download', [
             'event_certificate' => $event_certificate,
        ])
           
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
             ->setOption('enable-javascript', true)
            ->setOption('javascript-delay', 200)
            ->setOption('defaultFont', 'sofia')
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        //     $dompdf = $pdf->getDomPDF();
        
        // // Get font metrics
        // $fonts = $dompdf->getFontMetrics();
        
        // // Dump registered fonts
        // dd($fonts);
           
            $customPaper = [0, 0, 1123, 794];

            $pdf->setPaper($customPaper, 'landscape');
        // return $pdf;  
        // return $pdf->stream('certificate_print.pdf');
        date_default_timezone_set('Asia/Kolkata'); 

        DB::table('et_event_participant')
                                ->where('sno', $id)
                                ->where('download_status', 0)
                                ->update(['download_status' => 1,'download_date_time'=>now()]);
                                
        // return $pdf->stream('event_certificate.pdf');   
        return $pdf->download('event_certificate.pdf');   
  }
  
     public function sendEventCertificate(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'lead_id'  => 'required',
            
        ]);
        // If validation fails, return a response with errors
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        $branch_id  = $request->user()->branch_id;
        $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

        $id=$request->lead_id;
       
        $event_certificate = DB::table('et_event_participant')
              ->select(
                'et_event_participant.*',
                'bh.staff_name as bh_staff_name',
                'bh.nick_name as bh_nick_name',
                'bh.mobile_no as bh_mobile_no',
                'et_event.event_name',
                'et_event.event_date',
                'et_branch.franchise_name',
                'et_event_category.event_category_name as event_category_name',
                'et_branch.branch_name',
                'et_branch.cert_auth_name',
                'et_branch.cert_auth_sign',
                'et_branch.branch_head_sign'
                )
                  ->Join('et_event', 'et_event_participant.event_id', '=', 'et_event.sno')
                   ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
                  ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_event.branch_id')
                  ->leftJoin('et_staff as bh', 'bh.sno', '=', 'et_branch.authority_id')
                  ->where('et_event_participant.sno', $id)
                  ->first();
                  $helper = new \App\Helpers\Helpers();
                  $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
               $event_date =$event_certificate->event_date ? date($common_date_format, strtotime($event_certificate->event_date)) : '22 May 2025'  ;

        $branch_name = "";
        if ($branchData->branch_type == 1) {
            $branch_name = $branchData->branch_name;
        } elseif ($branchData->branch_type == 2) {
            $branch_name = $branchData->franchise_name;
        }

        // Extract the validated data
        $lead_mobile           = $event_certificate->mobile_no;
        $lead_email           = $event_certificate->participant_email;
        $lead_name= $event_certificate->participant_name;
        $event_name= $event_certificate->event_name;
       
        
        $user_id           = $request->user()->user_id;
        // Send email if email flag is set to true
         $helper = new \App\Helpers\Helpers();
          $encrypted_values = $helper->encrypt_decrypt($id, 'encrypt');
             $entityData='';
       
           $Link =url('event/event_certificate_download/' . $encrypted_values);
        
        
            if(!$event_certificate->certificate_link){
                 $channelId = 12;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                 
                 if($shortUrl){
                        DB::table('et_event_participant')
                        ->where('sno', $id)
                        ->update(['certificate_link' => $shortUrl]);
                 }
                 
              }
              
              $participantData=DB::table('et_event_participant')->where('et_event_participant.sno',$id)->first();
              $shortsendUrl = $participantData->certificate_link ;
              
              $certificate_key = basename($shortsendUrl);
        
      
                    if($lead_email){
                             try {
                     
                              $email_template_id = 11; // Event Certificate template
                              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                    
                              $content = $emailTemplate->email_subject;
                              $content = str_replace('#name', $lead_name, $content);
                              $content = str_replace('#EventName', $event_name ?? 'Event', $content);
                              $branchNo = $branchData->mobile;
                              $branchemail = $branchData->mail;
                              $fbLink = $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                              $instaLink = $branchData->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                              $content = str_replace('#link_certificate', $shortsendUrl , $content);
                              $content = str_replace('#EventDate', $event_date , $content);
                              $content = str_replace('#CRENo', $branchData->cre_mobile ?? '9677781155', $content);
                              $content = str_replace('#BranchName', $branch_name ?? 'Elysium Technology', $content);
                              $content = str_replace('#mail', $branchData->mail ?? 'info@elysiumacademy.org', $content);
                    
                              $mailData = [
                                'url' => 'Eapl.com',
                                'subject' => $emailTemplate->email_name,
                                'content' => $content,
                                'branchNo' => $branchNo,
                                'branchemail' => $branchemail, // Use the message content from the request
                                'fbLink' => $fbLink, // Use the message content from the request
                                'instaLink' => $instaLink, // Use the message content from the request
                                'salesMobile' => $branchData->sales_mobile,
                              ];
                    
                              $to_address = $lead_email;
                              $from_address = 'elysiumtechnology@elysium.community';
                             $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                              Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                              
                             DB::table('et_event_participant')
                                ->where('sno', $id)
                                ->update(['email_send' => 1]);
                             } catch (\Exception $e) {
                        
                                // Mark as failed
                                DB::table('et_event_participant')
                                    ->where('sno', $id)
                                    ->update(['email_send' => 2]);
                            }
                    }
                    else{
                        
                    }
                    
                    if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "download_your_ecertificate";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'download_your_ecertificate') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           =>$event_certificate->participant_name ?? "participant",
                                        'parameter_name' => 'participant_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $event_certificate->event_name ?? "Workshop",
                                        'parameter_name' => 'event_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $event_date,
                                        'parameter_name' => 'event_date',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $shortsendUrl,
                                        'parameter_name' => 'certificate_link',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $branch_data->sales_mobile ?? '9677781155',
                                        'parameter_name' => 'support_contact',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           =>  $branch_data->mail ?? 'info@elysiumacademy.org',
                                        'parameter_name' => 'support_email',
                                    ]
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $certificate_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                               $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
                                $accessToken               = $this->accessData($request)->access_tokken;
                                $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                             $mobile = preg_replace('/\D/', '', $lead_mobile); // remove any non-digits
                                if (strpos($lead_mobile, '+') === 0) {
                                    $to = $lead_mobile;
                                } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                                    $to = '+' . $mobile;
                                } else {
                                    $to = '+91' . $mobile;
                                }
                            $languageCode = 'en';
                
                            // if (strpos($to, $countryCode) !== 0) {
                            //     $to = $countryCode . $to;
                            // }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {
                               DB::table('et_event_participant')
                                ->where('sno', $id)
                                ->update([
                                    'certificate_status' => 1,
                                    'download_status' => 0,
                                    'download_date_time'=>NULL,
                                ]);
                         }
                         else{
                              DB::table('et_event_participant')
                                ->where('sno', $id)
                                ->update(['certificate_status' => 2]);
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                   'certificate_status'=>2,
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
                    else{
                          DB::table('et_event_participant')
                                            ->where('sno', $id)
                                            ->update([
                                                'certificate_status' => 0,
                                            ]);
                         return response([
                              'status' => 200,
                              'message' => 'Mobile no not found',
                              'error_msg' => 'mobile no not found',
                              'certificate_status'=>0,
                            ], 200);
                                  
                      }
                    
                    
        
        return response([
            'status'    => 200,
            'message'   => "Message sent successfully",
            'certificate_status'=>1,
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
     public function accessData(Request $request){
        
        $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 1)->first();
        return $whatsappConfig;
    }

    private function sendRequestToWhatsApp($url, $token, $data)
    {
      try {
        $client = new \GuzzleHttp\Client();
        $response = $client->post($url, [
          'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json',
          ],
          'json' => $data,
          
        ]);
  
        return [
          'status' => $response->getStatusCode(),
          'data' => json_decode($response->getBody(), true),
        ];
      } catch (\Exception $e) {
        return [
          'status' => 400,
          'error' => $e->getMessage(),
        ];
      }
    }
 
    public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
        
        
        public function generateQrEvent($id, Request $request)
    {
        
    
        // Encode sno in base64 (shorter than Crypt)
        $encodedId = base64_encode($id);
    
        $qrContent = url("/event_qr/{$encodedId}");
    
        // Generate QR as base64 image
        $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=300x300";
        $qrImageData = @file_get_contents($qrServerUrl);
        $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        // Save scan details
        
    
        return response()->json([
            'status'    => $qrBase64 ? 200 : 500,
            'qr_base64' => $qrBase64,
            'link'      => $qrContent,
        ]);
    }
    
    private function saveScanDetails($event_id,Request $request)
    {
        // Get the user's IP address
        $ipAddress = $request->ip();
    
        // Get latitude and longitude if provided by frontend (JavaScript geolocation)
        $latitude = $request->input('latitude', null);
        $longitude = $request->input('longitude', null);
    
        // Get area from IP address (you can use any IP geolocation API)
        // $area = $this->getAreaByIp($ipAddress);
        $area="";
        // Get device information (User-Agent string)
        $deviceInfo = $request->header('User-Agent');
        $isMobile = preg_match('/Mobile|Android|iP(hone|od|ad)|IEMobile|BlackBerry|Opera Mini/i', $deviceInfo);
                
        $deviceType = $isMobile ? 'Mobile' : 'Desktop';
    
        // Insert the scan data into the database
        EventQRScannerModel::create([
            'event_id'      => $event_id,
            'ipaddress' => $ipAddress,
            'latitude'   => $latitude,
            'longitude'  => $longitude,
            'area'       => $area,
            'device'=> $deviceType,
        ]);
    }
    
    
     public function EventQrForm($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        // $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
          $decodeId = base64_decode($id);

        if (!$decodeId) {
            return view('errors.invalid_coupon');
        }
        
        //  $scanTracked = session('event_scan_tracked_' . $decodeId);

        // if (!$scanTracked) {
        //     // Save the scan details if not tracked already
        //     $this->saveScanDetails($decodeId, $request);
    
        //     // Set a session flag to indicate that the scan has been tracked for this event
        //     session(['event_scan_tracked_' . $decodeId => true]);
        // }


        $today = date('Y-m-d');
    
        $QR_data = EventModel::select('et_event_category.event_category_name as event_category_name', 'et_event.*')
            ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
            ->where('et_event.status', '!=', 2)
            ->where('et_event.sno', $decodeId)
            ->first(); 
            $applied_count = ParticipantModel::where('event_id',$decodeId)
                                ->count();
            if($applied_count){
                $QR_data->applied_count=$applied_count ? $applied_count : 0;
            }else{
                $QR_data->applied_count=0;
            }
            
               
            $students = DB::table('et_event_participant')
                ->select('et_event_participant.*')
                ->join('et_event','et_event.sno','=','et_event_participant.event_id')
                ->where('et_event.status', '!=', 2)
                ->where('et_event_participant.event_id', $decodeId)
                ->orderBy('et_event_participant.participant_name', 'asc')
                ->get();

        if (!$QR_data) {
            return view('errors.invalid_coupon');
        }

        $branch_data = BranchModel::where('sno', $QR_data->branch_id)
            ->select(
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mobile',
                'et_branch.branch_name',
                'et_branch.sno AS branch_id',
                'et_branch.branch_type',
                'et_branch.franchise_name',
                'et_branch.mail',
                'et_branch.area_street',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')->first();
            
        if (!$branch_data) {
            return view('errors.invalid_coupon');
        }

        return view('content.marketing_management.events.event_qr_page', [
            'Branch_details' => $branch_data,
            'QR_data' =>  $QR_data
        ]);
    }

    public function checkEventMobileExists(Request $request)
    {
        $lead_mobile = $request->input('mobile');
        $event_id = $request->input('event_id');

        $existsInEventLead = DB::table('et_event_participant')
            ->where('mobile_no', $lead_mobile)
            ->where('event_id', $event_id)
            ->exists();

        $exists = $existsInEventLead ;

        return response()->json(['exists' => $exists]);
    }
    
    
    
     public function AddQrParticipant(Request $request)
    {
        $validated = $request->validate([
            'lead_mobile'    => 'required|string|max:15',
            'lead_name'      => 'required|string|max:255',
        ]);

       
      
        $lead_email=$request->lead_email;
        $event_id=$request->event_id;
        
        $eventData = DB::table('et_event')
            ->where('sno', $event_id)
            ->first();

          
            $branch_id = $eventData->branch_id;
            $user_id = 0;
            $participant_name = $request->lead_name;
            $mobile_no = $request->lead_mobile;
            $participant_email = $lead_email;
            
            $chk = ParticipantModel::where('event_id', $event_id)
            ->where('mobile_no', $mobile_no)
            ->first();
            
            if($chk){
             return response()->json(['error' => false, 'message' => 'You Already Applied This Event.'], 500);
            }else{
                 $last_participant_entry = ParticipantModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();
                    
                if (!$last_participant_entry) {
                    $year = substr(date('y'), -2);
                    $participant_id = 'EPT-0001/' . $year;
                } else {
                    $data = $last_participant_entry->participant_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $participant_id = sprintf('EPT-%04d', $next_number) . '/' . substr(date('y'), -2);
                }
                $ipAddress = $request->ip();
                // Create a new participant entry for the student
                $add = new ParticipantModel();
                $add->participant_id = $participant_id;
                $add->participant_name = $participant_name;
                $add->event_id = $event_id;
                $add->mobile_no = $mobile_no;
                $add->participant_email = $participant_email;
                $add->ipAddress = $ipAddress;
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                // raw lead save
                if ($add->save()) {  
                    $eventdata = DB::table('et_event')
                    ->select('et_event.event_name', 'et_lead_source.sno as lead_source_id','et_event.branch_id','et_event.event_date','et_event.start_time','et_event.end_time','et_event.event_type_id','et_event.contact_person_mob_no')
                    ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
                    ->leftJoin('et_lead_source', function ($join) {
                        $join->on('et_lead_source.lead_source_name', 'like', DB::raw('CONCAT("%", et_event_category.event_category_name, "%")'));
                    })
                    ->where('et_event.sno', $event_id)
                    ->first();
                    $values = $add->sno;
                    // Encrypt the combined values
                    $helper = new \App\Helpers\Helpers();
                    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');
                    

                    $lead_name = $participant_name;
                    $lead_mobile =  $mobile_no;
                    $lead_date     = date('Y-m-d');
                    $lead_source_id=$eventdata->lead_source_id ?? 21;
                    $lead_group=$eventdata->event_name ?? 'Event';
                    $event_mode =$eventdata->event_type_id;
                    $contact_person_no =$eventdata->contact_person_mob_no;
                    
                    // Use Carbon to format the date and time
                    $event_date = Carbon::parse($eventdata->event_date)->format('d-M-Y');  // Format the date like 14-Oct-2024
                    $start_time = Carbon::parse($eventdata->start_time)->format('h:i A');  // Format time to 10:30 AM
                    $end_time = Carbon::parse($eventdata->end_time)->format('h:i A');  // Format time to 12:30 PM
                 
                    $event_date_time = $event_date.', '.$start_time.' to '.$end_time;
                    
                      $branchData = BranchModel::where('status', 0)->where('sno', $eventdata->branch_id)->first();
                        $entityData='';
                    // communication Send
                        if($participant_email){
                            
                            try{
                              $email_template_id = 10; // Event Certificate template
                              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                              $dynamicSubject = str_replace('#eventName',$eventdata ? $eventdata->event_name : 'Event',$emailTemplate->email_name);
                             
                              $content = $emailTemplate->email_subject;
                              $content = str_replace('#parti_name', $participant_name, $content);
                              $content = str_replace('#event_name', $eventdata ? $eventdata->event_name : 'Event', $content);
                              $branchNo = $branchData->mobile;
                              $branchemail = $branchData->mail;
                              $fbLink = $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                              $instaLink = $branchData->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                              $content = str_replace('#event_date', $event_date_time , $content);
                              $content = str_replace('#mode_type', $event_mode , $content);
                              $content = str_replace('#contact_number', $contact_person_no ?? '9677781155', $content);
                    
                              $mailData = [
                                'url' => 'Eapl.com',
                                'subject' => $dynamicSubject,
                                'content' => $content,
                                'branchNo' => $branchNo,
                                'branchemail' => $branchemail, // Use the message content from the request
                                'fbLink' => $fbLink, // Use the message content from the request
                                'instaLink' => $instaLink, // Use the message content from the request
                                'salesMobile' => $branchData->sales_mobile,
                              ];
                    
                              $to_address = $participant_email;
                              $from_address = 'elysiumtechnology@elysium.community';
                              $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                              Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                              
                            } catch (\Exception $e) {
                                  
                                }
                           
                        }
                    
                        if ($lead_mobile) {
                            
                            $templateName  = "event_confirmation";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            
            
                            if ($templateName == 'event_confirmation') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           =>  $participant_name,
                                        'parameter_name' => 'parti_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $eventdata->event_name ?? 'Event',
                                        'parameter_name' => 'event_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $event_date_time,
                                        'parameter_name' => 'event_date',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $event_mode,
                                        'parameter_name' => 'mode_type',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $contact_person_no ?? '9677781155',
                                        'parameter_name' => 'contact_number',
                                    ]
                                ];
                                $hasHeader = false;
                                $hasBody   = true;
                                $hasButton = false;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $event_mode,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                               $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
                                $accessToken               = $this->accessData($request)->access_tokken;
                                $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                             $mobile = preg_replace('/\D/', '', $lead_mobile); // remove any non-digits
                                if (strpos($lead_mobile, '+') === 0) {
                                    $to = $lead_mobile;
                                } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                                    $to = '+' . $mobile;
                                } else {
                                    $to = '+91' . $mobile;
                                }
                            $languageCode = 'en';
                
                            // if (strpos($to, $countryCode) !== 0) {
                            //     $to = $countryCode . $to;
                            // }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         
                        
                  }
                    
                    // Check for existing mobile number
                    $chk_raw = RawLeadModel::where('lead_mobile', $lead_mobile)->first();
                    if ($chk_raw) {
                       return response()->json(['success' => true, 'link' => $encrypted_values]);
                    }else{
                        $chk_lead = DB::table('et_lead')->where('lead_mobile', $lead_mobile)->first();
                        if ($chk_lead) {
                           return response()->json(['success' => true, 'link' => $encrypted_values]);
                        }else{
                            $branch_check = BranchModel::where('sno', $eventdata->branch_id)->first();
                            $branch_code = $branch_check->city_short_code;
                    
                            $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                            $year = date("Y");
                            if (!$category_check) {
                                $lead_id = $year . '/' . $branch_code . '/' . "RL0001";
                            } else {
                                $data = $category_check->lead_id;
                                $slice = explode("/", $data);
                                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                                $next_number = (int)$resultcus + 1;
                                $lead_id = $year . '/' . $branch_code . '/' . sprintf("RL%04d", $next_number);
                            }
                    
                            $user_id = $request->user()->user_id ?? 0;
                            $branch_id = $request->user()->branch_id ?? $eventdata->branch_id;
                            // Create new lead
                            $new_lead = new RawLeadModel();
                            $new_lead->lead_id = $lead_id;
                            $new_lead->lead_name = $lead_name;
                            $new_lead->lead_mobile = $lead_mobile;
                            $new_lead->lead_source_id = $lead_source_id;
                            $new_lead->lead_group = $lead_group;
                            $new_lead->registered_date = $lead_date;
                            $new_lead->status = 6;
                            $new_lead->branch_id = $branch_id;
                            $new_lead->created_by = $user_id ?? 0;
                            $new_lead->updated_by = $user_id ?? 0;
                            if( $new_lead->save()){
                               
                            }
                        }

                    }   
                }
            }

    

        if ($add) {
            return response()->json(['success' => true, 'link' => $encrypted_values]);
        } else {
            return response()->json(['error' => false, 'message' => 'Error inserting record.'], 500);
        }
    }
    
    public function EventAppliedSuccess($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $QR_data = DB::table('et_event_participant')
          ->select(
            'et_event_participant.*',
            'bh.staff_name as bh_staff_name',
            'bh.nick_name as bh_nick_name',
            'bh.mobile_no as bh_mobile_no',
            'et_event.event_name',
            'et_event.event_date',
            'et_event.start_time',
            'et_event.event_description',
            'et_event.contact_person_mob_no',
            'et_event.end_time',
            'et_branch.franchise_name',
            'et_event_category.event_category_name as event_category_name',
            'et_branch.branch_name',
            'et_branch.cert_auth_name',
            'et_branch.cert_auth_sign',
            'et_branch.branch_head_sign'
            )
              ->Join('et_event', 'et_event_participant.event_id', '=', 'et_event.sno')
               ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
              ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_event.branch_id')
              ->leftJoin('et_staff as bh', 'bh.sno', '=', 'et_branch.authority_id')
              ->where('et_event_participant.sno', $decryptedValue)
              ->first();
        
    //  return $QR_data;
        return view('content.marketing_management.events.event_applied_success', [
            'QR_data' =>  $QR_data,
        ]);
    }

    public function participant_location_qr(Request $request)
    {
        // Validate request
        $validated = $request->validate([
            'event_id' => 'required|integer',
        ]);
        
        $event_id=$request->event_id;
    
       $scanTracked = session('event_scan_tracked_' . $event_id);
       try {
            if (!$scanTracked) {
                $this->saveScanDetails( $event_id,$request);
              
                session(['event_scan_tracked_' . $event_id => true]);
                  return response()->json(['success' => true]);
            }else{
                return response()->json(['success' => true]);
            }
       } catch (\Exception $e) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
         
           
    }
    
    
       public function Scanner_view(Request $request)
    {
            $search_fill = $request->search_fill ?? '';
            $user_id     = $request->user()->user_id;
            $branch_id   = $request->user()->branch_id;
            $role_id   = $request->user()->role_id;
            $sno = $request->sno ?? '';
            $List_table = EventQRScannerModel::where('et_event_qr_scanner.event_id',$sno)->select('et_event_qr_scanner.*','et_event_participant.participant_name')
            ->leftJoin('et_event_participant', function($join) use ($sno) {
                                $join->on('et_event_participant.ipaddress', '=', 'et_event_qr_scanner.ipaddress')
                                     ->where('et_event_participant.event_id', '=', $sno); // subquery-like condition
                            })
                    ->orderBy('et_event_qr_scanner.sno','desc')->get();
        // return $ListTable;
        return view('content.marketing_management.events.qr_scannerTable', compact('List_table'));
    }
   
    public function MultiMap(Request $request){
        $sno = $request->sno ?? '';
        $locations = EventQRScannerModel::where('et_event_qr_scanner.event_id', $sno)
                         ->leftJoin('et_event_participant', function($join) use ($sno) {
                                $join->on('et_event_participant.ipaddress', '=', 'et_event_qr_scanner.ipaddress')
                                     ->where('et_event_participant.event_id', '=', $sno); // subquery-like condition
                            })
                        ->where('et_event_qr_scanner.latitude','!=',NULL)
                        ->where('et_event_qr_scanner.longitude','!=',NULL)
                        ->select('et_event_qr_scanner.latitude', 'et_event_qr_scanner.longitude', 'et_event_qr_scanner.ipaddress as name','et_event_participant.participant_name') // adjust columns
                        ->get();
        return response()->json($locations);
    }
    
    public function updateAttendance(Request $request)
    {
        $attendanceData = $request->input('attendance_data');
        $event_id = $request->input('event_id');
    // return $attendanceData;
        foreach ($attendanceData as $data) {
            // Update attendance_check for each student based on sno
            $student = ParticipantModel::where('sno', $data['sno'])->first();
    
            if ($student) {
                $student->attendance_check = $data['attendance_status'];
                $student->save();
            }
        }
        if($event_id){
             $upd_eventModel =  EventModel::where('sno', $event_id)->first();
              $attendance_status = 1;
              $upd_eventModel->attendance_status  =  $attendance_status;
              $upd_eventModel->Update();
        }
    
        return response()->json(['success' => true]);
    }
    
    public function ViewUpdated($id,Request $request)
    {   
        $branch_id = $request->user()->branch_id;
        $event_data = EventModel::select('et_event_category.event_category_name as event_category_name', 'et_event.*')
        ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
        ->where('et_event.status', '!=', 2)
        ->where('et_event.sno', $id)
        ->first(); 
        
       
        
        $applied_count = ParticipantModel::where('event_id',$id)
                            ->count();
                            
        $event_data->applied_count=$applied_count ? $applied_count : 0;
           
        $students = DB::table('et_event_participant')
            ->select('et_event_participant.*')
            ->join('et_event','et_event.sno','=','et_event_participant.event_id')
            ->where('et_event.status', '!=', 2)
            ->where('et_event_participant.attendance_check', 1)
            ->where('et_event_participant.event_id', $id)
            ->orderBy('et_event_participant.participant_name', 'asc')
            ->get();

            $helper = new \App\Helpers\Helpers();
        foreach ($students as $index => $student) {
            $student->encrypted_sno = $helper->encrypt_decrypt($student->sno, 'encrypt');
            $student->encrypted_index = $helper->encrypt_decrypt($index + 1, 'encrypt'); // Encrypt index + 1
        }
        $event_data->student_list = $students;  
        
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $event_data ,
        ], 200);
    }
    
    public function AddPosterTemplate(Request $request){
        
        // return $request;
         $chk = EventPosterModel::where('poster_template', $request->template_name)->where('status', '!=', 2)->first();

          if ($chk) {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Template Name has been already created!'
            ]);
            return redirect()->back();
          }
    
            $user_id = $request->user()->user_id ?? 1;
  
     $template_name=$request->template_name;
     $poster_type=  $request->poster_type;
     $poster_image = '';
     $request = request(); // Assuming the request object is available.

        if ($request->hasFile('template_image')) {
            // Define the base directory for logos
            $poster_base_path = public_path('Poster_images');
        
            // Ensure the directory for the company exists, or create it
            if (!is_dir($poster_base_path)) {
                mkdir($poster_base_path, 0777, true);
            }
        
            // Define the base filename
            $base_name = 'poster_';
            $extension = $request->file('template_image')->extension();
        
            // Start by checking for the first available file name (entity_1.png, entity_2.jpg, etc.)
            $i = 1;
            do {
                $poster_image_name = $base_name . $i . '.' . $extension;
                $file_path = $poster_base_path . DIRECTORY_SEPARATOR . $poster_image_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path)); // Check if the file already exists
        
            // Move the uploaded file to the company directory
            $request->file('template_image')->move($poster_base_path, $poster_image_name);
            $poster_image = $poster_image_name; // Assign the filename to the entity_logo variable
        }
    $Add = new EventPosterModel();

    $Add->poster_type_id = $poster_type;
    $Add->poster_template = $template_name;
    $Add->poster_image = $poster_image;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Poster Template added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Poster Template!'
      ]);
    }

    return redirect()->back();
        
    }
    
     public function PosterListByType(Request $request)
  {

      $type_id = $request->input('type_id');
      $Poster = EventPosterModel::where('status', 0)
    //   ->where('poster_type_id', $type_id)
      ->orderBy('sno', 'desc')->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $Poster
      ], 200);
  }

     public function get_poster_data(Request $request)
  {

      $template_id = $request->input('template_id');
      $Poster = EventPosterModel::where('status', 0)->where('sno', $template_id)->orderBy('sno', 'desc')->first();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $Poster
      ], 200);
  }


  public function GetScheduledEvent(Request $request){
        $event_id = $request->event_id;
        $eventData=EventModel::where('sno',$event_id)->first();

        if(!$eventData){
            return  response([
                'status'    => 200,
                'message'   => 'Event Not Found !',
                'error_msg' => null,
                'data'      => null
            ], 200);
        }else{
            $scheduled_events=EventModel::where('branch_id',$eventData->branch_id)->where('event_date','>=',date('Y-m-d'))->where('status', 0)->get();

            if(!$scheduled_events){
                return  response([
                    'status'    => 200,
                    'message'   => 'No Event Scheduled',
                    'error_msg' => null,
                    'data'      => null
                ], 200);
            }

            return  response([
                'status'    => 200,
                'message'   => count($scheduled_events).' Events Found',
                'error_msg' => null,
                'data'      => $scheduled_events
            ], 200);
        }

  }

  public function TranferEventParticipant(Request $request)
{
    $event_id = $request->event_id;
    $old_event_id = $request->old_event_id;
    $user_id = $request->user()->user_id;

    $participants = ParticipantModel::where('event_id', $old_event_id)->get();

    // Check if participants exist
    if ($participants->isEmpty()) {
        return response([
            'status'    => 404,
            'message'   => 'No participants found for this event!',
            'error_msg' => null,
            'data'      => null
        ], 404);
    }

    foreach ($participants as $participant) {
        $update_eachPart = ParticipantModel::where('sno', $participant->sno)->first();

        if ($update_eachPart) {
            // Update event and user info
            $update_eachPart->event_id = $event_id;
            $update_eachPart->updated_by = $user_id;
            $update_eachPart->save();

            // Log transfer
            $this->updateTranferLog($old_event_id, $update_eachPart, $user_id);
        }
    }

        $eventData=EventModel::where('sno',$old_event_id)->first();
        $eventData->transfer_participant = 1;
        $eventData->updated_by = $user_id;
        $eventData->save();

    return response([
        'status'  => 200,
        'message' => 'Participants transferred successfully!',
        'data'    => null
    ], 200);
}


public function updateTranferLog($old_event_id, $participant, $user_id)
{
    $transfer = new ParticipantTransferModel();
    $transfer->branch_id        = $participant->branch_id;
    $transfer->participant_id   = $participant->sno;
    $transfer->current_event_id = $old_event_id; // from where they were transferred
    $transfer->change_event_id  = $participant->event_id; // to which event they were transferred
    $transfer->created_by       = $user_id;
    $transfer->updated_by       = $user_id;
    $transfer->save();
}


    
}
