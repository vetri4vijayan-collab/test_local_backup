<?php

namespace App\Http\Controllers\payment_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerModel;
use App\Models\SubLedgerModel;
use App\Models\TransactionModel;
use Illuminate\Support\Facades\Http;
use App\Models\BranchModel;
use App\Models\StaffModel;
use App\Models\ProductModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use PDF;

class Payment extends Controller
{
  
  protected $razorpayKey;
  protected $razorpaySecret;

  public function __construct()
  {
    $this->razorpayKey = 'rzp_live_1UWaj2nifGd7hH';
    $this->razorpaySecret = 'EK3odrpKfO9EiK7k0aRxuKBP';
    // $this->razorpayKey = 'rzp_test_cjiZ7kyueJCUGb';
    // $this->razorpaySecret = 'fG0zEeXUiJKNbggEKRhsJf0k';
  }
  
   public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $user_id   = $request->user()->user_id ;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      
      $search_fill = $request->search_fill ?? '';

    // Base query for customers joined with lead, excluding status=2
    $customersQuery = DB::table('et_customer_services')
        ->select('et_customer.*','et_customer_services.proposal_id')
        ->join('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_customer.status', '!=', 2)
        ->distinct('et_customer_services.proposal_id')
        ->where('et_lead.status', '!=', 2);

    if (!empty($search_fill)) {
        $customersQuery->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }

    $customers = $customersQuery->orderBy('et_customer.sno', 'desc')
        ->paginate($perpage);

    foreach ($customers as $customer) {
        $proposal_ids = json_decode($customer->proposal_ids, true);
        
        $proposal_data = DB::table('et_proposal')
            ->where('et_proposal.sno', $customer->proposal_id)
            ->where('et_proposal.status', '!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->first();
        $total_amount=$proposal_data->total_amount;
        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*')
                        ->where('et_proposal_pay_slot.proposal_sno',$customer->proposal_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->get();
        $paid_amount =$slots->sum('paidAmount');
    
        $customer->service_title = $proposal_data->service_title;
        $customer->pay_total_amount = $total_amount;
        $customer->paid_amount = $paid_amount;
        
        
    }
    $TodayPaymentCount=0;
    return view('content.payment_management.manage_payment.list',[
            'customers' => $customers,
            'search_fill' => $search_fill,
            'perpage' => $perpage,
            'TodayPaymentCount' => $TodayPaymentCount,
        ]);
  }
  public function cus_invoice($id,Request $request)
  {
      
       $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id =$decryptedValue;
    
     $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
     
        

              $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.proposal_id',$proposal->proposal_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->get();
                 $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.proposal_id',$proposal->proposal_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->first();
             
             $PaidAmount = $slots->sum('paidAmount');
             $total_balance =$slot_total->total_amount ? $slot_total->total_amount - $PaidAmount :0 ;
              $branch_data = DB::table('et_branch')
                ->select(
                    'et_branch.*', 
                    'et_cities.name as city_name', 
                    'et_countries.name as country_name', 
                    'et_states.name as state_name'
                )
                ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
                ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
                ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
                ->where('et_branch.sno', $proposal->branch_id)
                ->first();
      
   
  
      $customer=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
    return view('content.payment_management.manage_payment.create_invoice',[
        
         'customer' =>$customer,
          'proposal' =>$proposal,
          'slots' =>$slots ,
          'total_balance' =>$total_balance ,
          'PaidAmount' =>$PaidAmount ,
          'branch_data' =>$branch_data ,
        ]);
  }
  public function cus_payment(Request $request)
  {
    return view('content.payment_management.manage_payment.payments');
  }
  public function manage_history(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $user_id   = $request->user()->user_id ;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      
      $search_fill = $request->search_fill ?? '';

    // Base query for customers joined with lead, excluding status=2
    $customersQuery = DB::table('et_transaction')
        ->select('et_customer.*','et_transaction.payment_id','et_transaction.payment_status','et_transaction.sno as trans_sno','et_proposal.proposal_id','et_proposal.gst_perc','et_proposal.gst_inclusive','et_transaction.invoice_id','et_payment.pay_slot_id','et_payment.payment_mode','et_payment.paid_amount','et_transaction.transaction_id','et_payment.proposal_id as proposal_sno','et_subledger.subledger_name','et_payment.transaction_date','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
        ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_subledger', 'et_subledger.payment_sno', '=', 'et_payment.sno')
        ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2)
        ->where('et_transaction.customer_type', 0)
        ->where('et_customer.branch_id', $branch_id)
        // ->whereMonth('et_payment.transaction_date', 8)
        ->where('et_transaction.status', 0);

    if (!empty($search_fill)) {
        $customersQuery->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }
    
    

    $customers = $customersQuery->orderBy('et_transaction.sno', 'desc')
        ->paginate($perpage);
        
        foreach($customers as $cus){
           $gst_rate= $cus->gst_perc/100;
           $tax_amount= $cus->paid_amount * $gst_rate;
           $cus->tax_amount=$tax_amount;
        }
    // return $customers;
    return view('content.payment_management.manage_history.list',[
            'customers' => $customers,
            'search_fill' => $search_fill,
            'perpage' => $perpage,
        ]);
  }
    
  public function payment_history_status_change(Request $request)
  {
    $id = $request->sts_change_id;
    $sts = $request->sts_change_type;
    $customer_id = $request->customer_id_hidden;
    $proposal_id = $request->proposal_id_hidden;
    $slot_id = $request->slot_id_hidden;
      $payment_id = $request->payment_id_hidden;
      $offline_description = $request->offline_description;
      $offline_transaction_id = $request->offline_transaction_id;
      //   return $request;
     $helper = new \App\Helpers\Helpers();
    // Find the record
    $OldCustomerModel = TransactionModel::where('sno', $id)->select('sno', 'payment_status')->first();
    
     $slots = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id)
                    ->where('status', 0)
                    ->first();
     $Payment = DB::table('et_payment')
                    ->where('sno', $payment_id)
                    ->where('status', 0)
                    ->first();
                    
     $transaction_date_edit = $request->transaction_date ? date('Y-m-d', strtotime($request->transaction_date)) : $slots->$transaction_date;
     $paid_amount = $request->paid_amount;
  
    
     if($sts ==1){
         $customer =DB::table('et_customer')->where('sno', $customer_id)->first();
       
            $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.nick_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$proposal_id)
              ->join('et_staff', 'et_proposal.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
         $slots = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id)
                    ->where('status', 0)
                    ->first();
        $paymentData=DB::table('et_payment')->where('et_payment.pay_slot_id',$slot_id)->first();
        
         //  communication Proposal
         $communicationStatusReceipt=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
         $communicationStatusNDA=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
         $communicationStatusCustomer=DB::table('et_communication_handle')->where('module_name','Customer Welcome')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         
         
         // Communication For Offline
         if($proposal->old_customer_check != 1){
            if($paymentData->payment_mode == 2){
                   $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                   $lead_name =$customer->cus_name ?? $lead->lead_name;
                   $lead_email_id =$customer->cus_email_id ?? $lead->lead_email_id;
                   $lead_mobile =$customer->cus_mobile ?? $lead->lead_mobile;
                    if ($customer->country_code) {
                        if($customer->cus_mobile){
                            $lead_call_code = ($customer->country_code == 0) ? '+91' : '+' . $customer->country_code;
                        }else{
                            $lead_call_code = ($lead->inter_calls) ? 
                            ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                        }
                        
                    } else {
                        $lead_call_code = ($lead->inter_calls) ? 
                            ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                    }

                   
                   
                   $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                   $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                   $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                   $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                   
                   $paidAmount=$paymentData->paid_amount;
                      
                       $transaction_date =  Carbon::parse($paymentData->transaction_date)->format('d M Y');
                     
                      $slotAmount = $proposal->currency_symbol . number_format($paidAmount, 2, '.', ',');
             
                 // Receipt Communication
                 if($communicationStatusReceipt && $communicationStatusReceipt->status == 0){
                     
                      $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
                      $Link_receipt = url('receipt_print/' . $encrypted_values_receipt);
                      
                      $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                      $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
                      $slot_url_key_receipt = basename($shortsendUrl_receipt);
                      
                      
                     
                     
                      
                      if(!$slots->receipt_temp_link){
                            $channelId_receipt = 7;
                             $shortUrlData_receipt = $this->shortenUrl($Link_receipt,$channelId_receipt);
                             $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
                             $urlId_receipt =$shortUrlData_receipt['id'];
                             if($shortUrl_receipt){
                                 DB::table('et_proposal_pay_slot')
                                    ->where('sno', $slot->sno)
                                    ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                    
                                      DB::table('et_chotta_links')->insert([
                                          'branch_id' => $proposal->branch_id,
                                          'chotta_link_id' => $urlId_receipt,
                                          'chotta_short_link' => $shortUrl_receipt,
                                          'large_encrypt_link' => $Link_receipt,
                                          'link_type' => 'Receipt Send',
                                          'pay_slot_id' =>$slot->sno,
                                          'created_by' => $proposal->created_by,
                                          'updated_by' => $proposal->created_by,
                                      ]);
                             }
                        }
                       
                      //   SMS Receipt
                      if($communicationStatusReceipt->sms ==0){
                          if ($lead_mobile) {
                
                                  $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                                  $authkey = $result_sms ? $result_sms->authkey : '';
                                  $sender_id = $result_sms ? $result_sms->sender_id : '';
                                  $template_id = $result_sms ? $result_sms->template_id : '';
                                  $country_code = $result_sms ? $result_sms->country_code : '';
                                  $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                                  $mobile_number = $country_code . $lead_mobile;
                        
                                 
                               
                        
                                  // Replace placeholders with actual values
                                  $replacement_values = [$lead_name,$shortsendUrl_receipt,$slotAmount,$cre_mobile];
                                  $message_content = preg_replace_callback(
                                    '/\{#var#\}/',
                                    function () use (&$replacement_values) {
                                      return array_shift($replacement_values);
                                    },
                                    $message_content
                                  );
                        
                                  $route = "default";
                                  $postData = array(
                                    'authkey' => $authkey,
                                    'mobiles' => $mobile_number,
                                    'message' => $message_content,
                                    'sender' => $sender_id,
                                    'route' => $route,
                                  );
                        
                                  // API URL
                                  $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                        
                                  // Initialize the resource
                                  $ch = curl_init();
                                  curl_setopt_array($ch, array(
                                    CURLOPT_URL => $url,
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_POST => true,
                                    CURLOPT_POSTFIELDS => $postData,
                                    CURLOPT_SSL_VERIFYHOST => 0,
                                    CURLOPT_SSL_VERIFYPEER => 0,
                                  ));
                        
                                  // Get response
                                  $response = curl_exec($ch);
                                  // return $response;
                                  $err = curl_error($ch);
                                  curl_close($ch);
                                }
                      }
                        // return "sms success";
                      //   Email Receipt
                      if($communicationStatusReceipt->email ==0){
                          if ($lead_email_id) {
                                $emailTemplate_id =7; // proposal send Template Id
                                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                    
                                // Gender condition
                                $genderPrefix = 'Mr/Ms'; // Default value
                                if ($lead->lead_gender == 1) {
                                  $genderPrefix = 'Mr';
                                } elseif ($lead->lead_gender == 2) {
                                  $genderPrefix = 'Ms';
                                }
                            
                            
                           
                            
                            $content = $emailTemplate->email_subject;
                    
                            $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                    
                            $content = str_replace('#customer_name',$lead_name, $content);
                            $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
                            $content = str_replace('#payment_date', $transaction_date ?? date('d-M-Y'), $content);
                            $content = str_replace('#link', $shortsendUrl_receipt, $content);
                            $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                            $content = str_replace('#payment', $slotAmount ?? '', $content);
                            $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                            $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                            $branchNo = $branch->mobile;
                            $branchemail = $branch->mail;
                            $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                            $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                            $url= 'phdizone.com';
                    
                            $mailData = [
                                  'url'         => $url,
                                  'subject'     => $dynamicSubject,
                                  'content'     => $content,
                                  'branchNo'    => $branchNo,
                                  'branchemail' => $branchemail, // Use the message content from the request
                                  'fbLink'      => $fbLink,      // Use the message content from the request
                                  'instaLink'   => $instaLink,   // Use the message content from the request
                                  'salesMobile' => $cre_mobile ?? '8220011465',
                              ];
                    
                            $to_address = $lead_email_id;
                            $from_address = 'elysiumtechnology@elysium.community';
                            $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                    
                    
                            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                         }
                      }
                    //   return "email success";
                      //   Whatsapp Receipt
                      if($communicationStatusReceipt->whatsapp ==0){
                          
                        //   if ($lead_mobile) {
                              
                               
                        //             // $templateName  = "hello_world";
                        //             $templateNameReceipt  = "payment_recept_phdizone";
                    
                        //             $hasHeader  = false; // Example flag: set based on template
                        //             $hasBody    = false; // Example flag: set based on template
                        //             $hasFooter  = false; // Example flag: set based on template
                        //             $hasButton  = false;
                        //             $components = [];
                        //             $couponCode = " ";
                        //             date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        //             $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                        //                                                       // $currentHour = date('H'); // Get current hour in 24-hour format
                        //             if ($currentHour >= 5 && $currentHour < 12) {
                        //                 $greeting = 'Good Morning';
                        //             } elseif ($currentHour >= 12 && $currentHour < 18) {
                        //                 $greeting = 'Good Afternoon';
                        //             } else {
                        //                 $greeting = 'Good Evening';
                        //             }
                    
                        //             if ($templateNameReceipt == 'payment_recept_phdizone') {
                        //                 $headerImage = url('public/assets/phdizone_images/Payment.jpg');
                        //                 $couponCode  = 'NOOFFER';
                        //                 $buttonIndex = 1;
                        //                 $bodyText    = [
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           => $lead_name ?? '',
                        //                         'parameter_name' => 'customer_name',
                        //                     ],
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           => $paymentData->payment_id ?? '',
                        //                         'parameter_name' => 'recept_number',
                        //                     ],
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           =>  $transaction_date ?? date('d-M-Y'),
                        //                         'parameter_name' => 'payment_date',
                        //                     ],
                        //                      [
                        //                         'type'           => 'text',
                        //                         'text'           => $slotAmount ?? '',
                        //                         'parameter_name' => 'payment',
                        //                     ],
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           => $proposal->service_title ?? '',
                        //                         'parameter_name' => 'service_name',
                        //                     ],
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           => $slot_url_key_receipt,
                        //                         'parameter_name' => 'link_key',
                        //                     ],
                        //                     [
                        //                         'type'           => 'text',
                        //                         'text'           => $cre_mobile ?? '8220011465',
                        //                         'parameter_name' => 'cre_number',
                        //                     ],
                        //                 ];
                        //                 $hasHeader = true;
                        //                 $hasBody   = true;
                        //                 $hasButton = true;
                        //             }
                    
                        //             // Add Header if required
                        //             if ($hasHeader) {
                        //                 $components[] = [
                        //                     'type'       => 'header',
                        //                     'parameters' => [
                        //                         [
                        //                             'type'  => 'image',
                        //                             'image' => [
                        //                                 'link' => $headerImage, // Dynamically set header image
                        //                             ],
                        //                         ],
                        //                     ],
                        //                 ];
                        //             }
                    
                        //             // Add Body if required
                        //             if ($hasBody) {
                        //                 $components[] = [
                        //                     'type'       => 'body',
                        //                     'parameters' => $bodyText,
                        //                 ];
                        //             }
                    
                        //             // Add Footer if required
                        //             if ($hasButton) {
                        //                 $components[] = [
                        //                     'type'       => 'button',
                        //                     'sub_type'   => 'url',
                        //                     'index'      => 0,
                        //                     'parameters' => [
                        //                         [
                        //                             'type' => 'text',
                        //                             'text' => $slot_url_key_receipt,
                        //                         ],
                        //                     ],
                        //                 ];
                        //             }
                                    
                                    
                        //             $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                        //             $dynamicParameters         = $templateParameters[$templateNameReceipt] ?? [];
                        //             $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                        //             $accessToken               = $whatsappApi->access_tokken ?? '';
                        //             $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                    
                        //             $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                    
                        //             $countryCode  = $lead_call_code;
                        //             $to           = $lead_mobile;
                        //             $languageCode = 'en';
                        
                        //             if (strpos($to, $countryCode) !== 0) {
                        //                 $to = $countryCode . $to;
                        //             }
                    
                        //             $message = 'test~message';
                        //             if (empty($components)) {
                        //                 $payload = [
                        //                     'messaging_product' => 'whatsapp',
                        //                     'to'                => $to,
                        //                     'type'              => 'template',
                        //                     'template'          => [
                        //                         'name'     => $templateNameReceipt,
                        //                         'language' => [
                        //                             'code' => $languageCode,
                        //                         ],
                        //                     ],
                        //                 ];
                        //             } else {
                        //                 $payload = [
                        //                     'messaging_product' => 'whatsapp',
                        //                     'to'                => $to,
                        //                     'type'              => 'template',
                        //                     'template'          => [
                        //                         'name'       => $templateNameReceipt,
                        //                         'language'   => [
                        //                             'code' => $languageCode,
                        //                         ],
                        //                         'components' => $components,
                        //                     ],
                        //                 ];
                        //             }
                    
                        //             $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                        //          if ($response['status'] == 200) {}
                        //          else{
                        //              return response([
                        //                   'status' => 404,
                        //                   'message' => 'Failed to send message in receipt',
                        //                   'error_msg' => $response,
                        //                 ], 400);
                        //             }
                                
                        //   }
                          
                      }
                    //   return "whatsapp success";
                      DB::table('et_proposal_pay_slot')
                            ->where('sno', $slots->sno)
                            ->update(['receipt_send_status' => 1]);
                     
                 }
                 
                 //  customer & Nda communication
                 if($customer->status == 1){
                        // return "nda before";
                    // Nda signed Communication
                    if($proposal->nda_signed !=1){
                        if($communicationStatusNDA && $communicationStatusNDA->status == 0){
                             $nda_check = DB::table('et_manage_nda')->where('proposal_id', $proposal_id)->first();
                             if (!$nda_check) {
                                $year = date('Y');
                                $month = date('m');
                                
                                // Get the last NDA record
                                $category_check_nda = DB::table('et_manage_nda')->orderBy('sno', 'desc')->first();
                                
                                
                                if (!$category_check_nda) {
                                    $next_number = 1;
                                } else {
                                    $last_nda_id = $category_check_nda->nda_id;
                                
                                    $parts = explode('/', $last_nda_id);
                                    $last_number = isset($parts[4]) ? (int) $parts[4] : 0;
                                    $next_number = $last_number + 1;
                                }
                            
                                $nda_id = sprintf("EGC/IZONE/%s/%s/%05d", $year, $month, $next_number);
                              $helper = new \App\Helpers\Helpers();
                              $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');
                              $Link =url('manage_nda/nda_message/' . $encrypted_values);
                              
                              if(!$proposal->nda_temp_link){
                                    $channelId = 6;
                                     $shortUrlData = $this->shortenUrl($Link,$channelId);
                                     $shortUrl = $shortUrlData['shorturl'];
                                     $urlId =$shortUrlData['id'];
                                     if($shortUrl){
                                         DB::table('et_proposal')
                                            ->where('sno', $proposal_id)
                                            ->update(['nda_temp_link' => $shortUrl]);
                                            
                                              DB::table('et_chotta_links')->insert([
                                                  'branch_id' => $proposal->branch_id,
                                                  'chotta_link_id' => $urlId,
                                                  'chotta_short_link' => $shortUrl,
                                                  'large_encrypt_link' => $Link,
                                                  'link_type' => 'NDA Send',
                                                  'proposal_id' =>$proposal_id,
                                                  'created_by' => $proposal->created_by,
                                                  'updated_by' => $proposal->created_by,
                                              ]);
                                     }
                                }
                              $slotUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
                              $shortsendUrl = $slotUrl->nda_temp_link ;
                              $slot_url_key = basename($shortsendUrl);
                              
                                DB::table('et_manage_nda')->insert([
                                                  'nda_id' =>$nda_id,
                                                  'nda_link' =>$shortsendUrl ,
                                                  'nda_date' => date('Y-m-d'),
                                                  'customer_id' => $customer ? $customer->sno : 0,
                                                  'proposal_id' => $proposal_id,
                                                  'branch_id' => $proposal->branch_id ?? '0',
                                                  'status' => 0,
                                                  'created_by' => $proposal->created_by,
                                                  'updated_by' => $proposal->created_by,
                                              ]);
                                
                              // NDA SMS
                                  if($communicationStatusNDA->sms ==0){
                                      
                                  }
                                // return " nda sms success";
                              // NDA Email
                              if($communicationStatusNDA->email ==0){
                                  if ($lead_email_id) {
                                     
                                        $emailTemplate_id =5; // proposal send Template Id
                                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                            
                                        // Gender condition
                                        $genderPrefix = 'Mr/Ms'; // Default value
                                        if ($lead->lead_gender == 1) {
                                          $genderPrefix = 'Mr';
                                        } elseif ($lead->lead_gender == 2) {
                                          $genderPrefix = 'Ms';
                                        }
                                    
                                    
                                   
                                    
                                    $content = $emailTemplate->email_subject;
                            
                                    $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                            
                                    $content = str_replace('#customer_name', $lead_name, $content);
                                    $content = str_replace('#nda_number', $nda_id ?? 'EGC/IZONE/2025/06/00001', $content);
                                    $content = str_replace('#nda_date', date('d-M-Y'), $content);
                                    $content = str_replace('#link', $shortsendUrl, $content);
                                    $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                                    $content = str_replace('#invoice_amount', $slotAmount ?? '', $content);
                                    $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                                    $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
                                    $branchNo = $branch->mobile;
                                    $branchemail = $branch->mail;
                                    $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                                    $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                                    $url= 'phdizone.com';
                            
                                    $mailData = [
                                          'url'         => $url,
                                          'subject'     => $dynamicSubject,
                                          'content'     => $content,
                                          'branchNo'    => $branchNo,
                                          'branchemail' => $branchemail, // Use the message content from the request
                                          'fbLink'      => $fbLink,      // Use the message content from the request
                                          'instaLink'   => $instaLink,   // Use the message content from the request
                                          'salesMobile' => $cre_mobile ?? '8220011465',
                                      ];
                            
                                    $to_address = $lead_email_id;
                                    $from_address = 'elysiumtechnology@elysium.community';
                                    $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                            
                            
                                    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                                    
                                    
                                 }
                              }
                              
                            //   return "nda email success";
                               
                              // NDA Whatsapp
                              if($communicationStatusNDA->whatsapp ==0){
                                  if ($lead_mobile) {
                                      
                                       
                                            // $templateName  = "hello_world";
                                            $templateName  = "nda_phdizone";
                            
                                            $hasHeader  = false; // Example flag: set based on template
                                            $hasBody    = false; // Example flag: set based on template
                                            $hasFooter  = false; // Example flag: set based on template
                                            $hasButton  = false;
                                            $components = [];
                                            $couponCode = " ";
                                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                                            if ($currentHour >= 5 && $currentHour < 12) {
                                                $greeting = 'Good Morning';
                                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                                $greeting = 'Good Afternoon';
                                            } else {
                                                $greeting = 'Good Evening';
                                            }
                            
                                            if ($templateName == 'nda_phdizone') {
                                                $headerImage = url('public/assets/phdizone_images/nda_signed.jpg');
                                                $couponCode  = 'NOOFFER';
                                                $buttonIndex = 1;
                                                $bodyText    = [
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $lead_name ?? '',
                                                        'parameter_name' => 'customer_name',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $nda_id ?? 'EGC/IZONE/2025/06/00001',
                                                        'parameter_name' => 'nda_number',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => date('d-M-Y'),
                                                        'parameter_name' => 'nda_date',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $proposal->service_title ?? '',
                                                        'parameter_name' => 'service_name',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $slot_url_key,
                                                        'parameter_name' => 'link_key',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $cre_mobile ?? '8220011465',
                                                        'parameter_name' => 'customer_care',
                                                    ],
                                                ];
                                                $hasHeader = true;
                                                $hasBody   = true;
                                                $hasButton = true;
                                            }
                            
                                            // Add Header if required
                                            if ($hasHeader) {
                                                $components[] = [
                                                    'type'       => 'header',
                                                    'parameters' => [
                                                        [
                                                            'type'  => 'image',
                                                            'image' => [
                                                                'link' => $headerImage, // Dynamically set header image
                                                            ],
                                                        ],
                                                    ],
                                                ];
                                            }
                            
                                            // Add Body if required
                                            if ($hasBody) {
                                                $components[] = [
                                                    'type'       => 'body',
                                                    'parameters' => $bodyText,
                                                ];
                                            }
                            
                                            // Add Footer if required
                                            if ($hasButton) {
                                                $components[] = [
                                                    'type'       => 'button',
                                                    'sub_type'   => 'url',
                                                    'index'      => 0,
                                                    'parameters' => [
                                                        [
                                                            'type' => 'text',
                                                            'text' => $slot_url_key,
                                                        ],
                                                    ],
                                                ];
                                            }
                                            
                                            
                                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                            $accessToken               = $whatsappApi->access_tokken ?? '';
                                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                            
                                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                            
                                            $countryCode  = $lead_call_code;
                                            $to           = $lead_mobile;
                                            $languageCode = 'en';
                                
                                            if (strpos($to, $countryCode) !== 0) {
                                                $to = $countryCode . $to;
                                            }
                            
                                            $message = 'test~message';
                                            if (empty($components)) {
                                                $payload = [
                                                    'messaging_product' => 'whatsapp',
                                                    'to'                => $to,
                                                    'type'              => 'template',
                                                    'template'          => [
                                                        'name'     => $templateName,
                                                        'language' => [
                                                            'code' => $languageCode,
                                                        ],
                                                    ],
                                                ];
                                            } else {
                                                $payload = [
                                                    'messaging_product' => 'whatsapp',
                                                    'to'                => $to,
                                                    'type'              => 'template',
                                                    'template'          => [
                                                        'name'       => $templateName,
                                                        'language'   => [
                                                            'code' => $languageCode,
                                                        ],
                                                        'components' => $components,
                                                    ],
                                                ];
                                            }
                            
                                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                         if ($response['status'] == 200) {}
                                         else{
                                             return response([
                                                  'status' => 404,
                                                  'message' => 'Failed to send message in nda',
                                                  'error_msg' => $response,
                                                ], 400);
                                            }
                                        
                                  }
                              }
                              
                            //   return "nda whatsapp success";
                             }
                          
                         
                        }
                    }
                    
                    // Customer Communication
                    if($communicationStatusCustomer && $communicationStatusCustomer->status == 0){
                          $creData=StaffModel::where('sno', $proposal->cre_id)->first();
                          
                          // SMS customer welcome
                          if($communicationStatusCustomer->sms ==0){
                               if ($lead_mobile) {
                
                                  $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '3_Phdizone_Customer_Welcome_Message')->first();
                                  $authkey = $result_sms ? $result_sms->authkey : '';
                                  $sender_id = $result_sms ? $result_sms->sender_id : '';
                                  $template_id = $result_sms ? $result_sms->template_id : '';
                                  $country_code = $result_sms ? $result_sms->country_code : '';
                                  $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                                  $mobile_number = $country_code . $lead_mobile;
                        
                                 
                               
                        
                                  // Replace placeholders with actual values
                                  $replacement_values = [$lead_name,$customer->customer_id,$cre_mobile];
                                  $message_content = preg_replace_callback(
                                    '/\{#var#\}/',
                                    function () use (&$replacement_values) {
                                      return array_shift($replacement_values);
                                    },
                                    $message_content
                                  );
                        
                                  $route = "default";
                                  $postData = array(
                                    'authkey' => $authkey,
                                    'mobiles' => $mobile_number,
                                    'message' => $message_content,
                                    'sender' => $sender_id,
                                    'route' => $route,
                                  );
                        
                                  // API URL
                                  $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                        
                                  // Initialize the resource
                                  $ch = curl_init();
                                  curl_setopt_array($ch, array(
                                    CURLOPT_URL => $url,
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_POST => true,
                                    CURLOPT_POSTFIELDS => $postData,
                                    CURLOPT_SSL_VERIFYHOST => 0,
                                    CURLOPT_SSL_VERIFYPEER => 0,
                                  ));
                        
                                  // Get response
                                  $response = curl_exec($ch);
                                  // return $response;
                                  $err = curl_error($ch);
                                  curl_close($ch);
                                }
                          }
                        //   return " cus sms success";
                          // Email customer welcome
                          if($communicationStatusCustomer->email ==0){
                               if ($lead_email_id) {
                                        $emailTemplate_id =6; // proposal send Template Id
                                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                            
                                        // Gender condition
                                        $genderPrefix = 'Mr/Ms'; // Default value
                                        if ($lead->lead_gender == 1) {
                                          $genderPrefix = 'Mr';
                                        } elseif ($lead->lead_gender == 2) {
                                          $genderPrefix = 'Ms';
                                        }
                                    
                                    
                                   
                                    
                                    $content = $emailTemplate->email_subject;
                            
                                    $dynamicSubject = str_replace('#customer_name', $lead_name ??  '', $emailTemplate->email_name);
                            
                                    $content = str_replace('#customer_name', $lead_name ??  '', $content);
                                    $content = str_replace('#customer_id', $customer ? $customer->customer_id :  '', $content);
                                    $content = str_replace('#cre_name', $creData ? $creData->nick_name :  'Staff', $content);
                                    $content = str_replace('#customercare_no',  $cre_mobile ?? '8220011465', $content);
                                    $branchNo = $branch->mobile;
                                    $branchemail = $branch->mail;
                                    $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone';
                                    $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                                    $url= 'phdizone.com';
                            
                                    $mailData = [
                                          'url'         => $url,
                                          'subject'     => $dynamicSubject,
                                          'content'     => $content,
                                          'branchNo'    => $branchNo,
                                          'branchemail' => $branchemail, // Use the message content from the request
                                          'fbLink'      => $fbLink,      // Use the message content from the request
                                          'instaLink'   => $instaLink,   // Use the message content from the request
                                          'salesMobile' => $cre_mobile ?? '8220011465',
                                      ];
                            
                                    $to_address = $lead_email_id;
                                    $from_address = 'elysiumtechnology@elysium.community';
                                    $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                            
                            
                                    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                                 }
                          }
                            // return " cus email success";
                          // Whatsapp customer welcome
                          if($communicationStatusCustomer->whatsapp ==0){
                              if ($lead_mobile) {
                                      
                                       
                                            // $templateName  = "hello_world";
                                            $templateName  = "customer_welcome";
                            
                                            $hasHeader  = false; // Example flag: set based on template
                                            $hasBody    = false; // Example flag: set based on template
                                            $hasFooter  = false; // Example flag: set based on template
                                            $hasButton  = false;
                                            $components = [];
                                            $couponCode = " ";
                                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                                            if ($currentHour >= 5 && $currentHour < 12) {
                                                $greeting = 'Good Morning';
                                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                                $greeting = 'Good Afternoon';
                                            } else {
                                                $greeting = 'Good Evening';
                                            }
                            
                                            if ($templateName == 'customer_welcome') {
                                                $headerImage = url('public/assets/phdizone_images/Welcome.jpg');
                                                $couponCode  = 'NOOFFER';
                                                $buttonIndex = 1;
                                                $bodyText    = [
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $lead_name ?? '',
                                                        'parameter_name' => 'customer_name',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $customer ? $customer->customer_id :  '',
                                                        'parameter_name' => 'customer_id',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $creData ? $creData->nick_name :  'Staff',
                                                        'parameter_name' => 'cre_name',
                                                    ],
                                                    [
                                                        'type'           => 'text',
                                                        'text'           => $cre_mobile ?? '8220011465',
                                                        'parameter_name' => 'custonercare_no',
                                                    ],
                                                ];
                                                $hasHeader = true;
                                                $hasBody   = true;
                                            }
                            
                                            // Add Header if required
                                            if ($hasHeader) {
                                                $components[] = [
                                                    'type'       => 'header',
                                                    'parameters' => [
                                                        [
                                                            'type'  => 'image',
                                                            'image' => [
                                                                'link' => $headerImage, // Dynamically set header image
                                                            ],
                                                        ],
                                                    ],
                                                ];
                                            }
                            
                                            // Add Body if required
                                            if ($hasBody) {
                                                $components[] = [
                                                    'type'       => 'body',
                                                    'parameters' => $bodyText,
                                                ];
                                            }
                            
                                            // Add Footer if required
                                            if ($hasButton) {
                                                $components[] = [
                                                    'type'       => 'button',
                                                    'sub_type'   => 'url',
                                                    'index'      => 0,
                                                    'parameters' => [
                                                        [
                                                            'type' => 'text',
                                                            'text' => '',
                                                        ],
                                                    ],
                                                ];
                                            }
                                            
                                            
                                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                            $accessToken               = $whatsappApi->access_tokken ?? '';
                                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                            
                                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                            
                                            $countryCode  = $lead_call_code;
                                            $to           = $lead_mobile;
                                            $languageCode = 'en';
                                
                                            if (strpos($to, $countryCode) !== 0) {
                                                $to = $countryCode . $to;
                                            }
                            
                                            $message = 'test~message';
                                            if (empty($components)) {
                                                $payload = [
                                                    'messaging_product' => 'whatsapp',
                                                    'to'                => $to,
                                                    'type'              => 'template',
                                                    'template'          => [
                                                        'name'     => $templateName,
                                                        'language' => [
                                                            'code' => $languageCode,
                                                        ],
                                                    ],
                                                ];
                                            } else {
                                                $payload = [
                                                    'messaging_product' => 'whatsapp',
                                                    'to'                => $to,
                                                    'type'              => 'template',
                                                    'template'          => [
                                                        'name'       => $templateName,
                                                        'language'   => [
                                                            'code' => $languageCode,
                                                        ],
                                                        'components' => $components,
                                                    ],
                                                ];
                                            }
                            
                                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                         if ($response['status'] == 200) {}
                                         else{
                                             return response([
                                                  'status' => 404,
                                                  'message' => 'Failed to send message in customer',
                                                  'error_msg' => $response,
                                                ], 400);
                                            }
                                        
                                  }
                          }
                        //   return " cus whatsapp success";
                     }
                    
                 
                 }
                 
            

            }
         }else{
             if($customer->status == 1){
                 // Nda signed Communication
                    if($proposal->nda_signed !=1){
                     $nda_check = DB::table('et_manage_nda')->where('proposal_id', $proposal_id)->first();
                      if (!$nda_check) {
                            $year = date('Y');
                            $month = date('m');
                            
                            // Get the last NDA record
                            $category_check_nda = DB::table('et_manage_nda')->orderBy('sno', 'desc')->first();
                            
                            
                            if (!$category_check_nda) {
                                $next_number = 1;
                            } else {
                                $last_nda_id = $category_check_nda->nda_id;
                            
                                $parts = explode('/', $last_nda_id);
                                $last_number = isset($parts[4]) ? (int) $parts[4] : 0;
                                $next_number = $last_number + 1;
                            }
                            
                            $nda_id = sprintf("EGC/IZONE/%s/%s/%05d", $year, $month, $next_number);
                             
                     $helper = new \App\Helpers\Helpers();
                      $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');
                      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                      $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slot_id)->first();
                       
                      $Link =url('manage_nda/nda_message/' . $encrypted_values);
                 
                          
                          DB::table('et_manage_nda')->insert([
                                              'nda_id' =>$nda_id,
                                              'nda_link' =>  $Link,
                                              'nda_date' => date('Y-m-d'),
                                              'customer_id' => $customer ? $customer->sno : 0,
                                              'proposal_id' => $proposal_id,
                                              'branch_id' => $proposal->branch_id ?? '0',
                                              'status' => 0,
                                              'created_by' => $proposal->created_by,
                                              'updated_by' => $proposal->created_by,
                                          ]);
                              //   For Old Customer
                             DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update([
                                    'nda_temp_link' => $Link,
                                    'nda_old_customer_check'=>1,
                                    ]);
                    
                      }
                    }
             }
         }
         
         
         
     }
      //  return "nda stop";

        if ($OldCustomerModel) {
          if($sts ==1){
               DB::table('et_customer')
                ->where('sno', $customer_id)
                ->update(['status' => 0]);
                
          }
          
          
          $OldCustomerModel->payment_status = $sts;
          $OldCustomerModel->update(); 
         
     
          DB::table('et_proposal_pay_slot')
            ->where('sno', $slot_id)
            ->update(['initialPayDate' => $transaction_date_edit]);
            
         
                DB::table('et_payment')
                   ->where('sno', $payment_id)
                    ->update(['transaction_date' => $transaction_date_edit]);
            if($Payment->payment_mode == 2){
                    if ($request->hasFile('payment_proof')) {
                        $file = $request->file('payment_proof');
                        $slot_id = $slot_id;
                        $extension = $file->getClientOriginalExtension();
        
                        $folder = public_path('payment_documents');
                        $baseName = "payment_doc_{$slot_id}_";
        
                        // Get all files matching this slot_id pattern
                        $existingFiles = glob($folder . "/{$baseName}*.$extension");
        
                        // Count existing uploads to determine next index
                        $nextIndex = count($existingFiles) + 1;
        
                        // Build new filename
                        $filename = "{$baseName}{$nextIndex}." . $extension;
                        $file->move($folder, $filename);
                    } else {
                        $filename = null;
                    }
                
                 DB::table('et_payment')
                    ->where('sno', $payment_id)
                    ->update(['offline_description' => $offline_description,
                                'payment_doc'      => $filename,
                                'offline_transaction_id'      => $offline_transaction_id,
                            ]);
            }
                        
          
        
        
          
          
          // return $OldCustomerModel;
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Successfully Status Updated!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update Status!'
          ]);
        }
    return redirect('/manage_history');
  }


// Payment Function 
  public function showPaymentForm()
    {
        return view('payment');
    }

//  Create Order For First Proposal Payment
  public function createOrder(Request $request)
    {
        $amount = $request->slot_amount;
        $slot_id = $request->slot_id;
        $prps_id = $request->proposal_id;
        $pay_mode = $request->pay_mode;
         $transaction_id = $request->transaction_id;
        
     



          $slot = DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id)
                ->where('status', 0)
                ->first();

            $proposal = DB::table('et_proposal')
                        ->where('sno', $prps_id)
                        ->first();

            $leadData = DB::table('et_lead')
                            ->where('sno', $proposal->lead_id)
                        ->first();
            $lead_status =$leadData->status ?? '0';

        if (!$slot || $slot->link_status == 1) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Payment link has expired or is already used.',
                    'error_msg' => 'Link expired',
                    'data' => null,
                    'id' => null,
                    'pay_mode' => $pay_mode
                ]);
        }

        if ($pay_mode == 'Online') {
            // Continue to encrypt for online payment

             $encrypt_id = $prps_id . '~' . $slot_id . '~' . $amount;
            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($encrypt_id, 'encrypt');

            return response()->json([
                'status' => 200,
                'message' => 'Payment Redirect',
                'error_msg' => null,
                'data' => $encrypted_values,
                'id' => $encrypted_values,
                'pay_mode' => $pay_mode
            ]);
        }else{
            DB::beginTransaction();
            
            if ($request->hasFile('payment_proof')) {
                $file = $request->file('payment_proof');
                $slot_id = $request->slot_id;
                $extension = $file->getClientOriginalExtension();

                $folder = public_path('payment_documents');
                $baseName = "payment_doc_{$slot_id}_";

                // Get all files matching this slot_id pattern
                $existingFiles = glob($folder . "/{$baseName}*.$extension");

                // Count existing uploads to determine next index
                $nextIndex = count($existingFiles) + 1;

                // Build new filename
                $filename = "{$baseName}{$nextIndex}." . $extension;
                $file->move($folder, $filename);
            } else {
                $filename = null;
            }
            
            // Generate IDs helper function
            $generateId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)->orderBy('sno', 'desc')->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };
            
            $generateTransId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)->where('customer_type',0)->orderBy('sno', 'desc')->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };

            
            $invoice_id = $slot->invoice_id;
            $payment_id = $generateId('PAY', 'et_payment', 'payment_id', 6);
            
             $currencyData = DB::table('et_country_currencies')
                        ->where('sno', $proposal->currency_id)
                        ->first();

          // Insert payment
            $save_transaction = DB::table('et_payment')->insert([
                'payment_id'     => $payment_id,
                'invoice_id'     => $invoice_id,
                'branch_id'      => $slot->branch_id ?? 0,
                'payment_mode'   => 2,
                'proposal_id'    => $prps_id ?? 0,
                'pay_slot_id'    => $slot_id ?? 0,
                'paid_amount'    => $amount ,
                'transaction_date' => date('Y-m-d'),
                'payment_method' => 'Offline',
                'currency'       => $currencyData->currency_code,
                'offline_transaction_id' => $transaction_id,
                'payment_doc'      => $filename,
            ]);

            if (!$save_transaction) {
                DB::rollBack();
                return response()->json(['status' => 'failed', 'message' => 'Failed to save payment'], 500);
            }

            

            if ($leadData) {
                if($lead_status !=4){
                    $customer_id = $generateId('CUS', 'et_customer', 'customer_id', 5);
    
                    // Use updateOrCreate with unique identifier (like lead_id)
                    $customer = CustomerModel::updateOrCreate(
                        ['lead_id' => $leadData->sno],
                        [
                            'cus_name' => $leadData->lead_name,
                            'customer_id' => $customer_id,
                            'branch_id' => $leadData->branch_id ?? null,
                            'cus_gender' => $leadData->lead_gender ?? null,
                            'cus_dob' => $leadData->lead_dob ?? null,
                            'cus_mobile' => $leadData->lead_mobile ?? null,
                            'country_code' => $leadData->inter_calls ?? 0,
                            'cus_alternate_mobile' => $leadData->lead_alternate_mobile ?? null,
                            'cus_email_id' => $leadData->lead_email_id ?? null,
                            'door_no' => $leadData->door_no ?? null,
                            'pincode' => $leadData->pincode ?? null,
                            'country' => $leadData->country ?? null,
                            'state' => $leadData->state ?? null,
                            'city' => $leadData->city ?? null,
                            'address' => $leadData->address ?? null,
                            'proposal_ids' => json_encode([$prps_id]),
                            'created_by' => 0,
                            'updated_by' => 0,
                            'status' => 1,
                        ]
                    );
    
                     $lead_update = DB::table('et_lead')
                    ->where('sno', $leadData->sno)
                    ->update([
                        'status' => 4,
                        'lead_status_id' => 5,
                    ]);
                    
    
                    if ($customer) {
    
                       if ($proposal->product_package == 2) {
                            // Insert a single service record for product_package 2
                            $save_services = DB::table('et_customer_services')->insert([
                                'branch_id'        => $customer->branch_id,
                                'lead_id'          => $customer->lead_id,
                                'customer_id'      => $customer->sno ?? 0,
                                'proposal_id'      => $proposal->sno ?? 0,
                                 'cre_id'      => $proposal->cre_id ?? 0,
                                'product_package'  => $proposal->product_package ?? 0,
                                'package_id'       => $proposal->package_id ?? 0,
                            ]);
                        } else {
                            // Get the product cart data for other product_package values
                            $product_cart_data = DB::table('et_proposal_product_cart')
                                ->where('status', 0)
                                ->where('proposal_sno', $proposal->sno)
                                ->pluck('product_id');
    
                            foreach ($product_cart_data as $cart) {
                                $save_services = DB::table('et_customer_services')->insert([
                                    'branch_id'        => $customer->branch_id,
                                    'lead_id'          => $customer->lead_id,
                                    'customer_id'      => $customer->sno ?? 0,
                                    'proposal_id'      => $proposal->sno ?? 0,
                                     'cre_id'      => $proposal->cre_id ?? 0,
                                    'product_package'  => $proposal->product_package ?? 0,
                                    'product_id'       => $cart ?? 0,
                                ]);
                            }
                        }
    
                    }
                
                }else{
                    $customer=DB::table('et_customer')->where('status', '!=', 2)->where('lead_id', $leadData->sno)->first();
                }

                $paymentData = DB::table('et_payment')->where('status', '!=', 2)->where('invoice_id', $invoice_id)->first();

                $subledger_id = $generateId('SUB', 'et_subledger', 'subledger_id', 5);

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $invoice_id;
                $add_subledger->subledger_desc = 'Proposal Payment';
                $add_subledger->branch_id = $customer->branch_id;
                $add_subledger->payment_sno = $paymentData->sno ?? null;
                $add_subledger->created_by = 0;
                $add_subledger->updated_by = 0;
                $add_subledger->save();

                $transaction_id = $generateTransId('TRANS', 'et_transaction', 'transaction_id', 5);
                
                $add_transaction = new TransactionModel();
                $add_transaction->transaction_id = $transaction_id;
                $add_transaction->branch_id = $customer->branch_id;
                $add_transaction->transaction_type = 'Credit';
                $add_transaction->transaction_name = 'Customer';
                $add_transaction->customer_id = $customer->sno;
                $add_transaction->ledger_id = 1;
                $add_transaction->subledger_id = $add_subledger->sno;
                $add_transaction->invoice_id = $invoice_id;
                $add_transaction->receipt_id = null;
                $add_transaction->payment_id = $paymentData->sno ?? null;
                $add_transaction->created_by = 0;
                $add_transaction->updated_by = 0;
                $add_transaction->save();

               
            }
            
            // Update slot status
            $slot_update = DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id)
                ->where('status', 0)
                ->update([
                    'invoice_id' => $invoice_id,
                    'link_status' => 1,
                    'paid_status' => 1,
                    'initialPayDate' => date('Y-m-d'),
                    'paidAmount' => $slot->payable_amount, 
                ]);
            if($lead_status !=4){
                $proposal_update = DB::table('et_proposal')
                    ->where('sno', $prps_id)
                    ->update([
                        'proposal_status' => 3,
                    ]);
            }

            if (!$slot_update) {
                DB::rollBack();
                return response()->json(['status' => 'failed', 'message' => 'Failed to update slot'], 500);
            }
             $cus_Proposal_update = DB::table('et_proposal')
                ->where('sno', $prps_id)
                ->where('status', 0)
                ->update([
                    'customer_id' =>$customer->sno,
                ]);
                
                $cus_pay = DB::table('et_payment')
                ->where('sno', $paymentData->sno)
                ->update([
                    'customer_id' =>$customer->sno,
                ]);

            DB::commit();
            
            //  // Nda signed Communication
            // if($proposal->nda_signed !=1){
            //  $nda_check = DB::table('et_manage_nda')->where('proposal_id', $proposal_id)->first();
            //   if (!$nda_check) {
            //         $year = date('Y');
            //         $month = date('m');
                    
            //         // Get the last NDA record
            //         $category_check_nda = DB::table('et_manage_nda')->orderBy('sno', 'desc')->first();
                    
                    
            //         if (!$category_check_nda) {
            //             $next_number = 1;
            //         } else {
            //             $last_nda_id = $category_check_nda->nda_id;
                    
            //             $parts = explode('/', $last_nda_id);
            //             $last_number = isset($parts[4]) ? (int) $parts[4] : 0;
            //             $next_number = $last_number + 1;
            //         }
                    
            //         $nda_id = sprintf("GC/IZONE/%s/%s/%05d", $year, $month, $next_number);
                     
            //  $helper = new \App\Helpers\Helpers();
            //   $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');
            //   $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
            //   $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
               
            //   $Link ='https://erp.elysiumtechnologies.com/manage_nda/nda_message/'.$encrypted_values;
            //   if($proposal->old_customer_check == 1){
                  
            //       DB::table('et_manage_nda')->insert([
            //                           'nda_id' =>$nda_id,
            //                           'nda_link' =>  $Link,
            //                           'nda_date' => date('Y-m-d'),
            //                           'customer_id' => $customer ? $customer->sno : 0,
            //                           'proposal_id' => $proposal_id,
            //                           'branch_id' => $proposal->branch_id ?? '0',
            //                           'status' => 0,
            //                           'created_by' => $proposal->created_by,
            //                           'updated_by' => $proposal->created_by,
            //                       ]);
            //       //   For Old Customer
            //      DB::table('et_proposal')
            //         ->where('sno', $proposal_id)
            //         ->update([
            //             'nda_temp_link' => $Link,
            //             'nda_old_customer_check'=>1,
            //             ]);
            //   }else{
            //         if(!$proposal->nda_temp_link){
            //             $channelId = 6;
            //              $shortUrlData = $this->shortenUrl($Link,$channelId);
            //              $shortUrl = $shortUrlData['shorturl'];
            //              $urlId =$shortUrlData['id'];
            //              if($shortUrl){
            //                  DB::table('et_proposal')
            //                     ->where('sno', $proposal_id)
            //                     ->update(['nda_temp_link' => $shortUrl]);
                                
            //                       DB::table('et_chotta_links')->insert([
            //                           'branch_id' => $proposal->branch_id,
            //                           'chotta_link_id' => $urlId,
            //                           'chotta_short_link' => $shortUrl,
            //                           'large_encrypt_link' => $Link,
            //                           'link_type' => 'NDA Send',
            //                           'proposal_id' =>$proposal_id,
            //                           'created_by' => $proposal->created_by,
            //                           'updated_by' => $proposal->created_by,
            //                       ]);
            //              }
            //         }
            //              $slotUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
            //               $shortsendUrl = $slotUrl->nda_temp_link ;
            //               $slot_url_key = basename($shortsendUrl);
                          
            //               DB::table('et_manage_nda')->insert([
            //                           'nda_id' =>$nda_id,
            //                           'nda_link' =>$shortsendUrl ,
            //                           'nda_date' => date('Y-m-d'),
            //                           'customer_id' => $customer ? $customer->sno : 0,
            //                           'proposal_id' => $proposal_id,
            //                           'branch_id' => $proposal->branch_id ?? '0',
            //                           'status' => 0,
            //                           'created_by' => $proposal->created_by,
            //                           'updated_by' => $proposal->created_by,
            //                       ]);
                          
            //              $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
            //              $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                        
            //               if ($lead->lead_email_id) {
            //                 $emailTemplate_id =5; // proposal send Template Id
            //                 $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
            //                 // Gender condition
            //                 $genderPrefix = 'Mr/Ms'; // Default value
            //                 if ($lead->lead_gender == 1) {
            //                   $genderPrefix = 'Mr';
            //                 } elseif ($lead->lead_gender == 2) {
            //                   $genderPrefix = 'Ms';
            //                 }
                        
                        
                       
                        
            //             $content = $emailTemplate->email_subject;
                
            //             $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
            //             $content = str_replace('#customer_name', $lead->lead_name, $content);
            //             $content = str_replace('#nda_number', $nda_id ?? 'GC/IZONE/2025/06/00001', $content);
            //             $content = str_replace('#nda_date', date('d-M-Y'), $content);
            //             $content = str_replace('#link', $shortsendUrl, $content);
            //             $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
            //             $content = str_replace('#invoice_amount', $slotAmount ?? '', $content);
            //             $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
            //             $content = str_replace('#customer_care',  $branch->cre_mobile ?? '8220011465', $content);
            //             $branchNo = $branch->mobile;
            //             $branchemail = $branch->mail;
            //             $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
            //             $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
            //             $url= 'phdizone.com';
                
            //             $mailData = [
            //                   'url'         => $url,
            //                   'subject'     => $dynamicSubject,
            //                   'content'     => $content,
            //                   'branchNo'    => $branchNo,
            //                   'branchemail' => $branchemail, // Use the message content from the request
            //                   'fbLink'      => $fbLink,      // Use the message content from the request
            //                   'instaLink'   => $instaLink,   // Use the message content from the request
            //                   'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
            //               ];
                
            //             $to_address = $lead->lead_email_id;
            //             $from_address = 'elysiumtechnology@elysium.community';
            //             $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
            //             Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            //          }
                     
            //           if ($lead->lead_mobile) {
                          
                           
            //                     // $templateName  = "hello_world";
            //                     $templateName  = "nda_phdizone";
                
            //                     $hasHeader  = false; // Example flag: set based on template
            //                     $hasBody    = false; // Example flag: set based on template
            //                     $hasFooter  = false; // Example flag: set based on template
            //                     $hasButton  = false;
            //                     $components = [];
            //                     $couponCode = " ";
            //                     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            //                     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            //                                                               // $currentHour = date('H'); // Get current hour in 24-hour format
            //                     if ($currentHour >= 5 && $currentHour < 12) {
            //                         $greeting = 'Good Morning';
            //                     } elseif ($currentHour >= 12 && $currentHour < 18) {
            //                         $greeting = 'Good Afternoon';
            //                     } else {
            //                         $greeting = 'Good Evening';
            //                     }
                
            //                     if ($templateName == 'nda_phdizone') {
            //                         $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/nda_signed.jpg';
            //                         $couponCode  = 'NOOFFER';
            //                         $buttonIndex = 1;
            //                         $bodyText    = [
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $lead->lead_name ?? '',
            //                                 'parameter_name' => 'customer_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $nda_id ?? 'GC/IZONE/2025/06/00001',
            //                                 'parameter_name' => 'nda_number',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => date('d-M-Y'),
            //                                 'parameter_name' => 'nda_date',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $proposal->service_title ?? '',
            //                                 'parameter_name' => 'service_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $slot_url_key,
            //                                 'parameter_name' => 'link_key',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $branch->cre_mobile ?? '8220011465',
            //                                 'parameter_name' => 'customer_care',
            //                             ],
            //                         ];
            //                         $hasHeader = true;
            //                         $hasBody   = true;
            //                         $hasButton = true;
            //                     }
                
            //                     // Add Header if required
            //                     if ($hasHeader) {
            //                         $components[] = [
            //                             'type'       => 'header',
            //                             'parameters' => [
            //                                 [
            //                                     'type'  => 'image',
            //                                     'image' => [
            //                                         'link' => $headerImage, // Dynamically set header image
            //                                     ],
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                
            //                     // Add Body if required
            //                     if ($hasBody) {
            //                         $components[] = [
            //                             'type'       => 'body',
            //                             'parameters' => $bodyText,
            //                         ];
            //                     }
                
            //                     // Add Footer if required
            //                     if ($hasButton) {
            //                         $components[] = [
            //                             'type'       => 'button',
            //                             'sub_type'   => 'url',
            //                             'index'      => 0,
            //                             'parameters' => [
            //                                 [
            //                                     'type' => 'text',
            //                                     'text' => $slot_url_key,
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                                
                                
            //                     $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
            //                     $dynamicParameters         = $templateParameters[$templateName] ?? [];
            //                     $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
            //                     $accessToken               = $whatsappApi->access_tokken ?? '';
            //                     $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
            //                     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
            //                     $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
            //                     $to           = $lead->lead_mobile;
            //                     $languageCode = 'en';
                    
            //                     if (strpos($to, $countryCode) !== 0) {
            //                         $to = $countryCode . $to;
            //                     }
                
            //                     $message = 'test~message';
            //                     if (empty($components)) {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'     => $templateName,
            //                                 'language' => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                             ],
            //                         ];
            //                     } else {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'       => $templateName,
            //                                 'language'   => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                                 'components' => $components,
            //                             ],
            //                         ];
            //                     }
                
            //                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            //                  if ($response['status'] == 200) {}
            //                  else{
            //                      return response([
            //                           'status' => 404,
            //                           'message' => 'Failed to send message',
            //                           'error_msg' => $response['error'],
            //                         ], 400);
            //                     }
                            
            //           }
                    
            //          DB::table('et_proposal')
            //             ->where('sno', $proposal_id)
            //             ->update(['nda_send_status' => 1]);
            //   }
            
            //   }
            // }
            
            // if($proposal->old_customer_check != 1){
            // // Customer Communication
            //  if($lead_status !=4){
            //      $creData=StaffModel::where('sno', $branch->cre_id)->first();
            //       if ($lead->lead_email_id) {
            //                 $emailTemplate_id =6; // proposal send Template Id
            //                 $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
            //                 // Gender condition
            //                 $genderPrefix = 'Mr/Ms'; // Default value
            //                 if ($lead->lead_gender == 1) {
            //                   $genderPrefix = 'Mr';
            //                 } elseif ($lead->lead_gender == 2) {
            //                   $genderPrefix = 'Ms';
            //                 }
                        
                        
                       
                        
            //             $content = $emailTemplate->email_subject;
                
            //             $dynamicSubject = str_replace('#customer_name', $customer ? $customer->cus_name :  '', $emailTemplate->email_name);
                
            //             $content = str_replace('#customer_name', $customer ? $customer->cus_name :  '', $content);
            //             $content = str_replace('#customer_id', $customer ? $customer->customer_id :  '', $content);
            //             $content = str_replace('#cre_name', $creData ? $creData->nick_name :  'Staff', $content);
            //             $content = str_replace('#customercare_no',  $branch->cre_mobile ?? '8220011465', $content);
            //             $branchNo = $branch->mobile;
            //             $branchemail = $branch->mail;
            //             $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone';
            //             $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
            //             $url= 'phdizone.com';
                
            //             $mailData = [
            //                   'url'         => $url,
            //                   'subject'     => $dynamicSubject,
            //                   'content'     => $content,
            //                   'branchNo'    => $branchNo,
            //                   'branchemail' => $branchemail, // Use the message content from the request
            //                   'fbLink'      => $fbLink,      // Use the message content from the request
            //                   'instaLink'   => $instaLink,   // Use the message content from the request
            //                   'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
            //               ];
                
            //             $to_address = $lead->lead_email_id;
            //             $from_address = 'elysiumtechnology@elysium.community';
            //             $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
            //             Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            //          }
                     
            //           if ($lead->lead_mobile) {
                          
                           
            //                     // $templateName  = "hello_world";
            //                     $templateName  = "customer_welcome";
                
            //                     $hasHeader  = false; // Example flag: set based on template
            //                     $hasBody    = false; // Example flag: set based on template
            //                     $hasFooter  = false; // Example flag: set based on template
            //                     $hasButton  = false;
            //                     $components = [];
            //                     $couponCode = " ";
            //                     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            //                     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            //                                                               // $currentHour = date('H'); // Get current hour in 24-hour format
            //                     if ($currentHour >= 5 && $currentHour < 12) {
            //                         $greeting = 'Good Morning';
            //                     } elseif ($currentHour >= 12 && $currentHour < 18) {
            //                         $greeting = 'Good Afternoon';
            //                     } else {
            //                         $greeting = 'Good Evening';
            //                     }
                
            //                     if ($templateName == 'customer_welcome') {
            //                         $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Welcome.jpg';
            //                         $couponCode  = 'NOOFFER';
            //                         $buttonIndex = 1;
            //                         $bodyText    = [
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $lead->lead_name ?? '',
            //                                 'parameter_name' => 'customer_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $customer ? $customer->customer_id :  '',
            //                                 'parameter_name' => 'customer_id',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $creData ? $creData->nick_name :  'Staff',
            //                                 'parameter_name' => 'cre_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $branch->cre_mobile ?? '8220011465',
            //                                 'parameter_name' => 'custonercare_no',
            //                             ],
            //                         ];
            //                         $hasHeader = true;
            //                         $hasBody   = true;
            //                     }
                
            //                     // Add Header if required
            //                     if ($hasHeader) {
            //                         $components[] = [
            //                             'type'       => 'header',
            //                             'parameters' => [
            //                                 [
            //                                     'type'  => 'image',
            //                                     'image' => [
            //                                         'link' => $headerImage, // Dynamically set header image
            //                                     ],
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                
            //                     // Add Body if required
            //                     if ($hasBody) {
            //                         $components[] = [
            //                             'type'       => 'body',
            //                             'parameters' => $bodyText,
            //                         ];
            //                     }
                
            //                     // Add Footer if required
            //                     if ($hasButton) {
            //                         $components[] = [
            //                             'type'       => 'button',
            //                             'sub_type'   => 'url',
            //                             'index'      => 0,
            //                             'parameters' => [
            //                                 [
            //                                     'type' => 'text',
            //                                     'text' => '',
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                                
                                
            //                     $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
            //                     $dynamicParameters         = $templateParameters[$templateName] ?? [];
            //                     $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
            //                     $accessToken               = $whatsappApi->access_tokken ?? '';
            //                     $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
            //                     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
            //                     $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
            //                     $to           = $lead->lead_mobile;
            //                     $languageCode = 'en';
                    
            //                     if (strpos($to, $countryCode) !== 0) {
            //                         $to = $countryCode . $to;
            //                     }
                
            //                     $message = 'test~message';
            //                     if (empty($components)) {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'     => $templateName,
            //                                 'language' => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                             ],
            //                         ];
            //                     } else {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'       => $templateName,
            //                                 'language'   => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                                 'components' => $components,
            //                             ],
            //                         ];
            //                     }
                
            //                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            //                  if ($response['status'] == 200) {}
            //                  else{
            //                      return response([
            //                           'status' => 404,
            //                           'message' => 'Failed to send message',
            //                           'error_msg' => $response['error'],
            //                         ], 400);
            //                     }
                            
            //           }
            //  }
             
            // // Receipt Communication 
            //      $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
            //       $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
            //       $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                   
            //       $Link_receipt ='https://erp.elysiumtechnologies.com/manage_invoice/invoice_print/'.$encrypted_values_receipt;
            //         if(!$slots->receipt_temp_link){
            //             $channelId_receipt = 7;
            //              $shortUrlData_receipt = $this->shortenUrl($ReceiptLink,$channelId_receipt);
            //              $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
            //              $urlId_receipt =$shortUrlData_receipt['id'];
            //              if($shortUrl_receipt){
            //                  DB::table('et_proposal_pay_slot')
            //                     ->where('sno', $slot->sno)
            //                     ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                
            //                       DB::table('et_chotta_links')->insert([
            //                           'branch_id' => $proposal->branch_id,
            //                           'chotta_link_id' => $urlId_receipt,
            //                           'chotta_short_link' => $shortUrl_receipt,
            //                           'large_encrypt_link' => $Link_receipt,
            //                           'link_type' => 'Receipt Send',
            //                           'pay_slot_id' =>$slot->sno,
            //                           'created_by' => $proposal->created_by,
            //                           'updated_by' => $proposal->created_by,
            //                       ]);
            //              }
            //         }
                    
            //               $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
            //               $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
            //               $slot_url_key_receipt = basename($shortsendUrl_receipt);
                          
            //              $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
            //              $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                         
            //              $paidAmount=$paymentData->paid_amount;
                         
            //               $slotAmount = $proposalData->currency_symbol . number_format($paidAmount, 2, '.', ',');
                        
            //               if ($lead->lead_email_id) {
            //                 $emailTemplate_id =7; // proposal send Template Id
            //                 $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
            //                 // Gender condition
            //                 $genderPrefix = 'Mr/Ms'; // Default value
            //                 if ($lead->lead_gender == 1) {
            //                   $genderPrefix = 'Mr';
            //                 } elseif ($lead->lead_gender == 2) {
            //                   $genderPrefix = 'Ms';
            //                 }
                        
                        
                       
                        
            //             $content = $emailTemplate->email_subject;
                
            //             $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
            //             $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead->lead_name, $content);
            //             $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
            //             $content = str_replace('#payment_date', date('d-M-Y'), $content);
            //             $content = str_replace('#link', $shortsendUrl_receipt, $content);
            //             $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
            //             $content = str_replace('#payment', $slotAmount ?? '', $content);
            //             $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
            //             $content = str_replace('#cre_number',  $branch->cre_mobile ?? '8220011465', $content);
            //             $branchNo = $branch->mobile;
            //             $branchemail = $branch->mail;
            //             $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
            //             $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
            //             $url= 'phdizone.com';
                
            //             $mailData = [
            //                   'url'         => $url,
            //                   'subject'     => $dynamicSubject,
            //                   'content'     => $content,
            //                   'branchNo'    => $branchNo,
            //                   'branchemail' => $branchemail, // Use the message content from the request
            //                   'fbLink'      => $fbLink,      // Use the message content from the request
            //                   'instaLink'   => $instaLink,   // Use the message content from the request
            //                   'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
            //               ];
                
            //             $to_address = $lead->lead_email_id;
            //             $from_address = 'elysiumtechnology@elysium.community';
            //             $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
            //             Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            //          }
                     
            //           if ($lead->lead_mobile) {
                          
                           
            //                     // $templateName  = "hello_world";
            //                     $templateName  = "payment_recept_phdizone";
                
            //                     $hasHeader  = false; // Example flag: set based on template
            //                     $hasBody    = false; // Example flag: set based on template
            //                     $hasFooter  = false; // Example flag: set based on template
            //                     $hasButton  = false;
            //                     $components = [];
            //                     $couponCode = " ";
            //                     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            //                     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            //                                                               // $currentHour = date('H'); // Get current hour in 24-hour format
            //                     if ($currentHour >= 5 && $currentHour < 12) {
            //                         $greeting = 'Good Morning';
            //                     } elseif ($currentHour >= 12 && $currentHour < 18) {
            //                         $greeting = 'Good Afternoon';
            //                     } else {
            //                         $greeting = 'Good Evening';
            //                     }
                
            //                     if ($templateName == 'payment_recept_phdizone') {
            //                         $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
            //                         $couponCode  = 'NOOFFER';
            //                         $buttonIndex = 1;
            //                         $bodyText    = [
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $lead->lead_name ?? '',
            //                                 'parameter_name' => 'customer_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $paymentData->payment_id ?? '',
            //                                 'parameter_name' => 'recept_number',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => date('d-M-Y'),
            //                                 'parameter_name' => 'payment_date',
            //                             ],
            //                              [
            //                                 'type'           => 'text',
            //                                 'text'           => $slotAmount ?? '',
            //                                 'parameter_name' => 'payment',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $proposal->service_title ?? '',
            //                                 'parameter_name' => 'service_name',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $slot_url_key_receipt,
            //                                 'parameter_name' => 'link_key',
            //                             ],
            //                             [
            //                                 'type'           => 'text',
            //                                 'text'           => $branch->cre_mobile ?? '8220011465',
            //                                 'parameter_name' => 'cre_number',
            //                             ],
            //                         ];
            //                         $hasHeader = true;
            //                         $hasBody   = true;
            //                         $hasButton = true;
            //                     }
                
            //                     // Add Header if required
            //                     if ($hasHeader) {
            //                         $components[] = [
            //                             'type'       => 'header',
            //                             'parameters' => [
            //                                 [
            //                                     'type'  => 'image',
            //                                     'image' => [
            //                                         'link' => $headerImage, // Dynamically set header image
            //                                     ],
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                
            //                     // Add Body if required
            //                     if ($hasBody) {
            //                         $components[] = [
            //                             'type'       => 'body',
            //                             'parameters' => $bodyText,
            //                         ];
            //                     }
                
            //                     // Add Footer if required
            //                     if ($hasButton) {
            //                         $components[] = [
            //                             'type'       => 'button',
            //                             'sub_type'   => 'url',
            //                             'index'      => 0,
            //                             'parameters' => [
            //                                 [
            //                                     'type' => 'text',
            //                                     'text' => $slot_url_key_receipt,
            //                                 ],
            //                             ],
            //                         ];
            //                     }
                                
                                
            //                     $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
            //                     $dynamicParameters         = $templateParameters[$templateName] ?? [];
            //                     $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
            //                     $accessToken               = $whatsappApi->access_tokken ?? '';
            //                     $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
            //                     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
            //                     $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
            //                     $to           = $lead->lead_mobile;
            //                     $languageCode = 'en';
                    
            //                     if (strpos($to, $countryCode) !== 0) {
            //                         $to = $countryCode . $to;
            //                     }
                
            //                     $message = 'test~message';
            //                     if (empty($components)) {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'     => $templateName,
            //                                 'language' => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                             ],
            //                         ];
            //                     } else {
            //                         $payload = [
            //                             'messaging_product' => 'whatsapp',
            //                             'to'                => $to,
            //                             'type'              => 'template',
            //                             'template'          => [
            //                                 'name'       => $templateName,
            //                                 'language'   => [
            //                                     'code' => $languageCode,
            //                                 ],
            //                                 'components' => $components,
            //                             ],
            //                         ];
            //                     }
                
            //                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            //                  if ($response['status'] == 200) {}
            //                  else{
            //                      return response([
            //                           'status' => 404,
            //                           'message' => 'Failed to send message',
            //                           'error_msg' => $response['error'],
            //                         ], 400);
            //                     }
                            
            //           }
                    
            //          DB::table('et_proposal_pay_slot')
            //             ->where('sno', $slots->sno)
            //             ->update(['receipt_send_status' => 1]);
              
            //  }
    
        }
        
        $encrypt_id_slot = $slot_id ;
        $helper = new \App\Helpers\Helpers();
        $encrypted_values_slot = $helper->encrypt_decrypt($encrypt_id_slot, 'encrypt');


        return response()->json([
            'status' => 200,
            'message' => 'Offline payment selected',
            'error_msg' => null,
            'data' => $encrypted_values_slot,
            'id' => $encrypted_values_slot,
            'pay_mode' => $pay_mode
        ]);

       

        
    }

    public function CreateOrderPayment($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $exp = explode('~', $decryptedValue);
        $prps_id = str_replace(' ', '', $exp[0] ?? '');
        $slot_id_hidden = str_replace(' ', '', $exp[1] ?? '');
        $slot_amount_hidden = str_replace(' ', '', $exp[2] ?? '');

        // $amount = $slot_amount_hidden;
        $slot_id = $slot_id_hidden;



        

        $proposal = DB::table('et_proposal')
            ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.sno', $prps_id)
            ->where('et_proposal.status', '!=', 2)
            ->first();

        if (!$proposal) {
            return redirect()->back()->with('error', 'Proposal not found or inactive.');
        }
        $amount = $slot_amount_hidden * 100;

        $currency = $proposal->currency_code ?? 'INR';
        $api = new Api($this->razorpayKey, $this->razorpaySecret);

        $order_no = 'ORD-' . now()->format('YmdHis') . '-' . rand(1000, 9999);
        try{
            $order = $api->order->create([
                'receipt' => $order_no,
                'amount' =>(int)$amount,
                'currency' => $currency,
            ]);
        } catch (\Razorpay\Api\Errors\ServerError $e) {
            // Razorpay server error
            return 'Razorpay Server Error: ' . $e->getMessage();
        } catch (\Razorpay\Api\Errors\Base $e) {
            // Razorpay API error (like bad request, unauthorized, etc.)
            return 'Razorpay API Error: ' . $e->getMessage();
        } catch (\Exception $e) {
            // Any other error (network, PHP, etc.)
            return 'Unexpected Error: ' . $e->getMessage();
        }

        return view('content.razorpay_page', [
            'order_id' => $order['id'],
            'amount' => $amount,
            'proposal' => $proposal,
            'razorpay_key' => $this->razorpayKey,
            'currency' => $currency,
            'prps_id' => $prps_id,
            'slot_id' => $slot_id,
            'page_id' => $id,
        ]);
    }

    public function handlePaymentSuccess(Request $request)
    {
        $razorpayOrderId = $request->razorpay_order_id;
        $razorpayPaymentId = $request->razorpay_payment_id;
        $razorpaySignature = $request->razorpay_signature;
        $slot_id = $request->slot_id;
        $proposal_id = $request->prps_id;
        
        $proposal_ids_cus=json_encode($proposal_id);

        // Fetch necessary data
        $slots = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id)
                    ->where('status', 0)
                    ->first();

        $proposal = DB::table('et_proposal')
                        ->where('sno', $proposal_id)
                        ->first();
        $proposalData =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$proposal_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
        $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();         
                        
        $leadData = DB::table('et_lead')
                            ->where('sno', $proposal->lead_id)
                        ->first();
        $lead_status =$leadData->status ?? '0';

        if (!$slots || !$proposal) {
            return response()->json(['status' => 'failed', 'message' => 'Invalid slot or proposal'], 400);
        }

        $leadData = DB::table('et_lead')
                        ->where('sno', $proposal->lead_id)
                        ->first();

        // Validate signature
        $generatedSignature = hash_hmac('sha256', $razorpayOrderId . "|" . $razorpayPaymentId, $this->razorpaySecret);

        if (!hash_equals($generatedSignature, $razorpaySignature)) {
            return response()->json(['status' => 'failed', 'message' => 'Invalid signature'], 400);
        }

        DB::beginTransaction();

        try {
            $api = new Api($this->razorpayKey,$this->razorpaySecret);
            $payment = $api->payment->fetch($razorpayPaymentId);

            $payment_method = $payment->method;
            $card_last4 = null;
            $card_network = null;
            $card_id = null;
            $payment_type = null;

            if ($payment_method === 'card') {
                $card_details = $payment->card;
                $card_last4 = $card_details->last4 ?? null;
                $card_network = $card_details->network ?? null;
                $card_id = $card_details->id ?? null;
                $payment_type = $card_details->sub_type ?? null;
            } elseif ($payment_method === 'upi') {
                $payment_type = $payment->vpa ?? null;
            } elseif ($payment_method === 'wallet') {
                $payment_type = $payment->wallet ?? null;
            } elseif ($payment_method === 'netbanking') {
                $payment_type = $payment->bank ?? null;
            }

            // Generate IDs helper function
            $generateId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)->orderBy('sno', 'desc')->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };
            
              $generateTransId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)->where('customer_type',0)->orderBy('sno', 'desc')->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };

            $invoice_id = $slots->invoice_id;
            $payment_id = $generateId('PAY', 'et_payment', 'payment_id', 6);

            $acquirer_data = $payment->acquirer_data;

            // If acquirer_data is string, decode it first
            if (is_string($acquirer_data)) {
                $acquirer_data = json_decode($acquirer_data, true);
            }

            // If acquirer_data is object, convert to array
            if (is_object($acquirer_data)) {
                $acquirer_data = (array) $acquirer_data;
            }
            $pay_transaction_id = !empty($acquirer_data) ? json_encode($acquirer_data) : null;

            // Insert payment
            $save_transaction = DB::table('et_payment')->insert([
                'payment_id'     => $payment_id,
                'invoice_id'     => $invoice_id,
                'branch_id'      => $slots->branch_id ?? 0,
                'payment_mode'   => 1,
                'proposal_id'    => $proposal_id ?? 0,
                'pay_slot_id'    => $slot_id ?? 0,
                'paid_amount'    => $payment->amount / 100,
                'transaction_date' => date('Y-m-d'),
                'order_id'       => $payment->order_id ?? null,
                'razor_pay_id'   => $payment->id,
                'payment_method' => $payment_method,
                'payment_type'   => $payment_type,
                'card_id'        => $card_id,
                'card_last4_no'  => $card_last4,
                'card_network'   => $card_network,
                'razor_fee'      => $payment->fee ? $payment->fee / 100 : null,
                'razor_tax'      => $payment->tax ? $payment->tax / 100 : null,
                'currency'       => $payment->currency,
                'pay_transaction_id' => $pay_transaction_id,
                'razorpay_status'=> $payment->status,
                'razorpay_data' => json_encode($payment->toArray()),
            ]);

            if (!$save_transaction) {
                DB::rollBack();
                return response()->json(['status' => 'failed', 'message' => 'Failed to save payment'], 500);
            }

            

            if ($leadData) {
                if($lead_status !=4){
                    $customer_id = $generateId('CUS', 'et_customer', 'customer_id', 5);
    
                    // Use updateOrCreate with unique identifier (like lead_id)
                    $customer = CustomerModel::updateOrCreate(
                        ['lead_id' => $leadData->sno],
                        [
                            'cus_name' => $leadData->lead_name,
                            'customer_id' => $customer_id,
                            'branch_id' => $leadData->branch_id ?? null,
                            'cus_gender' => $leadData->lead_gender ?? null,
                            'cus_dob' => $leadData->lead_dob ?? null,
                            'cus_mobile' => $leadData->lead_mobile ?? null,
                            'country_code' => $leadData->inter_calls ?? 0,
                            'cus_alternate_mobile' => $leadData->lead_alternate_mobile ?? null,
                            'cus_email_id' => $leadData->lead_email_id ?? null,
                            'door_no' => $leadData->door_no ?? null,
                            'pincode' => $leadData->pincode ?? null,
                            'country' => $leadData->country ?? null,
                            'state' => $leadData->state ?? null,
                            'city' => $leadData->city ?? null,
                            'address' => $leadData->address ?? null,
                            'proposal_ids' =>json_encode([$proposal_id]),
                            'created_by' => 0,
                            'updated_by' => 0,
                            'status' => 0,
                        ]
                    );
    
                     $lead_update = DB::table('et_lead')
                    ->where('sno', $leadData->sno)
                    ->update([
                        'status' => 4,
                        'lead_status_id' => 5,
                    ]);
    
                    if ($customer) {
    
                       if ($proposal->product_package == 2) {
                            // Insert a single service record for product_package 2
                            $save_services = DB::table('et_customer_services')->insert([
                                'branch_id'        => $customer->branch_id,
                                'lead_id'          => $customer->lead_id,
                                'customer_id'      => $customer->sno ?? 0,
                                'proposal_id'      => $proposal->sno ?? 0,
                                'cre_id'      => $proposal->cre_id ?? 0,
                                'product_package'  => $proposal->product_package ?? 0,
                                'package_id'       => $proposal->package_id ?? 0,
                            ]);
                        } else {
                            // Get the product cart data for other product_package values
                            $product_cart_data = DB::table('et_proposal_product_cart')
                                ->where('status', 0)
                                ->where('proposal_sno', $proposal->sno)
                                ->pluck('product_id');
    
                            foreach ($product_cart_data as $cart) {
                                $save_services = DB::table('et_customer_services')->insert([
                                    'branch_id'        => $customer->branch_id,
                                    'lead_id'          => $customer->lead_id,
                                    'customer_id'      => $customer->sno ?? 0,
                                    'proposal_id'      => $proposal->sno ?? 0,
                                     'cre_id'      => $proposal->cre_id ?? 0,
                                    'product_package'  => $proposal->product_package ?? 0,
                                    'product_id'       => $cart ?? 0,
                                ]);
                            }
                        }
    
                    }
                }else{
                    $customer=DB::table('et_customer')->where('status', '!=', 2)->where('lead_id', $leadData->sno)->first();
                }
                $paymentData = DB::table('et_payment')->where('status', '!=', 2)->where('invoice_id', $invoice_id)->first();

                $subledger_id = $generateId('SUB', 'et_subledger', 'subledger_id', 5);

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $invoice_id;
                $add_subledger->subledger_desc = 'Proposal Payment';
                $add_subledger->branch_id = $customer->branch_id;
                $add_subledger->payment_sno = $paymentData->sno ?? null;
                $add_subledger->created_by = 0;
                $add_subledger->updated_by = 0;
                $add_subledger->save();

                $transaction_id = $generateTransId('TRANS', 'et_transaction', 'transaction_id', 5);

                 $add_transaction = new TransactionModel();
                $add_transaction->transaction_id = $transaction_id;
                $add_transaction->branch_id = $customer->branch_id;
                $add_transaction->transaction_type = 'Credit';
                $add_transaction->transaction_name = 'Customer';
                $add_transaction->customer_id = $customer->sno;
                $add_transaction->ledger_id = 1;
                $add_transaction->subledger_id = $add_subledger->sno;
                $add_transaction->invoice_id = $invoice_id;
                $add_transaction->receipt_id = null;
                $add_transaction->payment_id = $paymentData->sno ?? null;
                $add_transaction->created_by = 0;
                $add_transaction->updated_by = 0;
                $add_transaction->save();
            }
            
            // Update slot status
            $slot_update = DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id)
                ->where('status', 0)
                ->update([
                    'invoice_id' => $invoice_id,
                    'link_status' => 1,
                    'paid_status' => 1,
                    'initialPayDate' => date('Y-m-d'),
                    'paidAmount' => $slots->payable_amount, 
                ]);
            if($lead_status !=4){
                $proposal_update = DB::table('et_proposal')
                    ->where('sno', $proposal_id)
                    ->update([
                        'proposal_status' => 3,
                    ]);
            }
            if (!$slot_update) {
                DB::rollBack();
                return response()->json(['status' => 'failed', 'message' => 'Failed to update slot'], 500);
            }
            
            $cus_Proposal_update = DB::table('et_proposal')
                ->where('sno', $proposal_id)
                ->where('status', 0)
                ->update([
                    'customer_id' =>$customer->sno,
                ]);
                
                $cus_pay = DB::table('et_payment')
                ->where('sno', $paymentData->sno)
                ->update([
                    'customer_id' =>$customer->sno,
                ]);
            
              DB::commit();
              
            
            // Nda signed Communication
            if($proposal->nda_signed !=1){
             $nda_check = DB::table('et_manage_nda')->where('proposal_id', $proposal_id)->first();
              if (!$nda_check) {
                    $year = date('Y');
                    $month = date('m');
                    
                    // Get the last NDA record
                    $category_check_nda = DB::table('et_manage_nda')->orderBy('sno', 'desc')->first();
                    
                    
                    if (!$category_check_nda) {
                        $next_number = 1;
                    } else {
                        $last_nda_id = $category_check_nda->nda_id;
                    
                        $parts = explode('/', $last_nda_id);
                        $last_number = isset($parts[4]) ? (int) $parts[4] : 0;
                        $next_number = $last_number + 1;
                    }
                    
                    $nda_id = sprintf("EGC/IZONE/%s/%s/%05d", $year, $month, $next_number);
                     
             $helper = new \App\Helpers\Helpers();
              $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');
               $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
               $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
               
              $Link ='https://erp.elysiumtechnologies.com/manage_nda/nda_message/'.$encrypted_values;
              if($proposal->old_customer_check == 1){
                  
                   DB::table('et_manage_nda')->insert([
                                      'nda_id' =>$nda_id,
                                      'nda_link' =>  $Link,
                                      'nda_date' => date('Y-m-d'),
                                      'customer_id' => $customer ? $customer->sno : 0,
                                      'proposal_id' => $proposal_id,
                                      'branch_id' => $proposal->branch_id ?? '0',
                                      'status' => 0,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                  //   For Old Customer
                 DB::table('et_proposal')
                    ->where('sno', $proposal_id)
                    ->update([
                        'nda_temp_link' => $Link,
                        'nda_old_customer_check'=>1,
                        ]);
              }else{
                    if(!$proposal->nda_temp_link){
                        $channelId = 6;
                         $shortUrlData = $this->shortenUrl($Link,$channelId);
                         $shortUrl = $shortUrlData['shorturl'];
                         $urlId =$shortUrlData['id'];
                         if($shortUrl){
                             DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update(['nda_temp_link' => $shortUrl]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $proposal->branch_id,
                                      'chotta_link_id' => $urlId,
                                      'chotta_short_link' => $shortUrl,
                                      'large_encrypt_link' => $Link,
                                      'link_type' => 'NDA Send',
                                      'proposal_id' =>$proposal_id,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                         }
                    }
                         $slotUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
                          $shortsendUrl = $slotUrl->nda_temp_link ;
                          $slot_url_key = basename($shortsendUrl);
                          
                          DB::table('et_manage_nda')->insert([
                                      'nda_id' =>$nda_id,
                                      'nda_link' =>$shortsendUrl ,
                                      'nda_date' => date('Y-m-d'),
                                      'customer_id' => $customer ? $customer->sno : 0,
                                      'proposal_id' => $proposal_id,
                                      'branch_id' => $proposal->branch_id ?? '0',
                                      'status' => 0,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                        
                          if ($lead->lead_email_id) {
                            $emailTemplate_id =5; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                        
                       
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name', $lead->lead_name, $content);
                        $content = str_replace('#nda_number', $nda_id ?? 'EGC/IZONE/2025/06/00001', $content);
                        $content = str_replace('#nda_date', date('d-M-Y'), $content);
                        $content = str_replace('#link', $shortsendUrl, $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#invoice_amount', $slotAmount ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#customer_care',  $branch->cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead->lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                     
                      if ($lead->lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "nda_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'nda_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/nda_signed.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead->lead_name ?? '',
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $nda_id ?? 'EGC/IZONE/2025/06/00001',
                                            'parameter_name' => 'nda_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => date('d-M-Y'),
                                            'parameter_name' => 'nda_date',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key,
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $branch->cre_mobile ?? '8220011465',
                                            'parameter_name' => 'customer_care',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead->lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                    
                     DB::table('et_proposal')
                        ->where('sno', $proposal_id)
                        ->update(['nda_send_status' => 1]);
              }
            
              }
            }
            
             if($proposal->old_customer_check != 1){
                 
            // Customer Communication
             if($lead_status !=4){
                 $creData=StaffModel::where('sno', $branch->cre_id)->first();
                   if ($lead->lead_email_id) {
                            $emailTemplate_id =6; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                        
                       
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#customer_name', $customer ? $customer->cus_name :  '', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name', $customer ? $customer->cus_name :  '', $content);
                        $content = str_replace('#customer_id', $customer ? $customer->customer_id :  '', $content);
                        $content = str_replace('#cre_name', $creData ? $creData->nick_name :  'Staff', $content);
                        $content = str_replace('#customercare_no',  $branch->cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone';
                        $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead->lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                     
                      if ($lead->lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "customer_welcome";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'customer_welcome') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Welcome.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead->lead_name ?? '',
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->customer_id :  '',
                                            'parameter_name' => 'customer_id',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $creData ? $creData->nick_name :  'Staff',
                                            'parameter_name' => 'cre_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $branch->cre_mobile ?? '8220011465',
                                            'parameter_name' => 'custonercare_no',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => '',
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead->lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
             }
             
            // Receipt Communication 
                 $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                   
                  $Link_receipt ='https://erp.elysiumtechnologies.com/receipt_print/'.$encrypted_values_receipt;
                    if(!$slots->receipt_temp_link){
                        $channelId_receipt = 7;
                         $shortUrlData_receipt = $this->shortenUrl($Link_receipt,$channelId_receipt);
                         $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
                         $urlId_receipt =$shortUrlData_receipt['id'];
                         if($shortUrl_receipt){
                             DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot->sno)
                                ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $proposal->branch_id,
                                      'chotta_link_id' => $urlId_receipt,
                                      'chotta_short_link' => $shortUrl_receipt,
                                      'large_encrypt_link' => $Link_receipt,
                                      'link_type' => 'Receipt Send',
                                      'pay_slot_id' =>$slot->sno,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                         }
                    }
                    
                          $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                          $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
                          $slot_url_key_receipt = basename($shortsendUrl_receipt);
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                         
                         $paidAmount=$paymentData->paid_amount;
                         
                          $slotAmount = $proposalData->currency_symbol . number_format($paidAmount, 2, '.', ',');
                        
                          if ($lead->lead_email_id) {
                            $emailTemplate_id =7; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                        
                       
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead->lead_name, $content);
                        $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
                        $content = str_replace('#payment_date', date('d-M-Y'), $content);
                        $content = str_replace('#link', $shortsendUrl_receipt, $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#payment', $slotAmount ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $branch->cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $branch_data->cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead->lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                     
                      if ($lead->lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead->lead_name ?? '',
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt,
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $branch->cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead->lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                    
                     DB::table('et_proposal_pay_slot')
                        ->where('sno', $slots->sno)
                        ->update(['receipt_send_status' => 1]);
              
             }
          

            return response()->json([
                'status' => 'success',
                'lead_status' => $lead_status,
                'encrypt_id' => $encrypted_values,
                'payment' =>  $payment->toArray()
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'failed', 'message' => $e->getMessage()], 500);
        }
    }

 public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
        
        private function sendRequestToWhatsApp($url, $token, $data)
      {
        try {
          $client = new \GuzzleHttp\Client();
          $response = $client->post($url, [
            'headers' => [
              'Authorization' => 'Bearer ' . $token,
              'Content-Type' => 'application/json',
            ],
            'json' => $data,
          ]);
    
          return [
            'status' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
          ];
        } catch (\Exception $e) {
          return [
            'status' => 400,
            'error' => $e->getMessage(),
          ];
        }
      }
      
      
    //   Transcation History List
     public function PaymentHistory(Request $request)
  {
      
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    // paid amount
    $sumPaidAmount = DB::table('et_payment')
      ->where('et_payment.status', 1)
       ->where('et_payment.branch_id', $branch_id)
      ->sum('et_payment.paid_amount');
    

$HistoryPayment = DB::table('et_customer')->select('et_customer.*')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2);

    if (!empty($search_fill)) {
        $HistoryPayment->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }

    $HistoryPayment = $HistoryPayment->orderBy('et_customer.sno', 'desc')
        ->paginate($perpage);
        
    
    $total_schedule_amount=0;
    $total_paid_amount=0;

    foreach($HistoryPayment as $cus){
        $proposal_ids=json_decode($cus->proposal_ids);
       $proposals = DB::table('et_proposal')
        ->whereIn('sno', $proposal_ids)
        ->pluck('service_title') 
        ->toArray();
        
        $total_amount = DB::table('et_proposal')
        ->where('customer_id',$cus->sno)
        ->sum('total_amount');
        $total_schedule_amount +=$total_amount;
        
        $paid_amount = DB::table('et_proposal_pay_slot')
        ->where('proposal_sno',$proposal_ids)
        ->where('paid_status',1)
        ->sum('paidAmount');
        
        $total_paid_amount +=$paid_amount;

        $cus->proposal_names = implode(', ', $proposals);
        $cus->total_amount=$total_amount;
        $cus->total_amount=$total_amount;
        $cus->total_paid=$paid_amount;
        $cus->total_balance=$total_amount-$paid_amount;
        
        $lastData=DB::table('et_payment')
        ->where('customer_id', $cus->sno)
        ->where('status',0) 
        ->orderBy('sno','desc')
        ->first();
        $cus->transaction_date=$lastData->transaction_date;
       $transactionDate = Carbon::parse($lastData->transaction_date);
        $currentDate = Carbon::now();
        $cus->last_since_payment_days = $transactionDate->diffInDays($currentDate);
    }





      

        

        $OutstandingPayment = DB::table('et_payment')->where('et_payment.branch_id', $branch_id)
          ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->where('et_payment.status', 0)
          ->where('et_customer.status', 0)
          ->whereDate('et_payment.transaction_date', '<=', $currentDate)
          ->orderBy('et_payment.sno', 'asc')->count();

        $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();

        $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

        $TodayPayment = DB::table('et_payment')->where('et_payment.branch_id', $branch_id)
          ->where('et_payment.status', 0)
          ->whereDate('et_payment.transaction_date', $currentDate)->count();

          // Current Month
        $outstandingAmount = DB::table('et_payment')
        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->where('et_payment.status', 0)
        ->where('et_customer.status', 0)
        ->where('et_payment.branch_id', $branch_id)
        ->sum('et_payment.paid_amount');
        
        $outstandingAmount =$total_schedule_amount -$total_paid_amount;
        // return $HistoryPayment;
        
        $TodayPayment=0;
    // Return the view with the data and total count
    return view('content.payment_management.manage_payment.payment_history', [
      'perpage' => $perpage,
      'cus_fill' => $cus_fill,
      'HistoryPayment' => $HistoryPayment,
      'outstandingAmount' => $outstandingAmount,
      'sumPaidAmount' => $total_paid_amount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'gstPercentage' => $gstPercentage,
    ])->with('filter_on', false);
  }
  
   public function getCustomerDetails($id, Request $request)
  {
      $helper = new \App\Helpers\Helpers();
      $branch_id = $request->user()->branch_id;
      $customer = CustomerModel::find($id);

      // Get branch details and calculate GST percentage
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
          
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

     
      $generalSettings = $helper->general_setting_data();
      $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

      // Fetch payments and format dates + add encrypted values
      $payments = DB::table('et_payment')->where('customer_id', $id)->where('et_payment.paid_amount', '>',0)->where('et_payment.status', '!=',2)->get()->map(function ($payment, $index) use ($dateFormat, $helper) {
          // Format dates
          $payment->transaction_date = $payment->transaction_date ? \Carbon\Carbon::parse($payment->transaction_date)->format($dateFormat) : null;
        //   $payment->nextPayDate = $payment->nextPayDate ? \Carbon\Carbon::parse($payment->nextPayDate)->format($dateFormat) : null;

          // Add encrypted fields
          $payment->encryptedValue = $helper->encrypt_decrypt($payment->invoice_id, 'encrypt');
          $payment->printValue = $helper->encrypt_decrypt($index + 1, 'encrypt');

          return $payment;
      });
    //   $paidamount = $payments->sum('paid_amount');
    //   total payment
       $grandTotal =  DB::table('et_proposal')->where('customer_id', $id)
        ->orderBy('created_at', 'desc') // Get latest records first
        ->sum('total_amount');
    
    
        
      $paidamount =  DB::table('et_payment')->where('customer_id', $id)->sum('paid_amount'); 
    
        // // Sum total_amount from the latest records of each payment_id
        //  $grandTotal = $paymentss->sum('paid_amount');
         
         $balanceAmount = $grandTotal- $paidamount;
         
      return response()->json([
          'customer' => $customer,
          'payments' => $payments,
          'grandTotal' => $grandTotal,
           'paidamount' => $paidamount,
            'balanceAmount' => $balanceAmount,
          'gstPercentage' => $gstPercentage,
      ]);
  }
  
   public function PaidUnder(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perPage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perPage;
      $cus_fill = $request->cus_fill ?? '';
    
      // Get the current date
      $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    
      // Get branch details
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
  
      // Handle case where no branch is found
      if (!$branch) {
          return redirect()->back()->with('error', 'Branch not found.');
      }
  
      // Sum of the amounts
      $sumScheduleAmount = DB::table('et_proposal_pay_slot')
          ->where('et_proposal_pay_slot.branch_id', $branch_id)
          ->where('et_proposal_pay_slot.proposal_sno','>',0)
          ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
          ->whereNotIn('et_proposal.proposal_status',[0,2])
          ->where('et_proposal.status',0)
          ->where('et_customer.status','!=',2)
          ->sum('et_proposal_pay_slot.payable_amount');
          
      $sumPaidAmount = DB::table('et_proposal_pay_slot')
          ->where('et_proposal_pay_slot.branch_id', $branch_id)
          ->where('et_proposal_pay_slot.proposal_sno','>',0)
          ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
          ->whereNotIn('et_proposal.proposal_status',[0,2])
          ->where('et_proposal.status',0)
          ->where('et_customer.status','!=',2)
          ->sum('et_proposal_pay_slot.paidAmount');
          
  $sumBalanceFee = $sumScheduleAmount - $sumPaidAmount;
  
  
      // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('et_proposal')
          ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
          ->join('et_customer', 'et_customer.sno', '=', 'et_payment.customer_id')
          ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
          ->select(
              'et_customer.customer_id',
              'et_payment.proposal_id',
              'et_payment.payment_mode',
              'et_payment.payment_id',
              'et_customer.sno as customer_sno',
              'et_customer.cus_name',
              'et_customer.cus_gender',
              'et_customer.cus_pic',
              'et_customer.cus_mobile',
              'et_customer.cus_email_id',
              'et_proposal.service_title',
              'et_proposal.total_amount',
              'et_proposal.proposal_id as auto_proposal_id',
              'et_proposal.sno as proposal_primary_id',
              'et_payment.transaction_date',
              'et_proposal_pay_slot.paidAmount',
              'et_proposal_pay_slot.nextPayDate',
              'et_proposal_pay_slot.initialPayDate'
          )
          ->where('et_payment.branch_id', $branch_id)
          ->groupBy(
              'et_customer.customer_id',
              'et_customer.sno',
              'et_payment.payment_id',
              'et_payment.payment_mode',
              'et_customer.cus_name',
              'et_customer.cus_mobile',
              'et_customer.cus_pic',
              'et_customer.cus_gender',
              'et_customer.cus_email_id',
              'et_proposal.service_title',
              'et_proposal.proposal_id',
              'et_proposal.sno',
              'et_proposal.total_amount',
              'et_payment.transaction_date',
              'et_payment.proposal_id',
              'et_proposal_pay_slot.paidAmount',
              'et_proposal_pay_slot.nextPayDate',
              'et_proposal_pay_slot.initialPayDate'
          )
            ->orderByDesc('et_payment.sno')
          ->get()
           ->unique('proposal_id'); // Keep only unique customer records;
    
    foreach($PaidUnderPayment as $pay){
         $sumPaidAmount = DB::table('et_proposal_pay_slot')
          ->where('et_proposal_pay_slot.branch_id', $branch_id)
          ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
          ->whereNotIn('et_proposal.proposal_status',[0,2])
          ->where('et_proposal.status',0)
          ->where('et_proposal_pay_slot.proposal_sno',$pay->proposal_primary_id)
          ->where('et_customer.status','!=',2)
          ->sum('et_proposal_pay_slot.paidAmount');
        
        $pay->paidAmount =$sumPaidAmount;
    }
    
    // return $PaidUnderPayment;
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->paidAmount < $branch->min_prd_cost;
      });
      
    
    
      // Apply search condition if 'cus_fill' is provided
      if ($cus_fill) {
          $result = $result->filter(function ($payment) use ($cus_fill) {
              return strpos(strtolower($payment->cus_name), strtolower($cus_fill)) !== false ||
                     strpos(strtolower($payment->cus_mobile), strtolower($cus_fill)) !== false;
          });
      }
    
      // Group by customer_id
      $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          // Filter payments where paidAmount is greater than 0
          $filteredPayments = $payments->filter(function ($payment) {
              return $payment->paidAmount > 0;
          });
    
          // If no valid payments exist after filtering, exclude this customer
          if ($filteredPayments->isEmpty()) {
              return null;
          }
    
          $payment = $payments->first();
    
          // Return structured data for each customer
          return [
              'customer_name' => $payment->cus_name,
              'customer_sno' => $payment->customer_sno,
              'total_paid' => $payment->paidAmount,
              'min_required' => $branch->min_prd_cost,
              'status' => 'Pending',
              'payments' => $filteredPayments->sortBy('transaction_date')->map(function ($payment) {
                  return [
                      'service_title' => $payment->service_title,
                      'auto_proposal_id' => $payment->auto_proposal_id,
                      'cus_gender' => $payment->cus_gender,
                      'cus_pic' => $payment->cus_pic,
                      'payment_id' => $payment->payment_id,
                      'cus_name' => $payment->cus_name,
                      'cus_mobile' => $payment->cus_mobile,
                      'amount' => $payment->total_amount,
                      'paidAmount' => $payment->paidAmount,
                      'balanceFee' => $payment->total_balance_fee ?? 0,
                      'gst_amount' => $payment->total_gst_amount ?? 0,
                      'nextPayDate' => $payment->nextPayDate,
                      'initialPayDate' => $payment->initialPayDate,
                      'transaction_date' => $payment->transaction_date,
                       'payment_mode_label' => $payment->payment_mode == 1 ? 'Online' :'Offline',
                  ];
              })->values(), // Reset array keys
          ];
      })->filter();
  
      // Paginate the results
      $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
    
      // Calculate the total number of pages
      $totalItems = $finalResult->count();
      $totalPages = ceil($totalItems / $perPage);
  
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    
   
     
    
      $OutstandingPayment = DB::table('et_payment')->where('et_payment.branch_id', $branch_id)
          ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->where('et_payment.status', 0)
          ->where('et_customer.status', 0)
          ->whereDate('et_payment.transaction_date', '<=', $currentDate)
          ->orderBy('et_payment.sno', 'asc')->count();
    
      // Get today's payments (nextPayDate equals today)
      $TodayPayment = DB::table('et_payment')->where('et_payment.branch_id', $branch_id)
          ->where('et_payment.status', 0)
          ->whereDate('et_payment.transaction_date', $currentDate)
          ->count();
    
      $outstandingAmount = DB::table('et_payment')
          ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->where('et_payment.status', 0)
          ->where('et_customer.status', 0)
          ->where('et_payment.branch_id', $branch_id)
          ->whereDate('et_payment.transaction_date', '<=', $currentDate)
          ->sum('et_payment.paid_amount');
        $TodayPayment=0;
      // Return the view with the data
      return view('content.payment_management.manage_payment.paid_under', [
          'perpage' => $perPage,
          'cus_fill' => $cus_fill,
          'sumScheduleAmount' => $sumScheduleAmount,
          'outstandingAmount' => $outstandingAmount,
          'sumBalanceFee' => $sumBalanceFee,
          'PaidUnderPayment' => $paginatedResult,
          'PaidUnderPaymentCount' => $totalItems,
          'TodayPaymentCount' => $TodayPayment,
          'OutstandingPaymentCount' => $OutstandingPayment,
          'gstPercentage' => $gstPercentage,
          'branch' => $branch,
          'pagination' => [
              'current_page' => $page,
              'total_pages' => $totalPages,
              'total_items' => $totalItems,
              'per_page' => $perPage,
          ]
      ])->with('filter_on', true);
  }
  
  public function ReceiptPrint($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->first();
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    // return  $slotData->total_amount;
    // $slotData->due_amount =$balance_amount;
    $slotData->total_paid_amount_receipt =$paidAmount;
    
     $prps_id =$slotData->proposal_sno;
    

      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.nick_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';
            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                $cart_total = $variable_amount + $product_data->base_price;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverables = DB::table('et_product_delivarables')
                        ->whereIn('sno', $deliverable_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('delivarable_name');
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
       
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
    
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $productSlot_amount ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;


    // return $proposal;

    return view('content.payment_management.manage_history.receipt_print',[
      'lead' =>$lead,
      'paySlots' =>$slotData,
      'proposal' =>$proposal,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
    ]);
  }
  
  public function SendReceiptMessage(Request $request)
    {
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

     
      $slot_id  = $request->slot_id;
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;

     $slots = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id)
                    ->where('status', 0)
                    ->first();

    $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$slots->proposal_sno)
              ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
              ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->where('et_lead.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
         $proposal_id  = $proposal->sno;
      $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      $paymentData=DB::table('et_payment')->where('et_payment.pay_slot_id',$slot_id)->first();
      // Extract the validated data
      $lead_id=$proposal->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
      
      

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($slot_id, 'encrypt');

      $ReceiptLink ='https://erp.elysiumtechnologies.com/receipt_print/'.$encrypted_values;
      
         //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         
        if($communicationStatus && $communicationStatus->status == 0){
      
     
              // Receipt Communication 
              
                 $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                  
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                  
                        $TargetCurrency = $proposal->currency_code ?? 'INR';
                        $converted_amount =$slots->paidAmount;
                        $endpoint = 'convert';
                        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
                        $helper = new \App\Helpers\Helpers();
                          if ($TargetCurrency !== 'INR') {
                            $response= $helper->convertFromINR($TargetCurrency);   
                            $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                            $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                            $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
                          }else{
                            $converted_amount =$slots->paidAmount;
                          }
               
               
               $slotAmount = $proposal->currency_symbol . number_format($converted_amount, 2, '.', ',');
                  
                  
                   
                 
                         if(!$slots->receipt_temp_link){
                        $channelId_receipt = 7;
                         $shortUrlData_receipt = $this->shortenUrl($ReceiptLink,$channelId_receipt);
                         $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
                         $urlId_receipt =$shortUrlData_receipt['id'];
                         if($shortUrl_receipt){
                             DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot->sno)
                                ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $proposal->branch_id,
                                      'chotta_link_id' => $urlId_receipt,
                                      'chotta_short_link' => $shortUrl_receipt,
                                      'large_encrypt_link' => $ReceiptLink,
                                      'link_type' => 'Receipt Send',
                                      'pay_slot_id' =>$slot->sno,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                         }
                    }
                    
                          $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                          $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
                          $slot_url_key_receipt = basename($shortsendUrl_receipt);
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
                       
                          
                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                        if ($sms == 1) {
            
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$shortsendUrl_receipt,$slotAmount,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                    
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                    
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                    
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                            }
                    }
                    
                    // Email Receipt Send
                      if($communicationStatus->email ==0){ 
                           if ($email == 1) {
                        if ($lead_email_id) {
                            $emailTemplate_id =7; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                      
                       $transaction_date = Carbon::parse($paymentData->transaction_date)->format('d M Y');
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                        $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
                        $content = str_replace('#payment_date', $transaction_date ?? date('d-M-Y'), $content);
                        $content = str_replace('#link', $shortsendUrl_receipt, $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#payment', $slotAmount ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                           }
                      }
                      
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           
                          if ($whatsapp == 1) {
                        if ($lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt,
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                          }
                      }
                    
                     DB::table('et_proposal_pay_slot')
                        ->where('sno', $slots->sno)
                        ->update(['receipt_send_status' => 1]);
        }
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
    
    public function encrypt_ids(Request $request)
  {
    // Get the values sent from JavaScript
    $values = $request->input('values');
    // Encrypt the combined values
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }
   public function DownloadReceiptPrint($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $branch_id = $request->user()->branch_id;
         $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->first();
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $slotData->due_amount =$balance_amount;
        $slotData->total_paid_amount_receipt =$paidAmount;
     $prps_id =$slotData->proposal_sno;
    

      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.nick_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $proposal->lead_name =$lead_data->lead_name ?? '';
          $proposal->lead_door_no =$lead_data->door_no ?? '';
          $proposal->lead_address = $lead_data->address ?? '';
          $proposal->lead_city_name =  $lead_data->city_name ?? '' ;
          $proposal->lead_state_name =  $lead_data->state_name ?? '' ;
          $proposal->lead_country_name =  $lead_data->country_name ?? '' ;
          $proposal->lead_pincode =  $lead_data->pincode ?? '';
          $proposal->lead_mail =  $lead_data->lead_email_id ?? '' ;
          $proposal->lead_mobile =  $lead_data->lead_mobile ??'' ;

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                $cart_total = $variable_amount + $product_data->base_price;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverables = DB::table('et_product_delivarables')
                        ->whereIn('sno', $deliverable_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('delivarable_name');
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
       
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
    
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $productSlot_amount ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;
    
        // if ($interns) {
        //     $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
        //     $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
        //     $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

        //     $qrContent = "Name         : {$interns->intern_name}\n"
        //         . "Start Date   : {$interns->start_date_formatted}\n"
        //         . "End Date     : {$interns->end_date_formatted}\n"
        //         . "Company      : {$interns->company}\n"
        //         . "Issue Date   : {$issueDateFormatted}\n"
        //         . "Certificate  : Verified";



        //     // Create QR using PHP without installation
        //     $qrImage = imagecreate(200, 200);
        //     $white = imagecolorallocate($qrImage, 255, 255, 255);
        //     $black = imagecolorallocate($qrImage, 0, 0, 0);
        //     imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

        //     // Just a placeholder pattern (real QR not generated like this)
        //     // Since you don't want to install any package and can't rely on Google API,
        //     // we're forced to ask: are you open to use a **small local script** or CDN?

        //     // RECOMMENDED: Use API from https://api.qrserver.com/

        //     $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

        //     // Convert to base64
        //     $qrImageData = @file_get_contents($qrServerUrl);
        //     $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        // }

        // return $interns;
        $pdf = PDF::loadView('content.payment_management.manage_history.receipt_page', [
            'lead' =>$lead,
              'paySlots' =>$slotData,
              'proposal' =>$proposal,
              'branch_data' =>$branch_data,
              'proposal_note' =>$proposal_note,
              'proposal_terms' =>$proposal_terms,
              'signature' =>$signature,
              'packages' =>$packages,
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        return $pdf->download('receipt.pdf');   
        // return view('content.payment_management.manage_history.receipt_page', [
        //     'lead' =>$lead,
        //       'paySlots' =>$slotData,
        //       'proposal' =>$proposal,
        //       'branch_data' =>$branch_data,
        //       'proposal_note' =>$proposal_note,
        //       'proposal_terms' =>$proposal_terms,
        //       'signature' =>$signature,
        //       'packages' =>$packages,
        // ]
        // );
    }
    
    public function PayLater(Request $request){
        
        $amount = $request->slot_amount;
        $slot_id = $request->slot_id;
        $prps_id = $request->proposal_id;
        $pay_mode = $request->pay_mode;
         $transaction_id = $request->reason;
        
           DB::table('et_proposal_pay_slot')
                                ->where('sno',$slot_id)
                                ->update([
                                    'paid_status' =>2,
                                    'pay_later_reason' =>$transaction_id
                                    ]);
                                
            $encrypt_id = $slot_id;
            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($encrypt_id, 'encrypt');

            return response()->json([
                'status' => 200,
                'message' => 'Payment Redirect',
                'error_msg' => null,
                'data' => $encrypted_values,
                'id' => $encrypted_values,
                'pay_mode' => $pay_mode
            ]);
                                
    }
    
    public function OfflineAccepted($id ,Request $request){
         
        

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    //   return $decryptedValue;
     
                 
        $slotData = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.sno',$decryptedValue)
                        ->where('et_proposal_pay_slot.status',0)
                        ->orderBy('et_proposal_pay_slot.sno', 'asc')
                        ->first();
        // return $slotData;
                        
         $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_country_currencies.currency_symbol','et_country_currencies.currency_code')
             ->where('et_proposal.sno',$slotData->proposal_sno)
             ->where('et_proposal.status','!=',2)
             ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
        // return $slotData;
        $link=$slotData->temp_send_link;
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
      return view('content.lead_management.manage_proposal.offline_payment',[
        'proposal'=>$proposal,
        'slot'=>$slotData,
        'link'=>$link,
        'cug_mobile'=>$cug_details->staff_mobile ?? $branch->cre_mobile,
      ]);
    }

}
