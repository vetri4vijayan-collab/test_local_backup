<?php

namespace App\Http\Controllers\payment_management;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\PaymentModel;
use App\Models\CustomerModel;
use App\Models\PaymentOldModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageHarvesting extends Controller
{
    
//      public function Index(Request $request, $month = null, $year = null ,$day = null)
//   {
//     $branch_id = $request->user()->branch_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

    
//     $balance_payment = $request->get('balance_payment', $balance_payment ?? '');
    
//     // $month_filter = 'Feb-2025';
//     $month_filter = $request->get('month_filter', date('M-Y'));
//     $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
//     $month = $parsedDate->month; // numeric month (1-12)
//     $year = $parsedDate->year;
//     $day = $request->input('day', $day ?? null); // optional
//   $month_chk =0;
//      $helper = new \App\Helpers\Helpers();
//     // return $month;
     
//     // Get the current date
//     $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
//     $drop_ids = DB::table('et_customer')
//       ->where('et_customer.drop_refund_id', '!=' ,0)
//       ->where('et_customer.drop_verified' ,1)
//       ->pluck('et_customer.sno');
    
//      $firstIds = DB::table('et_proposal_pay_slot')
//         ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//         ->where('et_proposal.status', 0)
//         ->where('et_proposal_pay_slot.status', 0)
//         ->whereNotIn('et_proposal.proposal_status', [0, 2])
//         ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
//         ->groupBy('et_proposal_pay_slot.proposal_sno')
//         ->orderBy('first_id', 'asc')
//         ->pluck('first_id');
//     // paid amount
//     $sumPaidAmount = DB::table('et_payment')
//       ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//       ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
//       ->where('et_proposal.status', 0)
//       ->whereNotIn('et_proposal.proposal_status', [0,2])
//       ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//       ->sum('et_proposal_pay_slot.paidAmount');
//     $customer_fill = $request->cus_fill ?? '';
    

//     $previous_unpaid_Data = DB::table('et_proposal_pay_slot')
//     ->select(
//         \DB::raw('NULL AS payment_id'),
//         'et_proposal_pay_slot.nextPayDate',
//         'et_proposal_pay_slot.initialPayDate',
//         'et_proposal_pay_slot.paid_status AS payment_status',
//         'et_proposal_pay_slot.payable_amount AS payment_amount',
//         'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
//         'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
//         'et_proposal_pay_slot.balance_amount',
//         'et_customer.sno as customer_sno',
//         'et_customer.customer_id',
//         'et_customer.cus_name',
//         'et_customer.cus_pic',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.cus_gender',
//         'et_proposal.service_title',
//         'et_proposal.gst_perc',
//         'et_proposal.currency_id',
//         'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol',
//         'et_proposal.sno as proposal_id',
//         'et_proposal_pay_slot.propo_pay_slot_id',
//         \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
//         \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
//         \DB::raw("'1' AS is_previous"), // Flag for previous unpaid data
        
//     )
//     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//     ->where('et_lead.created_by', '>', 1)
//     ->where('et_proposal.status', 0)
//     ->where('et_proposal_pay_slot.status', 0)
//     ->where('et_proposal_pay_slot.paid_status', 0)
//     ->whereNotIn('et_proposal.proposal_status', [0, 2])
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)
//     ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
//     ->where(function($query) use ($year, $month) {
//           $query->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
//                 ->orWhere(function($query2) use ($year, $month) {
//                     $query2->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year)
//                           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
//                 });
//       })
//     // ->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year) // Before the year 2025
//     // ->orWhere(function ($query) use ($month, $year,$firstIds) {
//     //     $query->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year) // Year = 2025
//     //           ->where('et_proposal_pay_slot.paid_status', 0)
//     //           ->where('et_proposal_pay_slot.status', 0)
//     //           ->whereNotIn('et_proposal.proposal_status', [0, 2])
//     //           ->where('et_lead.created_by', '>', 1)
//     //             ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
//     //           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month); // Before month 11 (October or earlier)
//     // })
//     ->groupBy(
//         'et_customer.sno', 'et_customer.customer_id', 'et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name',
//         'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 'et_customer.cus_gender',
//         'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
//         'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc', 'et_proposal_pay_slot.gst_amount',
//         'et_proposal_pay_slot.balance_amount', 'et_proposal.currency_id', 'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol'
//     );

  

//     $previousCount=count($previous_unpaid_Data->get());


   

   
//     // return $firstIds;
//     $HistoryPayment = DB::table('et_proposal_pay_slot')
//       ->leftJoin('et_payment', function ($join) {
//         $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//              ->where('et_payment.status', 0);  // Adding the status condition here
//     })
//       ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//       ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//       ->where('et_lead.created_by','>', 1)
//       ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//       ->where('et_proposal_pay_slot.branch_id', $branch_id)
//       ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
//       ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
//       ->whereNotIn('et_proposal.proposal_status', [0,2])
//       ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//       ->whereNotIn('et_customer.sno', $drop_ids)
//       ->select(
//           'et_payment.payment_id',
//           'et_proposal_pay_slot.nextPayDate',
//           'et_proposal_pay_slot.initialPayDate',
//           'et_proposal_pay_slot.paid_status AS payment_status',
//           'et_proposal_pay_slot.payable_amount AS payment_amount',
//           'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
//           'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
//           'et_proposal_pay_slot.balance_amount',
//           'et_customer.sno as customer_sno',
//           'et_customer.customer_id',
//           'et_customer.cus_name',
//           'et_customer.cus_pic',
//           'et_customer.cus_mobile',
//           'et_customer.cus_email_id',
//           'et_customer.cus_gender',
//           'et_proposal.service_title',
//           'et_proposal.gst_perc',
//           'et_proposal.currency_id',
//           'et_country_currencies.currency_code',
//           'et_country_currencies.currency_symbol',
//           'et_proposal.sno as proposal_id',
//           'et_proposal_pay_slot.propo_pay_slot_id',
//           \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
//           \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
//           \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
//           \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
//           \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
//           \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
//             \DB::raw("'0' AS is_previous")
//           )
//           // ->whereNotIn('et_customer.sno', $drop_ids)
//           ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
//                 'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
//                 'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
//                 'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount',  'et_proposal.gst_perc',
//                 'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
                
//           if (!empty($customer_fill)) {
//               $HistoryPayment->where(function ($query) use ($customer_fill) {
//                   $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
//                       ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
//                       ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
//               });
//           }
      
//           if (!empty($balance_payment)) {
//             $HistoryPayment
//           //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
//                           ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
//           }
//           // Assign paginated result
      
      
      
//           if($request->pending == 1){
//               $finalData=$previous_unpaid_Data->get();
//           }else{
//             $combinedData = $previous_unpaid_Data->unionAll($HistoryPayment);
//             $finalData = DB::table(DB::raw("({$combinedData->toSql()}) as combined"))
//               ->mergeBindings($combinedData)
//               ->orderBy('is_previous', 'desc')
//               ->orderBy('nextPayDate', 'asc')
//               ->get();
//           }
      
//     //   return $HistoryPayment;

     

//     $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
//       ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//       ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     //   ->whereNotIn('et_payment.payment_id', $drop_ids)
//       ->where('et_proposal_pay_slot.paid_status', 0)
//       ->whereNotIn('et_proposal.proposal_status', [0,2])
//       ->where('et_customer.status', 0)
//       ->whereNotIn('et_customer.sno', $drop_ids)
//       ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
//       ->orderBy('et_proposal_pay_slot.sno', 'asc')->count();

//     $branch = BranchModel::where('sno', $branch_id)
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')
//       ->first();

//     $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;


//     // total paid inr amount dashboard Previous start
    

//     // privious end
//     $TodayPayment = DB::table('et_proposal_pay_slot')->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')->where('et_proposal_pay_slot.branch_id', $branch_id)
//       ->where('et_proposal_pay_slot.paid_status', 0)->whereNotIn('et_proposal.proposal_status', [0,2])
//       ->whereDate('et_proposal_pay_slot.nextPayDate', $currentDate)->count();



//     // common mini dashboard
//       // Current Month
//     $outstandingAmountnew =DB::table('et_proposal_pay_slot')
//     ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->where('et_lead.created_by','>', 1)
//     ->where('et_customer.branch_id', $branch_id)
//     ->where('et_proposal_pay_slot.status', '!=',2) // not paid amount
//     ->where('et_customer.status', 0)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//     ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
//     ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)
//     ->whereNotIn('et_proposal.proposal_status', [0,2])
//     ->sum('et_proposal_pay_slot.payable_amount');
    
//     $outstandingAmountold=0;
    
 
//     // total paid inr amount dashboard
//      $totalPaidAmountInr = DB::table('et_proposal_pay_slot')
//     ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->where('et_lead.created_by','>', 1)
//     ->where('et_customer.branch_id', $branch_id)
//     ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
//     ->where('et_customer.status', 0)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->where('et_proposal.currency_id', 70)
//      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//     ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//     ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
//     ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
//     ->sum('et_proposal_pay_slot.paidAmount');
    
//      $gst_percent = $branch ? $branch->gst_percentage :18 ;
             
//      $base_amount_paidInr = $totalPaidAmountInr / (1 + ($gst_percent / 100));
    
//     $totalPaidAmountInr=$base_amount_paidInr;
    
//      // total paid non inr amount dashboard
//     $totalPaidAmountNonInr = DB::table('et_proposal_pay_slot')
//     ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//     ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->where('et_lead.created_by','>', 1)
//     ->where('et_customer.branch_id', $branch_id)
//     ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
//     ->where('et_customer.status', 0)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->whereNot('et_proposal.currency_id', 70)
//      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//     ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//     ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
//     ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
//     ->select('et_proposal_pay_slot.paidAmount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol')->get();
//     $totalConvertedPaidNonInr=0;
//     if(!empty($totalPaidAmountNonInr)){
//         foreach($totalPaidAmountNonInr as $nonInrData){
//              $currency_code = $nonInrData->currency_code;
//              $paidAmount = $nonInrData->paidAmount;
//              $totalConvertedPaidNonInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//         }
//     }
    
//     $base_amount_paidNonInr = $totalConvertedPaidNonInr >0 ? $totalConvertedPaidNonInr / (1 + ($gst_percent / 100)) : 0;
    
//     $totalConvertedPaidNonInr=$base_amount_paidNonInr;
    
//     $totalPaidAmount = $totalPaidAmountInr + $totalConvertedPaidNonInr;

//      $totalscheduleamountnew = DB::table('et_proposal_pay_slot')
//     ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->where('et_lead.created_by','>', 1)
//     // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//     ->where('et_customer.branch_id', $branch_id)
//     ->whereNotIn('et_proposal_pay_slot.status', [2])
//     ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//     ->where('et_customer.status', 0)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//     ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
//     ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
//     ->sum('et_proposal_pay_slot.payable_amount');
    
//     $base_amount_schedule = $totalscheduleamountnew / (1 + ($gst_percent / 100));
    
//     $totalscheduleamountnew=$base_amount_schedule;
    

//      $notpaidamountInr = DB::table('et_proposal_pay_slot')
//             ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//             ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->where('et_lead.created_by','>', 1)
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
//             ->where('et_customer.status', 0)
//             ->whereNotIn('et_customer.sno', $drop_ids)
//             ->where('et_proposal.currency_id', 70)
//             ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//             ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
//             ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
//              ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//             ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
//             ->sum('et_proposal_pay_slot.payable_amount');
            
//     $base_amount_notPaidInr = $notpaidamountInr / (1 + ($gst_percent / 100));

//     $notpaidamountInr=$base_amount_notPaidInr;
    
//      $notpaidamountNonInr = DB::table('et_proposal_pay_slot')
//             ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//             ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->where('et_lead.created_by','>', 1)
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
//             ->where('et_customer.status', 0)
//             ->whereNotIn('et_customer.sno', $drop_ids)
//             ->whereNot('et_proposal.currency_id', 70)
//             ->where('et_proposal_pay_slot.payable_amount','>', 0) 
//             ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
//             ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
//              ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//             ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
//             ->select('et_proposal_pay_slot.payable_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol')->get();
            
//             $ConvertNotpaidamountInr=0;
//             if(!empty($notpaidamountNonInr)){
//                 foreach($notpaidamountNonInr as $nonInrData){
//                      $currency_code = $nonInrData->currency_code;
//                      $paidAmount = $nonInrData->payable_amount;
//                      $ConvertNotpaidamountInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//                 }
//             }
            
//         $base_amount_notPaidNonInr = $ConvertNotpaidamountInr >0 ? $ConvertNotpaidamountInr / (1 + ($gst_percent / 100)) : 0;
    
//         $ConvertNotpaidamountInr=$base_amount_notPaidNonInr;
        
//         $notpaidamount=$notpaidamountInr + $ConvertNotpaidamountInr;
    
//     //  return $totalPaidAmountold;
    
//     // $totalscheduleamount = $totalscheduleamountnew + $totalscheduleamountold;
//     $totalscheduleamount = $notpaidamount + $totalPaidAmount;

//     $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
//     // Calculate Total Amount
//     $totalAmount = $notpaidamount + $totalPaidAmount;

   
    
//     // Calculate Outstanding Percentage (Handle division by zero)
//     $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;
    
    
//     $previous_unpaid_Data2 = DB::table('et_proposal_pay_slot')
//     ->select(
//         \DB::raw('NULL AS payment_id'),
//         'et_proposal_pay_slot.nextPayDate',
//         'et_proposal_pay_slot.initialPayDate',
//         'et_proposal_pay_slot.paid_status AS payment_status',
//         'et_proposal_pay_slot.payable_amount AS payment_amount',
//         'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
//         'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
//         'et_proposal_pay_slot.balance_amount',
//         'et_customer.sno as customer_sno',
//         'et_customer.customer_id',
//         'et_customer.cus_name',
//         'et_customer.cus_pic',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.cus_gender',
//         'et_proposal.service_title',
//         'et_proposal.gst_perc',
//         'et_proposal.currency_id',
//         'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol',
//         'et_proposal.sno as proposal_id',
//         'et_proposal_pay_slot.propo_pay_slot_id',
//         \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
//         \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
//         \DB::raw("'1' AS is_previous"), // Flag for previous unpaid data
        
//     )
//     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//     ->where('et_lead.created_by', '>', 1)
//     ->where('et_proposal.status', 0)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->where('et_proposal_pay_slot.status', 0)
//     ->where('et_proposal_pay_slot.paid_status', 0)
//     ->whereNotIn('et_proposal.proposal_status', [0, 2])
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)
//     ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
//     ->where(function($query) use ($year, $month) {
//           $query->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
//                 ->orWhere(function($query2) use ($year, $month) {
//                     $query2->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year)
//                           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
//                 });
//       })
//     // ->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year) // Before the year 2025
//     // ->orWhere(function ($query) use ($month, $year,$firstIds) {
//     //     $query->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year) // Year = 2025
//     //           ->where('et_proposal_pay_slot.paid_status', 0)
//     //           ->where('et_proposal_pay_slot.status', 0)
//     //           ->whereNotIn('et_proposal.proposal_status', [0, 2])
//     //           ->where('et_lead.created_by', '>', 1)
//     //             ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
//     //           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month); // Before month 11 (October or earlier)
//     // })
//     ->groupBy(
//         'et_customer.sno', 'et_customer.customer_id', 'et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name',
//         'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 'et_customer.cus_gender',
//         'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
//         'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc', 'et_proposal_pay_slot.gst_amount',
//         'et_proposal_pay_slot.balance_amount', 'et_proposal.currency_id', 'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol'
//     );

    
//     $HistoryPayment2 =  DB::table('et_proposal_pay_slot')
//     ->leftJoin('et_payment', function ($join) {
//         $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
//              ->where('et_payment.status', 0);  // Adding the status condition here
//     })
//     ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//     ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
//     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//     ->where('et_lead.created_by','>', 1)
//     ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//     ->where('et_proposal_pay_slot.branch_id', $branch_id)
//     ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
//     ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
//     ->whereNotIn('et_proposal.proposal_status', [0,2])
//     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
//     ->whereNotIn('et_customer.sno', $drop_ids)
//     ->select(
//         'et_payment.payment_id',
//         'et_proposal_pay_slot.nextPayDate',
//         'et_proposal_pay_slot.initialPayDate',
//         'et_proposal_pay_slot.paid_status AS payment_status',
//         'et_proposal_pay_slot.payable_amount AS payment_amount',
//         'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
//         'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
//         'et_proposal_pay_slot.balance_amount',
//         'et_customer.sno as customer_sno',
//         'et_customer.customer_id',
//         'et_customer.cus_name',
//         'et_customer.cus_pic',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.cus_gender',
//         'et_proposal.service_title',
//         'et_proposal.gst_perc',
//         'et_proposal.currency_id',
//         'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol',
//         'et_proposal.sno as proposal_id',
//         'et_proposal_pay_slot.propo_pay_slot_id',
//         \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
//         \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
//         \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt')
//         )
//         // ->whereNotIn('et_customer.sno', $drop_ids)
//         ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
//               'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
//               'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
//               'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc',
//               'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
              
//         if (!empty($customer_fill)) {
//               $HistoryPayment2->where(function ($query) use ($customer_fill) {
//                   $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
//                       ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
//                       ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
//               });
//         }
      
//         if (!empty($balance_payment)) {
//           $HistoryPayment2
//         //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
//                         ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
//         }
//       // Assign paginated result

//         if($request->pending == 1){
//               $finalData2=$previous_unpaid_Data->get();
//           }else{
//             $combinedData2 = $previous_unpaid_Data2->unionAll($HistoryPayment2);
//             $finalData2 = DB::table(DB::raw("({$combinedData->toSql()}) as combined"))
//               ->mergeBindings($combinedData2)
//               ->orderBy('is_previous', 'desc')
//               ->orderBy('nextPayDate', 'asc')
//               ->get();
//           }
//       // $HistoryPayment2 = $HistoryPayment2->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->get();
      
//     //   return count($HistoryPayment2);
//     $total_paid = 0;
//     $total_gst = 0;
//     foreach ($finalData2 as $i=> $pay){
//         if($pay->payment_status == 0){
//             $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
//             $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
//             $gstAmount = $pay->payment_amount - $baseAmount;
            
//             if ($pay->currency_id != 70) {
//                 $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
//                 $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
//             } else {
//                 $total_paid += $baseAmount;
//                 $total_gst  += $gstAmount;
//             }
//         }else{
//             $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
//             $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
//             $gstAmount = $pay->payment_paid_amt - $baseAmount;
            
//             if ($pay->currency_id != 70) {
//                 $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
//                 $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
//             } else {
//                 $total_paid += $baseAmount;
//                 $total_gst  += $gstAmount;
//             }
//         }
//     }
    
   
//     //  return $total_gst;
      
    
//     // return $outstandingAmount;
//     // Return the view with the data and total count
//     return view('content.payment_management.manage_payment.harvesting_sheet', [
//       'perpage' => $perpage,
//       'month_chk' =>$month_chk,
//       'HistoryPayment' => $finalData,
//       'previousCount' => $previousCount,
//       'outstandingAmount' => $outstandingAmount,
//       'outstandingPercentage' => $outstandingPercentage,
//       'totalPaidAmount' => $totalPaidAmount,
//       'totalscheduleamount' => $totalscheduleamount,
//       'sumPaidAmount' => $sumPaidAmount,
//       'TodayPaymentCount' => $TodayPayment,
//       'OutstandingPaymentCount' => $OutstandingPayment,
//       'cus_fill' => $customer_fill,
//       'total_paid' => $total_paid,
//       'total_gst' => $total_gst,
//       'gstPercentage' => $gstPercentage,
//       'month_filter' => $month_filter,
//     ])->with('filter_on', false);
//   }

    public function Index(Request $request, $month = null, $year = null ,$day = null)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id = $request->user()->user_id;

    
    $balance_payment = $request->get('balance_payment', $balance_payment ?? '');
    
    // $month_filter = 'Feb-2025';
    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
    $month = $parsedDate->month; // numeric month (1-12)
    $year = $parsedDate->year;
    $day = $request->input('day', $day ?? null); // optional
   $month_chk =0;
     $helper = new \App\Helpers\Helpers();
    // return $month;
     
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    // $drop_ids = DB::table('et_drop_refund')
    //   ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
    //   ->where('et_drop_refund.bh_status', 1)
    //   ->pluck('et_training.customer_id');
    
     $drop_ids = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno');
      
     $firstIds = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
        ->where('et_proposal.status', 0)
        ->where('et_proposal_pay_slot.status', 0)
        ->whereNotIn('et_proposal.proposal_status', [0, 2])
        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
        ->groupBy('et_proposal_pay_slot.proposal_sno')
        ->orderBy('first_id', 'asc')
        ->pluck('first_id');
    // paid amount
    $sumPaidAmount = DB::table('et_payment')
      ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
      ->where('et_proposal.status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
       ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
      ->sum('et_proposal_pay_slot.paidAmount');
    $customer_fill = $request->cus_fill ?? '';
    

    $previous_unpaid_Data = DB::table('et_proposal_pay_slot')
    ->select(
        \DB::raw('NULL AS payment_id'),
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
           \DB::raw('MAX(et_proposal.cre_id) AS pay_cre_id'),
        \DB::raw("'1' AS is_previous") // Flag for previous unpaid data
        
    )
    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->where('et_lead.created_by', '>', 1)
    ->where('et_proposal.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->where('et_proposal_pay_slot.status', 0)
    ->where('et_proposal_pay_slot.paid_status', 0)
    ->whereNotIn('et_proposal.proposal_status', [0, 2])
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
    // ->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year) // Before the year 2025
    // ->orWhere(function ($query) use ($month, $year,$firstIds) {
    //     $query->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year) // Year = 2025
    //           ->where('et_proposal_pay_slot.paid_status', 0)
    //           ->where('et_proposal_pay_slot.status', 0)
    //            ->whereNotIn('et_proposal.proposal_status', [0, 2])
    //            ->where('et_lead.created_by', '>', 1)
    //             ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
    //           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month); // Before month 11 (October or earlier)
    // })
    ->where(function($query) use ($year, $month) {
          $query->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
                ->orWhere(function($query2) use ($year, $month) {
                    $query2->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year)
                          ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
                });
      })
    ->groupBy(
        'et_customer.sno', 'et_customer.customer_id', 'et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name',
        'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 'et_customer.cus_gender',
        'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
        'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc', 'et_proposal_pay_slot.gst_amount',
        'et_proposal_pay_slot.balance_amount', 'et_proposal.currency_id', 'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol'
    );

      if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
        $previous_unpaid_Data->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }

      if (!empty($customer_fill)) {
          $previous_unpaid_Data->where(function ($query) use ($customer_fill) {
              $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
          });
      }
  

    $previousCount=count($previous_unpaid_Data->get());




   
    // return $firstIds;
    $HistoryPayment = DB::table('et_proposal_pay_slot')
      ->leftJoin('et_payment', function ($join) {
        $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
             ->where('et_payment.status', 0);  // Adding the status condition here
    })
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by','>', 1)
      ->whereNotIn('et_customer.sno', $drop_ids)
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
      ->select(
          'et_payment.payment_id',
          'et_proposal_pay_slot.nextPayDate',
          'et_proposal_pay_slot.initialPayDate',
          'et_proposal_pay_slot.paid_status AS payment_status',
          'et_proposal_pay_slot.payable_amount AS payment_amount',
          'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
          'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
          'et_proposal_pay_slot.balance_amount',
          'et_customer.sno as customer_sno',
          'et_customer.customer_id',
          'et_customer.cus_name',
          'et_customer.cus_pic',
          'et_customer.cus_mobile',
          'et_customer.cus_email_id',
          'et_customer.cus_gender',
          'et_proposal.service_title',
          'et_proposal.gst_perc',
          'et_proposal.currency_id',
          'et_country_currencies.currency_code',
          'et_country_currencies.currency_symbol',
          'et_proposal.sno as proposal_id',
          'et_proposal_pay_slot.propo_pay_slot_id',
          \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
          \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
          \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
          \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
          \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
          \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
          \DB::raw('MAX(et_proposal.cre_id) AS pay_cre_id'),
            \DB::raw("'0' AS is_previous")
          )
          // ->whereNotIn('et_customer.sno', $drop_ids)
          ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
                'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
                'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
                'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount',  'et_proposal.gst_perc',
                'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
                
          if (!empty($customer_fill)) {
              $HistoryPayment->where(function ($query) use ($customer_fill) {
                  $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
          }
      
          if (!empty($balance_payment)) {
            $HistoryPayment
          //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
                          ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
          }
          // Assign paginated result
      
      
      
          if($request->pending == 1){
              $finalData=$previous_unpaid_Data->get();
          }else{
            $combinedData = $previous_unpaid_Data->unionAll($HistoryPayment);
            $queryfinal = DB::query()->fromSub($combinedData, 'combined');
        
            if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
                $queryfinal->where('pay_cre_id', $user_id);
            } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
                abort(403, 'Unauthorized');
            }
            $finalData = $queryfinal
              ->orderBy('is_previous', 'desc')
              ->orderBy('nextPayDate', 'asc')
              ->get();
              // return $finalData;
          }
      
    //   return $HistoryPayment;

     

    $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    //   ->whereNotIn('et_payment.payment_id', $drop_ids)
      ->where('et_proposal_pay_slot.paid_status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
      ->where('et_customer.status', 0)
      ->whereNotIn('et_customer.sno', $drop_ids)
      ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
      ->orderBy('et_proposal_pay_slot.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;


    // total paid inr amount dashboard Previous start
    

    // privious end
    $TodayPayment = DB::table('et_proposal_pay_slot')->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 0)->whereNotIn('et_proposal.proposal_status', [0,2])
      ->whereDate('et_proposal_pay_slot.nextPayDate', $currentDate)->count();



    // common mini dashboard
       // Current Month
    $outstandingAmountnew =DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.status', '!=',2) // not paid amount
    ->where('et_customer.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereNotIn('et_proposal.proposal_status', [0,2]);
    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
          $outstandingAmountnew->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }
    $outstandingAmountnew=$outstandingAmountnew->sum('et_proposal_pay_slot.payable_amount');
    
    $outstandingAmountold=0;
    
 
    // total paid inr amount dashboard
     $totalPaidAmountInr = DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
    ->where('et_customer.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->where('et_proposal.currency_id', 70)
     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2]);
    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
          $totalPaidAmountInr->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }
    $totalPaidAmountInr=$totalPaidAmountInr->sum('et_proposal_pay_slot.paidAmount');
    
     $gst_percent = $branch ? $branch->gst_percentage :18 ;
             
     $base_amount_paidInr = $totalPaidAmountInr / (1 + ($gst_percent / 100));
    
    $totalPaidAmountInr=$base_amount_paidInr;
    
     // total paid non inr amount dashboard
    $totalPaidAmountNonInr = DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
    ->where('et_customer.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->whereNot('et_proposal.currency_id', 70)
     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
    ->select('et_proposal_pay_slot.paidAmount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
          $totalPaidAmountNonInr->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }
    $totalPaidAmountNonInr=$totalPaidAmountNonInr->get();
    $totalConvertedPaidNonInr=0;
    if(!empty($totalPaidAmountNonInr)){
        foreach($totalPaidAmountNonInr as $nonInrData){
             $currency_code = $nonInrData->currency_code;
             $paidAmount = $nonInrData->paidAmount;
             $totalConvertedPaidNonInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
        }
    }
    
    $base_amount_paidNonInr = $totalConvertedPaidNonInr >0 ? $totalConvertedPaidNonInr / (1 + ($gst_percent / 100)) : 0;
    
    $totalConvertedPaidNonInr=$base_amount_paidNonInr;
    
    $totalPaidAmount = $totalPaidAmountInr + $totalConvertedPaidNonInr;

     $totalscheduleamountnew = DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->where('et_customer.branch_id', $branch_id)
    ->whereNotIn('et_proposal_pay_slot.status', [2])
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->where('et_customer.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2]);
    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
          $totalscheduleamountnew->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }
    $totalscheduleamountnew=$totalscheduleamountnew->sum('et_proposal_pay_slot.payable_amount');
    
    $base_amount_schedule = $totalscheduleamountnew / (1 + ($gst_percent / 100));
    
    $totalscheduleamountnew=$base_amount_schedule;
    

     $notpaidamountInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
            ->where('et_customer.status', 0)
            ->whereNotIn('et_customer.sno', $drop_ids)
            ->where('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.payable_amount','>', 0) 
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
             ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2]);
              if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
                 $notpaidamountInr->where('et_proposal.cre_id', $user_id);
              } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
                  abort(403, 'Unauthorized');
              }
            $notpaidamountInr=$notpaidamountInr->sum('et_proposal_pay_slot.payable_amount');
            
    $base_amount_notPaidInr = $notpaidamountInr / (1 + ($gst_percent / 100));

    $notpaidamountInr=$base_amount_notPaidInr;
    
     $notpaidamountNonInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
             ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
            ->where('et_customer.status', 0)
            ->whereNotIn('et_customer.sno', $drop_ids)
            ->whereNot('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.payable_amount','>', 0) 
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
             ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
            ->select('et_proposal_pay_slot.payable_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
            if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
                 $notpaidamountNonInr->where('et_proposal.cre_id', $user_id);
              } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
                  abort(403, 'Unauthorized');
              }
            $notpaidamountNonInr=$notpaidamountNonInr->get();
            
            $ConvertNotpaidamountInr=0;
            if(!empty($notpaidamountNonInr)){
                foreach($notpaidamountNonInr as $nonInrData){
                     $currency_code = $nonInrData->currency_code;
                     $paidAmount = $nonInrData->payable_amount;
                     $ConvertNotpaidamountInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                }
            }
            
        $base_amount_notPaidNonInr = $ConvertNotpaidamountInr >0 ? $ConvertNotpaidamountInr / (1 + ($gst_percent / 100)) : 0;
    
        $ConvertNotpaidamountInr=$base_amount_notPaidNonInr;
        
        $notpaidamount=$notpaidamountInr + $ConvertNotpaidamountInr;
    
    //  return $totalPaidAmountold;
    
    // $totalscheduleamount = $totalscheduleamountnew + $totalscheduleamountold;
    $totalscheduleamount = $notpaidamount + $totalPaidAmount;

    $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
    // Calculate Total Amount
    $totalAmount = $notpaidamount + $totalPaidAmount;

   
    
    // Calculate Outstanding Percentage (Handle division by zero)
    $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;
    
    
    $previous_unpaid_Data2 = DB::table('et_proposal_pay_slot')
    ->select(
        \DB::raw('NULL AS payment_id'),
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
           \DB::raw('MAX(et_proposal.cre_id) AS pay_cre_id'),
        \DB::raw("'1' AS is_previous"), // Flag for previous unpaid data
        
    )
    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->where('et_lead.created_by', '>', 1)
    ->where('et_proposal.status', 0)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->where('et_proposal_pay_slot.status', 0)
    ->where('et_proposal_pay_slot.paid_status', 0)
    ->whereNotIn('et_proposal.proposal_status', [0, 2])
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
    // ->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year) // Before the year 2025
    // ->orWhere(function ($query) use ($month, $year,$firstIds) {
    //     $query->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year) // Year = 2025
    //           ->where('et_proposal_pay_slot.paid_status', 0)
    //           ->where('et_proposal_pay_slot.status', 0)
    //            ->whereNotIn('et_proposal.proposal_status', [0, 2])
    //            ->where('et_lead.created_by', '>', 1)
    //             ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
    //           ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month); // Before month 11 (October or earlier)
    // })
     ->where(function($query) use ($year, $month) {
          $query->whereYear('et_proposal_pay_slot.nextPayDate', '<', $year)
                ->orWhere(function($query2) use ($year, $month) {
                    $query2->whereYear('et_proposal_pay_slot.nextPayDate', '=', $year)
                          ->whereMonth('et_proposal_pay_slot.nextPayDate', '<', $month);
                });
      })
    ->groupBy(
        'et_customer.sno', 'et_customer.customer_id', 'et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name',
        'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 'et_customer.cus_gender',
        'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
        'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc', 'et_proposal_pay_slot.gst_amount',
        'et_proposal_pay_slot.balance_amount', 'et_proposal.currency_id', 'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol'
    );

    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
        $previous_unpaid_Data2->where('et_proposal.cre_id', $user_id);
      } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
          abort(403, 'Unauthorized');
      }

    
    $HistoryPayment2 =  DB::table('et_proposal_pay_slot')
    ->leftJoin('et_payment', function ($join) {
        $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
             ->where('et_payment.status', 0);  // Adding the status condition here
    })
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereNotIn('et_customer.sno', $drop_ids)
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->whereNotIn('et_proposal.proposal_status', [0,2])
    ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->select(
        'et_payment.payment_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
        \DB::raw('MAX(et_proposal.cre_id) AS pay_cre_id'),
         \DB::raw("'0' AS is_previous"), 
        )
        // ->whereNotIn('et_customer.sno', $drop_ids)
        ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
              'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
              'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
              'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc',
              'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount','et_proposal.currency_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol');
              
        if (!empty($customer_fill)) {
              $HistoryPayment2->where(function ($query) use ($customer_fill) {
                  $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment2
        //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
                        ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
        }
      // Assign paginated result

        if($request->pending == 1){
              $finalData2=$previous_unpaid_Data2->get();
          }else{
            $combinedData2 = $previous_unpaid_Data2->unionAll($HistoryPayment2);
            $queryfinal2 = DB::query()->fromSub($combinedData2, 'combined');
        
            if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
                $queryfinal2->where('pay_cre_id', $user_id);
            } elseif (!auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
                abort(403, 'Unauthorized');
            }
            $finalData2 = $queryfinal2
              ->orderBy('is_previous', 'desc')
              ->orderBy('nextPayDate', 'asc')
              ->get();
      
          }
      // $HistoryPayment2 = $HistoryPayment2->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->get();
      
    //   return count($HistoryPayment2);
    $total_paid = 0;
    $total_gst = 0;
    foreach ($finalData2 as $i=> $pay){
        if($pay->payment_status == 0){
            $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
            $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
            $gstAmount = $pay->payment_amount - $baseAmount;
            
            if ($pay->currency_id != 70) {
                $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
                $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
            } else {
                $total_paid += $baseAmount;
                $total_gst  += $gstAmount;
            }
        }else{
            $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
            $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
            $gstAmount = $pay->payment_paid_amt - $baseAmount;
            
            if ($pay->currency_id != 70) {
                $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
                $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
            } else {
                $total_paid += $baseAmount;
                $total_gst  += $gstAmount;
            }
        }
    }
    
   
    //  return $total_gst;
      
    
    // return $outstandingAmount;
    // Return the view with the data and total count
    return view('content.payment_management.manage_payment.harvesting_sheet', [
      'perpage' => $perpage,
      'month_chk' =>$month_chk,
      'HistoryPayment' => $finalData,
      'previousCount' => $previousCount,
      'outstandingAmount' => $outstandingAmount,
      'outstandingPercentage' => $outstandingPercentage,
      'totalPaidAmount' => $totalPaidAmount,
      'totalscheduleamount' => $totalscheduleamount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'cus_fill' => $customer_fill,
      'total_paid' => $total_paid,
      'total_gst' => $total_gst,
      'gstPercentage' => $gstPercentage,
      'month_filter' => $month_filter,
    ])->with('filter_on', false);
  }
  
  
 public function IndexOld(Request $request, $month = null, $year = null ,$day = null)
  {
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    
    $balance_payment = $request->get('balance_payment', $balance_payment ?? '');
    
    // $month_filter = 'Feb-2025';
    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
    $month = $parsedDate->month; // numeric month (1-12)
    $year = $parsedDate->year;
    $day = $request->input('day', $day ?? null); // optional
   $month_chk =0;
    
    // return $month;
     
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    // $drop_ids = DB::table('et_drop_refund')
    //   ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
    //   ->where('et_drop_refund.bh_status', 1)
    //   ->pluck('et_training.customer_id');
    
     $firstIds = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
        ->where('et_proposal.status', 0)
        ->where('et_proposal_pay_slot.status', 0)
        ->whereNotIn('et_proposal.proposal_status', [0, 2])
        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
        ->groupBy('et_proposal_pay_slot.proposal_sno')
        ->orderBy('first_id', 'asc')
        ->pluck('first_id');
    // paid amount
    $sumPaidAmount = DB::table('et_payment')
      ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
      ->where('et_proposal.status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
       ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
      ->sum('et_proposal_pay_slot.paidAmount');
    $customer_fill = $request->cus_fill ?? '';
    
   
// return $firstIds;
   $HistoryPayment = DB::table('et_proposal_pay_slot')
    ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->whereNotIn('et_proposal.proposal_status', [0,2])
    ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->select(
        'et_payment.payment_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt')
        )
        // ->whereNotIn('et_customer.sno', $drop_ids)
        ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
              'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
              'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
              'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount',  'et_proposal.gst_perc',
              'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount');
              
              
      if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
            // User can only view their own data
            $HistoryPayment = $HistoryPayment->where('et_proposal.cre_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
            // User can view all data
            $HistoryPayment = $HistoryPayment;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
              
        if (!empty($customer_fill)) {
              $HistoryPayment->where(function ($query) use ($customer_fill) {
                  $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment
        //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
                        ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
        }
      // Assign paginated result
      $HistoryPayment = $HistoryPayment->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->paginate($perpage);
      
    //   return $HistoryPayment;

     

    $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    //   ->whereNotIn('et_payment.payment_id', $drop_ids)
      ->where('et_proposal_pay_slot.paid_status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
      ->where('et_customer.status', 0)
      ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
      ->orderBy('et_proposal_pay_slot.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = DB::table('et_proposal_pay_slot')->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 0)->whereNotIn('et_proposal.proposal_status', [0,2])
      ->whereDate('et_proposal_pay_slot.nextPayDate', $currentDate)->count();



    // common mini dashboard
       // Current Month
    $outstandingAmountnew =DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.status', '!=',2) // not paid amount
    ->where('et_customer.status', 0)
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereNotIn('et_proposal.proposal_status', [0,2])
    ->sum('et_proposal_pay_slot.payable_amount');
    
    $outstandingAmountold=0;
    
    //  $outstandingAmountold = DB::table('et_old_payments')
    // ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
    // ->where('et_old_customer.branch_id', $branch_id)
    // ->where('et_old_payments.status', '!=',2) // not paid amount
    // ->where('et_old_customer.status', 0)
    // ->where('et_old_payments.amount','>', 0) 
    // ->whereYear('et_old_payments.schedule_date', $year)
    // ->whereMonth('et_old_payments.schedule_date', $month)
    // ->where('et_old_payments.branch_id', $branch_id)
    // ->sum('et_old_payments.amount');
    
     $totalPaidAmountnew = DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
    ->where('et_customer.status', 0)
     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2])
    ->sum('et_proposal_pay_slot.paidAmount');
    
     $gst_percent = $branch ? $branch->gst_percentage :18 ;
             
     $base_amount_paid = $totalPaidAmountnew / (1 + ($gst_percent / 100));
    
    $totalPaidAmountnew=$base_amount_paid;
    
    $totalPaidAmountold=0;
    // $totalPaidAmountold = DB::table('et_old_payments')
    // ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
    // ->where('et_old_customer.branch_id', $branch_id)
    // ->where('et_old_payments.status', '!=',2) // paid amount
    // ->whereIn('et_old_customer.status', [1,4])
    // ->where('et_old_payments.amount','>', 0) 
    // ->whereYear('et_old_payments.created_at', $year)
    // ->whereMonth('et_old_payments.created_at', $month)
    // ->where('et_old_payments.branch_id', $branch_id)
    // ->sum('et_old_payments.paidAmount');
    
     $totalscheduleamountnew = DB::table('et_proposal_pay_slot')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->where('et_customer.branch_id', $branch_id)
    ->whereNotIn('et_proposal_pay_slot.status', [2])
    ->where('et_proposal_pay_slot.payable_amount','>', 0) 
    ->where('et_customer.status', 0)
     ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2]);
    if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
            // User can only view their own data
            $totalscheduleamountnew = $totalscheduleamountnew->where('et_proposal.cre_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
            // User can view all data
            $totalscheduleamountnew = $totalscheduleamountnew;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
    $totalscheduleamountnew=$totalscheduleamountnew->sum('et_proposal_pay_slot.payable_amount');
    
    $base_amount_schedule = $totalscheduleamountnew / (1 + ($gst_percent / 100));
    
    $totalscheduleamountnew=$base_amount_schedule;
    
    $totalscheduleamountold=0;
    // $totalscheduleamountold=0; = DB::table('et_old_payments')
    // ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
    // ->where('et_old_customer.branch_id', $branch_id)
    // ->whereNotIn('et_old_payments.status', [1, 2])
    // ->where('et_old_customer.status', 0)
    // ->where('et_old_payments.amount','>', 0) 
    // ->whereYear('et_old_payments.schedule_date', $year)
    // ->whereMonth('et_old_payments.schedule_date', $month)
    // ->where('et_old_payments.branch_id', $branch_id)
    // ->sum('et_old_payments.amount');
    
     $notpaidamount = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
            ->where('et_customer.status', 0)
            ->where('et_proposal_pay_slot.payable_amount','>', 0) 
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
             ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0,2]);
            if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
                // User can only view their own data
                $notpaidamount = $notpaidamount->where('et_proposal.cre_id', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
                // User can view all data
                $notpaidamount = $notpaidamount;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
            $notpaidamount=$notpaidamount->sum('et_proposal_pay_slot.payable_amount');
            
    $base_amount_notPaid = $notpaidamount / (1 + ($gst_percent / 100));

    $notpaidamount=$base_amount_notPaid;
    
    //  return $totalPaidAmountold;
    $totalPaidAmount = $totalPaidAmountnew + $totalPaidAmountold;
    // $totalscheduleamount = $totalscheduleamountnew + $totalscheduleamountold;
    $totalscheduleamount = $notpaidamount + $totalPaidAmount;
    $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
    // Calculate Total Amount
    $totalAmount = $notpaidamount + $totalPaidAmount;
    
    // Calculate Outstanding Percentage (Handle division by zero)
    $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;
    
    
    
    
    $HistoryPayment2 =  DB::table('et_proposal_pay_slot')
    ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->where('et_lead.created_by','>', 1)
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
    ->whereNotIn('et_proposal.proposal_status', [0,2])
    ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    ->select(
        'et_payment.payment_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt')
        )
        // ->whereNotIn('et_customer.sno', $drop_ids)
        ->groupBy('et_payment.payment_id', 'et_customer.sno', 'et_customer.customer_id','et_proposal_pay_slot.initialPayDate', 'et_customer.cus_name', 
              'et_customer.cus_pic', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 
              'et_customer.cus_gender', 'et_proposal.service_title', 'et_proposal.sno', 'et_proposal_pay_slot.propo_pay_slot_id',
              'et_proposal_pay_slot.nextPayDate', 'et_proposal_pay_slot.paid_status', 'et_proposal_pay_slot.payable_amount', 'et_proposal_pay_slot.paidAmount', 'et_proposal.gst_perc',
              'et_proposal_pay_slot.gst_amount', 'et_proposal_pay_slot.balance_amount');
              
        if (!empty($customer_fill)) {
              $HistoryPayment2->where(function ($query) use ($customer_fill) {
                  $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
        
        if (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'view_self_lead')) {
            // User can only view their own data
            $HistoryPayment2 = $HistoryPayment2->where('et_proposal.cre_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Payment Management', 'Manage Harvesting', 'global_lead')) {
            // User can view all data
            $HistoryPayment2 = $HistoryPayment2;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment2
        //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
                        ->where('et_proposal_pay_slot.paid_status',0)->where('et_proposal_pay_slot.payable_amount','>', 0) ;
        }
      // Assign paginated result
      $HistoryPayment2 = $HistoryPayment2->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->get();
      
    //   return count($HistoryPayment2);
    $total_paid = 0;
    $total_gst = 0;
    foreach ($HistoryPayment2 as $i=> $pay){
        if($pay->payment_status == 0){
            $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
            $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
            $gstAmount = $pay->payment_amount - $baseAmount;
            
            $total_paid += $baseAmount;
              
            $total_gst += $gstAmount;
        }else{
            $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
            $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
            $gstAmount = $pay->payment_paid_amt - $baseAmount;
            
            $total_paid += $baseAmount;
            $total_gst += $gstAmount;
        }
    }
    
   
    //  return $total_gst;
      
    
    // return $outstandingAmount;
    // Return the view with the data and total count
    return view('content.payment_management.manage_payment.harvesting_sheet', [
      'perpage' => $perpage,
      'month_chk' =>$month_chk,
      'HistoryPayment' => $HistoryPayment,
      'outstandingAmount' => $outstandingAmount,
      'outstandingPercentage' => $outstandingPercentage,
      'totalPaidAmount' => $totalPaidAmount,
      'totalscheduleamount' => $totalscheduleamount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'cus_fill' => $customer_fill,
      'total_paid' => $total_paid,
      'total_gst' => $total_gst,
      'gstPercentage' => $gstPercentage,
      'month_filter' => $month_filter,
    ])->with('filter_on', false);
  }


  public function PaymentRemainder_OLD(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
  
      // Get the selected filter date
      $payRemFill = $request->input('pay_rem_fill', 'today');
      $currentDate = now()->toDateString(); // Get today's date in 'YYYY-MM-DD' format
  
      // Handle the filter date
      switch ($payRemFill) {
          case 'next_day':
              $filterDate = now()->addDay()->toDateString();
              break;
          case '3rd_day':
              $filterDate = now()->addDays(2)->toDateString();
              break;
          case '4th_day':
              $filterDate = now()->addDays(3)->toDateString();
              break;
          case '5th_day':
              $filterDate = now()->addDays(4)->toDateString();
              break;
          case '6th_day':
              $filterDate = now()->addDays(5)->toDateString();
              break;
          case '7th_day':
              $filterDate = now()->addDays(6)->toDateString();
              break;
          default:
              $filterDate = $currentDate;
      }
  
      // Fetch the History Payment data based on the filtered date
      $HistoryPayment = PaymentModel::join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->join('et_training', 'et_training.payment_id', '=', 'et_payment.payment_id')
          ->join('et_course', 'et_payment.course_id', '=', 'et_course.sno')
          ->where('et_payment.branch_id', $branch_id)
          ->whereDate('et_payment.nextPayDate', $filterDate)  // Filter by the calculated date
          ->select(
              'et_customer.sno as customer_sno',
              'et_customer.customer_id',
              'et_customer.cus_name',
              'et_customer.cus_pic',
              'et_customer.cus_mobile',
              'et_customer.cus_email_id',
              'et_customer.doj',
              'et_customer.cus_gender',
              'et_course.course_name',
              'et_course.sno as course_sno',
              'et_training.training_id',
              'et_training.overall_fees',
              'et_training.gst_amount AS overall_gst_fees',
              'et_training.paid_amount AS tot_pay_amt',        
              'et_training.paid_gst AS tot_pay_gst_amt',
              'et_training.balance_amount AS tot_bal_amt',
              'et_training.balance_gst AS tot_bal_gst_amt',
              'et_payment.balanceFee',
              'et_payment.payment_id',
              'et_payment.nextPayDate',
              'et_payment.initialPayDate',
              'et_payment.status AS payment_status',
              'et_payment.amount AS payment_amount',
              'et_payment.paidAmount AS payment_paid_amt',
              'et_payment.gst_amount AS payment_gst_amount'
          )
          ->orderBy('et_payment.nextPayDate', 'ASC')
          ->paginate($perpage);
  
      // Calculate the total paid amount
      $sumPaidAmount = DB::table('et_payment')
          ->where('et_payment.status', 1)
          ->sum('et_payment.paidAmount');
  
     
  
      // Count outstanding payments
      $OutstandingPayment = PaymentModel::where('et_payment.branch_id', $branch_id)
          ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->where('et_payment.status', 0)
          ->where('et_customer.status', 0)
          ->whereDate('et_payment.nextPayDate', '<=', $currentDate)
          ->orderBy('et_payment.sno', 'asc')->count();
  
      // Fetch the branch details
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
  
      // Get the GST percentage from the branch
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
  
      // Count today's payments
      $TodayPayment = PaymentModel::where('et_payment.branch_id', $branch_id)
          ->where('et_payment.status', 0)
          ->whereDate('et_payment.nextPayDate', $currentDate)->count();
  
      // Calculate the total outstanding amount for the current month
      $outstandingAmount = DB::table('et_payment')
          ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
          ->join('et_course', 'et_payment.course_id', '=', 'et_course.sno')
          ->where('et_payment.status', 0)
          ->where('et_customer.status', 0)
          ->where('et_payment.branch_id', $branch_id)
          ->whereDate('et_payment.nextPayDate', '<=', $currentDate)
          ->sum('et_payment.amount');
  
      // Return the view with the updated data
      return view('content.payment.payment_remainder', [
          'perpage' => $perpage,
          'HistoryPayment' => $HistoryPayment,
          'sumPaidAmount' => $sumPaidAmount,
          'OutstandingPaymentCount' => $OutstandingPayment,
          'TodayPaymentCount' => $TodayPayment,
          'gstPercentage' => $gstPercentage,
          'filterDate' => $filterDate,  // Pass the filter date to the view if needed
      ])->with('filter_on', false);
  }  
  
   public function PaymentRemainder(Request $request, $month = null, $year = null, $day = null)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;


    $balance_payment = $request->get('balance_payment', $balance_payment ?? '');

    // $month_filter = 'Feb-2025';
    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
    $month = $parsedDate->month; // numeric month (1-12)
    $year = $parsedDate->year;
    $day = $request->input('day', $day ?? null); // optional
    $month_chk = 0;
    $helper = new \App\Helpers\Helpers();

    $payRemFill = $request->input('pay_rem_fill', 'today');
    $currentDate = now()->toDateString(); // Get today's date in 'YYYY-MM-DD' format

    // Handle the filter date
    switch ($payRemFill) {
      case 'next_day':
        $filterDate = now()->addDay()->toDateString();
        break;
      case '3rd_day':
        $filterDate = now()->addDays(2)->toDateString();
        break;
      case '4th_day':
        $filterDate = now()->addDays(3)->toDateString();
        break;
      case '5th_day':
        $filterDate = now()->addDays(4)->toDateString();
        break;
      case '6th_day':
        $filterDate = now()->addDays(5)->toDateString();
        break;
      case '7th_day':
        $filterDate = now()->addDays(6)->toDateString();
        break;
      default:
        $filterDate = $currentDate;
    }
    // return $month;

    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    // $drop_ids = DB::table('et_drop_refund')
    //   ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
    //   ->where('et_drop_refund.bh_status', 1)
    //   ->pluck('et_training.customer_id');

    $firstIds = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
      ->where('et_proposal.status', 0)
      ->where('et_proposal_pay_slot.status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
      ->groupBy('et_proposal_pay_slot.proposal_sno')
      ->orderBy('first_id', 'asc')
      ->pluck('first_id');
    // paid amount
    $sumPaidAmount = DB::table('et_payment')
      ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
      ->where('et_proposal.status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->sum('et_proposal_pay_slot.paidAmount');
    $customer_fill = $request->cus_fill ?? '';


    // return $firstIds;
    $HistoryPayment = DB::table('et_proposal_pay_slot')
      ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->whereDate('et_proposal_pay_slot.initialPayDate', $filterDate)
      ->select(
        'et_payment.payment_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt')
      )
      // ->whereNotIn('et_customer.sno', $drop_ids)
      ->groupBy(
        'et_payment.payment_id',
        'et_customer.sno',
        'et_customer.customer_id',
        'et_proposal_pay_slot.initialPayDate',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.sno',
        'et_proposal_pay_slot.propo_pay_slot_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.paid_status',
        'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount',
        'et_proposal.gst_perc',
        'et_proposal_pay_slot.gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol'
      );

    if (!empty($customer_fill)) {
      $HistoryPayment->where(function ($query) use ($customer_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
      });
    }

    if (!empty($balance_payment)) {
      $HistoryPayment
        //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
        ->where('et_proposal_pay_slot.paid_status', 0)->where('et_proposal_pay_slot.payable_amount', '>', 0);
    }
    // Assign paginated result
    $HistoryPayment = $HistoryPayment->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->paginate($perpage);

    //   return $HistoryPayment;



    $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      //   ->whereNotIn('et_payment.payment_id', $drop_ids)
      ->where('et_proposal_pay_slot.paid_status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->where('et_customer.status', 0)
      ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
      ->orderBy('et_proposal_pay_slot.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = DB::table('et_proposal_pay_slot')->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 0)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->whereDate('et_proposal_pay_slot.nextPayDate', $currentDate)->count();



    // common mini dashboard
    // Current Month
    $outstandingAmountnew = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->where('et_customer.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.status', '!=', 2) // not paid amount
      ->where('et_customer.status', 0)
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->sum('et_proposal_pay_slot.payable_amount');

    $outstandingAmountold = 0;


    // total paid inr amount dashboard
    $totalPaidAmountInr = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->where('et_customer.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
      ->where('et_customer.status', 0)
      ->where('et_proposal.currency_id', 70)
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->sum('et_proposal_pay_slot.paidAmount');

    $gst_percent = $branch ? $branch->gst_percentage : 18;

    $base_amount_paidInr = $totalPaidAmountInr / (1 + ($gst_percent / 100));

    $totalPaidAmountInr = $base_amount_paidInr;

    // total paid non inr amount dashboard
    $totalPaidAmountNonInr = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->where('et_customer.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 1) // paid amount
      ->where('et_customer.status', 0)
      ->whereNot('et_proposal.currency_id', 70)
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->select('et_proposal_pay_slot.paidAmount', 'et_proposal.currency_id', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')->get();
    $totalConvertedPaidNonInr = 0;
    if (!empty($totalPaidAmountNonInr)) {
      foreach ($totalPaidAmountNonInr as $nonInrData) {
        $currency_code = $nonInrData->currency_code;
        $paidAmount = $nonInrData->paidAmount;
        $totalConvertedPaidNonInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
      }
    }

    $base_amount_paidNonInr = $totalConvertedPaidNonInr > 0 ? $totalConvertedPaidNonInr / (1 + ($gst_percent / 100)) : 0;

    $totalConvertedPaidNonInr = $base_amount_paidNonInr;

    $totalPaidAmount = $totalPaidAmountInr + $totalConvertedPaidNonInr;

    $totalscheduleamountnew = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
      ->where('et_customer.branch_id', $branch_id)
      ->whereNotIn('et_proposal_pay_slot.status', [2])
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->where('et_customer.status', 0)
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->sum('et_proposal_pay_slot.payable_amount');

    $base_amount_schedule = $totalscheduleamountnew / (1 + ($gst_percent / 100));

    $totalscheduleamountnew = $base_amount_schedule;


    $notpaidamountInr = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->where('et_customer.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
      ->where('et_customer.status', 0)
      ->where('et_proposal.currency_id', 70)
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->sum('et_proposal_pay_slot.payable_amount');

    $base_amount_notPaidInr = $notpaidamountInr / (1 + ($gst_percent / 100));

    $notpaidamountInr = $base_amount_notPaidInr;

    $notpaidamountNonInr = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->where('et_customer.branch_id', $branch_id)
      ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
      ->where('et_customer.status', 0)
      ->whereNot('et_proposal.currency_id', 70)
      ->where('et_proposal_pay_slot.payable_amount', '>', 0)
      ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->where('et_proposal_pay_slot.branch_id', $branch_id)->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->select('et_proposal_pay_slot.payable_amount', 'et_proposal.currency_id', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')->get();

    $ConvertNotpaidamountInr = 0;
    if (!empty($notpaidamountNonInr)) {
      foreach ($notpaidamountNonInr as $nonInrData) {
        $currency_code = $nonInrData->currency_code;
        $paidAmount = $nonInrData->payable_amount;
        $ConvertNotpaidamountInr += $helper->ConvertedAmountInr($currency_code, $paidAmount);
      }
    }

    $base_amount_notPaidNonInr = $ConvertNotpaidamountInr > 0 ? $ConvertNotpaidamountInr / (1 + ($gst_percent / 100)) : 0;

    $ConvertNotpaidamountInr = $base_amount_notPaidNonInr;

    $notpaidamount = $notpaidamountInr + $ConvertNotpaidamountInr;

    //  return $totalPaidAmountold;

    // $totalscheduleamount = $totalscheduleamountnew + $totalscheduleamountold;
    $totalscheduleamount = $notpaidamount + $totalPaidAmount;
    $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
    // Calculate Total Amount
    $totalAmount = $notpaidamount + $totalPaidAmount;

    // Calculate Outstanding Percentage (Handle division by zero)
    $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;




    $HistoryPayment2 =  DB::table('et_proposal_pay_slot')
      ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
      ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
      ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->where('et_lead.created_by', '>', 1)
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal_pay_slot.branch_id', $branch_id)
      ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
      ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
      ->select(
        'et_payment.payment_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.initialPayDate',
        'et_proposal_pay_slot.paid_status AS payment_status',
        'et_proposal_pay_slot.payable_amount AS payment_amount',
        'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
        'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_customer.sno as customer_sno',
        'et_customer.customer_id',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.gst_perc',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.propo_pay_slot_id',
        \DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt')
      )
      // ->whereNotIn('et_customer.sno', $drop_ids)
      ->groupBy(
        'et_payment.payment_id',
        'et_customer.sno',
        'et_customer.customer_id',
        'et_proposal_pay_slot.initialPayDate',
        'et_customer.cus_name',
        'et_customer.cus_pic',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.cus_gender',
        'et_proposal.service_title',
        'et_proposal.sno',
        'et_proposal_pay_slot.propo_pay_slot_id',
        'et_proposal_pay_slot.nextPayDate',
        'et_proposal_pay_slot.paid_status',
        'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount',
        'et_proposal.gst_perc',
        'et_proposal_pay_slot.gst_amount',
        'et_proposal_pay_slot.balance_amount',
        'et_proposal.currency_id',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol'
      );

    if (!empty($customer_fill)) {
      $HistoryPayment2->where(function ($query) use ($customer_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
      });
    }

    if (!empty($balance_payment)) {
      $HistoryPayment2
        //   ->whereDate('et_payment.nextPayDate', '<', $currentDate)
        ->where('et_proposal_pay_slot.paid_status', 0)->where('et_proposal_pay_slot.payable_amount', '>', 0);
    }
    // Assign paginated result
    $HistoryPayment2 = $HistoryPayment2->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')->get();

    //   return count($HistoryPayment2);
    $total_paid = 0;
    $total_gst = 0;
    foreach ($HistoryPayment2 as $i => $pay) {
      if ($pay->payment_status == 0) {
        $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc / 100 : 0;
        $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
        $gstAmount = $pay->payment_amount - $baseAmount;

        if ($pay->currency_id != 70) {
          $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
          $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
        } else {
          $total_paid += $baseAmount;
          $total_gst  += $gstAmount;
        }
      } else {
        $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc / 100 : 0;
        $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
        $gstAmount = $pay->payment_paid_amt - $baseAmount;

        if ($pay->currency_id != 70) {
          $total_paid += $helper->ConvertedAmountInr($pay->currency_code, $baseAmount);
          $total_gst  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
        } else {
          $total_paid += $baseAmount;
          $total_gst  += $gstAmount;
        }
      }
    }


    //  return $total_gst;


    // return $outstandingAmount;
    // Return the view with the data and total count
    return view('content.payment_management.payment_remainder.payment_reminder', [
      'perpage' => $perpage,
      'month_chk' => $month_chk,
      'HistoryPayment' => $HistoryPayment,
      'outstandingAmount' => $outstandingAmount,
      'outstandingPercentage' => $outstandingPercentage,
      'totalPaidAmount' => $totalPaidAmount,
      'totalscheduleamount' => $totalscheduleamount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'cus_fill' => $customer_fill,
      'total_paid' => $total_paid,
      'total_gst' => $total_gst,
      'gstPercentage' => $gstPercentage,
      'month_filter' => $month_filter,
      'filterDate' => $filterDate,
    ])->with('filter_on', false);
  }
   public function OutstandingPayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $customer_fill = $request->customer_fill ?? '';
     $helper = new \App\Helpers\Helpers();
      
     $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->first();

      $totalConvertedInr = 0;
      $totalNextThreeConvertInr = 0;
      $totalNextMonthConvertInr = 0;
      $totalCurrentMonthConvertInr = 0;
      $gst_percent = $branch ? $branch->gst_percentage : 18;
      $drop_ids = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno');
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('et_proposal_pay_slot')
        ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_proposal_pay_slot.paid_status', 0)
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2)
        ->where('et_lead.created_by','>', 1)
        ->whereNotIn('et_customer.sno', $drop_ids)
        ->where('et_proposal_pay_slot.status', 0)
        ->where('et_proposal_pay_slot.branch_id', $branch_id)
        ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
        ->whereNotIn('et_proposal.proposal_status', [0,2])
        ->sum('et_proposal_pay_slot.payable_amount');
    
    $currentMonthStart = now()->startOfMonth();
    $currentMonthEnd = now()->endOfMonth();
    $nextMonthStart = now()->addMonth()->startOfMonth();
    $nextMonthEnd = now()->addMonth()->endOfMonth();
    $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();
    
    // Current Month
    $currentMonthAmount = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->select(
              'et_proposal_pay_slot.*',
              'et_proposal.currency_id',
              'et_country_currencies.currency_code',
          )
        ->where('et_proposal_pay_slot.paid_status', 0)
        ->where('et_proposal_pay_slot.status', 0)
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2)
        ->where('et_lead.created_by','>', 1)
        ->whereNotIn('et_customer.sno', $drop_ids)
        ->where('et_proposal_pay_slot.branch_id', $branch_id)
        ->whereBetween('et_proposal_pay_slot.nextPayDate', [$currentMonthStart, $currentMonthEnd])
        ->whereNotIn('et_proposal.proposal_status', [0,2])
        ->get();

        foreach ($currentMonthAmount as $pending) {

          $currency_code = $pending->currency_code;
          $payAmount = $pending->payable_amount;

          // ✔ Fix partial check logic
          if ($pending->partial_check == 1) {
              $payAmount = $pending->payable_amount >=$pending->paidAmount ?  $pending->payable_amount - $pending->paidAmount:$pending->payable_amount;
          }

          // ✔ Convert only if not INR
          if ($pending->currency_id != 70) {
              $totalCurrentMonthConvertInr += $helper->ConvertedAmountInr($currency_code, $payAmount);
          } else {
              $totalCurrentMonthConvertInr += $payAmount;
          }
        }

      // ✔ GST Removal: Base Amount = Total / (1 + GST%)
      $currentMonthConvert = $totalCurrentMonthConvertInr > 0 
          ? $totalCurrentMonthConvertInr / (1 + ($gst_percent / 100)) 
          : 0;


      $currentMonthConvert = round($currentMonthConvert);
    

      
    // Next Month
    $nextMonthAmount = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_proposal_pay_slot.paid_status', 0)
        ->where('et_proposal_pay_slot.status', 0)
        ->select(
              'et_proposal_pay_slot.*',
              'et_proposal.currency_id',
              'et_country_currencies.currency_code',
          )
        ->where('et_customer.status', '!=', 2)
        ->whereNotIn('et_customer.sno', $drop_ids)
        ->where('et_lead.status', '!=', 2)
        ->where('et_lead.created_by','>', 1)
        ->where('et_proposal_pay_slot.branch_id', $branch_id)
        ->whereBetween('et_proposal_pay_slot.nextPayDate', [$nextMonthStart, $nextMonthEnd])
        ->get();

        foreach ($nextMonthAmount as $pending) {

          $currency_code = $pending->currency_code;
          $payAmount = $pending->payable_amount;

          // ✔ Fix partial check logic
          if ($pending->partial_check == 1) {
              $payAmount = $pending->payable_amount >=$pending->paidAmount ?  $pending->payable_amount - $pending->paidAmount:$pending->payable_amount;
          }

          // ✔ Convert only if not INR
          if ($pending->currency_id != 70) {
              $totalNextMonthConvertInr += $helper->ConvertedAmountInr($currency_code, $payAmount);
          } else {
              $totalNextMonthConvertInr += $payAmount;
          }
        }

      // ✔ GST Removal: Base Amount = Total / (1 + GST%)
      $nextMonthConvert = $totalNextMonthConvertInr > 0 
          ? $totalNextMonthConvertInr / (1 + ($gst_percent / 100)) 
          : 0;


      $nextMonthConvert = round($nextMonthConvert);
    
    // Greater than 3 Months
    $greaterThanThreeMonthsAmount = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->select(
              'et_proposal_pay_slot.*',
              'et_proposal.currency_id',
              'et_country_currencies.currency_code',
          )
        ->where('et_proposal_pay_slot.paid_status', 0)
        ->where('et_proposal_pay_slot.status', 0)
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2)
        ->whereNotIn('et_customer.sno', $drop_ids)
        ->where('et_lead.created_by','>', 1)
        ->where('et_proposal_pay_slot.branch_id', $branch_id)
        ->where('et_proposal_pay_slot.nextPayDate', '>=', $threeMonthsLaterStart)
        ->whereNotIn('et_proposal.proposal_status', [0,2])
        ->get();

        foreach ($greaterThanThreeMonthsAmount as $pending) {

          $currency_code = $pending->currency_code;
          $payAmount = $pending->payable_amount;

          // ✔ Fix partial check logic
          if ($pending->partial_check == 1) {
              $payAmount = $pending->payable_amount >=$pending->paidAmount ?  $pending->payable_amount - $pending->paidAmount:$pending->payable_amount;
          }

          // ✔ Convert only if not INR
          if ($pending->currency_id != 70) {
              $totalNextThreeConvertInr += $helper->ConvertedAmountInr($currency_code, $payAmount);
          } else {
              $totalNextThreeConvertInr += $payAmount;
          }
        }

      // ✔ GST Removal: Base Amount = Total / (1 + GST%)
      $greaterThanThreeMonthConvert = $totalNextThreeConvertInr > 0 
          ? $totalNextThreeConvertInr / (1 + ($gst_percent / 100)) 
          : 0;


      $greaterThanThreeMonthConvert = round($greaterThanThreeMonthConvert);
    

        $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereNotIn('et_proposal.proposal_status', [0,2])
            ->select(
                'et_proposal_pay_slot.sno',
                \DB::raw('MAX(et_proposal.currency_id) AS currency_id'),
                \DB::raw('MAX(et_country_currencies.currency_code) AS currency_code'),
                \DB::raw('MAX(et_country_currencies.currency_symbol) AS currency_symbol'),
                \DB::raw('MAX(et_proposal_pay_slot.propo_pay_slot_id) AS payment_id'),
                \DB::raw('MAX(et_payment.sno) AS payment_sno'),
                \DB::raw('MAX(et_customer.jumper_skiper) AS jumper_skiper'),
                \DB::raw('MAX(et_payment.branch_id) AS branch_id'),
                \DB::raw('MAX(et_customer.customer_id) AS customer_id'),
                \DB::raw('MAX(et_customer.sno) AS customer_sno'),
                \DB::raw('MAX(et_proposal_pay_slot.initialPayDate) AS initialPayDate'),
                \DB::raw('MAX(et_proposal_pay_slot.nextPayDate) AS nextPayDate'),
                \DB::raw('MAX(et_proposal_pay_slot.payable_amount) AS amount'),
                \DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS paidAmount'),
                \DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS gst_amount'),
                \DB::raw('MAX(et_proposal_pay_slot.total_amount) AS total_amount'),
                \DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS balanceFee'),
                \DB::raw('MAX(et_payment.payment_mode) AS payment_mode_label'),
                \DB::raw('MAX(et_proposal_pay_slot.paid_status) AS payment_status'),
                \DB::raw('MIN(et_customer.cus_name) AS cus_name'),
                \DB::raw('MAX(et_customer.cus_pic) AS cus_pic'),
                \DB::raw('MAX(et_customer.cus_gender) AS cus_gender'),
                \DB::raw('MAX(et_customer.cus_mobile) AS cus_mobile'),
                \DB::raw('MAX(et_customer.cus_email_id) AS cus_email_id'),
                \DB::raw('MAX(et_customer.status) AS cus_status'),
                \DB::raw('MAX(et_proposal.service_title) AS service_title'),
                \DB::raw('MAX(et_proposal.sno) AS proposal_sno'),
                \DB::raw('MAX(et_proposal.proposal_id) AS proposal_id'),
                // \DB::raw('MAX(et_staff.staff_name) AS pro_staff_name')
            )
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->where('et_proposal_pay_slot.status', 0)
            ->where('et_proposal_pay_slot.payable_amount', '>',0)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->whereNotIn('et_customer.sno', $drop_ids)
            ->where('et_lead.created_by','>', 1)
            ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate);
            if (!empty($customer_fill)) {
                  $OutstandingPayment->where(function ($query) use ($customer_fill) {
                      $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                          ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
                  });
              }
            $OutstandingPayment=$OutstandingPayment ->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')
            ->groupBy('et_proposal_pay_slot.sno')
            ->paginate($perpage);

      $OutstandingPaymentOverAll = DB::table('et_proposal_pay_slot')
          ->where('et_proposal_pay_slot.branch_id', $branch_id)
          ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
          ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
          ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->select(
              'et_proposal_pay_slot.*',
              'et_proposal.currency_id',
              'et_country_currencies.currency_code',
          )
          ->whereNotIn('et_proposal.proposal_status', [0, 2])
          ->where('et_proposal_pay_slot.paid_status', 0)
          ->where('et_proposal_pay_slot.status', 0)
          ->where('et_proposal_pay_slot.payable_amount', '>', 0)
          ->where('et_customer.status', '!=', 2)
          ->whereNotIn('et_customer.sno', $drop_ids)
          ->where('et_lead.status', '!=', 2)
          ->where('et_lead.created_by', '>', 1)
          ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
          ->orderBy('et_proposal_pay_slot.nextPayDate', 'DESC')
          ->distinct('et_proposal_pay_slot.sno')  // replaces wrong distinct usage
          ->get();

      foreach ($OutstandingPayment as $pending) {
           $logExist = DB::table('et_pay_skipper_history')
              ->where('et_pay_skipper_history.pay_slot_id', $pending->sno)
              ->exists();
          $pending->log_exist = $logExist ?? false;
      }

      foreach ($OutstandingPaymentOverAll as $pending) {

          $currency_code = $pending->currency_code;
          $payAmount = $pending->payable_amount;

          // ✔ Fix partial check logic
          if ($pending->partial_check == 1) {
              $payAmount = $pending->payable_amount >=$pending->paidAmount ?  $pending->payable_amount - $pending->paidAmount:$pending->payable_amount;
          }

          // ✔ Convert only if not INR
          if ($pending->currency_id != 70) {
              $totalConvertedInr += $helper->ConvertedAmountInr($currency_code, $payAmount);
          } else {
              $totalConvertedInr += $payAmount;
          }
      }

      // ✔ GST Removal: Base Amount = Total / (1 + GST%)
      $total_base_amount_Inr = $totalConvertedInr > 0 
          ? $totalConvertedInr / (1 + ($gst_percent / 100)) 
          : 0;


      $total_base_amount_Inr = round($total_base_amount_Inr);

    // Get the total count of records
    $OutstandingPaymentCount = $OutstandingPayment->total();
    
    // return $OutstandingPayment;

    $TodayPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id) 
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.status', '!=', 2)
        ->whereNotIn('et_customer.sno', $drop_ids)
        ->where('et_lead.status', '!=', 2)
        ->where('et_lead.created_by','>', 1)
      ->where('et_proposal_pay_slot.paid_status', 0)
      ->where('et_proposal_pay_slot.status', 0)
      ->whereNotIn('et_proposal.proposal_status', [0,2])
      ->whereDate('et_proposal_pay_slot.nextPayDate', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();

    // Return the view with the data and total count
    return view('content.payment_management.manage_payment.outstanding_payment', [
      'perpage' => $perpage,
      'sumScheduleAmount' => $sumScheduleAmount,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gst_percent,
       'customer_fill' => $customer_fill,
      'currentMonthAmount' => $currentMonthConvert,
      'nextMonthAmount' => $nextMonthConvert,
      'total_base_amount_Inr' => $total_base_amount_Inr,
      'greaterThanThreeMonthsAmount' => $greaterThanThreeMonthConvert,
    ])->with('filter_on', false);
  }
  
//   public function Payment_reschedule(Request $request)
// {
//     $branch_id = $request->user()->branch_id;
//     $user_id = $request->user()->user_id;

//     $resch_date = date('Y-m-d', strtotime($request->max_reschedule_date));

//     $get_payment = DB::table('et_proposal_pay_slot')
//         ->select('et_proposal_pay_slot.*', 'et_proposal.customer_id')
//         ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
//         ->where('et_proposal_pay_slot.sno', $request->cus_payment_sno)
//         ->first();

//     $get_customer = null;

//     if ($get_payment) {

//         // determine previous date
//         $previous_date = $get_payment->nextPayDate ?? $get_payment->initialPayDate;

//         // calculate new reschedule count
//         $reschedule_count = ($get_payment->reschedule_payment ?? 0) + 1;

//         // update payment table
//         DB::table('et_proposal_pay_slot')
//             ->where('sno', $request->cus_payment_sno)
//             ->update([
//                 'nextPayDate'        => $resch_date,
//                 'initialPayDate'     => $resch_date,
//                 'reschedule_payment' => $reschedule_count
//             ]);

//         // insert skipper history
//         $this->paySkipperHistory(
//             $branch_id,
//             $get_payment->customer_id,
//             $previous_date,
//             $resch_date,
//             $get_payment->sno,  // correct pay_slot_id
//             $reschedule_count,
//             $user_id
//         );

//         // update customer
//         $get_customer = CustomerModel::where('sno', $get_payment->customer_id)->first();
//         if ($get_customer) {
//             $get_customer->jumper_skiper = ($get_customer->jumper_skiper ?? 0) + 1;
//             $get_customer->save();
//         }
//     }

//     // flash result
//     if ($get_customer) {
//         session()->flash('toastr', [
//             'type'    => 'success',
//             'message' => 'Payment Rescheduled Successfully!'
//         ]);
//     } else {
//         session()->flash('toastr', [
//             'type'    => 'error',
//             'message' => 'Could not Reschedule the Payment!'
//         ]);
//     }

//     return redirect('/outstanding_payment');
// }


//   private function paySkipperHistory(
//     $branch_id,
//     $customer_id,
//     $previousDate,
//     $resch_date,
//     $pay_slot_id,
//     $reschedule_payment,
//     $user_id
// ){
//     DB::table('et_pay_skipper_history')->insert([
//         'branch_id'          => $branch_id,
//         'customer_id'        => $customer_id,
//         'previous_date'      => $previousDate,
//         'reschedule_date'    => $resch_date,
//         'pay_slot_id'        => $pay_slot_id,
//         'slot_id_history'    => $pay_slot_id,
//         'reschedule_payment' => $reschedule_payment,
//         'created_by'         => $user_id,
//         'updated_by'         => $user_id,
//     ]);
// }
  
    
   public function Payment_reschedule(Request $request)
{
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;

    $resch_date = date('Y-m-d', strtotime($request->max_reschedule_date));
    $custom_reschedule_date = date('Y-m-d', strtotime($request->custom_reschedule_date));

    $get_payment = DB::table('et_proposal_pay_slot')
        ->select('et_proposal_pay_slot.*', 'et_proposal.customer_id')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->where('et_proposal_pay_slot.sno', $request->cus_payment_sno)
        ->first();

    $get_customer = null;

    if ($get_payment) {

        // determine previous date
        $previous_date = $get_payment->nextPayDate ?? $get_payment->initialPayDate;

        // calculate new reschedule count
        $reschedule_count = ($get_payment->reschedule_payment ?? 0) + 1;

        // update payment table
        DB::table('et_proposal_pay_slot')
            ->where('sno', $request->cus_payment_sno)
            ->update([
                // 'nextPayDate'        => $resch_date,
                // 'initialPayDate'     => $resch_date,
                'nextPayDate'        => $custom_reschedule_date,
                'initialPayDate'     => $custom_reschedule_date,
                'reschedule_payment' => $reschedule_count
            ]);

        // insert skipper history
        $this->paySkipperHistory(
            $branch_id,
            $get_payment->customer_id,
            $previous_date,
            $custom_reschedule_date,
            $get_payment->sno,  // correct pay_slot_id
            $reschedule_count,
            $user_id
        );

        // update customer
        $get_customer = CustomerModel::where('sno', $get_payment->customer_id)->first();
        if ($get_customer) {
            $get_customer->jumper_skiper = ($get_customer->jumper_skiper ?? 0) + 1;
            $get_customer->save();
        }
    }

    // flash result
    if ($get_customer) {
        session()->flash('toastr', [
            'type'    => 'success',
            'message' => 'Payment Rescheduled Successfully!'
        ]);
    } else {
        session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Could not Reschedule the Payment!'
        ]);
    }

    return redirect('/outstanding_payment');
}


  private function paySkipperHistory(
    $branch_id,
    $customer_id,
    $previousDate,
    $resch_date,
    $pay_slot_id,
    $reschedule_payment,
    $user_id
){
    DB::table('et_pay_skipper_history')->insert([
        'branch_id'          => $branch_id,
        'customer_id'        => $customer_id,
        'previous_date'      => $previousDate,
        'reschedule_date'    => $resch_date,
        'pay_slot_id'        => $pay_slot_id,
        'slot_id_history'    => $pay_slot_id,
        'reschedule_payment' => $reschedule_payment,
        'created_by'         => $user_id,
        'updated_by'         => $user_id,
    ]);
}


public function getCustomerOutstanding($id, Request $request) {
    // Fetch customer data
    $OutstandingPayment = DB::table('et_proposal_pay_slot')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_staff as cre_staff', 'et_proposal.cre_id', '=', 'cre_staff.sno')
        ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_staff as sales_staff', 'et_lead.created_by', '=', 'sales_staff.sno')
        ->leftJoin('et_staff as post_sale_staff', 'et_proposal.created_by', '=', 'post_sale_staff.sno')
        ->join('et_payment', function($join) {
            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                 ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno AND ep.status = 0
                 )');
        })
        ->select(
            // Your fields here
            'et_proposal.sno AS proposal_sno',
            'et_proposal.proposal_id AS proposal_id',
            'et_payment.transaction_date AS proposal_date',
            'et_proposal_pay_slot.sno',
            'et_proposal.currency_id AS currency_id',
            'et_country_currencies.currency_code AS currency_code',
            'et_country_currencies.currency_symbol AS currency_symbol',
            'et_proposal_pay_slot.propo_pay_slot_id AS payment_id',
            'et_customer.jumper_skiper AS jumper_skiper',
            'et_customer.customer_id AS customer_id',
            'et_customer.sno AS customer_sno',
            'et_proposal_pay_slot.initialPayDate AS initialPayDate',
            'et_proposal_pay_slot.nextPayDate AS nextPayDate',
            'et_proposal_pay_slot.payable_amount AS amount',
            'et_proposal_pay_slot.paidAmount AS paidAmount',
            'et_proposal_pay_slot.gst_amount AS gst_amount',
            'et_proposal_pay_slot.total_amount AS total_amount',
            'et_proposal_pay_slot.balance_amount AS balanceFee',
            'et_proposal_pay_slot.paid_status AS payment_status',
            'et_customer.cus_name AS cus_name',
            'et_customer.cus_pic AS cus_pic',
            'et_customer.cus_gender AS cus_gender',
            'et_customer.cus_mobile AS cus_mobile',
            'et_customer.cus_email_id AS cus_email_id',
            'et_customer.status AS cus_status',
            'et_proposal.service_title AS service_title',
            'et_proposal.post_sale_check',
            'cre_staff.staff_name AS cre_staff_name',
            'sales_staff.staff_name AS sales_staff_name',
            'post_sale_staff.staff_name AS post_sale_staff_name',
            'et_payment.transaction_date AS converted_date',
        )
        ->where('et_proposal_pay_slot.sno', $id)
        ->first();

    // Fetch reschedule logs
    $log = DB::table('et_pay_skipper_history')
        ->where('et_pay_skipper_history.pay_slot_id', $id)
        ->join('et_proposal_pay_slot', 'et_pay_skipper_history.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_staff', 'et_pay_skipper_history.created_by', '=', 'et_staff.sno')
        ->select(
            'et_pay_skipper_history.*',
            'et_proposal.service_title',
            'et_payment_slot.payment_slot_name',
            'et_staff.staff_name'
        )
        ->get();

    return response()->json([
        'status' => '200',
        'customer' => $OutstandingPayment,
        'data' => $log,
        'message' => 'Outstanding data fetched successfully'
    ]);
}
  
  
}