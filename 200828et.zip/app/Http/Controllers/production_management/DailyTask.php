<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use App\Models\DailyTaskModel;
use App\Models\ManageTaskChecklistModel;
use App\Models\ManageTaskModel;
use App\Models\NewTaskModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class DailyTask extends Controller
{
    public function index()
    {
        return view('content.production_management.daily_task.daily_task');
    }

    public function production_staff_data_fetch(Request $request)
    {

        $search = $request->query('search');

        $query = DB::table('et_staff')
            ->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.department_id', 2)
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', '!=', 15)
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.employee_skill_id',
                'et_job_position.job_position_name'
            );

        if (!empty($search)) {
            $query->where('et_staff.staff_name', 'LIKE', "%{$search}%");
        }

        $data = $query->orderBy('et_staff.staff_name', 'asc')
            ->distinct()
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function get_customer_services($id)
    {
        $datas = DB::table('et_customer_services')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_task', 'et_task.service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            // ->whereIn('et_customer_services.status', [0, 1, 5])
            ->whereJsonContains('et_task.assign_staffs', $id)
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name"),
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids',
            )
            ->groupBy(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer_services.product_package',
                'et_product.product_name',
                'et_package.package_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->get();

        foreach ($datas as $data) {
            $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);

            $variant_name = '-';
            $variable_name = '-';
            $variable_id = 0;
            $variant_id = 0;

            // Loop through the variant_variable_data if it contains multiple variants/variables
            foreach ($variant_variable_data as $pair) {
                // Fetch variant and variable data
                $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
                $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

                // If a variant or variable is found, assign them
                if ($variant) {
                    $variant_id = $variant->sno;
                    $variant_name = $variant->product_variant_name ?? '';
                }

                if ($variable) {
                    $variable_id = $variable->sno;
                    $variable_name = $variable->variable_name ?? '';
                }
            }
            $data->variant_name = $variant_name;
            $data->variable_name = $variable_name;
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $datas
        ], 200);
    }

    public function task_data_fetch($serviceId, $staffId)
    {

        $data = DB::table('et_task')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->where('et_task.service_id', $serviceId)
            ->whereJsonContains('et_task.assign_staffs', $staffId)
            ->select(
                'et_product_task.task_name',
                'et_task.sno',
                'et_task.task_id',
                'et_task.pages_percentage',
                'et_task.working_hours',
                'et_task.task_category',
            )
            ->where('et_task.status', 0)
            ->where(function ($query) {
                $query->where('et_task.working_hours', '>', 0)
                    ->orWhere('et_task.pages_percentage', '>', 0);
            })
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function split_task_data_fetch($taskId)
    {
        $data = DB::table('et_task')
            ->leftJoin('et_staff', function ($join) {
                $join->on('et_staff.sno', '=', DB::raw("JSON_UNQUOTE(JSON_EXTRACT(et_task.assign_staffs, '$[0]'))"));
            })
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_task.service_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->where('et_task.sno', $taskId)
            ->where('et_task.status', 0)
            ->select(
                'et_staff.staff_name',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name"),
                'et_customer.cus_name',
                'et_customer_services.variant_variable_ids',
                'et_customer.customer_id',
                'et_product_task.task_name',
                'et_task.task_id',
                'et_task.task_category',
                'et_task.pages_percentage',
                'et_task.working_hours',
            )
            ->first();

        $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);
        $variant_name = '-';
        $variable_name = '-';

        // Loop through the variant_variable_data if it contains multiple variants/variables
        foreach ($variant_variable_data as $pair) {
            // Fetch variant and variable data
            $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
            $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

            // If a variant or variable is found, assign them
            if ($variant) {
                $variant_id = $variant->sno;
                $variant_name = $variant->product_variant_name ?? '';
            }

            if ($variable) {
                $variable_id = $variable->sno;
                $variable_name = $variable->variable_name ?? '';
            }
        }
        $data->variant_name = $variant_name;
        $data->variable_name = $variable_name;


        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function get_task_date_progress($id, $date)
    {
        try {
            $total_hours = DB::table('et_daily_tasks')
                ->where('status', '!=', 2)
                ->where('staff_id', $id)
                ->whereDate('task_date', $date)
                ->sum('task_hours');

            return response()->json([
                'status' => 200,
                'message' => 'Task Hours Fetched Successfully!',
                'error_msg' => null,
                'data' => $total_hours
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error fetching task hours',
                'error_msg' => $e->getMessage(),
                'data' => 0
            ]);
        }
    }

    public function edit($id, $taskDate)
    {
        $data = DB::table('et_daily_tasks')
            ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->where('et_daily_tasks.staff_id', $id)
            ->where('et_daily_tasks.task_date', $taskDate)
            ->where('et_daily_tasks.status', '!=', 2)
            ->select(
                'et_daily_tasks.*',
                'et_product_task.task_name',
                'et_task.task_id as task_id',
                'et_task.task_category'
            )
            ->get();

        $total_hours = 0;
        $balance_hours = 7;
        $task_count = 0;

        if ($data) {
            $total_hours = $data->sum('task_hours');
            $balance_hours = 7 - $total_hours;
            $task_count = str_pad(count($data), 2, '0', STR_PAD_LEFT);
        }

        $staff = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.sno', $id)
            ->select(
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.employee_skill_id',
                'et_job_position.job_position_name'
            )
            ->first();

        $staff->total_hours = $total_hours;
        $staff->balance_hours = $balance_hours;
        $staff->task_count = $task_count;
        // return $data;
        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data,
            'staff' => $staff
        ], 200);
    }

    public function Delete($id)
    {
        $data = DailyTaskModel::where('sno', $id)->first();
        $data->status = 2;
        $data->update();

        if ($data) {
            $addTask = ManageTaskModel::where('sno', $data->task_id)->first();

            $working_hours = $data->task_hours + $addTask->working_hours;
            $pages_percentage = $data->max_page_or_per + $addTask->pages_percentage;

            $addTask->working_hours = $working_hours;
            $addTask->pages_percentage = $pages_percentage;
            $addTask->update();

            return response([
                'status' => 200,
                'message' => 'Task Deleted!',
                'error_msg' => null,
                'data' => null
            ], 200);
        }

        return response([
            'status' => 302,
            'message' => 'Task Deletion Failed!',
            'error_msg' => null,
            'data' => null
        ], 302);
    }

    // public function Create(Request $request)
    // {

    //     $staff_id = $request->staff_id;
    //     $task_id = $request->task_id;
    //     $service_id = $request->service_id;
    //     $task_date = $request->task_date;
    //     $allocated_pages = $request->allocated_pages;
    //     $allocated_time = $request->allocated_time;
    //     $allocated_time = str_replace(',', '.', $allocated_time);
    //     $allocated_time = (float)$allocated_time;
    //     $description = $request->description;
    //     $user_id = $request->user()->user_id;
    //     $branch_id = $request->user()->branch_id;

    //     $check = DailyTaskModel::where('staff_id', $staff_id)
    //         ->where('task_date', $task_date)
    //         ->where('status', '!=', 2)
    //         ->get();

    //     $task_hours = $check->sum('task_hours');

    //     if (($task_hours + $allocated_time) > 7) {
    //         return response([
    //             'status' => 302,
    //             'message' => 'Task hours limit (7 hrs) reached for this staff on the selected date!',
    //             'error_msg' => null,
    //             'data' => null
    //         ], 302);
    //     }

    //     $tasks = new DailyTaskModel();
    //     $tasks->staff_id = $staff_id;
    //     $tasks->service_id = $service_id;
    //     $tasks->task_id = $task_id;
    //     $tasks->task_date = $task_date;
    //     $tasks->max_page_or_per = $allocated_pages;
    //     $tasks->task_hours = $allocated_time;
    //     $tasks->description = $description;
    //     $tasks->created_by = $user_id;
    //     $tasks->updated_by = $user_id;
    //     $tasks->save();

    //     if ($tasks) {
    //         $update_task = ManageTaskModel::where('sno', $tasks->task_id)->first();

    //         if ($update_task) {
    //             $update_task->working_hours = $update_task->working_hours - $allocated_time;
    //             $update_task->pages_percentage = $update_task->pages_percentage - $allocated_pages;
    //             $update_task->update();
    //         }

    //         // Notification
    //         $notificationData = [
    //             'branch_id' => $branch_id,
    //             'notification_content' =>   '<div class="d-flex align-items-center">
    //                                             <div class="me-3">
    //                                                 <span class="badge bg-success">
    //                                                     <i class="mdi mdi-calendar-edit fs-3 "></i>
    //                                                 </span>
    //                                             </div>
    //                                             <div class="me-2">
    //                                                 <a href="javascript:;" class="fs-7 text-primary fw-bold">New Task Assigned</a>
    //                                                 <div class="text-secondary fs-8  fw-bold">' . $update_task->task_id . '</div>
    //                                             </div>
    //                                         </div>',
    //             'who' => $tasks->staff_id,
    //             'created_by' => $user_id,
    //             'updated_by' => $user_id,
    //             'status' => 0
    //         ];
    //         $notificationtype = 'Requirement';
    //         $newNotification = new \App\Helpers\Helpers();
    //         $newNotification->createNotificationAssessment($notificationData, $notificationtype, $tasks->staff_id);
            

    //         return response([
    //             'status' => 200,
    //             'message' => 'Task added successfully!',
    //             'error_msg' => null,
    //             'data' => null
    //         ], 200);
    //     }

    //     return response([
    //         'status' => 500,
    //         'message' => 'Something went wrong while saving the task!',
    //         'error_msg' => null,
    //         'data' => null
    //     ], 500);
    // }
    
    public function Create(Request $request)
    {
 
        $staff_id = $request->staff_id;
        $task_id = $request->task_id;
        $service_id = $request->service_id;
        $task_date = $request->task_date;
        $allocated_pages = $request->allocated_pages;
        $allocated_time = $request->allocated_time;
        $allocated_time = str_replace(',', '.', $allocated_time);
        $allocated_time = (float)$allocated_time;
        $description = $request->description;
        $critical_chk = $request->critical_chk;
        $emergency_chk = $request->emergency_chk;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
 
        $check = DailyTaskModel::where('staff_id', $staff_id)
            ->where('task_date', $task_date)
            ->where('status', '!=', 2)
            ->get();
 
        $task_hours = $check->sum('task_hours');
 
        if (($task_hours + $allocated_time) > 7) {
            return response([
                'status' => 302,
                'message' => 'Task hours limit (7 hrs) reached for this staff on the selected date!',
                'error_msg' => null,
                'data' => null
            ], 302);
        }
 
        $tasks = new DailyTaskModel();
        $tasks->staff_id = $staff_id;
        $tasks->service_id = $service_id;
        $tasks->task_id = $task_id;
        $tasks->task_date = $task_date;
        $tasks->max_page_or_per = $allocated_pages;
        $tasks->task_hours = $allocated_time;
        $tasks->description = $description;
        $tasks->emergency_chk = $emergency_chk;
        $tasks->critical_chk = $critical_chk;
        $tasks->created_by = $user_id;
        $tasks->updated_by = $user_id;
        $tasks->save();
 
        if ($tasks) {
            $update_task = ManageTaskModel::where('sno', $tasks->task_id)->first();
 
            if ($update_task) {
                $update_task->working_hours = $update_task->working_hours - $allocated_time;
                $update_task->pages_percentage = $update_task->pages_percentage - $allocated_pages;
                $update_task->update();
            }
 
            // Notification
            $notificationData = [
                'branch_id' => $branch_id,
                'notification_content' =>   '<div class="d-flex align-items-center">
                                                <div class="me-3">
                                                    <span class="badge bg-success">
                                                        <i class="mdi mdi-calendar-edit fs-3 "></i>
                                                    </span>
                                                </div>
                                                <div class="me-2">
                                                    <a href="javascript:;" class="fs-7 text-primary fw-bold">New Task Assigned</a>
                                                    <div class="text-secondary fs-8  fw-bold">' . $update_task->task_id . '</div>
                                                </div>
                                            </div>',
                'who' => $tasks->staff_id,
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'status' => 0
            ];
            $notificationtype = 'Requirement';
            $newNotification = new \App\Helpers\Helpers();
            $newNotification->createNotificationAssessment($notificationData, $notificationtype, $tasks->staff_id);
           
 
            return response([
                'status' => 200,
                'message' => 'Task added successfully!',
                'error_msg' => null,
                'data' => null
            ], 200);
        }
 
        return response([
            'status' => 500,
            'message' => 'Something went wrong while saving the task!',
            'error_msg' => null,
            'data' => null
        ], 500);
    }
 
}
