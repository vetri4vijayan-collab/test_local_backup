<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskRequest extends Controller
{
    public function index (Request $request) {

        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';

        $query = DB::table('et_task_request')
            ->leftJoin('et_journal_request', 'et_journal_request.sno', '=', 'et_task_request.request_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_task_request.journal_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_staff as je_staff', 'je_staff.sno', '=', 'et_task_request.assigned_by')
            ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_task_request.pc_id')
            ->leftJoin('et_staff as pro_staff', 'pro_staff.sno', '=', 'et_task_request.staff_id')
            ->where('et_task_request.status', '!=', 2)
            ->select(
                'et_journal_request.request_name',
                'et_task_request.sno',
                'et_task_request.from',
                'et_task_request.status',
                'et_task_request.drive_link',
                'et_task_request.staff_documents',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'je_staff.staff_name as je_name',
                'je_staff.staff_image as je_image',
                'pc_staff.staff_name as pc_name',
                'pc_staff.staff_image as pc_image',
                'pro_staff.staff_name as pro_name',
                'pro_staff.staff_image as pro_image'
            );

        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_journal_request.request_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('je_staff.je_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('pc_staff.pc_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('pro_staff.pro_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_journal.paper_name', 'LIKE', "%{$search_fill}%");
            });
        }


        $lists = $query->paginate($perpage);

        return view('content.production_management.task_request.list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill
        ]);
    }

    public function get_task_request($id) {
        $data = DB::table('et_task_request')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_task_request.journal_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_journal_request', 'et_journal_request.sno', '=', 'et_task_request.request_id')
            ->leftJoin('et_staff as je_staff', 'je_staff.sno', '=', 'et_task_request.assigned_by')
            ->where('et_task_request.sno', $id)
            ->where('et_task_request.status', '!=', 2)
            ->select(
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'je_staff.staff_name as je_name',
                'je_staff.staff_image as je_image',
                'et_journal_request.request_name',
                'et_task_request.from',
                'et_task_request.sno'
            )
            ->first();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        }
    }

    public function taskRequestAdd($id, Request $request)
    {
        $request->validate([
            'temp_status' => 'required|integer',
            'pc_id'       => 'required_if:temp_status,0',
            'reason'      => 'required_if:temp_status,1',
            'staff_id'    => 'required_if:temp_status,2',
        ]);

        $status = $request->temp_status;
        $userId = $request->user()->user_id;

        $taskRequest = DB::table('et_task_request')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_task_request.journal_id')
            ->where('et_task_request.status', '!=', 2)
            ->where('et_task_request.sno', $id)
            ->select(
                'et_task_request.*',
                'et_manage_journal.service_id'
            )
            ->first();

        if (!$taskRequest) {
            return response([
                'status' => 404,
                'message' => 'No Request Found!',
                'data' => null
            ], 404);
        }

        DB::beginTransaction();

        try {
            switch ($status) {

                case 0: // Accept
                    DB::table('et_task_request')
                        ->where('sno', $id)
                        ->update([
                            'pc_id'      => $request->pc_id,
                            'updated_by' => $userId,
                            'status'     => 1
                        ]);
                    break;

                case 1: // Reject
                    DB::table('et_task_request')
                        ->where('sno', $id)
                        ->update([
                            'reason'     => $request->reason,
                            'updated_by' => $userId,
                            'status'     => 3
                        ]);
                    break;

                case 2: // Allocate Staff
                    DB::table('et_task_request')
                        ->where('sno', $id)
                        ->update([
                            'staff_id'   => $request->staff_id,
                            'updated_by' => $userId,
                            'status'     => 4
                        ]);

                    DB::table('et_daily_tasks')->insert([
                        'service_id' => $taskRequest->service_id,
                        'task_id'    => $taskRequest->sno,
                        'staff_id'   => $request->staff_id,
                        'task_date'  => now(),
                        'is_request' => 1,
                        'created_by' => $userId,
                        'updated_by' => $userId
                    ]);
                    break;
            }

            DB::commit();

            return response([
                'status' => 200,
                'message' => 'Task Request Updated Successfully!'
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Server Error!',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
