<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use App\Models\ManageDeliverablesModel;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;


class ManageDeliverables extends Controller
{


  // ... [your existing index method and other methods] ...
  public function index(Request $request)
  {
    $entity_id = $request->user()->entity_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $search_fill = $request->search_fill ?? '';
    $cat_fill = $request->cat_fill ?? '';
    $product_fill = $request->product_fill ?? '';
    $status_fill = $request->status_fill ?? '';
    $filter_on = $request->filter_on ?? '';

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);

    // return $ListTable;
    // Dropdown data
    $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
    $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
    $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
    $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();
    $staffs = DB::table('et_staff')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.status', 0)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.branch_id', $branch_id)
      ->select('et_staff.*', 'et_job_position.job_position_name')
      ->get();

    // MAIN QUERY
    $List = DB::table('et_milestone_mapping')
      ->select(
        'et_customer_services.sno',
        'et_customer_services.customer_id',
        'et_customer_services.service_check',
        'et_customer_services.cre_id',
        'et_customer_services.pc_id',
        'et_customer_services.product_id',
        'et_customer_services.package_id',
        'et_customer_services.product_package',
        'et_customer_services.production_staffs_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer_services.created_at',
        'et_customer_services.published_status',
        'et_customer_services.status',
        'et_customer_services.proposal_id',
        'et_customer_services.variant_variable_ids',
        'et_product.product_name',

        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id AS cus_id',

        'et_product.duration',
        'et_product.duration_in',

        'et_customer_services.journal_check',
        'et_package.actual_duration',

        'cre.staff_name as cre_name',
        'cre.staff_image as cre_image',

        'pc.staff_name as pc_name',
        'pc.staff_image as pc_image',

        DB::raw("GROUP_CONCAT(pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
        DB::raw("GROUP_CONCAT(pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),

        'et_product_category.product_category_name',
        'et_product_category.sno as prd_cat_id',
        'et_product_category.jouranal_check',
      )
      ->where('et_customer_services.branch_id', $branch_id)
      ->where('et_customer_services.work_order_check', 3)
      ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
      ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
      ->leftJoin('et_staff as pro_staff', function ($join) {
        $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno');

    // Filters
    if ($search_fill != '') {
      $List->where(function ($query) use ($search_fill) {
        $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
      });
    }

    if ($cat_fill) $List->where('et_product_category.sno', $cat_fill);
    if ($product_fill) $List->where('et_product.sno', $product_fill);
    if ($status_fill || $status_fill === '0') {
      $List->where('et_customer_services.status', $status_fill);
    }

    $List->groupBy(
      'et_customer_services.sno',
      'et_customer_services.customer_id',
      'et_customer_services.cre_id',
      'et_customer_services.pc_id',
      'et_customer_services.product_id',
      'et_customer_services.package_id',
      'et_customer_services.product_package',
      'et_customer_services.service_check',
      'et_customer_services.production_staffs_id',
      'et_customer_services.branch_id',
      'et_customer_services.work_order_check',
      'et_customer_services.created_at',
      'et_customer_services.published_status',
      'et_customer_services.status',
      'et_customer_services.proposal_id',
      'et_customer_services.variant_variable_ids',

      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id',

      'et_product.duration',
      'et_product.duration_in',
      'et_product.product_name',

      'et_package.actual_duration',

      'et_customer_services.journal_check',
      'cre.staff_name',
      'cre.staff_image',
      'pc.staff_name',
      'pc.staff_image',

      'et_product_category.product_category_name',
      'et_product_category.sno',
      'et_product_category.jouranal_check'
    )
      ->orderBy('et_customer_services.sno', 'DESC')
      ->where('et_milestone_mapping.milestone_status', 1)
      ->where('et_milestone_mapping.delivery_status', 1);


    // Clone query for service IDs
    $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();

    // If no services → show blank page
    if (empty($serviceIds)) {
      $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
        'path' => $request->url(),
        'query' => $request->query(),
      ]);

      return view('content.production_management.manage_deliverables.list', [
        'ListTable' => $emptyPaginator,
        'perpage' => $perpage,
        'search_fill' => $search_fill,
        'Product_cat_list' => $Product_cat_list,
        'Product_ist' => $Product_list,
        'DeliCheck_list' => $DeliCheck_list,
        'staffs' => $staffs,
        'Check_list' => $Check_list,
        'cat_fill' => $cat_fill,
        'product_fill' => $product_fill,
        'status_fill' => $status_fill,
      ]);
    }

    // Task count per service
    $taskCounts = DB::table('et_milestone_mapping')
      ->whereIn('service_id', $serviceIds)
      ->where('status', '!=', 2)
      ->select('service_id', 'task_ids')
      ->get()
      ->groupBy('service_id');

    // Collect all task IDs
    $allTaskIds = [];
    foreach ($taskCounts as $serviceTasks) {
      foreach ($serviceTasks as $m) {
        $ids = json_decode($m->task_ids, true);
        if (is_array($ids)) $allTaskIds = array_merge($allTaskIds, $ids);
      }
    }
    $allTaskIds = array_unique($allTaskIds);

    // Get task names
    $taskNames = [];
    if (!empty($allTaskIds)) {
      $taskNames = DB::table('et_product_task')
        ->whereIn('sno', $allTaskIds)
        ->pluck('task_name', 'sno')
        ->toArray();
    }

    // Milestone data
    $milestoneData = DB::table('et_milestone_mapping')
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->select(
        'et_milestone_mapping.service_id',
        'et_milestone_mapping.sno',
        'et_milestone_mapping.milestone_status',
        'et_milestone_mapping.task_ids',
        'et_payment_slot.payment_slot_name',
        'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount'
      )
      ->whereIn('et_milestone_mapping.service_id', $serviceIds)
      ->where('et_milestone_mapping.status', '!=', 2)
      ->where('et_milestone_mapping.milestone_status', 1)
      ->get()
      ->groupBy('service_id');

    // APPLY PAGINATION
    $ListTable = $List->paginate($perpage);

    // ADD task & milestone data to each row
    foreach ($ListTable as $list) {

      // Total tasks
      $serviceTaskIds = [];
      if (isset($taskCounts[$list->sno])) {
        foreach ($taskCounts[$list->sno] as $milestone) {
          $ids = json_decode($milestone->task_ids, true);
          if (is_array($ids)) $serviceTaskIds = array_merge($serviceTaskIds, $ids);
        }
      }
      $list->total_task_count = count(array_unique($serviceTaskIds));

      // Milestone details
      $milestoneDataWithTasks = [];

      if (isset($milestoneData[$list->sno])) {

        foreach ($milestoneData[$list->sno] as $m) {

          // 1️⃣ Get product-task IDs from milestone JSON
          $productTaskIds = json_decode($m->task_ids, true) ?? [];

          // 2️⃣ Get task names
          $productTasks = DB::table('et_product_task')
            ->whereIn('sno', $productTaskIds)
            ->pluck('task_name')
            ->toArray();

          // 3️⃣ Map to et_task IDs
          $etTaskIds = DB::table('et_task')
            ->where('service_id', $list->sno)
            ->whereIn('task_name', $productTaskIds)
            ->pluck('sno')
            ->toArray();

          // 4️⃣ Get daily tasks
          $dailyTasks = DB::table('et_daily_tasks')
            ->where('service_id', $list->sno)
            ->whereIn('task_id', $etTaskIds)
            ->get();

          $totalDaily = $dailyTasks->count();
          $completedDaily = $dailyTasks->where('status', 4)->count();

          $percentage = ($totalDaily > 0)
            ? round(($completedDaily / $totalDaily) * 100, 2)
            : 0;

          // ---------------------------------------------------
          // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
          // ---------------------------------------------------
          $staffIdsRaw = DB::table('et_pro_milestone_staffs')
            ->where('service_id', $list->sno)
            ->where('milestone_id', $m->sno)
            ->pluck('staff_ids')
            ->toArray();

          $staffIds = [];

          foreach ($staffIdsRaw as $row) {
            // Decode JSON array string like ["25","58"]
            $decoded = json_decode($row, true);

            if (is_array($decoded)) {
              $staffIds = array_merge($staffIds, $decoded);
            }
          }

          // Remove duplicates & reindex
          $staffIds = array_unique($staffIds);

          $staffDetails = [];

          if (!empty($staffIds)) {
            $staffDetails = DB::table('et_staff')
              ->whereIn('sno', $staffIds)
              ->where('status', 0)
              ->select('sno', 'staff_name', 'staff_image')
              ->get()
              ->toArray();
          }


          // ---------------------------------------------------
          // FINAL STRUCTURE
          // ---------------------------------------------------
          $milestoneDataWithTasks[] = (object)[
            'mile_stone_name'        => $m->payment_slot_name,
            'payable_amount'         => $m->payable_amount,
            'paidAmount'             => $m->paidAmount,
            'task_ids'               => $m->task_ids,
            'mile_sno'                    => $m->sno,
            'status'                 => $m->milestone_status,

            // TASKS
            'task_names'             => $productTasks,
            'task_count'             => count($productTasks),

            // DAILY
            'total_daily_tasks'      => $totalDaily,
            'completed_daily_tasks'  => $completedDaily,
            'milestone_percentage'   => $percentage,

            // STAFF
            'assigned_staff'         => $staffDetails,  // array of {sno, staff_name, staff_image}
            'staff_count'            => count($staffDetails)
          ];
        }
      }

      $list->milestone_data = $milestoneDataWithTasks;
    }


    // return $ListTable;
    // Dropdown data
    $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
    $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
    $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
    $staffs = DB::table('et_staff')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.status', 0)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.branch_id', $branch_id)
      ->select('et_staff.*', 'et_job_position.job_position_name')
      ->get();

    return view('content.production_management.manage_deliverables.list', [
      'ListTable' => $ListTable,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'Product_cat_list' => $Product_cat_list,
      'Product_ist' => $Product_list,
      'staffs' => $staffs,
      'Check_list' => $Check_list,
      'DeliCheck_list' => $DeliCheck_list,
      'cat_fill' => $cat_fill,
      'product_fill' => $product_fill,
      'status_fill' => $status_fill,
      'filter_on' => $filter_on,
    ]);
  }
  public function delivery_documentation_data_fetch($id, $mileId)
  {


    $data = DB::table('et_customer_services')
      ->where('et_customer_services.sno', $id)
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
      ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
      ->select(
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.customer_id',
        'et_product.product_name',
        'et_product_category.product_category_name',
        'et_customer_services.sno',
        'et_customer_services.variant_variable_ids',
        'cre.staff_name as cre_name',
        'pc.staff_name as pc_name',
        'cre.staff_image as cre_image',
        'pc.staff_image as pc_image',
        'et_customer_services.created_at'
      )
      ->first();

    $variantVariableIds = json_decode($data->variant_variable_ids, true);

    $variantName = '';
    $variableName = '';

    if (is_array($variantVariableIds)) {
      foreach ($variantVariableIds as $v) {
        $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
        $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

        if ($variant) {
          $variantName = $variant->product_variant_name ?? '';
        }

        if ($variable) {
          $variableName = $variable->variable_name ?? '';
        }
      }
    }

    $year = date('Y', strtotime($data->created_at));
    $formattedId = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
    $data->formatted_service_id = "SR-{$formattedId}/{$year}";

    $data->variant_name = $variantName;
    $data->variable_name = $variableName;

    $milestoneData = DB::table('et_milestone_mapping')
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->select(
        'et_milestone_mapping.service_id',
        'et_milestone_mapping.sno',
        'et_milestone_mapping.milestone_status',
        'et_milestone_mapping.task_ids',
        'et_payment_slot.payment_slot_name',
        'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount'
      )
      ->where('et_milestone_mapping.sno', $mileId)
      ->where('et_milestone_mapping.status', '!=', 2)
      ->where('et_milestone_mapping.milestone_status', 1)
      ->first();



    return response([
      'status' => 200,
      'message' => 'Data fetched successfully!',
      'error_msg' => null,
      'data' => $data,
      'milestone_data' => $milestoneData
    ], 200);
  }

  public function upload(Request $request)
  {
    try {
      $request->validate([
        'file'      => 'required|file|max:5120',
        'mile_sno'  => 'required',
        'deli_id'   => 'required'
      ]);

      $file = $request->file('file');
      $folder = "delivery_temp/{$request->mile_sno}/{$request->deli_id}";
      $uniqueName = Str::random(20) . '.' . $file->getClientOriginalExtension();
      $path = $file->storeAs($folder, $uniqueName, 'public');

      return response()->json([
        'success' => true,
        'files' => [[
          'original_name' => $file->getClientOriginalName(),
          'unique_name'   => $uniqueName,
          'path'          => $path,
          'url'           => asset('storage/' . $path),
          'size'          => $file->getSize(),
          'type'          => $file->getMimeType()
        ]]
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => 'Upload failed: ' . $e->getMessage()
      ], 500);
    }
  }



  /**
   * List existing temp files.
   */
  public function existingFiles(Request $request)
  {
    $mile = $request->input('mile_sno');
    $deli = $request->input('deli_id');

    if (!$mile || !$deli) {
      return response()->json(['success' => false, 'message' => 'Missing parameters']);
    }

    $folder = "delivery_temp/{$mile}/{$deli}";
    $files = [];

    if (Storage::disk('public')->exists($folder)) {
      foreach (Storage::disk('public')->files($folder) as $p) {
        $name = basename($p);
        $files[] = [
          'name'        => $name,
          'unique_name' => $name,
          'path'        => $p,
          'url'         => asset('storage/' . $p),
          'size'        => Storage::disk('public')->size($p),
          'type'        => mime_content_type(storage_path("app/public/{$p}"))
        ];
      }
    }

    return response()->json(['success' => true, 'files' => $files]);
  }

  /**
   * Remove a temp file.
   */
  public function remove(Request $request)
  {
    $path = $request->input('file_path');
    if (!$path) return response()->json(['success' => false, 'message' => 'Missing file path']);

    if (Storage::disk('public')->exists($path)) {
      Storage::disk('public')->delete($path);
      return response()->json(['success' => true, 'message' => 'Deleted']);
    }

    return response()->json(['success' => false, 'message' => 'File not found']);
  }

  /**
   * Final submission: move files from temp → live and save metadata.
   */
  public function finalSubmit(Request $request)
  {
    $mile        = $request->input('mile_sno');
    $customerId  = $request->input('customer_id');
    $checklist   = $request->input('checklist_items', []);

    if (!$mile || !$customerId || !is_array($checklist) || count($checklist) === 0) {
      return response()->json(['success' => false, 'message' => 'Missing parameters']);
    }

    $movedFiles = 0;
    $liveBase   = "delivery/{$mile}";
    $tempBase   = "delivery_temp/{$mile}";

    foreach ($checklist as $deliId) {
      $tempFolder = "{$tempBase}/{$deliId}";
      $liveFolder = "{$liveBase}/{$deliId}";

      if (!Storage::disk('public')->exists($tempFolder)) continue;

      foreach (Storage::disk('public')->files($tempFolder) as $filePath) {
        $filename   = basename($filePath);
        $targetPath = "{$liveFolder}/{$filename}";

        Storage::disk('public')->move($filePath, $targetPath);
        $movedFiles++;

        DB::table('delivery_files')->insert([
          'mile_sno'     => $mile,
          'customer_id'  => $customerId,
          'deli_id'      => $deliId,
          'file_name'    => $filename,
          'file_path'    => $targetPath,
          'file_url'     => asset('storage/' . $targetPath),
          'created_at'   => Carbon::now(),
          'updated_at'   => Carbon::now()
        ]);
      }
    }

    return response()->json([
      'success' => true,
      'message' => "Moved {$movedFiles} files to live folder",
      'file_count' => $movedFiles,
      'checklist_count' => count($checklist)
    ]);
  }
}
