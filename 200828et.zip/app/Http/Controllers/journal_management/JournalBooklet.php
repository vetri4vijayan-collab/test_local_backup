<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\CountryModel;
use App\Models\DomainModel;
use Illuminate\Http\Request;
use App\Models\JournalBookletModel;
use App\Models\JournalIndexModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;


class JournalBooklet extends Controller
{
    public function index(Request $request)
    {

        $filter_on = $request->filter_on ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $domain_fill = $request->domain_fill ?? '';
        $index_fill = $request->index_fill ?? '';
        $payment_type_fill = $request->payment_type_fill ?? '';
        $search_fill = $request->search_fill ?? '';

        $branch_id = $request->user()->branch_id;

        $query = JournalBookletModel::where('et_journal_booklet.status', '!=', 2)
            ->select(
                'et_journal_booklet.*',
                'et_countries.name',
                'et_country_currencies.currency_name',
                'et_country_currencies.currency_symbol',
            )
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_journal_booklet.country_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_journal_booklet.currency_id')
            ->orderBy('et_journal_booklet.sno', 'desc')
            ->where('branch_id', $branch_id);

        if (!empty($domain_fill)) {
            $query->whereJsonContains('domain_id', (string) $domain_fill);
        }

        if (!empty($index_fill)) {
            $query->whereJsonContains('journal_score', ['journal_index_id' => (string)$index_fill]);
        }
        if ($payment_type_fill != '') {
            $query->where('et_journal_booklet.free_paid_check', $payment_type_fill);
        }

        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_journal_booklet.journal_name', 'LIKE', "%{$search_fill}%");
            });
        }


        $books = $query->paginate($perpage);

        $domains = DomainModel::where('status', '!=', 2)->get();

        $indices = JournalIndexModel::where('status', '!=', 2);

        if (!empty($index_fill)) {
            $indices->where('sno', $index_fill);
        }

        $indices = $indices->orderBy('sno', 'desc')->get();

        $filter_index = JournalIndexModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return view('content.journal_management.journal_booklet.list', compact(
            'books',
            'domains',
            'indices',
            'filter_on',
            'perpage',
            'domain_fill',
            'index_fill',
            'payment_type_fill',
            'filter_index',
            'search_fill'
        ));
    }


    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'journal_name' => 'required|string|max:255',
            'journal_desc' => 'nullable'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 404);
        }

        $name = $request->journal_name;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $contactDetails = [];

        $contacts = $request->input('contact');
        $emails = $request->input('email');

        for ($i = 0; $i < count($contacts); $i++) {
            $contactDetails[] = [
                'contact_no' => $contacts[$i],
                'email' => $emails[$i]
            ];
        }

        $rawindices = $request->input('journal_indices', []);
        $formattedIndices = [];

        foreach ($rawindices as $indexData) {
            if (!empty($indexData['id']) && isset($indexData['score'])) {
                $formattedIndices[] = [
                    'journal_index_id' => $indexData['id'],
                    'score' => $indexData['score']
                ];
            }
        }

        $check = JournalBookletModel::where('journal_name', $name)->where('status', '!=', 2)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $journalBooklet = new JournalBookletModel();
        $journalBooklet->journal_name = $name;
        $journalBooklet->publisher = $request->publisher;
        $journalBooklet->journal_link = $request->journal_link;
        $journalBooklet->domain_id = json_encode($request->domain_id);
        $journalBooklet->contact_details = json_encode($contactDetails);
        $journalBooklet->journal_desc = $request->journal_desc;
        $journalBooklet->journal_score = json_encode($formattedIndices);
        $journalBooklet->country_id = $request->country_id;
        $journalBooklet->currency_id = $request->currency_id;
        $journalBooklet->free_paid_check = $request->payment_type ?? 0;
        $journalBooklet->amount = $request->journal_amount;
        $journalBooklet->issn = $request->journal_issn;
        $journalBooklet->created_by = $user_id;
        $journalBooklet->updated_by = $user_id;
        $journalBooklet->branch_id = $branch_id;
        $journalBooklet->save();

        if ($journalBooklet) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Journal Booklet Created Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Journel Booklet Creation Failed !'
            ]);
        }

        return redirect()->back();
    }

    public function view($id)
    {

        $book = JournalBookletModel::where('et_journal_booklet.status', '!=', 2)
            ->select(
                'et_journal_booklet.*',
                'et_countries.name',
                'et_country_currencies.currency_name',
                'et_country_currencies.currency_symbol',
            )
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_journal_booklet.country_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_journal_booklet.currency_id')
            ->where('et_journal_booklet.sno', $id)
            ->first();

        $book->domain_id = json_decode($book->domain_id, true);
        $book->contact_details = json_decode($book->contact_details, true);
        $book->journal_score = json_decode($book->journal_score, true);

        $domains = DomainModel::whereIn('sno', $book->domain_id ?? [])->pluck('domain_name', 'sno');
        $indices = JournalIndexModel::get()->keyBy('sno');

        return response()->json([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => [
                'book' => $book,
                'domains' => $domains,
                'indices' => $indices,
            ]
        ]);
    }

    public function Edit($id)
    {

        $book = JournalBookletModel::findOrFail($id);

        $book->domain_id = json_decode($book->domain_id, true);
        $book->contact_details = json_decode($book->contact_details, true);
        $book->journal_score = json_decode($book->journal_score, true);

        $domains = DomainModel::whereIn('sno', $book->domain_id ?? [])->pluck('domain_name', 'sno');
        $indices = JournalIndexModel::get()->keyBy('sno');

        return response()->json([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => [
                'book' => $book,
                'domains' => $domains,
                'indices' => $indices,
            ]
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_journal_name' => 'required|string|max:255',
            'edit_journal_desc' => 'nullable'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 404);
        }

        $name = $request->edit_journal_name;
        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $contactDetails = [];

        $contacts = $request->input('edit_contact_no');
        $emails = $request->input('edit_email');

        for ($i = 0; $i < count($contacts); $i++) {
            $contactDetails[] = [
                'contact_no' => $contacts[$i],
                'email' => $emails[$i]
            ];
        }

        $rawindices = $request->input('edit_journal_indices', []);
        $formattedIndices = [];

        foreach ($rawindices as $indexData) {
            if (!empty($indexData['id']) && isset($indexData['score'])) {
                $formattedIndices[] = [
                    'journal_index_id' => $indexData['id'],
                    'score' => $indexData['score']
                ];
            }
        }

        $check = JournalBookletModel::where('journal_name', $name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $journalBooklet = JournalBookletModel::where('sno', $sno)->first();
        $journalBooklet->journal_name = $name;
        $journalBooklet->publisher = $request->edit_publisher;
        $journalBooklet->journal_link = $request->edit_journal_link;
        $journalBooklet->domain_id = json_encode($request->edit_domain_id);
        $journalBooklet->contact_details = json_encode($contactDetails);
        $journalBooklet->journal_desc = $request->edit_journal_desc;
        $journalBooklet->country_id = $request->edit_country_id;
        $journalBooklet->currency_id = $request->edit_currency_id;
        $journalBooklet->free_paid_check = $request->edit_payment_type;
        $journalBooklet->issn = $request->edit_journal_issn;
        $journalBooklet->amount = $request->edit_journal_amount;
        $journalBooklet->journal_score = json_encode($formattedIndices);
        $journalBooklet->updated_by = $user_id;
        $journalBooklet->update();

        if ($journalBooklet) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Journal Booklet Updated Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Journel Booklet Updation Failed !'
            ]);
        }

        return redirect()->back();
    }
    public function list()
    {
        $data = JournalBookletModel::where('status', 0)
            ->get();

        return response([
            'status' => 200,
            'message' => 'Journal booklet fetched...',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }
    public function get_domain_name_and_count()
    {
        $result = DB::table('et_domain')
            ->select(
                'et_domain.sno',
                'et_domain.domain_name',
                DB::raw('COUNT(et_journal_booklet.sno) as booklet_count')
            )
            ->leftJoin('et_journal_booklet', function ($join) {
                $join->on(DB::raw('JSON_CONTAINS(et_journal_booklet.domain_id, CONCAT(\'"\', et_domain.sno, \'"\') )'), '=', DB::raw('1'));
            })
            ->where('et_domain.status', 0)
            ->groupBy('et_domain.sno', 'et_domain.domain_name')
            ->get();

        return response([
            'status' => 200,
            'message' => 'Booklet Count Fetched Successfully',
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    public function get_index_name_and_count()
    {
        $result = DB::table('et_journal_index')
            ->select(
                'et_journal_index.sno',
                'et_journal_index.index_name',
                DB::raw('COUNT(et_journal_booklet.sno) as booklet_count')
            )
            ->leftJoin('et_journal_booklet', function ($join) {
                $join->on(
                    DB::raw("JSON_SEARCH(et_journal_booklet.journal_score, 'one', CAST(et_journal_index.sno AS CHAR))"),
                    'IS NOT',
                    DB::raw('NULL')
                );
            })
            ->where('et_journal_index.status', 0)
            ->groupBy('et_journal_index.sno', 'et_journal_index.index_name')
            ->get();

        return response([
            'status' => 200,
            'message' => 'Booklet Count Fetched Successfully',
            'error_msg' => null,
            'data' => $result
        ], 200);
    }
}