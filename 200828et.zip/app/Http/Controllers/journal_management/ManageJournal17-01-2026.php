<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\JournalBookletModel;
use App\Models\JournalHistoryModel;
use App\Models\ManageJournalModel;
use App\Models\PassLockerModel;
use App\Models\StaffModel;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;

class ManageJournal extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id;
        $search_fill = $request->search_fill ?? '';
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;
        $statusFilter = $request->input('status');

        // Build main query for customer services
        $query = DB::table('et_customer_services')
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.branch_id', $branch_id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.journal_index',
                'et_customer_services.proposal_id',
                'et_customer.sno as journal_customer_id',
                'et_customer_services.jc_id',
                'et_customer_services.jc_staff',
                'journal_staff.staff_name as journal_staff_name',
                'journal_coordinator.staff_name as jouranal_coordinator_name',
                'journal_staff.staff_image as journal_staff_image',
                'journal_coordinator.staff_image as jouranal_coordinator_image',
                DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name")
            );

        // Apply status filter if provided - only show services that have journal entries with this status
        if ($statusFilter !== null) {
            $query->whereExists(function ($query) use ($branch_id, $statusFilter) {
                $query->select(DB::raw(1))
                    ->from('et_manage_journal')
                    ->whereRaw('et_manage_journal.service_id = et_customer_services.sno')
                    ->whereRaw('et_manage_journal.customer_id = et_customer.sno')
                    ->where('et_manage_journal.branch_id', $branch_id)
                    ->where('et_manage_journal.status', $statusFilter);
            });
        }

        // Apply user permissions
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            // User can only view their own data
            if ($user_role == 34) {
                $query = $query->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $query = $query->where('et_customer_services.jc_id', $user_id);
            }
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
            // User can view all data - no additional filter needed
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }

        // Apply search filter
        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // Instead of GROUP BY, use DISTINCT to get unique records
        $query->distinct('et_customer_services.sno');

        // Paginate results
        $lists = $query->paginate($perpage);

        // ========== COUNT QUERIES ==========

        // Submitted Count
        $submittedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 0);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $submittedCount = $submittedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $submittedCount = $submittedCount->where('et_customer_services.jc_id', $user_id);
            }
        } elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
            abort(403, 'Unauthorized');
        }

        $submittedCount = $submittedCount->count();

        // Reviewed Count
        $reviewedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 4);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $reviewedCount = $reviewedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $reviewedCount = $reviewedCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $reviewedCount = $reviewedCount->count();

        $withEditorCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 1);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $withEditorCount = $withEditorCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $withEditorCount = $withEditorCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $withEditorCount = $withEditorCount->count();

        $underReviewerCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 3);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $underReviewerCount = $underReviewerCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $underReviewerCount = $underReviewerCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $underReviewerCount = $underReviewerCount->count();

        $eproofingCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 7);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $eproofingCount = $eproofingCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $eproofingCount = $eproofingCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $eproofingCount = $eproofingCount->count();

        // Resubmitted Count
        $resubmittedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 3);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $resubmittedCount = $resubmittedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $resubmittedCount = $resubmittedCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $resubmittedCount = $resubmittedCount->count();

        // Accepted Count
        $acceptedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 5);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $acceptedCount = $acceptedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $acceptedCount = $acceptedCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $acceptedCount = $acceptedCount->count();

        // Rejected Count
        $rejectedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 6);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $rejectedCount = $rejectedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $rejectedCount = $rejectedCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $rejectedCount = $rejectedCount->count();

        // Published Count
        $publishedCount = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', 8);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $publishedCount = $publishedCount->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $publishedCount = $publishedCount->where('et_customer_services.jc_id', $user_id);
            }
        }

        $publishedCount = $publishedCount->count();

        // ========== PROCESS EACH SERVICE ==========

        foreach ($lists as $list) {
            // Get domain names from helper
            $domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
            $list->domain_names = $domain_names;

            // Process journal index
            if (!empty($list->journal_index)) {
                $decoded = json_decode($list->journal_index, true);

                if (is_array($decoded)) {
                    $index_ids = $decoded;
                } elseif (is_numeric($list->journal_index)) {
                    $index_ids = [(int)$list->journal_index];
                } else {
                    $index_ids = [];
                }

                if (!empty($index_ids)) {
                    $index_names = DB::table('et_journal_index')
                        ->whereIn('sno', $index_ids)
                        ->where('status', 0)
                        ->pluck('index_name')
                        ->toArray();

                    $list->index_names = !empty($index_names)
                        ? implode(', ', $index_names)
                        : 'No Index';
                } else {
                    $list->index_names = 'No Index';
                }
            } else {
                $list->index_names = 'No Index';
            }

            // Generate service ID
            $year = date('Y', strtotime($list->created_at));
            $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            // Get journal data for this service
            $journalDataQuery = DB::table('et_manage_journal')
                ->where('et_manage_journal.service_id', $list->sno)
                ->where('et_manage_journal.customer_id', $list->journal_customer_id)
                ->where('et_manage_journal.branch_id', $branch_id)
                ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
                ->select(
                    'et_journal_booklet.journal_name',
                    'et_journal_booklet.domain_id',
                    'et_manage_journal.status',
                    'et_manage_journal.paper_name',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.submited_date',
                    'et_manage_journal.sno',
                    'et_manage_journal.publish_author',
                    'et_manage_journal.published_paper_name',
                    'et_manage_journal.publish_url',
                    'et_manage_journal.publish_date'
                );

            // Apply status filter to journal data if selected
            if ($statusFilter !== null) {
                $journalDataQuery->where('et_manage_journal.status', $statusFilter);
            }

            $list->journal_data = $journalDataQuery->get();

            // Process domain names for each journal
            foreach ($list->journal_data as $journal) {
                if ($journal->domain_id) {
                    $domain_ids = json_decode($journal->domain_id, true);

                    if (is_array($domain_ids) && !empty($domain_ids)) {
                        $domain_names = DB::table('et_domain')
                            ->whereIn('et_domain.sno', $domain_ids)
                            ->where('et_domain.status', 0)
                            ->pluck('domain_name')
                            ->toArray();

                        $journal->domain_names = $domain_names;
                    } else {
                        $journal->domain_names = [];
                    }
                } else {
                    $journal->domain_names = [];
                }
            }
        }

        // Return view with all data
        return view('content.journal_management.manage_journal.list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill,
            'submittedCount' => $submittedCount,
            'reviewedCount' => $reviewedCount,
            'resubmittedCount' => $resubmittedCount,
            'underReviewerCount' => $underReviewerCount,
            'eproofingCount' => $eproofingCount,
            'withEditorCount' => $withEditorCount,
            'acceptedCount' => $acceptedCount,
            'rejectedCount' => $rejectedCount,
            'publishedCount' => $publishedCount,
            'currentStatus' => $statusFilter
        ]);
    }

    public function addDataFetch($id)
    {
        $fetch = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->where('et_customer_services.journal_check', 1)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_customer.sno as cus_sno',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name")
            )
            ->first();

        $year = date('Y', strtotime($fetch->created_at));
        $id = str_pad($fetch->sno, 5, '0', STR_PAD_LEFT);
        $fetch->service_id = "SR-{$id}/{$year}";

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $fetch
        ], 200);
    }

    public function uploadFiles(Request $request)
    {
        $request->validate([
            'file_upload.*' => 'required|file|max:10240' // max 10MB
        ]);

        $uploaded = [];

        foreach ($request->file('file_upload') as $file) {

            $timestamp = now()->format('Ymd_His'); // e.g., 20250618_142530
            $extension = $file->getClientOriginalExtension();

            // Create a unique filename using timestamp and a unique ID
            $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

            // Move the file
            $file->move(public_path('journals'), $fileName);

            $uploaded[] = $fileName;
        }

        return response()->json([
            'success' => true,
            'files' => $uploaded
        ]);
    }

    public function Create(Request $request)
    {
        try {
            $validated = $request->validate([
                'paper_name' => 'required|string|max:255',
                'journal_booklet_id' => 'required|integer',
                'customer_services_id' => 'required|integer',
                'customer_id' => 'required|integer',
            ]);

            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $submittedDate = $request->submitted_date ? date('Y-m-d', strtotime($request->submitted_date)) : now();

            DB::beginTransaction();

            // ! GENERATE JOURNAL ID
            $latest_journal = DB::table('et_manage_journal')
                ->where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();

            $year = date("Y");

            if (!$latest_journal) {
                $journal_id = "JOR0001" . '/' . $year;
            } else {
                $latest_journal_id = $latest_journal->journal_id;
                $parts = explode("/", $latest_journal_id);
                $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
                $nextNumber = (int)$numericPart + 1; // 8
                $journal_id = sprintf("JOR%04d/%s", $nextNumber, $year);
            }

            $journal = ManageJournalModel::create([
                'branch_id' => $branch_id,
                'service_id' => $validated['customer_services_id'],
                'customer_id' => $validated['customer_id'],
                'journal_id' => $journal_id,
                'booklet_id' => $validated['journal_booklet_id'],
                'paper_name' => $validated['paper_name'],
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'submited_date' => $submittedDate
            ]);

            DB::table('et_manage_journal')
                ->where('sno', $journal->sno)
                ->increment('submitted_count', 1);

            if (!$journal) {
                throw new Exception('Failed to submit journal.');
            }

            if ($request->filled('uploaded_files')) {
                $files = json_decode($request->uploaded_files, true);
                $journal->documents = json_encode($files);
                $journal->save();
            }

            if ($journal) {
                $history = new JournalHistoryModel();
                $history->branch_id = $branch_id;
                $history->customer_id = $validated['customer_id'];
                $history->service_id = $validated['customer_services_id'];
                $history->journal_id = $journal->sno;
                $history->submitted_date = $submittedDate;
                $history->submitted_documents = $journal->documents;
                $history->created_by = $user_id;
                $history->updated_by = $user_id;
                $history->save();
            }

            if (!$history) {
                throw new Exception('Failed to create history.');
            }

            $emails = $request->input('email', []);
            $passwords = $request->input('password', []);

            if (is_array($emails) && is_array($passwords)) {
                foreach ($emails as $index => $email) {
                    $password = $passwords[$index] ?? null;
                    if (empty($email) || empty($password)) {
                        continue;
                    }

                    $credential = new PassLockerModel();
                    $credential->journal_id = $journal->sno;
                    $credential->customer_id = $validated['customer_id'];
                    $credential->user_name = $email;
                    $credential->password = $password;
                    $credential->created_by = $user_id;
                    $credential->updated_by = $user_id;
                    $credential->status = 1;
                    $credential->save();
                }
            }

            DB::commit();

            return response([
                'status' => 200,
                'message' => 'Journal Submitted Successfully!',
                'data' => null
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();

            return response([
                'status' => 422,
                'message' => 'Validation Failed',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 422);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Failed to submit journal.',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function view($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;

        $view = DB::table('et_customer_services')
            ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_email_id',
                'et_customer.cus_mobile',
                'et_customer.country_code',
                'et_product.product_name',
                'et_customer_services.proposal_id',
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.journal_index',
                'et_product_category.product_category_name',
            )
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.sno', $id)
            ->first();

        $journals = DB::table('et_manage_journal')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.service_id', $id)
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->select(
                'et_manage_journal.submitted_count',
                'et_manage_journal.reviewed_count',
                'et_manage_journal.resubmitted_count',
                'et_manage_journal.accepted_count',
                'et_manage_journal.reject_count',
                'et_manage_journal.published_count',
                'et_manage_journal.documents',
                'et_manage_journal.sno',
                'et_manage_journal.paper_name',
                'et_manage_journal.status',
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id'
            )
            ->get();

        $view->submitted_count = $journals->sum('submitted_count');
        $view->reviewed_count = $journals->sum('reviewed_count');
        $view->resubmitted_count = $journals->sum('resubmitted_count');
        $view->accepted_count = $journals->sum('accepted_count');
        $view->reject_count = $journals->sum('reject_count');
        $view->published_count = $journals->sum('published_count');

        $domain_names = $helper->get_domain_by_proposalId($view->proposal_id);
        $view->domain_names = $domain_names;

        if (!empty($view->journal_index)) {

            $decoded = json_decode($view->journal_index, true);

            // CASE 1: valid JSON array
            if (is_array($decoded)) {
                $index_ids = $decoded;
            }
            // CASE 2: single integer or numeric string
            elseif (is_numeric($view->journal_index)) {
                $index_ids = [(int)$view->journal_index];
            }
            // CASE 3: anything else → invalid
            else {
                $index_ids = [];
            }

            if (!empty($index_ids)) {
                $index_names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $view->index_names = !empty($index_names)
                    ? implode(', ', $index_names)
                    : 'No Index';
            } else {
                $view->index_names = 'No Index';
            }
        } else {
            $view->index_names = 'No Index';
        }

        $year = date('Y', strtotime($view->created_at));
        $id = str_pad($view->sno, 5, '0', STR_PAD_LEFT);
        $view->service_id = "SR-{$id}/{$year}";

        foreach ($journals as $journal) {
            $domainIds = json_decode($journal->domain_id, true);
            if (is_array($domainIds)) {
                $domains = DB::table('et_domain')->whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
                $journal->domain_names = $domains;
            } else {
                $journal->domain_names = [];
            }

            $status = "";
            $bg = "";
            $text = "";

            if ($journal->status == 0) {
                $status = "Submitted";
                $bg = "007BFF";
                $text = "white";
            } elseif ($journal->status == 1) {
                $status = "Reviewed";
                $bg = "FFA500";
                $text = "black";
            } elseif ($journal->status == 3) {
                $status = "Resubmitted";
                $bg = "800080";
                $text = "white";
            } elseif ($journal->status == 4) {
                $status = "Accepted";
                $bg = "28A745";
                $text = "white";
            } elseif ($journal->status == 5) {
                $status = "Rejected";
                $bg = "DC3545";
                $text = "white";
            } elseif ($journal->status == 6) {
                $status = "Published";
                $bg = "FFA500";
                $text = "white";
            }

            $journal->statusHTML = $status;
            $journal->background_color = $bg;
            $journal->text_color = $text;

            $submittedFiles = json_decode($journal->documents, true);
            $journal->submitted_files = is_array($submittedFiles) ? $submittedFiles : [];

            $journalStatus = DB::table('et_journal_history')
                ->where('et_journal_history.journal_id', $journal->sno)
                ->select('et_journal_history.*')
                ->orderBy('et_journal_history.created_at', 'DESC')
                ->get();


            foreach ($journalStatus as $status) {

                $statusText = "";
                $bg = "";
                $text = "";

                if ($status->status == 0) {
                    $statusText = "Submitted";
                    $bg = "007BFF";
                    $text = "white";
                } elseif ($status->status == 1) {
                    $statusText = "Reviewed";
                    $bg = "FFA500";
                    $text = "black";
                } elseif ($status->status == 3) {
                    $statusText = "Resubmitted";
                    $bg = "800080";
                    $text = "white";
                } elseif ($status->status == 4) {
                    $statusText = "Accepted";
                    $bg = "28A745";
                    $text = "white";
                } elseif ($status->status == 5) {
                    $statusText = "Rejected";
                    $bg = "DC3545";
                    $text = "white";
                } elseif ($status->status == 6) {
                    $statusText = "Published";
                    $bg = "FFA500";
                    $text = "white";
                }

                $status->statusHTML = $statusText;
                $status->bg = $bg;
                $status->text = $text;

                $published_files = json_decode($status->published_files, true);
                $status->published_files = is_array($published_files) ? $published_files : [];

                $reviewed_files = json_decode($status->reviewer_document, true);
                $status->reviewed_files = is_array($reviewed_files) ? $reviewed_files : [];
            }

            $journal->journalStatus = $journalStatus;
        }
        $view->journals = $journals;

        // return $view;


        return view('content.journal_management.manage_journal.view', [
            'view' => $view,
            'id' => $decryptedValue,
        ]);
    }

    public function AssignDataFetch($id)
    {
        $fetch = DB::table('et_customer_services')
            ->where('et_customer_services.journal_check', 1)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->select(
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_customer.sno as cus_sno',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name")
            )
            ->where('et_customer_services.sno', $id)
            ->first();

        $year = date('Y', strtotime($fetch->created_at));
        $id = str_pad($fetch->sno, 5, '0', STR_PAD_LEFT);
        $fetch->service_id = "SR-{$id}/{$year}";

        $staff = StaffModel::select('et_staff.sno', 'et_staff.staff_name', 'et_staff.department_id as dept_id', 'et_job_position.job_position_name as position_name')->where('et_staff.status', 0)->where('et_staff.sno', '>', 1)->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $fetch,
            'staff' => $staff
        ], 200);
    }

    public function AddJournalStaff(Request $request)
    {

        $serviceId = $request->assgn_service_id;
        $staffId = $request->assgn_staff_id;

        $AddStaff = DB::table('et_customer_services')->where('sno', $serviceId)->update(['jc_staff' => $staffId]);

        if ($AddStaff) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Staff Assigned Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Staff Assigned Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function journalList(Request $request)
    {

        $books = JournalBookletModel::where('status', '!=', 2)->get();
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $query = DB::table('et_customer_services')
            ->where('et_customer_services.status', 8)
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.branch_id', $branch_id)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.customer_services_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_journal_history', 'et_journal_history.customer_services_id', '=', 'et_manage_journal.sno')
            ->leftJoin('et_staff as js_id', 'js_id.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as jc_id', 'jc_id.sno', '=', 'et_customer_services.jc_id')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_manage_journal.sno as manage_sno',
                'et_manage_journal.submitted_count',
                'et_manage_journal.review_count',
                'et_manage_journal.resubmitted_count',
                'et_manage_journal.accepted_count',
                'et_manage_journal.rejected_count',
                'et_manage_journal.published_count',
                'js_id.staff_name as js_name',
                'jc_id.staff_name as jc_name',
                'js_id.staff_image as js_image',
                'jc_id.staff_image as jc_image',
                DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name"),
                DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                ELSE NULL
            END as category_name")
            );

        $fill_chk = $request->fill_chk ?? 0;
        $customer_fill = $request->customer_fill ?? '';
        $customer_id_fill = $request->customer_id_fill ?? '';
        $booklet_fill = $request->booklet_fill ?? '';
        $paper_fill = $request->paper_fill ?? '';

        if ($customer_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%");
        }
        if ($customer_id_fill) {
            $query->where('et_customer.customer_id', 'LIKE', "%{$customer_id_fill}%");
        }
        if ($paper_fill) {
            $query->where('et_journal_history.paper_name', 'LIKE', "%{$paper_fill}%");
        }
        if ($booklet_fill) {
            $query->where('et_journal_history.journal_booklet_id', $booklet_fill);
        }

        $fetch = $query->orderBy('et_customer_services.sno', 'desc')->paginate($perpage);



        $pageConfigs = ['myLayout' => 'default'];
        if ($fill_chk == 1) {
            $fill = true;
        } else {
            $fill = false;
        }

        return view('content.journal_management.journal_list', compact('fetch', 'books', 'perpage', 'customer_fill', 'paper_fill', 'booklet_fill', 'customer_id_fill', 'pageConfigs'))->with('filter_on', $fill);
    }

    public function getJournalBookletData()
    {
        $data = JournalBookletModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function getJournalReviewData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name"),
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name"),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && !empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function journalReviewStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $reviewedDate = $request->reviewed_date 
            ? date('Y-m-d', strtotime($request->reviewed_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $comment = $request->reviewer_comment;

            $files = [];
            if ($request->filled('reviewed_files')) {
                $files = json_decode($request->reviewed_files, true);
            }

            $updateData = [
                'reviewer_comment' => $comment,
                'reviewed_document' => !empty($files) ? json_encode($files) : null,
                'reviewed_at' => $reviewedDate,
                'status' => 4,
                'reviewed_count' => DB::raw('reviewed_count + 1')
            ];

            $journal = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->reviewed_date = $reviewedDate;
            $history->reviewer_comment = $comment;
            $history->reviewer_document = !empty($files) ? json_encode($files) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 4;
            $history->save();

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' =>  $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 4,
                    'documents' => !empty($files) ? json_encode($files) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Review submitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function journalWithEditorStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $withEditorDate = $request->with_editor_date
            ? date('Y-m-d', strtotime($request->with_editor_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $comment = $request->with_editor_comment;

            $files = [];
            if ($request->filled('with_editor_files')) {
                $files = json_decode($request->with_editor_files, true);
            }

            $updateData = [
                'status' => 1,
                'with_editor_count' => DB::raw('with_editor_count + 1'),
                'updated_by' => $user_id
            ];

            $journal = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->with_editor_date = $withEditorDate;
            $history->with_editor_comment = $comment;
            $history->with_editor_documents = !empty($files) ? json_encode($files) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 1;
            $history->save();

            if($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id'=> $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' =>  $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 1,
                    'documents' => !empty($files) ? json_encode($files) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Review submitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function journalUnderReviewerStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $under_reviewer_date = $request->under_reviewer_date
            ? date('Y-m-d', strtotime($request->under_reviewer_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $comment = $request->under_reviewer_comment;

            $files = [];
            if ($request->filled('under_reviewer_files')) {
                $files = json_decode($request->under_reviewer_files, true);
            }

            $updateData = [
                'status' => 3,
                'under_reviewer_count' => DB::raw('under_reviewer_count + 1'),
                'updated_by' => $user_id
            ];

            $journal = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->under_reviewer_date = $under_reviewer_date;
            $history->under_reviewer_comment = $comment;
            $history->under_reviewer_documents = !empty($files) ? json_encode($files) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 3;
            $history->save();

            if($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id'=> $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' =>  $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 3,
                    'documents' => !empty($files) ? json_encode($files) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Under Reviewer Status submitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getJournalResubmitData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name"),
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name"),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && !empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function journalResubmitStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $resubmittedDate = $request->resubmitted_date 
            ? date('Y-m-d', strtotime($request->resubmitted_date))
            : now();

        try {
            DB::beginTransaction();

            $resubmit = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$resubmit) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $updateData = [
                'resubmitted_at' => $resubmittedDate,
                'status' => 3,
                'resubmitted_count' => DB::raw('resubmitted_count + 1')
            ];

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $resubmit->customer_id;
            $history->service_id = $resubmit->service_id;
            $history->journal_id = $resubmit->sno;
            $history->resubmitted_date = $resubmittedDate;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 3;
            $history->save();

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getJournalAcceptData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name"),
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name"),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && !empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function journalAcceptStatus($id, Request $request)
    {

                $branch_id = $request->user()->branch_id;
                $user_id = $request->user()->user_id;
                $accepted_date = $request->accepted_date
                    ? date('Y-m-d', strtotime($request->accepted_date))
                    : now();

                try {

                    DB::beginTransaction();

                    $review = DB::table('et_manage_journal')
                        ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                        ->select(
                            'et_manage_journal.*',
                            'et_customer_services.jc_id',
                            'et_customer_services.jc_staff'
                        )
                        ->where('et_manage_journal.sno', $id)
                        ->where('et_manage_journal.status', '!=', 2)
                        ->first();

                    if (!$review) {
                        return response([
                            'status' => 404,
                            'message' => 'Record not found',
                            'error_msg' => 'Record not found'
                        ], 404);
                    }

                    $comment = $request->accepted_comment;

                    $files = [];
                    if ($request->filled('accepted_files')) {
                        $files = json_decode($request->accepted_files, true);
                    }

                    $updateData = [
                        'accepted_at' => $accepted_date,
                        'status' => 5,
                        'accepted_count' => DB::raw('accepted_count + 1')
                    ];

                    $journal = DB::table('et_manage_journal')
                        ->where('sno', $id)
                        ->update($updateData);

                    $history = new JournalHistoryModel();
                    $history->branch_id = $branch_id;
                    $history->customer_id = $review->customer_id;
                    $history->service_id = $review->service_id;
                    $history->journal_id = 5;
                    $history->accepted_date = $accepted_date;
                    $history->accepted_comment = $comment;
                    $history->accepted_document = !empty($files) ? json_encode($files) : null;
                    $history->created_by = $user_id;
                    $history->updated_by = $user_id;
                    $history->status = 5;
                    $history->save();

                    if ($history) {
                        DB::table('et_journal_revision')->insert([
                            'journal_id' => $review->sno,
                            'service_id' => $review->service_id,
                            'customer_id' => $review->customer_id,
                            'jc_id' =>  $review->jc_staff,
                            'jtl_id' => $review->jc_id ?? 0,
                            'journal_status' => $review->status,
                            'documents' => !empty($files) ? json_encode($files) : null,
                            'comments' => $comment,
                            'created_by' => $user_id,
                            'updated_by' => $user_id
                        ]);
                    }

                DB::commit();

                return response()->json([
                    'status' => 200,
                    'message' => 'Journal resubmitted successfully!',
                    'data' => $updateData
                ], 200);
            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json([
                    'status' => 500,
                    'message' => 'Failed to submit review',
                    'error' => $e->getMessage()
                ], 500);
            }
    }

    public function getJournalRejectData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->where('et_manage_journal.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name"),
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name"),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && !empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function journalRejectStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $rejectedDate = $request->rejected_date 
            ? date('Y-m-d', strtotime($request->rejected_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $comment = $request->reject_reason;

            $files = [];
            if ($request->filled('rejected_files')) {
                $files = json_decode($request->rejected_files, true);
            }

            $updateData = [
                'rejected_at' => $rejectedDate,
                'status' => 6,
                'reject_count' => DB::raw('reject_count + 1')
            ];

            $journal = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->accepted_date = $rejectedDate;
            $history->accepted_comment = $comment;
            $history->accepted_document = !empty($files) ? json_encode($files) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 6;
            $history->save();

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' =>  $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 6,
                    'documents' => !empty($files) ? json_encode($files) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function journalEProofingStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $e_proofing_date = $request->e_proofing_date
            ? date('Y-m-d', strtotime($request->e_proofing_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $comment = $request->reject_reason;

            $files = [];
            if ($request->filled('e_proofing_files')) {
                $files = json_decode($request->e_proofing_files, true);
            }

            $updateData = [
                'status' => 7,
                'e_proofing_count' => DB::raw('e_proofing_count + 1')
            ];

            $journal = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->e_proofing_date = $e_proofing_date;
            $history->e_proofing_comments = $comment;
            $history->e_proofing_documents = !empty($files) ? json_encode($files) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 7;
            $history->save();

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' =>  $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 7,
                    'documents' => !empty($files) ? json_encode($files) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getJournalPublishData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->where('et_manage_journal.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name"),
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name"),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && !empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data
        ], 200);
    }

    public function journalPublishStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        try {

            DB::beginTransaction();

            $publish = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (!$publish) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found'
                ], 404);
            }

            $publish_date = date('Y-m-d', strtotime($request->publish_date));
            $paper_name = $request->paper_name;
            $publish_url = $request->publish_url;
            $publish_author = $request->publish_author;

            $files = [];
            if ($request->filled('published_files')) {
                $files = json_decode($request->published_files, true);
            }

            $updateData = [
                'publish_date' => $publish_date,
                'published_paper_name' => $paper_name,
                'publish_url' => $publish_url,
                'publish_author' => $publish_author,
                'published_files' => !empty($files) ? json_encode($files) : null,
                'published_at' => now(),
                'status' => 8,
                'published_count' => DB::raw('published_count + 1')
            ];

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);
            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $publish->customer_id;
            $history->service_id = $publish->service_id;
            $history->journal_id = $publish->sno;
            $history->published_date = date('Y-m-d', strtotime($request->publish_date));
            $history->published_files = !empty($files) ? json_encode($files) : null;
            $history->published_author = $publish_author;
            $history->published_url = $publish_url;
            $history->publiched_paper = $paper_name;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 8;
            $history->save();

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal published successfully!',
                'data' => $updateData
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit publish',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    
}
