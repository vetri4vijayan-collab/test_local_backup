<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use App\Models\LedgerModel;
use Illuminate\Http\Request;
use App\Models\PaymentSlotModel;
use Illuminate\Support\Facades\Validator;

class Payment_Slot extends Controller{
    public function index(){
        $paymentSlots = PaymentSlotModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.product_settings.payment_slot', compact('paymentSlots'));
    }

    public function create(Request $request){
        $validator = Validator::make($request->all(), [
            'payment_slot_name' => 'required|string',
            'payment_slot_des' => 'nullable|string|max:255',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Format input field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $payment_name = $request->payment_slot_name;
        $payment_des = $request->payment_slot_des;

        $check = PaymentSlotModel::where('payment_slot_name', ucwords($payment_name))->where('status', '!=', 2)->first();

        if($check){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Name is exist!'
            ]);
            return redirect()->back();
        } 

        $paymentSlot = new PaymentSlotModel();
        $paymentSlot->payment_slot_name = $request->input('payment_slot_name');
        $paymentSlot->payment_slot_des = $request->input('payment_slot_des');
        $paymentSlot->save();

            if ($paymentSlot) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Payment MileStone added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payment MileStone!'
                    ]);
                }
       return redirect()->back();
    }


    public function update(Request $request){
        $validator = Validator::make($request->all(), [
            'edit_payment_slot_name' => 'required|max:255|string',
            'edit_payment_slot_des' => 'nullable|string',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Format Input Field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
        } else {
            $edit_payment_name = $request->edit_payment_slot_name;

            $edit_payment_des = $request->edit_payment_slot_des;
            $sno = $request->edit_id;

            $check = PaymentSlotModel::where('payment_slot_name', ucwords($edit_payment_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if($check){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Alreaady Name Exists'
                ]);
                return redirect()->back();
            } else{
                $upd_PaymentSlotModel = PaymentSlotModel::where('sno', $sno)->first();
                $upd_PaymentSlotModel->payment_slot_name = Ucfirst($edit_payment_name);
                $upd_PaymentSlotModel->payment_slot_des = $edit_payment_des;

                $upd_PaymentSlotModel->update();

                if($upd_PaymentSlotModel){
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Payment MileStone Updated Succesfully',
                    ]);
                } else{
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Payment MileStone'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = PaymentSlotModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id){
        $upd_PaymentSlotModel = PaymentSlotModel::where('sno', $id)->first();
        $upd_PaymentSlotModel->status = 2;
        $upd_PaymentSlotModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}