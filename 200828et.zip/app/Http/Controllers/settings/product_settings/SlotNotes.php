<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SlotNotesModel;
use Illuminate\Support\Facades\Validator;

class SlotNotes extends Controller
{
    public function index()
    {
        $slotNotes = SlotNotesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.product_settings.slot_notes', compact('slotNotes'));
    }

    public function create(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'slot_notes_name' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format input field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $slot_notes_name = $request->input('slot_notes_name');

        foreach ($slot_notes_name as $slot_note_name) {
            $check = SlotNotesModel::where('slot_notes_name', ucwords($slot_note_name))->where('status', '!=', 2)->first();


            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Name is exist!'
                ]);
                continue;
            }

            $slotNotes = new SlotNotesModel();
            $slotNotes->slot_notes_name = $slot_note_name;
            $slotNotes->created_by = $user_id;
            $slotNotes->updated_by = $user_id;
            $slotNotes->save();
            if ($slotNotes) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Slot Note Created Succesfully',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Create the Slot Note '
                    ]);
                }
        }
        return redirect()->back();
    }


    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_slot_name' => 'required',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format Input Field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
        } else {
            $edit_slot_name = $request->edit_slot_name;
            $sno = $request->edit_id;

            $check = SlotNotesModel::where('slot_notes_name', ucwords($edit_slot_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Alreaady Name Exists'
                ]);
                return redirect()->back();
            } else {
                $upd_SlotnotesModel = SlotNotesModel::where('sno', $sno)->first();
                $upd_SlotnotesModel->slot_notes_name = Ucfirst($edit_slot_name);


                $upd_SlotnotesModel->update();

                if ($upd_SlotnotesModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Slot Note Updated Succesfully',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Slot Note '
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $upd_SlotnotesModel = SlotNotesModel::where('sno', $id)->first();
        $upd_SlotnotesModel->status = $request->input('status', 0);
        $upd_SlotnotesModel->update();
        if ($upd_SlotnotesModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $upd_SlotnotesModel = SlotNotesModel::where('sno', $id)->first();
        $upd_SlotnotesModel->status = 2;
        $upd_SlotnotesModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id){
        $data = SlotNotesModel::where('sno', $id)->first();

        if(!$data){
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function deleteData($id){
        $data = SlotNotesModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }
}
