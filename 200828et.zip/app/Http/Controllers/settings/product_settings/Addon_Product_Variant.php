<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Addon_product_VariantModel;
use Illuminate\Support\Facades\Validator;

class Addon_Product_Variant extends Controller
{
    public function index()
    {
        $University = Addon_product_VariantModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.product_settings.addon_variant', [
            'ListTable' => $University,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = Addon_product_VariantModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'product_variant_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->product_variant_name;
            $company_des = $request->service_des;


            $user_id = 1;
            $chk = Addon_product_VariantModel::where('addon_varientname', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Varient is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = Addon_product_VariantModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'AV-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('AV-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new Addon_product_VariantModel();

                $add_company->addon_varientname = Ucfirst($company_name);
                $add_company->addon_varientdes = $company_des;
                $add_company->addon_varientid = $company_id;

                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Service Varient added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Service Varient!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editcompany = Addon_product_VariantModel::where('sno', $id)->first();

        return view('content.settings.product_settings.addon_variant', [
            'editcompany' => $editcompany,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'edit_service_varient' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_service_varient;

            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = Addon_product_VariantModel::where('addon_varientname', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Varient is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = Addon_product_VariantModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->addon_varientname = Ucfirst($company_name);

                $upd_CompanyTypeModel->addon_varientdes = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Addon Service Varient successfull updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Addon Service Varient!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = Addon_product_VariantModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
