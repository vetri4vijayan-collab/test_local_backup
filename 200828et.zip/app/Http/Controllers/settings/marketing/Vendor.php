<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MarketingVendorModel;
use Illuminate\Support\Facades\Validator;

class Vendor extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $marketing_vendor = MarketingVendorModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.marketing.vendor', [
            'marketing_vendor' => $marketing_vendor
        ]);
    }
    public function Listdropdown()
    {

        $MarType = MarketingVendorModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarType
        ], 200);
    }



    //ADD NEW VENDOR
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'marketing_vendor_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        // return $request;

        // If validation passes
        $marketing_vendor_name = $request->marketing_vendor_name;
        $marketing_vendor_id = $request->marketing_vendor_id;
        $vendor_contact_person_name = $request->vendor_contact_person_name;
        $vendor_contact_person_mobile = $request->vendor_contact_person_mobile;
        $marketing_vendor_address = $request->marketing_vendor_address;
        $marketing_vendor_desc = $request->marketing_vendor_desc;

        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = MarketingVendorModel::where('marketing_vendor_name', ucwords($marketing_vendor_name))
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Vendor has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $add_vendor = MarketingVendorModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$add_vendor) {
                $year = substr(date('y'), -2);
                $marketing_vendor_id = 'MC-0001/' . $year;
            } else {
                $data = $add_vendor->marketing_vendor_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $marketing_vendor_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new MarketingVendorModel();
            $add->marketing_vendor_id = $marketing_vendor_id;
            $add->marketing_vendor_name = ucfirst($marketing_vendor_name);
            $add->vendor_contact_person_name = $vendor_contact_person_name;
            $add->vendor_contact_person_mobile = $vendor_contact_person_mobile;
            $add->marketing_vendor_address = $request->marketing_vendor_address;
            $add->marketing_vendor_desc = $request->marketing_vendor_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => ' Marketing Vendor added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the  Marketing Vendor !'
                ]);
            }
        }

        return redirect()->back();
    }



    //EDIT VENDOR
    public function Update(Request $request)
    {



        $validator = Validator::make($request->all(), [

            'marketing_vendor_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $marketing_vendor_name_edit = $request->marketing_vendor_name_edit;
        $vendor_contact_person_name_edit = $request->vendor_contact_person_name_edit;
        $vendor_contact_person_mobile_edit = $request->vendor_contact_person_mobile_edit;
        $marketing_vendor_address_edit = $request->marketing_vendor_address_edit;
        $marketing_vendor_desc_edit = $request->marketing_vendor_desc_edit;
        $sno    = $request->sno_edit;



        $upd_marketing_vendor = MarketingVendorModel::find($sno);

        if (!$upd_marketing_vendor) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Vendor  not found!'
            ]);
            return redirect()->back();
        }
        //VENDOR NAME
        $chk = MarketingVendorModel::where('marketing_vendor_name', ucwords($marketing_vendor_name_edit))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Vendor has already been created!'
            ]);
            return redirect()->back();
        } else {

            $upd_marketing_vendor->marketing_vendor_name = ucfirst($marketing_vendor_name_edit);
            $upd_marketing_vendor->vendor_contact_person_name = ucfirst($vendor_contact_person_name_edit);
            $upd_marketing_vendor->vendor_contact_person_mobile = $vendor_contact_person_mobile_edit;
            $upd_marketing_vendor->marketing_vendor_address = $marketing_vendor_address_edit;
            $upd_marketing_vendor->marketing_vendor_desc = $marketing_vendor_desc_edit;
            $upd_marketing_vendor->save();

            if ($upd_marketing_vendor) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => ' Marketing Vendor updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the  Marketing Vendor !'
                ]);
            }
        }
        // return $request;
        return redirect()->back();
    }


    // Status change
    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  MarketingVendorModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Vendor Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Marketing Vendor Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Marketing Vendor Status!',
                'error_msg' => 'Could not ,update  Marketing Vendor Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_CourseTypeModel =  MarketingVendorModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Vendor Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Marketing Vendor!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
