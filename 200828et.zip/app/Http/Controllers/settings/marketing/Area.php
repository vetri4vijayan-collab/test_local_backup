<?php

namespace App\Http\Controllers\settings\marketing;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\MarketingAreaModel;
use App\Models\MarketingZoneModel;
use App\Models\BranchModel;

class Area extends Controller
{

    protected static $branch_id = 1;

    public function index()
    {
        // inner join query
        $marketing_area = MarketingAreaModel::select('et_marketing_area.*', 'et_branch.branch_name', 'et_branch.franchise_name', 'et_marketing_zone.zone_name', 'et_marketing_zone.sno as zone_id')
            ->leftjoin('et_branch', 'et_branch.sno', '=', 'et_marketing_area.zone_branch_id')
            ->leftjoin('et_marketing_zone', 'et_marketing_zone.sno', '=', 'et_marketing_area.zone_name')
            ->where('et_marketing_area.status', '!=', 2)
            ->orderBy('et_marketing_area.sno', 'desc')
            ->get();

        $branch = BranchModel::select('*')->where('status', '!=', 2)->get();

        $zone = MarketingZoneModel::select('*')->where('status', '!=', 2)->get();

        return view('content.settings.marketing.area', [
            'marketing_area' => $marketing_area,
            'branch' => $branch,
            'zone' => $zone

        ]);
    }
    public function Listdropdown()
    {

        $MarType = MarketingAreaModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarType
        ], 200);
    }


    //ADD NEW ZONE
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'zone_name' => 'required|max:255',
            // 'zone_dropdown' => 'required|integer' // Adjust validation as needed
        ]);



        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        // return $request;

        // If validation passes
        $branch_id = 1;
        $zone_dropdown = $request->zone_dropdown;
        // $marketing_area_id = $request->marketing_area_id;
        $zone_name = $request->zone_name;
        $zone_area_name = $request->zone_area_name;
        $user_id = $request->user()->user_id;



        // Check if the zone already exists
        $chk = MarketingAreaModel::where('zone_area_name', ucwords($zone_area_name))
            ->where('zone_branch_id', $zone_dropdown)->where('zone_name', $zone_name)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Area has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $add_zone = MarketingAreaModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$add_zone) {
                $year = substr(date('y'), -2);
                $marketing_area_id = 'MC-0001/' . $year;
            } else {
                $data = $add_zone->marketing_area_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $marketing_area_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new MarketingAreaModel();
            $add->marketing_area_id = $marketing_area_id;
            $add->zone_branch_id = $zone_dropdown;
            $add->zone_name = ucfirst($zone_name);
            $add->branch_id = $branch_id;
            $add->zone_area_name = $request->zone_area_name;
            $add->zone_desc = $request->zone_desc;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => ' Area added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Area !'
                ]);
            }
        }

        return redirect()->back();
    }

    // Status change
    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  MarketingAreaModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Area Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Area Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update  Area Status!',
                'error_msg' => 'Could not ,update   Area Status!',
                'data'      => null,
            ], 200);
        }
    }


    //EDIT VENDOR
    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [

            'zone_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        $zone_dropdown_edit = $request->zone_dropdown_edit;
        $zone_name_edit = $request->zone_name_edit;
        $zone_area_name_edit = $request->zone_area_name_edit;

        $zone_desc_edit = $request->zone_desc_edit;
        $sno    = $request->sno_edit;



        $upd_marketing_zone = MarketingAreaModel::find($sno);

        if (!$upd_marketing_zone) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Area  not found!'
            ]);
            return redirect()->back();
        }
        //Area NAME
        $chk = MarketingAreaModel::where('zone_area_name', ucwords($zone_area_name_edit))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => ' Area has already been created!'
            ]);
            return redirect()->back();
        } else {
            $upd_marketing_zone->zone_branch_id = $zone_dropdown_edit;
            $upd_marketing_zone->zone_name = ucfirst($zone_name_edit);
            $upd_marketing_zone->zone_area_name = ucfirst($zone_area_name_edit);
            $upd_marketing_zone->zone_desc = $zone_desc_edit;
            $upd_marketing_zone->save();


            // return $upd_marketing_zone;

            if ($upd_marketing_zone) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => '  Area updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the   Area !'
                ]);
            }
        }
        // return $request;
        return redirect()->back();
    }

    public function Delete($id)
    {

        $upd_CourseTypeModel =  MarketingAreaModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => ' Area Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Area!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
