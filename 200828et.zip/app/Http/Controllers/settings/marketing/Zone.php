<?php

namespace App\Http\Controllers\settings\marketing;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\MarketingZoneModel;
use App\Models\BranchModel;

class Zone extends Controller
{

    protected static $branch_id = 1;

    public function index()
    {
        // inner join query
        $marketing_zone = MarketingZoneModel::select('et_marketing_zone.*')
            ->where('et_marketing_zone.status', '!=', 2)
            ->orderBy('et_marketing_zone.sno', 'desc')
            ->get();

        $branch = BranchModel::select('*')->where('status', '!=', 2)->get();

        return view('content.settings.marketing.zone', [
            'marketing_zone' => $marketing_zone,
            'branch' => $branch

        ]);
    }
    public function Listdropdown()
    {

        $MarType = MarketingZoneModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarType
        ], 200);
    }


    //ADD NEW ZONE
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'zone_name' => 'required|max:255',
            // 'zone_dropdown' => 'required|integer' // Adjust validation as needed
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        // return $request;

        // If validation passes
        $branch_id = 1;
        $marketing_zone_id = $request->marketing_zone_id;
        $zone_name = $request->zone_name;

        $user_id = $request->user()->user_id;



        // Check if the zone already exists
        $chk = MarketingZoneModel::where('zone_name', ucwords($zone_name))
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Zone has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $add_zone = MarketingZoneModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$add_zone) {
                $year = substr(date('y'), -2);
                $marketing_zone_id = 'MC-0001/' . $year;
            } else {
                $data = $add_zone->marketing_zone_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $marketing_zone_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new MarketingZoneModel();
            $add->marketing_zone_id = $marketing_zone_id;
            $add->zone_name = ucfirst($zone_name);
            $add->branch_id = $branch_id;
            $add->zone_desc = $request->zone_desc;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => ' Zone added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Zone !'
                ]);
            }
        }

        return redirect()->back();
    }

    // Status change
    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  MarketingZoneModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Zone Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Zone Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update  Zone Status!',
                'error_msg' => 'Could not ,update   Zone Status!',
                'data'      => null,
            ], 200);
        }
    }


    //EDIT VENDOR
    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [

            'zone_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        $zone_name_edit = $request->zone_name_edit;
        $zone_desc_edit = $request->zone_desc_edit;
        $sno    = $request->sno_edit;



        $upd_marketing_zone = MarketingZoneModel::find($sno);

        if (!$upd_marketing_zone) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Zone  not found!'
            ]);
            return redirect()->back();
        }
        //zone NAME
        $chk = MarketingZoneModel::where('zone_name', ucwords($zone_name_edit))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => ' Zone has already been created!'
            ]);
            return redirect()->back();
        } else {
            //database colums         blade fields
            $upd_marketing_zone->zone_name = ucfirst($zone_name_edit);
            $upd_marketing_zone->zone_desc = $zone_desc_edit;
            $upd_marketing_zone->save();


            // return $upd_marketing_zone;

            if ($upd_marketing_zone) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => '  zone updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the   zone !'
                ]);
            }
        }
        // return $request;
        return redirect()->back();
    }

    public function Delete($id)
    {

        $upd_CourseTypeModel =  MarketingZoneModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => ' zone Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  zone!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
