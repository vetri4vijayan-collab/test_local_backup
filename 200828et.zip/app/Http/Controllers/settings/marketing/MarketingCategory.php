<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\MarketingCategoryModel;

class MarketingCategory extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $marketing_category = MarketingCategoryModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        return view('content.settings.marketing.marketing_category', [
            'marketing_category' => $marketing_category
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_MarketingCategoryModel =  MarketingCategoryModel::where('sno', $id)->first();
        $upd_MarketingCategoryModel->status = $request->input('status', 0);
        $upd_MarketingCategoryModel->update();
        if ($upd_MarketingCategoryModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Category Status Successfully Updated!',
                'error_msg' => 'Could not update  Marketing Category Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Marketing Category Status!',
                'error_msg' => 'Could not update  Marketing Category Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_MarketingCategoryModel =  MarketingCategoryModel::where('sno', $id)->first();
        $upd_MarketingCategoryModel->status  = 2;
        $upd_MarketingCategoryModel->Update();
        if ($upd_MarketingCategoryModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Category  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Marketing Category !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function List()
    {
        $MarketingCategory = MarketingCategoryModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarketingCategory
        ], 200);
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'marketing_category_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $marketing_category_name = $request->marketing_category_name;
        $marketing_category_id = $request->marketing_category_id;
        $marketing_category_desc = $request->marketing_category_desc;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = MarketingCategoryModel::where('marketing_category_name', ucwords($marketing_category_name))
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Marketing Category has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = MarketingCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $marketing_category_id = 'MC-0001/' . $year;
            } else {
                $data = $category_check->marketing_category_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $marketing_category_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new MarketingCategoryModel();
            $add->marketing_category_id = $marketing_category_id;
            $add->marketing_category_name = ucfirst($marketing_category_name);
            $add->marketing_category_desc = $marketing_category_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by =  $request->user()->user_id;
            $add->updated_by = $request->user()->user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Marketing Category added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Marketing Category!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'marketing_category_id' => 'required|max:255',
            'marketing_category_name_edit' => 'required|max:255',
            'marketing_category_desc_edit' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $marketing_category_name_edit = $request->marketing_category_name_edit;
        $marketing_category_desc_edit = $request->marketing_category_desc_edit;
        $marketing_category_id   = $request->marketing_category_id;
        $user_id = $request->user()->user_id;

        $upd_marketing_category = MarketingCategoryModel::find($marketing_category_id);

        if (!$upd_marketing_category) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Category  not found!'
            ]);
            return redirect()->back();
        }

        $chk = MarketingCategoryModel::where('marketing_category_name', ucwords($marketing_category_name_edit))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $marketing_category_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Marketing Category has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_marketing_category->marketing_category_name = ucfirst($marketing_category_name_edit);
        $upd_marketing_category->marketing_category_desc = $marketing_category_desc_edit;
        $upd_marketing_category->created_by =  $request->user()->user_id;
        $upd_marketing_category->updated_by = $request->user()->user_id;
        $upd_marketing_category->save();

        if ($upd_marketing_category) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Marketing Category updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Marketing Category !'
            ]);
        }

        return redirect()->back();
    }
}
