<?php

namespace App\Http\Controllers\settings\buissness_goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\BuissnessGoalSetModel;

class BuissnessGoalSet extends Controller
{


    public function index()
    {
        return view('content.settings.buissness_goal_set.buissness_goal_set');
    }

    public function getBusinessGoals(Request $request)
    {
        $goal = BuissnessGoalSetModel::where('branch_id', $request->branch_id)->first();

        if (!$goal) {
            return response()->json([
                'status' => 200,
                'data' => [
                    'conversion' => '',
                    'conversion_check' => 0,
                    'target' => '',
                    'target_check' => 0,
                ]
            ]);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'conversion' => $goal->conversion,
                'conversion_check' => $goal->conversion_check,
                'target' => $goal->target,
                'target_check' => $goal->target_check,
            ]
        ]);
    }


    public function updateBusinessGoals(Request $request)
    {
        $validatedData = $request->validate([
            'branch_id' => 'required|integer',
            'conversion' => 'nullable|numeric',
            'conversion_check' => 'nullable|boolean',
            'target' => 'nullable|numeric',
            'target_check' => 'nullable|boolean',
        ]);

        // Ensure unchecked checkboxes are set to 0
        foreach ($validatedData as $key => $value) {
            if (strpos($key, '_check') !== false && $value === null) {
                $validatedData[$key] = 0;
            }
        }

        $goal = BuissnessGoalSetModel::updateOrCreate(
            ['branch_id' => $validatedData['branch_id']], // Search condition
            array_merge(
                $validatedData,
                [
                    'updated_by' => auth()->id(),
                    'created_by' => BuissnessGoalSetModel::where('branch_id', $validatedData['branch_id'])
                        ->exists()
                        ? BuissnessGoalSetModel::where('branch_id', $validatedData['branch_id'])
                        ->value('created_by')
                        : auth()->id(), // Keep existing created_by if record exists
                ]
            )
        );

        return response()->json(['status' => 200, 'message' => 'Business goals updated successfully', 'data' => $goal]);
    }
}
