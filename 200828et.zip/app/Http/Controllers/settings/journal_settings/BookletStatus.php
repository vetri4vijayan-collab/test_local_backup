<?php

namespace App\Http\Controllers\settings\journal_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BookletStatusModel;
use Illuminate\Support\Facades\Validator;

class BookletStatus extends Controller
{
    public function index(){
        $books = BookletStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.journal_settings.booklet_status', compact('books'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'booklet_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format.',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $name = $request->booklet_name;
        $user_id = $request->user()->user_id;

        // Check if the name is already exists
        $exists = BookletStatusModel::where('booklet_name', ucwords($name))->where('status', '!=', 2)->first();

        if ($exists) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $create = new BookletStatusModel();
        $create->booklet_name = ucwords($name);
        $create->booklet_desc = $request->booklet_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Booklet Status Created Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Something Went Wrong !'
            ]);
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format.',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $id = $request->edit_id;
        $name = $request->edit_name;
        $user_id = $request->user()->user_id;

        // Check if the name is already exists
        $exists = BookletStatusModel::where('booklet_name', ucwords($name))
            ->where('sno', '!=', $id)
            ->where('status', '!=', 2)->first();

        if ($exists) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $Update = BookletStatusModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Update->booklet_name = ucwords($name);
        $Update->booklet_desc = $request->booklet_desc;
        $Update->updated_by = $user_id;
        $Update->update();

        if ($Update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Booklet Status Updated Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Something Went Wrong !'
            ]);
        }

        return redirect()->back();
    }

    public function Status($id, Request $request){
        $Status = BookletStatusModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = $request->input('status', 0);
        $Status->update();

        if($Status){
            return response([
                'status' => 200,
                'message' => 'Success! Your Booklet Status Is Now Updated',
                'error_msg' => 'Failed to Change Booklet Status. Please Try Again.',
                'data' => null
            ], 200);
        } else {
            return response([
                'status' => 401,
                'message' => 'Failed to Change Booklet Status. Please Try Again.',
                'error_msg' => 'Failed to Change Booklet Status. Please Try Again.',
                'data' => null
            ], 401);
        }
    }

    public function Delete($id){
        $Delete = BookletStatusModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Delete->status = 2;
        $Delete->update();

        return response([
            'status' => 200,
            'message' => 'Booklet Status Has Been Deleted Successfully',
            'error_msg' => 'Failed to Delete Booklet Status. Please Try Again.',
            'data' => null
        ], 200);
    }
}
