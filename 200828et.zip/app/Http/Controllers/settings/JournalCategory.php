<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JournalCategoryModel;
use Illuminate\Support\Facades\Validator;

class JournalCategory extends Controller
{
  public function index()
    {
        $Department = JournalCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // return $Department;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.journal_settings', [
            'ListTable' => $Department,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'journal_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->journal_name;
            $company_des = $request->journal_des;


            $user_id = 1;
            $chk = JournalCategoryModel::where('journal_category_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Journal is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = JournalCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'CT-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('CT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new JournalCategoryModel();

                $add_company->journal_category_name = Ucfirst($company_name);
                $add_company->category_des = $company_des;


                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Journal Category added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Journal Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = JournalCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'journal_category_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->journal_category_edit;
            $company_type_desc = $request->journal_des_edit;
            $sno = $request->edit_id;
            $chk = JournalCategoryModel::where('journal_category_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Department is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = JournalCategoryModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->journal_category_name = Ucfirst($company_name);

                $upd_CompanyTypeModel->category_des = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Journal Category successfull updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Journal Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = JournalCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
//content.settings.journal_settings
