<?php

namespace App\Http\Controllers\settings\lead_settings;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\RequirementReasonModel;




class RequirementRejectReason extends Controller
{
   
    public function index()
    {
      $summaryReason = RequirementReasonModel::select('*')
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')->get();

        // return $summaryReason;
        

      return view('content.settings.lead_settings.requirement_reason', [
        'summaryReason' => $summaryReason
      ]);
    
    }

    public function List(Request $request)
    {  
      $branch_id = $request->user()->branch_id;
      $CourseSubCategory = RequirementReasonModel::where('branch_id', $branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $CourseSubCategory
      ], 200);
    }
  
    public function Add(Request $request)
    {
      // return $request;
      $branch_id = $request->user()->branch_id;
  
      $validator = Validator::make($request->all(), [
        'summary_reason_add' => 'required|max:255'
      ]);
      if ($validator->fails()) {
        return  response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {
  
  
        $reason_name       = $request->summary_reason_add;      
        $comment_check       = $request->comment_check_add;      
        $user_id                    = $request->user()->user_id;
        $chk = RequirementReasonModel::where('reason_name', ucwords($reason_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();
  
        if ($chk) {
  
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Requirement Reason Already Exists!'
          ]);
        } else {
        
          $add_category = new RequirementReasonModel();
          $add_category->reason_name       = Ucfirst($reason_name);
          $add_category->comments_check       = $comment_check;
          $add_category->branch_id                 = $branch_id;
          $add_category->created_by                 = $user_id;
          $add_category->updated_by                 = $user_id;
  
          $add_category->save();
  
          if ($add_category) {

            session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Requirement Reason Added Successfully!'
            ]);
          } else {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not add the Requirement Reject Reason!'
            ]);
          }
        }
        return redirect()->back();
      }
    }
  
  
    public function Update(Request $request)
    {
  
      // return $request;
      $branch_id = $request->user()->branch_id;
      $validator = Validator::make($request->all(), [
        'summary_reason_edit' => 'required|max:255',
      ]);
  
      if ($validator->fails()) {
        return   response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg'     => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {

        $reason_name             = $request->summary_reason_edit;
        $comment_check       = $request->comment_check_edit;     
        $summary_reason_id       = $request->summary_reason_id;
      // return $request;
  
        $upd_CourseCategoryModel =  RequirementReasonModel::where('sno', $summary_reason_id)->first();
  
        $chk = RequirementReasonModel::where('reason_name', ucwords($reason_name))->where('status', '!=', 2)->where('sno', '!=', $summary_reason_id)->first();
  
        if ($chk) {
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Requirement Reason Already Exists!'
          ]);
        } else {
          $upd_CourseCategoryModel->sno    = $summary_reason_id;
          $upd_CourseCategoryModel->comments_check       = $comment_check;
          $upd_CourseCategoryModel->reason_name  = Ucfirst($reason_name);
          $upd_CourseCategoryModel->update();
        }
        if ($upd_CourseCategoryModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Requirement Reason Updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Requirement Reason!'
          ]);
        }
      }
      return redirect()->back();
    }


    public function Delete($id)
    {
      
      $upd_CourseCategoryModel =  RequirementReasonModel::where('sno', $id)->first();
      $upd_CourseCategoryModel->status  = 2;
      $upd_CourseCategoryModel->Update();
  
  
      return response([
        'status'    => 200,
        'message'   => 'Requirement Reason Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  
    public function Status($id, Request $request)
    {
  
      $summary_reason =  RequirementReasonModel::where('sno', $id)->first();
      $summary_reason->status = $request->input('status', 0);
      $summary_reason->update();
  
      return response([
        'status'    => 200,
        'message'   => 'Requirement Reason Status Updated Successfully!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
