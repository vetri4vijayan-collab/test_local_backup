<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadStatusModel;
use Illuminate\Support\Facades\Validator;

class LeadStatus extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        // return view( 'content.settings.course.knowledge_type.knowledge_type_list' );
        $level = LeadStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.lead_status', compact('level', 'pageConfigs'));
    }

    public function List()
    {
        $lead_status = LeadStatusModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $lead_status
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_status_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_status_name       = $request->lead_status_name;
            $lead_bg_color                   = $request->lead_bg_color;
            $lead_status_desc       = $request->lead_status_desc;

            $user_id                    = $request->user()->user_id;
            $chk = LeadStatusModel::where('lead_status_name', ucwords($lead_status_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Lead Status Already Exists!'
                ]);
            } else {
                $category_check = LeadStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $lead_status_id = 'LS-0001/' . $year;
                } else {

                    $data = $category_check->lead_status_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('LS-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $lead_status_id = $request . '/' . $year;
                }

                $add_category = new LeadStatusModel();
                $add_category->lead_status_id         = $lead_status_id;
                $add_category->lead_status_name       = Ucfirst($lead_status_name);
                $add_category->lead_bg_color               = $lead_bg_color;
                $add_category->lead_status_desc       = $lead_status_desc;
                $add_category->branch_id = self::$branch_id;
                $add_category->created_by             = $user_id;
                $add_category->updated_by             = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Status added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Lead Status!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'Lead Status Created successfully!');
        }
    }

    public function Edit($id)
    {
        $knowledge = LeadStatusModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge
        ], 200);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_status_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        } else {
            $id = $request->edit_id;
            $lead_status_name       = $request->lead_status_name;
            $lead_bg_color          = $request->lead_bg_color;
            $lead_status_desc       = $request->lead_status_desc;

            $upd_CourseCategoryModel =  LeadStatusModel::where('sno', $id)->first();

            $chk = LeadStatusModel::where('lead_status_name', ucwords($lead_status_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Lead Status Already Exists!'
                ]);
                return redirect()->back();
            } else {

                $upd_CourseCategoryModel->lead_status_name  = Ucfirst($lead_status_name);
                $upd_CourseCategoryModel->lead_bg_color     = $lead_bg_color;
                $upd_CourseCategoryModel->lead_status_desc  = $lead_status_desc;
                $upd_CourseCategoryModel->update();

                if ($upd_CourseCategoryModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Status updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the Lead Status !'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadStatusModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadStatusModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    public function Legend_Status($id, Request $request)
    {
        // Find the lead status by sno
        $upd_CourseCategoryModel = LeadStatusModel::find($id);
    
        // Update the status
        $upd_CourseCategoryModel->legend_status = $request->input('status', 0);
        $upd_CourseCategoryModel->save();
    
        return response([
          'status'    => 200,
          'message'   => 'Legend status successfully updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
    }
}