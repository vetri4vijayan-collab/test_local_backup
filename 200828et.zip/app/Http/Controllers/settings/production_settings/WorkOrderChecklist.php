<?php

namespace App\Http\Controllers\settings\production_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WorkOrderChecklistModel;
use Illuminate\Support\Facades\Validator;

class WorkOrderChecklist extends Controller
{
    public function index()
    {
        $tasks = WorkOrderChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.production_settings.work_order_checklist', compact('tasks'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'work_order_checklist' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format !',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $work_order_checklist = $request->input('work_order_checklist');

        foreach ($work_order_checklist as $work) {
            $checks = WorkOrderChecklistModel::where('work_order_checklist', ucwords($work))->where('status', '!=', 2)->first();

            if ($checks) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Work Order Checklist Already Exists!',
                ]);
            } else {

                $create = new WorkOrderChecklistModel();
                $create->work_order_checklist = ucwords($work);
                $create->created_by = $user_id;
                $create->updated_by = $user_id;
                $create->save();

                if ($create) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Work Order Checklist Created Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Work Order Checklist Creation Failed',
                    ]);
                }
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_work_order_checklist' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_work_order_checklist;

        $checks = WorkOrderChecklistModel::where('work_order_checklist', $edit_name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Work Order Checklist Already Exists!',
            ]);

            return  redirect()->back();
        } else {
            $update = WorkOrderChecklistModel::where('sno', $sno)->first();
            $update->work_order_checklist = $edit_name;
            $update->created_by = $user_id;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Work Order Checklist Updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Error Updating Work Order Checklist',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $Update = WorkOrderChecklistModel::where('sno', $id)->first();
        $Update->status = $request->input('status', 0);
        $Update->update();

        if ($Update) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation Failed !',
                'error_msg' => 'Failed Updating Status',
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = WorkOrderChecklistModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->Update();

        return response([
            'status' => 200,
            'message' => 'Work Order Checklist Deleted Succesfully',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        $data = WorkOrderChecklistModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function deleteData($id)
    {
        $data = WorkOrderChecklistModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }
}
