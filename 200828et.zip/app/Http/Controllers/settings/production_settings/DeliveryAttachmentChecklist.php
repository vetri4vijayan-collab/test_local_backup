<?php

namespace App\Http\Controllers\settings\production_settings;

use App\Http\Controllers\Controller;
use App\Models\DeliveryAttachmentChecklistModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DeliveryAttachmentChecklist extends Controller
{
    public function index()
    {
        $tasks = DeliveryAttachmentChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.production_settings.delivery_attachment_checklist', compact('tasks'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'task_checklist' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format !',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $task_checklist = $request->input('task_checklist');

        foreach ($task_checklist as $task) {
            $checks = DeliveryAttachmentChecklistModel::where('delivery_attachment_checklist', ucwords($task))->where('status', '!=', 2)->first();

            if ($checks) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Delivery Attachment Checklist Already Exists',
                ]);
            } else {

                $create = new DeliveryAttachmentChecklistModel();
                $create->delivery_attachment_checklist = ucwords($task);
                $create->created_by = $user_id;
                $create->updated_by = $user_id;
                $create->save();

                if ($create) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Delivery Attachment Checklist Created Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Delivery Attachment Checklist Creation Failed',
                    ]);
                }
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_task_checklist' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_task_checklist;

        $checks = DeliveryAttachmentChecklistModel::where('delivery_attachment_checklist', $edit_name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Delivery Checklist Already Exists!',
            ]);

            return  redirect()->back();
        } else {
            $update = DeliveryAttachmentChecklistModel::where('sno', $sno)->first();
            $update->delivery_attachment_checklist = $edit_name;
            $update->created_by = $user_id;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Delivery Attachment Checklist updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Error Updating Delivery Attachment Checklist',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $update = DeliveryAttachmentChecklistModel::where('sno', $id)->first();
        $update->status = $request->input('status', 0);
        $update->update();

        if ($update) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation Failed !',
                'error_msg' => 'Failed Updating Status',
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = DeliveryAttachmentChecklistModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->Update();

        return response([
            'status' => 200,
            'message' => 'Delivery Attachment Checklist Deleted Succesfully',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        $data = DeliveryAttachmentChecklistModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function deleteData($id)
    {
        $data = DeliveryAttachmentChecklistModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function list()
    {
        $data = DeliveryAttachmentChecklistModel::where('status', 0)->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}
