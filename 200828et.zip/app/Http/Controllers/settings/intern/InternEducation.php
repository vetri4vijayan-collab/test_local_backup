<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InternEducationModel;
use Illuminate\Support\Facades\Validator;

class InternEducation extends Controller
{


    public function index()
    {
        $Education = InternEducationModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.intern.education.education_list', [
            'Education' => $Education,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $Education = InternEducationModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Education
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'education' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $education       = $request->education;
            $education_desc          = $request->education_desc;
            $user_id                    = $request->user()->user_id;
            $chk = InternEducationModel::where('education', ucwords($education))->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Name has been  already created!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = InternEducationModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    // $topic_id = 'LS-0001/' . $year;
                } else {

                    //     $data = $category_check->topic_id;
                    //     $slice = explode('/', $data);
                    //     $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    //     $next_number = (int)$result + 1;
                    //     $request = sprintf('LS-%04d', $next_number);

                    //     $year = substr(date('y'), -2);
                    //     $topic_id = $request . '/' . $year;
                    // }

                    $add_education = new InternEducationModel();
                    // $add_ai->topic_id         = $topic_id;
                    $add_education->education       = Ucfirst($education);
                    $add_education->education_desc       = $education_desc;
                    // $add_ai->branch_id = self::$branch_id;
                    $add_education->created_by                 = $user_id;
                    $add_education->updated_by                 = $user_id;

                    $add_education->save();

                    if ($add_education) {
                        // If category added successfully, return success response and display Toastr message
                        session()->flash('toastr', [
                            'type' => 'success',
                            'message' => 'Education added Successfully!'
                        ]);
                    } else {
                        session()->flash('toastr', [
                            'type' => 'error',
                            'message' => 'Could not add the Education!'
                        ]);
                    }
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = InternEducationModel::where('sno', $id)->first();

        return view('content.settings.intern.education.education_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {
        //    return $request;
        $validator = Validator::make($request->all(), [
            'education' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $education       = $request->education;
            $education_desc       = $request->education_desc;
            $education_id        = $request->education_id;

            $upd_CourseCategoryModel =  InternEducationModel::where('sno', $education_id)->first();

            $chk = InternEducationModel::where('education', ucwords($education))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $education_id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already assigned!'
                    ]);
                } else {
                }
            }

            $upd_CourseCategoryModel->education  = Ucfirst($education);
            $upd_CourseCategoryModel->education_desc  = $education_desc;

            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Education Update Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Education!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  InternEducationModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Education Successfully Deleted!',
            'error_msg' => 'Could not Delete Education!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  InternEducationModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
