<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InternTopicModel;
use Illuminate\Support\Facades\Validator;

class InternTopic extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $CourseCategory = InternTopicModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.intern.topic.topic_list', [
            'CourseCategory' => $CourseCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $CourseCategory = InternTopicModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $title       = $request->title;
            $topic_desc          = $request->topic_desc;
            $user_id                    = $request->user()->user_id;
            $chk = InternTopicModel::where('title', ucwords($title))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Name has been  already created!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = InternTopicModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $topic_id = 'LS-0001/' . $year;
                } else {

                    $data = $category_check->topic_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('LS-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $topic_id = $request . '/' . $year;
                }

                $add_topic = new InternTopicModel();
                $add_topic->topic_id         = $topic_id;
                $add_topic->title       = Ucfirst($title);
                $add_topic->topic_desc       = $topic_desc;
                $add_topic->branch_id = self::$branch_id;
                $add_topic->created_by                 = $user_id;
                $add_topic->updated_by                 = $user_id;

                $add_topic->save();

                if ($add_topic) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Topic added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Topic!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = InternTopicModel::where('sno', $id)->first();

        return view('content.settings.intern.topic.topic_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $title       = $request->title;
            $topic_desc       = $request->topic_desc;
            $topic_id        = $request->topic_id;

            $upd_CourseCategoryModel =  InternTopicModel::where('sno', $topic_id)->first();

            $chk = InternTopicModel::where('title', ucwords($title))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $topic_id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already assigned!'
                    ]);
                } else {
                }
            }

            $upd_CourseCategoryModel->title  = Ucfirst($title);
            $upd_CourseCategoryModel->topic_desc  = $topic_desc;

            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Topic Update Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Topic!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  InternTopicModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Topic Successfully Deleted!',
            'error_msg' => 'Could not Delete Topic!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  InternTopicModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
