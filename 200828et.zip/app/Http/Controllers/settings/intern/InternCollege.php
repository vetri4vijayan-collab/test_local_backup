<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\InternCollegeModel;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class InternCollege extends Controller
{
  public function index(Request $request)
  {
    // Get all branches and map by 'sno'
    $branches = DB::table('et_branch')
      ->select('sno', 'branch_name', 'franchise_name', 'branch_type')
      ->get()
      ->keyBy('sno')
      ->toArray();

    // Get colleges
    $College = InternCollegeModel::where('status', '!=', 2)
      ->orderBy('sno', 'desc')
      ->get();

    // Process each college
    foreach ($College as $colleges) {
      $branchIds = json_decode($colleges->branch_id, true);

      if (is_array($branchIds)) {
        $colleges->branch_id_raw = implode(', ', $branchIds);
        $branchNames = array_map(function ($id) use ($branches) {
          $id = (int) $id;
          if (isset($branches[$id])) {
            $branch = $branches[$id];
            return $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name;
          }
          return '-';
        }, $branchIds);
        $colleges->branch_name = implode(', ', $branchNames);
      }
    }

    return view('content.settings.intern.College.college_list', [
      'College' => $College
    ]);
  }


  public function List(Request $request)
  {
    $branch_id = (string) $request->user()->branch_id;
    $College = InternCollegeModel::where('status', 0)->orderBy('sno', 'desc')->get();

    $filtered = $College->filter(function ($item) use ($branch_id) {
      $branchIds = json_decode($item->branch_id, true); // decode the string
      return in_array((string)$branch_id, $branchIds ?? []);
    });
    // return $College;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $filtered->values()
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'college_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $college_name       = $request->college_name;
      $college_desc       = $request->college_desc;
      $branchId = $request->branchId;
      $user_id                    = $request->user()->user_id;
      $chk = InternCollegeModel::where('college_name', ucwords($college_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = InternCollegeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_category_id = "CC-0001/" . $year;
        } else {

          $data = $category_check->job_category_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_category_id = $request . '/' . $year;
        }


        $add_category = new InternCollegeModel();
        // $add_category->job_category_id         = $job_category_id;
        $add_category->college_name       = Ucfirst($college_name);
        $add_category->college_desc       = $college_desc;
        $add_category->branch_id                 =  json_encode($branchId);
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'College Successfully added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the college!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {

    $editcategory = InternCollegeModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request->all();
    $validator = Validator::make($request->all(), [
      'college_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 401);
    }

    $id = $request->id;
    $college_name = $request->college_name;
    $college_desc = $request->college_desc;
    $branchId = $request->branch_id; // 👈 Ensure this matches frontend

    $college = InternCollegeModel::where('sno', $id)->first();

    if (!$college) {
      return response([
        'status'    => 404,
        'message'   => 'College not found',
        'error_msg' => null,
        'data'      => null,
      ], 404);
    }

    $college->college_name = ucfirst($college_name); // Or Str::title($college_name)
    $college->college_desc = $college_desc;
    $college->branch_id = json_encode($branchId);
    $college->save();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


  public function Delete($id)
  {
    $upd_ReviewLinkModel =  InternCollegeModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status  = 2;
    $upd_ReviewLinkModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_ReviewLinkModel =  InternCollegeModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status = $request->input('status', 0);
    $upd_ReviewLinkModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
