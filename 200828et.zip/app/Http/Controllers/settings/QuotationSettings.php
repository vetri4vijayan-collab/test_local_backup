<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QuotationSettings extends Controller
{
  public function index()
  {
    return view('content.settings.quotation_settings');
  }
  public function quotation_template_add()
  {
    return view('content.settings.template.add');
  }
  public function quotation_template_edit()
  {
    return view('content.settings.template.edit');
  }
  public function quotation_template_view()
  {
    return view('content.settings.template.view');
  }
}
