<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchTypeModel;
use Illuminate\Support\Facades\Validator;

class BranchCategory extends Controller
{
    public function index()
    {
        $Branch = BranchTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        //return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.base_settings.branch_category', [
            'ListTable' => $Branch,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'branch_name' => 'required'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->branch_name;
            $company_des = $request->branch_description;
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $chk = BranchTypeModel::where('branchtype_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Branch Name Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $category_check = BranchTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'BC-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('BC-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }


                $add_company = new BranchTypeModel();

                $add_company->branchtype_name = Ucfirst($company_name);
                $add_company->branchtype_desc = $company_des;
                $add_company->branchtype_id = $company_id;
                $add_company->created_by = $user_id;
                $add_company->branch_id = $branch_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Branch Category added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Branch Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = BranchTypeModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Edit($id)
    {
        $editcompany = BranchTypeModel::where('sno', $id)->first();

        return view('content.settings.base_settings.branch_category', [
            'editcompany' => $editcompany,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'edit_branch_name' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_branch_name;

            $company_type_desc = $request->edit_description;
            $sno = $request->edit_id;
            $chk = BranchTypeModel::where('branchtype_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Branch Name Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = BranchTypeModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->branchtype_name = Ucfirst($company_name);

                $upd_CompanyTypeModel->branchtype_desc = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Branch Updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Branch!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = BranchTypeModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}