<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadStatusModel;
use App\Models\TypeCredentialModel;
use Illuminate\Support\Facades\Validator;

class CredentialType extends Controller
{
    public function index(){

        $types = TypeCredentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return view('content.settings.customer_settings.credential_type', compact('types'));
    }

    public function Create(Request $request) {
        $validator = Validator::make($request->all(), [
            'type_name' => 'required'
        ]);

        if($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $name = $request->type_name;
        $desc = $request->type_desc;
        $user_id = $request->user()->user_id;

        $check = TypeCredentialModel::where('type_name', $name)->where('status', '!=', 2)->first();

        if($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type Already Exists!'
            ]);

            return redirect()->back();
        }

        $CREATE = new TypeCredentialModel();
        $CREATE->type_name = $name;
        $CREATE->type_desc = $desc;
        $CREATE->created_by = $user_id;
        $CREATE->updated_by = $user_id;
        $CREATE->save();

        if($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Type Created Successfully !'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type Creation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Update(Request $request) {
        $validator = Validator::make($request->all(), [
            'edit_type_name' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $sno = $request->edit_id;
        $name = $request->edit_type_name;
        $desc = $request->edit_type_desc;
        $user_id = $request->user()->user_id;

        $check = TypeCredentialModel::where('type_name', $name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type Already Exists!'
            ]);

            return redirect()->back();
        }

        $UPDATE = TypeCredentialModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $UPDATE->type_name = $name;
        $UPDATE->type_desc = $desc;
        $UPDATE->created_by = $user_id;
        $UPDATE->updated_by = $user_id;
        $UPDATE->update();

        if ($UPDATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Type Updated Successfully !'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type Updation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  TypeCredentialModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Type Successfully Deleted!',
            'error_msg' => 'Could not Delete Type!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  TypeCredentialModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Type Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
