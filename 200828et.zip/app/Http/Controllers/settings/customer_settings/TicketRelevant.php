<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use App\Models\TicketRelevantModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TicketRelevant extends Controller
{
    public function index()
    {
        $tasks = TicketRelevantModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.customer_settings.ticket_relevant', compact('tasks'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ticket_relevant' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format !',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $ticket_relevant = $request->input('ticket_relevant');

        foreach ($ticket_relevant as $task) {
            $checks = TicketRelevantModel::where('relevant_name', ucwords($task))->where('status', '!=', 2)->first();

            if ($checks) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Ticket Relevant Already Exists',
                ]);
            } else {

                $create = new TicketRelevantModel();
                $create->relevant_name = ucwords($task);
                $create->created_by = $user_id;
                $create->updated_by = $user_id;
                $create->save();

                if ($create) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Ticket Relevant Created Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Ticket Relevant Creation Failed',
                    ]);
                }
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_ticket_relevant' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_ticket_relevant;

        $checks = TicketRelevantModel::where('relevant_name', $edit_name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Ticket Relevant Already Exists!',
            ]);

            return  redirect()->back();
        } else {
            $update = TicketRelevantModel::where('sno', $sno)->first();
            $update->relevant_name = $edit_name;
            $update->created_by = $user_id;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Ticket Relevant updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Error Updating Task Checklist',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $update = TicketRelevantModel::where('sno', $id)->first();
        $update->status = $request->input('status', 0);
        $update->update();

        if ($update) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation Failed !',
                'error_msg' => 'Failed Updating Status',
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = TicketRelevantModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->Update();

        return response([
            'status' => 200,
            'message' => 'Ticket Relevant Deleted Succesfully',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        $data = TicketRelevantModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function deleteData($id)
    {
        $data = TicketRelevantModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function list()
    {
        $data = TicketRelevantModel::where('status', 0)->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}