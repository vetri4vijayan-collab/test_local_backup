<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DivisionModel;
use App\Models\JobpositionModel;
use Carbon\Carbon;

class Division extends Controller
{
  public function index()
  {
    $Division = DivisionModel::where('et_division.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('et_division.*', 'et_entity.entity_name as entityname', 'et_branch.branch_name', 'et_branch.franchise_name', 'et_branch.branch_type', 'et_department.department_name as deptname')
      ->leftJoin('et_entity', 'et_division.entity_id', 'et_entity.sno')
      ->leftJoin('et_branch', 'et_division.branch_id', 'et_branch.sno')
      ->leftJoin('et_department', 'et_division.department_id', 'et_department.sno')
      ->orderBy('et_division.sno', 'desc')->get();
    // return $Department;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.base_settings.division', [
      'ListTable' => $Division,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function Status($id, Request $request)
  {

    $staff =  DivisionModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DivisionModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function DepartDivisionList(Request $request)
  {

    $department_id = $request->department_id;
    $Department = DivisionModel::where('status', '!=', 2)->where('department_id', $department_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function JobPostionList()
  {
    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobpositionModel::where('sub_department_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'divisionName' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $division_name = $request->divisionName;
      $Desc = $request->divDesc;
      $branch_id = $request->branchId;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', ucwords($division_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = new DivisionModel();
        $add_division->division_name = Ucfirst($division_name);
        $add_division->entity_id = 1;
        $add_division->department_id = $request->departmentId;
        $add_division->division_desc = $Desc;
        $add_division->branch_id  = 1;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function Edit($id)
  {
    $data = DivisionModel::where('sno', $id)->first();
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Division not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Division fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'divisionName' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $division_name = $request->divisionName;
      $sno = $request->edit_id;
      $Desc = $request->divDesc;
      $branch_id = $request->branchId;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', ucwords($division_name))->where('branch_id', $branch_id)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = DivisionModel::where('sno', $sno)->first();
        $add_division->division_name = Ucfirst($division_name);
        $add_division->entity_id = 1;
        $add_division->department_id = $request->departmentId;
        $add_division->division_desc = $Desc;
        $add_division->branch_id  = 1;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
}
