<?php

namespace App\Http\Controllers\settings\training_settings;

use App\Http\Controllers\Controller;
use App\Models\TrainingCategoryModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class TrainingCategory extends Controller
{
    public function index()
    {
        $ListTable = TrainingCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.training_settings.training_category', compact('ListTable'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);

            return redirect()->back();
        } else {
            $name = $request->category_name;
            $desc = $request->category_desc;
            $user_id = $request->user()->user_id;

            $check = TrainingCategoryModel::where('category_name', ucwords($name))->where('status', '!=', 2)->first();
            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $store = new TrainingCategoryModel();
                $store->category_name = ucwords($name);
                $store->category_desc = $desc;
                $store->created_by = $user_id;
                $store->updated_by = $user_id;
                $store->save();

                if ($store) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Training Document Category created successfully !',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Training Document Category creation failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_category_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);

            return redirect()->back();
        } else {
            $sno = $request->edit_id;
            $edit_name = $request->edit_category_name;
            $edit_desc = $request->edit_description;
            $user_id = $request->user()->user_id;

            $check = TrainingCategoryModel::where('category_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $upgrade = TrainingCategoryModel::where('sno', $sno)->first();
                $upgrade->category_name = $edit_name;
                $upgrade->category_desc = $edit_desc;
                $upgrade->created_by = $user_id;
                $upgrade->updated_by = $user_id;
                $upgrade->update();

                if ($upgrade) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Training Document Category Updated successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Training Document Category Update failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function status($id, Request $request)
    {
        $updChargeModel = TrainingCategoryModel::where('sno', $id)->first();
        $updChargeModel->status = $request->input('status', 0);
        $updChargeModel->update();

        if ($updChargeModel) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation failed',
                'error_msg' => 'Status Updation failed',
                'data' => null,
            ], 400);
        }
    }

    public function delete($id)
    {
        $updChargeModel = TrainingCategoryModel::where('sno', $id)->first();
        $updChargeModel->status = 2;
        $updChargeModel->update();

        if ($updChargeModel) {
            return response([
                'status' => 200,
                'message' => 'Training Document Category deleted Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}
