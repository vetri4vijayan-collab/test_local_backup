<?php

namespace App\Http\Controllers\settings\exam_settings;

use App\Http\Controllers\Controller;
use App\Models\ExamCategoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExamCategory extends Controller
{
    public function index()
    {
        $lists = ExamCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.exam_settings.exam_category', compact('lists'));
    }
    
     public function List()
    {
        $data = ExamCategoryModel::where('status', '!=', 2)->get();

        if($data) {
            return response([
                'status' => 200,
                'message' => 'Exam Category Fetched Succesfully',
                'error_msg' => 'Exam Category Fetch Failed !',
                'data' => $data,
            ]);
        }
    }
    
    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_cat_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->exam_cat_name;

        $check = ExamCategoryModel::where('status', '!=', 2)->where('category_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Category Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new ExamCategoryModel();
        $create->category_name = $name;
        $create->category_desc = $request->desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Category Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Category Creation Failed!'
            ]);
        }
    }

    public function Status($id, Request $request)
    {
        $status = ExamCategoryModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = ExamCategoryModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Category Deleted Succesfully',
            'error_msg' => 'Exam Category Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_bank' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->edit_bank;
        $sno = $request->edit_id;

        $check = ExamCategoryModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('category_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Category Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = ExamCategoryModel::where('status', '!=', 2)->where('sno', $sno)->first();
        $create->category_name = $name;
        $create->category_desc = $request->edit_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Category Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Category Updation Failed!'
            ]);
        }
    }
}
