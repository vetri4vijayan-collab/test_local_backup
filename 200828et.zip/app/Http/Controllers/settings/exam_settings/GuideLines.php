<?php

namespace App\Http\Controllers\settings\exam_settings;

use App\Http\Controllers\Controller;
use App\Models\Exam_guidelinesModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GuideLines extends Controller
{
    public function index()
    {
        $guidelines = Exam_guidelinesModel::where('status', '!=', 2)->latest()->first();
        return view('content.settings.exam_settings.guidelines', compact('guidelines'));
    }

    public function store(Request $request) {

        $create = Exam_guidelinesModel::latest()->first() ?? new Exam_guidelinesModel();
        $create->exam_guidelines = $request->add_text;
        $create->created_by = $request->user()->user_id;
        $create->updated_by = $request->user()->user_id;
        $create->save();

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Guidelines Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Guidelines Creation Failed!'
            ]);

            return redirect()->back();
        }
    }
}
