<?php

namespace App\Http\Controllers\settings\common_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CountryModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class CommunicationHandler extends Controller
{


  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $communication = DB::table('et_communication_handle')->where('status', '!=', 2);
//     if ($search_filter != '') {
//       $communication->where(function ($subquery) use ($search_filter) {
//           $subquery->where('name', 'LIKE', "%{$search_filter}%")
//               ->orWhere('sortname', 'LIKE', "%{$search_filter}%")
//               ->orWhere('phonecode', 'LIKE', "%{$search_filter}%");
              
//       });
//   }
    $communication=$communication->orderBy('sno', 'desc')->paginate($perpage);
    return view('content.settings.common_setting.communication_handler', [
      'communication' => $communication,
      'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }

  public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Incorrect format input fields'
        ]);
        return redirect()->back();
    }

    try {
        DB::beginTransaction();

        $name = $request->name;
        $user_id = $request->user()->user_id ?? 1;

        $chk = DB::table('et_communication_handle')
            ->where('module_name', $name)
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name has already been created!'
            ]);
            DB::rollBack();
            return redirect()->back();
        }

        $add_category = DB::table('et_communication_handle')->insert([
            'module_name' => $name,
            'created_by' => $user_id,
            'updated_by' => $user_id,
        ]);

        if ($add_category) {
            DB::commit();
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Communication Module added Successfully!'
            ]);
        } else {
            DB::rollBack();
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Communication Module!'
            ]);
        }

    } catch (\Exception $e) {
        DB::rollBack();
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Something went wrong! Please try again later.' . $e->getMessage()
        ]);
    }

    return redirect()->back();
}



  public function Delete($id)
  {
  
       DB::table('et_communication_handle')
                    ->where('sno', $id)
                    ->update([
                        'status' => 2,
                    ]);

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

      $type=$request->type;
    
    if($type=='1'){ // sms
         DB::table('et_communication_handle')
                    ->where('sno', $id)
                    ->update([
                        'sms' => $request->input('status', 0) ,
                    ]);
    }elseif($type=='2'){ // email
          DB::table('et_communication_handle')
                    ->where('sno', $id)
                    ->update([
                        'email' => $request->input('status', 0) ,
                    ]);
    }elseif($type=='3'){
          DB::table('et_communication_handle')
                    ->where('sno', $id)
                    ->update([
                        'whatsapp' => $request->input('status', 0) ,
                    ]);
    }else{
        DB::table('et_communication_handle')
                    ->where('sno', $id)
                    ->update([
                        'status' => $request->input('status', 0) ,
                    ]);
    }

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
