<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

use App\Models\CronjobMonitorModel;

class CronjobMonitor extends Controller
{
    public function index(Request $request)
    {
        $entity_id   = $request->user()->entity_id;
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        
        $search_fill = $request->search_fill ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        
        $List = CronjobMonitorModel::where('status', '!=', 2);
        
        // Filters:
        if ($search_fill != '') {
          $List->where(function ($query) use ($search_fill) {
            $query->where('cronjob_name', 'LIKE', "%{$search_fill}%")
              ->orWhere('cronjb_link', 'LIKE', "%{$search_fill}%");
          });
        }
        
        $ListTable = $List->orderBy('cronjob_run_duration', 'DESC')->paginate($perpage);
        
        if ($request->ajax()) {
            return view('content.branch_management.cronjob_monitor_table', compact('ListTable'))->render();
        }
        
        return view('content.branch_management.cronjob_monitor', [
          'ListTable' => $ListTable,
          'perpage' => $perpage,
          'search_fill' => $search_fill,
        ]);
    }
    public function cronjobHistory(Request $request, $cronjobId)
    {
        $perpage = (int) $request->input('perpage', 10);
        
        $crons = CronjobMonitorModel::where('sno', $cronjobId)->first();
        
        $logs = \DB::table('et_cronjob_logs')
            ->where('cronjob_id', $cronjobId)
            ->orderBy('sno', 'desc')
            ->paginate($perpage);
    
        if ($request->ajax()) {
            return view('content.branch_management.cronjob_monitor_history_table', compact('logs','crons'))->render();
        }
    
        return view('content.branch_management.cronjob_monitor_history', compact('logs'));
    }

    public function Status($id, Request $request)
    {
    
        $upd_DepartmentModel = CronjobMonitorModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
          return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
          ], 200);
        } else {
          return response([
            'status' => 400,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
          ], 400);
        }
    }
    
    public function clearCronJobLogs(Request $request)
    {
        $months = (int) $request->input('months', 0);
    
        if ($months <= 0) {
            return response()->json([
                'status' => 400,
                'message' => 'Invalid duration selected.'
            ], 400);
        }
    
        // Format thresholdDate as 'Y-m-d' to compare only the date part
        $thresholdDate = now()->subMonths($months)->format('Y-m-d');
    
        // Delete logs older than thresholdDate
        $deleted = DB::table('et_cronjob_logs')
            ->whereDate('created_at', '<', $thresholdDate)  // Use whereDate to compare date only
            ->delete();
    
        return response()->json([
            'status' => 200,
            'message' => "Logs older than {$months} month(s) cleared successfully. ({$deleted} records deleted)"
        ]);
    }

}
