<?php


namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Models\DepartmentModel;
use App\Models\JobpositionModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Carbon\Carbon;
use App\Models\TrainingPlannerModel;
use App\Models\User;  
use function Laravel\Prompts\select;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageTraining extends Controller
{

  public function index(Request $request)
  {

    // $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $training = TrainingPlannerModel::select('*')->where('status', '!=', 2)->orderBy('sno', 'desc')->paginate($perpage);
    // return $training;

    // if ($branch_id != 0) {
    //   $training->whereIn('et_training_planner.branch_id', $branch_id);
    // }

    $totalTraining = TrainingPlannerModel::select('*')->where('status', '!=', 2)->orderBy('sno', 'desc')->count('sno');

    $branch = BranchModel::select('*')->where('status', '!=', 2)->get();

    // return $branch;

    $totalTrainingMonth = TrainingPlannerModel::select('*')
      ->where('status', '!=', 2)
      ->whereMonth('created_at', Carbon::now()->month)
      ->whereYear('created_at', Carbon::now()->year)
      ->orderBy('sno', 'desc')
      ->count('sno');
      // $training_name_fill = '';
      // $training_mode_fill = '';
      // $trainer_fill = '';
      // $date_filter = '';
      $training_pl_fill = '';

    return view('content.branch_management.training_planner.list', [
      't_list' => $training,
      // 'trainer_branch_id' => $branch_id,
      'totalTraining' => $totalTraining,
      'branch' => $branch,
      'perpage' => $perpage,
      'totalTrainingMonth' => $totalTrainingMonth,
      // 'training_name_fill' => '',
      // 'training_mode_fill' => '',
      'training_pl_fill' => '',
      // 'trainer_fill' => '',
      // 'date_filter' => ''
    ])->with('filter_on', false);
  }

  public function list_filter(Request $request)
  {
    // return $request;
    // $branch_id = $request->user()->branch_id;

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    // $training_name_fill = $request->training_name_fill ?? '';
    // $training_mode_fill = $request->input('training_mode_fill', []);
    // $trainer_fill = $request->trainer_fill ?? '';
    // $date_filter = $request->dt_fill_issue_rpt;
    // $from_date_filter = $request->from_date_fillter_textbox;
    // $to_date_filter = $request->to_date_fillter_textbox;
    $training_pl_fill           = $request->training_pl_fill ?? '';

    // // Ensure training_mode_fill is an array
    // if (!is_array($training_mode_fill)) {
    //   $training_mode_fill = [];
    // }

    $query = TrainingPlannerModel::select('*')->where('status', '!=', 2);

    // return $query;

    // Date Filtering Logic
    // if ($date_filter == "today") {
    //   $todayDate = now()->format('Y-m-d');
    //   $query->whereDate('created_at', $todayDate);
    // } elseif ($date_filter == "week") {
    //   $weekFromDate = now()->startOfWeek()->format('Y-m-d');
    //   $weekToDate = now()->endOfWeek()->format('Y-m-d');
    //   $query->whereBetween('created_at', [$weekFromDate, $weekToDate]);
    // } elseif ($date_filter == "monthly") {
    //   $firstDayOfMonth = now()->startOfMonth()->format('Y-m-d');
    //   $lastDayOfMonth = now()->endOfMonth()->format('Y-m-d');
    //   $query->whereBetween('created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    // } elseif ($date_filter == "custom_date") {
    //   if ($from_date_filter && $to_date_filter) {
    //     $fromDate = date('Y-m-d', strtotime($from_date_filter));
    //     $toDate = date('Y-m-d', strtotime($to_date_filter));
    //     $query->whereBetween('created_at', [$fromDate, $toDate]);
    //   } elseif ($from_date_filter) {
    //     $fromDate = date('Y-m-d', strtotime($from_date_filter));
    //     $query->where('created_at', '>=', $fromDate);
    //   } elseif ($to_date_filter) {
    //     $toDate = date('Y-m-d', strtotime($to_date_filter));
    //     $query->where('created_at', '<=', $toDate);
    //   }
    // }

    // // Apply filters
    // if ($training_name_fill) {
    //   $query->where('training_planner_name', $training_name_fill);
    // }
    // if (!empty($training_mode_fill)  && !in_array('0', $training_mode_fill)) {
    //   $query->whereIn('training_mode', $training_mode_fill);
    // } else {
    //   $training_mode_fill = 0;
    // }
    // if ($trainer_fill) {
    //   $query->where('trainer', $trainer_fill);
    // }

    // Filter by branch_id if it's not zero
    // if ($branch_id != 0) {
    //   $query->where('branch_id', $branch_id);
    // }

    if ($training_pl_fill != '') {
      $query->where(function ($query) use ($training_pl_fill) {
        $query->where('et_training_planner.training_planner_name', 'LIKE', "%{$training_pl_fill}%")
          ->orWhere('et_training_planner.schedule_date', 'LIKE', "%{$training_pl_fill}%")
          ->orWhere('et_training_planner.trainer', 'LIKE', "%{$training_pl_fill}%")
          ->orWhere('et_training_planner.trainer_name', 'LIKE', "%{$training_pl_fill}%")
          ->orWhere('et_training_planner.training_mode', 'LIKE', "%{$training_pl_fill}%");
      });
    }


    // Execute the query
    $training = $query->orderBy('sno', 'desc')->paginate($perpage);
    // return $training_name_fill;

    $totalTraining = TrainingPlannerModel::select('*')->where('status', '!=', 2)->orderBy('sno', 'desc')->count('sno');

    $branch = BranchModel::select('*')->where('status', '!=', 2)->get();

    $totalTrainingMonth = TrainingPlannerModel::select('*')
      ->where('status', '!=', 2)
      ->whereMonth('created_at', Carbon::now()->month)
      ->whereYear('created_at', Carbon::now()->year)
      ->orderBy('sno', 'desc')
      ->count('sno');

    return view('content.branch_management.training_planner.list', [
      't_list' => $training,
      'perpage' => $perpage,
      // 'trainer_branch_id' => $branch_id,
      'totalTraining' => $totalTraining,
      'branch' => $branch,
      'totalTrainingMonth' => $totalTrainingMonth,
      // 'training_name_fill' => $training_name_fill,
      // 'training_mode_fill' => $training_mode_fill,
      'training_pl_fill' => $training_pl_fill,
      // 'trainer_fill' => $trainer_fill,
      // 'date_filter' => $date_filter,
    ])->with('filter_on', true);
  }



  public function Status($id, Request $request)
  {

    $training =  TrainingPlannerModel::where('sno', $id)->first();
    $training->status = $request->input('status', 0);
    $training->update();
    if ($training) {
      return response([
        'status'    => 200,
        'message'   => 'Training Planner Status Successfully Updated!',
        'error_msg' => 'Could not, update  Training Planner  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Training Planner  Status!',
        'error_msg' => 'Could not, update  Training Planner  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $updt_training = TrainingPlannerModel::where('sno', $id)->first();
    $updt_training->status = 2;
    $updt_training->Update();

    if ($updt_training) {
      return response([
        'status'    => 200,
        'message'   => 'Training Planner Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Training Planner ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }


  public function getAllStaff(Request $request)
  {
      $branch_ids = $request->input('branch_ids');  // Accept branch_ids from the frontend
  
      // If branch_ids is a string (e.g., '2,6'), convert it to an array
      if (is_string($branch_ids)) {
          $branch_ids = explode(',', $branch_ids);  // Convert the comma-separated string into an array
      }
  
      // If branch_ids is not 0 and is an array, use 'whereIn' to get staff from multiple branches
      if ($branch_ids && $branch_ids != 0) {
          $staff = StaffModel::select('*')->where('status', 0)
                              ->whereIn('branch_id', $branch_ids)  // Use whereIn for multiple branches
                              ->get();
      } else {
          $staff = StaffModel::select('*')->where('status', 0)
                              ->get();
      }
      // return $staff;
      return response()->json($staff);
  }
  
  // Method to exclude a selected trainer from the staff list
  public function getStaffExcluding($trainerId, Request $request)
  {
      $branch_ids = $request->input('branch_ids');  // Accept branch_ids from the frontend
  
      if (is_string($branch_ids)) {
          $branch_ids = explode(',', $branch_ids); 
      }
  
      if ($branch_ids && $branch_ids != 0) {
          $staff = StaffModel::select('*')->where('sno', '!=', $trainerId)
                              ->where('status', 0)
                              ->whereIn('branch_id', $branch_ids)  
                              ->get();
      } else {
          $staff = StaffModel::select('*')->where('sno', '!=', $trainerId)
                              ->where('status', 0)
                              ->get();
      }
      // return $staff;
      return response()->json($staff);
  }

  public function jobPosition(){
    $jobs = jobPositionModel::select('*')->where('status', '!=',2)->get();
    return $jobs;
    // return response()->json($jobs);
  }

  public function branchList(){
    $branches = BranchModel::select('*')->where('status', '!=',2)->get();
    return $branches;
    // return response()->json($jobs);
  }

  public function Add(Request $request)
  {
    // return $request;
    // $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'training_planner_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $training_planner_name              = ucfirst($request->training_planner_name);
      $training_mode                      = $request->training_mode;
      $trainer                            = $request->trainer;
      $trainer_name                       = $request->trainer_name;
      $duration                           = $request->duration;
      $department                           = $request->department_add;
      $schedule_date                      = date('Y-m-d', strtotime($request->training_planner_sch_dt_add));
      $schedule_time                      = date('H:i:s', strtotime($request->training_planner_sch_time_add));
      $training_desc                      = $request->training_desc;
      $all_check                          = $request->staff_list_add ? 0 : 1;
      $staff_check                        = $request->staff_check;
      $branch_id                          = $request->branch_name;
      //   return $request->staff_check;
      $user_id                    = auth()->user()->user_id;

      $category_check = TrainingPlannerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$category_check) {

        $year = substr(date('y'), -2);
        $training_planner_id = 'TP-0001/' . $year;
      } else {

        $data = $category_check->training_planner_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf('BT-%04d', $next_number);

        $year = substr(date('y'), -2);
        $training_planner_id = $request . '/' . $year;
      }

      $add_category = new TrainingPlannerModel();
      $add_category->training_planner_id                 = $training_planner_id;
      $add_category->training_planner_name               = $training_planner_name;
      $add_category->training_mode                       = $training_mode;
      $add_category->trainer                             = $trainer;
      $add_category->trainer_name                        = $trainer_name;
      $add_category->department                          = $department;
      $add_category->training_duration                   = $duration;
      $add_category->schedule_date                       = $schedule_date;
      $add_category->schedule_time                       = $schedule_time;
      $add_category->training_desc                       = $training_desc;
      $add_category->staff_check = json_encode($staff_check);
      $add_category->all_check = $all_check;
      $add_category->created_by                = $user_id;
      $add_category->updated_by                = $user_id;
      $add_category->branch_id                 = json_encode($branch_id);

      //  return $add_category;
      $add_category->save();

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Training Planner added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Training Planner!'
        ]);
      }
      // return $result;
      return redirect()->back()->with('success', 'Training Planner Created successfully!');
    }
  }


  public function Update(Request $request)
  {
    // return $request;
    // $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'training_planner_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $training_planner_id                = $request->training_planner_id_edit;
      $training_planner_name              = ucfirst($request->training_planner_name);
      $training_mode                      = $request->training_mode_edit;
      $trainer                            = $request->trainer;
      $trainer_name                       = $request->trainer_name;
      $duration                           = $request->duration;
      $schedule_date                      = date('Y-m-d', strtotime($request->training_planner_sch_dt_edit));
      $schedule_time                      = date('H:i:s', strtotime($request->training_planner_sch_time_edit));
      $training_desc                      = $request->training_desc;
      $all_check                          = $request->staff_list_edit ? 0 : 1;
      $staff_check                        = $request->staff_check;
      $user_id                            = auth()->user()->user_id;
      $branch_id                          = $request->branch_name_edit;
      $department                           = $request->department_edit;
      // dd($training_planner_name);
      $add_category = TrainingPlannerModel::where('sno', $training_planner_id)->first();
      // dd($add_category);

      $add_category->training_planner_name               = $training_planner_name;

      $add_category->training_mode                       = $training_mode;
       $add_category->department                   = $department;
      $add_category->trainer                             = $trainer;
      $add_category->trainer_name                        = $trainer_name;
      $add_category->training_duration                   = $duration;
      $add_category->schedule_date                       = $schedule_date;
      $add_category->schedule_time                       = $schedule_time;
      $add_category->training_desc                       = $training_desc;
      $add_category->staff_check = json_encode($staff_check);
      $add_category->all_check = $all_check;
      $add_category->created_by                = $user_id;
      $add_category->updated_by                = $user_id;
      $add_category->branch_id                 = json_encode($branch_id);

      // dd($add_category);
      // return $add_category;
      $add_category->update();

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Training Planner updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Training Planner!'
        ]);
      }
      // return $result;
      return redirect()->back()->with('success', 'Training Planner Created successfully!');
    }
  }


  public function edit($id)
  {
    $data = TrainingPlannerModel::where('sno', $id)->first();

    if ($data && isset($data->staff_check)) {
      $data->staff_check = json_decode($data->staff_check);
    }
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }


  public function tableGet(Request $request)
  {
      $id = $request->id;
      $trainerId = $request->trainer_id;
      $branch_id = $request->branch_id;
      $depart_id = $request->departmentId;
      if (is_string($branch_id)) {
          $branch_ids = explode(',', $branch_id);  // Convert the comma-separated string into an array
      }
      $data = TrainingPlannerModel::where('sno', $id)->first();
  
      if ($data) {
          // Decode the JSON string into an associative array
          $checked_staff = json_decode($data->staff_check, true);
          // return $checked_staff;
          // Check if the decoded result is an array
          if (is_array($checked_staff)) {
              if ($trainerId == 0) {
                  $staffData = StaffModel::where('status', 0)
                                    ->whereIn('branch_id', $branch_ids)
                                    ->where('sno','>',1)
                                    ->where('department_id',$depart_id)
                                    ->get();
                              // return $staffData;
              } else {
                  // Fetch staff excluding the selected trainer
                  $staffData = StaffModel::where('sno', '<>', $trainerId)
                                         ->whereIn('branch_id', $branch_ids)
                                         ->where('department_id',$depart_id)
                                         ->where('status', 0)
                                         ->where('sno','>',1)
                                         ->get();
              }
  
              // Retrieve departments and job positions for mapping
              $departments = DepartmentModel::where('status', '!=', 2)
                                            ->pluck('department_name', 'sno');
              $job_positions = JobpositionModel::where('status', 0)
                                               ->pluck('job_position_name', 'sno');
  
              $output = '';
              foreach ($staffData as $staff) {
                  $output .= '<tr>';
                  $output .= '<td>';
                  // Ensure $checked_staff is an array before using in_array
                  $isChecked = (is_array($checked_staff) && in_array($staff->sno, $checked_staff)) ? 'checked' : '';
                  $output .= '<input class="form-check-input bulk_chk_edit" type="checkbox" value="' . $staff->sno . '" id="staff_check_edit_' . $staff->sno . '" name="staff_check[]" ' . $isChecked . ' />';
                  $output .= '</td>';
                  $output .= '<td>' . $staff->staff_name . '</td>';
                  $output .= '<td>' . ($departments[$staff->department_id] ?? 'Unknown Department') . '</td>';
                  $output .= '<td>' . ($job_positions[$staff->position_role] ?? 'Unknown Position') . '</td>';
                  $output .= '</tr>';
              }
  
              return $output;
          } else {
              // Return error if the staff_check is not a valid array
              return response()->json(['error' => 'Invalid staff data (staff_check is not an array)'], 400);
          }
      } else {
          return false;
      }
  }
  



  // public function View($id, Request $request)
  // {
  //     $branch_id = $request->user()->branch_id;


  //     $training = TrainingPlannerModel::where('status', '!=', 2)->where('branch_id', $branch_id)
  //         ->where('sno', $id)
  //         ->first();

  //     return view('content.branch_management.training_planner.list', [
  //         'view' => $training,
  //     ]);
  // }


  public function Attendance($id, Request $request)
  {
    // return $id;
    $data = TrainingPlannerModel::where('sno', $id)->first();

    // return $data;

    if ($data && isset($data->staff_check)) {
      $data->staff_check = json_decode($data->staff_check);
    }

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }


  public function completeTraining(Request $request)
  {
    // return $request;
    $trainingPlannerId = $request->input('training_planner_id');
    $data = TrainingPlannerModel::where('sno', $trainingPlannerId)->first();

    // return $data;

    if (!$data) {
      return response()->json(['message' => 'Training planner not found'], 404);
    }

    // Prepare the attendance data for saving
    $attendanceData = [];
    foreach ($request->input('attendance') as $attendance) {
      $attendanceData[] = [
        'staff_id' => $attendance['staff_id'],
        'attendance' => $attendance['attendance']
      ];
    }
    $attend =  json_encode($attendanceData);
    // return $attend;

    $data->attendance_status  = $attend;
    $data->update();


    return response()->json([
      'status' => 200,
      'message' => 'Attendance updated successfully!',
      'data' => $data,
    ], 200);
  }

  public function get_branch_staff(Request $request)
  {
      $branchIds = $request->input('branch_ids', []);
      $departmentId = $request->input('department_id');
       $query = StaffModel::whereIn('branch_id', $branchIds)->where('status', 0);

        if ($departmentId) {
            $query->where('department_id', $departmentId);
        }
    
        $staffList = $query->get();

      return response()->json([
          'staff_list' => $staffList
      ]);
  }
}