<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\UserRoleModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use App\Models\IncentiveCriteriaModel;
use App\Models\IncentiveModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;



class ManageIncentive extends Controller
{


    public function index()
    {

        return view('content.branch_management.manage_incentive.manage_incentive');
    }
    // Fetch role based on Branch
    public function getroleIncentive(Request $request)
    {

        $departments = UserRoleModel::where('status', 0)->get(['sno', 'role_name']);
        return response()->json(['status' => 200, 'data' => $departments]);
    }

    public function getroleIncentivedata(Request $request)
    {
        $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

        $incentivedata = IncentiveModel::where('role_id', $request->role_id)
            ->whereDate('incentive_month', $incentiveMonthDate->format('Y-m-d'))
            ->where('branch_id', $request->branch_id)
            ->where('status', 0)
            ->first();
            if(!$incentivedata){
            $incentivedata = IncentiveModel::where('role_id', $request->role_id)
            ->where('branch_id', $request->branch_id)
            ->where('status', 0)
            ->orderBy('sno','desc')
            ->first();
            $incentivedata->previousMonth=1;
            }
        return response()->json(['status' => 200, 'data' => $incentivedata]);
    }
    public function Incentivecreateupdate(Request $request)
    {
        try {
            // Convert to proper date
            $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

            // Validate input
            // $validatedData = $request->validate([
            //     'branch_id' => 'required|integer',
            //     'role_id' => 'required|integer',
            //     'tenx_award' => 'nullable|integer',
            //     'tenx_warrior' => 'nullable|integer',
            //     'eci_count' => 'nullable|integer',
            //     'eci_reward' => 'nullable|integer',
            //     'bi_amount' => 'nullable|integer',
            //     'si_crash_course' => 'nullable|integer',
            //     'si_profession_course' => 'nullable|integer',
            //     'si_tesbo_course' => 'nullable|integer',
            //     'pi_percentage' => 'nullable|integer',
            //     'spot_incentive_month' => 'nullable|integer',
            //     'spot_incentive_day' => 'nullable|integer',
            //     'performance_incentive_missed_call' => 'nullable|integer',
            //     'performance_incentive_outgoing_call_count' => 'nullable|integer',
            //     'performance_incentive_reward' => 'nullable|integer',
            //     'luxury_incentive' => 'nullable',
            //     'pi_slab_json' => 'nullable',
            // ]);

            $validatedData = $request->validate([
                'branch_id' => 'required|integer',
                'role_id' => 'required|integer',
                'tenx_award' => 'nullable|integer',
                'second_payment_check' => 'nullable|integer',
                'tenx_warrior' => 'nullable|integer',
                'eci_count' => 'nullable|integer',
                'warrior_reward' => 'nullable',
                'eci_reward' => 'nullable|integer',
                'si_incentive_json' => 'nullable',
                'bi_amount' => 'nullable',
                'ri_amount' => 'nullable',
                'spot_incentive_percent' => 'nullable',
                'spot_incentive_day' => 'nullable',
                'spot_incentive_month' => 'nullable',
                'double_x_reward' => 'nullable',
                'check_accepted_paper' => 'nullable',
                'journal_extra_reward' => 'nullable',
                'journal_extra_count' => 'nullable',
                'si_lead_reward' => 'nullable|integer',
                'pi_lead_base' => 'nullable|integer',
                'perform_incent_attend' => 'nullable|integer',
                // 'pi_lead_reward' => 'nullable|integer',
                'pi_lead_percent' => 'nullable',
                'spot_incentive_lead' => 'nullable',
                'performance_incentive_missed_call' => 'nullable|integer',
                'performance_incentive_outgoing_call_count' => 'nullable|integer',
                'performance_incentive_reward' => 'nullable|integer',
                'luxury_incentive' => 'nullable',
                'pi_slab_json' => 'nullable',
                 // bh role
                'ceiling' => 'nullable',
                'quarterly' => 'nullable',
                'twenty_five_percentage' => 'nullable',
                'fifty_percentage' => 'nullable',
                'six_month' => 'nullable',
                'twelve_month' => 'nullable',
                'nine_monthadd' => 'nullable',
                'twelve_monthadd' => 'nullable',
                'overall_year' => 'nullable',
                'dynamic' => 'nullable',
                'presale' => 'nullable',
                'megabonus' => 'nullable',
                'eci_second_reward' => 'nullable',
                'abv_reward' => 'nullable',
                'target_day' => 'nullable',
                'team_target' => 'nullable',
                'abv_achieved_reward' => 'nullable',

                'old_month_per' => 'nullable',
                'old_month_collection_reward' => 'nullable',
                'drop_collection_reward' => 'nullable',
                'bi_collection_reward' => 'nullable',
                'issue_free' => 'nullable',
                'ondate_collection_reward' => 'nullable',
            ]);
            
            $user_id = $request->user()->user_id;
            // Add date
            $validatedData['incentive_month'] = $incentiveMonthDate->format('Y-m-d');

            // Check by branch, role, and month
            $incentive = IncentiveModel::where('branch_id', $validatedData['branch_id'])
                ->where('role_id', $validatedData['role_id'])
                ->whereDate('incentive_month', $validatedData['incentive_month'])
                ->first();

            if ($incentive) {
                $validatedData['updated_by'] = $user_id;
                 $incentive->update($validatedData);
            } else {
                $validatedData['created_by'] = $user_id;
                $validatedData['updated_by'] = $user_id;
                IncentiveModel::create($validatedData);
            }

            return response()->json(['status' => 200, 'message' => 'Incentive saved successfully.']);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong.',
                'error' => $e->getMessage()
            ]);
        }
    }
    public function checkIncentive(Request $request)
    {
        $user = Auth::user(); // logged-in user
 
      $today = Carbon::now();
 
        $exists = IncentiveModel::where('branch_id', $user->branch_id)
            ->where('role_id', $user->role_id)
            ->whereNotIn('role_id',[32,36,15])
            ->whereYear('incentive_month', $today->year)
            ->whereMonth('incentive_month', $today->month)
            ->exists();
 
        return response()->json([
            'isIncentive' => $exists
        ]);
    }

    public function getCriteria(Request $request)
  {
    $request->validate([
      'incentive_key' => 'required|string',
      'role_id' => 'required|integer',
      'branch_id' => 'required|integer',
      'month' => 'required|string',
      'year' => 'required|string',
    ]);
 
    $criteria = IncentiveCriteriaModel::where([
      'incentive_key' => $request->incentive_key,
      'role_id' => $request->role_id,
      'branch_id' => $request->branch_id,
    ])->first();
 
    if ($criteria) {
      return response()->json([
        'status' => 200,
        'data' => $criteria
      ]);
    }
 
    return response()->json([
      'status' => 404,
      'message' => 'No criteria found'
    ]);
  }
 
  public function saveCriteria(Request $request)
  {
    $request->validate([
      'incentive_key' => 'required|string',
      'role_id' => 'required|integer',
      'branch_id' => 'required|integer',
      'month' => 'required|string',
      'year' => 'required|string',
      'criteria_points' => 'required|json',
    ]);
 
    try {
      $criteria = IncentiveCriteriaModel::updateOrCreate(
        [
          'incentive_key' => $request->incentive_key,
          'role_id' => $request->role_id,
          'branch_id' => $request->branch_id,
        ],
        [
          'criteria_points' => $request->criteria_points,
        ]
      );
 
      return response()->json([
        'status' => 200,
        'message' => 'Criteria saved successfully',
        'data' => $criteria
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Failed to save criteria: ' . $e->getMessage()
      ], 500);
    }
  }
    
}
