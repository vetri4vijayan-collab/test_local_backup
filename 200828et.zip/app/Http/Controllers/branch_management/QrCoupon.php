<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Models\ManageCouponModel;
use App\Models\QrCouponModel;
use App\Models\ManageCouponHistoryModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

// QrPromotion controller

class QrCoupon extends Controller
{


  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }
    $search_fill = $request->search_fill ?? '';
   
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;

    $query = QrCouponModel::select('et_discount_lead.*', 'et_qr_promotion.discount_name', 'et_qr_promotion.discount_type', 'et_qr_promotion.min_value', 'et_qr_promotion.max_value', 'et_qr_promotion.expiry_date')->leftJoin('et_qr_promotion', 'et_qr_promotion.sno', '=', 'et_discount_lead.discount_id')->where('et_discount_lead.status', '!=', 2)->where('et_discount_lead.branch_id', '=', $branch_id)->whereIn('et_qr_promotion.discount_type', [0,1]);

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('et_qr_promotion.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('et_qr_promotion.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('et_qr_promotion.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('et_qr_promotion.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('et_qr_promotion.created_at', '<=', $toDate);
      }
    }
    
    if ($search_fill != '') {
        $query->where(function ($sub_query) use ($search_fill) {
            $sub_query->where('et_qr_promotion.discount_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.min_value', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.max_value', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.expiry_date', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_discount_lead.discount_lead_phone', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_discount_lead.discount_lead_name', 'LIKE', "%{$search_fill}%");
        });
    }

    // Fetch Branch list ordered by sno in descending order
    $List_table = $query->orderBy('sno', 'desc')->paginate($perpage);

    // Add flag to each result
    foreach ($List_table as $item) {
      $used = ManageCouponModel::where('coupon_code', $item->discount_code)
      ->whereIn('sno', function ($query) {
          $query->select('coupon_id')
                ->from('et_coupon_usage_history');
      })
      ->exists();
      $item->coupon_used = $used;
    }

    return view('content.branch_management.qr_coupon.list', [
      'List_table' => $List_table,
      'search_fill' => $search_fill,
      'perpage' => $perpage,
      'date_filter' => $date_filter,

    ])->with('filter_on', false);
  }

  public function redeemCoupon($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;

    $coupon_chk = QrCouponModel::select('et_discount_lead.*', 'et_qr_promotion.discount_name','et_qr_promotion.is_status', 'et_qr_promotion.discount_type', 'et_qr_promotion.min_value', 'et_qr_promotion.max_value', 'et_qr_promotion.expiry_date')->leftJoin('et_qr_promotion', 'et_qr_promotion.sno', '=', 'et_discount_lead.discount_id')->where('et_discount_lead.sno', '=',$id)->where('et_discount_lead.branch_id', '=', $branch_id)->where('et_discount_lead.status', '=', 0)->whereIn('et_qr_promotion.discount_type', [0,1])->first();

    // return $coupon_chk;

    if($coupon_chk){
      
      $chk = ManageCouponModel::where('coupon_name', $coupon_chk->discount_name)
                ->where('coupon_code', $coupon_chk->discount_code)
                ->where('status', '!=', 2)
                ->first();

                
            // Generate coupon ID
            $category_check = ManageCouponModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')->first();
    
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $coupon_id = "COU-0001/" . $year;
            } else {
                $data = $category_check->coupon_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
                $next_number = (int)$result + 1;
                $request_id = sprintf("COU-%04d", $next_number);
    
                $year = substr(date("y"), -2);
                $coupon_id = $request_id . '/' . $year;
            }
    
            // Create new Coupon record for each branch
            $add_category = new ManageCouponModel();
    
            $add_category->coupon_code      = $coupon_chk->discount_code;
            $add_category->coupon_id        = $coupon_id;
            $add_category->coupon_name      = ucfirst($coupon_chk->discount_name);
            $add_category->coupon_value     = $coupon_chk->discount_value;
            $add_category->coupon_type      = $coupon_chk->discount_type == 0 ? 'percentage' : 'rupee';
            $add_category->max_usage_count  = 1;
            $add_category->end_date         = $coupon_chk->expiry_date;
            $add_category->branch_id        = $coupon_chk->branch_id; // Save per branch entry
            $add_category->is_qr            = 1;
            $add_category->created_by       = $user_id;
            $add_category->updated_by       = $user_id;
            // return $add_category;
            // Save the coupon
            if ($add_category->save()) {
              $coupon_chk->status       = 1;
              $coupon_chk->update();

                return response()->json([
                    'status' => 200,
                    'message' => 'Coupon added successfully!'
                ]);
            } else {
              return response()->json([
                  'status' => 500,
                  'error_msg' => 'Could not add the Coupon!'
              ]);
            }
    }else {
      return response()->json([
          'status' => 404,
          'error_msg' => 'Discount Lead not found!'
      ]);
    }
  }

}