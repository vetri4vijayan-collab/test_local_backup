<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\DefaultGoalSetModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class SetGoal extends Controller
{
  public function index()
  {
    return view('content.branch_management.set_goal');
  }
  public function getDepartmentsGoal(Request $request)
  {

    $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
  }
  public function getTeamGoal(Request $request)
  {
    $branchId = $request->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $year_id = $request->year;

    // Convert month name to number if necessary
    if (!empty($request->month_id)) {
      if (!is_numeric($request->month_id)) {
        $monthNumber = date('m', strtotime($request->month_id . ' 1'));
        $request->month_id = (int) $monthNumber;
      } else {
        $request->month_id = (int) $request->month_id;
      }
    }
    // Fetch the department details
    $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

    $staffcount = StaffModel::where('et_staff.branch_id', $branchId)
      ->where('et_staff.department_id', $departmentId)
      ->where('et_staff.status', 0)->count();


    // Get goal records for the selected department and month
    $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('team_goal_month', $request->month_id)
      ->where('team_goal_year', $year_id)
      ->first();
    // if empty goalteam means this record to default goalset show send
    if (empty($goalteam)) {
      $goalteam =  DefaultGoalSetModel::where('branch_id', $branchId)->where('department_id', $departmentId)->first();
    }
    // return $goalteam;

    // Prepare goal details response
    $goalteamDetails = [
      '1' => $goalteam,
      'department_name' => optional($department)->department_name ?? '',
      'department_id'   => optional($department)->sno ?? '',
      'team_id'         => optional($goalteam)->sno ?? '',
      'ten_x' => json_decode(optional($goalteam)->ten_x ?? '{}', true),
      'conversion_over_all'     => optional($goalteam)->conversion_over_all ?? optional($goalteam)->conversion  ?? 0,
      'conversion_check'        => optional($goalteam)->conversion_check ?? 0,
      'conversion_type'         => optional($goalteam)->conversion_type ?? 0,
      'cr_over_all'     => optional($goalteam)->cr_over_all ?? optional($goalteam)->CR ?? 0,
      'cr_check'        => optional($goalteam)->cr_check ?? optional($goalteam)->CR_check ?? 0,
      'cr_type'         => optional($goalteam)->cr_type ?? 0,
      'abv_over_all'    => optional($goalteam)->abv_over_all ?? optional($goalteam)->ABV ?? 0,
      'abv_check'       => optional($goalteam)->abv_check ?? optional($goalteam)->ABV_check ?? 0,
      'abv_type'        => optional($goalteam)->abv_type ?? 0,
      'acv_over_all'    => optional($goalteam)->acv_over_all ?? optional($goalteam)->ACV ?? 0,
      'acv_check'       => optional($goalteam)->acv_check ?? optional($goalteam)->ACV_check ?? 0,
      'acv_type'        => optional($goalteam)->acv_type ?? 0,
      'avg_call_out_over_all' => optional($goalteam)->avg_call_out_over_all ?? optional($goalteam)->avg_call_out ?? 0,
      'avg_call_out_check'    => optional($goalteam)->avg_call_out_check ?? 0,
      'avg_call_out_type'     => optional($goalteam)->avg_call_out_type ?? 0,
      'no_of_walk_over_all'   => optional($goalteam)->no_of_walk_over_all ?? optional($goalteam)->no_of_walk ?? 0,
      'no_of_walk_check'      => optional($goalteam)->no_of_walk_check ?? 0,
      'no_of_walk_type'       => optional($goalteam)->no_of_walk_type ?? 0,
      'no_of_followup_over_all' => optional($goalteam)->no_of_followup_over_all ?? optional($goalteam)->no_of_followup ?? 0,
      'no_of_followup_check'    => optional($goalteam)->no_of_followup_check ?? 0,
      'no_of_followup_type'     => optional($goalteam)->no_of_followup_type ?? 0,
      'working_hours_over_all'          => optional($goalteam)->working_hours_over_all ?? optional($goalteam)->working_hours ?? 0,
      'working_hours_check'             => optional($goalteam)->working_hours_check ?? 0,
      'working_hours_type'              => optional($goalteam)->working_hours_type ?? 0,
      'no_of_post_sale_over_all' => optional($goalteam)->no_of_post_sale_over_all ?? optional($goalteam)->no_of_post_sale ?? 0,
      'no_of_post_sale_check'    => optional($goalteam)->no_of_post_sale_check ?? 0,
      'no_of_post_sale_type'     => optional($goalteam)->no_of_post_sale_type ?? 0,
      'no_of_outstanding_over_all' => optional($goalteam)->no_of_outstanding_over_all ?? optional($goalteam)->no_of_outstanding ?? 0,
      'no_of_outstanding_check'    => optional($goalteam)->no_of_outstanding_check ?? 0,
      'no_of_outstanding_type'     => optional($goalteam)->no_of_outstanding_type ?? 0,
      'min_no_of_students_over_all' => optional($goalteam)->min_no_of_students_over_all ?? optional($goalteam)->min_no_of_students ?? 0,
      'min_no_of_students_check'    => optional($goalteam)->min_no_of_students_check ?? 0,
      'min_no_of_students_type'     => optional($goalteam)->min_no_of_students_type ?? 0,
      'rework_over_all' => optional($goalteam)->rework_over_all ?? optional($goalteam)->rework ?? 0,
      'rework_check'    => optional($goalteam)->rework_check ?? 0,
      'rework_type'     => optional($goalteam)->rework_type ?? 0,
      
      'no_of_papers_over_all' => optional($goalteam)->no_of_papers_over_all ?? optional($goalteam)->no_of_papers ?? 0,
      'no_of_papers_check'    => optional($goalteam)->no_of_papers_check ?? 0,
      'no_of_papers_type'     => optional($goalteam)->no_of_papers_type ?? 0,

      'productions_over_all'        => optional($goalteam)->productions_over_all ?? optional($goalteam)->productions ?? 0,
      'productions_check'           => optional($goalteam)->productions_check ?? 0,
      'productions_type'            => optional($goalteam)->productions_type ?? 0,
      'no_of_reviews_over_all'      => optional($goalteam)->no_of_reviews_over_all ?? optional($goalteam)->no_of_reviews ?? 0,
      'no_of_reviews_check'         => optional($goalteam)->no_of_reviews_check ?? 0,
      'no_of_reviews_type'          => optional($goalteam)->no_of_reviews_type ?? 0,
      'given_links_over_all'        => optional($goalteam)->given_links_over_all ?? optional($goalteam)->given_links ?? 0,
      'given_links_check'           => optional($goalteam)->given_links_check ?? 0,
      'given_links_type'            => optional($goalteam)->given_links_type ?? 0,
      'no_of_placements_over_all'   => optional($goalteam)->no_of_placements_over_all ?? optional($goalteam)->no_of_placements ?? 0,
      'no_of_placements_check'      => optional($goalteam)->no_of_placements_check ?? 0,
      'no_of_placements_type'       => optional($goalteam)->no_of_placements_type ?? 0,
      'mou_over_all'                => optional($goalteam)->mou_over_all ?? optional($goalteam)->mou ?? 0,
      'mou_check'                   => optional($goalteam)->mou_check ?? 0,
      'mou_type'                    => optional($goalteam)->mou_type ?? 0,
      'reference_sales_over_all'     => optional($goalteam)->reference_sales_over_all ?? optional($goalteam)->reference_sales ?? 0,
      'reference_sales_check'        => optional($goalteam)->reference_sales_check ?? 0,
      'reference_sales_type'         => optional($goalteam)->reference_sales_type ?? 0,
      'status' => optional($goalteam)->status == 1 ? true : false,
      'month'  => $month_id
    ];

    return response()->json([
      'status' => 200,
      'data'   => $goalteamDetails
    ]);
  }
  public function saveTeamGoalset(Request $request)
  {
    // return $request;
    // Validate incoming data
    $validatedData = $request->validate([
      'department_id' => 'required|numeric',
      'month_id'      => 'required',
      'year_id'      => 'required',
      'branch_id'      => 'required',
      'conversion_over_all' => 'nullable|numeric',
      'conversion_check' => 'nullable|numeric',
      'conversion_type' => 'nullable|numeric',
      'cr_over_all'   => 'nullable|numeric',
      'cr_check'      => 'nullable|numeric',
      'cr_type'       => 'nullable|numeric',
      'abv_over_all'  => 'nullable|numeric',
      'abv_check'     => 'nullable|numeric',
      'abv_type'      => 'nullable|numeric',
      'acv_over_all'  => 'nullable|numeric',
      'acv_type'      => 'nullable|numeric',
      'acv_check'     => 'nullable|numeric',
      'avg_call_out_over_all'   => 'nullable|numeric',
      'avg_call_out_check'      => 'nullable|numeric',
      'avg_call_out_type'       => 'nullable|numeric',
      'no_of_walk_over_all'     => 'nullable|numeric',
      'no_of_walk_check'        => 'nullable|numeric',
      'no_of_walk_type'         => 'nullable|numeric',
      'no_of_followup_over_all' => 'nullable|numeric',
      'no_of_followup_check'    => 'nullable|numeric',
      'no_of_followup_type'     => 'nullable|numeric',

      'working_hours_over_all'            => 'nullable|numeric',
      'working_hours_check'               => 'nullable|numeric',
      'working_hours_type'                => 'nullable|numeric',

      'rework_over_all' => 'nullable|numeric',
      'rework_check'    => 'nullable|numeric',
      'rework_type'     => 'nullable|numeric',

      'no_of_papers_over_all' => 'nullable|numeric',
      'no_of_papers_check'    => 'nullable|numeric',
      'no_of_papers_type'     => 'nullable|numeric',

      'no_of_papers_over_all' => 'nullable|numeric',
      'no_of_papers_check'    => 'nullable|numeric',
      'no_of_papers_type'     => 'nullable|numeric',

    ]);

    $branchId = $validatedData['branch_id'];
    $departmentId = $validatedData['department_id'];
    $month_id = $validatedData['month_id'];
    $year_id = $validatedData['year_id'];
    $createdBy = $request->user()->user_id;

    // Convert month_id if it's a string
    if (!is_numeric($month_id)) {
      $month_id = date('m', strtotime($month_id . ' 1'));
    }

    $tenXData = collect($request->all())
      ->filter(function ($value, $key) {
        return str_ends_with($key, '_10x');
      });

    $validatedData['ten_x'] = $tenXData->toJson();
    //  return  $year_id;
    // Update or create the goal record
    $goal = GoalSetTeamModel::updateOrCreate(
      [
        'team_goal_month' => (int)$month_id,
        'team_goal_year' => $year_id,
        'branch_id'       => (int) $branchId,
        'department_id'   => (int) $departmentId,
      ],
      array_merge($validatedData, [
        'created_by' => $createdBy,
        'updated_by' => $createdBy,
        'status'     => 1 // Mark as 'Goal Set'
      ])
    );

    return response()->json([
      'status'  => 200,
      'message' => 'Team goal successfully updated!',
      'data'    => $goal
    ]);
  }
  public function getStaffGoal(Request $request)
  {
    $branchId = $request->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;

    if (!empty($month_id)) {
      if (!is_numeric($month_id)) {
        // Convert month name (e.g., "February") to its numeric value
        $monthNumber = date('m', strtotime($month_id . ' 1'));
        $request->merge(['month_id' => (int)$monthNumber]);
      } else {
        // Ensure month_id is an integer if it's already numeric
        $request->merge(['month_id' => (int)$month_id]);
      }
    }


    //  return $request->all();
    // return $request->month_id;
    // Get staff members with department and role details
    $staff = StaffModel::where('et_staff.branch_id', $branchId)
      ->where('et_staff.department_id', $departmentId)
      ->where('et_staff.status', 0)
      ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
      ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
      ->get([
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.nick_name',
        'et_staff.gender',
        'et_staff.staff_image',
        'et_department.department_name',
        'et_user_role.role_name'
      ]);

     $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $departmentId)->where('et_goal_set_team.branch_id', $branchId)
      ->where('et_goal_set_team.team_goal_month', $request->month_id)
      ->first();
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('goal_month', $request->month_id)
      ->get();
    // return $goalsetteam;

    // if empty goalteam means this record to default goalset show send
    // if(empty($goalteam)){
    //   $goalteam =  DefaultGoalSetModel::first();
    // }
    // Convert goalsetRecords to an associative array for easy lookup
    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    // Attach goal details to staff members
    $staffDetails = [];
    foreach ($staff as $member) {
      $staffDetails[] = [
        'sno'           => $member->sno,
        'staff_name'    => $member->staff_name,
        'nick_name'     => $member->nick_name,
        'gender'        => $member->gender,
        'staff_image'   => $member->staff_image,
        'conversion_check'       => $goalsetteam->conversion_check ?? 0,
        'cr_check'                => $goalsetteam->cr_check ?? 0,
        'abv_check'              => $goalsetteam->abv_check ?? 0,
        'acv_check'               => $goalsetteam->acv_check ?? 0,
        'avg_call_out_check'         => $goalsetteam->avg_call_out_check ?? 0,
        'no_of_walk_check'           => $goalsetteam->no_of_walk_check ?? 0,
        'no_of_followup_check'       => $goalsetteam->no_of_followup_check ?? 0,
        'working_hours_check'                  => $goalsetteam->working_hours_check ?? 0,
        'no_of_post_sale_check'       => $goalsetteam->no_of_post_sale_check ?? 0,
        'no_of_outstanding_check'       => $goalsetteam->no_of_outstanding_check ?? 0,
        'min_no_of_students_check'       => $goalsetteam->min_no_of_students_check ?? 0,
        'rework_check'       => $goalsetteam->rework_check ?? 0,
        'no_of_papers_check'       => $goalsetteam->no_of_papers_check ?? 0,
        'department_name' => $member->department_name, // Fetched directly from join
        'role_name'     => $member->role_name, // Fetched directly from join
        'team_id'            => $goalsetData[$member->sno]->team_id ?? '',
        'conversion'            => $goalsetData[$member->sno]->conversion ?? '',
        'cr'            => $goalsetData[$member->sno]->CR ?? '',
        'abv'           => $goalsetData[$member->sno]->ABV ?? '',
        'acv'           => $goalsetData[$member->sno]->ACV ?? '',
        'avg_call_out'  => $goalsetData[$member->sno]->avg_call_out ?? '',
        'no_of_walk'    => $goalsetData[$member->sno]->no_of_walk ?? '',
        'no_of_followup'    => $goalsetData[$member->sno]->no_of_followup ?? '',
        'working_hours'              => $goalsetData[$member->sno]->working_hours ?? '',
        'no_of_post_sale'    => $goalsetData[$member->sno]->no_of_post_sale ?? '',
        'no_of_outstanding'    => $goalsetData[$member->sno]->no_of_outstanding ?? '',
        'min_no_of_students'    => $goalsetData[$member->sno]->min_no_of_students ?? '',
        'rework'    => $goalsetData[$member->sno]->rework ?? '',
        'no_of_papers'    => $goalsetData[$member->sno]->no_of_papers ?? '',
        
        'sales_lead_checks'    => $goalsetData[$member->sno]->sales_lead_check ?? 0,
        'status' => isset($goalsetData[$member->sno])
          ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending')
          : 'Pending',
        'month'         => $month_id
      ];
    }

    return response()->json([
      'status' => 200,
      'data' => $staffDetails
    ]);
  }
  public function addOrUpdateStaffGoal(Request $request)
  {

    //   return $request->all();
    // sales_lead_check
    // Convert month name to numeric format
    $monthName = $request->input('month_id');
    $monthNumber = date('m', strtotime($monthName . ' 1')); // Converts "February" to "02"

    // Replace month_id in the request before validation
    $request->merge(['month_id' => (int)$monthNumber]);
    $validatedData = $request->validate([
      'team_id' => 'required|integer',
      'month_id' => 'required|integer',
      'year' => 'required|integer',
      'department_id' => 'required|integer',
      'branch_id' => 'required|integer',
      'staff_goals' => 'required|array',
      'staff_goals.*.staff_id' => 'required|integer',
      'staff_goals.*.conversion' => 'nullable|integer',
      'staff_goals.*.cr' => 'nullable|integer',
      'staff_goals.*.abv' => 'nullable|integer',
      'staff_goals.*.acv' => 'nullable|integer',
      'staff_goals.*.avg_call_out' => 'nullable|integer',
      'staff_goals.*.no_of_walk' => 'nullable|integer',
      'staff_goals.*.no_of_followup' => 'nullable|integer',
      'staff_goals.*.working_hours' => 'nullable|integer',
      'staff_goals.*.no_of_post_sale' => 'nullable|integer',
      'staff_goals.*.no_of_outstanding' => 'nullable|integer',
      'staff_goals.*.rework' => 'nullable|integer',
      'staff_goals.*.no_of_papers' => 'nullable|integer',
      'staff_goals.*.min_no_of_students' => 'nullable|integer',
      'staff_goals.*.productions' => 'nullable|integer',
      'staff_goals.*.no_of_reviews' => 'nullable|integer',
      'staff_goals.*.given_links' => 'nullable|integer',
      'staff_goals.*.no_of_placements' => 'nullable|integer',
      'staff_goals.*.mou' => 'nullable|integer',
      'staff_goals.*.reference_sales' => 'nullable|integer',
      'staff_goals.*.sales_lead_check' => 'nullable',
    ]);

    $branchId = $validatedData['branch_id'];
    $departmentId = $validatedData['department_id'];
    $month = $validatedData['month_id'];
    $year = $validatedData['year'];
    $team_id = $validatedData['team_id'];
    $createdBy = $request->user()->user_id;
    // return $request->all();
    $branch_check = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first();

    $branch_code = $branch_check->city_short_code;


    foreach ($validatedData['staff_goals'] as $goalData) {
      GoalSetStaffModel::updateOrCreate(
        [
          'goal_month' => $month,
          'goal_date' => "{$year}-{$month}-01", // Proper date format
          'branch_id' => $branchId,
          'department_id' => $departmentId,
          'staff_id' => $goalData['staff_id'],
        ],
        [
          'team_id' => $team_id,
          'conversion' => $goalData['conversion'] ?? 0,
          'CR' => $goalData['cr'] ?? 0,
          'ABV' => $goalData['abv'] ?? 0,
          'ACV' => $goalData['acv'] ?? 0,
          'avg_call_out' => $goalData['avg_call_out'] ?? 0,
          'no_of_walk' => $goalData['no_of_walk'] ?? 0,
          'no_of_followup' => $goalData['no_of_followup'] ?? 0,
          'working_hours' => $goalData['working_hours'] ?? 0,
          'no_of_post_sale' => $goalData['no_of_post_sale'] ?? 0,
          'no_of_outstanding' => $goalData['no_of_outstanding'] ?? 0,
          'rework' => $goalData['rework'] ?? 0,
          'no_of_papers' => $goalData['no_of_papers'] ?? 0,
          'min_no_of_students' => $goalData['min_no_of_students'] ?? 0,
          'productions' => $goalData['productions'] ?? 0,
          'no_of_reviews' => $goalData['no_of_reviews'] ?? 0,
          'given_links' => $goalData['given_links'] ?? 0,
          'no_of_placements' => $goalData['no_of_placements'] ?? 0,
          'mou' => $goalData['mou'] ?? 0,
          'reference_sales' => $goalData['reference_sales'] ?? 0,
          'sales_lead_check' => $goalData['sales_lead_check'] ?? 0,
          'created_by' => $createdBy,
          'updated_by' => $createdBy,
          'status' => 1, // Default status
        ]
      );
    }


    return response()->json([
      'status' => 200,
      'message' => 'Goals updated successfully'
    ]);
  }
}
