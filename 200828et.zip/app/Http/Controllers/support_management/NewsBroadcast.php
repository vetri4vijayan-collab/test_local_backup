<?php

namespace App\Http\Controllers\support_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel;
use App\Models\BroadcastThemeModel;
use Illuminate\Support\Facades\Validator;
use App\Models\BranchModel;
use App\Models\UserRolePermissionModel;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\DB;
use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;
use Carbon\Carbon;

class NewsBroadcast extends Controller
{
  protected static $branch_id = 1;

  public function index(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    date_default_timezone_set('Asia/Kolkata');
    // Now, run your query to check the current time in the set timezone
   $now = Carbon::now()->format('Y-m-d H:i:s');
    

    $country = NewsBroadcastModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $country->where(function ($subquery) use ($search_filter) {
            $subquery->where('template_name', 'LIKE', "%{$search_filter}%");
        });
    }
           $country = $country->select('*', \DB::raw('
            CASE
                WHEN start_date <= "' . $now . '" AND end_date >= "' . $now . '" THEN 1
                WHEN start_date > "' . $now . '" THEN 2
                ELSE 3
            END AS phase_order
        '))
        ->orderByRaw('phase_order ASC') // Order by phase_order first
        ->orderBy('start_date', 'asc')
    ->paginate($perpage);



    $helper = new \App\Helpers\Helpers();
    // If AJAX request → return JSON only
    if ($request->ajax()) {
        $data = $country->map(function ($item) use ($helper) {
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'branch_ids' => json_decode($item->branch_id,true),
                'role_ids' => json_decode($item->role_ids,true),
                'template_name' => $item->template_name,
                'broadcast_message' => $item->broadcast_message,
                'start_date' => \Carbon\Carbon::parse($item->start_date)->format('d-M-Y h:i A'),
                'end_date' => \Carbon\Carbon::parse($item->end_date)->format('d-M-Y h:i A'),
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'next_page' => $country->nextPageUrl()
        ]);
    }

    return view('content.support_management.news_broadcast.news_broadcast', [
        'country' => $country,
        'perpage' => $perpage,
        'search_filter' => $search_filter
    ]);
}

  public function List()
  {
      $city = NewsBroadcastModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    
    public function List_for_edit()
  {
    $sms_template = NewsBroadcastModel::orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  
  public function Add(Request $request)
  {
      
      $branch_list = BranchModel::where('status', 0)->get();
      $theme_list = BroadcastThemeModel::where('status', 0)->get();

        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
            $default_theme = BroadcastThemeModel::where('status',0)->first();
        $theme_id =$default_theme ? $default_theme->sno : 0 ;
    return view('content.support_management.news_broadcast.add_news_broadcast',[
        'branch_list'=>$branch_list,
        'roleList'=>$roleList,
        'theme_list'=>$theme_list,
        'theme_id'=>$theme_id,
        ]);
  }
  
   public function Edit($id,Request $request)
  {
      
          $branch_list = BranchModel::where('status', 0)->get();
          $theme_list = BroadcastThemeModel::where('status', 0)->get();
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
            $editData = NewsBroadcastModel::where('status', '!=', 2) ->where('sno',$decryptedValue)
                    ->first();
                    $editData->branch_id=json_decode($editData->branch_id, true);
                    $editData->role_ids=json_decode($editData->role_ids, true);
                    $editData->information = json_decode($editData->information, true); 
                    $editData->firstData = $editData->information[0]; 
                 
                    
        $default_theme = BroadcastThemeModel::where('status',0)->first();
        $theme_id =$default_theme ? $default_theme->sno : 0 ;
    return view('content.support_management.news_broadcast.edit_news_broadcast',[
            'branch_list'=>$branch_list,
            'roleList'=>$roleList,
            'theme_list'=>$theme_list,
            'editData'=>$editData,
            'theme_id'=>$theme_id,
        ]);
  }
  
    public function saveTemplate(Request $request)
{
    $branch_ids = $request->branch_id;
    $user_id = $request->user()->user_id;
    if ($branch_ids === "all") {
        $branch_ids = DB::table("et_branch")->where("status", 0)->pluck("sno")->toArray();
        $branch_ids = array_map('strval', $branch_ids);
    }

    $role_ids = $request->role_ids;
    if ($role_ids === "all") {
        $role_ids = DB::table("et_user_role")->where("status", 0)->pluck("sno")->toArray();
         $role_ids = array_map('strval', $role_ids);
    }
    
    $themeData = DB::table('et_broadcast_theme')
        ->where('et_broadcast_theme.status', 0)
        ->where('et_broadcast_theme.sno',$request->theme_id)
        ->first();
        
        
        
       
    $theme = $themeData ? json_decode($themeData->theme_style, true) : null;

    if ($theme) {
        $theme['position'] = 'sticky';
    }
       
   NewsBroadcastModel::create([
        "branch_id"    => json_encode($branch_ids),
        "role_ids"     => json_encode($role_ids),
        "start_date"   => date('Y-m-d H:i:s', strtotime($request->start_date)),
        "end_date"     => date('Y-m-d H:i:s', strtotime($request->end_date)),
        "information"  => $request->information, // already json
        "theme_id"     => $request->theme_id,
        "broadcast_message"     => $request->broadcast_message,
        "theme_style"  => json_encode($theme), // Save the updated theme here
        "created_by"   => $user_id,
        "template_name"=> $request->template_name,
        "updated_by"   => $user_id,
    ]);

    return response()->json(["status" => "success"]);
}

  public function Update(Request $request)
  {

    $broadcast_id = $request->broadcast_id;
    $branch_ids = $request->branch_id;
    $user_id = $request->user()->user_id;
    if ($branch_ids === "all") {
        $branch_ids = DB::table("et_branch")->where("status", 0)->pluck("sno")->toArray();
        $branch_ids = array_map('strval', $branch_ids);
    }

    $role_ids = $request->role_ids;
    if ($role_ids === "all") {
        $role_ids = DB::table("et_user_role")->where("status", 0)->pluck("sno")->toArray();
         $role_ids = array_map('strval', $role_ids);
    }
    
    $themeData = DB::table('et_broadcast_theme')
        ->where('et_broadcast_theme.status', 0)
        ->where('et_broadcast_theme.sno',$request->theme_id)
        ->first();
        
       
    $theme = $themeData ? json_decode($themeData->theme_style, true) : null;

    if ($theme) {
        $theme['position'] = 'sticky';
    }
    $UpdateBroadcast=NewsBroadcastModel::where('sno', $broadcast_id)->first();
    if($UpdateBroadcast){
        $UpdateBroadcast->branch_id    = json_encode($branch_ids);
        $UpdateBroadcast->role_ids    = json_encode($role_ids);
           $UpdateBroadcast->start_date  = date('Y-m-d H:i:s', strtotime($request->start_date));
           $UpdateBroadcast->end_date   = date('Y-m-d H:i:s', strtotime($request->end_date));
           $UpdateBroadcast->information  = $request->information; // already json
           $UpdateBroadcast->theme_id    = $request->theme_id;
           $UpdateBroadcast->broadcast_message     =$request->broadcast_message;
           $UpdateBroadcast->theme_style  =json_encode($theme); 
           $UpdateBroadcast->template_name =$request->template_name;
           $UpdateBroadcast->updated_by   = $user_id;
           $UpdateBroadcast->update();
        
    }else{
        return response()->json(["status" => "failed"]);
    }
   

    return response()->json(["status" => "success"]);
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  
  public function checkDates(Request $request) {
      
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('et_news_broadcast')
        ->where('status', '!=',2)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}

public function checkDatesEdit(Request $request) {
      
      $broadcast_id=$request->broadcast_id;
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('et_news_broadcast')
        ->where('status', '!=',2)
        ->where('sno', '!=',$broadcast_id)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}
  public function broadcastThemeById(Request $request) {
      
    $theme_id=$request->theme_id;

    $theme = DB::table('et_broadcast_theme')
        ->where('et_broadcast_theme.status', 0)
        ->where('et_broadcast_theme.sno',$theme_id)
        ->first();

    if ($theme) {
        return response()->json([
            'status' => '200',
            'data' => json_decode($theme->theme_style)
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}


public function newsBroadcastById(Request $request) {
      
    $template_id=$request->theme_id;

    $theme = DB::table('et_news_broadcast')
        ->where('et_news_broadcast.status', '!=',2)
        ->where('et_news_broadcast.sno',$template_id)
        ->first();
        $data = json_decode($theme->theme_style, true); // decode as array
        $data['position'] = 'fixed'; 
    if ($theme) {
        return response()->json([
            'status' => '200',
            'allData' => $theme,
            'data' => $data,
            'content' => json_decode($theme->information),
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}
 public function uploadDocument(Request $request)
{
    $request->validate([
        'file' => 'required|mimes:pdf,docx,txt|max:2097152',
    ]);

    try {
        $file = $request->file('file');
        $extension = strtolower($file->getClientOriginalExtension());

        $content = '';
        $pageCount = 1;
        $totalWordCount = 0;
        $perPageWordCounts = [];

        if ($extension === 'pdf') {
            $parser = new \Smalot\PdfParser\Parser();
            $pdf = $parser->parseFile($file->getPathname());
            $pages = $pdf->getPages();
            $pageCount = count($pages);

            foreach ($pages as $i => $page) {
                $text = $page->getText();
                $pageText = is_string($text) ? $text : '';
                $content .= $pageText . "\n";

                $wordCount = str_word_count(strip_tags($pageText));
                $perPageWordCounts["Page " . ($i + 1)] = $wordCount;
                $totalWordCount += $wordCount;
            }
        } elseif ($extension === 'docx') {
                  // Flag to indicate we estimated pages (not exact)
                $isEstimated = true;
                $content = '';
            
                // Try to open document.xml inside the docx ZIP
                $zip = new \ZipArchive();
                $documentXml = null;
                if ($zip->open($file->getPathname()) === true) {
                    $idx = $zip->locateName('word/document.xml');
                    if ($idx !== false) {
                        $documentXml = $zip->getFromIndex($idx);
                    }
                    $zip->close();
                }
            
                if ($documentXml !== null) {
                    // 1) Preserve paragraph and break markers
                    $doc = $documentXml;
                    $doc = preg_replace('/<w:br\b[^>]*\/?>/i', '[[BR]]', $doc);       // inline breaks
                    $doc = preg_replace('/<\/w:p>/i', '[[PARA]]', $doc);            // paragraph end
            
                    // 2) Extract <w:t> text nodes only (keeps our markers in place)
                    $plain = preg_replace_callback('/<w:t[^>]*>(.*?)<\/w:t>/is', function ($m) {
                        return $m[1];
                    }, $doc);
            
                    // 3) Remove remaining XML/HTML tags (markers remain)
                    $plain = strip_tags($plain);
            
                    // 4) Replace markers with newlines (parags -> double newline)
                    $plain = str_replace('[[BR]]', "\n", $plain);
                    $plain = str_replace('[[PARA]]', "\n\n", $plain);
            
                    // 5) Remove Word field codes and hyperlink field artifacts
                    //    e.g. { HYPERLINK "http..."  \l "..." } or other { ... } fields
                    $plain = preg_replace('/\{[^}]{0,800}\}/s', ' ', $plain);            // remove { ... } blocks safely
                    $plain = preg_replace('/HYPERLINK\s+"[^"]*"/i', ' ', $plain);
            
                    // 6) Decode HTML entities (&amp;gt; etc.) and normalize whitespace but preserve newlines
                    $plain = html_entity_decode($plain, ENT_QUOTES | ENT_XML1, 'UTF-8');
                    // collapse multiple spaces but preserve newlines: replace runs of spaces/tabs with single space
                    $plain = preg_replace('/[ \t]+/', ' ', $plain);
                    // collapse 3+ newlines to two
                    $plain = preg_replace("/\n{3,}/", "\n\n", $plain);
                    $plain = trim($plain);
            
                    // 7) Count words (split on whitespace)
                    $wordsArr = preg_split('/\s+/u', strip_tags($plain), -1, PREG_SPLIT_NO_EMPTY);
                    $totalWordCount = $wordsArr ? count($wordsArr) : 0;
            
                    // 8) Heuristics: detect images, tables, and long paragraphs (they increase page usage)
                    $imageCount = preg_match_all('/<w:drawing\b|<pic:pic\b/i', $documentXml, $m1) ? count($m1[0]) : 0;
                    $tableCount = preg_match_all('/<w:tbl\b/i', $documentXml, $m2) ? count($m2[0]) : 0;
            
                    // long paragraphs
                    $paragraphs = array_filter(array_map('trim', preg_split("/\n{2,}/", $plain)));
                    $longParagraphs = 0;
                    foreach ($paragraphs as $p) {
                        $pWords = preg_split('/\s+/u', trim($p), -1, PREG_SPLIT_NO_EMPTY);
                        if ($pWords && count($pWords) >= 120) {
                            $longParagraphs++;
                        }
                    }
            
                    // 9) Read average font size (w:sz) if present (w:sz is in half-points)
                    $fontSizes = [];
                    if (preg_match_all('/<w:sz\b[^>]*w:val=["\']?(\d+)["\']?/i', $documentXml, $szMatches)) {
                        foreach ($szMatches[1] as $s) {
                            $fontSizes[] = (int)$s;
                        }
                    }
                    $avgFontPt = 11; // default pt
                    if (!empty($fontSizes)) {
                        // w:sz value is in half-points, so pt = val/2
                        $avgFontPt = array_sum($fontSizes) / count($fontSizes) / 2.0;
                        if ($avgFontPt <= 0) $avgFontPt = 11;
                    }
            
                    // 10) Read page size and margins (twips). Convert to points: pt = twips / 20
                    $pageW = 595; $pageH = 842; // default A4 in points (approx)
                    $marginLeft = $marginRight = $marginTop = $marginBottom = 72; // default 1" margins in points
            
                    if (preg_match('/<w:pgSz\b[^>]*w:w=["\']?(\d+)["\']?[^>]*w:h=["\']?(\d+)["\']?/i', $documentXml, $m)) {
                        $pageW = (int)$m[1] / 20.0; // twips -> pts
                        $pageH = (int)$m[2] / 20.0;
                    } elseif (preg_match('/<w:pgSz\b([^>]*)>/i', $documentXml, $m0)) {
                        // fallback: try to extract w:w and w:h individually
                        if (preg_match('/w:w=["\']?(\d+)["\']?/i', $m0[1], $mw)) $pageW = (int)$mw[1] / 20.0;
                        if (preg_match('/w:h=["\']?(\d+)["\']?/i', $m0[1], $mh)) $pageH = (int)$mh[1] / 20.0;
                    }
            
                    if (preg_match('/<w:pgMar\b[^>]*>/i', $documentXml, $mm)) {
                        $attrs = $mm[0];
                        if (preg_match('/w:left=["\']?(\d+)["\']?/i', $attrs, $a)) $marginLeft = (int)$a[1] / 20.0;
                        if (preg_match('/w:right=["\']?(\d+)["\']?/i', $attrs, $a)) $marginRight = (int)$a[1] / 20.0;
                        if (preg_match('/w:top=["\']?(\d+)["\']?/i', $attrs, $a)) $marginTop = (int)$a[1] / 20.0;
                        if (preg_match('/w:bottom=["\']?(\d+)["\']?/i', $attrs, $a)) $marginBottom = (int)$a[1] / 20.0;
                    }
            
                    // printable area (points)
                    $printableW = max(100, $pageW - ($marginLeft + $marginRight));
                    $printableH = max(100, $pageH - ($marginTop + $marginBottom));
                    $printableArea = $printableW * $printableH;
            
                    // default printable area for baseline (A4 minus 1" margins roughly)
                    $defaultPrintableW = 595 - (72*2);   // A4 width - 2*1"
                    $defaultPrintableH = 842 - (72*2);   // A4 height - 2*1"
                    $defaultPrintableArea = $defaultPrintableW * $defaultPrintableH;
            
                    // 11) Compute adjusted words-per-page using font & printable area ratio
                    $baseWordsPerPage = 250; // baseline for typical A4 / 11pt document
                    $areaFactor = $printableArea / max(1, $defaultPrintableArea);
                    $fontFactor = 11 / max(1, $avgFontPt); // larger font -> fewer words per page
                    $wordsPerPage = (int) round($baseWordsPerPage * $areaFactor * $fontFactor);
                    $wordsPerPage = max(80, min(450, $wordsPerPage)); // clamp to reasonable range
            
                    // 12) Add "extra words" equivalent for images/tables/long paragraphs
                    $imageWordEquiv = 220;   // each image ~= 220 words
                    $tableWordEquiv = 260;   // each table ~= 260 words
                    $longParaEquiv = 120;    // each very long paragraph adds equivalent words
                    $extraWords = ($imageCount * $imageWordEquiv) + ($tableCount * $tableWordEquiv) + ($longParagraphs * $longParaEquiv);
            
                    // 13) Final estimated pages
                    $estimatedPages = (int) ceil( ($totalWordCount + $extraWords) / max(1, $wordsPerPage) );
                    $pageCount = max(1, $estimatedPages);
            
                    // 14) Distribute per-page word counts (simple even distribution)
                    $perPageWordCounts = [];
                    $base = intdiv($totalWordCount, $pageCount);
                    $rem = $totalWordCount % $pageCount;
                    for ($i = 0; $i < $pageCount; $i++) {
                        $wc = $base + ($i < $rem ? 1 : 0);
                        $perPageWordCounts["Page " . ($i + 1)] = $wc;
                    }
            
                    // 15) prepare content for preview (preserve line breaks in HTML safely)
                    $content = trim($plain);
                    $isEstimated = true;
                } else {
                    // fallback: use PhpWord extraction (less ideal, but works)
                    $phpWord = \PhpOffice\PhpWord\IOFactory::load($file->getPathname());
                    $allText = '';
                    foreach ($phpWord->getSections() as $section) {
                        foreach ($section->getElements() as $element) {
                            if (method_exists($element, 'getText')) {
                                $t = $element->getText();
                                if (is_array($t)) $t = implode(' ', $t);
                                $allText .= (string)$t . "\n";
                            }
                        }
                    }
                    $plain = preg_replace('/\{[^}]{0,800}\}/s', ' ', $allText);
                    $plain = html_entity_decode($plain, ENT_QUOTES | ENT_XML1, 'UTF-8');
                    $plain = preg_replace('/\s+/', ' ', trim($plain));
                    $wordsArr = preg_split('/\s+/', strip_tags($plain), -1, PREG_SPLIT_NO_EMPTY);
                    $totalWordCount = $wordsArr ? count($wordsArr) : 0;
                    $wordsPerPage = 180;
                    $pageCount = max(1, (int) ceil($totalWordCount / $wordsPerPage));
                    $perPageWordCounts = [];
                    $base = intdiv($totalWordCount, $pageCount);
                    $rem = $totalWordCount % $pageCount;
                    for ($i = 0; $i < $pageCount; $i++) {
                        $wc = $base + ($i < $rem ? 1 : 0);
                        $perPageWordCounts["Page " . ($i + 1)] = $wc;
                    }
                    $content = trim($plain);
                    $isEstimated = true;
                }
        } elseif ($extension === 'txt') {
            // treat whole txt as one page
            $content = file_get_contents($file->getPathname());
            $pageCount = 1;
            $totalWordCount = str_word_count(strip_tags($content));
            $perPageWordCounts["Page 1"] = $totalWordCount;
        }

        return response()->json([
            'content' => nl2br(e($content ?: '⚠️ No readable text found in this document.')),
            'page_count' => $pageCount,
            'total_word_count' => $totalWordCount,
            'per_page_word_counts' => $perPageWordCounts,
        ]);

    } catch (\Throwable $e) {
        return response()->json([
            'message' => '⚠️ Failed to process document: ' . $e->getMessage()
        ], 500);
    }
}

public function role_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('role_ids')
      ->first();

    $roleIds = json_decode($data->role_ids, true);
    $roles = [];
    foreach ($roleIds as $roleId) {
      $role = UserRoleModel::where('status', 0)->where('sno', $roleId)->first(); 
      $roles[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['roles' => $roles]
    ], 200);
  }


public function Update_role(Request $request)
  {
    // return $request;
    $request->validate([
      'edit_role_sno' => 'required|integer',
      'Add_role_table' => 'required|array',
    ]);

    $user_id = $request->user()->user_id;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_role_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Training document not found.',
      ], 404);
    }

    $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
    $roleIds = is_array($roleIds) ? $roleIds : [];

    $newRoles = [];
    foreach ($request->Add_role_table as $roles) {
      if (is_array($roles)) {
        $newRoles = array_merge($newRoles, $roles);
      } else {
        $newRoles[] = $roles;
      }
    }

    $mergedRoles = array_unique(array_merge($roleIds, $newRoles));
    
    if($broadcast){
        $broadcast->role_ids=json_encode(array_values($mergedRoles));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $roles = UserRoleModel::where('status', 0)
      ->whereIn('sno', $mergedRoles)
      ->get()
      ->keyBy('sno');

    $rolesData = [];
    foreach ($mergedRoles as $roleId) {
      $role = $roles->get($roleId);
      $rolesData[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Roles updated successfully!',
      'roles'   => $rolesData,
    ]);
  }
  
  
   public function removeRole(Request $request)
    {
        $request->validate([
            'sno' => 'required|integer',
            'role_id' => 'required'
        ]);
        $user_id = $request->user()->user_id;
        $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
    
        if(!$broadcast){
            return response()->json(['success' => false, 'message' => 'Record not found']);
        }
    
        // Decode role_ids
        $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
    
        // Remove the role_id
        $roleIds = array_filter($roleIds, function($id) use ($request){
            return $id != $request->role_id;
        });
    
        if($broadcast){
            $broadcast->role_ids = json_encode(array_values($roleIds));
            $broadcast->updated_by=$user_id;
            $broadcast->update();
        }
     
    
        return response()->json(['success' => true]);
    }
    
    public function branch_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('branch_id')
      ->first();

    $branchIds = json_decode($data->branch_id, true);
    $branches = [];
    foreach ($branchIds as $branchId) {
      $branch = BranchModel::where('status', 0)->where('sno', $branchId)->first(); 
      $branches[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['branches' => $branches]
    ], 200);
  }
  
   public function branch_list(Request $request)
  {
     $user_id = $request->user()->user_id;
     $entity_id = $request->user()->entity_id;
    $data = BranchModel::where('status', '!=', 2)
      ->where('entity_id', $entity_id)
      ->get();
      
    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' =>  $data
    ], 200);
  }


public function Update_branch(Request $request)
  {
   
    $request->validate([
      'edit_branch_sno' => 'required|integer',
      'Add_branch_table' => 'required|array',
    ]);

    $user_id = $request->user()->user_id;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_branch_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Broadcast not found.',
      ], 404);
    }

    $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
    $branchIds = is_array($branchIds) ? $branchIds : [];

    $newBranches = [];
    foreach ($request->Add_branch_table as $branches) {
      if (is_array($branches)) {
        $newBranches = array_merge($newBranches, $branches);
      } else {
        $newBranches[] = $branches;
      }
    }

    $mergedBranches= array_unique(array_merge($branchIds, $newBranches));

    if($broadcast){
        $broadcast->branch_id=json_encode(array_values($mergedBranches));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $branches = BranchModel::where('status', 0)
      ->whereIn('sno', $mergedBranches)
      ->get()
      ->keyBy('sno');

    $branchesData = [];
    foreach ($mergedBranches as $branchId) {
      $branch = $branches->get($branchId);
      $branchesData[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Branch updated successfully!',
      'branches'   => $branchesData,
    ]);
  }
  
  
   public function removeBranch(Request $request)
    {
        $request->validate([
            'sno' => 'required|integer',
            'branch_id' => 'required'
        ]);
        $user_id = $request->user()->user_id;
        $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
    
        if(!$broadcast){
            return response()->json(['success' => false, 'message' => 'Record not found']);
        }
    
        // Decode role_ids
        $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
    
        // Remove the role_id
        $branchIds = array_filter($branchIds, function($id) use ($request){
            return $id != $request->branch_id;
        });
    
        if($broadcast){
            $broadcast->branch_id = json_encode(array_values($branchIds));
            $broadcast->updated_by=$user_id;
            $broadcast->update();
        }
     
    
        return response()->json(['success' => true]);
    }

}
