<?php

namespace App\Http\Controllers\support_management;

use App\Http\Controllers\Controller;

use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\Models\TrainingDocumentModel;
use App\Models\TrainingDocumentViewerModel;
use PhpOffice\PhpPresentation\IOFactory;
use PhpOffice\PhpPresentation\PhpPresentation;

class TrainingDocument extends Controller
{
    public function index(Request $request)
    {
        
        $search_fill = $request->search_fill ?? '';
        $entity_id   = $request->user()->entity_id;
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $role_id   = $request->user()->role_id;
        $ListTable = [];
        $categories = DB::table('et_training_category as cat')
            ->where('cat.status', 0)
            ->orderBy('cat.category_name', 'ASC')
            ->get(['cat.sno', 'cat.category_name']);
        
        $filteredCategories = [];
        
        foreach ($categories as $category) {
            // Get subcategories for this category
            $subcategories = DB::table('et_training_sub_category')
                ->where('category_id', $category->sno)
                ->where('status', 0)
                ->get(['sno', 'sub_cat_name']);
        
            $subcategoriesWithDocs = [];
        
            foreach ($subcategories as $sub) {
                $count_document = DB::table('et_training_document')
                    ->where('training_sub_category_id', $sub->sno)
                    ->where('status', 0);
        
                if (!empty($role_id)) {
                    $count_document->whereJsonContains('role_ids', (string)$role_id);
                }
        
                $count_document = $count_document->count();
        
                if ($count_document > 0) {
                    $sub->document_count = $count_document;
                    $subcategoriesWithDocs[] = $sub; // Only add subcategories with documents
                }
            }
        
            if (!empty($subcategoriesWithDocs)) {
                $category->subcategories = $subcategoriesWithDocs;
                $filteredCategories[] = $category; // Only add category if it has subcategories with documents
            }else{
                $category->subcategories = $subcategoriesWithDocs;
            }
        }
        
        // $filteredCategories now contains only categories with at least one document


        
        return view('content.support_management.training_document.training_list', compact('categories','ListTable'));
    }
    public function ajax_table(Request $request)
    {
        $search_fill = $request->search_fill ?? '';
        $subcategory_ids = $request->subcategory_ids ?? '';
        $entity_id   = $request->user()->entity_id;
        $user_id     = $request->user()->user_id;
        $branch_id   = $request->user()->branch_id;
        $role_id   = $request->user()->role_id;
    
        $ListTable = TrainingDocumentModel::where('et_training_document.status', '!=', 2)
            ->select('et_training_document.*', 'et_training_category.category_name', 'et_training_sub_category.sub_cat_name')
            ->leftJoin('et_training_category', 'et_training_document.training_category_id', 'et_training_category.sno')
            ->leftJoin('et_training_sub_category', 'et_training_document.training_sub_category_id', 'et_training_sub_category.sno');
    
        // Search text
        if (!empty($search_fill)) {
            $ListTable->where(function ($query) use ($search_fill) {
                $query->where('et_training_document.traning_name', 'LIKE', "%{$search_fill}%")
                      ->orWhere('et_training_category.category_name', 'LIKE', "%{$search_fill}%")
                      ->orWhere('et_training_sub_category.sub_cat_name', 'LIKE', "%{$search_fill}%");
            });
        }
    
        // Filter by subcategory IDs
        if (!empty($subcategory_ids)) {
            $ListTable->where('et_training_document.training_sub_category_id', $subcategory_ids);
        }
        if (!empty($role_id)) {
            $ListTable->whereJsonContains('et_training_document.role_ids', (string) $role_id);
        }
    
    
        // Branch filter
        $ListTable = $ListTable
        // ->where('branch_id', $branch_id)
                               ->orderBy('et_training_document.order_id', 'ASC')
                               ->get();
                               
        foreach ($ListTable as $list) {
            $list->view_count = TrainingDocumentViewerModel::where('staff_id', $user_id)->where('training_document_id', $list->sno)->sum('view_count');
        }
    
        return view('content.support_management.training_document.ajax_table', compact('ListTable'));
    }
    
    public function fetchTrainingDocumentById($id,Request $request)
    {
        if (!$id) {
            return null; // or handle error as needed
        }
    
        $document = TrainingDocumentModel::where('et_training_document.status', '!=', 2)
            ->where('et_training_document.sno', $id)
            ->select('et_training_document.*', 'et_training_category.category_name', 'et_training_sub_category.sub_cat_name')
            ->leftJoin('et_training_category', 'et_training_document.training_category_id', 'et_training_category.sno')
            ->leftJoin('et_training_sub_category', 'et_training_document.training_sub_category_id', 'et_training_sub_category.sno')
            ->first();
            
        $user_id = $request->user()->user_id;

        $count_update = TrainingDocumentViewerModel::where('staff_id', $user_id)
            ->where('training_document_id', $id)
            ->first();
        
        if ($count_update) {
            // Record exists, increment view_count by 1
            $count_update->increment('view_count');
        } else {
            // Record doesn't exist, create new with view_count = 1
            TrainingDocumentViewerModel::create([
                'staff_id' => $user_id,
                'training_document_id' => $id,
                'view_count' => 1,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
        }
        return $document;
    }


 

}
