<?php

namespace App\Http\Controllers\support_management;

use App\Http\Controllers\Controller;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\TrainingDocumentModel;
use App\Models\UserRoleModel;
use Illuminate\Support\Str;

class ManageTrainingDocument extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    // if($user_id != 0){
    //     return view('content.working_on_progress');
    // }

    $search_fill = $request->search_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $ListTable = TrainingDocumentModel::where('et_training_document.status', '!=', 2)
      ->select('et_training_document.*', 'et_training_category.category_name', 'et_training_sub_category.sub_cat_name')
      ->leftJoin('et_training_category', 'et_training_document.training_category_id', 'et_training_category.sno')
      ->leftJoin('et_training_sub_category', 'et_training_document.training_sub_category_id', 'et_training_sub_category.sno');
    if ($search_fill  != '') {
      $ListTable->where(function ($query) use ($search_fill) {
        $query->where('et_training_document.traning_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_training_category.category_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_training_sub_category.sub_cat_name', 'LIKE', "%{$search_fill}%");
      });
    }
    $ListTable = $ListTable
    // ->where('branch_id', $branch_id)
    ->orderBy('et_training_document.sno', 'desc')->paginate($perpage);
     foreach ($ListTable->items() as $item) {
        $item->fileExist = 0; // Default to 0

        // Check for different file types
        if ($item->video_link) {
            $videoPath = public_path('training_document/videos/' . $item->video_link);
            $item->fileExist = file_exists($videoPath) ? 1 : 0;
        } elseif ($item->pdf_id) {
            $pdfPath = public_path('training_document/' . $item->pdf_id);
            $item->fileExist = file_exists($pdfPath) ? 1 : 0;
        } elseif ($item->ppt_id) {
            $pptPath = public_path('training_document/ppt/' . $item->ppt_id);
            $item->fileExist = file_exists($pptPath) ? 1 : 0;
        } elseif ($item->image_id) {
            $imagePath = public_path('training_document/image/' . $item->image_id);
            $item->fileExist = file_exists($imagePath) ? 1 : 0;
        } elseif ($item->audio_id) {
            $audioPath = public_path('training_document/audios/' . $item->audio_id);
            $item->fileExist = file_exists($audioPath) ? 1 : 0;
        }else{
             $item->fileExist = 1;
        }
    }


    $categories = DB::table('et_training_category')->where('status', 0)->orderBy('category_name', 'ASC')->get(['sno', 'category_name']);

    return view('content.support_management.manage_training_document.training_document', compact('categories', 'ListTable', 'perpage', 'search_fill'));
  }
  public function getSubcategories(Request $request)
  {
    $categoryId = $request->cat_id;
    $data = DB::table('et_training_sub_category')->where('category_id', $categoryId)->where('status', 0)->orderBy('sub_cat_name', 'ASC')->get(['sno', 'sub_cat_name']);
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }

  public function getSubcategories_Document_list(Request $request)
  {
    $categoryId = $request->cat_id;
    $branch_id = $request->user()->branch_id;
    // Get documents filtered by subcategory and active status, ordered by order_id
    $data = DB::table('et_training_document')
      ->where('training_sub_category_id', $categoryId)
    //   ->where('branch_id', $branch_id)
      ->where('status', 0)
      ->orderBy('order_id', 'ASC')
      ->get();
       $icons = [
                1 => 'mdi-video-check-outline',
                2 => 'mdi-file-pdf-box',
                3 => 'mdi-web',
                4 => 'mdi-headphones',
                5 => 'mdi-file-image-outline',
                6 => 'mdi-file-powerpoint-outline',
            ];

    // Build the HTML string for drag-and-drop list
    $html = '<label class="text-black mb-1 fs-6 fw-semibold">Training Name</label>
                 <ul class="list-group list-group-flush task-container border bg-label-secondary">';

    foreach ($data as $doc) {
     $iconClass = $icons[$doc->traning_mode] ?? 'mdi-book-open-blank-variant-outline';
            $icon_badge = '<i class="mdi '.$iconClass.' fs-4 me-1"> </i>';
            $html .= '
                <li class="list-group-item drag-item cursor-move me-2" data-id="'.$doc->sno.'">
                    <span class="mdi mdi-arrow-all"></span>
                    '.$icon_badge.'
                    <span>'.$doc->traning_name.'</span>
                </li>';
    }
    $html .= '</ul>';

    // Return the HTML in the response (JSON)
    return response()->json([
      'status'    => 200,
      'message'   => 'Documents fetched successfully',
      'error_msg' => null,
      'html'      => $html
    ]);
  }
  public function saveDocumentOrder(Request $request)
  {
    $orderList = $request->order; // array of ['id' => x, 'order_id' => y]

    foreach ($orderList as $item) {
      DB::table('et_training_document')
        ->where('sno', $item['id'])
        ->update(['order_id' => $item['order_id']]);
    }

    return response()->json(['status' => 200, 'message' => 'Order updated successfully']);
  }


  public function Status($id, Request $request)
  {

    $upd_DepartmentModel = TrainingDocumentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = $request->input('status', 0);
    $upd_DepartmentModel->update();
    if ($upd_DepartmentModel) {
      return response([
        'status' => 200,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 400,
        'message' => 'Successfully Status Updated!',
        'error_msg' => null,
        'data' => null,
      ], 400);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = TrainingDocumentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  // public function Create(Request $request)
  // {
  //   $validator = Validator::make($request->all(), [
  //     'cat_id' => 'required'
  //   ]);

  //   if ($validator->fails()) {
  //     return response([
  //       'status' => 403,
  //       'message' => 'Incorrect Input Field Format',
  //       'error_msg' => $validator->messages()->get('*'),
  //       'data' => null
  //     ], 403);
  //   }

  //   $userId = $request->user()->user_id;
  //   $branch_id = $request->user()->branch_id;
  //   $trainingName = $request->training_name;

  //   $check = TrainingDocumentModel::where('traning_name', $trainingName)->where('status', '!=', 2)->first();

  //   if($check) {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Name Already Exists!'
  //     ]);

  //     return redirect()->back();
  //   }

  //   $category_check = TrainingDocumentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

  //   if (!$category_check) {

  //     $year = substr(date('y'), -2);
  //     $company_id = 'TRD-0001/' . $year;
  //   } else {

  //     $data = $category_check->training_id;
  //     $slice = explode('/', $data);
  //     $result = preg_replace('/[^0-9]/', '', $slice[0]);

  //     $next_number = (int) $result + 1;
  //     $request_id = sprintf('TRD-%04d', $next_number);

  //     $year = substr(date('y'), -2);
  //     $company_id = $request_id . '/' . $year;
  //   }

  //   $training = new TrainingDocumentModel();
  //   $training->training_id = $company_id;
  //    $training->training_category_id = $request->cat_id;
  //   $training->training_sub_category_id = $request->sub_cat_id;
  //   $training->traning_name = $trainingName;
  //   $training->traning_mode = $request->training_mode;

  //   if ($request->training_mode == '0' || $request->training_mode == 0) {
  //     $training->text_content = $request->add_text;
  //   } elseif ($request->training_mode == '1') {
  //     $video = $request->file('video_upload');
  //     $videoFile = '';

  //     if ($video) {
  //       $videoName = idate('B') . rand(1, 50) . '.' . $video->extension();
  //       $videoDestination = public_path('training_document/videos');
  //       $video->move($videoDestination, $videoName);
  //       $videoFile = $videoName;
  //     }
  //     $training->video_link = $videoFile;
  //   } elseif ($request->training_mode == '2') {

  //     $attachment = $request->file('attachment');
  //     $attachmentFile = '';

  //     if ($attachment) {
  //       $attachmentName = idate('B') . rand(1, 50) . '.' . $attachment->extension();
  //       $attachmentDestination = public_path('training_document');
  //       $attachment->move($attachmentDestination, $attachmentName);
  //       $attachmentFile = $attachmentName;
  //     }
  //     $training->pdf_id = $attachmentFile;
  //   }
  //   $training->branch_id = $branch_id;
  //   $training->created_by = $userId;
  //   $training->updated_by = $userId;


  //   $roleIdGroups = $request->input('role_id', []);
  //   $deptIds = $request->input('dept_id', []);

  //   $deptIdsFiltered = [];
  //   $roleIdGroupsFiltered = [];

  //   foreach ($deptIds as $index => $deptId) {
  //     // roles may be missing or empty
  //     $roles = isset($roleIdGroups[$index]) ? $roleIdGroups[$index] : [];

  //     // Only add if dept is set
  //     if (!empty($deptId)) {
  //       $deptIdsFiltered[] = $deptId;
  //       $roleIdGroupsFiltered[] = $roles;
  //     }
  //   }

  //   $training->dept_id = json_encode($deptIdsFiltered);
  //   $training->role_ids = json_encode($roleIdGroupsFiltered);

  //   $training->save();

  //   if($training) {
  //     session()->flash('toastr', [
  //       'type' => 'success',
  //       'message' => 'Training Document Created Successfully!'
  //     ]);

  //     return redirect()->back();
  //   } else {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Training Document Creation Failed!'
  //     ]);

  //     return redirect()->back();
  //   }
  // }

  public function create(Request $request)
  {

    //   return $request;
    // Validate required fields
    $validator = Validator::make($request->all(), [
      'cat_id' => 'required',
      'sub_cat_id' => 'required',
      'training_name' => 'required|max:70',
      'role_id' => 'required|array|min:1',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 400,
        'toastr' => [
          'type' => 'error',
          'message' => 'Validation failed: ' . implode(' ', $validator->errors()->all())
        ],
        'errors' => $validator->errors()
      ], 400);
    }

    try {
      DB::beginTransaction();

      $userId = auth()->user()->user_id;
      $branchId = auth()->user()->branch_id;
      $trainingName = $request->training_name;

      // Generate training ID
      $lastTraining = TrainingDocumentModel::orderBy('sno', 'desc')->first();
      $year = substr(date('y'), -2);

      if (!$lastTraining) {
        $trainingId = 'TRD-0001/' . $year;
      } else {
        $parts = explode('/', $lastTraining->training_id);
        $number = preg_replace('/[^0-9]/', '', $parts[0]);
        $nextNumber = sprintf('TRD-%04d', ((int)$number) + 1);
        $trainingId = $nextNumber . '/' . $year;
      }

      // Handle file uploads based on training mode
      $trainingMode = $request->training_mode;
      $videoName = null;
      $pdfName = null;
      $pptName = null;
      $traininglink = null;
      $imageName = null;
      $audioName = null;


      if ($request->hasFile('video_upload') && $trainingMode == 1) {
        $video = $request->file('video_upload');
        $videoName = 'video_' . time() . '_' . Str::random(10) . '.' . $video->getClientOriginalExtension();
        $video->move(public_path('training_document/videos'), $videoName);
      }

      if ($request->hasFile('attachment') && $trainingMode == 2) {
        $pdf = $request->file('attachment');
        $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();
        $pdf->move(public_path('training_document'), $pdfName);
      }

      if ($request->hasFile('attachment_ppt') && $trainingMode == 6) {
        $ppt = $request->file('attachment_ppt');
        $pptName = 'doc_' . time() . '_' . Str::random(10) . '.' . $ppt->getClientOriginalExtension();
        $ppt->move(public_path('training_document/ppt'), $pptName);
      }

      if ($request->hasFile('attachment_img') && $trainingMode == 5) {
        $image = $request->file('attachment_img');
        $imageName = 'doc_' . time() . '_' . Str::random(10) . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('training_document/image'), $imageName);
      }

      if ($request->hasFile('audio_upload') && $trainingMode == 4) {
        $audio = $request->file('audio_upload');
        $audioName = 'audio_' . time() . '_' . Str::random(10) . '.' . $audio->getClientOriginalExtension();
        $audio->move(public_path('training_document/audios'), $audioName);
      }

      if ($trainingMode == 3) {
        // Link mode
        $trainingLink = $request->link;
      }


      // Create training document
      $training = new TrainingDocumentModel();
      $training->training_id = $trainingId;
      $training->training_category_id = $request->cat_id;
      $training->training_sub_category_id = $request->sub_cat_id;
      $training->traning_name = $trainingName;
      $training->traning_mode = $trainingMode;
      $training->text_content = ($trainingMode == 0) ? $request->add_text : null;
      $training->video_link = $videoName;
      $training->link = $traininglink;
      $training->pdf_id = $pdfName;
      $training->ppt_id = $pptName;
      $training->image_id = $imageName;
      $training->audio_id = $audioName;
      $training->branch_id = $branchId;
      $training->created_by = $userId;
      $training->updated_by = $userId;
    //   $training->dept_id = json_encode($request->dept_id);
      $training->role_ids = json_encode($request->role_id);
      $training->save();

      DB::commit();

      return response()->json([
        'status' => 200,
        'toastr' => [
          'type' => 'success',
          'message' => 'Training document created successfully!'
        ]
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack();

      // Clean up uploaded files if error occurred
      if (isset($videoName) && file_exists(public_path('training_document/videos/' . $videoName))) {
        @unlink(public_path('training_document/videos/' . $videoName));
      }
      if (isset($pdfName) && file_exists(public_path('training_document/' . $pdfName))) {
        @unlink(public_path('training_document/' . $pdfName));
      }

      if (isset($audioName) && file_exists(public_path('training_document/audios/' . $audioName))) {
        @unlink(public_path('training_document/audios/' . $audioName));
      }

      return response()->json([
        'status' => 500,
        'toastr' => [
          'type' => 'error',
          'message' => 'Failed to create training document: ' . $e->getMessage()
        ],
        'error' => $e->getMessage()
      ], 500);
    }
  }

  public function Edit($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $data = TrainingDocumentModel::where('status', '!=', 2)->where('sno', $id)
    // ->where('branch_id', $branch_id)
    ->first();

    if ($data) {
      return response([
        'status' => 200,
        'message' => 'Data Fetched Successfully!',
        'error_msg' => null,
        'data' => $data,
      ], 200);
    } else {
      return response([
        'status' => 400,
        'message' => 'Data Fetching Failed',
        'error_msg' => null,
        'data' => null,
      ], 400);
    }
  }


  public function Update(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'edit_cat_id' => 'required',
      'edit_sub_cat_id' => 'required',
      'edit_training_name' => 'required|max:70',
      'training_mode_edit' => 'required',
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 403,
        'message' => 'Incorrect Input Field Format',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null
      ], 403);
    }

    try {
      DB::beginTransaction();

      $sno = $request->edit_id;
      $userId = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $trainingName = $request->edit_training_name;

      $training = TrainingDocumentModel::where('sno', $sno)->where('status', '!=', 2)->firstOrFail();

      // Update basic fields
      $training->training_category_id = $request->edit_cat_id;
      $training->training_sub_category_id = $request->edit_sub_cat_id;
      $training->traning_name = $trainingName;
      $training->traning_mode = $request->training_mode_edit;
      $training->updated_by = $userId;

      // Handle each mode separately
      if ($request->training_mode_edit == '0') {
        // Text mode - clear any existing files
        // $this->deleteExistingFiles($training);
        $training->text_content = $request->edit_text;
        $training->video_link = null;
        $training->pdf_id = null;
        $training->image_id = null;
        $training->audio_id = null;
      } elseif ($request->training_mode_edit == '1') {
        // Video mode
        $training->text_content = null;
        $training->pdf_id = null;
        $training->audio_id = null;
        $training->image_id = null;
        // $this->deleteExistingFiles($training);

        // Handle video file operations
        if ($request->has('existing_video_name')) {
          if (empty($request->existing_video_name)) {
            if ($training->video_link) {
              $this->deleteVideoFile($training->video_link);
              $training->video_link = null;
            }
          }
          // Else keep existing video
        }

        // Upload new video if provided
        if ($request->hasFile('video_upload_edit')) {
          // Delete old video if exists
          if ($training->video_link) {
            $this->deleteVideoFile($training->video_link);
          }

          // Upload new video with unique name
          $video = $request->file('video_upload_edit');
          $videoName = 'video_' . time() . '_' . Str::random(10) . '.' . $video->getClientOriginalExtension();

          // Move file with error handling
          if (!$video->move(public_path('training_document/videos'), $videoName)) {
            throw new \Exception('Failed to upload video file');
          }

          $training->video_link = $videoName;
        }
      } elseif ($request->training_mode_edit == '2') {
        // PDF mode
        $training->text_content = null;
        $training->video_link = null;
        // $this->deleteExistingFiles($training);
        $training->image_id = null;
        $training->audio_id = null;

        if ($request->hasFile('attachment_edit')) {
          // Delete old PDF if exists
          if ($training->pdf_id) {
            $this->deletePdfFile($training->pdf_id);
          }

          // Upload new PDF
          $pdf = $request->file('attachment_edit');
          $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();

          if (!$pdf->move(public_path('training_document'), $pdfName)) {
            throw new \Exception('Failed to upload PDF file');
          }

          $training->pdf_id = $pdfName;
        }
      } elseif ($request->training_mode_edit == '3') {
        // Link mode
        $training->text_content = null;
        $training->video_link = null;
        $training->audio_id = null;
        // $this->deleteExistingFiles($training);
        $training->pdf_id = null;
        $training->ppt_id = null;
        $training->image_id = null;
        $training->link = $request->link_edit;
      } elseif ($request->training_mode_edit == '4') {
        $training->text_content = null;
        $training->pdf_id = null;
        $training->video_link = null;
        // $this->deleteExistingFiles($training);
        $training->image_id = null;

        // Handle video file operations
        if ($request->has('existing_audio_name')) {
          if (empty($request->existing_audio_name)) {
            if ($training->audio_id) {
              $this->deleteAudioFile($training->audio_id);
              $training->audio_id = null;
            }
          }
        }

        // Upload new video if provided
        if ($request->hasFile('audio_upload_edit')) {
          // Delete old video if exists
          if ($training->audio_id) {
            $this->deleteAudioFile($training->audio_id);
          }

          // Upload new video with unique name
          $audio = $request->file('audio_upload_edit');
          $audioName = 'audio_' . time() . '_' . Str::random(10) . '.' . $audio->getClientOriginalExtension();

          // Move file with error handling
          if (!$audio->move(public_path('training_document/audios'), $audioName)) {
            throw new \Exception('Failed to upload audio file');
          }

          $training->audio_id = $audioName;
        }
      } elseif ($request->training_mode_edit == '5') {
        $training->text_content = null;
        $training->video_link = null;
        $training->audio_id = null;
        $training->link = null;
        // $this->deleteExistingFiles($training);

        if ($request->hasFile('attachment_img_edit')) {
          // Delete old PDF if exists
          if ($training->pdf_id) {
            $this->deleteImgFile($training->pdf_id);
          }

          // Upload new PDF
          $pdf = $request->file('attachment_img_edit');
          $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();

          if (!$pdf->move(public_path('training_document/image'), $pdfName)) {
            throw new \Exception('Failed to upload Image');
          }

          $training->image_id = $pdfName;
        }
      } elseif ($request->training_mode_edit == '6') {
        $training->text_content = null;
        $training->video_link = null;
        $training->audio_id = null;
        $training->image_id = null;
        $training->link = null;
        // $this->deleteExistingFiles($training);

        if ($request->hasFile('attachment_ppt_edit')) {
          // Delete old PDF if exists
          if ($training->ppt_id) {
            $this->deletePPTFile($training->ppt_id);
          }

          // Upload new PDF
          $pdf = $request->file('attachment_ppt_edit');
          $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();

          if (!$pdf->move(public_path('training_document/ppt'), $pdfName)) {
            throw new \Exception('Failed to upload Image');
          }

          $training->ppt_id = $pdfName;
        }
      }

      // Process department and roles
      $roleIdGroups = $request->input('role_id', []);
      $training->role_ids = json_encode($roleIdGroups);

      $training->save();
      DB::commit();

      return response()->json([
        'status' => 200,
        'toastr' => [
          'type' => 'success',
          'message' => 'Training document updated successfully!'
        ]
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack();

      // Delete any uploaded files if error occurred
      if (isset($videoName) && file_exists(public_path('training_document/videos/' . $videoName))) {
        @unlink(public_path('training_document/videos/' . $videoName));
      }

      if (isset($audioName) && file_exists(public_path('training_document/audios/' . $audioName))) {
        @unlink(public_path('training_document/audios/' . $audioName));
      }

      if (isset($pdfName) && file_exists(public_path('training_document/' . $pdfName))) {
        @unlink(public_path('training_document/' . $pdfName));
      }

      return response()->json([
        'status' => 500,
        'message' => 'Training Document Update Failed!'
      ], 500);
    }
  }

  // Helper methods for file operations
  private function deleteExistingFiles($training)
  {
    if ($training->video_link) {
      $this->deleteVideoFile($training->video_link);
    }
    if ($training->pdf_id) {
      $this->deletePdfFile($training->pdf_id);
    }
    if($training->image_id) {
      $this->deleteImgFile($training->image_id);
    }
    if($training->ppt_id) {
      $this->deletePPTFile($training->ppt_id);
    }
    if($training->audio_id) {
      $this->deleteAudioFile($training->audio_id);
    }
  }

  private function deleteVideoFile($filename)
  {
    $filePath = public_path('training_document/videos/' . $filename);
    if (file_exists($filePath)) {
      @unlink($filePath);
    }
  }

  private function deleteAudioFile($filename)
  {
    $filePath = public_path('training_document/audios/' . $filename);
    if (file_exists($filePath)) {
      @unlink($filePath);
    }
  }

  private function deletePdfFile($filename)
  {
    $filePath = public_path('training_document/' . $filename);
    if (file_exists($filePath)) {
      @unlink($filePath);
    }
  }

  private function deleteImgFile($filename)
  {
    $filePath = public_path('training_document/image' . $filename);
    if (file_exists($filePath)) {
      @unlink($filePath);
    }
  }

  private function deletePPTFile($filename)
  {
    $filePath = public_path('training_document/ppt' . $filename);
    if (file_exists($filePath)) {
      @unlink($filePath);
    }
  }
  public function removeRole(Request $request)
    {
        $request->validate([
            'sno' => 'required|integer',
            'role_id' => 'required'
        ]);
    
        $training = DB::table('et_training_document')->where('sno', $request->sno)->first();
    
        if(!$training){
            return response()->json(['success' => false, 'message' => 'Record not found']);
        }
    
        // Decode role_ids
        $roleIds = is_string($training->role_ids) ? json_decode($training->role_ids, true) : $training->role_ids;
    
        // Remove the role_id
        $roleIds = array_filter($roleIds, function($id) use ($request){
            return $id != $request->role_id;
        });
    
        // Save back as JSON
        DB::table('et_training_document')
            ->where('sno', $request->sno)
            ->update(['role_ids' => json_encode(array_values($roleIds))]);
    
        return response()->json(['success' => true]);
    }
//   public function Update_role(Request $request)
//     {
//     $request->validate([
//         'edit_role_sno'   => 'required|integer',
//         'Add_role_table'  => 'required|array'
//     ]);

//     $training = DB::table('et_training_document')
//         ->where('sno', $request->edit_role_sno)
//         ->first();

//     if(!$training){
//         session()->flash('toastr', [
//             'type' => 'error',
//             'message' => 'Record not found!'
//         ]);
//         return redirect()->back();
//     }

//     // Decode old roles
//     $roleIds = is_string($training->role_ids) ? json_decode($training->role_ids, true) : $training->role_ids;
//     $roleIds = is_array($roleIds) ? $roleIds : [];

//     // ✅ Flatten new roles without Arr::flatten
//     $newRoles = [];
//     foreach ($request->Add_role_table as $roles) {
//         if (is_array($roles)) {
//             $newRoles = array_merge($newRoles, $roles);
//         } else {
//             $newRoles[] = $roles;
//         }
//     }

//     // ✅ Merge old + new, remove duplicates
//     $mergedRoles = array_unique(array_merge($roleIds, $newRoles));

//     // Save JSON back
//     DB::table('et_training_document')
//         ->where('sno', $request->edit_role_sno)
//         ->update(['role_ids' => json_encode(array_values($mergedRoles))]);

//     session()->flash('toastr', [
//         'type' => 'success',
//         'message' => 'Roles updated successfully!'
//     ]);

//     return redirect()->back();
// }

 public function Update_role(Request $request)
  {
    // return $request;
    $request->validate([
      'edit_role_sno' => 'required|integer',
      'Add_role_table' => 'required|array',
    ]);

    $training = DB::table('et_training_document')
      ->where('sno', $request->edit_role_sno)
      ->first();

    if (!$training) {
      return response()->json([
        'status' => 'error',
        'message' => 'Training document not found.',
      ], 404);
    }

    $roleIds = is_string($training->role_ids) ? json_decode($training->role_ids, true) : $training->role_ids;
    $roleIds = is_array($roleIds) ? $roleIds : [];

    $newRoles = [];
    foreach ($request->Add_role_table as $roles) {
      if (is_array($roles)) {
        $newRoles = array_merge($newRoles, $roles);
      } else {
        $newRoles[] = $roles;
      }
    }

    $mergedRoles = array_unique(array_merge($roleIds, $newRoles));

    DB::table('et_training_document')
      ->where('sno', $request->edit_role_sno)
      ->update(['role_ids' => json_encode(array_values($mergedRoles))]);

    // Fetch all roles at once to reduce DB queries
    $roles = UserRoleModel::where('status', 0)
      ->whereIn('sno', $mergedRoles)
      ->get()
      ->keyBy('sno');

    $rolesData = [];
    foreach ($mergedRoles as $roleId) {
      $role = $roles->get($roleId);
      $rolesData[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Roles updated successfully!',
      'roles'   => $rolesData,
    ]);
  }

 public function role_list_fetch($id)
  {
    $data = TrainingDocumentModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('role_ids')
      ->first();

    $roleIds = json_decode($data->role_ids, true);
    $roles = [];
    foreach ($roleIds as $roleId) {
      $role = UserRoleModel::where('status', 0)->where('sno', $roleId)->first(); 
      $roles[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['roles' => $roles]
    ], 200);
  }
}
