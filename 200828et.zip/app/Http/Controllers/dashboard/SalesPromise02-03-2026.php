<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SalesPromiseModel;
use App\Models\CustomerModel;
use Illuminate\Support\Facades\DB;

class SalesPromise extends Controller
{
    public function showTaskPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        // return $user;
         // Only show the modal for these roles
        $allowedRoles = ['11'];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => true, 'show_modal' => false]); // No modal for other roles
        }
        $task = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->where('branch_id',1)
            ->first();
            
            if($user->branch_id == 2){
                $task = 1;
            }
            

            return response()->json([
              'task' => $task,
              'show_modal' => !$task  // Show modal if task is not already submitted
          ]);
    }

    public function submitTask(Request $request)
    {
        $request->validate([
            'promise_count' => 'required|integer|min:1',
        ]);
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();

        $task = SalesPromiseModel::updateOrCreate(
        ['staff_id' => $user->user_id, 'promise_date' => $today],
        [
            'promise_count' => $request->promise_count,
            'branch_id' => $branch_id,
            'created_by' => $user->user_id,
            'updated_by' => $user->user_id,
            'created_at' => now(),
        ]
    );

        return response()->json(['success' => true]);
    }

    public function showFailerPopup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request('year', date('Y'));
        
        $month = request('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = [11];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['show_modal' => false]);
        }

        // Count successfully converted customers
        $customerConvertCount = CustomerModel::where('et_customer.status', 0)
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $user->branch_id)
            ->where('et_lead.created_by', $user->user_id)
             ->whereDate('et_customer.created_at',  date('Y-m-d'))
            ->count();
            
            $customerConvertCount =  DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    // ->where('et_customer.status', 0)
                    ->where('et_customer.branch_id', $user->branch_id)
                    ->where('et_lead.created_by', $user->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                     ->whereDay('et_payment.transaction_date', date('Y-m-d')) // Use `whereDay` instead of `whereDate`
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    // ->orderBy('et_customer.sno', 'asc')
                    ->count();


     // Count successfully converted customers
        $data = CustomerModel::where('et_customer.status', 0)->select('et_customer.cus_name','et_customer.created_at')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $user->branch_id)
            ->where('et_lead.created_by', $user->user_id)
             ->whereMonth('et_customer.created_at',  date('m'))
            ->get();
        // Check if the promise was not met
        $taskFailure = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->whereNull('failer_date_time') // Check if failer_date_time is NOT NULL
            ->where('status',0)
            ->where('promise_count', '>', $customerConvertCount) // If the promise count was not met
            ->exists();

        return response()->json(['show_modal' => $taskFailure,'customerConvertCount' => $customerConvertCount,'$data' => $customerConvertCount]);
    }

    public function submitFailureReason(Request $request)
    {
        $request->validate([
            'reason' => 'required|string|max:255',
        ]);
    
        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $user->branch_id;
    
        $updated = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('branch_id', $branch_id)
            ->where('promise_date', $today)
            ->update([
                'failer_date_time' => now(),  // corrected field name assuming typo
                'reason' => $request->reason,
                'updated_by' => $user->user_id,
                'status' => 2,
            ]);
    
        if ($updated) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false, 'message' => 'No records updated'], 404);
        }
    }


    public function showSuccessPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request()->get('year', date('Y'));
        $month = request()->get('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = ['11'];
        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => false, 'show_modal' => false]); // No modal for other roles
        }

        // $customerConvertCount = CustomerModel::select('et_customer.sno')
        //     ->where('et_customer.status', 0)
        //     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //     ->where('et_customer.branch_id', $user->branch_id)
        //     ->where('et_lead.created_by', $user->user_id)
        //      ->whereDate('et_customer.created_at',  date('Y-m-d'))
        //     ->count();
        
          $customerConvertCount =  DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    // ->where('et_customer.status', 0)
                    // ->where('et_customer.branch_id', 1)
                    ->where('et_lead.created_by', $user->user_id)
                     ->where('et_payment.transaction_date',  date('Y-m-d')) 
                    ->where('et_transaction.payment_status', 1)
                    ->count();
            
            // $customerConvertCount =  DB::table('et_customer')
            //         ->select('et_customer.sno', 'et_customer.proposal_ids')
            //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            //         ->join('et_payment', function($join) {
            //             $join->on('et_payment.customer_id', '=', 'et_customer.sno')
            //                  ->whereRaw('et_payment.transaction_date = (
            //                      SELECT MIN(ep.transaction_date)
            //                      FROM et_payment ep
            //                      WHERE ep.customer_id = et_customer.sno
            //                  )');
            //         })
            //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            //         // ->where('et_customer.status', 0)
            //         ->where('et_customer.branch_id', $user->branch_id)
            //         ->where('et_lead.created_by', $user->sno)
            //         // ->whereYear('et_payment.transaction_date', $year)
            //          ->whereDay('et_payment.transaction_date', date('Y-m-d')) // Use `whereDay` instead of `whereDate`
            //         // ->whereMonth('et_payment.transaction_date', $month)
            //         ->where('et_transaction.payment_status', 1)
            //         // ->orderBy('et_customer.sno', 'asc')
            //         ->count();

        // Check if promise was met
        $promiseMet = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->where('status', 0)
            ->where('promise_count', '<=', $customerConvertCount) // Promise met
            ->exists();

        return response()->json([
            'promiseMet' => $promiseMet,
            'show_modal' => $promiseMet  // Show modal only if promise was met
        ]);
    }

    public function submitSuccessCheers(Request $request)
    {

        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $request->user()->branch_id;
        SalesPromiseModel::where('staff_id', $user->user_id)->where('branch_id', $branch_id)
            ->where('promise_date', $today)
            ->update([
                'updated_by' => $user->user_id,
                'status' => 1,
            ]);

        return response()->json(['success' => true]);
    }


}
