<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;
// Model
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class Login extends Controller
{
  public function index()
  {
    return view('content.dashboard.login');
  }
  public function get_staff()
  {
    return view('content.dashboard.get_staff');
  }
  public function forgot_password()
  {
    return view('content.dashboard.forgot_password');
  }
  public function new_password()
  {
    return view('content.dashboard.new_password');
  }
  public function dashboards()
  {
    // Initialize variables
    $branch_common = null;
    $role_user = null;
    $role_permission = null;
    $user = Auth::user();
    if ($user) {
      $branch_common   = BranchModel::where('sno', $user->branch_id)->first();
      $role_user       = UserRoleModel::where('sno', $user->role_id)->first();
      $role_permission = UserRolePermissionModel::where('role_id', $user->role_id)->first();
    }
    $helper = new \App\Helpers\Helpers();
    
     if ($user->role_id == 1 || $user->role_id == 20) {
      return view('content.dashboard.business_head', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 11) {
      return view('content.dashboard.sales_executive_dashboards', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 12) {
      return view('content.dashboard.sales_tl_dashboard_new', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if($user->role_id ==  41){
      return view('content.dashboard.bdm_dashboard', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission,
        'user' =>$user
      ]);

    }

    if ($user->role_id == 33) {
      return view('content.dashboard.journal_teamlead_dashboad', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 34) {
      return view('content.dashboard.journal_coordinator_dashbord', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 15) {
      return view('content.dashboard.pc_dashboard', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 16) {
      return view('content.dashboard.cre_dashboard', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    return view('content.dashboard.dashboards-analytics', compact('branch_common', 'role_user', 'role_permission'));

  }

  public function login(Request $request)
  {
    // return Hash::make($request->password);
    // return $request;
    $validator = Validator::make($request->all(), [
      'name' => 'required|max:50',
      'password' => 'required',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' =>  $validator->errors(),
      ]);
      return back()->withInput();
      //   return response()->json([
      //     'status' => 422,
      //     'message' => 'Validation Error',
      //     'error_msg' => $validator->errors(),
      //     'data' => null
      //   ], 422);
    }
    $remember = $request->has('remember');
    $user = User::select('users.*', 'et_staff.status as staff_status')
      ->where('users.name', $request->name)
      ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
      ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
      ->where('et_branch.status', 0)
      ->where('et_staff.inactive_status', 0)
      ->where('et_staff.status', 0)
      ->first();

    if (!$user) {
      DB::table('user_login_logs')->insert([
        'user_id'    => 0,
        'login_at'   => Carbon::now('Asia/Kolkata'),
        'ip_address' => $request->ip(),
        'user_agent' => $request->header('User-Agent'),
        'user_name'  => $request->name,
        'password'   => $request->password,
        'type'       => 1, // failed
        'created_at' => Carbon::now('Asia/Kolkata'),
        'updated_at' => Carbon::now('Asia/Kolkata'),
      ]);
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'User not found.'
      ]);
      return back()->withInput();
    }

    if ($user->staff_status == 1) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is inactive. Please contact the administrator.'
      ]);
      return back()->withInput();
    } elseif ($user->staff_status == 2) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is deactivated. Please contact the administrator.'
      ]);
      return back()->withInput();
    }
    if ($user->name !== $request->name) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Username is case-sensitive. Please enter the correct case.'
      ]);
      return back()->withInput();
    }



    if (!Hash::check($request->password, $user->password)) {
DB::table('user_login_logs')->insert([
        'user_id'    => 0,
        'login_at'   => Carbon::now('Asia/Kolkata'),
        'ip_address' => $request->ip(),
        'user_agent' => $request->header('User-Agent'),
        'user_name'  => $request->name,
        'password'   => $request->password,
        'type'       => 1, // failed
        'created_at' => Carbon::now('Asia/Kolkata'),
        'updated_at' => Carbon::now('Asia/Kolkata'),
      ]);
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid credentials'
      ]);
      return back()->withInput();
    }

    // ✅ Log login info to user_login_logs
    DB::table('user_login_logs')->insert([
      'user_id'    => $user->id,
      'login_at'   => Carbon::now('Asia/Kolkata'),
      'ip_address' => $request->ip(),
      'user_agent' => $request->header('User-Agent'),
      'user_name'  => $request->name,
      'password'   => $request->password,
      'type'       => 0, // success
      'created_at' => Carbon::now('Asia/Kolkata'),
      'updated_at' => Carbon::now('Asia/Kolkata'),
    ]);

    // $user->task_timer = 1;
    if ($user->task_timer == 1) {

      $getUserlogin = DB::table('et_login_approval')
        ->where('staff_id', $user->user_id)
        ->first();

      if (!$getUserlogin) {
        session()->flash('toastr', [
          'authentication' => true,
          'user_id' => $user->user_id,
          'type' => 'error',
          'message' => 'Get Authentication Code..!'
        ]);
      } else {
        session()->flash('toastr', [
          'authentication' => true,
          'type' => 'error',
          'user_id' => $user->user_id,
          'message' => 'Authentication Blocked'
        ]);
      }

      return back()->withInput();
    }

    Auth::login($user, $remember);
    session(['user_id' => $user->id]);





    $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();

    // dd($permissions);
    // Assuming you have a method in the User model to check role permissions
    if (!$permissions) {
      // Redirect to the role_permission_error page if the user doesn't have the role
      return redirect()->route('role_permission_error');
    }
    // Create a personal access token
    $token = $user->createToken('auth_token')->plainTextToken;

    // Set the cookie with the token, valid for 1 day
    // Cookie::queue('auth_token', $token, 1440);




    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Login Successfully!'
    ]);

    if ($request->expectsJson()) {
      return response()->json([
        'status' => 200,
        'message' => 'Login Successful',
        'data' => [
          'redirect_url' => route('dashboards'),
          'token' => $token,
        ]
      ]);
    } else {
      $top_5_sales_persons = StaffModel::where('et_staff.branch_id', $user->branch_id)
        ->select(
          'et_staff.sno',  // Include sno to compare
          'et_staff.staff_name',
          'et_staff.nick_name',
          'et_staff.staff_image',
          DB::raw('COUNT(et_lead.created_by) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.created_by', '=', 'et_staff.sno')
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_staff.role_id', '!=', 12)
        ->where('et_lead.status', 4)
        ->groupBy('et_staff.sno', 'et_staff.staff_name', 'et_staff.nick_name', 'et_staff.staff_image')
        ->orderBy('total_leads', 'desc')
        ->limit(5)
        ->get();


      if ($top_5_sales_persons && $top_5_sales_persons->count() > 1) {
        $firstStaff = $top_5_sales_persons->first();
        $lastStaff = $top_5_sales_persons->last();

        // Clear both to avoid overlap
        session()->forget(['show_congrats_modal', 'show_loser_modal']);

        if ($lastStaff && $lastStaff->sno == $user->user_id) {
          session(['show_loser_modal' => true]);
        } elseif ($firstStaff && $firstStaff->sno == $user->user_id) {
          session(['show_congrats_modal' => true]);
        }
      }
      return redirect()->route('dashboards');  // Ensure correct route name

    }
  }

//   public function destroy(Request $request)
//   {

//     // Get the current authenticated user
//     $user = Auth::user();

//     if ($user) {
//       // Update the latest login log with logout time
//       DB::table('user_login_logs')
//         ->where('user_id', $user->id)
//         ->whereNull('logout_at') // Ensure we only update the last active session
//         ->latest('login_at')
//         ->limit(1)
//         ->update([
//           'logout_at' => now(),
//           'updated_at' => now()
//         ]);
//     }
//     Auth::guard('web')->logout();

//     $request->session()->invalidate();

//     $request->session()->regenerateToken();

//     $cookieName = config('session.cookie'); // Get the session cookie name from configuration
//     Cookie::queue(Cookie::forget($cookieName));

//     return redirect('/');
//   }
  
  public function destroy(Request $request)
  {
 
    $roleId = $request->user()->role_id;
    $userId = $request->user()->user_id;
 
    if ($roleId == 36 || $roleId == 32) {
      $timer = DB::table('et_task_log')
                ->where('status', 0)
                ->whereNull('end_time')
                ->where('staff_id', $userId)
                ->first();
 
      if ($timer) {
 
        $startTime = Carbon::parse($timer->start_time);
        $now = Carbon::now();
 
        $seconds = $startTime->diffInSeconds($now);
 
        // Format HH:MM:SS
        $duration = gmdate('H:i:s', $seconds);
 
        return response([
          'status' => 'success',
          'message' => 'Stop the timer',
          'data' => $duration
        ], 409);
      }
    }
 
 
     // Get the current authenticated user
    $user = Auth::user();
 
    if ($user) {
        // Update the latest login log with logout time
        DB::table('user_login_logs')
            ->where('user_id', $user->id)
            ->whereNull('logout_at') // Ensure we only update the last active session
            ->latest('login_at')
            ->limit(1)
            ->update([
                'logout_at' => now(),
                'updated_at' => now()
            ]);
    }
    Auth::guard('web')->logout();
 
    $request->session()->invalidate();
 
    $request->session()->regenerateToken();
 
    $cookieName = config('session.cookie'); // Get the session cookie name from configuration
    \Cookie::queue(\Cookie::forget($cookieName));
 
    return redirect('/');
  }
 
 
 
  public function updateProfile(Request $request)
  {
    $user = Auth::user(); // Get authenticated user

    // Validate request
    $request->validate([
      'staff_password' => 'nullable|min:6', // Password is optional, must be at least 6 characters if provided
      'staff_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Image validation
    ]);

    // Update password in user table if provided
    if ($request->filled('staff_password')) {
      $user->password = Hash::make($request->staff_password); // Hash and update password
      $user->save();
    }

    // Update password in staff table if exists
    $staff = $user->staff;
    if ($staff) {
      if ($request->filled('staff_password')) {
        $staff->password = $request->staff_password; // Hash and update password
      }

      // Handle profile image upload
      if ($request->hasFile('staff_image')) {
        $image = $request->file('staff_image');
        $staff_imageName = 'staff_' . $staff->sno . '.' . $image->extension();
        $image->move(public_path('staff_images'), $staff_imageName);
        $staff->staff_image = $staff_imageName;
      }

      $staff->save(); // Save staff record after updating password and/or image
    }

    return back()->with('success', 'Profile updated successfully.');
  }

  // Egc Login handle
  public function HandleEGCLogin(Request $request)
  {
    if (!$request->token) {
      abort(400, "Missing SSO token");
    }



    // Verify with App1
    $verifyResponse = Http::get($request->token);

    if (!$verifyResponse->ok()) {
      abort(401, "SSO Verification failed");
    }

    $data = $verifyResponse->json()['data'];

    if ($data['secret_token'] != 'egcswitchportal2027') {
      abort(401, "UnAuthorized Entry");
    }

    $user_name = $data['user_name'];
    $email = $data['email'];

    // Find user in ERP database
    $user = User::where('name', $user_name)
      ->first();

    if (!$user) {
      abort(404, "User not found");
    }

    // Direct login, no password check needed
    Auth::login($user);

    return redirect()->route('dashboards');
  }
}
