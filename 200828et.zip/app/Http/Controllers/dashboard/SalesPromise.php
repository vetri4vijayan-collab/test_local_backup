<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SalesPromiseModel;
use App\Models\CustomerModel;
use App\Models\StaffModel;
use App\Models\StaffpointsModel;
use Illuminate\Support\Facades\DB;

class SalesPromise extends Controller
{
    public function showTaskPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        // return $user;
        // Only show the modal for these roles
        $allowedRoles = ['11'];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => true, 'show_modal' => false]); // No modal for other roles
        }
        $task = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->where('branch_id', 1)
            ->first();

        $goalSetData = DB::table('et_goal_set_staff')
            ->where('staff_id', $user->user_id)
            ->whereMonth('goal_date', now()->month)
            ->whereYear('goal_date', now()->year)
            ->select('conversion')
            ->first();

        // Monthly total promise count
        $taskSum = SalesPromiseModel::where('staff_id', $user->user_id)
            ->whereMonth('promise_date', now()->month)
            ->whereYear('promise_date', now()->year)
            ->sum('promise_count');

        $conversion = $goalSetData->conversion ?? 8;

        // Remaining count (never negative)
        $remaining = max(0, $conversion - $taskSum);

        //  next condition

        // Current month total days
        $totalDaysInMonth = now()->daysInMonth;

        // Current date (day number)
        $currentDay = now()->day;

        // Remaining days in this month
        $remainingDays = $totalDaysInMonth - $currentDay;


        // Validation condition
        $isValid = ($remaining > $remainingDays);
        return response()->json([
            'task' => $task,
            'show_modal' => !$task,
            'remaining' => $remaining,
            'remaining_days' => $remainingDays,
            'validation' => $isValid
        ]);
    }

    public function submitTask(Request $request)
    {
        $request->validate([
            'promise_count' => 'required|integer',
        ]);
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();

        $task = SalesPromiseModel::updateOrCreate(
            ['staff_id' => $user->user_id, 'promise_date' => $today],
            [
                'promise_count' => $request->promise_count,
                'branch_id' => $branch_id,
                'created_by' => $user->user_id,
                'updated_by' => $user->user_id,
                'created_at' => now(),
            ]
        );

        return response()->json(['success' => true]);
    }

    public function showFailerPopup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request('year', date('Y'));

        $month = request('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = [11];

        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['show_modal' => false]);
        }

        // Count successfully converted customers
        $customerConvertCount = CustomerModel::where('et_customer.status', 0)
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $user->branch_id)
            ->where('et_lead.created_by', $user->user_id)
            ->whereDate('et_customer.created_at',  date('Y-m-d'))
            ->count();

        $customerConvertCount =  DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            // ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $user->branch_id)
            ->where('et_lead.created_by', $user->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereDay('et_payment.transaction_date', date('Y-m-d')) // Use `whereDay` instead of `whereDate`
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            // ->orderBy('et_customer.sno', 'asc')
            ->count();


        // Count successfully converted customers
        $data = CustomerModel::where('et_customer.status', 0)->select('et_customer.cus_name', 'et_customer.created_at')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $user->branch_id)
            ->where('et_lead.created_by', $user->user_id)
            ->whereMonth('et_customer.created_at',  date('m'))
            ->get();
        // Check if the promise was not met
        $taskFailure = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('promise_date', $today)
            ->whereNull('failer_date_time') // Check if failer_date_time is NOT NULL
            ->where('status', 0)
            ->where('promise_count', '>', $customerConvertCount) // If the promise count was not met
            ->exists();
        $sch_count  = DB::table('et_schedule_daily_call')
            ->where('current_staff', $user->user_id)
            ->where('sch_date', date('Y-m-d'))
            ->where('branch_id', $user->branch_id)
            ->count();
        $dailyCallmet = DB::table('za_sales_dailly_call')
            ->where('branch_id', $user->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user->user_id)
            ->whereDate('dc_date', date('Y-m-d'))
            ->where('dc_count', '<', $sch_count) // Promise met
            ->exists();
        return response()->json([
            'show_modal' => $taskFailure,
            'show_modal_call' => $dailyCallmet,
            'customerConvertCount' => $customerConvertCount,
            '$data' => $customerConvertCount
        ]);
    }

    public function submitFailureReason(Request $request)
    {
        $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $user->branch_id;

        $updated = SalesPromiseModel::where('staff_id', $user->user_id)
            ->where('branch_id', $branch_id)
            ->where('promise_date', $today)
            ->update([
                'failer_date_time' => now(),  // corrected field name assuming typo
                'reason' => $request->reason,
                'updated_by' => $user->user_id,
                'status' => 2,
            ]);

        if ($updated) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false, 'message' => 'No records updated'], 404);
        }
    }

    public function submitFailureReasonCall(Request $request)
    {
        $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $request->user()->branch_id;
           

        $updated = DB::table('za_sales_dailly_call')
                ->where('staff_id', $user->user_id)
                ->where('branch_id', $branch_id)
                ->where('dc_date', $today)
            ->update([
                'failer_date_time' => now(),
                'reason' => $request->reason,
                'updated_by' => $user->user_id,
                'status' => 2,
            ]);
        return response()->json(['success' => true]);
    }



    public function showSuccessPopup()
    {
        $user = auth()->user();
        $today = now()->toDateString();
        $year  = request()->get('year', date('Y'));
        $month = request()->get('month', date('m'));

        // Only show the modal for these roles
        $allowedRoles = ['11'];
        if (!in_array($user->role_id, $allowedRoles)) {
            return response()->json(['task' => false, 'show_modal' => false]); // No modal for other roles
        }

        // $customerConvertCount = CustomerModel::select('et_customer.sno')
        //     ->where('et_customer.status', 0)
        //     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //     ->where('et_customer.branch_id', $user->branch_id)
        //     ->where('et_lead.created_by', $user->user_id)
        //      ->whereDate('et_customer.created_at',  date('Y-m-d'))
        //     ->count();

        $customerConvertCount =  DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            // ->where('et_customer.status', 0)
            // ->where('et_customer.branch_id', 1)
            ->where('et_lead.created_by', $user->user_id)
            ->where('et_payment.transaction_date',  date('Y-m-d'))
            ->where('et_transaction.payment_status', 1)
            ->count();

        // $customerConvertCount =  DB::table('et_customer')
        //         ->select('et_customer.sno', 'et_customer.proposal_ids')
        //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        //         ->join('et_payment', function($join) {
        //             $join->on('et_payment.customer_id', '=', 'et_customer.sno')
        //                  ->whereRaw('et_payment.transaction_date = (
        //                      SELECT MIN(ep.transaction_date)
        //                      FROM et_payment ep
        //                      WHERE ep.customer_id = et_customer.sno
        //                  )');
        //         })
        //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        //         // ->where('et_customer.status', 0)
        //         ->where('et_customer.branch_id', $user->branch_id)
        //         ->where('et_lead.created_by', $user->sno)
        //         // ->whereYear('et_payment.transaction_date', $year)
        //          ->whereDay('et_payment.transaction_date', date('Y-m-d')) // Use `whereDay` instead of `whereDate`
        //         // ->whereMonth('et_payment.transaction_date', $month)
        //         ->where('et_transaction.payment_status', 1)
        //         // ->orderBy('et_customer.sno', 'asc')
        //         ->count();

        // Check if promise was met
        // Check if promise was met
        $promiseMet = SalesPromiseModel::where('staff_id', $user->user_id)
            ->whereDate('promise_date', $today)
            ->where('status', 0)
            ->where('promise_count', '>', 0) // Ignore zero
            ->where('promise_count', '<=', $customerConvertCount)
            ->exists();

        $sch_count  = DB::table('et_schedule_daily_call')
            ->where('current_staff', $user->user_id)
            ->where('sch_date', date('Y-m-d'))
            ->where('branch_id', $user->branch_id)
            ->count();

        $dailyCallmet = DB::table('za_sales_dailly_call')
            ->where('branch_id', $user->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user->user_id)
            ->whereDate('created_at', date('Y-m-d'))
            ->where('dc_count', '>=', $sch_count) // Promise met
            ->exists();

        if ($dailyCallmet) {
            $user = auth()->user();
            $branch_id = $user->branch_id;
            $staff_id = $user->user_id;

            // Check if points already awarded today
            $prechk = StaffpointsModel::where('points_id', 27)
                ->whereDate('created_at', today())
                ->where('staff_id', $staff_id)
                ->first();

            if (!$prechk) {
                // Initialize helper and get points data
                $helper = new \App\Helpers\Helpers();
                $pointsData = $helper->get_points_by_id(27);

                // Set default values if pointsData is null
                $point = $pointsData->points ?? 0;
                $reason = $pointsData->points_name ?? 'Schedule Daily Call Complete points';

                try {
                    // Save new points for the staff
                    $newPoints = StaffpointsModel::create([
                        'branch_id' => $branch_id,
                        'staff_id'  => $staff_id,
                        'points_by' => 0,
                        'points_id' => 27,
                        'points'    => $point,
                        'reason'    => $reason
                    ]);

                    // Update staff's available points
                    if ($newPoints && $point > 0) {
                        StaffModel::where('sno', $staff_id)
                            ->increment('avaiable_points', $point);
                    }
                } catch (\Exception $e) {
                    // Log error or handle exception as needed
                    // \Log::error('Failed to award daily call points: ' . $e->getMessage());
                }
            }
        }

        return response()->json([
            'promiseMet' => $promiseMet,
            'show_modal' => $promiseMet,  // Show modal only if promise was met
            'show_modal_call' => $dailyCallmet,  // Show modal cal only if daily Call was met
        ]);
    }

    public function submitSuccessCheers(Request $request)
    {

        $user = auth()->user();
        $today = now()->toDateString();
        $branch_id = $request->user()->branch_id;
        SalesPromiseModel::where('staff_id', $user->user_id)->where('branch_id', $branch_id)
            ->where('promise_date', $today)
            ->update([
                'updated_by' => $user->user_id,
                'status' => 1,
            ]);

        return response()->json(['success' => true]);
    }

    public function submitSuccessCheersCall(Request $request)
    {
        try {

            $user = auth()->user();
            $today = now()->toDateString();
            $branch_id = $request->user()->branch_id;

            $updated = DB::table('za_sales_dailly_call')
                ->where('staff_id', $user->user_id)
                ->where('branch_id', $branch_id)
                ->whereDate('created_at', $today) // FIXED
                ->update([
                    'status'      => 2,
                    'updated_by'  => $user->user_id,
                    'updated_at'  => now()
                ]);

            if ($updated > 0) {
                return response()->json([
                    'success' => true,
                    'message' => 'Status updated successfully.'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'No record found to update.'
                ], 404);
            }
        } catch (\Exception $e) {

            return response()->json([
                'success' => false,
                'message' => 'Something went wrong.',
                'error'   => $e->getMessage()
            ], 500);
        }
    }
}
