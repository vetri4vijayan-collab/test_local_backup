<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class JournalReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function journal_yearly()
    {
        $feedbacknavHtml = $this->generateNavHtml();

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $types_list = [
            'submitted' => 'Submitted',
            'reviewed' => 'Revisioned',
            'accepted' => 'Accepted',
            'rejected' => 'Rejected',
            'published' => 'Published'
        ];

        return view('content.report_management.journal_report.journal_yearly_list', compact(
            'months','types_list','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function JournalYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $search_lead_src_fill = $request->search_lead_src_fill ?? 'submitted';

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getJournalStatusBasedDailyMonthlyYearlyReport($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_lists = [
                'submitted' => 'Submitted',
                'reviewed' => 'Revisioned',
                'accepted' => 'Accepted',
                'rejected' => 'Rejected',
                'published' => 'Published'
            ];

            $type_colors = [
                'submitted' => '#6c757d',
                'reviewed'  => '#0dcaf0',
                'accepted'  => '#198754',
                'rejected'  => '#dc3545',
                'published' => '#0d6efd'
            ];

            $types_list = $search_lead_src_fill && isset($types_lists[$search_lead_src_fill]) ? [$search_lead_src_fill => $types_lists[$search_lead_src_fill]] : $types_lists;
    
            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $month_percentages = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$type_key][$year][$monthNum]) ? $monthlyData[$type_key][$year][$monthNum] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$type_key][$year] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                // $percentages[$year] = ($monthly_data[$year]['drop_percentage'] ?? 0);
                                // $month_percentages[$year][$monthNum] = isset($monthlyData[$year][$monthNum]['drop_percentage']) ? $monthlyData[$year][$monthNum]['drop_percentage'] : 0;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$type_key][$year] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
                    }
                }
            }

            $Trend_data_year  = [];
            $Trend_data = [];

            foreach ($finalYears as $year_index => $year) {

                // skip first year
                if ($year_index == 0) {
                    continue;
                }

                foreach ($types_lists as $type_key => $type_name) {

                    // yearly total
                    $Trend_data_year[$type_key][] =
                        $monthly_data[$type_key][$year] ?? 0;

                    // monthly data
                    foreach ($months as $monthNum => $monthName) {
                        $Trend_data[$type_key][$year][] =
                            $monthlyData[$type_key][$year][$monthNum] ?? 0;
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'Trend_data_year' => $Trend_data_year,
                'month_percentages' => $month_percentages,
                'type_colors' => $type_colors,
                'status_head' => $search_lead_src_fill ? ucfirst($types_lists[$search_lead_src_fill]) : 'Status',
                'search_lead_src_fill' => $search_lead_src_fill ?? '',
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function journal_duarions_yearly()
    {
        $feedbacknavHtml = $this->generateNavHtml();

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $types_list = [
            'submitted' => 'Submitted',
            'reviewed' => 'Reviewed',
            'accepted' => 'Accepted',
            'rejected' => 'Rejected',
            'published' => 'Published'
        ];

        return view('content.report_management.journal_report.journal_duarions_yearly_list', compact(
            'months','types_list','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function JournalDuarionsYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $search_lead_src_fill = $request->search_lead_src_fill ?? 'submitted';

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getJournalMonthDurationReport($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            

            // return $result;
            
            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            $headers = $result['headers'] ?? [];
            $short_headers = [];

            // return $result;

            $types_lists = [
                'submitted' => 'Submitted',
                'reviewed' => 'Reviewed',
                'accepted' => 'Accepted',
                'rejected' => 'Rejected',
                'published' => 'Published'
            ];

            $type_colors = [
                'submitted' => '#6c757d',
                'reviewed'  => '#0dcaf0',
                'accepted'  => '#198754',
                'rejected'  => '#dc3545',
                'published' => '#0d6efd'
            ];

            $types_list = $search_lead_src_fill && isset($types_lists[$search_lead_src_fill]) ? [$search_lead_src_fill => $types_lists[$search_lead_src_fill]] : $types_lists;
    
            $type_keys = array_keys($types_list);
            
            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $month_percentages = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($headers as $monthNum => $monthName) {

                        // $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            // if (strtotime($date_format) <= strtotime($currentDate)) {
                            
                            $amount = isset($monthlyData[$type_key][$year][$monthNum]) ? $monthlyData[$type_key][$year][$monthNum] : 0;

                            // } else {
                            //     $amount = 0;
                            // }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$type_key][$year] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                // $percentages[$year] = ($monthly_data[$year]['drop_percentage'] ?? 0);
                                // $month_percentages[$year][$monthNum] = isset($monthlyData[$year][$monthNum]['drop_percentage']) ? $monthlyData[$year][$monthNum]['drop_percentage'] : 0;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$type_key][$year] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        // if($year_index != 0){
                        //     $Trend_data[$year][] = $Trend_data_list;
                        // }
                    }
                }
            }

            if(!empty($headers)){
                uksort($headers, function ($a, $b) {
                    $aStart = (int) explode('-', $a)[0];
                    $bStart = (int) explode('-', $b)[0];
                    return $aStart <=> $bStart;
                });

                foreach ($headers as $k => $v) {
                    [$start, $end] = explode('-', $k);
                    $short_headers[$k] = $short_months[$start] . ' - ' . $short_months[$end];
                }
            }

            $Trend_data_year  = [];
            $Trend_data = [];

            foreach ($finalYears as $year_index => $year) {

                // skip first year
                if ($year_index == 0) {
                    continue;
                }

                foreach ($types_lists as $type_key => $type_name) {

                    // yearly total
                    $Trend_data_year[$type_key][] =
                        $monthly_data[$type_key][$year] ?? 0;

                    // monthly data
                    foreach ($headers as $monthNum => $monthName) {
                        $Trend_data[$type_key][$year][] =
                            $monthlyData[$type_key][$year][$monthNum] ?? 0;
                    }
                }
            }
            
            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'duration_headers' => $headers,
                'duration_short_headers' => $short_headers,
                'month_percentages' => $month_percentages,
                'type_colors' => $type_colors,
                'Trend_data_year' => $Trend_data_year,
                'status_head' => $search_lead_src_fill ? ucfirst($search_lead_src_fill) : 'Status',
                'search_lead_src_fill' => $search_lead_src_fill ?? '',
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getJournalStatusBasedDailyMonthlyYearlyReport(int $branch_id)
    {
        if (!$branch_id) {
            return [];
        }

        /* ================= STATUS CONFIG ================= */
        $config = [
            'submitted' => [
                'status' => 0,
                'history_date' => 'submitted_date',
                'manage_date'  => 'submited_date'
            ],
            'reviewed' => [
                'status' => 4,
                'history_date' => 'reviewed_date',
                'manage_date'  => 'reviewed_at'
            ],
            'accepted' => [
                'status' => 5,
                'history_date' => 'accepted_date',
                'manage_date'  => 'accepted_at'
            ],
            'rejected' => [
                'status' => 6,
                'history_date' => 'rejected_date',
                'manage_date'  => 'rejected_at'
            ],
            'published' => [
                'status' => 8,
                'history_date' => 'published_date',
                'manage_date'  => 'published_at'
            ],
        ];

        /* ================= INIT ================= */
        $result = [
            'years'   => [],
            'yearly'  => [],
            'monthly' => [],
            'daily'   => [],
        ];

        foreach ($config as $type => $c) {
            $result['yearly'][$type]  = [];
            $result['monthly'][$type] = [];
            $result['daily'][$type]   = [];
        }

        /* ================= FETCH TABLES ================= */
        $historyRows = DB::table('et_journal_history')
            ->where('branch_id', $branch_id)
            ->get()
            ->keyBy('journal_id');

        $manageRows = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->get();

        /* ================= PROCESS ================= */
        foreach ($manageRows as $manage) {

            $history = $historyRows[$manage->journal_id] ?? null;

            foreach ($config as $type => $c) {

                /* ---- STATUS CHECK (manage or history) ---- */
                $statusMatch = false;

                if ($manage->status == $c['status']) {
                    $statusMatch = true;
                }

                if ($history && $history->status == $c['status']) {
                    $statusMatch = true;
                }

                if (!$statusMatch) {
                    continue;
                }

                /* ---- DATE FALLBACK CHAIN ---- */
                $dateValue = null;

                // 1️⃣ history date
                if ($history && !empty($history->{$c['history_date']})) {
                    $dateValue = $history->{$c['history_date']};
                }

                // 2️⃣ manage date
                elseif (!empty($manage->{$c['manage_date']})) {
                    $dateValue = $manage->{$c['manage_date']};
                }

                // 3️⃣ fallback updated_at
                elseif ($history && !empty($history->updated_at)) {
                    $dateValue = $history->updated_at;
                }
                elseif (!empty($manage->updated_at)) {
                    $dateValue = $manage->updated_at;
                }

                if (empty($dateValue)) {
                    continue;
                }

                $date = \Carbon\Carbon::parse($dateValue);

                $y = $date->year;
                $m = $date->month;
                $d = $date->day;

                $result['years'][$y] = $y;

                $result['yearly'][$type][$y] =
                    ($result['yearly'][$type][$y] ?? 0) + 1;

                $result['monthly'][$type][$y][$m] =
                    ($result['monthly'][$type][$y][$m] ?? 0) + 1;

                $result['daily'][$type][$y][$m][$d] =
                    ($result['daily'][$type][$y][$m][$d] ?? 0) + 1;
            }
        }

        ksort($result['years']);
        return $result;
    }
    
    public function getJournalMonthDurationReport(int $branch_id)
    {
        if (!$branch_id) {
            return [];
        }

        /* ================= STATUS CONFIG ================= */
        $config = [
            'submitted' => [
                'status' => 0,
                'history_date' => 'submitted_date',
                'manage_date'  => 'submited_date'
            ],
            'reviewed' => [
                'status' => 4,
                'history_date' => 'reviewed_date',
                'manage_date'  => 'reviewed_at'
            ],
            'accepted' => [
                'status' => 5,
                'history_date' => 'accepted_date',
                'manage_date'  => 'accepted_at'
            ],
            'rejected' => [
                'status' => 6,
                'history_date' => 'rejected_date',
                'manage_date'  => 'rejected_at'
            ],
            'published' => [
                'status' => 8,
                'history_date' => 'published_date',
                'manage_date'  => 'published_at'
            ],
        ];

        /* ================= INIT ================= */
        $result = [
            'years'   => [],
            'yearly'  => [],
            'monthly' => [],   // duration based
            'headers' => [],   // duration based
        ];

        foreach ($config as $type => $c) {
            $result['yearly'][$type]  = [];
            $result['monthly'][$type] = [];
        }

        /* ================= FETCH ================= */
        $historyRows = DB::table('et_journal_history')
            ->where('branch_id', $branch_id)
            ->get()
            ->keyBy('journal_id');

        $manageRows = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->get();

        /* ================= PROCESS ================= */
        foreach ($manageRows as $manage) {

            $history = $historyRows[$manage->journal_id] ?? null;

            foreach ($config as $type => $c) {

                /* ---------- STATUS CHECK ---------- */
                $statusMatch = false;

                if ($manage->status == $c['status']) {
                    $statusMatch = true;
                }

                if ($history && $history->status == $c['status']) {
                    $statusMatch = true;
                }

                if (!$statusMatch) {
                    continue;
                }

                /* ---------- DATE FALLBACK ---------- */
                $dateValue = null;

                if ($history && !empty($history->{$c['history_date']})) {
                    $dateValue = $history->{$c['history_date']};
                } elseif (!empty($manage->{$c['manage_date']})) {
                    $dateValue = $manage->{$c['manage_date']};
                } elseif ($history && !empty($history->updated_at)) {
                    $dateValue = $history->updated_at;
                } elseif (!empty($manage->updated_at)) {
                    $dateValue = $manage->updated_at;
                }

                if (empty($dateValue)) {
                    continue;
                }

                $date = \Carbon\Carbon::parse($dateValue);

                $y = $date->year;
                $m = $date->month;

                $result['years'][$y] = $y;

                /* ================= YEARLY ================= */
                $result['yearly'][$type][$y] =
                    ($result['yearly'][$type][$y] ?? 0) + 1;

                /* ================= MONTH RANGE ================= */
                if ($m >= 1 && $m <= 3) {
                    $range = '1-3';
                } elseif ($m >= 4 && $m <= 6) {
                    $range = '4-6';
                } elseif ($m >= 7 && $m <= 9) {
                    $range = '7-9';
                } else {
                    $range = '10-12';
                }

                $result['headers'][$range] = $range;

                $result['monthly'][$type][$y][$range] =
                    ($result['monthly'][$type][$y][$range] ?? 0) + 1;
            }
        }

        ksort($result['years']);

        return $result;
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    public function get_lead_type_list()
    {
        $LeadTypeModelList = LeadTypeModel::where('status', '!=', 2)->orderBy('lead_type_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    private function generateLeadSourceAttractiveColorsNew($leadTypesMapped, $baseHue = 200)
    {
        $colors = [];
        if (!empty($leadTypesMapped)) {
            foreach ($leadTypesMapped as $slotType => $slots) {
                // Ensure valid data
                if (!is_array($slots) || empty($slots)) {
                    continue;
                }
                $count = count($slots);
                $i = 0;
                foreach ($slots as $slug => $label) {
                    $hue = ($baseHue + $i * (360 / $count)) % 360;
                    // Assign color to slug within its slotType
                    $colors[$slotType][$slug] = "hsl({$hue}, 65%, 55%)";

                    $i++;
                }
            }
        }
        return $colors;
    }

    private function generateNavHtml()
    {
        $menus =  [
            [
                'title' => 'Journal Status',
                'url' => url('/manage_reports/journal_yearly'),
                'is_active' => request()->is([
                    'manage_reports/journal_yearly'
                ]),
            ],
            [
                'title' => 'Journal Status Vs Durations',
                'url' => url('/manage_reports/journal_duarions_yearly'),
                'is_active' => request()->is([
                    'manage_reports/journal_duarions_yearly'
                ]),
            ]
        ];

        $html = '<div class="w-65 nav-align-top mb-2"><div class="nav-align-top mb-2">';
        $html .= '<ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">';

        foreach ($menus as $menu) {

            $active = $menu['is_active'] ? 'active' : '';

            $html .= "<div class='item'><li class='nav-item'>
                    <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                        {$menu['title']}
                    </a>
                </li></div>
            ";
        }

        $html .= '</div><button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button></div></ul></div></div>';

        return $html;
    }
}