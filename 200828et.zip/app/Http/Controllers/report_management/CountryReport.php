<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\CountryModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;

class CountryReport extends Controller
{
    public static $report_heading = 'Analysis';

    public function country_wise_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);
        
        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.lead_report.country_wise_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function getCountryWiseYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCountryWiseLeadDetails($request);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            // $lead_source_list = collect($lead_source_list)
            //     ->mapWithKeys(fn($value, $key) => [(string)$key => $value])
            //     ->sort(function ($a, $b) {
            //         return strcasecmp($a, $b);
            //     })
            //     ->toArray();

            $lead_source_list = collect($lead_source_list)
                ->mapWithKeys(function ($value, $key) {return [(string)$key => $value];})
                ->sort(function ($a, $b) {
                    return strcasecmp($a, $b);
                })
                ->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        $percentages[$lead_source_id] =
                            $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function country_wise_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.lead_report.country_wise_monthly_list', compact(
            'days','currentMonth', 'currentYear','months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function getCountryWiseMonthlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCountryWiseLeadDetails($request);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $lead_source_list = collect($lead_source_list)->mapWithKeys(function ($value, $key) {return [(string)$key => $value];})->sort(function ($a, $b) {
                return strcasecmp($a, $b);
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        $percentages[$lead_source_id] =
                            $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }

    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    public function get_country_list()
    {
        $countries = CountryModel::where('status', '!=', 2)
            ->orderBy('name', 'asc')
            ->get();

        // ✅ Add "Others" at top
        $others = collect([
            [
                'id' => 0,
                'name' => 'Others'
            ]
        ]);

        $countries = $others->merge($countries);

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $countries
        ], 200);
    }

    public function GetCountryWiseLeadDetails($request)
    {
        $branch_id = $request->user()->branch_id;
        $entity_id = $request->user()->entity_id;

        $search_country_filter = $request->search_lead_src_fill ?? [];

        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];

        /* ------------------------------------
        * 1. Country List
        * ------------------------------------ */
        $country_list = DB::table('et_countries')
            ->select('id', 'name as source_name')
            ->where('status','!=', 2)
            ->when(!empty($search_country_filter), function ($q) use ($search_country_filter) {
                $q->whereIn('id', $search_country_filter);
            })
            ->orderBy('name', 'asc')
            ->get();

        $sortedCountry = $country_list->sortBy(function ($item) {
            return strtolower($item->source_name);
        });

        // $sortedCountry = $country_list->sortBy(fn($item) => strtolower($item->source_name));

        $countryIds  = $sortedCountry->pluck('id')->toArray();
        $countryList = $sortedCountry->pluck('source_name', 'id')->toArray();

        // ✅ Add Others
        $othersId = 0;
        $isOnlyOthers = (count($search_country_filter) == 1 && in_array($othersId, $search_country_filter));

        // dd($search_country_filter);

        if ($isOnlyOthers) {
            $countryList = [0 => 'Others'];
            $countryIds = [0];
        }else{
            $countryList = [$othersId => 'Others'] + $countryList;
            $countryIds[] = $othersId;
        }
        

        /* ---------------------------------------------------------
        | 2. LEAD DATA
        --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_countries', 'et_lead.country', '=', 'et_countries.id','left')
            ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->select(
                DB::raw('COALESCE(et_countries.id, 0) as source_id'),
                DB::raw('COALESCE(et_countries.name, "Others") as source_name'),
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', 0)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.spam_verified', 0)
            // ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.entity_id', $entity_id)
            ->where(function ($q) use ($countryIds, $isOnlyOthers) {
                if ($isOnlyOthers) {
                    // Only Others
                    $q->whereNull('et_countries.id')
                    ->orWhere('et_countries.id', 0);
                } else {
                    // Normal + Others
                    $q->whereIn('et_countries.id', $countryIds)
                    ->orWhereNull('et_countries.id');
                }

            })
            ->groupBy('source_id','source_name','y','m','d')
            ->get();

        /* ---------------------------------------------------------
        | 3. CONVERSION DATA (PRE + POST)
        --------------------------------------------------------- */
        $conversionData = DB::query()
            ->fromSub(function ($q) use ($branch_id, $entity_id, $countryIds, $isOnlyOthers) {

                // PRE SALE
                $q->from('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_countries', 'et_customer.country', '=', 'et_countries.id','left')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(p.transaction_date)
                                FROM et_payment p
                                WHERE p.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->select(
                        DB::raw('COALESCE(et_countries.id, 0) as source_id'),
                        DB::raw('COALESCE(et_countries.name, "Others") as source_name'),
                        DB::raw('YEAR(et_payment.transaction_date) as y'),
                        DB::raw('MONTH(et_payment.transaction_date) as m'),
                        DB::raw('DAY(et_payment.transaction_date) as d'),
                        DB::raw('COUNT(*) as conversion_count')
                    )
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', '>', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_lead.entity_id', $entity_id)
                    ->where(function ($q) use ($countryIds, $isOnlyOthers) {

                        if ($isOnlyOthers) {
                            // Only Others
                            $q->whereNull('et_countries.id')
                            ->orWhere('et_countries.id', 0);
                        } else {
                            // Normal + Others
                            $q->whereIn('et_countries.id', $countryIds)
                            ->orWhereNull('et_countries.id');
                        }

                    })
                    ->groupBy('source_id','source_name','y','m','d')

                // POST SALE
                ->unionAll(
                    DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_countries', 'et_customer.country', '=', 'et_countries.id','left')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function ($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(p.transaction_date)
                                    FROM et_payment p
                                    WHERE p.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->select(
                            DB::raw('COALESCE(et_countries.id, 0) as source_id'),
                            DB::raw('COALESCE(et_countries.name, "Others") as source_name'),
                            DB::raw('YEAR(et_payment.transaction_date) as y'),
                            DB::raw('MONTH(et_payment.transaction_date) as m'),
                            DB::raw('DAY(et_payment.transaction_date) as d'),
                            DB::raw('COUNT(*) as conversion_count')
                        )
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_customer.status', 0)
                        ->where('et_lead.created_by', '>', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branch_id)
                        ->where('et_lead.entity_id', $entity_id)
                        ->where(function ($q) use ($countryIds, $isOnlyOthers) {

                            if ($isOnlyOthers) {
                                // Only Others
                                $q->whereNull('et_countries.id')
                                ->orWhere('et_countries.id', 0);
                            } else {
                                // Normal + Others
                                $q->whereIn('et_countries.id', $countryIds)
                                ->orWhereNull('et_countries.id');
                            }

                        })
                        ->groupBy('source_id','source_name','y','m','d')
                );

            }, 'x')
            ->select(
                'source_id',
                'source_name',
                'y','m','d',
                DB::raw('SUM(conversion_count) as conversion_count')
            )
            ->groupBy('source_id','source_name','y','m','d')
            ->get();

        /* ---------------------------------------------------------
        | 4. MERGE DATA
        --------------------------------------------------------- */
        foreach ($leadData as $row) {
            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            $leadSources[$s]['source_name'] = $row->source_name;
            $leadSources[$s][$y][$m][$d]['lead_count'] = $row->lead_count;
            $leadSources[$s][$y][$m][$d]['conversion_count'] = 0;
        }

        foreach ($conversionData as $row) {
            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            if (!isset($leadSources[$s]['source_name'])) {
                $leadSources[$s]['source_name'] = $row->source_name;
            }

            if (!isset($leadSources[$s][$y][$m][$d]['lead_count'])) {
                $leadSources[$s][$y][$m][$d]['lead_count'] = 0;
            }

            $leadSources[$s][$y][$m][$d]['conversion_count'] = $row->conversion_count;
        }

        /* ---------------------------------------------------------
        | 5. SUMMARY
        --------------------------------------------------------- */
        foreach ($leadSources as $sourceId => $srcData) {

            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    // DAILY
                    foreach ($dData as $d => $v) {
                        $lead = $v['lead_count'];
                        $conv = $v['conversion_count'];

                        $daily[$sourceId][$y][$m][$d] = [
                            'lead_count' => $lead,
                            'conversion_count' => $conv,
                            'conversion_percentage' =>
                                ($lead > 0 ? round(($conv / $lead) * 100, 2) : 0)
                        ];
                    }

                    // MONTHLY
                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sourceId][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            ($monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0)
                    ];
                }

                // YEARLY
                $yearLead = 0;
                $yearConv = 0;

                foreach ($monthly[$sourceId][$y] as $m => $vals) {
                    $yearLead += $vals['lead_count'];
                    $yearConv += $vals['conversion_count'];
                }

                $yearly[$sourceId][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        ($yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0)
                ];
            }
        }

        /* ---------------------------------------------------------
        | FINAL RETURN
        --------------------------------------------------------- */
        return [
            "lead_source_list" => $countryList,
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly
        ];
    }

    private function generateNavHtml()
    {
        $menus =  [
            [
                'title' => 'Lead Vs Conversion',
                'url' => url('/manage_reports/country_wise_yearly_report'),
                'is_active' => request()->is([
                    'manage_reports/country_wise_yearly_report*',
                    'manage_reports/country_wise_monthly_report*'
                ]),
            ]
        ];

        /* -------- WIDTH BASED ON URL -------- */

        if (request()->is([
            'manage_reports/country_wise_yearly_report*',
            'manage_reports/country_wise_monthly_report*'
        ])) {
            $widthClass = 'w-50 ';
        }
        elseif (request()->is([
            
        ])) {
            $widthClass = 'w-100 ';
        }
        else {
            $widthClass = 'w-100 ';
        }

        /* ---------- AUTO WIDTH CALCULATION ---------- */

        $html = '<style>
        .scroll-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: #099DDA;
            border: none;
            padding: 10px 10px;
            cursor: pointer;
            z-index: 10;
            border-radius: 4px;
            display: none;
        }

        .scroll-btn.left {
            left: 0;
        }

        .scroll-btn.right {
            right: 0;
        }
        </style>
        <div class="'.$widthClass.'nav-align-top mb-2" id="nav_width_div"><div class="nav-align-top mb-2">';
        $html .= '<ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">';

        foreach ($menus as $menu) {

            $active = $menu['is_active'] ? 'active' : '';

            $html .= "<div class='item'><li class='nav-item'>
                    <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                        {$menu['title']}
                    </a>
                </li></div>
            ";
        }

        $html .= '</div><button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button></div></ul></div></div>';

        return $html;
    }
}
