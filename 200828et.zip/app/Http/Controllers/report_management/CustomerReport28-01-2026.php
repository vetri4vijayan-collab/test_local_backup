<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\LeadTypeModel;
use App\Models\LeadSourceModel;

class CustomerReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    // public function customer_drop()
    // {
    //     $months = [
    //         1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
    //         7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
    //     ];

    //     return view('content.report_management.customer_report.customer_drop_yearly_list', compact(
    //         'months'
    //     ))->with('report_heading', self::$report_heading);
    // }

    // public function CusDropYearlyData(Request $request)
    // {
    //     try {

    //         $months = [
    //             1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
    //             7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
    //         ];

    //         // $years = range(2022, date('Y'));

    //         $user = $request->user();
    //         $user_id = $user->user_id;
    //         $branch_id = $user->branch_id;

    //         $currentMonth = date('n');
    //         $currentYear = date('Y');

    //         // Get lead years
    //         $leadYears = DB::table('za_training')
    //                 ->where('za_training.branch_id', $branch_id)
    //                 // ->where('za_training.customer_id', $cust_data->sno)
    //                 ->select(DB::raw('YEAR(za_training.created_at) as year'))
    //                 ->where('za_training.status', 0)
    //                 ->distinct()
    //                 ->pluck('year');

    //         // Get conversion years
    //         $conversionYears = DB::table('za_drop_refund')
    //                         ->select(
    //                             DB::raw('YEAR(za_drop_refund.created_at) as year')
    //                         )
    //                         ->where([
    //                             ['za_drop_refund.type', '=', 0],
    //                             ['za_drop_refund.bh_status', '=', 1],
    //                             ['za_drop_refund.status', '=', 0],
    //                             ['za_drop_refund.branch_id', '=', $branch_id],
    //                             // ['za_drop_refund.training_id', '=', $pre_training->sno],
    //                             // ['za_drop_refund.customer_id', '=', $pre_training->customer_id],
    //                             // ['za_drop_refund.course_id', '=', $pre_training->course_id],
    //                         ])->distinct()->pluck('year');
            
                            
    //                         // Combine and get unique years
    //         $allYears = $leadYears->merge($conversionYears)->unique()->sort()->values();
            
    //         $out_Years = $allYears->sort()->values()->toArray();
            
    //         $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            
    //         $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
    //         $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)
            
    //         $year_string = $firstYear.$lastYear;
            
    //         $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
    //         // Push previousYear if not already in the list
    //         if (!empty($yearList) && !$yearList->contains($previousYear)) {
    //             $yearList->push($previousYear);
    //         }
            
    //         // Sort and reset keys
    //         $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];

            
    //         $years = $allYears->toArray();
            
    //         $cust = DB::table('za_customer')
    //             ->select('za_customer.*')
    //             ->whereIn('za_customer.status', [0, 6])
    //             ->where('za_customer.branch_id', $branch_id)
    //             ->get();

    //         $customerData_count_details = [];

    //         $customerData = [];   // [year][month] => customer count
    //         $dropData     = [];   // [year][month] => drop count
    //         $yearlyCustomers = []; // [year] => total customers
    //         $yearlyDrops     = []; // [year] => total drops

    //         // Drop reasons
    //         $dropReasons = ['Price', 'Service', 'Competitor', 'Product Issue', 'Other'];
    //         $dropReasonData = []; // [reason][year][month] => count

    //         // 1️⃣ Populate per-year, per-month data

    //         if (!$cust->isEmpty()) {
                    
    //             foreach ($finalYears as $year_num) {

    //                 foreach ($cust as $cust_data) {

    //                         $training_data = DB::table('za_training')
    //                                         ->select(
    //                                             'za_training.tesbo_check',
    //                                             'za_training.customer_id',
    //                                             DB::raw("
    //                                                 GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
    //                                                     ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
    //                                             "),
    //                                             DB::raw("
    //                                                 GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
    //                                                     ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
    //                                             "),
    //                                             DB::raw("
    //                                                 GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
    //                                                     ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
    //                                             "),
    //                                             DB::raw("
    //                                                 GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
    //                                                     ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
    //                                             "),
    //                                             DB::raw('MONTH(za_training.created_at) as train_month')
    //                                         )
    //                                         ->where('za_training.branch_id', $branch_id)
    //                                         ->where('za_training.tesbo_check','!=',1)
    //                                         ->whereYear('za_training.created_at', $year_num)
    //                                         ->where('za_training.customer_id', $cust_data->sno)
    //                                         ->groupBy('za_training.tesbo_check','za_training.customer_id','za_training.training_id', DB::raw('MONTH(za_training.created_at)'))
    //                                         ->get();


    //                     foreach ($training_data as $training) {

    //                         $train_month = $training->train_month ?? date('n');

    //                         $active_training_ids = isset($training->active_training_ids) && !empty($training->active_training_ids) && is_string($training->active_training_ids) ? explode(',',$training->active_training_ids) : [];
    //                         $drop_training_ids = isset($training->drop_training_ids) && !empty($training->drop_training_ids) && is_string($training->drop_training_ids) ? explode(',',$training->drop_training_ids) : [];

    //                         $active_course_ids = isset($training->active_course_ids) && !empty($training->active_course_ids) && is_string($training->active_course_ids) ? explode(',',$training->active_course_ids) : [];
    //                         $drop_course_ids = isset($training->drop_course_ids) && !empty($training->drop_course_ids) && is_string($training->drop_course_ids) ? explode(',',$training->drop_course_ids) : [];

    //                         if(!empty($active_training_ids)){
    //                             $customerData_count_details[$year_num][$train_month]['cust_count'] = ($customerData_count_details[$year_num][$train_month]['cust_count'] ?? 0) + 1;
                                
    //                         }

    //                         // ✅ Fetch drop data
    //                         $drop_data = DB::table('za_drop_refund')
    //                             ->select(
    //                                 DB::raw('MONTH(za_drop_refund.created_at) as drop_month')
    //                             )
    //                             ->where([
    //                                 ['za_drop_refund.type', '=', 0],
    //                                 ['za_drop_refund.bh_status', '=', 1],
    //                                 ['za_drop_refund.status', '=', 0],
    //                                 ['za_drop_refund.branch_id', '=', $branch_id],
    //                                 ['za_drop_refund.customer_id', '=',$cust_data->sno],
    //                             ])
    //                             ->whereYear('za_drop_refund.created_at', $year_num)
    //                             ->whereIn('za_drop_refund.training_id', $drop_training_ids)
    //                             ->whereIn('za_drop_refund.course_id', $drop_course_ids)
    //                             ->get();

    //                         foreach ($drop_data as $drop) {
                                
    //                             $drop_month = $drop->drop_month ?? $train_month;

    //                             $customerData_count_details[$year_num][$drop_month]['drop_cust_count'] =
    //                                 ($customerData_count_details[$year_num][$drop_month]['drop_cust_count'] ?? 0) + 1;
    //                         }
    //                     }
    //                 }
    //             }
    //         }

    //         foreach ($finalYears as $year_index => $year) {

    //             if($year_index != 0){
    //                 $yearlyCustomers[$year] = 0;
    //                 $yearlyDrops[$year] = 0;
    //             }

    //             foreach ($months as $monthNum => $monthName) {

    //                 $customers = isset($customerData_count_details[$year][$monthNum]['cust_count']) && !empty($customerData_count_details[$year][$monthNum]['cust_count']) ? $customerData_count_details[$year][$monthNum]['cust_count']: 0;
    //                 $drops = isset($customerData_count_details[$year][$monthNum]['drop_cust_count']) && !empty($customerData_count_details[$year][$monthNum]['drop_cust_count']) ? $customerData_count_details[$year][$monthNum]['drop_cust_count']: 0;
    //                 // $drops = min($drops, $customers);

    //                 $customerData[$year][$monthNum] = $customers;
    //                 $dropData[$year][$monthNum]     = $drops;

    //                 if($year_index != 0){
    //                     $yearlyCustomers[$year] += $customers;
    //                     $yearlyDrops[$year]     += $drops;
    //                 }
                    
    //                 // Generate reason-wise drop counts (sum ≤ total drops)
    //                 // $remainingDrops = $drops;
    //                 // foreach ($dropReasons as $reason) {
    //                 //     if ($reason === end($dropReasons)) {
    //                 //         $dropReasonData[$reason][$year][$monthNum] = $remainingDrops;
    //                 //     } else {
    //                 //         $val = rand(0, $remainingDrops);
    //                 //         $dropReasonData[$reason][$year][$monthNum] = $val;
    //                 //         $remainingDrops -= $val;
    //                 //     }
    //                 // }
    //             }
    //         }

    //         // 2️⃣ Calculate month totals across all years
    //         $monthTotals = []; // [month] => ['customers'=>0,'drops'=>0]
    //         foreach ($months as $monthNum => $monthName) {

    //             $monthTotals[$monthNum]['customers'] = 0;
    //             $monthTotals[$monthNum]['drops']     = 0;

    //             foreach ($finalYears as $year_index => $year) {
    //                 if($year_index != 0){
    //                     $monthTotals[$monthNum]['customers'] += $customerData[$year][$monthNum] ?? 0;
    //                     $monthTotals[$monthNum]['drops']     += $dropData[$year][$monthNum] ?? 0;
    //                 }
    //             }
    //         }

    //         // 3️⃣ Calculate drop percentages per year per month
    //         $dropPercent = [];
    //         foreach ($finalYears as $year_index => $year) {

    //             foreach ($months as $monthNum => $monthName) {

    //                 $customers = $customerData[$year][$monthNum] ?? 0;
    //                 $drops     = $dropData[$year][$monthNum] ?? 0;

    //                 if($year_index != 0){

    //                     $drop_percent = ($customers > 0) ? round(($drops / $customers) * 100, 1) : 0;
    //                     $dropPercent[$year][$monthNum] = ((int)$drop_percent > 100) ? 100 : (int)$drop_percent;
    //                 }
    //             }
    //         }

    //         $year_colors = $this->generateAttractiveColors($years);

    //         return response()->json([
    //             'months' => $months ?? null,
    //             'currentYear' => $currentYear ?? null,
    //             'currentMonth' => $currentMonth ?? null,
    //             'months' => $months ?? null,
    //             'years' => $years ?? null,
    //             'customerData' => $customerData ?? null,
    //             'dropData' => $dropData ?? null,
    //             'dropPercent' => $dropPercent ?? null,
    //             'yearlyCustomers' => $yearlyCustomers ?? null,
    //             'yearlyDrops' => $yearlyDrops ?? null,
    //             'dropReasons' => $dropReasons ?? null,
    //             'dropReasonData' => $dropReasonData ?? null,
    //             'year_string' => !empty($year_string) ? $year_string : null,
    //             'year_colors' => !empty($year_colors) ? $year_colors : null,
    //             'monthTotals' => $monthTotals ?? null
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'message' => 'Failed to load leads data.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    // public function cus_drop_monthly(Request $request)
    // {
    //     $days = range(1,31);
    //     $year = date('Y');
    //     $yearShort = date('y');

    //     return view('content.report_management.customer_report.customer_drop_list', compact('days','year','yearShort'))->with('report_heading', self::$report_heading);
    // }

    // public function CusDropMonthlyData(Request $request)
    // {
    //     try {

    //         $inputYear = $request->year;
    
    //         if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
    //             $filter_year = $inputYear . '-01-01';
    //         } else {
    //             $filter_year = now()->format('Y-01-01');
    //         }

    //         $year  = date('Y',strtotime($filter_year));
    //         $pre_year  = (int)$year - 1;
    //         $currentYear  = date('Y');
    //         $currentMonth = date('n');
    //         $currentDay   = date('j');

    //         $months = $this->getYearBasedMonths($year);

    //         $user = $request->user();
    //         $user_id = $user->user_id;
    //         $branch_id = $user->branch_id;

    //         $cust = DB::table('za_customer')
    //             ->select('za_customer.*')
    //             ->whereIn('za_customer.status', [0, 6])
    //             ->where('za_customer.branch_id', $branch_id)
    //             ->get();

    //         $customerData_count_details = [];

    //         $customerData_drop_count_details = [];

    //         $customerData_count_details[$currentMonth][$currentDay] = [
    //             'cust_count' => 0,
    //             'drop_cust_count' => 0
    //         ];
            
    //         $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);
    //         $pre_customerData_count_details = [];

    //         $pre_customerData_count_details[12][$pre_daysInMonth] = [
    //             'cust_count' => 0,
    //             'drop_cust_count' => 0
    //         ];


    //         $customerData = [];
    //         $customerTrendData = [];
    //         $dropTrendData = [];
    //         $pre_customerData = [];
    //         $dropData = [];
    //         $pre_dropData = [];
    //         $dropPercent = [];
    //         $monthTotals = [];
    //         $grandTotals = [
    //             'customers' => [],
    //             'drops'     => [],
    //         ];

    //         $dropReasonData = [];
    //         $dropReasons = [];

    //         if (!$cust->isEmpty()) {
                
    //             foreach ($cust as $cust_data) {
                    
    //                 $training_data = DB::table('za_training')
    //                                     ->select(
    //                                         'za_training.tesbo_check',
    //                                         'za_training.customer_id',
    //                                         DB::raw("
    //                                             GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
    //                                                 ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
    //                                         "),
    //                                         DB::raw("
    //                                             GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
    //                                                 ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
    //                                         "),
    //                                         DB::raw("
    //                                             GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
    //                                                 ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
    //                                         "),
    //                                         DB::raw("
    //                                             GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
    //                                                 ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
    //                                         "),
    //                                         DB::raw('MONTH(za_training.created_at) as train_month'),
    //                                         DB::raw('DAY(za_training.created_at) as train_day')
    //                                     )
    //                                     ->where('za_training.branch_id', $branch_id)
    //                                     ->whereYear('za_training.created_at', $year)
    //                                     ->where('za_training.customer_id', $cust_data->sno)
    //                                     ->where('za_training.tesbo_check','!=',1)
    //                                     ->groupBy(
    //                                         'za_training.tesbo_check',
    //                                         'za_training.customer_id',
    //                                         'za_training.training_id',
    //                                         DB::raw('MONTH(za_training.created_at)'),
    //                                         DB::raw('DAY(za_training.created_at)')
    //                                     )
    //                                     ->get();

    //                 foreach ($training_data as $training) {

    //                     $train_month = $training->train_month ?? date('n');
    //                     $train_day = $training->train_day ?? date('j');
                        
    //                     $active_training_ids = isset($training->active_training_ids) && !empty($training->active_training_ids) && is_string($training->active_training_ids) ? explode(',',$training->active_training_ids) : [];
    //                     $drop_training_ids = isset($training->drop_training_ids) && !empty($training->drop_training_ids) && is_string($training->drop_training_ids) ? explode(',',$training->drop_training_ids) : [];

    //                     $active_course_ids = isset($training->active_course_ids) && !empty($training->active_course_ids) && is_string($training->active_course_ids) ? explode(',',$training->active_course_ids) : [];
    //                     $drop_course_ids = isset($training->drop_course_ids) && !empty($training->drop_course_ids) && is_string($training->drop_course_ids) ? explode(',',$training->drop_course_ids) : [];

    //                     if(!empty($active_training_ids)){
    //                         // ✅ Count customers (or training sessions) per day
    //                         $customerData_count_details[$train_month][$train_day]['cust_count'] = 
    //                             ($customerData_count_details[$train_month][$train_day]['cust_count'] ?? 0) + 1;
    //                     }

    //                     // $customerData_drop_count_details[$cust_data->sno] = $training;

    //                     // $customerData_count_details[$train_month][$train_day][] = $training;

    //                     // ✅ Fetch drop data
    //                     $drop_data = DB::table('za_drop_refund')
    //                         ->select(
    //                             'za_drop_refund.*',
    //                             DB::raw('MONTH(za_drop_refund.created_at) as drop_month'),
    //                             DB::raw('DAY(za_drop_refund.created_at) as drop_day')
    //                         )
    //                         ->where([
    //                             ['za_drop_refund.type', '=', 0],
    //                             ['za_drop_refund.bh_status', '=', 1],
    //                             ['za_drop_refund.status', '=', 0],
    //                             ['za_drop_refund.branch_id', '=', $branch_id],
    //                             ['za_drop_refund.customer_id', '=', $cust_data->sno],
    //                         ])
    //                         ->whereYear('za_drop_refund.created_at', $year)
    //                         ->whereIn('za_drop_refund.training_id', $drop_training_ids)
    //                         ->whereIn('za_drop_refund.course_id', $drop_course_ids)
    //                         ->get();
                        

    //                     foreach ($drop_data as $drop) {
                            
    //                         $drop_month = $drop->drop_month ?? 0;
    //                         $drop_day = $drop->drop_day ?? 0;

    //                         // $drop_refund_reason = $drop->drop_refund_reason ?? 'others';
                            
    //                         // $key = $this->slugify($drop_refund_reason);

    //                         // $dropReasonData[$key][$drop_month][$drop_day] = ($dropReasonData[$key][$drop_month][$drop_day] ?? 0) + 1;

    //                         // $dropReasons[$key] = $drop_refund_reason;

                            
    //                         $customerData_count_details[$drop_month][$drop_day]['drop_cust_count'] =
    //                             ($customerData_count_details[$drop_month][$drop_day]['drop_cust_count'] ?? 0) + 1;
    //                     }
    //                 }

    //                 $pre_training_data = DB::table('za_training')
    //                     ->select(
    //                         'za_training.tesbo_check',
    //                         'za_training.customer_id',
    //                         DB::raw("
    //                             GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
    //                                 ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
    //                         "),
    //                         DB::raw("
    //                             GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
    //                                 ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
    //                         "),
    //                         DB::raw("
    //                             GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
    //                                 ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
    //                         "),
    //                         DB::raw("
    //                             GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
    //                                 ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
    //                         "),
    //                         DB::raw('MONTH(za_training.created_at) as train_month'),
    //                         DB::raw('DAY(za_training.created_at) as train_day')
    //                     )
    //                     ->where('za_training.branch_id', $branch_id)
    //                     // ->where('za_training.status', 0)
    //                     ->whereYear('za_training.created_at', $pre_year)
    //                     ->whereMonth('za_training.created_at', 12)
    //                     ->whereDay('za_training.created_at', $pre_daysInMonth)
    //                     ->where('za_training.customer_id', $cust_data->sno)
    //                     ->where('za_training.tesbo_check','!=',1)
    //                     ->groupBy(
    //                         'za_training.tesbo_check','za_training.customer_id','za_training.training_id', DB::raw('MONTH(za_training.created_at)'),DB::raw('DAY(za_training.created_at)')
    //                     )
    //                     ->get();

    //                 foreach ($pre_training_data as $pre_training) {

    //                     $pre_train_month = $pre_training->train_month ?? date('n');
    //                     $pre_train_day = $pre_training->train_day ?? date('j');

    //                     $pre_active_training_ids = isset($pre_training->active_training_ids) && !empty($pre_training->active_training_ids) && is_string($pre_training->active_training_ids) ? explode(',',$pre_training->active_training_ids) : [];
    //                     $pre_drop_training_ids = isset($pre_training->drop_training_ids) && !empty($pre_training->drop_training_ids) && is_string($pre_training->drop_training_ids) ? explode(',',$pre_training->drop_training_ids) : [];

    //                     $pre_active_course_ids = isset($pre_training->active_course_ids) && !empty($pre_training->active_course_ids) && is_string($pre_training->active_course_ids) ? explode(',',$pre_training->active_course_ids) : [];
    //                     $pre_drop_course_ids = isset($pre_training->drop_course_ids) && !empty($pre_training->drop_course_ids) && is_string($pre_training->drop_course_ids) ? explode(',',$pre_training->drop_course_ids) : [];

    //                     if(!empty($pre_active_training_ids)){
    //                         // ✅ Count customers (or training sessions) per day
    //                         $pre_customerData_count_details[$pre_train_month][$pre_train_day]['cust_count'] = 
    //                             ($pre_customerData_count_details[$pre_train_month][$pre_train_day]['cust_count'] ?? 0) + 1;
    //                     }

    //                     // ✅ Fetch drop data
    //                     $pre_drop_data = DB::table('za_drop_refund')
    //                         ->select(
    //                             DB::raw('MONTH(za_drop_refund.created_at) as drop_month'),
    //                             DB::raw('DAY(za_drop_refund.created_at) as drop_day')
    //                         )
    //                         ->where([
    //                             ['za_drop_refund.type', '=', 0],
    //                             ['za_drop_refund.bh_status', '=', 1],
    //                             ['za_drop_refund.status', '=', 0],
    //                             ['za_drop_refund.branch_id', '=', $branch_id],
    //                             ['za_drop_refund.customer_id', '=', $pre_training->customer_id]
    //                         ])
    //                         ->whereYear('za_drop_refund.created_at', $pre_year)
    //                         ->whereMonth('za_drop_refund.created_at', 12)
    //                         ->whereDay('za_drop_refund.created_at', $pre_daysInMonth)
    //                         ->whereIn('za_drop_refund.training_id', $pre_drop_training_ids)
    //                         ->whereIn('za_drop_refund.course_id', $pre_drop_course_ids)
    //                         ->get();

    //                     foreach ($pre_drop_data as $pre_drop) {
                            
    //                         $pre_drop_month = $pre_drop->drop_month ?? $train_month;
    //                         $pre_drop_day = $pre_drop->drop_day ?? $train_day;

    //                         $pre_customerData_count_details[$pre_drop_month][$pre_drop_day]['drop_cust_count'] =
    //                             ($pre_customerData_count_details[$pre_drop_month][$pre_drop_day]['drop_cust_count'] ?? 0) + 1;
    //                     }
    //                 }
    //             }

    //             // return $customerData_drop_count_details;
    //         }
            
    //         foreach ($months as $monthNum => $monthName) {

    //             $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);
                
    //             for ($day = 1; $day <= 31; $day++) {
                    
    //                 $date_format = date('d-m-Y',strtotime($day.'-'.$monthNum.'-'.$year));

    //                 if (($monthNum == $currentMonth && $day > $currentDay) || $day > $daysInMonth) {
    //                     $customers = 0;
    //                     $drops = 0;
    //                 } else {
    //                     $customers = isset($customerData_count_details[$monthNum][$day]['cust_count']) && !empty($customerData_count_details[$monthNum][$day]['cust_count']) ? $customerData_count_details[$monthNum][$day]['cust_count']: 0;
    //                     $drops = isset($customerData_count_details[$monthNum][$day]['drop_cust_count']) && !empty($customerData_count_details[$monthNum][$day]['drop_cust_count']) ? $customerData_count_details[$monthNum][$day]['drop_cust_count']: 0;
    //                     // $drops = min($drops, $customers);
    //                 }
                    
    //                 $customerData[$monthNum][$day] = $customers;
    //                 $customerTrendData[$monthName][] = ['date'=>$date_format,'customer'=>$customers];
                    
    //                 $pre_customerData[12][$pre_daysInMonth] = isset($pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']) && !empty($pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']) ? $pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']: 0;

    //                 $dropData[$monthNum][$day] = $drops;
    //                 $dropTrendData[$monthName][] = ['date'=>$date_format,'drop'=>$drops];
                    
    //                 $pre_dropData[12][$pre_daysInMonth] = isset($pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']) && !empty($pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']) ? $pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']: 0;
                    
    //                 $drop_percent = ($customers > 0) ? round(($drops / $customers) * 100, 1) : 0;
    //                 $dropPercent[$monthNum][$day] = ((int)$drop_percent > 100) ? 100 : (int)$drop_percent;
                    
    //                 $monthTotals[$monthNum]['customers'] = ($monthTotals[$monthNum]['customers'] ?? 0) + $customers;
    //                 $monthTotals[$monthNum]['drops'] = ($monthTotals[$monthNum]['drops'] ?? 0) + $drops;

    //                 $grandTotals['customers'][$day] = ($grandTotals['customers'][$day] ?? 0) + $customers;
    //                 $grandTotals['drops'][$day] = ($grandTotals['drops'][$day] ?? 0) + $drops;
    //             }
    //         }
            
    //         $reasonColors = $this->generateLeadSourceAttractiveColors($dropReasons);
            
    //         // foreach ($months as $monthNum => $monthName) {
    //         //     $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);
    //         //     foreach ($dropReasons as $reason) {
    //         //         for ($day = 1; $day <= $daysInMonth; $day++) {
    //         //             $dropCount = DB::table('za_drop_refund')
    //         //                         ->select('za_drop_refund.sno')
    //         //                         ->where([
    //         //                             ['za_drop_refund.type', '=', 0],
    //         //                             ['za_drop_refund.bh_status', '=', 1],
    //         //                             ['za_drop_refund.status', '=', 0],
    //         //                             ['za_drop_refund.branch_id', '=', $branch_id]
    //         //                             // ['za_drop_refund.training_id', '=', $training->sno],
    //         //                             // ['za_drop_refund.customer_id', '=', $training->customer_id],
    //         //                             // ['za_drop_refund.course_id', '=', $training->course_id],
    //         //                         ])
    //         //                         ->whereYear('za_drop_refund.created_at', $year)
    //         //                         ->where('za_drop_refund.drop_refund_reason', 'LIKE', "%{$reason}%")
    //         //                         ->whereMonth('za_drop_refund.created_at', $monthNum)
    //         //                         ->whereDay('za_drop_refund.created_at', $day)
    //         //                         ->count();
    //         //             $dropReasonData[$reason][$monthNum][$day] = $dropCount ?? 0;
    //         //         }
    //         //     }
    //         // }

    //         return response()->json([
    //             'months' => $months ?? null,
    //             'year' => $year ?? null,
    //             'currentYear' => $currentYear ?? null,
    //             'currentMonth' => $currentMonth ?? null,
    //             'currentDay' => $currentDay ?? null,
    //             'customerData' => $customerData ?? null,
    //             'dropData' => $dropData ?? null,
    //             'pre_customerData' => $pre_customerData ?? null,
    //             'pre_dropData' => $pre_dropData ?? null,
    //             'dropPercent' => $dropPercent ?? null,
    //             'monthTotals' => $monthTotals ?? null,
    //             'customerTrendData' => $customerTrendData ?? null,
    //             'dropTrendData' => $dropTrendData ?? null,
    //             'grandTotals' => $grandTotals ?? null,
    //             'dropReasons' => $dropReasons ?? null,
    //             'dropReasonData' => $dropReasonData ?? null,
    //             'reasonColors' => $reasonColors ?? null
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'message' => 'Failed to load leads data.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    public function cus_src_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.customer_report.customer_src_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusSrcYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            $sortedLeadSource = DB::table('et_lead_source')
                    ->select('sno', 'lead_source_name')
                    ->where('status', '!=', 2)
                    ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                        $q->whereIn('sno', $search_lead_src_fill);
                    })->orderBy('lead_source_name', 'asc')
                    ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_source_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = (int)$year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id_new][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id_new][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($months as $monthNum => $monthName) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$monthNum] = ($source_totals > 0) ? round(($data[$lead_source_id][$monthNum][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_src_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.customer_report.customer_src_list', [
            'days','currentMonth', 'currentYear','months'
        ])->with('report_heading', self::$report_heading);
    }

    public function CusSrcMonthlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $Month_name      = date('F', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $sortedLeadSource = DB::table('et_lead_source')
                    ->select('sno', 'lead_source_name')
                    ->where('status', '!=', 2)
                    ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                        $q->whereIn('sno', $search_lead_src_fill);
                    })->orderBy('lead_source_name', 'asc')
                    ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_source_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                // return $lead_source_id_new;

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id_new][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id_new][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($days as $day) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$day] = ($source_totals > 0) ? round(($data[$lead_source_id][$day][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'Month_name' => $Month_name,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.cus_age_gen_yearly_list', compact(
            'months',
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->GetCustGenderDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'male_count' => 'Male',
                'female_count' => 'Female',
                'others_count' => 'Others',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$year][$monthNum][$type_key]) ? $monthlyData[$year][$monthNum][$type_key] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                // $percentages[$year] = ($monthly_data[$year]['conversion_percentage'] ?? 0);

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_monthly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        return view('content.report_management.customer_report.cus_age_gen_list', compact(
            'months',
            'days',
            'yearShort'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetCustGenderDetails($branch_id);

            // return ['result' => $result];

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            
            $types_list = [
                'male_count' => 'Male',
                'female_count' => 'Female',
                'others_count' => 'Others',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $increment_data  = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($monthlyData) && !empty($monthlyData) ? $monthlyData : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($dailyData[$year][$monthNum][$day][$type_key]) ? round($dailyData[$year][$monthNum][$day][$type_key]) : 0;
                        } else {
                            $amount = 0;
                        }

                        $pre_amount = isset($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) ? round($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // $percentages[$monthNum] = ($monthly_data[$year][$monthNum]['conversion_percentage'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'increment_data' => $increment_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.customer_report.customer_type_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustTypeDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;
            
            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            $sortedLeadSource = DB::table('et_lead_type')
                                ->select('sno', 'lead_type_name')
                                ->where('status', '!=', 2)
                                ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                                    $q->whereIn('sno', $search_lead_src_fill);
                                })->orderBy('lead_type_name', 'asc')
                                ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_type_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = (int)$year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id_new][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id_new][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($months as $monthNum => $monthName) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$monthNum] = ($source_totals > 0) ? round(($data[$lead_source_id][$monthNum][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.customer_report.customer_type_list', compact(
            'days','currentMonth', 'currentYear','months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeMonthlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $Month_name      = date('F', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustTypeDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $sortedLeadSource = DB::table('et_lead_type')
                                ->select('sno', 'lead_type_name')
                                ->where('status', '!=', 2)
                                ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                                    $q->whereIn('sno', $search_lead_src_fill);
                                })->orderBy('lead_type_name', 'asc')
                                ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_type_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                // return $lead_source_id_new;

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id_new][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id_new][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($days as $day) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$day] = ($source_totals > 0) ? round(($data[$lead_source_id][$day][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'Month_name' => $Month_name,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function GetCustTypeDetails($branch_id, $search_lead_src_fill = [])
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];
        // $leadSourceList = [];

        /* ------------------------------------
        * 1. Lead Sources List (ASC order)
        * ------------------------------------ */
        $leadSource_list = DB::table('et_lead_type')
        ->select('sno', 'lead_type_name as source_name')
        ->where('status', '!=', 2)
        ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
            $q->whereIn('sno', $search_lead_src_fill);
        })
        ->get();

        // Ensure alphabetical sorting A → Z
        $sortedLeadSource = $leadSource_list->sortBy(function ($item) {
            return strtolower($item->source_name);
        });

        // Final arrays
        $leadSourceListIds = $sortedLeadSource->pluck('sno')->toArray();
        $leadSourceList    = $sortedLeadSource->pluck('source_name', 'sno')->toArray();

        /* ---------------------------------------------------------
        | 1. LEAD DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->select(
                'et_lead_type.sno as source_id',
                'et_lead_type.lead_type_name as source_name',
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->whereIn('et_lead_type.sno', $leadSourceListIds)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | 2. CONVERSION DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $conversionData = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->select(
                'et_lead_type.sno as source_id',
                'et_lead_type.lead_type_name as source_name',
                DB::raw('DAY(et_payment.transaction_date) as d'),
                DB::raw('MONTH(et_payment.transaction_date) as m'),
                DB::raw('YEAR(et_payment.transaction_date) as y'),
                DB::raw('COUNT(et_customer.sno) as conversion_count')
            )
            ->where('et_transaction.payment_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereIn('et_lead_type.sno', $leadSourceListIds)
            ->where('et_lead.created_by', '>', 0)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | Merge both LEAD + CONVERSION
        --------------------------------------------------------- */
        foreach ($leadData as $row) {

            // build lead source list
            // $leadSourceList[$row->source_id] = [
            //     "source_id" => $row->source_id,
            //     "source_name" => $row->source_name
            // ];

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            $leadSources[$s]['source_name'] = $row->source_name;
            $leadSources[$s][$y][$m][$d]['lead_count'] = $row->lead_count;
            $leadSources[$s][$y][$m][$d]['conversion_count'] = 0;
        }

        foreach ($conversionData as $row) {

            // ensure lead source exists
            // if (!isset($leadSourceList[$row->source_id])) {
            //     $leadSourceList[$row->source_id] = [
            //         "source_id" => $row->source_id,
            //         "source_name" => $row->source_name
            //     ];
            // }

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            if (!isset($leadSources[$s]['source_name'])) {
                $leadSources[$s]['source_name'] = $row->source_name;
            }

            if (!isset($leadSources[$s][$y][$m][$d]['lead_count'])) {
                $leadSources[$s][$y][$m][$d]['lead_count'] = 0;
            }

            $leadSources[$s][$y][$m][$d]['conversion_count'] = $row->conversion_count;
        }


        /* ---------------------------------------------------------
        | DAILY / MONTHLY / YEARLY summary
        --------------------------------------------------------- */
        foreach ($leadSources as $sourceId => $srcData) {

            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    // DAILY
                    foreach ($dData as $d => $v) {

                        $lead = $v['lead_count'];
                        $conv = $v['conversion_count'];

                        $daily[$sourceId][$y][$m][$d] = [
                            'lead_count' => $lead,
                            'conversion_count' => $conv,
                            'conversion_percentage' =>
                                ($lead > 0 ? round(($conv / $lead) * 100, 2) : 0)
                        ];
                    }

                    // MONTHLY
                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sourceId][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            ($monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0)
                    ];
                }

                // YEARLY
                $yearLead = 0;
                $yearConv = 0;

                foreach ($monthly[$sourceId][$y] as $m => $vals) {
                    $yearLead += $vals['lead_count'];
                    $yearConv += $vals['conversion_count'];
                }

                $yearly[$sourceId][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        ($yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0)
                ];
            }
        }


        /* ---------------------------------------------------------
        | FINAL RETURN
        --------------------------------------------------------- */
        return [
            "lead_type_list" => $leadSourceList, // clean list
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly
        ];
    }

    public function GetCustSourceDetails($branch_id, $search_lead_src_fill = [])
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];
        // $leadSourceList = [];

        /* ------------------------------------
        * 1. Lead Sources List (ASC order)
        * ------------------------------------ */
        $leadSource_list = DB::table('et_lead_source')
        ->select('sno', 'lead_source_name as source_name')
        ->where('status', '!=', 2)
        ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
            $q->whereIn('sno', $search_lead_src_fill);
        })
        ->get();

        // Ensure alphabetical sorting A → Z
        $sortedLeadSource = $leadSource_list->sortBy(function ($item) {
            return strtolower($item->source_name);
        });

        // Final arrays
        $leadSourceListIds = $sortedLeadSource->pluck('sno')->toArray();
        $leadSourceList    = $sortedLeadSource->pluck('source_name', 'sno')->toArray();

        /* ---------------------------------------------------------
        | 1. LEAD DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->select(
                'et_lead_source.sno as source_id',
                'et_lead_source.lead_source_name as source_name',
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->whereIn('et_lead_source.sno', $leadSourceListIds)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | 2. CONVERSION DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $conversionData = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->select(
                'et_lead_source.sno as source_id',
                'et_lead_source.lead_source_name as source_name',
                DB::raw('DAY(et_payment.transaction_date) as d'),
                DB::raw('MONTH(et_payment.transaction_date) as m'),
                DB::raw('YEAR(et_payment.transaction_date) as y'),
                DB::raw('COUNT(et_customer.sno) as conversion_count')
            )
            ->where('et_transaction.payment_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereIn('et_lead_source.sno', $leadSourceListIds)
            ->where('et_lead.created_by', '>', 0)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | Merge both LEAD + CONVERSION
        --------------------------------------------------------- */
        foreach ($leadData as $row) {

            // build lead source list
            // $leadSourceList[$row->source_id] = [
            //     "source_id" => $row->source_id,
            //     "source_name" => $row->source_name
            // ];

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            $leadSources[$s]['source_name'] = $row->source_name;
            $leadSources[$s][$y][$m][$d]['lead_count'] = $row->lead_count;
            $leadSources[$s][$y][$m][$d]['conversion_count'] = 0;
        }

        foreach ($conversionData as $row) {

            // ensure lead source exists
            // if (!isset($leadSourceList[$row->source_id])) {
            //     $leadSourceList[$row->source_id] = [
            //         "source_id" => $row->source_id,
            //         "source_name" => $row->source_name
            //     ];
            // }

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            if (!isset($leadSources[$s]['source_name'])) {
                $leadSources[$s]['source_name'] = $row->source_name;
            }

            if (!isset($leadSources[$s][$y][$m][$d]['lead_count'])) {
                $leadSources[$s][$y][$m][$d]['lead_count'] = 0;
            }

            $leadSources[$s][$y][$m][$d]['conversion_count'] = $row->conversion_count;
        }


        /* ---------------------------------------------------------
        | DAILY / MONTHLY / YEARLY summary
        --------------------------------------------------------- */
        foreach ($leadSources as $sourceId => $srcData) {

            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    // DAILY
                    foreach ($dData as $d => $v) {

                        $lead = $v['lead_count'];
                        $conv = $v['conversion_count'];

                        $daily[$sourceId][$y][$m][$d] = [
                            'lead_count' => $lead,
                            'conversion_count' => $conv,
                            'conversion_percentage' =>
                                ($lead > 0 ? round(($conv / $lead) * 100, 2) : 0)
                        ];
                    }

                    // MONTHLY
                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sourceId][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            ($monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0)
                    ];
                }

                // YEARLY
                $yearLead = 0;
                $yearConv = 0;

                foreach ($monthly[$sourceId][$y] as $m => $vals) {
                    $yearLead += $vals['lead_count'];
                    $yearConv += $vals['conversion_count'];
                }

                $yearly[$sourceId][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        ($yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0)
                ];
            }
        }


        /* ---------------------------------------------------------
        | FINAL RETURN
        --------------------------------------------------------- */
        return [
            "lead_source_list" => $leadSourceList, // clean list
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly
        ];
    }

    private function GetCustGenderDetails($branch_id)
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $daily = [];
        $monthly = [];
        $yearly = [];
        $yearsList = [];

        /* ---------------------------------------------------------
        | 1. FETCH CUSTOMER (NO LEAD-SOURCE CONDITION)
        --------------------------------------------------------- */
        $genderData = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->select(
                'et_lead.lead_gender as gender',
                DB::raw('DAY(et_payment.transaction_date) as d'),
                DB::raw('MONTH(et_payment.transaction_date) as m'),
                DB::raw('YEAR(et_payment.transaction_date) as y'),
                DB::raw('COUNT(et_customer.sno) as gender_count')
            )
            ->where('et_transaction.payment_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>', 0)
            ->groupBy('gender', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | 2. NORMALIZE GENDER → male_count / female_count / others_count
        --------------------------------------------------------- */
        $keyMap = [
            1 => 'male_count',
            2 => 'female_count',
            3 => 'others_count',
            '' => 'unknown_count',
            null => 'unknown_count'
        ];

        foreach ($genderData as $row) {

            $key = $keyMap[$row->gender] ?? 'unknown_count';

            $y = $row->y;
            $m = $row->m;
            $d = $row->d;
            $count = isset($row->gender_count) && !empty($row->gender_count) ? (int) $row->gender_count : 0;

            /* Track year */
            if (!in_array($y, $yearsList)) {
                $yearsList[] = $y;
            }

            /* -------------------------------
            | DAILY  →  [$y][$m][$d][$key]
            ------------------------------- */
            if (!isset($daily[$y][$m][$d][$key])) $daily[$y][$m][$d][$key] = 0;
            $daily[$y][$m][$d][$key] = $count;

            /* -------------------------------
            | MONTHLY → [$y][$m][$key]
            ------------------------------- */
            if (!isset($monthly[$y][$m][$key])) $monthly[$y][$m][$key] = 0;
            $monthly[$y][$m][$key] += $count;

            /* -------------------------------
            | YEARLY → [$y][$key]
            ------------------------------- */
            if (!isset($yearly[$y][$key])) $yearly[$y][$key] = 0;
            $yearly[$y][$key] += $count;
        
        }

        return [
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly,
            "years"  => $yearsList
        ];
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    public function get_lead_type_list()
    {
        $LeadTypeModelList = LeadTypeModel::where('status', '!=', 2)->orderBy('lead_type_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    private function generateLeadSourceAttractiveColorsNew($leadTypesMapped, $baseHue = 200)
    {
        $colors = [];
        if (!empty($leadTypesMapped)) {
            foreach ($leadTypesMapped as $slotType => $slots) {
                // Ensure valid data
                if (!is_array($slots) || empty($slots)) {
                    continue;
                }
                $count = count($slots);
                $i = 0;
                foreach ($slots as $slug => $label) {
                    $hue = ($baseHue + $i * (360 / $count)) % 360;
                    // Assign color to slug within its slotType
                    $colors[$slotType][$slug] = "hsl({$hue}, 65%, 55%)";

                    $i++;
                }
            }
        }
        return $colors;
    }
}