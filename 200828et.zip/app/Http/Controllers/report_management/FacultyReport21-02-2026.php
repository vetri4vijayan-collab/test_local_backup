<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;
use App\Models\BatchModel;
use App\Models\JobpositionModel;

class FacultyReport extends Controller
{
    public static $report_heading = 'Analysis';

    public function index()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.faculty_report.faculty_yearly_list', compact(
            'currentMonth', 'currentYear','months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $query = JobpositionModel::where('department_id', 2)->where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'job_position_name')->orderBy('job_position_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_position_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['staff_count']) ? (int) $paymentSums[$year][$monthNum]['staff_count'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$leadType] = $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                    }else if((int)$monthNum != 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth]['staff_count'] : 0;

                    $preleadData[$prevMonth][$leadType] = $pre_count;

                    // $monthTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$lastMonth][$leadType]) ? (int) $leadData[$lastMonth][$leadType] : 0;
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.faculty_report.faculty_monthly_list', compact(
            'days','currentMonth', 'currentYear','months'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = JobpositionModel::where('department_id', 2)->where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'job_position_name')->orderBy('job_position_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_position_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['staff_count']) ? (int) $paymentSums[$year][$Month][$day]['staff_count'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$leadType] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count'] : 0;

                    $preleadData[$prevDay][$leadType] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$daysInMonth][$leadType]) ? (int) $leadData[$daysInMonth][$leadType] : 0;
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    // public function faculty_revenue_yearly()
    // {
    //     $currentMonth = date('n'); // 1-12
    //     $currentYear = date('Y');

    //     $months = $this->getYearBasedMonths($currentYear);
    //     $short_months = $this->getYearBasedMonths($currentYear,2);

    //     return view('content.report_management.faculty_report.faculty_revenue_yr_list', compact(
    //         'months','short_months'
    //     ))->with('report_heading', self::$report_heading);
    // }

    // public function FacultyRevenueYearData(Request $request)
    // {
    //     try {

    //         $selected_year = $request->year;
    //         $search_lead_src_fill = $request->search_lead_src_fill ?? null;
    //         $is_existing_val = (int)$request->is_existing_val ?? 2;

    //         if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
    //             $filterDate = $selected_year . '-01-01';
    //         } else {
    //             $filterDate = now()->format('Y-01-01');
    //         }

    //         $year = date('Y', strtotime($filterDate));
    //         $yearShort = date('y', strtotime($filterDate));
    //         $querycurrentMonth = date('m', strtotime($filterDate));
    //         $Month = date('n', strtotime($filterDate));

    //         $months = $this->getYearBasedMonths($year);
    //         $short_months = $this->getYearBasedMonths($year,2);

    //         $today = date('d');
    //         $today_month = date('n');
    //         $today_year = date('Y');

    //         $user = $request->user(); // Fetch user details only once
    //         $user_id = $user->user_id;
    //         $branch_id = $user->branch_id;

    //         $result = $this->GetFacultyRevenueDetails($branch_id,$search_lead_src_fill,$is_existing_val);

    //         if ($result === null) {
    //             return response()->json(['error' => 'Failed to get data'], 500);
    //         }

    //         // return $result;

    //         $currentDate  = date('Y-m-d');
    //         $currentYear  = (int) date('Y');
    //         $currentMonth = (int) date('n');
            
    //         $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

    //         // Sort by staff_name
    //         uasort($leadTypesMapped, function($a, $b) {
    //             return strcmp($a['staff_name'], $b['staff_name']);
    //         });

    //         $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

    //             $keep = true;

    //             // --- DOJ (Date of Joining) filter ---
    //             if (!empty($staff['doj'])) {

    //                 $dojDate  = strtotime($staff['doj']);
    //                 $dojYear  = (int) date('Y', $dojDate);
    //                 $dojMonth = (int) date('n', $dojDate);

    //                 // Exclude staff who joined after the selected year-month
    //                 if ($dojYear > (int)$year) {
    //                     $keep = false;
    //                 }
    //             }

    //             // --- Exit filter ---
    //             if ($staff['exist_status'] && !empty($staff['exist_date'])) {

    //                 $exitDate  = strtotime($staff['exist_date']);
    //                 $exitYear  = (int) date('Y', $exitDate);
    //                 $exitMonth = (int) date('n', $exitDate);

    //                 // Exclude staff whose exit date is before the selected year-month
    //                 if ($exitYear < (int)$year) {
    //                     $keep = false;
    //                 }
    //             }

    //             return $keep;
    //         });

    //         $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

    //         $currentMonth = date('n');
    //         $currentYear = date('Y');
    //         $currentDay = date('j');

    //         $leadData = [];
    //         $preleadData = [];
    //         $percentages = [];
    //         $sourceTotals = [];
    //         $monthTotals = [];
    //         $dayLabels = [];
    //         $dayNames = [];
    //         $grandTotalAll = 0;

    //         $exit_staff_details = [];
    //         $exit_staff_doj_details = [];
    //         $exit_status_staffs = [];

    //         $days = range(1, 31);

    //         $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

    //         // return $leadTypesMapped;

    //         foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
    //             $dayTotal = 0;

    //             foreach ($months as $monthNum => $monthName) {
                    
    //                 $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;
    //                 // ---------- Exit Staff Tracking ----------
    //                 $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
    //                 $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

    //                 if ($exist_status && $exist_date) {

    //                     $exist_y = (int) date('Y', strtotime($exist_date));
    //                     $exist_m = (int) date('n', strtotime($exist_date));
    //                     $exist_d = (int) date('j', strtotime($exist_date));

    //                     // If exit is before selected month/year → mark as inactive
    //                     if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$monthNum)) {
    //                         $exist_status = false;
    //                     }
    //                     // If same month but exited before current month → inactive for remaining days
    //                     elseif ($exist_y === (int)$year && $exist_m > (int)$monthNum) {
    //                         $exist_status = false;
    //                     }

    //                     $exit_staff_details[$monthNum][$lead_type_id] = [
    //                         'exist_status' => $exist_status,
    //                         'exist_date'   => $exist_date
    //                     ];

    //                     $exit_status_staffs[$lead_type_id] = $exist_status;
    //                 }

    //                 $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

    //                 $count = isset($paymentSums[$year][$monthNum]['earned_amount']) ? $paymentSums[$year][$monthNum]['earned_amount'] : 0;
    //                 $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;
                    
    //                 // $count = rand(5, 50); // Replace with DB query
    //                 $leadData[$monthNum][$lead_type_id] = $count;
    //                 $percentages[$lead_type_id][$monthNum] = $earned_per;
                    
    //                 $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

    //                 $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

    //                 $prevMonth = 0;
    //                 $prevYear = 0;

    //                 if ((int)$monthNum == 1) {
    //                     $prevYear = (int)$year - 1;
    //                     $prevMonth = 12;
    //                 }else if((int)$monthNum != 1){
    //                     $prevYear = (int)$year;
    //                     $prevMonth = (int)$monthNum - 1;
    //                 }
                    
    //                 $pre_count = isset($paymentSums[$prevYear][$prevMonth]['earned_amount']) ? $paymentSums[$prevYear][$prevMonth]['earned_amount'] : 0;

    //                 $preleadData[$prevMonth][$lead_type_id] = $pre_count;

    //                 // $monthTotals[$day] = $dayTotal;

    //                 // ---------- DOJ (Date of Joining) Logic ----------
    //                 $doj_status = false;

    //                 if ($doj) {

    //                     $doj_y = (int) date('Y', strtotime($doj));
    //                     $doj_m = (int) date('n', strtotime($doj));

    //                     // Case 1: DOJ is this year
    //                     if ($doj_y === (int)$year) {
    //                         if ((int)$monthNum >= $doj_m) {
    //                             $doj_status = true;
    //                         }
    //                     }

    //                     // Case 2: DOJ is before this year → always true
    //                     elseif ($doj_y < $year) {
    //                         $doj_status = true;
    //                     }

    //                     // Case 3: DOJ is after this year → always false
    //                     else {
    //                         $doj_status = false;
    //                     }
    //                 }

    //                 $exit_staff_doj_details[$monthNum][$lead_type_id] = [
    //                     'doj_status' => $doj_status,
    //                 ];
    //             }
                
                
    //             $grandTotalAll += $dayTotal;
                
    //             // Calculate percentages
    //         }
            
    //         // Prepare source-wise day trends for JS
    //         $sourceTrends = [];
    //         foreach ($leadTypesMapped as $lead_type_id => $leadType) {
    //             $trend = [];
    //             foreach ($months as $monthNum => $monthName) {
    //                 $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
    //             }
    //             $sourceTrends[$lead_type_id] = $trend;
    //         }

    //         $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
    //         $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

    //         return response()->json([
    //             'days' => $days,
    //             'months' => $months,
    //             'short_months' => $short_months,
    //             'dayLabels' => $dayLabels,
    //             'leadTypes' => $leadTypes_list,
    //             'staff_details' => $leadTypesMapped,
    //             'leadData' => $leadData,
    //             'preleadData' => $preleadData,
    //             'percentages' => $percentages,
    //             'sourceTotals' => $sourceTotals,
    //             'exit_staff_details' => $exit_staff_details,
    //             'exit_status_staffs' => $exit_status_staffs,
    //             'exit_staff_doj_details' => $exit_staff_doj_details,
    //             'monthTotals' => $monthTotals,
    //             'grandTotalAll' => $grandTotalAll,
    //             'currentMonth' => (int)$currentMonth,
    //             'currentYear' => (int)$currentYear,
    //             'currentDay' => (int)$currentDay,
    //             'Month' => (int)$Month,
    //             'dayNames' => $dayNames,
    //             'sourceTrends' => $sourceTrends,
    //             'year' => (int)$year,
    //             'yearShort' => (int)$yearShort,
    //             'line_MonthColors' => $line_MonthColors,
    //             'pie_MonthColors' => $pie_MonthColors
    //         ]);

    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'message' => 'Failed to load Faculty data.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    // public function faculty_revenue_monthly()
    // {
    //     $days = range(1, 31);

    //     $months = [
    //         1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
    //         7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
    //     ];

    //     return view('content.report_management.faculty_report.faculty_revenue_month_list', compact(
    //         'months','days'
    //     ))->with('report_heading', self::$report_heading);
    // }

    // public function FacultyRevenueMonthData(Request $request)
    // {
    //     try {
            
    //         $selected_year = $request->year;
    //         $selected_month = $request->month;
    //         $search_lead_src_fill = $request->search_lead_src_fill ?? null;
    //         $is_existing_val = (int)$request->is_existing_val ?? 2;

    //         if (
    //             $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
    //             $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
    //         ) {
    //             $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
    //             $filterDate = $selected_year . '-' . $monthFormatted . '-01';
    //         } else {
    //             $filterDate = now()->format('Y-m-01');
    //         }

    //         $year = date('Y', strtotime($filterDate));
    //         $yearShort = date('y', strtotime($filterDate));
    //         $querycurrentMonth = date('m', strtotime($filterDate));
    //         $Month = date('n', strtotime($filterDate));
    //         $today = date('d');
    //         $today_month = date('n');
    //         $today_year = date('Y');

    //         $user = $request->user(); // Fetch user details only once
    //         $user_id = $user->user_id;
    //         $branch_id = $user->branch_id;

    //         $result = $this->GetFacultyRevenueDetails($branch_id,$search_lead_src_fill,$is_existing_val);

    //         if ($result === null) {
    //             return response()->json(['error' => 'Failed to get data'], 500);
    //         }

    //         // return $result;

    //         $currentDate  = date('Y-m-d');
    //         $currentYear  = (int) date('Y');
    //         $currentMonth = (int) date('n');
            
    //         $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

    //         // Sort by staff_name
    //         uasort($leadTypesMapped, function($a, $b) {
    //             return strcmp($a['staff_name'], $b['staff_name']);
    //         });

    //         $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

    //             $keep = true;

    //             // --- DOJ (Date of Joining) filter ---
    //             if (!empty($staff['doj'])) {

    //                 $dojDate  = strtotime($staff['doj']);
    //                 $dojYear  = (int) date('Y', $dojDate);
    //                 $dojMonth = (int) date('n', $dojDate);

    //                 // Exclude staff who joined after the selected year-month
    //                 if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
    //                     $keep = false;
    //                 }
    //             }

    //             // --- Exit filter ---
    //             if ($staff['exist_status'] && !empty($staff['exist_date'])) {

    //                 $exitDate  = strtotime($staff['exist_date']);
    //                 $exitYear  = (int) date('Y', $exitDate);
    //                 $exitMonth = (int) date('n', $exitDate);

    //                 // Exclude staff whose exit date is before the selected year-month
    //                 if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
    //                     $keep = false;
    //                 }
    //             }

    //             return $keep;
    //         });

    //         $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

    //         $currentMonth = date('n');
    //         $currentYear = date('Y');
    //         $currentDay = date('j');

    //         $leadData = [];
    //         $preleadData = [];
    //         $percentages = [];
    //         $sourceTotals = [];
    //         $monthTotals = [];
    //         $dayLabels = [];
    //         $dayNames = [];
    //         $grandTotalAll = 0;

    //         $exit_staff_details = [];
    //         $exit_staff_doj_details = [];
    //         $exit_status_staffs = [];

    //         $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

    //         if($today_year == $year && $today_month == $Month){
    //             $daysInMonth = (int)$today;
    //         }
            
    //         $days = range(1, $daysInMonth);

    //         $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

    //         // return $leadTypesMapped;

    //         foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
    //             $dayTotal = 0;

    //             foreach ($days as $day) {

    //                 $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

    //                 // ---------- Exit Staff Tracking ----------
    //                 $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
    //                 $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

    //                 if ($exist_status && $exist_date) {

    //                     $exist_y = (int) date('Y', strtotime($exist_date));
    //                     $exist_m = (int) date('n', strtotime($exist_date));
    //                     $exist_d = (int) date('j', strtotime($exist_date));

    //                     // If exit is before selected month/year → mark as inactive
    //                     if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
    //                         $exist_status = false;
    //                     }
    //                     // If same month but exited before current day → inactive for remaining days
    //                     elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
    //                         $exist_status = false;
    //                     }

    //                     $exit_staff_details[$day][$lead_type_id] = [
    //                         'exist_status' => $exist_status,
    //                         'exist_date'   => $exist_date
    //                     ];

    //                     $exit_status_staffs[$lead_type_id] = $exist_status;
    //                 }
                    
    //                 $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

    //                 $count = isset($paymentSums[$year][$Month][$day]['earned_amount']) ? $paymentSums[$year][$Month][$day]['earned_amount'] : 0;
    //                 // $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;
                    
    //                 // $count = rand(5, 50); // Replace with DB query
    //                 $leadData[$day][$lead_type_id] = $count;
    //                 // $percentages[$lead_type_id][$monthNum] = $earned_per;
                    
    //                 $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

    //                 $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

    //                 $prevMonth = 0;
    //                 $prevYear = 0;
    //                 $prevDay = 0;

    //                 if ((int)$Month == 1 && $day == 1) {
    //                     $prevYear = (int)$year - 1;
    //                     $prevMonth = 12;
    //                     $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
    //                 }else if($day == 1){
    //                     $prevYear = (int)$year;
    //                     $prevMonth = (int)$Month - 1;
    //                     $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
    //                 }
                    
    //                 $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['earned_amount']) ? $paymentSums[$prevYear][$prevMonth][$prevDay]['earned_amount'] : 0;

    //                 $preleadData[$prevDay][$lead_type_id] = $pre_count;

    //                 // ---------- DOJ (Date of Joining) Logic ----------
    //                 $doj_status = false;

    //                 if ($doj) {

    //                     $doj_y = (int) date('Y', strtotime($doj));
    //                     $doj_m = (int) date('n', strtotime($doj));
    //                     $doj_d = (int) date('j', strtotime($doj));

    //                     // Case 1: DOJ is this year
    //                     if ($doj_y === (int)$year) {

    //                         // Same month
    //                         if ((int)$Month === $doj_m) {
    //                             if ($day >= $doj_d) {
    //                                 $doj_status = true;
    //                             }
    //                         }

    //                         // Month after DOJ month (still same year)
    //                         elseif ((int)$Month > $doj_m) {
    //                             $doj_status = true;
    //                         }

    //                         // Month before DOJ month → false
    //                         else {
    //                             $doj_status = false;
    //                         }
    //                     }

    //                     // Case 2: DOJ is before this year → always true
    //                     elseif ($doj_y < $year) {
    //                         $doj_status = true;
    //                     }

    //                     // Case 3: DOJ is after this year → always false
    //                     else {
    //                         $doj_status = false;
    //                     }
    //                 }

    //                 $exit_staff_doj_details[$day][$lead_type_id] = [
    //                     'doj_status' => $doj_status,
    //                 ];

    //                 // $dayTotals[$day] = $dayTotal;
    //             }
                
                
    //             $grandTotalAll += $dayTotal;
                
    //             // Calculate percentages
    //         }
            
    //         // Prepare source-wise day trends for JS
    //         $sourceTrends = [];
    //         foreach ($leadTypesMapped as $lead_type_id => $leadType) {
    //             $trend = [];
    //             foreach ($days as $day) {
    //                 $trend[] = $leadData[$day][$lead_type_id] ?? 0;
    //             }
    //             $sourceTrends[$lead_type_id] = $trend;
    //         }

    //         $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
    //         $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

    //         return response()->json([
    //             'days' => $days,
    //             'dayLabels' => $dayLabels,
    //             'leadTypes' => $leadTypes_list,
    //             'leadData' => $leadData,
    //             'preleadData' => $preleadData,
    //             'percentages' => $percentages,
    //             'sourceTotals' => $sourceTotals,
    //             'dayTotals' => $dayTotals,
    //             'staff_details' => $leadTypesMapped,
    //             'grandTotalAll' => $grandTotalAll,
    //             'currentMonth' => (int)$currentMonth,
    //             'currentYear' => (int)$currentYear,
    //             'currentDay' => (int)$currentDay,
    //             'exit_staff_details' => $exit_staff_details,
    //             'exit_status_staffs' => $exit_status_staffs,
    //             'exit_staff_doj_details' => $exit_staff_doj_details,
    //             'Month' => (int)$Month,
    //             'dayNames' => $dayNames,
    //             'sourceTrends' => $sourceTrends,
    //             'year' => (int)$year,
    //             'yearShort' => (int)$yearShort,
    //             'line_MonthColors' => $line_MonthColors,
    //             'pie_MonthColors' => $pie_MonthColors
    //         ]);

    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'message' => 'Failed to load Faculty data.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }
    
    public function faculty_attendance_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.faculty_report.faculty_attendance_yr_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyAttYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = isset($request->is_existing_val) ? (int)$request->is_existing_val : 2;

            // Validate year
            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = (int) date('Y', strtotime($filterDate));
            $yearShort = (int) date('y', strtotime($filterDate));
            $querycurrentMonth = (int) date('m', strtotime($filterDate));
            $Month = (int) date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name alphabetically
            uasort($leadTypesMapped, function ($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $holiday_status_staffs = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            
            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                // ---------- Month Loop ----------
                foreach ($months as $monthNum => $monthName) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;
                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$monthNum)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current month → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m > (int)$monthNum) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$monthNum][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = $monthlyData[$lead_type_id] ?? [];
                    $count = $paymentSums[$year][$monthNum]['leave_abs_count'] ?? 0;

                    $earned_per = isset($paymentSums[$year][$monthNum]['present_percentage']) ? $paymentSums[$year][$monthNum]['present_percentage'] : 0;

                    $holiday_status = isset($paymentSums[$year][$monthNum]['holiday_status']) ? $paymentSums[$year][$monthNum]['holiday_status'] : false;

                    $leadData[$monthNum][$lead_type_id] = $count;
                    $percentages[$monthNum][$lead_type_id] = $earned_per;
                    $holiday_status_staffs[$monthNum][$lead_type_id] = $holiday_status;

                    $sourceTotals[$lead_type_id] = $yearlyData[$lead_type_id][$year]['leave_abs_count'] ?? 0;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    // Previous month calc
                    if ((int)$monthNum === 1) {
                        $prevYear = $year - 1;
                        $prevMonth = 12;
                    } else {
                        $prevYear = $year;
                        $prevMonth = (int)$monthNum - 1;
                    }

                    $pre_count = $paymentSums[$prevYear][$prevMonth]['leave_abs_count'] ?? 0;
                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {
                            if ((int)$monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];
                }

                $grandTotalAll += (int) ($sourceTotals[$lead_type_id] ?? 0);
            }

            // ---------- Prepare monthly trends for JS chart ----------
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'holiday_status_staffs' => $holiday_status_staffs,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => $currentMonth,
                'currentYear' => $currentYear,
                'currentDay' => (int) date('j'),
                'Month' => $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => $year,
                'yearShort' => $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_attendance_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.faculty_report.faculty_attendance_month_list', compact(
            'months','days'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyAttMonthData(Request $request)
    {
        try {
            
            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];
            
            
            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            
            $holiday_status_staffs = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $grandTotalAll = 0;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current day → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$day][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['leave_abs_count']) ? $paymentSums[$year][$Month][$day]['leave_abs_count'] : 0;
                    
                    $earned_per = isset($paymentSums[$year][$Month][$day]['present_percentage']) ? $paymentSums[$year][$Month][$day]['present_percentage'] : 0;

                    $holiday_status = isset($paymentSums[$year][$Month][$day]['holiday_status']) ? $paymentSums[$year][$Month][$day]['holiday_status'] : false;
                    
                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;
                    $percentages[$day][$lead_type_id] = $earned_per;
                    $holiday_status_staffs[$day][$lead_type_id] = $holiday_status;
                    
                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['leave_abs_count']) ? $paymentSums[$prevYear][$prevMonth][$prevDay]['leave_abs_count'] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));
                        $doj_d = (int) date('j', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {

                            // Same month
                            if ((int)$Month === $doj_m) {
                                if ($day >= $doj_d) {
                                    $doj_status = true;
                                }
                            }

                            // Month after DOJ month (still same year)
                            elseif ((int)$Month > $doj_m) {
                                $doj_status = true;
                            }

                            // Month before DOJ month → false
                            else {
                                $doj_status = false;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$day][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $dayTotals[$day] = $dayTotal;
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'staff_details' => $leadTypesMapped,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'holiday_status_staffs' => $holiday_status_staffs,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function GetFacultyDetails(int $branch_id, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            // --- Fetch job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            foreach ($job_positions as $position) {

                // --- Fetch staff under this position ---
                $staff_list = DB::table('et_staff')
                    ->where('branch_id', $branch_id)
                    ->where('position_role', $position->sno)
                    ->where(function($query) use ($currentYear, $currentMonth, $is_existing_val) {
                        if($is_existing_val == 2){
                            $query->where(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                ->whereYear('staff_last_date', '>=', $currentYear)
                                ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                        }else{
                            $query->where('status','!=',2);
                        }
                    })
                    ->orderBy('sno', 'desc')
                    ->get();

                // --- Loop staff for daily counts ---
                foreach ($staff_list as $staff) {
                    
                    if (empty($staff->date_of_joining)) continue;

                    $staffStart = date('Y-m-d', strtotime($staff->date_of_joining));

                    $staffEnd   = $currentDate;

                    $loopDate = $staffStart;

                    while ($loopDate <= $staffEnd) {

                        $y = (int) date('Y', strtotime($loopDate));
                        $m = (int) date('n', strtotime($loopDate));
                        $d = (int) date('j', strtotime($loopDate));

                        if (!isset($dailyData[$position->sno][$y][$m][$d])) {

                            $dailyData[$position->sno][$y][$m][$d] = [
                                'staff_count' => 0
                            ];
                        }

                        // --- Staff count ---
                        $dailyData[$position->sno][$y][$m][$d]['staff_count']++;
                        $years[$y] = $y;

                        $loopDate = date('Y-m-d', strtotime($loopDate . ' +1 day'));
                    }
                }
            }

            // --- Monthly aggregation including attendance ---
            foreach ($dailyData as $positionId => $yearsData) {
                foreach ($yearsData as $year => $months) {
                    foreach ($months as $month => $days) {
                        $lastDay = (int) date('t', strtotime("$year-$month-01"));
                        if ($year == $currentYear && $month == $currentMonth) {
                            $lastDay = (int) date('j', strtotime($currentDate));
                        }

                        $monthlyData[$positionId][$year][$month] = [
                            'staff_count' => $days[$lastDay]['staff_count'] ?? 0
                        ];
                    }
                }
            }

            // --- Yearly aggregation including attendance ---
            foreach ($monthlyData as $positionId => $yearsData) {

                foreach ($yearsData as $year => $months) {

                    $lastMonth = ($year == $currentYear)
                    ? $currentMonth
                    : max(array_keys($months));

                    $yearlyData[$positionId][$year] = [
                        'staff_count'          => $months[$lastMonth]['staff_count'] ?? 0
                    ];
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyDetails: " . $e->getMessage());
            return null;
        }
    }

    private function GetFacultyAttendanceDetails(int $branch_id,$search_lead_src_fill = null,int $is_existing_val = 2,int $year) 
    {
        try {
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details = [];
            $dailyData     = [];
            $monthlyData   = [];
            $yearlyData    = [];
            $years         = [];

            // Get months for given year
            $months = $this->getYearBasedMonths($year);

            // --- Fetch faculty job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Fetch faculty/staff list ---
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->whereIn('et_staff.position_role', $job_positionsIds);

            // Existing / active staff filter
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->where('et_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            // Get staff data
            $staff_list = $staff_query->orderBy('et_staff.staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);

            // --- Loop through each staff ---
            foreach ($staff_list as $staff) {

                $staffId = $staff->sno;

                $staff_details[$staffId] = [
                    'staff_name'      => $staff->staff_name ?? 'None',
                    'staff_position'  => (isset($staff->job_position_name) && !empty($staff->job_position_name)
                        ? $staff->job_position_name
                        : ($staff->role_name ?? 'None')),
                    'doj'             => $staff->date_of_joining ?? null,
                    'staff_full_name' => ($staff->staff_name ?? 'None') . ' (' . ($staff->role_name ?? 'None') . ')',
                    'exist_status'    => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date'      => match ($staff->status) {
                        4 => $staff->notice_end_date,
                        5 => $staff->updated_at,
                        6 => $staff->staff_last_date,
                        7 => $staff->updated_at,
                        default => null,
                    },
                ];

                $year_start = "$year-01-01";
                $year_end   = "$year-12-31";

                // --- Attendance Base Query ---
                $attBaseQuery = DB::table('et_staff_attendance')
                    ->where('branch_id', $branch_id)
                    ->where('staff_id', $staffId)
                    ->whereBetween('date', [$staff->date_of_joining ?? $year_start, $staff_details[$staffId]['exist_date'] ?? date('Y-m-d')]);

                // --- Yearly Data ---
                $yearQuery = clone $attBaseQuery;
                $yearQuery->whereBetween('date', [$year_start, $year_end]);

                $total_attendance = $yearQuery->count();
                $attTypeWise      = $yearQuery->select('attendance', DB::raw('COUNT(*) as count'))
                    ->groupBy('attendance')->pluck('count', 'attendance')->toArray();

                $present_count      = $attTypeWise['P'] ?? 0;
                $leave_abs_count    = ($attTypeWise['L'] ?? 0) + ($attTypeWise['A'] ?? 0);
                $present_percentage = $total_attendance > 0 ? round(($present_count / $total_attendance) * 100, 2) : 0;
                $holiday_status = isset($attTypeWise['HD']) && !empty($attTypeWise['HD']) ? true : false;

                $yearlyData[$staffId][$year] = [
                    'total_attendance'   => $total_attendance,
                    'att_type_wise'      => $attTypeWise,
                    'present_count'      => $present_count,
                    'leave_abs_count'    => $leave_abs_count,
                    'present_percentage' => $present_percentage,
                    'holiday_status' => $holiday_status,
                ];

                // --- Monthly & Daily Data (Optimized) ---
                foreach ($months as $monthNum => $monthName) {

                    $month_start = date('Y-m-01', strtotime("$year-$monthNum-01"));
                    $month_end   = date('Y-m-t', strtotime("$year-$monthNum-01"));

                    // 🔹 Fetch all attendance in one go for this month
                    $monthRecords = (clone $attBaseQuery)
                        ->whereBetween('date', [$month_start, $month_end])
                        ->select('date', 'attendance')
                        ->get();

                    // Group data by day
                    $dailyGrouped = $monthRecords->groupBy(function ($item) {
                        return date('j', strtotime($item->date)); // day number
                    });

                    // --- Monthly Aggregation ---
                    $total_attendance_m = $monthRecords->count();
                    $attTypeWise_m      = $monthRecords->groupBy('attendance')->map->count()->toArray();

                    $present_count_m      = $attTypeWise_m['P'] ?? 0;
                    $leave_abs_count_m    = ($attTypeWise_m['L'] ?? 0) + ($attTypeWise_m['A'] ?? 0);
                    $present_percentage_m = $total_attendance_m > 0 ? round(($present_count_m / $total_attendance_m) * 100, 1) : 0;
                    $holiday_status_m = isset($attTypeWise_m['HD']) && !empty($attTypeWise_m['HD']) ? true : false;

                    $monthlyData[$staffId][$year][$monthNum] = [
                        'total_attendance'   => $total_attendance_m,
                        'att_type_wise'      => $attTypeWise_m,
                        'present_count'      => $present_count_m,
                        'leave_abs_count'    => $leave_abs_count_m,
                        'present_percentage' => $present_percentage_m,
                        'holiday_status' => $holiday_status_m,
                    ];

                    // --- Daily Breakdown from grouped data ---
                    foreach ($dailyGrouped as $day => $records) {

                        $attTypeWise_d = $records->groupBy('attendance')->map->count()->toArray();

                        $total_attendance_d   = count($records);
                        $present_count_d      = $attTypeWise_d['P'] ?? 0;
                        $leave_abs_count_d    = ($attTypeWise_d['L'] ?? 0) + ($attTypeWise_d['A'] ?? 0);
                        $present_percentage_d = $total_attendance_d > 0 ? round(($present_count_d / $total_attendance_d) * 100, 2) : 0;
                        $holiday_status_d = isset($attTypeWise_d['HD']) && !empty($attTypeWise_d['HD']) ? true : false;

                        $dailyData[$staffId][$year][$monthNum][$day] = [
                            'total_attendance'   => $total_attendance_d,
                            'att_type_wise'      => $attTypeWise_d,
                            'present_count'      => $present_count_d,
                            'leave_abs_count'    => $leave_abs_count_d,
                            'present_percentage' => $present_percentage_d,
                            'holiday_status' => $holiday_status_d,
                        ];
                    }
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'        => $yearlyData,
                'monthly'       => $monthlyData,
                'daily'         => $dailyData,
                'staff_details' => $staff_details,
                'years'         => array_values(array_unique([$year])),
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyStudentsDetails: " . $e->getMessage());
            return null;
        }
    }

    // private function GetFacultyRevenueDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    // {
    //     try {

    //         if (!$branch_id) {
    //             throw new \InvalidArgumentException("Branch ID is required");
    //         }

    //         $currentDate  = date('Y-m-d');
    //         $currentYear  = (int) date('Y');
    //         $currentMonth = (int) date('n');

    //         $staff_details   = [];
    //         $dailyData   = [];
    //         $monthlyData = [];
    //         $yearlyData  = [];
    //         $years       = [];
            
    //         // --- Fetch faculty job positions ---
    //         $job_positions = DB::table('za_job_position')
    //             ->where('sub_department_id', 4)
    //             ->where('status', '!=', 2)
    //             ->get();

    //         $job_positionsIds = $job_positions->pluck('sno')->toArray();

    //         // --- Fetch faculty/staff list ---
    //         $staff_query = DB::table('za_staff')
    //             ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    //             ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    //             ->where('za_staff.branch_id', $branch_id)
    //             ->whereIn('za_staff.position_role', $job_positionsIds);

    //         // Existing / active staff filter
    //         if ($is_existing_val == 2) {
    //             $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
    //                 $query->where(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where('za_staff.status', 4)
    //                         ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
    //                         ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
    //                 })
    //                     ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                         $q->where('za_staff.status', 5)
    //                             ->whereYear('za_staff.updated_at', '>=', $currentYear)
    //                             ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
    //                     })
    //                     ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                         $q->where('za_staff.status', 6)
    //                             ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
    //                             ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
    //                     })
    //                     ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                         $q->where('za_staff.status', 7)
    //                             ->whereYear('za_staff.updated_at', '>=', $currentYear)
    //                             ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
    //                     })
    //                     ->orWhere('za_staff.status', 0);
    //             });
    //         } else {
    //             $staff_query->where('za_staff.status', '!=', 2);
    //         }

    //         // Search filter
    //         if (!empty($search_lead_src_fill)) {
    //             $staff_query->whereIn('za_staff.sno', $search_lead_src_fill);
    //         }

    //         // Get staff data
    //         $staff_list = $staff_query->orderBy('staff_name', 'asc')->get([
    //             'za_staff.*',
    //             'za_user_role.role_name',
    //             'za_job_position.job_position_name'
    //         ]);

    //         // --- Loop staff for daily counts ---
    //         foreach ($staff_list as $staff) {

    //             if(!isset($staff_details[$staff->sno])){
    //                 $staff_details[$staff->sno] = [];
    //             }

    //             $batchIds = DB::table('za_training')->where('branch_id', $branch_id)
    //             ->where('staff_id', $staff->sno)
    //             ->distinct()
    //             ->pluck('batch_id')
    //             ->toArray(); 

    //             $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array

    //             foreach ($batchIds as $batchId) {

    //                 // Fetch the batch details
    //                 $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
    //                     ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
    //                     ->where('za_batch.status','!=', 2)
    //                     ->find($batchId);
                
    //                 if ($batch) {

    //                     // Calculate the duration between start_time and end_time for the specific batch
    //                     $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
    //                     $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance
                
    //                     $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
    //                     $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch

    //                     // --- Fetch all attendance for all staff in one query ---
    //                     $attendances = DB::table('za_attendance')
    //                         ->where('batch_id', $batch->sno)
    //                         ->where('branch_id', $branch_id)
    //                         ->where('staff_id', $staff->sno)
    //                         ->whereDate('att_date', '<=', $currentDate)
    //                         ->where('attendance', 'P')
    //                         ->get();

    //                     // Attendance for this staff
    //                     if (!empty($attendances)) {

    //                         foreach ($attendances as $att) {

    //                             $attDate = date('Y-m-d', strtotime($att->att_date));

    //                             $y = (int) date('Y', strtotime($attDate));
    //                             $m = (int) date('n', strtotime($attDate));
    //                             $d = (int) date('j', strtotime($attDate));

    //                             // if ($attDate == $loopDate) {
    //                             if (!isset($dailyData[$staff->sno][$y][$m][$d])) {
    //                                 $dailyData[$staff->sno][$y][$m][$d] = [
    //                                     'earned_amount' => 0,
    //                                     'earned_per' => 0
    //                                 ];
    //                             }
    //                             if (!isset($monthlyData[$staff->sno][$y][$m])) {
    //                                 $monthlyData[$staff->sno][$y][$m] = [
    //                                     'earned_amount' => 0,
    //                                     'earned_per' => 0
    //                                 ];
    //                             }
    //                             if (!isset($yearlyData[$staff->sno][$y])) {
    //                                 $yearlyData[$staff->sno][$y] = [
    //                                     'earned_amount' => 0,
    //                                     'earned_per' => 0
    //                                 ];
    //                             }

    //                             $earnedAmountForAttendance = $att->per_hr_cost * $batchDurationInHours; // Use batch duration here
                                
    //                             $slary_amount = ($staff->basic_salary ?? 0) * 10;
                                
    //                             $earnedAmountForPer = 0;

    //                             if ($slary_amount != 0) {
    //                                 $earnedAmountForPer = ($earnedAmountForAttendance / $slary_amount) * 100;
    //                             }


    //                             $dailyData[$staff->sno][$y][$m][$d]['earned_amount'] += $earnedAmountForAttendance;
    //                             $monthlyData[$staff->sno][$y][$m]['earned_amount'] += $earnedAmountForAttendance;
    //                             $yearlyData[$staff->sno][$y]['earned_amount'] += $earnedAmountForAttendance;
    //                             $dailyData[$staff->sno][$y][$m][$d]['earned_per'] += $earnedAmountForPer;
    //                             $monthlyData[$staff->sno][$y][$m]['earned_per'] += $earnedAmountForPer;
    //                             $yearlyData[$staff->sno][$y]['earned_per'] += $earnedAmountForPer;

    //                         }
    //                     }
    //                 }
    //             }

    //             $staff_details[$staff->sno] = [
    //                 // 'staff_name' => $staff->staff_name ?? 'None',
    //                 // 'staff_position' => $position->job_position_name ?? 'None',
    //                 // 'staff_full_name' => $staff->staff_name.' ('.$position->job_position_name.')' ?? 'None',
    //                 'staff_name'      => $staff->staff_name ?? 'None',
    //                 'staff_position'  => (isset($staff->job_position_name) && !empty($staff->job_position_name)
    //                     ? $staff->job_position_name
    //                     : ($staff->role_name ?? 'None')),
    //                 'doj'             => $staff->date_of_joining ?? null,
    //                 'staff_full_name' => ($staff->staff_name ?? 'None') . ' (' . (isset($staff->job_position_name) && !empty($staff->job_position_name)
    //                     ? $staff->job_position_name
    //                     : ($staff->role_name ?? 'None')) . ')',
    //                 'exist_status'    => in_array($staff->status, [4, 5, 6, 7]),
    //                 'exist_date'      => match ($staff->status) {
    //                     4 => $staff->notice_end_date,
    //                     5 => $staff->updated_at,
    //                     6 => $staff->staff_last_date,
    //                     7 => $staff->updated_at,
    //                     default => null,
    //                 },
    //             ];
    //         }

    //         ksort($dailyData);
    //         ksort($monthlyData);
    //         ksort($yearlyData);

    //         return [
    //             'yearly'  => $yearlyData,
    //             'monthly' => $monthlyData,
    //             'daily'   => $dailyData,
    //             'staff_details'   => $staff_details,
    //             'years'   => array_values($years)
    //         ];

    //     } catch (\Exception $e) {
    //         \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
    //         return null;
    //     }
    // }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    public function get_faculty_positions_list()
    {
        $LeadTypeModelList = JobpositionModel::where('department_id', 2)
                                ->where('status', '!=', 2)
                                ->orderBy('job_position_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    public function getProductionStaffList(Request $request)
    {
        $currentDate = date('Y-m-d');
        $currentYear = (int) date('Y');
        $currentMonth = (int) date('n');

        $is_existing_val = (int) $request->checked_val ?? 2;

        $user = $request->user();
        $user_id = $user->user_id;
        $branch_id = $user->branch_id;

        $staff_details = [];

        $job_positions = DB::table('et_job_position')
            ->where('department_id', 2)
            ->where('status', '!=', 2)
            ->get();

        foreach ($job_positions as $position) {

            // --- Fetch staff under this position ---
            $staff_list = DB::table('et_staff')
                ->where('branch_id', $branch_id)
                ->where('position_role', $position->sno)
                // ->where('role_id', 22)
                // ->where('et_staff.status', 0)
                ->where(function ($query) use ($currentYear, $currentMonth, $is_existing_val) {
                    if ($is_existing_val == 2) {
                        $query->where(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                        })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                    ->whereYear('staff_last_date', '>=', $currentYear)
                                    ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                    } else {
                        $query->where('status', '!=', 2);
                    }
                })
                ->orderBy('staff_name', 'asc')
                ->get();

            $staff_list = $staff_list->unique('staff_id');

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $staff_details[$staff->sno] = [
                    'sno' => $staff->sno ?? 0,
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $position->job_position_name ?? 'None',
                    'staff_full_name' => $staff->staff_name . ' (' . $position->job_position_name . ')' ?? 'None',
                ];
            }
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => array_values($staff_details)
        ], 200);
    }
}
