<?php

namespace App\Http\Controllers\hr_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class JobRequest extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ? date('Y-m-d', strtotime($request->closing_date_filt)) : '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('status','!=',2);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('et_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('et_job_request.skill_required', 'LIKE', "%{$search_filter}%");
          });
      }
     
        if ($job_role_fill) {
          $jobRequest->where('et_job_request.job_role_name','LIKE', "%{$job_role_fill}%");
        }
        if ($closing_date_filt) {
          $jobRequest->where('et_job_request.closing_date', $closing_date_filt);
        }
        if ($exp_type_filt) {
          $jobRequest->whereJsonContains('et_job_request.exp_type_ids', $exp_type_filt);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('et_job_request.created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('et_job_request.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('et_job_request.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('et_job_request.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('et_job_request.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('et_job_request.created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'job_role_name' => $item->job_role_name ?? '-',
                  'min_salary' => $item->min_salary,
                  'max_salary' => $item->max_salary,
                  'vacancy_count' => $item->vacancy_count,
                  'experience' => $item->experience,
                  'experience' => $item->experience,
                  'closing_date' => $item->closing_date,
                  'skill_required' => $item->skill_required,
                  'exp_type_ids' => $item->exp_type_ids,
                  'item' => $item,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }

      return view('content.hr_management.job_request.job_request_list', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
  }
  
   public function SkillTagList()
  {
    $tags = DB::table('et_job_skill_tag')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $tags
    ], 200);
  }


  // Generate AI Skill Tags
    public function generateJobDescription (Request $request)
    {
        $jobRoleName = $request->input('job_role_name');
        $edit_id = $request->input('edit_id');

        // First try the fallback API
        $JobRequest = JobRequestModel::where('status','!=',2)
          ->where('job_role_name', $jobRoleName);
          if($edit_id){
          $JobRequest->where('sno','!=',$edit_id);
          }
          $JobRequest = $JobRequest->inRandomOrder()->first();
        $aiDescription = $JobRequest ? $JobRequest->job_description : '';
        // If fallback returns empty, use the main API
        if (empty($aiDescription)) {
            $aiDescription = $this->getAISecondFallBack($jobRoleName) ;
            if (empty($aiDescription)) {
                $aiDescription = $this->getAIDescriptionFromAPIFallBack($jobRoleName);
            }
        }
        
         

        return response()->json([
            'status' => 200,
            'data' => $aiDescription,
        ]);
    }


    public function Add(Request $request)
    {
         // --- VALIDATION ---
          $validator = Validator::make($request->all(), [
              'job_role_name' => 'required|max:255',
              'min_salary'    => 'required|numeric',
              'max_salary'    => 'required|numeric',
          ]);

          if ($validator->fails()) {
              return response([
                  'status'    => 400,
                  'message'   => 'Incorrect format input fields',
                  'error_msg' => $validator->errors(),
                  'data'      => null
              ], 400);
          }

           

            $job_role_name = $request->job_role_name;
            $exp_type = $request->exp_type ? json_encode($request->exp_type) : null;
            $experience_year = $request->experience_year ?? 0;
            $vacancy_count = $request->vacancy_count ?? 0;
            $closing_date = $request->closing_date ? date('Y-m-d', strtotime($request->closing_date)) : null;
            $min_salary = $request->min_salary;
            $max_salary = $request->max_salary;
            $skill_tag = $request->skill_KnowledgeTag ? json_encode($request->skill_KnowledgeTag) : null;
            $job_description = $request->job_description_generate ?? null;
            $branch_id = $request->user()->branch_id;
            $user_id = $request->user()->user_id;
            // Check if a job request already exists with the same job role name and closing date
            $chk = JobRequestModel::where('job_role_name', $job_role_name)
                ->where('closing_date', $closing_date)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                return response([
                    'status' => 401,
                    'message' => 'Job Request already exists!',
                    'error_msg' => 'Job Request with this role name and closing date already exists!',
                    'data' => null,
                ], 401);
            } else {
                // Generate job request ID
                $category_check = JobRequestModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = substr(date('y'), -2);
                    $job_request_id = 'JOBRQ-0001/' . $year;
                } else {
                    $data = $category_check->job_request_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $job_request_id = sprintf('JOBRQ-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                // Create a new job request entry
                $add_job_request = new JobRequestModel();
                $add_job_request->job_request_id = $job_request_id;
                $add_job_request->job_role_name = $job_role_name;
                $add_job_request->exp_type_ids = $exp_type;
                $add_job_request->experience = $experience_year;
                $add_job_request->min_salary = $min_salary;
                $add_job_request->max_salary = $max_salary;
                $add_job_request->closing_date = $closing_date;
                $add_job_request->skill_required = $skill_tag;
                $add_job_request->job_description = $job_description;
                $add_job_request->vacancy_count = $vacancy_count;
                $add_job_request->branch_id = $branch_id;
                $add_job_request->created_by = $user_id;
                $add_job_request->updated_by = $user_id;

                if ($add_job_request->save()) {

                    
                    $payload=[
                      'sno' => $add_job_request->sno,
                      'company_id' => 1,
                      'entity_id' => 1,
                      'branch_id' => $add_job_request->branch_id ==1 ? 6 :$add_job_request->branch_id,
                      'job_request_id' =>$add_job_request->job_request_id,
                      'job_role_name'    => $add_job_request->job_role_name,
                      'min_salary' => $add_job_request->min_salary ?? 0,
                      'max_salary' => $add_job_request->max_salary ?? 0,
                      'vacancy_count' => $add_job_request->vacancy_count,
                      'exp_type_ids' => $add_job_request->exp_type_ids,
                      'experience' => $add_job_request->experience,
                      'closing_date' => $add_job_request->closing_date,
                      'job_description' => $add_job_request->job_description,
                      'skill_required' => $add_job_request->skill_required,
                      
                    ];

                    $this->dispatchWebhooks($payload, 1 ,'Add_Job_Request_Hook');
      


                    return response([
                        'status' => 200,
                        'message' => 'Job Request created successfully.',
                        'error_msg' => null,
                        'data' => $add_job_request,
                    ], 200);
                } else {
                    return response([
                        'status' => 500,
                        'message' => 'Could not create Job Request.',
                        'error_msg' => 'There was an error while saving the Job Request.',
                        'data' => null,
                    ], 500);
                }
            }
        // }
    }


    
  public function Edit($id)
  {
    $role = JobRequestModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }

    public function Update(Request $request)
    {
      // return $request;
      $validator = Validator::make($request->all(), [
              'job_role_name' => 'required|max:255',
              'min_salary'    => 'required|numeric',
              'max_salary'    => 'required|numeric',

      ]);

      if ($validator->fails()) {
        return   response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg'     => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {

        $job_role_name = $request->job_role_name;
        $exp_type = $request->exp_type ? json_encode($request->exp_type) : null;
        $experience_year = $request->experience_year ?? 0;
        $vacancy_count = $request->vacancy_count ?? 0;
        $closing_date = $request->closing_date ? date('Y-m-d', strtotime($request->closing_date)) : null;
        $min_salary = $request->min_salary;
        $max_salary = $request->max_salary;
        $skill_tag = $request->skill_KnowledgeTag ? json_encode($request->skill_KnowledgeTag) : null;
        $job_description = $request->job_description_generate ?? null;
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        $edit_id       = $request->edit_id;

        $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $edit_id)->first();

        $chk = JobRequestModel::where('job_role_name', $job_role_name)
                ->where('closing_date', $closing_date)
                ->where('status', '!=', 2)
                ->where('sno', '!=', $edit_id)
                ->first();

        if ($chk) {
          return response([
              'status' => 400,
              'message' => 'Already Ledger is exist!',
              'error_msg' => 'Already Ledger is exist!',
              'data' => NULL,
          ], 400);
          
        } else {

          $upd_LedgerCategoryModel->job_role_name = $job_role_name;
          $upd_LedgerCategoryModel->exp_type_ids = $exp_type;
          $upd_LedgerCategoryModel->experience = $experience_year;
          $upd_LedgerCategoryModel->min_salary = $min_salary;
          $upd_LedgerCategoryModel->max_salary = $max_salary;
          $upd_LedgerCategoryModel->closing_date = $closing_date;
          $upd_LedgerCategoryModel->skill_required = $skill_tag;
          $upd_LedgerCategoryModel->job_description = $job_description;
          $upd_LedgerCategoryModel->vacancy_count = $vacancy_count;
          $upd_LedgerCategoryModel->updated_by = $user_id;
          $upd_LedgerCategoryModel->update();

          // return $upd_LedgerCategoryModel;

          if ($upd_LedgerCategoryModel) {
            // If category added successfully, return success response and display Toastr message
             $payload=[
                      'sno' => $upd_LedgerCategoryModel->sno,
                      'company_id' => 2,
                      'status' => 0,
                      'entity_id' => 2,
                      'branch_id' => $upd_LedgerCategoryModel->branch_id ==1 ? 6 :$upd_LedgerCategoryModel->branch_id,
                      'job_request_id' =>$upd_LedgerCategoryModel->job_request_id,
                      'job_role_name'    => $upd_LedgerCategoryModel->job_role_name,
                      'min_salary' => $upd_LedgerCategoryModel->min_salary ?? 0,
                      'max_salary' => $upd_LedgerCategoryModel->max_salary ?? 0,
                      'vacancy_count' => $upd_LedgerCategoryModel->vacancy_count,
                      'exp_type_ids' => $upd_LedgerCategoryModel->exp_type_ids,
                      'experience' => $upd_LedgerCategoryModel->experience,
                      'closing_date' => $upd_LedgerCategoryModel->closing_date,
                      'job_description' => $upd_LedgerCategoryModel->job_description,
                      'skill_required' => $upd_LedgerCategoryModel->skill_required,
                      
                    ];

                    $this->dispatchWebhooks($payload, 1 ,'Update_Job_Request_Hook');
      


                    return response([
                        'status' => 200,
                        'message' => 'Job Request Updated successfully.',
                        'error_msg' => null,
                        'data' => $upd_LedgerCategoryModel,
                    ], 200);
          } else {
            return response([
                        'status' => 400,
                        'message' => 'Could not update Job Request!',
                        'error_msg' => 'Could not update Job Request!',
                        'data' => NULL,
                    ], 400);
          }
        }
      }
      return redirect('settings/email_template');
    }


    public function Delete($id)
    {
      $upd_LedgerCategoryModel = JobRequestModel::where('sno', $id)->first();
      $upd_LedgerCategoryModel->status  = 2;
      $upd_LedgerCategoryModel->Update();

      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

    // private function getAIDescriptionFromAPIFallBack($jobRole)
    // {
    //         $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; // DeepSeek API
    //         $fallbackApiUrl = 'https://api.together.xyz/v1/chat/completions'; // LLaMA API

            
    //         $primaryApiKey = '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';  // Replace with your OpenRouter API key
    //         $fallbackApiKey = '616a73d21c4d1749a3671db5c9c42668afc783ccc76d7d5eb51f7defa03010b3';   // Replace with your Together AI API key

    //         // Define prompt
    //         $prompt = "
    //             Generate a full, detailed, professional Job Description in clean HTML format for the job role: '$jobRole'.

    //             Requirements:
    //             - Return ONLY HTML (no markdown, no explanations, no code blocks).
    //             - Use clean semantic tags (h2, h3, p, ul, li).
    //             - Content must look like a real corporate job description.
    //             - Include the following sections:
    //                 <h2>Job Title: [Job Role]</h2>
    //                 <h3>Job Overview</h3>
    //                 <p>...</p>

    //                 <h3>Key Responsibilities</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Required Skills & Competencies</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Qualifications</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Benefits</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Work Environment</h3>
    //                 <p>...</p>

    //             - Ensure text is well-formatted, readable, and professional.
    //             ";

    //         $maxTokens = 1000;

    //         // Primary API Request (DeepSeek)
    //         $response = Http::withHeaders([
    //             'Authorization' => "Bearer $primaryApiKey",
    //             'Content-Type' => 'application/json',
    //             "X-Title" => "JobDescriptionGenerator",
    //         ])->post($primaryApiUrl, [
    //             'model' => "tngtech/deepseek-r1t2-chimera:free",
    //             'messages' => [['role' => 'user', 'content' => $prompt]],
    //             'max_tokens' => $maxTokens, // Use the new, higher value
    //         ]);

    //         return $response->json();

    //         // Check if primary API failed
    //         if ($response->failed()) {
    //               // Use fallback API (Llama)
    //               $response = Http::withHeaders([
    //                   'Authorization' => "Bearer $primaryApiKey",
    //                   'Content-Type' => 'application/json',
    //                   "X-Title" => "JobDescriptionGenerator",
    //               ])->post($primaryApiUrl, [
    //                   'model' => "amazon/nova-2-lite-v1:free",
    //                   'messages' => [['role' => 'user', 'content' => $prompt]],
    //                   "reasoning"=> ["enabled"=> True],
    //                   'max_tokens' => $maxTokens, // Use the new, higher value
    //               ]);
                  
    //         }
          
    //         if ($response->successful()) {
    //             $responseData = $response->json();
                
    //             // This structure is common for OpenAI-compatible APIs (OpenRouter, Together AI)
    //             if (isset($responseData['choices'][0]['message']['content'])) {
    //                 $htmlDescription = $responseData['choices'][0]['message']['content'];
    //                 return $htmlDescription; 
    //             }
    //         }

    //         return '';
    // }

    private function getAIDescriptionFromAPIFallBack($jobRole)
    {
        $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 
        $primaryApiKey = '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'; 

      //   $prompt = "
      //     Generate a full, detailed, professional Job Description for the role: '$jobRole'.

      //     **CRITICAL OUTPUT INSTRUCTIONS (MUST BE FOLLOWED EXACTLY):**
      //     1. **Format:** Return only the raw HTML content fragment.
      //     2. **DO NOT** include any surrounding tags: `<html>`, `<head>`, `<body>`, `<div>`, ````json`, or ````html`.
      //     3. **Start:** Begin the output directly with a text/paragraph tag, such as: `<p>...` or `<p><strong style=\"color: rgb(34, 34, 34);\">...`.

      //     **Content Requirements:**
      //     - Use clean semantic HTML tags (`<h2>`, `<h3>`, `<h4>`, `<p>`, `<ul>`, `<li>`).
      //     - The content must look like a real corporate job description.
      //     - Include the following sections and fill them with professional content:
      //         <h3>Job Overview</h3><p>...</p>
      //         <h3>Key Responsibilities</h3><ul><li>...</li></li></ul>
      //         <h3>Required Skills & Competencies</h3><ul><li>...</li></ul>
      //         <h3>Qualifications</h3><ul><li>...</li></ul>
      //         <h3>Benefits</h3><ul><li>...</li></ul>
      //         <h3>Work Environment</h3><p>...</p>
      //     - Ensure text is well-formatted, readable, and professional.
      // ";

      $prompt = "
            Generate a complete, professional Job Description for the role: '$jobRole'.

            STRICT OUTPUT RULES (FOLLOW EXACTLY):
            1. Return ONLY clean HTML — no markdown, no code blocks, no ```html, no ```json, no <html>, <body>, or wrapper <div>.
            2. The HTML MUST be compact with minimal spacing:
              - NO blank lines.
              - NO extra'\n\n' spacing between tags.
            3. Each section must immediately follow the previous tag without empty lines.
            4. The output MUST start directly with: <p><strong>Role Name</strong></p>

            HTML STRUCTURE TO FOLLOW (NO EXTRA SPACES, NO BLANK LINES):
            <p><strong>React Developer</strong></p>
            <h3>Job Overview</h3>
            <p>...</p>
            <h3>Key Responsibilities</h3>
            <ul><li>...</li></ul>
            <h3>Required Skills & Competencies</h3>
            <ul><li>...</li></ul>
            <h3>Qualifications</h3>
            <ul><li>...</li></ul>

            CONTENT RULES:
            - Use corporate, professional tone.
            - Use clean semantic HTML only (<p>, <h3>, <ul>, <li>).
            - NO extra newlines, NO indentation, NO spacing between tags.
            - All content must be production-ready and visually tight when inserted into a WYSIWYG editor.

        ";
        $maxTokens = 1000;
        // Set a much longer timeout (e.g., 60 seconds) for the AI generation
        $aiTimeout = 60; 

        // Primary API Request (DeepSeek)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobDescriptionGenerator",
        ])->post($primaryApiUrl, [
            'model' => "tngtech/deepseek-r1t2-chimera:free",
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);

        // !! FIX 1: REMOVE THIS LINE !!
        // return $response->json(); 
        // This line caused your fallback logic to be completely skipped. 
        // The code should proceed to the 'if ($response->failed())' block.

        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Amazon Nova 2 Lite)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobDescriptionGenerator",
            ])->post($primaryApiUrl, [
                'model' => "amazon/nova-2-lite-v1:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                // Note: I removed the unused "reasoning" parameter
                'max_tokens' => $maxTokens, 
            ]);
            
        } // End of API calls

        // Parse Response
        if ($response->successful()) {
            $responseData = $response->json();
            
            if (isset($responseData['choices'][0]['message']['content'])) {
                $htmlDescription = $responseData['choices'][0]['message']['content'];
                return $htmlDescription; 
            }
        }

        return '';
    }
       
    
    // private function getAISecondFallBack($jobRole)
    // {
    //         $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 

            
    //         $primaryApiKey = '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';    // Replace with your Together AI API key

    //         // Define prompt
    //         $prompt = "
    //             Generate a full, detailed, professional Job Description in clean HTML format for the job role: '$jobRole'.

    //             Requirements:
    //             - Return ONLY HTML (no markdown, no explanations, no code blocks).
    //             - Use clean semantic tags (h2, h3, p, ul, li).
    //             - Content must look like a real corporate job description.
    //             - Include the following sections:
    //                 <h2>Job Title: [Job Role]</h2>
    //                 <h3>Job Overview</h3>
    //                 <p>...</p>

    //                 <h3>Key Responsibilities</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Required Skills & Competencies</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Qualifications</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Benefits</h3>
    //                 <ul>
    //                     <li>...</li>
    //                 </ul>

    //                 <h3>Work Environment</h3>
    //                 <p>...</p>

    //             - Ensure text is well-formatted, readable, and professional.
    //             ";

    //         $maxTokens = 1000;

    //         // Primary API Request (DeepSeek)
    //         $response = Http::withHeaders([
    //             'Authorization' => "Bearer $primaryApiKey",
    //             'Content-Type' => 'application/json',
    //             "X-Title" => "JobDescriptionGenerator",
    //         ])->post($primaryApiUrl, [
    //             'model' => "google/gemma-3-27b-it:free",
    //             'messages' => [['role' => 'user', 'content' => $prompt]],
    //             'max_tokens' => $maxTokens, // Use the new, higher value
    //         ]);

    //         return $response->json();

    //         // Check if primary API failed
    //         if ($response->failed()) {
    //               // Use fallback API (Llama)
    //               $response = Http::withHeaders([
    //                   'Authorization' => "Bearer $primaryApiKey",
    //                   'Content-Type' => 'application/json',
    //                   "X-Title" => "JobDescriptionGenerator",
    //               ])->post($primaryApiUrl, [
    //                   'model' => "google/gemma-3-12b-it:free",
    //                   'messages' => [['role' => 'user', 'content' => $prompt]],
    //                   'max_tokens' => $maxTokens, // Use the new, higher value
    //               ]);
                  
    //         }
          
    //         if ($response->successful()) {
    //             $responseData = $response->json();
                
    //             // This structure is common for OpenAI-compatible APIs (OpenRouter, Together AI)
    //             if (isset($responseData['choices'][0]['message']['content'])) {
    //                 $htmlDescription = $responseData['choices'][0]['message']['content'];
    //                 return $htmlDescription; 
    //             }
    //         }

    //         return '';
    // }
      
    
    private function getAISecondFallBack($jobRole)
    {
        $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 
        $primaryApiKey = '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'; 
        $maxTokens = 1000;
        $aiTimeout = 60; // Consistent timeout

        // Define prompt (same as before)
          $prompt = "
            Generate a complete, professional Job Description for the role: '$jobRole'.

            STRICT OUTPUT RULES (FOLLOW EXACTLY):
            1. Return ONLY clean HTML — no markdown, no code blocks, no ```html, no ```json, no <html>, <body>, or wrapper <div>.
            2. The HTML MUST be compact with minimal spacing:
              - NO blank lines.
              - NO extra'\n\n' spacing between tags.
            3. Each section must immediately follow the previous tag without empty lines.
            4. The output MUST start directly with: <p><strong>Role Name</strong></p>

            HTML STRUCTURE TO FOLLOW (NO EXTRA SPACES, NO BLANK LINES):
            <p><strong>React Developer</strong></p>
            <h3>Job Overview</h3>
            <p>...</p>
            <h3>Key Responsibilities</h3>
            <ul><li>...</li></ul>
            <h3>Required Skills & Competencies</h3>
            <ul><li>...</li></ul>
            <h3>Qualifications</h3>
            <ul><li>...</li></ul>

            CONTENT RULES:
            - Use corporate, professional tone.
            - Use clean semantic HTML only (<p>, <h3>, <ul>, <li>).
            - NO extra newlines, NO indentation, NO spacing between tags.
            - All content must be production-ready and visually tight when inserted into a WYSIWYG editor.

        ";

        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobDescriptionGenerator",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:free", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);

        // !! FIX 2: REMOVE THIS LINE !!
        // return $response->json(); 
        
        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobDescriptionGenerator",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);
        }
        
        // Parse Response
        if ($response->successful()) {
            $responseData = $response->json();
            
            if (isset($responseData['choices'][0]['message']['content'])) {
                $htmlDescription = $responseData['choices'][0]['message']['content'];
                return $htmlDescription; 
            }
        }

        return '';
    }

    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
               
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            return ['success' => false];
        }
    }
      
}
