<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\GoalSetTeamModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;
use App\Models\IncentiveCriteriaModel;

class ManageBhIncentive extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;



    return view('content.metrics.manage_bh_incentive');
  }

  public function fetchIncentive(Request $request)
  {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id') ?? $request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('za_staff.staff_name')
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.role_id', $role_id)
      ->where('za_staff.status', 0)
      ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
      return response()->json([
        'status' => false,
        'message' => 'Staff not found'
      ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
      'status' => true,
      'staff_names' => $staffNames,
      'types' => $types
    ]);
  }


  public function getIncentiveMetrics(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $role_id = $request->role_id;

    $year = $request->year;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

  
    $query = StaffModel::join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
      ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->join('et_branch', 'et_branch.sno', '=', 'et_staff.branch_id')
      ->where('et_staff.branch_id', $branchId);

    $query->where('et_staff.role_id', $role_id);

    $staffList = $query
      ->where('et_staff.status', 0)
      ->select(
        'et_staff.sno as staff_id',
        'et_staff.staff_name',
        'et_staff.role_id',
        'et_staff.department_id',
        'et_staff.staff_image',
        'et_staff.nick_name',
        'et_staff.branch_id',
        'et_branch.branch_name',
        'et_branch.franchise_name',
        'et_branch.cert_auth_sign',
        'et_staff.avaiable_points',
         'et_staff.per_hour_cost',
        'et_staff.basic_salary',
        'et_division.division_name as sub_department_name',
        'et_department.department_name'
      )
      ->get();

    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->whereMonth('branch_target.date', $request->month)
      ->whereYear('branch_target.date', $year)
      ->first();

    $goalset = GoalSetTeamModel::where('et_goal_set_team.branch_id', $branchId)
      ->where('et_goal_set_team.team_goal_month', $request->month)
      ->where('et_goal_set_team.team_goal_year', $year)
      ->where('et_goal_set_team.department_id', 1)
      ->first();
    // Define all incentive keys
    
    $criteriaKeys = [
      '10x_award',
      'ceiling',
      'quarterly',
      'twenty_five_percentage',
      'fifty_percentage',
      'six_month',
      'twelve_month',
      'nine_monthadd',
      'twelve_monthadd',
      'overall_year',
      'presale',
      'megabonus'
    ];

    $result = [];

    foreach ($staffList as $staff) {
       $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $year)
        ->where('status', 0)
        ->first();

      // Fetch criteria data for this staff
      $criteriaData = [];
      foreach ($criteriaKeys as $key) {
        $criteria = IncentiveCriteriaModel::where([
          'incentive_key' => $key,
          'role_id' => $staff->role_id,
          'branch_id' => $branchId,
        ])->first();

        $criteriaData[$key] = $criteria ? json_decode($criteria->criteria_points, true) : [];
      }

      $points = [];
      $calculations = [];
      $originalValues = [];
      $incentiveStatuses = [];
      $incentiveDetails = []; // NEW: Store details for each incentive

      // 1. 10X Award
      $result10xAward = $this->calculate10xAward($goalset, $targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['10xaward'] = $result10xAward['value'];
      $calculations['10xaward'] = $result10xAward['calculation'];
      $originalValues['10xaward'] = $incentive->tenx_award ?? 0;
      $incentiveStatuses['10xaward'] = $result10xAward['status'] ?? false;
      // Get condition_met from 10x award calculation
      $globalConditionMet = $calculations['10xaward']['condition_met'] ?? false;
      // Add incentive details
      $incentiveDetails['10xaward'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['10x_award'] ?? [],
        'status' => $result10xAward['status'] ?? false,
        'reward' => $incentive->tenx_award ?? 0
      ];

      // 2. Ceiling
      $resultCeiling = $this->calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $globalConditionMet);
      $points['ceiling'] = $resultCeiling['value'];
      $calculations['ceiling'] = $resultCeiling['calculation'];
      $originalValues['ceiling'] = $incentive->ceiling ?? 0;
      $incentiveStatuses['ceiling'] = $resultCeiling['status'] ?? false;

      $incentiveDetails['ceiling'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['ceiling'] ?? [],
        'status' => $resultCeiling['status'] ?? false,
        'reward' => $incentive->ceiling ?? 0
      ];

      // 3. Quarterly
      $resultQuarterly = $this->calculateQuarterly($targets, $branchId, $incentive, $year, $month, $globalConditionMet);
      $points['quarterly'] = $resultQuarterly['value'];
      $calculations['quarterly'] = $resultQuarterly['calculation'];
      $originalValues['quarterly'] = $incentive->quarterly ?? 0;
      $incentiveStatuses['quarterly'] = $resultQuarterly['status'] ?? false;

      $incentiveDetails['quarterly'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['quarterly'] ?? [],
        'status' => $resultQuarterly['status'] ?? false,
        'reward' => $incentive->quarterly ?? 0
      ];

      // 4. 25%
      $result25 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 25, $globalConditionMet);
      $points['twenty_five_percentage'] = $result25['value'];
      $calculations['twenty_five_percentage'] = $result25['calculation'];
      $originalValues['twenty_five_percentage'] = $incentive->twenty_five_percentage ?? 0;
      $incentiveStatuses['twenty_five_percentage'] = $result25['status'] ?? false;

      $incentiveDetails['twenty_five_percentage'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['twenty_five_percentage'] ?? [],
        'status' => $result25['status'] ?? false,
        'reward' => $incentive->twenty_five_percentage ?? 0
      ];

      // 5. 50%
      $result50 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 50, $globalConditionMet);
      $points['fifty_percentage'] = $result50['value'];
      $calculations['fifty_percentage'] = $result50['calculation'];
      $originalValues['fifty_percentage'] = $incentive->fifty_percentage ?? 0;
      $incentiveStatuses['fifty_percentage'] = $result50['status'] ?? false;

      $incentiveDetails['fifty_percentage'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['fifty_percentage'] ?? [],
        'status' => $result50['status'] ?? false,
        'reward' => $incentive->fifty_percentage ?? 0
      ];

      // 6. 6 Month
      $result6Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 6, $goalset);
      $points['six_month'] = $result6Month['value'];
      $calculations['six_month'] = $result6Month['calculation'];
      $originalValues['six_month'] = $incentive->six_month ?? 0;
      $incentiveStatuses['six_month'] = $result6Month['status'] ?? false;

      $incentiveDetails['six_month'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['six_month'] ?? [],
        'status' => $result6Month['status'] ?? false,
        'reward' => $incentive->six_month ?? 0
      ];

      // 7. 12 Month
      $result12Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 12, $goalset);
      $points['twelve_month'] = $result12Month['value'];
      $calculations['twelve_month'] = $result12Month['calculation'];
      $originalValues['twelve_month'] = $incentive->twelve_month ?? 0;
      $incentiveStatuses['twelve_month'] = $result12Month['status'] ?? false;

      $incentiveDetails['twelve_month'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['twelve_month'] ?? [],
        'status' => $result12Month['status'] ?? false,
        'reward' => $incentive->twelve_month ?? 0
      ];

      // 8. 9 Month Add
      $result9MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 9, $goalset);
      $points['nine_monthadd'] = $result9MonthAdd['value'];
      $calculations['nine_monthadd'] = $result9MonthAdd['calculation'];
      $originalValues['nine_monthadd'] = $incentive->nine_monthadd ?? 0;
      $incentiveStatuses['nine_monthadd'] = $result9MonthAdd['status'] ?? false;

      $incentiveDetails['nine_monthadd'] = [
        'reward_type' => 'gift',
        'rules' => $criteriaData['nine_monthadd'] ?? [],
        'status' => $result9MonthAdd['status'] ?? false,
        'reward' => $incentive->nine_monthadd ?? 0
      ];

      // 9. 12 Month Add
      $result12MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 12, $goalset);
      $points['twelve_monthadd'] = $result12MonthAdd['value'];
      $calculations['twelve_monthadd'] = $result12MonthAdd['calculation'];
      $originalValues['twelve_monthadd'] = $incentive->twelve_monthadd ?? 0;
      $incentiveStatuses['twelve_monthadd'] = $result12MonthAdd['status'] ?? false;

      $incentiveDetails['twelve_monthadd'] = [
        'reward_type' => 'gift',
        'rules' => $criteriaData['twelve_monthadd'] ?? [],
        'status' => $result12MonthAdd['status'] ?? false,
        'reward' => $incentive->twelve_monthadd ?? 0
      ];

      // 10. Overall Year
      $resultOverallYear = $this->calculateOverallYear($targets, $branchId, $incentive, $year);
      $points['overall_year'] = $resultOverallYear['value'];
      $calculations['overall_year'] = $resultOverallYear['calculation'];
      $originalValues['overall_year'] = $incentive->overall_year ?? 0;
      $incentiveStatuses['overall_year'] = $resultOverallYear['status'] ?? false;

      $incentiveDetails['overall_year'] = [
        'reward_type' => 'gift',
        'rules' => $criteriaData['overall_year'] ?? [],
        'status' => $resultOverallYear['status'] ?? false,
        'reward' => $incentive->overall_year ?? 0
      ];

      // 11. Presale
      $resultPresale = $this->calculatePresale($targets, $branchId, $incentive, $year);
      $points['presale'] = $resultPresale['value'];
      $calculations['presale'] = $resultPresale['calculation'];
      $originalValues['presale'] = $incentive->presale ?? 0;
      $incentiveStatuses['presale'] = $resultPresale['status'] ?? false;

      $incentiveDetails['presale'] = [
        'reward_type' => 'gift',
        'rules' => $criteriaData['presale'] ?? [],
        'status' => $resultPresale['status'] ?? false,
        'reward' => $incentive->presale ?? 0
      ];

      // 12. Mega Bonus
      $resultMegaBonus = $this->calculateMegaBonus($targets, $branchId, $incentive, $year);
      $points['megabonus'] = $resultMegaBonus['value'];
      $calculations['megabonus'] = $resultMegaBonus['calculation'];
      $originalValues['megabonus'] = $incentive->megabonus ?? 0;
      $incentiveStatuses['megabonus'] = $resultMegaBonus['status'] ?? false;

      $incentiveDetails['megabonus'] = [
        'reward_type' => 'amount',
        'rules' => $criteriaData['megabonus'] ?? [],
        'status' => $resultMegaBonus['status'] ?? false,
        'reward' => $incentive->megabonus ?? 0
      ];

      // Calculate total earned and total original
      $conditionMet = $calculations['10xaward']['condition_met'] ?? false;

      if (!$conditionMet) {
        foreach ($points as $key => $val) {
          $points[$key] = 0;
          $incentiveStatuses[$key] = false;
          // Update value in details too
          if (isset($incentiveDetails[$key])) {
            $incentiveDetails[$key]['value'] = 0;
            $incentiveDetails[$key]['status'] = false;
          }
        }
      }

      $totalEarned = array_sum($points);
      $totalOriginal = array_sum($originalValues);

      $result[] = [
        'staff_id' => $staff->staff_id,
        'staff_name' => $staff->staff_name,
        'branch_name' => $staff->branch_name,
        'bh_signature' => $staff->cert_auth_sign,
        'staff_image' => $staff->staff_image,
        'role_id' => $staff->role_id,
        'nick_name' => $staff->nick_name,
        'sub_department_name' => $staff->sub_department_name,
        'department_name' => $staff->department_name,
        'incentive_value' => $points,
        'incentive_value_original' => $originalValues,
        'incentive_cal' => $calculations,
        'incentive_status' => $incentiveStatuses,
        'incentive_details' => $incentiveDetails, // NEW: Detailed info with reward_type and rules
        'total_earned' => $totalEarned,
        'total_original' => $totalOriginal,
        'incentive_type' => [
          'presale' => 'gold',
        ]
      ];
    }

    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }

  private function calculate10xAward($goalset, $targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations'
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false]; // ADD status
    }

    $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;
      $total_collection_value = 0;

        // overall
        $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

      $customerConvertData = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function($join) {
                  $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
      })
      ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
      ->where('et_customer.status', 0)
      ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
      ->where('et_proposal.post_sale_check', 0)
      ->where('et_customer.branch_id', $branchId)
      ->whereYear('et_payment.transaction_date', $year)
      ->whereMonth('et_payment.transaction_date', $month)
      ->where('et_transaction.payment_status', 1)
      ->where('et_lead.created_by', '>',0)
      ->orderBy('et_customer.sno', 'asc')
      ->get();
      
      $presaleCount =count($customerConvertData);

    $postSaleCount = DB::table('et_customer')
        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->join('et_payment', function($join) {
            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.proposal_id = et_proposal.sno
                )');
        })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.status', 0)
        ->where('et_customer.post_sale_check', 1)
        ->where('et_proposal.post_sale_check', 1)
        ->where('et_customer.branch_id', $branchId)
        ->where('et_proposal.created_by', '>',1)
        ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
        ->where('et_proposal.status',0)
        ->orderBy('et_proposal.sno', 'asc')
        ->distinct('et_customer.sno')
          ->count();
     // Calculate for presale customers
    $presaleTotalOverallFees = 0;
    $presaleTotalCredit = 0;
    $averageBusinessValue = 0;
    $averageCollectionValue = 0;
    $total_paid_payment = 0;
    $total_payment = 0;
    $base_amount_paid = 0;

    

    $postsaleTotalOverallFees = 0;
    $postsaleTotalCredit = 0;
    $averageBusinessValuePost = 0;
    $averageCollectionValuePost = 0;
    $total_paid_paymentPost = 0;
    $total_paymentPost = 0;
    $base_amount_paidPost = 0;
    
      if ($presaleCount > 0) {
          $currentMonthCustomer = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by','>',1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

          $base_amount_paid=0;
          $gst_percent = 18;
          
        if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {
                $proposal_ids = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();
                    // return $proposal_ids;
                
                $proposals = DB::table('et_proposal')
                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereIn('et_proposal.sno', $proposal_ids)
                    ->get();
                  
                foreach ($proposals as $proposal) {
                    // Paid slots for this proposal
                    $paidAmount = DB::table('et_proposal_pay_slot')
                        ->where('proposal_sno', $proposal->sno)
                        ->where('status', 0)
                        ->sum('paidAmount');
                        
                    if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                        $grantAmount = $proposal->total_amount;
                        $basePaidLocal = $paidAmount ;
                    }else{
                        $grantAmount = $proposal->grant_total_amount;
                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                    }
                    
        
                    // First remove GST from paidAmount (base value in proposal's currency)
                    
        
                    if ($proposal->currency_id == 70) {
                        // INR: add directly
                        $total_paid_payment += $paidAmount;
                        $total_payment += $grantAmount;
                        $base_amount_paid += $basePaidLocal;
                    } else {
                        // Non-INR: convert both amounts and base value
                        $currency_code = $proposal->currency_code;
                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                    }
                }
            }
        }

        // average 
        $averageBusinessValue   = $presaleCount > 0 ? $total_payment / $presaleCount : 0;
        $averageCollectionValue = $presaleCount > 0 ? $base_amount_paid / $presaleCount : 0;

        $presaleTotalOverallFees = $total_payment;
        $presaleTotalCredit = $base_amount_paid;

      }

      $presaleABV             = round($averageBusinessValue) ?? 0;
      $presaleACV             = round($averageCollectionValue) ?? 0;

      if ($postSaleCount > 0) {
              
            $currentMonthCustomerPost = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function($join) {
                  $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
              })
              ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
              ->where('et_customer.status', 0)
              ->where('et_customer.branch_id', $branchId)
              ->where('et_lead.created_by', '>',1)
              ->whereYear('et_payment.transaction_date', $year)
              ->whereMonth('et_payment.transaction_date', $month)
              ->where('et_transaction.payment_status', 1)
              ->orderBy('et_customer.sno', 'asc')
              ->get();

                      
                
              $base_amount_paidPost=0;
              $gst_percent = 18;
              if ($currentMonthCustomerPost->isNotEmpty()) {
                  foreach ($currentMonthCustomerPost as $customer) {
                      $proposal_idsPost = DB::table('et_proposal')
                          ->where('et_proposal.customer_id', $customer->sno)
                          ->where('et_proposal.status', 0)
                          ->whereNot('et_proposal.post_sale_check', 1)
                          ->whereNotIn('et_proposal.proposal_status', [0, 2])
                          ->pluck('sno')
                          ->toArray();
                          // return $proposal_ids;
              
                      $proposalsPost = DB::table('et_proposal')
                          ->select('et_proposal.*', 'et_country_currencies.currency_code')
                          ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                          ->whereIn('et_proposal.sno', $proposal_idsPost)
                          ->get();
              
                      foreach ($proposalsPost as $proposal) {
                          // Paid slots for this proposal
                          $paidAmountPost = DB::table('et_proposal_pay_slot')
                              ->where('proposal_sno', $proposal->sno)
                              ->where('status', 0)
                              ->sum('paidAmount');

                            if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                $grantAmountPost = $proposal->total_amount;
                                $basePaidLocalPost = $paidAmountPost ;
                            }else{
                                $grantAmountPost = $proposal->grant_total_amount;
                                $basePaidLocalPost = $paidAmountPost / (1 + ($gst_percent / 100));
                            }
              
              
                          if ($proposal->currency_id == 70) {
                              // INR: add directly
                              $total_paid_paymentPost += $paidAmountPost;
                              $total_paymentPost += $grantAmountPost;
                              $base_amount_paidPost += $basePaidLocalPost;
                          } else {
                              // Non-INR: convert both amounts and base value
                              $currency_codePost = $proposal->currency_code;
                              $total_paid_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $paidAmountPost);
                              $total_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $grantAmountPost);
                              $base_amount_paidPost += $helper->ConvertedAmountInr($currency_codePost, $basePaidLocalPost);
                          }
                      }
                  }
              }

              // average 
              $averageBusinessValuePost   = $postSaleCount > 0 ? $total_paymentPost / $postSaleCount : 0;
              $averageCollectionValuePost = $postSaleCount > 0 ? $base_amount_paidPost / $postSaleCount : 0;

              $postsaleTotalOverallFees = $total_paymentPost;
              $postsaleTotalCredit = $base_amount_paidPost;
            
                
      }
      $postsaleABV             = round($averageBusinessValuePost) ?? 0;
      $postsaleACV             = round($averageCollectionValuePost) ?? 0;

    // Calculate for overall (combine presale + postsale)
    $totalCustomers = $presaleCount + $postSaleCount;
    $totalOverallFees = $presaleTotalOverallFees + $postsaleTotalOverallFees;
    $totalCreditAll = $presaleTotalCredit + $postsaleTotalCredit;

    $overallABV = ($totalCustomers > 0) ? $totalOverallFees / $totalCustomers : 0;
    $overallACV = ($totalCustomers > 0) ? $totalCreditAll / $totalCustomers : 0;

    $calculation = [
      'target' => [
        'monthly_target' => $targets->monthly_target ?? 0,
        'registrations' => $targets->no_of_registrations ?? 0,
        'post_sale' => $targets->post_sale ?? 0,
        'abv' => $goalset->abv_over_all ?? 0,
        'acv' => $goalset->acv_over_all ?? 0
      ],
      'actual' => [
        'total_credit' => round($totalCredit),
        'presale_count' => $presaleCount,
        'postsale_count' => $postSaleCount,
        'presale' => [
          'count' => $presaleCount,
          'abv_actual' => round($presaleABV),
          'acv_actual' => round($presaleACV),
          'total_overall_fees' => round($presaleTotalOverallFees),
          'total_credit' => round($presaleTotalCredit),
        ],
        'postsale' => [
          'count' => $postSaleCount,
          'abv_actual' => round($postsaleABV),
          'acv_actual' => round($postsaleACV),
          'total_overall_fees' => round($postsaleTotalOverallFees),
          'total_credit' => round($postsaleTotalCredit),
        ],
        'overall' => [
          'count' => $totalCustomers,
          'abv_actual' => round($overallABV),
          'acv_actual' => round($overallACV),
          'total_overall_fees' => round($totalOverallFees),
          'total_credit' => round($totalCreditAll),
        ],
      ],
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations',
      'condition_met' => (
        $presaleCount >= ($targets->no_of_registrations ?? 0) &&
        $postSaleCount >= ($targets->post_sale ?? 0) &&
        $totalCredit >= ($targets->monthly_target ?? 0) &&
        $overallABV >= ($goalset->abv_over_all ?? 0) &&
        $overallACV >= ($goalset->acv_over_all ?? 0)
      )
    ];

    // Main condition
    if (
      $presaleCount >= ($targets->no_of_registrations ?? 0) &&
      $totalCredit >= ($targets->monthly_target ?? 0)
    ) {
      $status = true; // 10x achieved
      return ['value' => $incentive->tenx_award ?? 0, 'calculation' => $calculation, 'status' => $status];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $globalConditionMet = false)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => 0,
      'percentage' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;
    $total_collection_value = 0;

    $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    $target = $targets->monthly_target ?? 0;

    $calculation = [
      'target' => $target,
      'actual' => round($totalCredit),
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => max(0, $totalCredit - $target),
      'percentage' => $incentive->ceiling ?? 0
    ];

    // Only if target achieved
    if ($globalConditionMet && $totalCredit > $target) {
      $profit = $totalCredit - $target;
      $percentage = $incentive->ceiling ?? 0;
      $percentageValue = ($profit * $percentage) / 100;
      $calculation['calculated_value'] = $percentageValue;
      return ['value' => $percentageValue, 'calculation' => $calculation, 'status' => true];
    }

    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }

  private function calculateQuarterly($targets, $branchId, $incentive, $year, $currentMonth, $globalConditionMet = false)
  {
    $calculation = [
      'eligible_quarter' => null,
      'months' => [],
      'message' => 'Not eligible'
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    //  Define quarters
    $quarters = [
      1 => [4, 5, 6],   // Q1
      2 => [7, 8, 9],   // Q2
      3 => [10, 11, 12], // Q3
      4 => [1, 2, 3]    // Q4
    ];

    // Map reward month → previous quarter
    $rewardMap = [
      1  => 3,
      2  => 4,
      3  => 4,
      4  => 4,
      5  => 1,
      6  => 1,
      7  => 1,
      8  => 2,
      9  => 2,
      10 => 2,
      11 => 3,
      12 => 3,
    ];

    //  If current month is not reward month → no calculation
    if (!isset($rewardMap[$currentMonth])) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $quarterKey = $rewardMap[$currentMonth];
    $months = $quarters[$quarterKey];

    $allAchieved = true;
    $monthData = [];

    foreach ($months as $m) {

      // Handle year change for Q4 (Jan–Mar belongs to NEXT year logic)
      $loopYear = ($quarterKey == 4) ? $year : $year;

      $startDate = Carbon::create($loopYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($loopYear, $m, 1)->endOfMonth();
      $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;
      $total_collection_value = 0;

      $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $loopYear)
        ->first();

      $target = $targetsMonth->monthly_target ?? $targets->monthly_target ?? 0;

      $achieved = ($target > 0 && $totalCredit >= $target);

      if (!$achieved) {
        $allAchieved = false;
      }

      $monthData[] = [
        'month' => $m,
        'month_name' => Carbon::create($loopYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => round($totalCredit),
        'achieved' => $achieved
      ];
    }

    $calculation['eligible_quarter'] = "Q{$quarterKey}";
    $calculation['months'] = $monthData;

    // FINAL CHECK (strict 3/3)
    if ($globalConditionMet && $allAchieved) {
      return [
        'value' => $incentive->quarterly ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    return [
      'value' => 0,
      'calculation' => $calculation,
      'status' => false
    ];
  }



  private function calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $percent, $globalConditionMet = false)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => "{$percent}% Achievement",
      'achievement_percent' => 0,
      'applied_slab' => 'no_data',
      'target_with_percentage' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

      $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;

    $total_collection_value = 0;

    $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    $target = $targets->monthly_target ?? 0;

    if ($target <= 0) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    $achievementPercent = ($totalCredit / $target) * 100;
    $profit = max(0, $totalCredit - $target);

    // Calculate target with percentage
    $targetWithPercentage = 0;
    if ($percent == 25) {
      $targetWithPercentage = $target + ($target * 25 / 100); // 25% = 25,00,000 + 25% = 31,25,000
    } elseif ($percent == 50) {
      $targetWithPercentage = $target + ($target * 50 / 100); // 50% = 25,00,000 + 50% = 37,50,000
    }

    $calculation = [
      'target' => $target,
      'target_with_percentage' => $targetWithPercentage,
      'actual' => round($totalCredit),
      'unit' => '₹',
      'target_label' => "{$percent}% Achievement",
      'achievement_percent' => round($achievementPercent, 2),
      'profit' => $profit,
      'applied_slab' => 'target_not_achieved'
    ];

    // Below 125% → nothing
    if ($achievementPercent < 125) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    // 25% slab: 125% to 149.99% (LESS THAN 150%)
    if ($percent == 25 && $achievementPercent >= 125 && $achievementPercent < 150) {
      if ($globalConditionMet) {
        $percentage = $incentive->twenty_five_percentage ?? 0;
        $calculation['applied_slab'] = '25%_slab';
        $calculation['slab_percentage'] = $percentage;
        $value = ($profit * $percentage) / 100;
        $calculation['calculated_value'] = $value;
        return ['value' => $value, 'calculation' => $calculation, 'status' => true];
      } else {
        return ['value' => 0, 'calculation' => $calculation, 'status' => false];
      }
    }

    // 50% slab: 150% AND ABOVE (>= 150%)
    if ($percent == 50 && $achievementPercent >= 150) {
      if ($globalConditionMet) {
        $percentage = $incentive->fifty_percentage ?? 0;
        $calculation['applied_slab'] = '50%_slab';
        $calculation['slab_percentage'] = $percentage;
        $value = ($profit * $percentage) / 100;
        $calculation['calculated_value'] = $value;
        return ['value' => $value, 'calculation' => $calculation, 'status' => true];
      } else {
        return ['value' => 0, 'calculation' => $calculation, 'status' => false];
      }
    }

    // If 25% and achievement >= 150%, it's blocked (already handled by 50% slab)
    if ($percent == 25 && $achievementPercent >= 150) {
      $calculation['applied_slab'] = 'blocked_by_50_slab';
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }

  // year based so no need 10x each month globalConditionMet check


  private function calculateMonthBased($targets, $branchId, $incentive, $year, $months, $goalset)
  {
    $calculation = [
      'target_label' => "{$months} Month Achievement (FY Apr–Mar)",
      'months_achieved' => 0,
      'required_months' => $months,
      'monthly_breakdown' => []
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    $startMonth = 4; // April
    $achievedMonths = 0;
    $monthlyBreakdown = [];

    for ($i = 0; $i < 12; $i++) {

      $m = (($startMonth + $i - 1) % 12) + 1;
      $fyYear = ($m >= 4) ? $year : $year + 1;

      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate = Carbon::create($fyYear, $m, 1)->endOfMonth();

      // Get monthly target
      $target = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first()
        ->monthly_target ?? 0;

      // Get 10x conditions for this month (same as calculate10xAward)
      $monthlyConditionMet = $this->check10xConditionForMonth($branchId, $startDate, $endDate, $goalset, $targets, $fyYear, $m);

      // Month achieved only if target met AND 10x condition met
      $achieved = ($target > 0 && $monthlyConditionMet);

      if ($achieved) {
        $achievedMonths++;
      }

      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => round($this->getMonthlyCredit($branchId, $startDate, $endDate)),
        'achieved' => $achieved,
        'condition_met' => $monthlyConditionMet // Add this to show 10x condition status
      ];
    }

    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;

    if ($achievedMonths >= 12) {
      return [
        'value' => $incentive->twelve_month ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    if ($achievedMonths >= 6) {
      return [
        'value' => $incentive->six_month ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    return [
      'value' => 0,
      'calculation' => $calculation,
      'status' => false
    ];
  }

  private function calculateMonthAdd($targets, $branchId, $incentive, $year, $months, $goalset)
  {
    $calculation = [
      'target_label' => "{$months} Month Add-on (FY Apr–Mar)",
      'months_achieved' => 0,
      'monthly_breakdown' => []
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    $startMonth = 4; // April
    $achievedMonths = 0;
    $monthlyBreakdown = [];

    for ($i = 0; $i < 12; $i++) {

      $m = (($startMonth + $i - 1) % 12) + 1;
      $fyYear = ($m >= 4) ? $year : $year + 1;

      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate = Carbon::create($fyYear, $m, 1)->endOfMonth();

      // Get monthly target
      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first();

      $target = $targetsMonth->monthly_target ?? 0;

      // Get 10x conditions for this month (same as calculate10xAward)
      $monthlyConditionMet = $this->check10xConditionForMonth($branchId, $startDate, $endDate, $goalset, $targets, $fyYear, $m);

      // Month achieved only if target met AND 10x condition met
      $achieved = ($target > 0 && $monthlyConditionMet);

      if ($achieved) {
        $achievedMonths++;
      }

      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => round($this->getMonthlyCredit($branchId, $startDate, $endDate)),
        'achieved' => $achieved,
        'condition_met' => $monthlyConditionMet // Add this to show 10x condition status
      ];
    }

    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;

    if ($achievedMonths >= 12) {
      return [
        'value' => $incentive->twelve_monthadd ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    if ($achievedMonths >= 9) {
      return [
        'value' => $incentive->nine_monthadd ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }

  // Helper function to check 10x conditions for a specific month
  private function check10xConditionForMonth($branchId, $startDate, $endDate, $goalset, $targets, $year, $month)
  {

    $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;
    // Total credit for the month
    $total_collection_value = 0;
    $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

   $customerConvertData = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function($join) {
                  $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
      })
      ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
      ->where('et_customer.status', 0)
      ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
      ->where('et_proposal.post_sale_check', 0)
      ->where('et_customer.branch_id', $branchId)
      ->whereYear('et_payment.transaction_date', $year)
      ->whereMonth('et_payment.transaction_date', $month)
      ->where('et_transaction.payment_status', 1)
      ->where('et_lead.created_by', '>',0)
      ->orderBy('et_customer.sno', 'asc')
      ->get();
      
      $presaleCount =count($customerConvertData);

    $postSaleCount = DB::table('et_customer')
        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->join('et_payment', function($join) {
            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.proposal_id = et_proposal.sno
                )');
        })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.status', 0)
        ->where('et_customer.post_sale_check', 1)
        ->where('et_proposal.post_sale_check', 1)
        ->where('et_customer.branch_id', $branchId)
        ->where('et_proposal.created_by', '>',1)
        ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
        ->where('et_proposal.status',0)
        ->orderBy('et_proposal.sno', 'asc')
        ->distinct('et_customer.sno')
          ->count();
     // Calculate for presale customers
    $presaleTotalOverallFees = 0;
    $presaleTotalCredit = 0;
    $averageBusinessValue = 0;
    $averageCollectionValue = 0;
    $total_paid_payment = 0;
    $total_payment = 0;
    $base_amount_paid = 0;

    $postsaleTotalOverallFees = 0;
    $postsaleTotalCredit = 0;
    $averageBusinessValuePost = 0;
    $averageCollectionValuePost = 0;
    $total_paid_paymentPost = 0;
    $total_paymentPost = 0;
    $base_amount_paidPost = 0;

      if ($presaleCount > 0) {
          $currentMonthCustomer = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by','>',1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

          $base_amount_paid=0;
          $gst_percent = 18;
          
        if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {
                $proposal_ids = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();
                    // return $proposal_ids;
                
                $proposals = DB::table('et_proposal')
                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereIn('et_proposal.sno', $proposal_ids)
                    ->get();
                  
                foreach ($proposals as $proposal) {
                    // Paid slots for this proposal
                    $paidAmount = DB::table('et_proposal_pay_slot')
                        ->where('proposal_sno', $proposal->sno)
                        ->where('status', 0)
                        ->sum('paidAmount');
        
                    if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                        $grantAmount = $proposal->total_amount;
                        $basePaidLocal = $paidAmount ;
                    }else{
                        $grantAmount = $proposal->grant_total_amount;
                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                    }
        
                    if ($proposal->currency_id == 70) {
                        // INR: add directly
                        $total_paid_payment += $paidAmount;
                        $total_payment += $grantAmount;
                        $base_amount_paid += $basePaidLocal;
                    } else {
                        // Non-INR: convert both amounts and base value
                        $currency_code = $proposal->currency_code;
                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                    }
                }
            }
        }

        // average 
        $averageBusinessValue   = $presaleCount > 0 ? $total_payment / $presaleCount : 0;
        $averageCollectionValue = $presaleCount > 0 ? $base_amount_paid / $presaleCount : 0;

        $presaleTotalOverallFees = $total_payment;
        $presaleTotalCredit = $base_amount_paid;

      }

      $presaleABV             = round($averageBusinessValue) ?? 0;
      $presaleACV             = round($averageCollectionValue) ?? 0;

      if ($postSaleCount > 0) {
              
            $currentMonthCustomerPost = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function($join) {
                  $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
              })
              ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
              ->where('et_customer.status', 0)
              ->where('et_customer.branch_id', $branchId)
              ->where('et_lead.created_by', '>',1)
              ->whereYear('et_payment.transaction_date', $year)
              ->whereMonth('et_payment.transaction_date', $month)
              ->where('et_transaction.payment_status', 1)
              ->orderBy('et_customer.sno', 'asc')
              ->get();

                      
                
              $base_amount_paidPost=0;
              $gst_percent = 18;
              if ($currentMonthCustomerPost->isNotEmpty()) {
                  foreach ($currentMonthCustomerPost as $customer) {
                      $proposal_idsPost = DB::table('et_proposal')
                          ->where('et_proposal.customer_id', $customer->sno)
                          ->where('et_proposal.status', 0)
                          ->whereNot('et_proposal.post_sale_check', 1)
                          ->whereNotIn('et_proposal.proposal_status', [0, 2])
                          ->pluck('sno')
                          ->toArray();
                          // return $proposal_ids;
              
                      $proposalsPost = DB::table('et_proposal')
                          ->select('et_proposal.*', 'et_country_currencies.currency_code')
                          ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                          ->whereIn('et_proposal.sno', $proposal_idsPost)
                          ->get();
              
                      foreach ($proposalsPost as $proposal) {
                          // Paid slots for this proposal
                          $paidAmountPost = DB::table('et_proposal_pay_slot')
                              ->where('proposal_sno', $proposal->sno)
                              ->where('status', 0)
                              ->sum('paidAmount');
              
                          if ( $proposal->currency_id != 70 &&( $year > 2026 ||($year == 2026 && $month >= 6))) {
                                $grantAmountPost = $proposal->total_amount;
                                $basePaidLocalPost = $paidAmountPost ;
                            }else{
                                $grantAmountPost = $proposal->grant_total_amount;
                                $basePaidLocalPost = $paidAmountPost / (1 + ($gst_percent / 100));
                            }
              
                          if ($proposal->currency_id == 70) {
                              // INR: add directly
                              $total_paid_paymentPost += $paidAmountPost;
                              $total_paymentPost += $grantAmountPost;
                              $base_amount_paidPost += $basePaidLocalPost;
                          } else {
                              // Non-INR: convert both amounts and base value
                              $currency_codePost = $proposal->currency_code;
                              $total_paid_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $paidAmountPost);
                              $total_paymentPost += $helper->ConvertedAmountInr($currency_codePost, $grantAmountPost);
                              $base_amount_paidPost += $helper->ConvertedAmountInr($currency_codePost, $basePaidLocalPost);
                          }
                      }
                  }
              }

              // average 
              $averageBusinessValuePost   = $postSaleCount > 0 ? $total_paymentPost / $postSaleCount : 0;
              $averageCollectionValuePost = $postSaleCount > 0 ? $base_amount_paidPost / $postSaleCount : 0;

              $postsaleTotalOverallFees = $total_paymentPost;
              $postsaleTotalCredit = $base_amount_paidPost;
            
                
      }
      $postsaleABV             = round($averageBusinessValuePost) ?? 0;
      $postsaleACV             = round($averageCollectionValuePost) ?? 0;

    // Overall ABV
    $totalCustomers = $presaleCount + $postSaleCount;
    $totalOverallFees = $presaleTotalOverallFees + $postsaleTotalOverallFees;
    $overallABV = ($totalCustomers > 0) ? $totalOverallFees / $totalCustomers : 0;

    // Overall ACV (using total credit)
    $overallACV = ($totalCustomers > 0) ? $totalCredit / $totalCustomers : 0;

    // Check all 10x conditions
    $conditionMet = (
      $presaleCount >= ($targets->no_of_registrations ?? 0) &&
      $postSaleCount >= ($targets->post_sale ?? 0) &&
      $totalCredit >= ($targets->monthly_target ?? 0) &&
      $overallABV >= ($goalset->abv_over_all ?? 0) &&
      $overallACV >= ($goalset->acv_over_all ?? 0)
    );

    return $conditionMet;
  }

  // Helper function to get monthly credit
  private function getMonthlyCredit($branchId, $startDate, $endDate)
  {

      $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;

      $total_collection_value = 0;
    $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    return $totalCredit;
  }

  

  private function calculateOverallYear($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    // Financial Year: April to March (Apr 1, YYYY to Mar 31, YYYY+1)
    $startMonth = 4; // April
    $startDate = Carbon::create($year, $startMonth, 1)->startOfMonth();
    $endDate = Carbon::create($year + 1, 3, 31)->endOfMonth(); // March of next year

      $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0;

      $total_collection_value = 0;

      $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $yearTotal = round($total_collection_value);
        // Total yearly credit for financial year
  

    // Year target (monthly × 12)
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => $yearTarget,
      'actual' => round($yearTotal),
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // Condition: 150% or more
    // AND condition: 10x achieved AND 150% or more
    if ($achievementPercent >= 150) {
      return [
        'value' => $incentive->presale ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }


    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }

  private function calculatePresale($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => 0,
      'actual' => 0,
      'unit' => 'registrations',
      'achievement_percent' => 0,
      'fy_range' => "Apr {$year} - Mar " . ($year + 1)
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    // Financial Year: April to March
    $startMonth = 4; // April
    $startDate = Carbon::create($year, $startMonth, 1)->startOfMonth();
    $endDate = Carbon::create($year + 1, 3, 31)->endOfMonth();

    // Total yearly presale count for financial year
    $customerConvertData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_customer.branch_id', $branchId)
            ->whereYear('et_payment.transaction_date', $year)
            // ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where('et_lead.created_by', '>',0)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
            
            $yearCount =count($customerConvertData);

    // Year target (monthly registrations × 12)
    $yearTarget = ($targets->no_of_registrations ?? 0) * 12;

    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => $yearTarget,
      'actual' => $yearCount,
      'unit' => 'registrations',
      'achievement_percent' => $yearTarget > 0 ? round(($yearCount / $yearTarget) * 100, 2) : 0,
      'fy_range' => "Apr {$year} - Mar " . ($year + 1)
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearCount / $yearTarget) * 100;

    // Condition: 150% or more
    // AND condition: 10x achieved AND 150% or more
    if ($achievementPercent >= 150) {
      return [
        'value' => $incentive->presale ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }

    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }

  private function calculateMegaBonus($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0,
      'fy_range' => "Apr {$year} - Mar " . ($year + 1)
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    // Financial Year: April to March
    $startMonth = 4; // April
    $startDate = Carbon::create($year, $startMonth, 1)->startOfMonth();
    $endDate = Carbon::create($year + 1, 3, 31)->endOfMonth();

        $helper = new \App\Helpers\Helpers();

        $branch = BranchModel::where('sno', $branchId)
                ->where('status', 0)
                ->orderBy('sno', 'desc')
                ->first();

          $gstPercentage = $branch ? $branch->gst_percentage  : 18;
          $transactionTotalNet = 0;

        $total_collection_value = 0;

      $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code',
                      DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                      DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                     )
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
              if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                 $netAmountInr = $convertedPaidAmountInr ;
              }else{
                  $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
              }
            $total_collection_value += $netAmountInr;
        }
        // Final net collection (matches verified_collection_net style)
        $yearTotal = round($total_collection_value);
    // Total yearly credit for financial year
    

    // Year target
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => $yearTarget,
      'actual' => round($yearTotal),
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0,
      'fy_range' => "Apr {$year} - Mar " . ($year + 1)
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation, 'status' => false];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // 200% condition (DOUBLE target)
    if ($achievementPercent >= 200) {
      return [
        'value' => $incentive->megabonus ?? 0,
        'calculation' => $calculation,
        'status' => true
      ];
    }
    return ['value' => 0, 'calculation' => $calculation, 'status' => false];
  }
}
