<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use App\Models\PaymentModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\CustomerModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
class ForecastMetrics extends Controller
{
  public function index(Request $request)
  {
     $user_id = $request->user()->user_id;
    //  if($user_id !=0){
    //      return view('content.working_on_progress');
         
    //  }
    return view('content.metrics.manage_forecast_metrics');
  }


public function getForecastMetrics(Request $request)
{
    $branch_id = $request->user()->branch_id;

    // Handle month input
    if (is_numeric($request->month)) {
        $monthNumber = str_pad($request->month, 2, '0', STR_PAD_LEFT);
    } else {
        $monthNumber = date('m', strtotime("1 " . $request->month));
    }

    $targetDate = $request->year . '-' . $monthNumber . '-01';
    
//   $monthNumber=9;

    // Get monthly target for the branch
    $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
        ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
        ->where('branch_target.date', $targetDate)
        ->select('branch_target.*')
        ->first();
     $branch = BranchModel::where('sno', $branch_id)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

    // Actual collected so far
    // $totalSumAll = DB::table('et_payment')->where('branch_id', $branch_id)
    //     ->whereYear('transaction_date', $request->year)
    //     ->whereMonth('transaction_date', $monthNumber)
    //     ->sum('paid_amount');
        
        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
            
        $transactionTotalNet = 0; // final net after GST
        $totalSumAll=0;

       

          
            
            $total_collection_value = 0;
          
            $allVerified = DB::table('et_transaction')
                ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
                ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->where('et_transaction.payment_status',1)
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->where('et_lead.created_by','>',1)
                ->where('et_lead.status','!=',2)
                ->where('et_customer.status',0)
                ->whereYear('et_payment.transaction_date', $request->year)
                ->whereMonth('et_payment.transaction_date', $monthNumber)
                ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                        'et_proposal.gst_perc',
                        'et_country_currencies.currency_code',
                        DB::raw('YEAR(et_payment.transaction_date) as trans_year'),
                        DB::raw('MONTH(et_payment.transaction_date) as trans_month')
                        )
                ->get();
            
                foreach ($allVerified as $row) {
                    // Determine INR value
                    if ($row->total_amount_inr > 0) {
                        $convertedPaidAmountInr = $row->total_amount_inr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
                    }
                
                    // Use transaction GST%
                    $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch_common->gst_percentage/100);
                    if ( $row->currency_code != 'INR' &&( $row->trans_year > 2026 ||($row->trans_year == 2026 && $row->trans_month >= 6))) {
                       $netAmountInr = $convertedPaidAmountInr ;
                    }else{
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    }
                   
                
                    $total_collection_value += $netAmountInr;
                }
            
            
                // Final net collection (matches verified_collection_net style)
                $totalSumAll = round($total_collection_value);

    // Post-sale & pre-sale actuals
        $customerConvertDataPost = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->whereRaw("
                        et_payment.sno = (
                            SELECT ep.sno
                            FROM et_payment ep
                            WHERE ep.proposal_id = et_proposal.sno
                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                            LIMIT 1
                        )
                    ");
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>',1)
            ->whereYear('et_payment.transaction_date', $request->year)
            ->whereMonth('et_payment.transaction_date', $monthNumber)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->distinct('et_customer.sno')
            ->get();
            
             $postSaleActual =count($customerConvertDataPost);
             
         

                $customerConvertData = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                   $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                  ->whereRaw("
                                      et_payment.sno = (
                                          SELECT ep.sno
                                          FROM et_payment ep
                                          WHERE ep.customer_id = et_customer.sno
                                          ORDER BY ep.transaction_date ASC, ep.sno ASC
                                          LIMIT 1
                                      )
                                  ");
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                 ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                 ->where('et_proposal.post_sale_check', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by','>',1)
                ->whereYear('et_payment.transaction_date', $request->year)
                ->whereMonth('et_payment.transaction_date', $monthNumber)
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();
            
            $preSaleActual =count($customerConvertData);

    

    // --- Day calculations ---
    $currentDay = Carbon::now()->day;
    $monthEndDay = Carbon::parse($targetDate)->daysInMonth;

    // --- Daily Averages ---
    // (divide by number of days passed so far)
    $totalSumAllAvg   = $currentDay > 0 ? round($totalSumAll / $currentDay, 2) : 0;
    $preSaleActualAvg = $currentDay > 0 ? round($preSaleActual / $currentDay, 2) : 0;
    $postSaleActualAvg = $currentDay > 0 ? round($postSaleActual / $currentDay, 2) : 0;

    // --- Predicted totals for the month ---
    $predictedMoney     = $currentDay > 0 ? round(($totalSumAll / $currentDay) * $monthEndDay) : 0;
    $predictedPreSale   = $currentDay > 0 ? round(($preSaleActual / $currentDay) * $monthEndDay) : 0;
    $predictedPostSale  = $currentDay > 0 ? round(($postSaleActual / $currentDay) * $monthEndDay) : 0;

    return response()->json([
        'status' => 200,
        'data' => $targets,
        'targetValue' => $totalSumAll ?? 0,
        'preSaleValue' => $preSaleActual ?? 0,
        'postSaleValue' => $postSaleActual ?? 0,

        // NEW: Daily averages section
        'daily_avg' => [
            'money_avg' => $totalSumAllAvg,
            'preSale_avg' => round($preSaleActualAvg,1),
            'postSale_avg' => round($postSaleActualAvg,1),
        ],

        // Existing predicted section
        'predicted' => [
            'money' => $predictedMoney,
            'preSale' => $predictedPreSale,
            'postSale' => $predictedPostSale,
        ],

        'monthEndDay' => $monthEndDay,
        'currentDay' => $currentDay,
    ]);
}




}
