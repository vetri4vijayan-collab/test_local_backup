<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageTicketCustomer extends Controller
{
  public function index(Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $Query = DB::table('et_manage_ticket')
      ->select(
        'et_manage_ticket.*',
        'et_customer.cus_name',
        'et_customer.customer_id AS cus_ai_id',
        'et_customer.cus_mobile',
        'et_customer_services.cre_id',
        'et_product.product_name as service_name',
        'et_customer_services.created_at as service_created_at',
        'et_manage_ticket.sno as ticket_sno',
      )
      ->leftJoin('et_customer', 'et_manage_ticket.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->where('et_customer.branch_id', $branch_id);

    if (!empty($search_fill)) {
      $Query->where(function ($query) use ($search_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_manage_ticket.ticket_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_manage_ticket.subject', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }
    // Clone the query for counts
    $baseQuery = clone $Query;

    // Get paginated list (this doesn't affect the base query)
    $list = $Query->orderBy('et_manage_ticket.sno', 'desc')->paginate($perpage);
    $total_ticket    = (clone $baseQuery)->count();
    $open_ticket     = (clone $baseQuery)->where('et_manage_ticket.status', 0)->count();
    $accepted_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 1)->count();
    $rejected_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 2)->count();
    $closed_ticket   = (clone $baseQuery)->where('et_manage_ticket.status', 3)->count();
    $reopen_ticket    = (clone $baseQuery)->where('et_manage_ticket.status', 4)->count();
    $completed_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 5)->count();
    
    return view('content.customer_management.manage_ticket.manage_ticket_list', [
      'List' => $list,
      'perpage' => $perpage,
      'total_ticket' => $total_ticket,
      'open_ticket' => $open_ticket,
      'accepted_ticket' => $accepted_ticket,
      'rejected_ticket' => $rejected_ticket,
      'closed_ticket' => $closed_ticket,
      'reopen_ticket' => $reopen_ticket,
      'completed_ticket' => $completed_ticket,
      'search_fill' => $search_fill,
    ]);
  }
  public function ticket_details($id, Request $request){
    $ticket = DB::table('et_manage_ticket')->where('sno', $id)->first();
    
    if (!$ticket) {
      return response([
        'status' => 404,
        'message' => 'Ticket not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Ticket fetched successfully',
      'error_msg' => null,
      'data' => $ticket,
    ], 200);
  }
  
  public function updateticket($id, Request $request)
    {
        $status = $request->status;
        $message = $request->message;
        $who = $request->who;
        $user_id = $request->user()->user_id;
 
        // Update the main ticket
        $ticket = DB::table('et_manage_ticket')
            ->where('sno', $id)
            ->update([
                'status' => $status,
                'updated_at' => now(),
                'updated_by' => $user_id,
            ]);
 
        if ($ticket) {
            // Insert into history table
            DB::table('et_manage_ticket_history')->insert([
                'ticket_id' => $id,
                'who' => $who,
                'message' => $message,
                'status' => $status,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
            // Customer app notification
            // 0-> Ticket Created (OR) Open Ticket 1-> Accept 2-> Reject 3-> Close 4-> Reopen 5-> Complete
            $sts_text = '';
            if ($status == 0) {
                $sts_text = 'Open';
            } elseif ($status == 1) {
                $sts_text = 'Accepted';
            } elseif ($status == 2) {
                $sts_text = 'Rejected';
            } elseif ($status == 3) {
                $sts_text = 'Closed';
            }
 
            $branch_id = $request->user()->branch_id;
            $ticketData = DB::table('et_manage_ticket')
                ->where('sno', $id)->first();
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 1,
                'notification_type' => 'Ticket',
                'header' => $ticketData->subject,
                'message' => 'Ticket Status Updated',
                'notification_date' => now(),
                'meesage_for' => $ticketData->ticket_id,
                'message_date' => date('d-M-Y'),
                'who' => $user_id,
                'whom' => $ticketData->customer_id,
                'process_id' => $ticketData->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
        }
 
        return response([
            'status' => 200,
            'message' => 'Ticket updated successfully!',
        ], 200);
    }

  public function getTicketHistory($id)
  {
    // Get main ticket details with joins
    $ticket = DB::table('et_manage_ticket')
      ->select(
        'et_manage_ticket.*',
        'et_customer.cus_name',
        'et_customer.customer_id AS cus_ai_id',
        'et_customer.cus_mobile',
        'et_customer_services.cre_id',
        'et_product.product_name as service_name',
        'et_manage_ticket.sno as ticket_sno',
        'et_manage_ticket.description as ticket_description',
        'et_customer_services.created_at as service_created_at',
    )
      ->leftJoin('et_customer', 'et_manage_ticket.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->where('et_manage_ticket.sno', $id)
      ->first();

    if (!$ticket) {
      return response()->json([
        'status' => 404,
        'message' => 'Ticket not found'
      ], 404);
    }


    $year = date('Y', strtotime($ticket->service_created_at));
    $id = str_pad($ticket->sno, 5, '0', STR_PAD_LEFT);
    $service_id = "SR-{$id}/{$year}";

    $ticket->services_id = $service_id;

    // Get ticket history from history table
    $history = DB::table('et_manage_ticket_history')
      ->where('ticket_id', $id)
      ->orderBy('created_at', 'desc')
      ->get();

    // Get CRE details if needed
    $cre = null;
    if ($ticket->cre_id) {
      $cre = DB::table('et_staff') // Adjust table name if different
        ->where('sno', $ticket->cre_id)
        ->select('staff_name as user_name')
        ->first();
    }

    // Get attachments
    $attachments = json_decode($ticket->attachments, true) ?? [];

    return response()->json([
      'status' => 200,
      'data' => [
        'ticket' => $ticket,
        'history' => $history,
        'customer' => [
          'name' => $ticket->cus_name,
          'mobile' => $ticket->cus_mobile,
          'id' => $ticket->cus_ai_id
        ],
        'cre' => $cre,
        'attachments' => $attachments
      ]
    ]);
  }

  

 }