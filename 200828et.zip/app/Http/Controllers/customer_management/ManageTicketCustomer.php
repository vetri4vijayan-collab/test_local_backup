<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ManageTicketCustomer extends Controller
{
    public function index(Request $request)
    {
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $search_fill = $request->search_fill;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $Query = DB::table('et_manage_ticket')
            ->select(
                'et_manage_ticket.*',
                'et_customer.cus_name',
                'et_customer.customer_id AS cus_ai_id',
                'et_customer.cus_mobile',
                'et_customer_services.cre_id',
                'et_product.product_name as service_name',
                'et_customer_services.created_at as service_created_at',
                'et_manage_ticket.sno as ticket_sno',
                'et_ticket_relevant.relevant_name',
            )
            ->leftJoin('et_customer', 'et_manage_ticket.customer_id', '=', 'et_customer.sno')
            ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
            ->leftJoin('et_ticket_relevant', 'et_manage_ticket.relevant_id', '=', 'et_ticket_relevant.sno')
            ->where('et_customer.branch_id', $branch_id);

        if (!empty($search_fill)) {
            $Query->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_ticket.ticket_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_ticket.subject', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
            });
        }

        $baseQuery = clone $Query;
        $listRecords = $Query->orderBy('et_manage_ticket.sno', 'desc')->paginate($perpage);

        $total_ticket = (clone $baseQuery)->count();
        $open_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 0)->count();
        $accepted_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 1)->count();
        $rejected_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 2)->count();
        $closed_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 3)->count();
        $reopen_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 4)->count();
        $completed_ticket = (clone $baseQuery)->where('et_manage_ticket.status', 5)->count();

        $pc_department = (clone $baseQuery)->where('et_manage_ticket.department_id', 15)->count();
        $cre_department = (clone $baseQuery)->where('et_manage_ticket.department_id', 16)->count();
        $jtl_department = (clone $baseQuery)->where('et_manage_ticket.department_id', 33)->count();

        return view('content.customer_management.manage_ticket.manage_ticket_list', [
            'tableRecords' => $listRecords,
            'perpage' => $perpage,
            'total_ticket' => $total_ticket,
            'open_ticket' => $open_ticket,
            'accepted_ticket' => $accepted_ticket,
            'rejected_ticket' => $rejected_ticket,
            'closed_ticket' => $closed_ticket,
            'reopen_ticket' => $reopen_ticket,
            'completed_ticket' => $completed_ticket,
            'cre_department' => $cre_department,
            'pc_department' => $pc_department,
            'jtl_department' => $jtl_department,
            'search_fill' => $search_fill,
        ]);
    }

    public function ticket_details($id, Request $request)
    {
        $ticket = DB::table('et_manage_ticket')->where('sno', $id)->first();

        if (!$ticket) {
            return response()->json([
                'status' => 404,
                'message' => 'Ticket not found',
                'data' => null,
            ], 404);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Ticket fetched successfully',
            'data' => $ticket,
        ], 200);
    }

    public function updateticket($id, Request $request)
    {
        try {
            $status = $request->status;
            $message = $request->message;
            $who = $request->who;
            $user_id = $request->user()->user_id;
            $attachments = $request->attachments ?: [];

            $currentTicket = DB::table('et_manage_ticket')->where('sno', $id)->first();

            if (!$currentTicket) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Ticket not found',
                ], 404);
            }

            $updateData = [
                'status' => $status,
                'updated_at' => now(),
                'updated_by' => $user_id,
            ];

            if ($status == 3 && !empty($attachments)) {
                $existingAttachments = json_decode($currentTicket->staff_attachments, true) ?: [];
                $allAttachments = array_merge($existingAttachments, $attachments);
                $updateData['staff_attachments'] = json_encode($allAttachments);
            }

            $ticket = DB::table('et_manage_ticket')
                ->where('sno', $id)
                ->update($updateData);

            if ($ticket) {
                DB::table('et_manage_ticket_history')->insert([
                    'ticket_id' => $id,
                    'who' => $who,
                    'message' => $message,
                    'status' => $status,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                $sts_text = '';
                if ($status == 0) $sts_text = 'Open';
                elseif ($status == 1) $sts_text = 'Accepted';
                elseif ($status == 2) $sts_text = 'Rejected';
                elseif ($status == 3) $sts_text = 'Closed';
                elseif ($status == 5) $sts_text = 'Completed';

                $branch_id = $request->user()->branch_id;
                $ticketData = DB::table('et_manage_ticket')->where('sno', $id)->first();

                DB::table('et_notification_customer_app')->insert([
                    'branch_id' => $branch_id,
                    'notification_type_id' => 1,
                    'notification_type' => 'Ticket',
                    'header' => $ticketData->subject,
                    'message' => 'Ticket Status Updated to ' . $sts_text,
                    'notification_date' => now(),
                    'meesage_for' => $ticketData->ticket_id,
                    'message_date' => date('d-M-Y'),
                    'who' => $user_id,
                    'whom' => $ticketData->customer_id,
                    'process_id' => $ticketData->sno,
                    'status_text' => $sts_text,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            return response()->json([
                'status' => 200,
                'message' => 'Ticket updated successfully!',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function uploadTicketAttachment(Request $request)
    {
        try {
            Log::info('File upload request received', [
                'has_files' => $request->hasFile('file'),
                'method' => $request->method(),
                'content_type' => $request->getContentType()
            ]);

            // Check if files exist
            if (!$request->hasFile('file')) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No files were uploaded'
                ], 400);
            }

            $files = $request->file('file');
            $uploadedFiles = [];

            // Ensure we're working with an array
            if (!is_array($files)) {
                $files = [$files];
            }

            foreach ($files as $file) {
                if (!$file) {
                    continue;
                }

                // Check if file is valid
                if (!$file->isValid()) {
                    Log::warning('Invalid file upload', [
                        'error' => $file->getError(),
                        'error_message' => $file->getErrorMessage()
                    ]);
                    continue;
                }

                try {
                    $originalName = $file->getClientOriginalName();
                    $extension = $file->getClientOriginalExtension();

                    // Generate safe filename
                    $safeName = preg_replace('/[^a-zA-Z0-9]/', '_', pathinfo($originalName, PATHINFO_FILENAME));
                    $fileName = time() . '_' . uniqid() . '_' . $safeName . '.' . $extension;
                    $destinationPath = public_path('/staff_ticket_attachments');

                    // Create directory if it doesn't exist
                    if (!file_exists($destinationPath)) {
                        mkdir($destinationPath, 0777, true);
                    }

                    // Get file size BEFORE moving
                    $fileSize = $file->getSize();
                    $fileType = $file->getMimeType();

                    // Move the file
                    $file->move($destinationPath, $fileName);

                    // Verify file was moved successfully
                    $fullPath = $destinationPath . '/' . $fileName;
                    if (file_exists($fullPath)) {
                        $uploadedFiles[] = [
                            'file_name' => $originalName,
                            'file_path' => 'staff_ticket_attachments/' . $fileName,
                            'file_size' => $fileSize,
                            'file_type' => $fileType,
                            'uploaded_at' => now()->toDateTimeString()
                        ];
                        Log::info('File uploaded successfully', ['file' => $fileName, 'size' => $fileSize]);
                    } else {
                        Log::error('File move failed - file not found at destination', [
                            'destination' => $fullPath
                        ]);
                    }
                } catch (\Exception $e) {
                    Log::error('Error processing individual file', [
                        'error' => $e->getMessage(),
                        'file_name' => $file->getClientOriginalName() ?? 'unknown'
                    ]);
                    continue;
                }
            }

            if (empty($uploadedFiles)) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No valid files were uploaded. Please check file types and sizes.'
                ], 400);
            }

            return response()->json([
                'status' => 'success',
                'message' => count($uploadedFiles) . ' file(s) uploaded successfully',
                'files' => $uploadedFiles
            ]);
        } catch (\Exception $e) {
            Log::error('File upload exception: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Upload failed: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getTicketHistory($id)
    {
        try {
            $ticket = DB::table('et_manage_ticket')
                ->select(
                    'et_manage_ticket.*',
                    'et_customer.cus_name',
                    'et_customer.customer_id AS cus_ai_id',
                    'et_customer.cus_mobile',
                    'et_customer_services.cre_id',
                    'et_product.product_name as service_name',
                    'et_manage_ticket.sno as ticket_sno',
                    'et_manage_ticket.description as ticket_description',
                    'et_customer_services.created_at as service_created_at',
                )
                ->leftJoin('et_customer', 'et_manage_ticket.customer_id', '=', 'et_customer.sno')
                ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
                ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
                ->where('et_manage_ticket.sno', $id)
                ->first();

            if (!$ticket) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Ticket not found',
                ], 404);
            }

            $year = date('Y', strtotime($ticket->service_created_at ?? now()));
            $id_padded = str_pad($ticket->sno, 5, '0', STR_PAD_LEFT);
            $service_id = "SR-{$id_padded}/{$year}";
            $ticket->services_id = $service_id;

            $history = DB::table('et_manage_ticket_history')
                ->where('ticket_id', $id)
                ->orderBy('created_at', 'asc')
                ->get();

            $cre = null;
            if ($ticket->cre_id) {
                $cre = DB::table('et_staff')
                    ->where('sno', $ticket->cre_id)
                    ->select('staff_name as user_name', 'staff_name as name')
                    ->first();
            }

            // Separate attachments from main table
            // Customer attachments are in 'attachments' column
            // Staff attachments are in 'staff_attachments' column
            $customerAttachments = json_decode($ticket->attachments, true) ?? [];
            $staffAttachments = json_decode($ticket->staff_attachments, true) ?? [];

            return response()->json([
                'status' => 200,
                'data' => [
                    'ticket' => $ticket,
                    'history' => $history,
                    'customer' => [
                        'name' => $ticket->cus_name,
                        'mobile' => $ticket->cus_mobile,
                        'id' => $ticket->cus_ai_id,
                    ],
                    'cre' => $cre,
                    'customer_attachments' => $customerAttachments,
                    'staff_attachments' => $staffAttachments,
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function getStaffList(Request $request)
    {
        try {
            $department = $request->input('dept');

            if (!$department) {
                return response()->json([
                    'status' => 400,
                    'data' => [],
                    'message' => 'Department parameter is required'
                ]);
            }

            $staffList = DB::table('et_staff')
                ->where('role_id', $department)
                ->where('status', 0)
                ->select('sno', 'staff_name', 'nick_name', 'gender', 'staff_image')
                ->orderBy('staff_name', 'asc')
                ->get();

            if ($staffList->isNotEmpty()) {
                return response()->json([
                    'status' => 200,
                    'data' => $staffList,
                    'message' => 'Staff list retrieved successfully'
                ]);
            }

            return response()->json([
                'status' => 404,
                'data' => [],
                'message' => 'No staff found for this department'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'data' => [],
                'message' => 'Error: ' . $e->getMessage()
            ]);
        }
    }

    public function updateAssignStaff(Request $request)
    {
        try {
            $validated = $request->validate([
                'ticket_id' => 'required|integer',
                'staff_id' => 'required|integer|exists:et_staff,sno',
                'ticket_no' => 'required|string'
            ]);

            $ticket = DB::table('et_manage_ticket')
                ->where('sno', $validated['ticket_id'])
                ->first();

            if (!$ticket) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Ticket not found'
                ]);
            }

            $updated = DB::table('et_manage_ticket')
                ->where('sno', $validated['ticket_id'])
                ->update([
                    'assign_staff' => $validated['staff_id'],
                    'updated_at' => now(),
                    'updated_by' => $request->user()->user_id
                ]);

            if ($updated) {
                $staffDetails = DB::table('et_staff')
                    ->where('sno', $validated['staff_id'])
                    ->first();

                DB::table('et_manage_ticket_history')->insert([
                    'ticket_id' => $validated['ticket_id'],
                    'who' => 0,
                    'message' => 'Staff assigned: ' . ($staffDetails->staff_name ?? ''),
                    'status' => $ticket->status,
                    'created_by' => $request->user()->user_id,
                    'updated_by' => $request->user()->user_id,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                return response()->json([
                    'status' => 200,
                    'message' => 'Staff assigned successfully',
                    'data' => [
                        'staff_name' => $staffDetails->staff_name ?? '',
                        'staff_image' => $staffDetails->staff_image ?? null,
                        'gender' => $staffDetails->gender ?? null
                    ]
                ]);
            }

            return response()->json([
                'status' => 400,
                'message' => 'Failed to update staff assignment'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error: ' . $e->getMessage()
            ]);
        }
    }
}