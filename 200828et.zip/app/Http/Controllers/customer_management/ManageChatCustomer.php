<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageChatCustomer extends Controller
{
  public function index(Request $request)
  {
    return view('content.customer_management.manage_chat.manage_chat');
  }

  public function CustomerChatList(Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill;

    $Query = DB::table('et_chat')
      ->select(
        'et_chat.customer_id',
        'et_customer.cus_name',
        'et_customer.customer_id AS cus_ai_id',
        'et_customer.cus_mobile',
        'et_customer.cus_pic',
        'et_customer.cus_email_id',
        DB::raw('MAX(et_chat.created_at) as last_message_time'),
        DB::raw('COUNT(CASE WHEN et_chat.who = 0 AND et_chat.status = 0 THEN 1 END) as unread_count')
      )
      ->leftJoin('et_customer', 'et_chat.customer_id', '=', 'et_customer.sno')
      ->where('et_customer.branch_id', $branch_id)
      ->groupBy(
        'et_chat.customer_id',
        'et_customer.cus_name',
        'et_customer.customer_id',
        'et_customer.cus_mobile',
        'et_customer.cus_pic',
        'et_customer.cus_email_id'
      );

    if (!empty($search_fill)) {
      $Query->where(function ($query) use ($search_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }

    $chat_customer = $Query->orderBy('last_message_time', 'desc')->get();

    foreach ($chat_customer as $customer) {
      $lastMessage = DB::table('et_chat')
        ->where('customer_id', $customer->customer_id)
        ->orderBy('created_at', 'desc')
        ->first();

      $customer->last_message = $lastMessage ? $lastMessage->message_content : '';
      $customer->last_message_time_formatted = $lastMessage ?
        Carbon::parse($lastMessage->created_at)->format('h:i A') : '';

      $customer->last_message_type = $lastMessage ? ($lastMessage->type == 0 ? 'proposal' : 'publication') : '';
      $customer->last_message_service_id = $lastMessage ? $lastMessage->service_id : '';

      if (!empty($customer->cus_pic) && file_exists(public_path('customer_images/' . $customer->cus_pic))) {
        $customer->cus_pic = asset('customer_images/' . $customer->cus_pic);
      } else {
        $customer->cus_pic = '';
      }
    }

    return response()->json([
      'status' => 'success',
      'message' => 'Customer Data Fetched Successfully!',
      'list' => $chat_customer
    ]);
  }

  public function ChatServicesList(Request $request)
  {
    $customer_id = $request->customer_id;

    if (!$customer_id) {
      return response()->json([
        'status' => 'error',
        'message' => 'Customer Id Not Found!',
      ], 404);
    }

    $Proposal = DB::table('et_customer_services')
      ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
      ->where('et_customer_services.status', '!=', 2)
      ->where('et_customer_services.customer_id', $customer_id)
      ->where('et_customer_services.journal_check', 0)
      ->select(
        'et_product.product_name',
        'et_customer_services.sno',
        'et_customer_services.created_at'
      )
      ->orderBy('et_customer_services.created_at', 'desc')
      ->get()
      ->map(function ($service) {
        $year = date('Y', strtotime($service->created_at));
        $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
        $service->service_id = "SR-{$tempid}/{$year}";
        $service->service_type = 'proposal';

        $service->unread_count = DB::table('et_chat')
          ->where('service_id', $service->sno)
          ->where('type', 0)
          ->where('who', 0)
          ->where('status', 0)
          ->count();

        $lastMessage = DB::table('et_chat')
          ->where('service_id', $service->sno)
          ->where('type', 0)
          ->orderBy('created_at', 'desc')
          ->first();

        if ($lastMessage) {
          $service->last_message_time = Carbon::parse($lastMessage->created_at)->format('d M Y, h:i A');
          $service->last_message = $lastMessage->message_content;
          $service->last_message_who = $lastMessage->who;
        } else {
          $service->last_message_time = '';
          $service->last_message = '';
          $service->last_message_who = null;
        }

        return $service;
      });

    $Publication = DB::table('et_customer_services')
      ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
      ->where('et_customer_services.status', '!=', 2)
      ->where('et_customer_services.customer_id', $customer_id)
      ->where('et_customer_services.journal_check', 1)
      ->select(
        'et_product.product_name',
        'et_customer_services.sno',
        'et_customer_services.created_at'
      )
      ->orderBy('et_customer_services.created_at', 'desc')
      ->get()
      ->map(function ($service) {
        $year = date('Y', strtotime($service->created_at));
        $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
        $service->service_id = "SR-{$tempid}/{$year}";
        $service->service_type = 'publication';

        $service->unread_count = DB::table('et_chat')
          ->where('service_id', $service->sno)
          ->where('type', 1)
          ->where('who', 0)
          ->where('status', 0)
          ->count();

        $lastMessage = DB::table('et_chat')
          ->where('service_id', $service->sno)
          ->where('type', 1)
          ->orderBy('created_at', 'desc')
          ->first();

        if ($lastMessage) {
          $service->last_message_time = Carbon::parse($lastMessage->created_at)->format('d M Y, h:i A');
          $service->last_message = $lastMessage->message_content;
          $service->last_message_who = $lastMessage->who;
        } else {
          $service->last_message_time = '';
          $service->last_message = '';
          $service->last_message_who = null;
        }

        return $service;
      });

    return response()->json([
      'status' => 'success',
      'message' => 'Service Data Fetched Successfully!',
      'Proposal' => $Proposal,
      'Publication' => $Publication
    ]);
  }

  public function ChatHistory(Request $request)
  {
    $service_id = $request->service_id;
    $type = $request->type;
    $page = $request->get('page', 1);
    $limit = $request->get('limit', 25);
    $offset = ($page - 1) * $limit;

    if (!$service_id) {
      return response()->json([
        'status' => 'error',
        'message' => 'Service Id Not Found!',
      ], 404);
    }

    $totalMessages = DB::table('et_chat')
      ->where('service_id', $service_id)
      ->where('type', $type)
      ->count();

    $chats = DB::table('et_chat')
      ->where('service_id', $service_id)
      ->where('type', $type)
      ->orderBy('created_at', 'desc')
      ->offset($offset)
      ->limit($limit)
      ->get()
      ->map(function ($chat) {
        $chat->formatted_time = Carbon::parse($chat->created_at)->format('h:i A');
        $chat->formatted_date = Carbon::parse($chat->created_at)->format('Y-m-d');
        $chat->formatted_datetime = Carbon::parse($chat->created_at)->format('Y-m-d H:i:s');
        $chat->message_type = $chat->who == 0 ? 'received' : 'sent';
        return $chat;
      })
      ->reverse()
      ->values();

    $hasMore = ($offset + $limit) < $totalMessages;
    $nextPage = $hasMore ? $page + 1 : null;

    DB::table('et_chat')
      ->where('service_id', $service_id)
      ->where('type', $type)
      ->where('who', 0)
      ->where('status', 0)
      ->update(['status' => 1]);

    return response()->json([
      'status' => 'success',
      'message' => 'Chat History Fetched Successfully!',
      'chats' => $chats,
      'pagination' => [
        'current_page' => (int)$page,
        'next_page' => $nextPage,
        'has_more' => $hasMore,
        'total' => $totalMessages,
        'per_page' => (int)$limit
      ]
    ]);
  }

  public function SendMessage(Request $request)
  {
    $request->validate([
      'customer_id' => 'required',
      'service_id' => 'required',
      'message' => 'required|string',
      'type' => 'required|in:0,1'
    ]);

    $user_id = $request->user()->user_id;

    $chatId = DB::table('et_chat')->insertGetId([
      'customer_id' => $request->customer_id,
      'service_id' => $request->service_id,
      'message_content' => $request->message,
      'who' => 1,
      'type' => $request->type,
      'status' => 0,
      'created_at' => now(),
      'updated_at' => now()
    ]);

    $chat = DB::table('et_chat')->where('sno', $chatId)->first();

    return response()->json([
      'status' => 'success',
      'message' => 'Message Sent Successfully!',
      'chat' => [
        'id' => $chat->sno,
        'message' => $chat->message_content,
        'formatted_time' => Carbon::parse($chat->created_at)->format('h:i A'),
        'formatted_date' => Carbon::parse($chat->created_at)->format('Y-m-d'),
        'formatted_datetime' => Carbon::parse($chat->created_at)->format('Y-m-d H:i:s'),
        'message_type' => 'sent',
        'who' => $chat->who
      ]
    ]);
  }

  public function MarkMessagesAsRead(Request $request)
  {
    $request->validate([
      'service_id' => 'required',
      'type' => 'required|in:0,1'
    ]);

    DB::table('et_chat')
      ->where('service_id', $request->service_id)
      ->where('type', $request->type)
      ->where('who', 0)
      ->where('status', 0)
      ->update(['status' => 1]);

    return response()->json([
      'status' => 'success',
      'message' => 'Messages marked as read successfully!'
    ]);
  }

  public function GetUnreadCount(Request $request)
  {
    $request->validate([
      'service_id' => 'required',
      'type' => 'required|in:0,1'
    ]);

    $unread_count = DB::table('et_chat')
      ->where('service_id', $request->service_id)
      ->where('type', $request->type)
      ->where('who', 0)
      ->where('status', 0)
      ->count();

    return response()->json([
      'status' => 'success',
      'unread_count' => $unread_count
    ]);
  }
}