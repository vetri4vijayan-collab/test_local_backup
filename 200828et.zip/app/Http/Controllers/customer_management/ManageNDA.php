<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageNDAModel;
use Illuminate\Support\Facades\DB;
use PDF;
use function PHPSTORM_META\map;

class ManageNDA extends Controller
{
  public function index()
  {
    $ndas = ManageNDAModel::where('et_manage_nda.status', '!=', 2)
      ->select('et_manage_nda.*','et_proposal.old_customer_check','et_customer.cus_name','et_customer.customer_id as cus_id', 'et_customer.cus_email_id', 'et_customer.door_no', 'et_customer.address', 'et_customer.country', 'et_customer.state', 'et_customer.city', 'et_countries.id', 'et_states.id', 'et_cities.id', 'et_cities.name as city_name', 'et_states.name as state_name', 'et_countries.name')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_manage_nda.proposal_id')
      ->join('et_customer', 'et_customer.sno', '=', 'et_manage_nda.customer_id')
      ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
      ->orderBy('et_manage_nda.sno', 'desc')
      ->get();
    return view('content.customer_management.manage_nda.nda_list', compact('ndas'));
  }
  
  public function ndaView($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $edit = ManageNDAModel::where('et_manage_nda.status', '!=', 2)
      ->select(
        'et_manage_nda.*',
        'et_customer.cus_name',
        'et_customer.cus_email_id',
        'et_branch.branch_name',
        'et_branch.door_no as branch_door',
        'et_branch.area_street',
        'et_branch.country_id',
        'et_branch.state_id',
        'et_branch.city_id',
        'et_branch.pincode',
        'branch_country.id',
        'customer_country.id',
        'branch_state.id',
        'customer_state.id',
        'branch_city.id',
        'customer_city.id',
        'et_customer.state',
        'et_customer.country',
        'et_customer.city',
        'branch_country.name as branch_country_name',
        'customer_country.name as customer_country_name',
        'branch_state.name as branch_state_name',
        'customer_state.name as customer_state_name',
        'branch_city.name as branch_city_name',
        'customer_city.name as customer_city_name',
        'et_customer.door_no',
        'et_customer.address',
        'et_staff.staff_name'
      )
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_nda.customer_id')
      ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_manage_nda.branch_id')
      ->leftJoin('et_countries as branch_country', 'branch_country.id', '=', 'et_branch.country_id')
      ->leftJoin('et_countries as customer_country', 'customer_country.id', '=', 'et_customer.country')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->leftJoin('et_states as branch_state', 'branch_state.id', '=', 'et_branch.state_id')
      ->leftJoin('et_states as customer_state', 'customer_state.id', '=', 'et_customer.state')
      ->leftJoin('et_cities as branch_city', 'branch_city.id', '=', 'et_branch.city_id')
      ->leftJoin('et_cities as customer_city', 'customer_city.id', '=', 'et_customer.city')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_nda.staff_id')
      ->where('et_manage_nda.sno', $decryptedValue)->first();
      
      $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $edit->branch_id)
            ->first();
     $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
    return view('content.customer_management.manage_nda.nda_view', compact('edit', 'id','terms'));
  }

  public function ndaPrint($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $edit = ManageNDAModel::where('et_manage_nda.status', '!=', 2)
      ->select(
        'et_manage_nda.*',
        'et_customer.cus_name',
        'et_customer.cus_email_id',
        'et_branch.branch_name',
        'et_branch.door_no as branch_door',
        'et_branch.area_street',
        'et_branch.country_id',
        'et_branch.state_id',
        'et_branch.city_id',
        'et_branch.pincode',
        'branch_country.id',
        'customer_country.id',
        'branch_state.id',
        'customer_state.id',
        'branch_city.id',
        'customer_city.id',
        'et_customer.state',
        'et_customer.country',
        'et_customer.city',
        'branch_country.name as branch_country_name',
        'customer_country.name as customer_country_name',
        'branch_state.name as branch_state_name',
        'customer_state.name as customer_state_name',
        'branch_city.name as branch_city_name',
        'customer_city.name as customer_city_name',
        'et_customer.door_no',
        'et_customer.address',
        'et_staff.staff_name'
      )
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_nda.customer_id')
      ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_manage_nda.branch_id')
      ->leftJoin('et_countries as branch_country', 'branch_country.id', '=', 'et_branch.country_id')
      ->leftJoin('et_countries as customer_country', 'customer_country.id', '=', 'et_customer.country')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->leftJoin('et_states as branch_state', 'branch_state.id', '=', 'et_branch.state_id')
      ->leftJoin('et_states as customer_state', 'customer_state.id', '=', 'et_customer.state')
      ->leftJoin('et_cities as branch_city', 'branch_city.id', '=', 'et_branch.city_id')
      ->leftJoin('et_cities as customer_city', 'customer_city.id', '=', 'et_customer.city')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_nda.staff_id')
      ->where('et_manage_nda.sno', $decryptedValue)->first();
      
      $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $edit->branch_id)
            ->first();
     $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
    return view('content.customer_management.manage_nda.nda_print', compact('edit', 'id','terms'));
  }
  
  public function NdaSignedConfirm(Request $request)
{
    $nda_id = $request->nda_id;

    $ndaData = DB::table('et_manage_nda')->where('sno', $nda_id)->first();
    if (!$ndaData) {
       return response()->json(['status' => 'error', 'message' => 'NDA record not found.']);
    }

    $destinationPath = public_path("ndaSignature/$nda_id");

    // Ensure directory exists
    if (!file_exists($destinationPath)) {
        if (!mkdir($destinationPath, 0755, true) && !is_dir($destinationPath)) {
          return response()->json(['status' => 'error', 'message' => 'Failed to create signature directory.']);
        }
    }

    $filesToUpdate = [];

    if ($request->signature_1) {
        $fileName = 'signature_1.png';
        $this->saveBase64Image($request->signature_1, "$destinationPath/$fileName");
        $filesToUpdate['nda_sign_img_1'] = $fileName;
    }

    if ($request->signature_2) {
        $fileName = 'signature_2.png';
        $this->saveBase64Image($request->signature_2, "$destinationPath/$fileName");
        $filesToUpdate['nda_sign_img_2'] = $fileName;
    }

    if ($request->signature_3) {
        $fileName = 'signature_3.png';
        $this->saveBase64Image($request->signature_3, "$destinationPath/$fileName");
        $filesToUpdate['nda_sign_img_3'] = $fileName;
    }

    if ($request->signature_4) {
        $fileName = 'signature_4.png';
        $this->saveBase64Image($request->signature_4, "$destinationPath/$fileName");
        $filesToUpdate['nda_sign_img_4'] = $fileName;
    }

    if (!empty($filesToUpdate)) {
        // Update the signatures and status in a single query
        $filesToUpdate['status'] = 1;
        DB::table('et_manage_nda')->where('sno', $nda_id)->update($filesToUpdate);

        // Update proposal flag
        if (!empty($ndaData->proposal_id)) {
            DB::table('et_proposal')->where('sno', $ndaData->proposal_id)->update([
                'nda_signed' => 1
            ]);
        }

        $encrypt_id_nda = $nda_id ;
        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($encrypt_id_nda, 'encrypt');
        return response()->json(['status' => 'success', 'id' => $encrypted_values, 'message' => 'ThankYou For NDA Sign.']);
    }

     return response()->json(['status' => 'warning', 'message' => 'No signatures found to save.']);
}

    function saveBase64Image($base64Image, $path)
    {
        if (preg_match('/^data:image\/(\w+);base64,/', $base64Image)) {
            $base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
            $base64Image = base64_decode($base64Image);
            if ($base64Image === false) {
                return false;
            }
        } else {
            return false;
        }
        return file_put_contents($path, $base64Image);
    }
    
    
     public function ndaDownload($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $edit = ManageNDAModel::where('et_manage_nda.status', '!=', 2)
      ->select(
        'et_manage_nda.*',
        'et_customer.cus_name',
        'et_customer.cus_email_id',
        'et_branch.branch_name',
        'et_branch.door_no as branch_door',
        'et_branch.area_street',
        'et_branch.country_id',
        'et_branch.state_id',
        'et_branch.city_id',
        'et_branch.pincode',
        'branch_country.id',
        'customer_country.id',
        'branch_state.id',
        'customer_state.id',
        'branch_city.id',
        'customer_city.id',
        'et_customer.state',
        'et_customer.country',
        'et_customer.city',
        'branch_country.name as branch_country_name',
        'customer_country.name as customer_country_name',
        'branch_state.name as branch_state_name',
        'customer_state.name as customer_state_name',
        'branch_city.name as branch_city_name',
        'customer_city.name as customer_city_name',
        'et_customer.door_no',
        'et_customer.address',
        'et_staff.staff_name'
      )
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_nda.customer_id')
      ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_manage_nda.branch_id')
      ->leftJoin('et_countries as branch_country', 'branch_country.id', '=', 'et_branch.country_id')
      ->leftJoin('et_countries as customer_country', 'customer_country.id', '=', 'et_customer.country')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->leftJoin('et_states as branch_state', 'branch_state.id', '=', 'et_branch.state_id')
      ->leftJoin('et_states as customer_state', 'customer_state.id', '=', 'et_customer.state')
      ->leftJoin('et_cities as branch_city', 'branch_city.id', '=', 'et_branch.city_id')
      ->leftJoin('et_cities as customer_city', 'customer_city.id', '=', 'et_customer.city')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_nda.staff_id')
      ->where('et_manage_nda.sno', $decryptedValue)->first();
      
      $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $edit->branch_id)
            ->first();
     $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
    // return view('content.customer_management.manage_nda.nda_download', compact('edit', 'id','terms'));
    $pdf = PDF::loadView('content.customer_management.manage_nda.nda_download', [
            'edit' =>$edit,
              'id' =>$id,
              'terms' =>$terms,
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        // return $pdf->stream('nda_print.pdf');
        return $pdf->download('nda_print.pdf');   
  }
  
   public function NDASuccess($id ,Request $request){
         
        

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    //   return $decryptedValue;
     
      $edit = ManageNDAModel::where('et_manage_nda.status', '!=', 2)
          ->select(
            'et_manage_nda.*',
            'et_customer.cus_name',
            'et_customer.cus_email_id',
            'et_branch.branch_name',
            'et_branch.door_no as branch_door',
            'et_branch.area_street',
            'et_branch.country_id',
            'et_branch.state_id',
            'et_branch.city_id',
            'et_branch.pincode',
            'branch_country.id',
            'customer_country.id',
            'branch_state.id',
            'customer_state.id',
            'branch_city.id',
            'customer_city.id',
            'et_customer.state',
            'et_customer.country',
            'et_customer.city',
            'branch_country.name as branch_country_name',
            'customer_country.name as customer_country_name',
            'branch_state.name as branch_state_name',
            'customer_state.name as customer_state_name',
            'branch_city.name as branch_city_name',
            'customer_city.name as customer_city_name',
            'et_customer.door_no',
            'et_customer.address',
            'et_staff.staff_name'
          )
          ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_nda.customer_id')
          ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_manage_nda.branch_id')
          ->leftJoin('et_countries as branch_country', 'branch_country.id', '=', 'et_branch.country_id')
          ->leftJoin('et_countries as customer_country', 'customer_country.id', '=', 'et_customer.country')
          ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
          ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
          ->leftJoin('et_states as branch_state', 'branch_state.id', '=', 'et_branch.state_id')
          ->leftJoin('et_states as customer_state', 'customer_state.id', '=', 'et_customer.state')
          ->leftJoin('et_cities as branch_city', 'branch_city.id', '=', 'et_branch.city_id')
          ->leftJoin('et_cities as customer_city', 'customer_city.id', '=', 'et_customer.city')
          ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_nda.staff_id')
          ->where('et_manage_nda.sno', $decryptedValue)->first();
          
          $download_url=url('nda_download/' . $id);
      return view('content.customer_management.manage_nda.nda_thanks',[
        'download_url'=>$download_url,
      ]);
    }

}
