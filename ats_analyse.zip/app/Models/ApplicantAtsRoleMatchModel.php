<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantAtsRoleMatchModel extends Model
{
    protected $table = 'egc_applicant_ats_role_matches';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $fillable = [
        'analysis_sno', 'applicant_sno', 'role_sno', 'role_code', 'role_name',
        'role_family', 'seniority_level', 'match_score', 'semantic_fit_score',
        'decision', 'education_alignment_score', 'mandatory_skill_coverage',
        'education_requirement_coverage', 'candidate_experience_years',
        'required_experience_years', 'confidence_score', 'scoring_version',
        'title_alignment_score', 'skill_alignment_score', 'experience_alignment_score',
        'responsibility_alignment_score', 'seniority_alignment_score',
        'evidence_quality_score', 'reason', 'evidence_json', 'gaps_json',
        'created_at', 'updated_at',
    ];

    protected $casts = [
        'evidence_json' => 'array',
        'gaps_json' => 'array',
    ];
}
