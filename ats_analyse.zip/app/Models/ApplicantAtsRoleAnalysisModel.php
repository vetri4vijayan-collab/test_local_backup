<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantAtsRoleAnalysisModel extends Model
{
    protected $table = 'egc_applicant_ats_role_analyses';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $fillable = [
        'applicant_sno', 'run_sno', 'schema_version', 'engine', 'model',
        'source_type', 'source_label', 'role_catalog_hash', 'resume_sha256',
        'resume_chars', 'overall_match_score', 'best_role_score', 'resume_quality_score',
        'match_count', 'role_catalog_size', 'semantic_candidate_count',
        'candidate_data_confidence', 'review_required', 'retrieval_model',
        'scoring_version', 'analysis_json', 'processed_at', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'analysis_json' => 'array',
        'review_required' => 'boolean',
        'processed_at' => 'datetime',
        'overall_match_score' => 'decimal:2',
        'best_role_score' => 'decimal:2',
        'resume_quality_score' => 'decimal:2',
        'candidate_data_confidence' => 'decimal:2',
    ];
}
