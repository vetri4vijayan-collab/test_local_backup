<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantResumeExtractionModel extends Model
{
    protected $table = 'egc_applicant_resume_extractions';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $fillable = [
        'applicant_sno', 'resume_sha256', 'source_filename', 'parser_version',
        'ai_primary_model', 'ai_verifier_model', 'ai_verified', 'review_required',
        'confidence', 'resume_chars', 'extracted_json', 'evidence_json',
        'processed_at', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'extracted_json' => 'array',
        'evidence_json' => 'array',
        'ai_verified' => 'boolean',
        'review_required' => 'boolean',
        'processed_at' => 'datetime',
    ];
}
