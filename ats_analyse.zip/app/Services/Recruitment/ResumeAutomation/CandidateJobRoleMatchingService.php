<?php

namespace App\Services\Recruitment\ResumeAutomation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Explainable, local ATS role matcher for egc_recruitment_roles.
 *
 * It deliberately makes no LLM calls. It uses active role master metadata,
 * optional per-role profiles from egc_recruitment_role_match_profiles, and a
 * conservative built-in taxonomy when profile rows/fields are not configured.
 */
class CandidateJobRoleMatchingService
{
    public const VERSION = '2026-10-16.1';
    public const PROFILE_TABLE = 'egc_recruitment_role_match_profiles';
    public const DEFAULT_LIMIT = 8;
    public const HARD_LIMIT = 12;
    public const DEFAULT_MIN_SCORE = 27;

    /** @var array<string,array<string,array<int,string>>> */
    private const TAXONOMY = [
        'sales' => [
            'education' => ['business administration', 'business management', 'marketing', 'commerce', 'BBA', 'MBA'],
            'employment' => ['sales executive', 'inside sales', 'field sales', 'retail sales', 'sales representative', 'sales target', 'sales targets', 'revenue target', 'customer acquisition', 'lead conversion', 'account management', 'sales operations'],
            'internship' => ['sales intern', 'sales internship', 'business development intern', 'retail sales intern', 'lead generation intern', 'marketing and sales intern'],
            'skills' => ['lead generation', 'cold calling', 'negotiation', 'sales pitch', 'sales pipeline', 'CRM', 'customer acquisition', 'client handling', 'sales reporting', 'upselling', 'cross selling', 'target achievement'],
            'titles' => ['sales associate', 'sales officer', 'sales representative', 'sales consultant', 'territory sales', 'retail sales'],
        ],
        'business_development' => [
            'education' => ['business administration', 'business management', 'marketing', 'commerce', 'BBA', 'MBA'],
            'employment' => ['business development', 'client acquisition', 'market expansion', 'lead generation', 'sales pipeline', 'partnership development', 'client relationship', 'account growth'],
            'internship' => ['business development intern', 'business development internship', 'growth intern', 'sales and business development intern'],
            'skills' => ['lead generation', 'cold calling', 'client acquisition', 'proposal writing', 'negotiation', 'CRM', 'market research', 'sales pipeline', 'partnerships', 'client pitching'],
            'titles' => ['BDE', 'business development associate', 'growth executive', 'partnership executive'],
        ],
        'marketing' => [
            'education' => ['marketing', 'business administration', 'mass communication', 'advertising', 'commerce', 'BBA', 'MBA'],
            'employment' => ['marketing executive', 'marketing campaign', 'market research', 'brand management', 'advertising campaign', 'marketing strategy', 'customer segmentation', 'market analysis', 'digital marketing', 'search engine optimization', 'search engine marketing', 'performance marketing'],
            'internship' => ['marketing intern', 'marketing internship', 'brand marketing intern', 'market research intern', 'digital marketing intern', 'SEO intern', 'social media intern', 'performance marketing intern'],
            'skills' => ['market research', 'brand strategy', 'campaign management', 'advertising', 'content marketing', 'market analysis', 'marketing analytics', 'customer segmentation', 'copywriting', 'SEO', 'SEM', 'Google Ads', 'Meta Ads', 'social media marketing', 'Google Analytics', 'performance marketing'],
            'titles' => ['marketing associate', 'brand executive', 'marketing coordinator'],
        ],
        'production' => [
            'education' => ['mechanical engineering', 'industrial engineering', 'production engineering', 'manufacturing engineering', 'industrial production', 'diploma in mechanical', 'mechatronics'],
            'employment' => ['production planning', 'manufacturing', 'shop floor', 'assembly line', 'production supervisor', 'machine operation', 'factory operations', 'production scheduling', 'quality control', 'inventory control'],
            'internship' => ['production intern', 'manufacturing intern', 'industrial training', 'production internship', 'plant internship'],
            'skills' => ['lean manufacturing', '5S', 'six sigma', 'production planning', 'inventory control', 'quality control', 'machine operation', 'safety compliance', 'process optimization', 'ERP production'],
            'titles' => ['production operator', 'production supervisor', 'plant operator', 'manufacturing associate'],
        ],
        'process' => [
            'education' => ['business administration', 'operations management', 'commerce', 'computer applications', 'BBA', 'BCom'],
            'employment' => ['process executive', 'process operations', 'business process', 'back office operations', 'data processing', 'workflow management', 'SOP compliance', 'service level agreement', 'BPO', 'KPO'],
            'internship' => ['process intern', 'operations intern', 'business process intern', 'back office intern'],
            'skills' => ['process improvement', 'SOP', 'data entry', 'data validation', 'workflow management', 'MIS reporting', 'Excel', 'quality assurance', 'documentation', 'SLA'],
            'titles' => ['operations associate', 'process associate', 'back office executive'],
        ],
        'customer_relationship' => [
            'education' => ['business administration', 'customer relationship management', 'commerce', 'communication', 'BBA'],
            'employment' => ['customer service', 'customer support', 'customer relationship', 'client servicing', 'customer success', 'customer retention', 'grievance handling', 'complaint resolution', 'call center', 'contact center'],
            'internship' => ['customer support intern', 'customer service intern', 'client servicing intern', 'customer success intern'],
            'skills' => ['CRM', 'customer satisfaction', 'complaint resolution', 'customer retention', 'client communication', 'ticketing system', 'escalation handling', 'customer onboarding', 'call handling'],
            'titles' => ['customer care executive', 'client service executive', 'customer success associate', 'support representative'],
        ],
        'software_engineering' => [
            'education' => ['computer science', 'computer engineering', 'information technology', 'computer applications', 'BCA', 'MCA', 'software engineering', 'CSE', 'IT engineering'],
            'employment' => ['software developer', 'software engineer', 'application development', 'web development', 'backend development', 'front end development', 'API development', 'database development', 'software maintenance', 'full stack development'],
            'internship' => ['software developer intern', 'software engineering intern', 'web development intern', 'backend developer intern', 'frontend developer intern', 'full stack developer intern', 'programming internship'],
            'skills' => ['programming', 'Java', 'Python', 'PHP', 'Laravel', 'JavaScript', 'TypeScript', 'React', 'Angular', 'Vue', 'Node.js', 'REST API', 'MySQL', 'PostgreSQL', 'Git', 'HTML', 'CSS', 'software testing', 'object oriented programming', 'OOP'],
            'titles' => ['software developer', 'software engineer', 'application developer', 'programmer'],
        ],
        'ui_ux' => [
            'education' => ['UI UX design', 'interaction design', 'visual communication', 'graphic design', 'design', 'human computer interaction'],
            'employment' => ['UI UX designer', 'user experience design', 'user interface design', 'interaction design', 'product design', 'design system', 'wireframing', 'prototyping'],
            'internship' => ['UI UX intern', 'UX design intern', 'UI design intern', 'product design intern', 'design internship'],
            'skills' => ['Figma', 'Adobe XD', 'Sketch', 'wireframes', 'prototyping', 'user research', 'usability testing', 'design systems', 'user journeys', 'information architecture', 'figma components'],
            'titles' => ['UX designer', 'UI designer', 'product designer', 'interaction designer'],
        ],
        'web_design' => [
            'education' => ['web design', 'graphic design', 'visual communication', 'multimedia', 'computer applications'],
            'employment' => ['web designer', 'website design', 'landing page design', 'responsive web design', 'website maintenance', 'visual design'],
            'internship' => ['web design intern', 'website design intern', 'web designer intern'],
            'skills' => ['HTML', 'CSS', 'responsive design', 'Bootstrap', 'WordPress', 'Figma', 'Adobe Photoshop', 'Adobe Illustrator', 'Canva', 'UI design', 'web layout'],
            'titles' => ['website designer', 'visual web designer', 'web design specialist'],
        ],
        'project_management' => [
            'education' => ['project management', 'engineering', 'business administration', 'MBA', 'operations management'],
            'employment' => ['project manager', 'project coordinator', 'project planning', 'project delivery', 'project schedule', 'stakeholder management', 'budget tracking', 'team lead', 'cross functional team'],
            'internship' => ['project management intern', 'project coordinator intern', 'project intern'],
            'skills' => ['Agile', 'Scrum', 'Jira', 'project planning', 'risk management', 'stakeholder management', 'Gantt chart', 'project scheduling', 'resource allocation', 'sprint planning'],
            'titles' => ['project lead', 'program coordinator', 'delivery manager'],
        ],
        'quality_assurance' => [
            'education' => ['computer science', 'information technology', 'computer applications', 'software engineering', 'CSE', 'BCA', 'MCA'],
            'employment' => ['software tester', 'QA engineer', 'quality assurance', 'manual testing', 'automation testing', 'test case design', 'defect tracking', 'regression testing'],
            'internship' => ['QA intern', 'software testing intern', 'quality assurance intern', 'testing internship'],
            'skills' => ['Selenium', 'Cypress', 'Playwright', 'Postman', 'JMeter', 'test cases', 'test plans', 'bug tracking', 'regression testing', 'API testing', 'manual testing', 'automation testing'],
            'titles' => ['QA analyst', 'test engineer', 'quality analyst', 'software test engineer'],
        ],
        'devops' => [
            'education' => ['computer science', 'information technology', 'cloud computing', 'computer engineering', 'CSE', 'IT engineering'],
            'employment' => ['DevOps engineer', 'CI CD pipeline', 'continuous integration', 'continuous deployment', 'cloud infrastructure', 'infrastructure automation', 'site reliability', 'release engineering'],
            'internship' => ['DevOps intern', 'cloud engineer intern', 'site reliability intern', 'DevOps internship'],
            'skills' => ['Docker', 'Kubernetes', 'Jenkins', 'GitHub Actions', 'GitLab CI', 'Terraform', 'AWS', 'Azure', 'GCP', 'Linux', 'CI/CD', 'Ansible', 'monitoring', 'containerization'],
            'titles' => ['cloud engineer', 'platform engineer', 'site reliability engineer', 'SRE'],
        ],
        'network_engineering' => [
            'education' => ['computer networks', 'network engineering', 'information technology', 'electronics and communication', 'ECE', 'computer science'],
            'employment' => ['network engineer', 'network administration', 'routing and switching', 'network troubleshooting', 'firewall administration', 'LAN WAN', 'network security'],
            'internship' => ['network engineer intern', 'networking intern', 'network administration intern'],
            'skills' => ['TCP/IP', 'CCNA', 'CCNP', 'routing', 'switching', 'Cisco', 'firewall', 'LAN', 'WAN', 'DNS', 'DHCP', 'VPN', 'network monitoring'],
            'titles' => ['network administrator', 'network support engineer', 'NOC engineer'],
        ],
        'digital_marketing' => [
            'education' => ['digital marketing', 'marketing', 'mass communication', 'business administration', 'advertising'],
            'employment' => ['digital marketing', 'search engine optimization', 'search engine marketing', 'social media marketing', 'paid advertising', 'performance marketing', 'marketing analytics'],
            'internship' => ['digital marketing intern', 'SEO intern', 'social media intern', 'performance marketing intern'],
            'skills' => ['SEO', 'SEM', 'Google Ads', 'Meta Ads', 'Google Analytics', 'social media', 'content strategy', 'keyword research', 'email marketing', 'PPC', 'conversion rate optimization', 'marketing automation'],
            'titles' => ['SEO executive', 'social media executive', 'performance marketing specialist', 'PPC specialist'],
        ],
        'training' => [
            'education' => ['education', 'BEd', 'MEd', 'computer science', 'information technology', 'network engineering', 'digital marketing', 'electronics', 'engineering'],
            'employment' => ['trainer', 'instructor', 'technical trainer', 'training delivery', 'classroom training', 'curriculum development', 'training coordinator', 'learning facilitator'],
            'internship' => ['teaching intern', 'trainer intern', 'training assistant', 'teaching practice', 'instructional design intern'],
            'skills' => ['lesson planning', 'curriculum development', 'classroom management', 'training delivery', 'student assessment', 'learning management system', 'technical instruction', 'public speaking'],
            'titles' => ['faculty', 'instructor', 'technical instructor', 'training specialist'],
        ],
        'embedded' => [
            'education' => ['electronics and communication', 'electrical engineering', 'electronics engineering', 'embedded systems', 'instrumentation', 'mechatronics', 'ECE', 'EEE'],
            'employment' => ['embedded developer', 'firmware development', 'microcontroller programming', 'embedded systems', 'device driver', 'RTOS', 'hardware software integration'],
            'internship' => ['embedded systems intern', 'firmware intern', 'electronics intern', 'embedded developer intern'],
            'skills' => ['C programming', 'C++', 'microcontroller', 'ARM', '8051', 'Arduino', 'Raspberry Pi', 'RTOS', 'firmware', 'PCB', 'UART', 'SPI', 'I2C', 'IoT', 'embedded C'],
            'titles' => ['firmware engineer', 'embedded software engineer', 'embedded systems engineer'],
        ],
        'placement' => [
            'education' => ['business administration', 'human resources', 'management', 'career counseling', 'MBA', 'BBA'],
            'employment' => ['placement officer', 'campus placement', 'placement coordination', 'employer relations', 'campus recruitment', 'career guidance', 'placement drive'],
            'internship' => ['placement intern', 'HR intern', 'career services intern'],
            'skills' => ['employer engagement', 'campus recruitment', 'student counseling', 'placement coordination', 'interview scheduling', 'job fair', 'recruiter relationship', 'career guidance'],
            'titles' => ['placement coordinator', 'career services executive', 'campus recruiter'],
        ],
        'human_resources' => [
            'education' => ['human resources', 'HRM', 'business administration', 'personnel management', 'industrial relations', 'MBA HR', 'BBA'],
            'employment' => ['human resources', 'HR executive', 'employee relations', 'employee onboarding', 'payroll processing', 'HR operations', 'performance management', 'employee engagement'],
            'internship' => ['HR intern', 'human resources intern', 'HR internship', 'people operations intern'],
            'skills' => ['HRMS', 'payroll', 'onboarding', 'employee engagement', 'attendance management', 'leave management', 'performance appraisal', 'labour law', 'employee relations', 'HR documentation'],
            'titles' => ['HR generalist', 'people operations', 'personnel executive', 'HR business partner'],
        ],
        'recruitment' => [
            'education' => ['human resources', 'HRM', 'business administration', 'psychology', 'management', 'MBA HR'],
            'employment' => ['recruitment executive', 'talent acquisition', 'full cycle recruitment', 'candidate sourcing', 'interview coordination', 'recruitment process', 'staffing', 'headhunting'],
            'internship' => ['recruitment intern', 'talent acquisition intern', 'HR recruiter intern', 'staffing intern'],
            'skills' => ['ATS', 'Boolean search', 'candidate sourcing', 'screening resumes', 'interview scheduling', 'recruitment metrics', 'LinkedIn Recruiter', 'job portals', 'talent pipeline', 'offer management'],
            'titles' => ['talent acquisition specialist', 'HR recruiter', 'technical recruiter', 'staffing specialist'],
        ],
        'finance_accounts' => [
            'education' => ['commerce', 'accounting', 'finance', 'BCom', 'MCom', 'CA', 'CMA', 'accountancy'],
            'employment' => ['accounts executive', 'accountant', 'accounts payable', 'accounts receivable', 'bookkeeping', 'GST filing', 'bank reconciliation', 'taxation', 'financial statements', 'audit assistance'],
            'internship' => ['accounts intern', 'accounting intern', 'finance intern', 'audit intern', 'tax intern'],
            'skills' => ['Tally', 'Tally ERP', 'Tally Prime', 'GST', 'TDS', 'Excel', 'SAP FICO', 'bank reconciliation', 'accounts payable', 'accounts receivable', 'bookkeeping', 'tax return', 'financial reporting'],
            'titles' => ['accountant', 'finance associate', 'audit assistant', 'accounts assistant'],
        ],
        'front_office' => [
            'education' => ['office administration', 'hospitality', 'travel and tourism', 'business administration', 'communication'],
            'employment' => ['receptionist', 'front desk', 'front office', 'visitor management', 'appointment scheduling', 'telephone operator', 'guest relations'],
            'internship' => ['front office intern', 'reception intern', 'hospitality intern'],
            'skills' => ['visitor management', 'appointment scheduling', 'telephone handling', 'EPABX', 'front desk operations', 'customer greeting', 'office coordination'],
            'titles' => ['front office associate', 'reception executive', 'guest relations executive'],
        ],
        'counseling' => [
            'education' => ['psychology', 'counseling', 'education', 'social work', 'human development', 'career counseling'],
            'employment' => ['student counseling', 'career counseling', 'academic counseling', 'admission counseling', 'student guidance', 'counselor'],
            'internship' => ['counseling intern', 'school counseling intern', 'student counselor intern'],
            'skills' => ['career guidance', 'student counseling', 'admission counseling', 'psychometric assessment', 'active listening', 'case documentation', 'academic advising'],
            'titles' => ['career counselor', 'academic advisor', 'admission counselor', 'student counselor'],
        ],
        'business_analysis' => [
            'education' => ['business analytics', 'business administration', 'computer science', 'information systems', 'information technology', 'MBA', 'statistics'],
            'employment' => ['business analyst', 'business analysis', 'requirements gathering', 'process mapping', 'business requirements', 'user stories', 'UAT', 'stakeholder interviews'],
            'internship' => ['business analyst intern', 'business analysis intern', 'data analyst intern', 'product analyst intern'],
            'skills' => ['SQL', 'Excel', 'Power BI', 'Tableau', 'BRD', 'FRD', 'user stories', 'Jira', 'process mapping', 'requirements analysis', 'UAT', 'data visualization'],
            'titles' => ['business systems analyst', 'requirements analyst', 'product analyst', 'functional analyst'],
        ],
        'mobile_development' => [
            'education' => ['computer science', 'information technology', 'computer applications', 'mobile application development', 'BCA', 'MCA', 'CSE'],
            'employment' => ['mobile app developer', 'Android development', 'iOS development', 'mobile application development', 'cross platform app development'],
            'internship' => ['mobile app developer intern', 'Android intern', 'Flutter intern', 'iOS developer intern'],
            'skills' => ['Flutter', 'Dart', 'Android Studio', 'Kotlin', 'Swift', 'React Native', 'Firebase', 'mobile UI', 'app store deployment', 'REST API integration'],
            'titles' => ['Android developer', 'iOS developer', 'Flutter developer', 'React Native developer'],
        ],
        'content' => [
            'education' => ['English literature', 'English', 'journalism', 'mass communication', 'communications', 'creative writing', 'linguistics'],
            'employment' => ['content writer', 'copywriter', 'technical writer', 'blog writing', 'content editing', 'content strategy', 'editorial calendar'],
            'internship' => ['content writing intern', 'copywriting intern', 'editorial intern', 'technical writing intern'],
            'skills' => ['SEO writing', 'copywriting', 'blog writing', 'editing', 'proofreading', 'content strategy', 'keyword research', 'technical documentation', 'editorial planning', 'grammar'],
            'titles' => ['copywriter', 'editor', 'technical writer', 'content specialist'],
        ],
        'administration' => [
            'education' => ['business administration', 'office administration', 'management', 'commerce', 'BBA', 'MBA'],
            'employment' => ['administration executive', 'office administration', 'office operations', 'vendor management', 'facility management', 'office coordination', 'records management', 'procurement'],
            'internship' => ['administration intern', 'office admin intern', 'operations intern', 'admin assistant intern'],
            'skills' => ['MS Office', 'Excel', 'documentation', 'vendor coordination', 'procurement', 'facility coordination', 'record keeping', 'travel arrangements', 'inventory management', 'office management'],
            'titles' => ['administrative assistant', 'office administrator', 'administration officer', 'facility coordinator'],
        ],
        'transportation' => [
            'education' => ['driving licence', 'driving license', 'commercial driving', 'heavy vehicle driving', 'transportation'],
            'employment' => ['driver', 'commercial vehicle', 'heavy vehicle', 'light motor vehicle', 'fleet driving', 'route delivery', 'transport driver'],
            'internship' => ['driver trainee', 'driving trainee'],
            'skills' => ['valid driving licence', 'valid driving license', 'defensive driving', 'route planning', 'vehicle maintenance', 'road safety', 'GPS navigation', 'LMV', 'HMV', 'transport documentation'],
            'titles' => ['chauffeur', 'delivery driver', 'fleet driver', 'commercial driver'],
        ],
        'field_operations' => [
            'education' => ['business administration', 'commerce', 'social work', 'field operations', 'marketing'],
            'employment' => ['field executive', 'field operations', 'field visit', 'customer visit', 'field survey', 'collection executive', 'field verification', 'on ground operations'],
            'internship' => ['field intern', 'field operations intern', 'survey intern', 'field sales intern'],
            'skills' => ['field survey', 'customer visits', 'field verification', 'data collection', 'route planning', 'reporting', 'collections', 'on ground coordination', 'geotagging'],
            'titles' => ['field officer', 'field investigator', 'field coordinator', 'field sales executive'],
        ],
    ];

    /** Return ATS role suggestions ranked with evidence; never throws into resume extraction. */
    public function matchResume(string $resumeText, int $limit = self::DEFAULT_LIMIT): array
    {
        $resumeText = trim($resumeText);
        if ($resumeText === '') {
            return $this->emptyResult('empty_resume_text');
        }

        try {
            $roles = DB::table('egc_recruitment_roles')
                ->where('status', 0)
                ->where('match_enabled', 1)
                ->orderBy('role_name')
                ->get([
                    'sno', 'role_code', 'role_name', 'role_family',
                    'seniority_level', 'description', 'role_description', 'mandatory_skills',
                    'preferred_skills', 'responsibilities', 'minimum_experience',
                    'education_requirements', 'seniority',
                ])->all();

            if (!$roles) {
                return $this->emptyResult('no_active_roles');
            }

            $profiles = [];
            try {
                if (Schema::hasTable(self::PROFILE_TABLE)) {
                    $profiles = DB::table(self::PROFILE_TABLE)
                        ->where('status', 0)
                        ->whereIn('role_code', array_map(static fn ($role) => (string) ($role->role_code ?? ''), $roles))
                        ->get()->keyBy('role_code')->all();
                }
            } catch (Throwable $profileError) {
                // The profile table is optional. Continue with the built-in taxonomy
                // if it has not been migrated yet or is temporarily unavailable.
                Log::warning('Optional role-match profiles unavailable; using baseline role taxonomy.', [
                    'service_version' => self::VERSION,
                    'exception' => get_class($profileError),
                ]);
            }

            return $this->matchAgainstCatalog($resumeText, $roles, $profiles, $limit);
        } catch (Throwable $e) {
            Log::warning('Candidate job-role matching could not read the role catalogue.', [
                'service_version' => self::VERSION,
                'exception' => get_class($e),
            ]);

            return $this->emptyResult('catalog_unavailable');
        }
    }

    /** Public for deterministic regression tests; $roles can be DB row objects or arrays. */
    public function matchAgainstCatalog(string $resumeText, array $roles, array $profiles = [], int $limit = self::DEFAULT_LIMIT): array
    {
        $resumeText = trim($resumeText);
        if ($resumeText === '' || !$roles) {
            return $this->emptyResult($resumeText === '' ? 'empty_resume_text' : 'no_active_roles');
        }

        $sections = $this->extractSections($resumeText);
        $matches = [];

        foreach ($roles as $rawRole) {
            $role = is_array($rawRole) ? (object) $rawRole : $rawRole;
            $roleId = (int) ($role->sno ?? $role->id ?? 0);
            $roleCode = strtoupper(trim((string) ($role->role_code ?? '')));
            $roleName = trim((string) ($role->role_name ?? $role->name ?? ''));
            if ($roleId <= 0 || $roleCode === '' || $roleName === '') {
                continue;
            }

            $profileRow = $profiles[$roleCode] ?? null;
            if (is_array($profileRow)) {
                $profileRow = (object) $profileRow;
            }
            $profile = $this->buildRoleProfile($role, $profileRow);
            $scored = $this->scoreRole($role, $profile, $sections);
            $minScore = max(15, min(75, (int) ($profileRow->minimum_match_score ?? self::DEFAULT_MIN_SCORE)));

            if ($scored['score'] < $minScore || !$scored['eligible']) {
                continue;
            }

            $matches[] = [
                'role_id' => $roleId,
                'role_code' => $roleCode,
                'role_name' => $roleName,
                'role_family' => trim((string) ($role->role_family ?? '')),
                'match_score' => $scored['score'],
                'match_band' => $this->matchBand($scored['score']),
                'evidence' => $scored['evidence'],
                'evidence_categories' => $scored['categories'],
                'seniority_level' => (int) ($role->seniority_level ?? 1),
            ];
        }

        usort($matches, static function (array $a, array $b): int {
            return ($b['match_score'] <=> $a['match_score'])
                ?: ($a['seniority_level'] <=> $b['seniority_level'])
                ?: strcmp($a['role_name'], $b['role_name']);
        });

        $limit = max(1, min(self::HARD_LIMIT, $limit));
        $matches = array_slice($matches, 0, $limit);
        $roleIds = array_values(array_unique(array_map(static fn ($row) => (int) $row['role_id'], $matches)));

        return [
            'status' => $matches ? 'matched' : 'no_reliable_match',
            'service_version' => self::VERSION,
            'matches' => $matches,
            'role_ids' => $roleIds,
            'match_count' => count($matches),
            'catalog_role_count' => count($roles),
        ];
    }

    private function buildRoleProfile(object $role, ?object $dbProfile): array
    {
        $code = strtoupper((string) ($role->role_code ?? ''));
        $family = strtolower((string) ($role->role_family ?? ''));
        $group = $this->taxonomyGroup($code, $family);
        $defaults = self::TAXONOMY[$group] ?? ['education' => [], 'employment' => [], 'internship' => [], 'skills' => [], 'titles' => []];
        $defaults = $this->applyRoleSpecificTaxonomy($code, $group, $defaults);

        $profile = [
            'education' => $defaults['education'] ?? [],
            'employment' => $defaults['employment'] ?? [],
            'internship' => $defaults['internship'] ?? [],
            'skills' => $defaults['skills'] ?? [],
            'titles' => array_values(array_unique(array_filter([
                (string) ($role->role_name ?? ''),
                str_replace('_', ' ', strtolower($code)),
                ...($defaults['titles'] ?? []),
            ]))),
            'exclude' => [],
        ];

        if ($dbProfile) {
            foreach ([
                'education' => 'education_keywords',
                'employment' => 'employment_keywords',
                'internship' => 'internship_keywords',
                'skills' => 'skill_keywords',
                'titles' => 'role_title_keywords',
                'exclude' => 'exclude_keywords',
            ] as $target => $column) {
                $profile[$target] = array_values(array_unique(array_merge(
                    $profile[$target],
                    $this->parseKeywords($dbProfile->{$column} ?? null)
                )));
            }
        }

        $profile['education'] = array_values(array_unique(array_merge(
            $profile['education'], $this->parseKeywords($role->education_requirements ?? null)
        )));
        $profile['skills'] = array_values(array_unique(array_merge(
            $profile['skills'],
            $this->parseKeywords($role->mandatory_skills ?? null),
            $this->parseKeywords($role->preferred_skills ?? null)
        )));
        $profile['employment'] = array_values(array_unique(array_merge(
            $profile['employment'], $this->parseKeywords($role->responsibilities ?? null)
        )));

        $longDescription = trim((string) ($role->role_description ?? $role->description ?? ''));
        if (strlen($longDescription) >= 45 && strlen($longDescription) > strlen((string) ($role->role_name ?? '')) * 2) {
            $profile['employment'] = array_values(array_unique(array_merge(
                $profile['employment'], $this->parseKeywords($longDescription)
            )));
        }

        // Role title and family are included as low-weight evidence, not treated
        // as a match by themselves. Configured database profiles are additive so
        // an empty optional profile column never disables the safe defaults.
        return $profile;
    }

    private function applyRoleSpecificTaxonomy(string $code, string $group, array $defaults): array
    {
        $specific = null;
        if (str_contains($code, 'FRONT_END_DEVELOPER')) {
            $specific = [
                'employment' => ['front end developer', 'frontend developer', 'front end development', 'frontend development', 'web interface development', 'user interface development', 'responsive web development'],
                'internship' => ['front end developer intern', 'frontend developer intern', 'front end development intern', 'frontend internship', 'UI development intern'],
                'skills' => ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React', 'Angular', 'Vue', 'Bootstrap', 'Tailwind CSS', 'responsive design', 'DOM manipulation', 'Next.js', 'accessibility', 'web components', 'frontend testing'],
                'titles' => ['front end developer', 'frontend developer', 'frontend engineer', 'UI developer', 'web UI developer'],
            ];
        } elseif (str_contains($code, 'BACK_END_DEVELOPER')) {
            $specific = [
                'employment' => ['back end developer', 'backend developer', 'back end development', 'backend development', 'server side development', 'API development', 'database development', 'microservices', 'web service development'],
                'internship' => ['back end developer intern', 'backend developer intern', 'backend development intern', 'server side intern', 'API development intern'],
                'skills' => ['PHP', 'Laravel', 'Symfony', 'Python', 'Django', 'Flask', 'Java', 'Spring Boot', 'Node.js', 'Express.js', 'MySQL', 'PostgreSQL', 'MongoDB', 'REST API', 'GraphQL', 'Redis', 'SQL', 'microservices', 'server side', 'API security'],
                'titles' => ['back end developer', 'backend developer', 'backend engineer', 'API developer', 'server side developer'],
            ];
        } elseif (str_contains($code, 'FULL_STACK_DEVELOPER')) {
            $specific = [
                'employment' => ['full stack developer', 'full-stack developer', 'full stack development', 'end to end web application', 'frontend and backend development'],
                'internship' => ['full stack developer intern', 'full-stack developer intern', 'full stack development intern'],
                'skills' => ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React', 'Angular', 'Vue', 'Bootstrap', 'PHP', 'Laravel', 'Python', 'Django', 'Java', 'Spring Boot', 'Node.js', 'Express.js', 'MySQL', 'PostgreSQL', 'MongoDB', 'REST API', 'GraphQL', 'Git'],
                'titles' => ['full stack developer', 'full-stack developer', 'full stack engineer', 'web application developer'],
            ];
        } elseif (str_contains($code, 'WEBSITE_DEVELOPER')) {
            $specific = [
                'employment' => ['website developer', 'website development', 'web developer', 'web development', 'CMS development', 'WordPress development', 'e commerce website', 'website maintenance'],
                'internship' => ['website developer intern', 'web developer intern', 'web development intern', 'WordPress intern'],
                'skills' => ['HTML', 'CSS', 'JavaScript', 'PHP', 'WordPress', 'WooCommerce', 'Shopify', 'Bootstrap', 'responsive design', 'SEO', 'MySQL', 'website deployment', 'domain hosting'],
                'titles' => ['website developer', 'web developer', 'WordPress developer', 'web application developer'],
            ];
        } elseif (str_contains($code, 'DIGITAL_MARKETING_TRAINER')) {
            $specific = [
                'employment' => ['digital marketing trainer', 'digital marketing instructor', 'SEO trainer', 'marketing trainer', 'digital marketing training', 'training delivery'],
                'internship' => ['digital marketing trainer intern', 'marketing trainer assistant', 'digital marketing teaching assistant'],
                'skills' => ['SEO', 'SEM', 'Google Ads', 'Meta Ads', 'Google Analytics', 'lesson planning', 'curriculum development', 'training delivery', 'student assessment', 'classroom training', 'public speaking'],
                'titles' => ['digital marketing trainer', 'SEO trainer', 'digital marketing instructor'],
            ];
        } elseif (str_contains($code, 'NETWORKING_TRAINER')) {
            $specific = [
                'employment' => ['networking trainer', 'network trainer', 'networking instructor', 'CCNA trainer', 'technical trainer', 'training delivery'],
                'internship' => ['network trainer intern', 'networking teaching assistant'],
                'skills' => ['TCP/IP', 'CCNA', 'CCNP', 'routing', 'switching', 'Cisco', 'firewall', 'lesson planning', 'curriculum development', 'training delivery', 'classroom training'],
                'titles' => ['networking trainer', 'network trainer', 'networking instructor'],
            ];
        } elseif (str_contains($code, 'EMBEDDED_TRAINER')) {
            $specific = [
                'employment' => ['embedded trainer', 'embedded systems trainer', 'electronics trainer', 'firmware instructor', 'technical trainer', 'training delivery'],
                'internship' => ['embedded trainer intern', 'electronics teaching assistant'],
                'skills' => ['C programming', 'C++', 'microcontroller', 'ARM', 'RTOS', 'firmware', 'Arduino', 'lesson planning', 'curriculum development', 'training delivery', 'classroom training'],
                'titles' => ['embedded trainer', 'embedded systems trainer', 'electronics instructor'],
            ];
        } elseif (str_contains($code, 'SOFTWARE_TRAINER')) {
            $specific = [
                'employment' => ['software trainer', 'programming trainer', 'coding instructor', 'software instructor', 'technical trainer', 'training delivery'],
                'internship' => ['software trainer intern', 'programming teaching assistant', 'coding instructor intern'],
                'skills' => ['programming', 'Java', 'Python', 'PHP', 'Laravel', 'JavaScript', 'HTML', 'CSS', 'lesson planning', 'curriculum development', 'training delivery', 'classroom training'],
                'titles' => ['software trainer', 'programming trainer', 'coding instructor', 'software instructor'],
            ];
        }

        if ($specific !== null) {
            foreach ($specific as $key => $values) {
                $defaults[$key] = $values;
            }
        }
        return $defaults;
    }

    private function taxonomyGroup(string $code, string $family): string
    {
        if (str_starts_with($code, 'BUSINESS_DEVELOPMENT_')) return 'business_development';
        if (str_starts_with($code, 'DIGITAL_MARKETING_TRAINER')) return 'training';
        if (str_starts_with($code, 'DIGITAL_MARKETING_')) return 'digital_marketing';
        if (str_starts_with($code, 'CUSTOMER_RELATIONSHIP_')) return 'customer_relationship';
        if (str_starts_with($code, 'SOFTWARE_TESTER')) return 'quality_assurance';
        if (str_starts_with($code, 'DEVOPS_')) return 'devops';
        if (str_starts_with($code, 'NETWORK_ENGINEER') || str_starts_with($code, 'NETWORKING_TRAINER')) return str_starts_with($code, 'NETWORKING_TRAINER') ? 'training' : 'network_engineering';
        if (str_starts_with($code, 'EMBEDDED_')) return str_starts_with($code, 'EMBEDDED_TRAINER') ? 'training' : 'embedded';
        if (str_starts_with($code, 'PROJECT_')) return 'project_management';
        if (str_starts_with($code, 'MOBILE_APP_') || str_starts_with($code, 'SENIOR_MOBILE_APP_')) return 'mobile_development';
        if (str_starts_with($code, 'FRONT_END_') || str_starts_with($code, 'BACK_END_') || str_starts_with($code, 'FULL_STACK_') || str_starts_with($code, 'SENIOR_FRONT_END_') || str_starts_with($code, 'SENIOR_BACK_END_') || str_starts_with($code, 'SENIOR_FULL_STACK_') || str_starts_with($code, 'WEBSITE_DEVELOPER') || str_starts_with($code, 'SENIOR_WEBSITE_DEVELOPER')) return 'software_engineering';
        if (str_starts_with($code, 'UI_UX_') || str_starts_with($code, 'SENIOR_UI_UX_')) return 'ui_ux';
        if (str_starts_with($code, 'WEB_DESIGNER') || str_starts_with($code, 'SENIOR_WEB_DESIGNER')) return 'web_design';
        if (str_starts_with($code, 'DIGITAL_MARKETING_TRAINER')) return 'training';
        if (str_starts_with($code, 'SOFTWARE_TRAINER')) return 'training';
        if (str_starts_with($code, 'SALES_')) return 'sales';
        if (str_starts_with($code, 'MARKETING_')) return 'marketing';
        if (str_starts_with($code, 'PRODUCTION_')) return 'production';
        if (str_starts_with($code, 'PROCESS_')) return 'process';
        if (str_starts_with($code, 'PLACEMENT_')) return 'placement';
        if (str_starts_with($code, 'HR_')) return 'human_resources';
        if (str_starts_with($code, 'RECRUITMENT_')) return 'recruitment';
        if (str_starts_with($code, 'ACCOUNT_')) return 'finance_accounts';
        if (str_starts_with($code, 'RECEPTIONIST')) return 'front_office';
        if (str_starts_with($code, 'ACADEMY_COUNSELOR') || str_starts_with($code, 'SENIOR_ACADEMY_COUNSELOR')) return 'counseling';
        if (str_starts_with($code, 'BRANCH_HEAD') || str_starts_with($code, 'CENTER_HEAD')) return 'administration';
        if (str_starts_with($code, 'BUSINESS_ANALYST') || str_starts_with($code, 'SENIOR_BUSINESS_ANALYST')) return 'business_analysis';
        if (str_starts_with($code, 'CONTENT_WRITER') || str_starts_with($code, 'SENIOR_CONTENT_WRITER')) return 'content';
        if (str_starts_with($code, 'ADMIN_')) return 'administration';
        if (str_starts_with($code, 'DRIVER')) return 'transportation';
        if (str_starts_with($code, 'FIELD_EXECUTIVE')) return 'field_operations';

        $familyMap = [
            'sales' => 'sales', 'business development' => 'business_development', 'marketing' => 'marketing',
            'production' => 'production', 'process operations' => 'process', 'customer relationship' => 'customer_relationship',
            'software engineering' => 'software_engineering', 'ui/ux & design' => 'ui_ux', 'ui/ux and design' => 'ui_ux',
            'project management' => 'project_management', 'quality assurance' => 'quality_assurance',
            'devops & infrastructure' => 'devops', 'devops and infrastructure' => 'devops',
            'digital marketing' => 'digital_marketing', 'embedded systems' => 'embedded', 'placement' => 'placement',
            'human resources' => 'human_resources', 'recruitment' => 'recruitment', 'finance & accounts' => 'finance_accounts',
            'finance and accounts' => 'finance_accounts', 'front office' => 'front_office',
            'academic counseling' => 'counseling', 'business analysis' => 'business_analysis',
            'mobile development' => 'mobile_development', 'content' => 'content', 'administration' => 'administration',
            'transportation' => 'transportation', 'field operations' => 'field_operations', 'training' => 'training',
        ];
        return $familyMap[$family] ?? '';
    }

    private function scoreRole(object $role, array $profile, array $sections): array
    {
        $employmentSource = $sections['employment'];
        $internshipSource = $sections['internship'];
        $skillSource = trim($sections['skills'] . ' ' . $sections['projects']);
        $educationSource = $sections['education'];
        $summarySource = $sections['summary'];
        $allSource = $sections['all'];
        $hasSectionStructure = $sections['has_sections'];

        $workHits = $this->matchKeywords($profile['employment'], $employmentSource);
        $internHits = $this->matchKeywords($profile['internship'], $internshipSource);
        $skillHits = $this->matchKeywords($profile['skills'], $skillSource);
        $educationHits = $this->matchKeywords($profile['education'], $educationSource);
        $titleAllHits = $this->matchKeywords($profile['titles'], $allSource);
        $titleWorkHits = array_values(array_unique(array_merge(
            $this->matchKeywords($profile['titles'], $employmentSource),
            $this->matchKeywords($profile['titles'], $internshipSource)
        )));
        $titleSummaryHits = $this->matchKeywords($profile['titles'], $summarySource);

        // If headings were lost during PDF conversion, use the full text only at
        // lower weights. Never let education/title words alone create broad matches.
        $generalWorkHits = $hasSectionStructure ? [] : $this->matchKeywords($profile['employment'], $allSource);
        $generalInternHits = $hasSectionStructure ? [] : $this->matchKeywords($profile['internship'], $allSource);
        $generalSkillHits = $hasSectionStructure ? [] : $this->matchKeywords($profile['skills'], $allSource);
        $generalEducationHits = $hasSectionStructure ? [] : $this->matchKeywords($profile['education'], $allSource);

        $score = 0;
        $evidence = [];
        $categories = [];
        $excludeHits = $this->matchKeywords($profile['exclude'] ?? [], $allSource);

        if ($workHits) {
            $score += min(42, count($workHits) * 15);
            $evidence[] = 'Work history: ' . implode(', ', array_slice($workHits, 0, 4));
            $categories[] = 'employment';
        }
        if ($internHits) {
            $score += min(32, count($internHits) * 13);
            $evidence[] = 'Internship: ' . implode(', ', array_slice($internHits, 0, 4));
            $categories[] = 'internship';
        }
        if ($skillHits) {
            $score += min(28, count($skillHits) * 8);
            $evidence[] = 'Skills/projects: ' . implode(', ', array_slice($skillHits, 0, 5));
            $categories[] = 'skills_projects';
        }
        if ($educationHits) {
            $score += min(18, count($educationHits) * 7);
            $evidence[] = 'Education: ' . implode(', ', array_slice($educationHits, 0, 3));
            $categories[] = 'education';
        }
        if ($titleWorkHits) {
            $score += min(16, count($titleWorkHits) * 8);
            $categories[] = 'role_title';
        } elseif ($titleSummaryHits) {
            $score += min(12, count($titleSummaryHits) * 6);
            $evidence[] = 'Resume summary/objective: ' . implode(', ', array_slice($titleSummaryHits, 0, 2));
            $categories[] = 'summary';
        } elseif ($titleAllHits) {
            $score += min(5, count($titleAllHits) * 2);
        }

        if (!$hasSectionStructure) {
            $score += min(18, count($generalWorkHits) * 5);
            $score += min(12, count($generalInternHits) * 4);
            $score += min(16, count($generalSkillHits) * 4);
            $score += min(10, count($generalEducationHits) * 4);
            if ($generalWorkHits) {
                $evidence[] = 'Resume text keywords: ' . implode(', ', array_slice($generalWorkHits, 0, 3));
                $categories[] = 'employment_or_general';
            }
            if ($generalInternHits) {
                $evidence[] = 'Internship keywords: ' . implode(', ', array_slice($generalInternHits, 0, 3));
                $categories[] = 'internship_or_general';
            }
            if ($generalSkillHits) {
                $evidence[] = 'Skill keywords: ' . implode(', ', array_slice($generalSkillHits, 0, 4));
                $categories[] = 'skills_or_general';
            }
            if ($generalEducationHits) {
                $evidence[] = 'Education keywords: ' . implode(', ', array_slice($generalEducationHits, 0, 3));
                $categories[] = 'education_or_general';
            }
        }

        // Explicit role-title evidence and substantive role metadata can add
        // corroboration; raw family/role labels alone are intentionally weak.
        $metadata = $this->normalizeText(implode(' ', array_filter([
            (string) ($role->description ?? ''),
            (string) ($role->role_description ?? ''),
            (string) ($role->responsibilities ?? ''),
        ])));
        if ($metadata !== '' && strlen($metadata) > 40) {
            $metadataHits = $this->matchKeywords($profile['skills'], $metadata);
            $score += min(8, count($metadataHits) * 2);
            if ($metadataHits) {
                $evidence[] = 'Role profile: ' . implode(', ', array_slice($metadataHits, 0, 3));
            }
        }

        if ($excludeHits) {
            $score -= min(20, count($excludeHits) * 10);
            $evidence[] = 'Profile exclusions: ' . implode(', ', array_slice($excludeHits, 0, 3));
        }
        $score = max(0, min(100, $score));
        $level = max(1, (int) ($role->seniority_level ?? 1));
        $careerEvidence = trim($employmentSource);
        if ($careerEvidence === '' && !$hasSectionStructure) $careerEvidence = $allSource;
        $leadershipContext = trim($careerEvidence . ' ' . $summarySource);
        $hasLeadershipEvidence = $this->hasLeadershipEvidence($leadershipContext);
        $years = $this->estimateExperienceYears($allSource);
        $hasEmploymentHistory = (trim($employmentSource) !== '' && (!empty($workHits) || !empty($titleWorkHits)))
            || (!$hasSectionStructure && (!empty($generalWorkHits) || !empty($titleAllHits)));
        $hasExplicitSeniorTitle = $this->hasSeniorTitle($careerEvidence);
        $hasExplicitManagementTitle = $this->hasManagementTitle($careerEvidence);
        $roleMinimumYears = $this->parseMinimumExperienceYears((string) ($role->minimum_experience ?? ''));

        // Hard eligibility gates for seniority: an internship or degree alone
        // must never recommend Senior, Team Lead, Manager, or Head positions.
        $seniorityEligible = true;
        if ($level >= 5) {
            $seniorityEligible = $hasExplicitManagementTitle && ($hasLeadershipEvidence || $years >= 5);
        } elseif ($level >= 4) {
            $seniorityEligible = $hasExplicitManagementTitle || ($hasLeadershipEvidence && $years >= 3) || $years >= 4;
        } elseif ($level >= 3) {
            $seniorityEligible = $hasLeadershipEvidence || $years >= 3;
        } elseif ($level >= 2) {
            $seniorityEligible = $hasExplicitSeniorTitle || ($hasEmploymentHistory && $years >= 2);
        }
        if ($roleMinimumYears > 0) {
            if ($years > 0 && $years < $roleMinimumYears) {
                $seniorityEligible = false;
            } elseif ($years <= 0 && !$hasEmploymentHistory && $roleMinimumYears >= 2) {
                $seniorityEligible = false;
            }
        }
        if (!$seniorityEligible) {
            $score = (int) round($score * ($level >= 4 ? 0.30 : 0.55));
        }

        $hasWorkOrIntern = !empty($workHits) || !empty($internHits) || !empty($generalWorkHits) || !empty($generalInternHits);
        $hasSkillEvidence = !empty($skillHits) || !empty($generalSkillHits);
        $hasDirectRoleTitle = !empty($titleWorkHits) || !empty($titleSummaryHits);
        $educationHitsForGate = $educationHits ?: $generalEducationHits;
        $hasEducation = !empty($educationHitsForGate);
        $specificEducationOnly = $level === 1 && $hasEducation && count($educationHitsForGate) >= 2 && in_array($this->taxonomyGroup(strtoupper((string) ($role->role_code ?? '')), strtolower((string) ($role->role_family ?? ''))), ['software_engineering', 'embedded', 'finance_accounts', 'quality_assurance', 'devops', 'network_engineering', 'mobile_development', 'business_analysis'], true);

        $roleCodeForGate = strtoupper((string) ($role->role_code ?? ''));
        $fullStackEligible = true;
        if (str_contains($roleCodeForGate, 'FULL_STACK')) {
            $frontSignals = $this->matchKeywords(['HTML', 'CSS', 'React', 'Angular', 'Vue', 'responsive design', 'frontend development', 'front end development'], $allSource);
            $backSignals = $this->matchKeywords(['PHP', 'Laravel', 'Node.js', 'Python', 'Django', 'Java', 'Spring Boot', 'MySQL', 'PostgreSQL', 'REST API', 'GraphQL', 'backend development', 'back end development'], $allSource);
            $fullStackTitle = $this->matchKeywords(['full stack developer', 'full-stack developer', 'full stack development'], $careerEvidence . ' ' . $internshipSource . ' ' . $summarySource);
            $fullStackEligible = !empty($fullStackTitle) || (!empty($frontSignals) && !empty($backSignals));
        }

        $eligible = $seniorityEligible && $fullStackEligible
            && ($hasWorkOrIntern || $hasSkillEvidence || $hasDirectRoleTitle || $specificEducationOnly)
            && $score >= self::DEFAULT_MIN_SCORE;

        if (!$evidence) {
            $evidence[] = 'Role similarity from resume wording';
        }

        return [
            'score' => $score,
            'eligible' => $eligible,
            'evidence' => array_values(array_unique($evidence)),
            'categories' => array_values(array_unique($categories)),
        ];
    }

    private function extractSections(string $text): array
    {
        $sections = [
            'all' => trim($text), 'education' => '', 'employment' => '', 'internship' => '',
            'skills' => '', 'projects' => '', 'summary' => '', 'general' => '', 'has_sections' => false,
        ];
        $current = 'general';
        $lines = preg_split('/\R/u', $text) ?: [$text];
        foreach ($lines as $line) {
            $rawLine = trim((string) $line);
            if ($rawLine === '') continue;
            [$heading, $content] = $this->detectHeading($rawLine);
            if ($heading !== null) {
                $current = $heading;
                $sections['has_sections'] = true;
                if ($content !== '') {
                    $sections[$current] .= ' ' . $content;
                }
                continue;
            }
            $sections[$current] .= ' ' . $rawLine;
        }

        // Some PDF parsers flatten all text into one/two giant lines. Recover
        // lightweight section windows using heading anchors where possible.
        if (!$sections['has_sections']) {
            $normalized = $this->normalizeText($text);
            $sections['education'] = $this->extractInlineSection($normalized, ['education', 'educational qualification', 'academic qualification'], ['experience', 'internship', 'skills', 'projects', 'certification']);
            $sections['employment'] = $this->extractInlineSection($normalized, ['work experience', 'professional experience', 'employment history', 'experience'], ['internship', 'education', 'skills', 'projects', 'certification']);
            $sections['internship'] = $this->extractInlineSection($normalized, ['internship', 'internships', 'industrial training'], ['education', 'work experience', 'professional experience', 'skills', 'projects', 'certification']);
            $sections['skills'] = $this->extractInlineSection($normalized, ['technical skills', 'skills', 'core competencies'], ['education', 'work experience', 'professional experience', 'internship', 'projects', 'certification']);
            $sections['projects'] = $this->extractInlineSection($normalized, ['projects', 'academic projects'], ['education', 'work experience', 'professional experience', 'internship', 'skills', 'certification']);
            $sections['summary'] = $this->extractInlineSection($normalized, ['career objective', 'objective', 'professional summary', 'summary', 'profile'], ['education', 'work experience', 'professional experience', 'internship', 'skills', 'projects']);
            // Don't claim section structure for these approximate windows; scorer
            // applies low weights for the whole-text fallback as well.
        }

        foreach (['education', 'employment', 'internship', 'skills', 'projects', 'summary', 'general'] as $key) {
            $sections[$key] = trim((string) $sections[$key]);
        }
        return $sections;
    }

    private function detectHeading(string $line): array
    {
        $normalized = $this->normalizeText($line);
        $normalized = trim($normalized);
        if ($normalized === '') return [null, ''];

        $patterns = [
            'education' => '/^(education|educational background|educational qualification|academic background|academic qualifications|academic qualification|qualification|qualifications)(?:\s+details)?(?:\s*[:\-])?$/i',
            'employment' => '/^(work experience|professional experience|employment history|career history|working experience|experience|professional background)(?:\s*[:\-])?$/i',
            'internship' => '/^(internship|internships|internship experience|internship experiences|industrial training|training experience)(?:\s*[:\-])?$/i',
            'skills' => '/^(skills|technical skills|key skills|core skills|core competencies|technical expertise|professional skills|tools and technologies)(?:\s*[:\-])?$/i',
            'projects' => '/^(projects|academic projects|personal projects|key projects)(?:\s*[:\-])?$/i',
            'summary' => '/^(career objective|objective|professional summary|summary|profile|about me|career summary)(?:\s*[:\-])?$/i',
        ];
        foreach ($patterns as $section => $pattern) {
            if (preg_match($pattern, $normalized)) return [$section, ''];
        }

        // Headings may share a line with content after PDF text extraction.
        foreach ($patterns as $section => $pattern) {
            $prefixPattern = preg_replace('/\$$/', '', $pattern);
            $prefixPattern = str_replace('$/i', '(?:\s*[:\-]?\s+)(.+)$/i', $prefixPattern);
            if (preg_match($prefixPattern, $normalized, $m) && !empty($m[1])) {
                return [$section, trim($m[2] ?? '')];
            }
        }

        return [null, ''];
    }

    private function extractInlineSection(string $normalizedText, array $startLabels, array $stopLabels): string
    {
        foreach ($startLabels as $start) {
            $startNorm = $this->normalizeText($start);
            $pos = strpos($normalizedText, $startNorm);
            if ($pos === false) continue;
            $startAt = $pos + strlen($startNorm);
            $endAt = strlen($normalizedText);
            foreach ($stopLabels as $stop) {
                $stopNorm = $this->normalizeText($stop);
                $next = strpos($normalizedText, $stopNorm, $startAt);
                if ($next !== false && $next < $endAt) $endAt = $next;
            }
            $value = trim(substr($normalizedText, $startAt, max(0, $endAt - $startAt)));
            if ($value !== '') return $value;
        }
        return '';
    }

    private function matchKeywords(array $keywords, string $source): array
    {
        $source = ' ' . $this->normalizeText($source) . ' ';
        if (trim($source) === '') return [];
        $hits = [];
        foreach ($keywords as $keyword) {
            $normalized = $this->normalizeText((string) $keyword);
            if (strlen($normalized) < 2 || preg_match('/^(and|or|the|with|for|role|job|work|experience|education|skills|team|executive|manager|senior)$/', $normalized)) {
                continue;
            }
            if (strpos($source, ' ' . $normalized . ' ') !== false) $hits[] = (string) $keyword;
        }
        return array_values(array_unique($hits));
    }

    private function parseKeywords($value): array
    {
        if ($value === null || $value === '') return [];
        if (is_array($value)) return array_values(array_filter(array_map('trim', $value), static fn ($v) => $v !== ''));
        $value = trim((string) $value);
        if ($value === '') return [];
        $decoded = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            return array_values(array_filter(array_map(static fn ($v) => trim((string) $v), $decoded), static fn ($v) => $v !== ''));
        }
        $parts = preg_split('/[\r\n;|,]+/u', $value) ?: [];
        return array_values(array_filter(array_map('trim', $parts), static fn ($v) => $v !== ''));
    }

    private function normalizeText(string $text): string
    {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace(["\u{00A0}", "\u{200B}", "\u{FEFF}"], ' ', $text);
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        $text = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $text) ?? $text;
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }

    private function hasLeadershipEvidence(string $text): bool
    {
        $normalized = ' ' . $this->normalizeText($text) . ' ';
        foreach (['team lead', 'team leader', 'people manager', 'managed a team', 'manage a team', 'led a team', 'lead a team', 'supervisor', 'department head', 'branch head', 'center head', 'project lead', 'team management', 'staff management', 'direct reports', 'manager', 'head of'] as $term) {
            if (strpos($normalized, ' ' . $this->normalizeText($term) . ' ') !== false) return true;
        }
        return false;
    }

    private function hasManagementTitle(string $text): bool
    {
        $normalized = ' ' . $this->normalizeText($text) . ' ';
        foreach (['manager', 'head', 'director', 'supervisor', 'team lead', 'team leader', 'branch head', 'center head', 'centre head', 'department lead', 'department head'] as $term) {
            if (strpos($normalized, ' ' . $this->normalizeText($term) . ' ') !== false) return true;
        }
        return false;
    }

    private function hasSeniorTitle(string $text): bool
    {
        $normalized = ' ' . $this->normalizeText($text) . ' ';
        foreach (['senior', 'sr', 'lead', 'team lead', 'principal'] as $term) {
            if (strpos($normalized, ' ' . $this->normalizeText($term) . ' ') !== false) return true;
        }
        return false;
    }

    private function parseMinimumExperienceYears(string $value): float
    {
        $normalized = $this->normalizeText($value);
        if ($normalized === '' || str_contains($normalized, 'fresher') || str_contains($normalized, 'no experience') || str_contains($normalized, 'not required')) {
            return 0.0;
        }
        if (preg_match('/\b(\d{1,2}(?:\.\d)?)\s*(?:\+\s*)?(?:years?|yrs?)\b/u', $normalized, $match)) {
            return min(60, max(0, (float) $match[1]));
        }
        return 0.0;
    }

    private function estimateExperienceYears(string $text): float
    {
        $text = $this->normalizeText($text);
        if (preg_match_all('/\b(\d{1,2}(?:\.\d)?)\s*(?:\+\s*)?(?:years?|yrs?)\b/u', $text, $matches) && !empty($matches[1])) {
            return min(60, max(array_map('floatval', $matches[1])));
        }
        return 0.0;
    }

    private function matchBand(int $score): string
    {
        if ($score >= 70) return 'strong';
        if ($score >= 45) return 'good';
        return 'potential';
    }

    private function emptyResult(string $status): array
    {
        return [
            'status' => $status,
            'service_version' => self::VERSION,
            'matches' => [],
            'role_ids' => [],
            'match_count' => 0,
            'catalog_role_count' => 0,
        ];
    }
}
