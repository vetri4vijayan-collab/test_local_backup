<?php

namespace App\Services\Recruitment\ResumeAutomation;

/**
 * Extracts a candidate-owned email address from resume text without sending email
 * addresses to an AI provider. Candidate suggestions must always be reviewed.
 */
class CandidateEmailService
{
    public const VERSION = '2026-10-15.1';

    /**
     * @return array{candidate_email:?string,source:string,parser_version:string}
     */
    public function extractFromResume(string $resumeText): array
    {
        $notFound = [
            'candidate_email' => null,
            'source' => 'not_found',
            'parser_version' => self::VERSION,
        ];

        if (trim($resumeText) === '') {
            return $notFound;
        }

        // Bound parsing time and memory for large/hostile text extractions.
        $text = function_exists('mb_substr')
            ? mb_substr($resumeText, 0, 150000, 'UTF-8')
            : substr($resumeText, 0, 150000);
        $text = str_replace(["\r\n", "\r", "\0", "\xC2\xA0", "\xE2\x80\xAF"], ["\n", "\n", '', ' ', ' '], $text);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{2060}\x{FEFF}]/u', '', $text) ?? $text;
        $lines = preg_split('/\n/u', $text) ?: [];

        // Resume PDFs often wrap an email at @, a dot, or at the domain boundary.
        // Scan the real text first, then bounded adjacent-line variants that are
        // only compacted when the line boundary looks like a broken email token.
        $candidates = [];
        $pattern = <<<'REGEX'
~(?<![A-Z0-9._%+\-])[A-Z0-9.!#$%&'*+/=?^_`{|}\~\-]{1,64}\s*@\s*[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\s*\.\s*[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+(?![A-Z0-9-])~iu
REGEX;

        $this->collectFromText($text, $pattern, $candidates, 0);

        $boundedLines = array_slice($lines, 0, 220);
        $lineOffsets = [];
        $offset = 0;
        foreach ($boundedLines as $line) {
            $lineOffsets[] = $offset;
            $offset += strlen((string) $line) + 1;
        }

        $lineCount = count($boundedLines);
        for ($i = 0; $i < $lineCount; $i++) {
            $line = trim((string) $boundedLines[$i]);
            if ($line === '') {
                continue;
            }

            // A local context improves ranking and avoids treating a reference's
            // address as the candidate's merely because it appears later in a CV.
            $context = trim(implode("\n", array_slice($boundedLines, max(0, $i - 1), 3)));
            $this->collectFromText($line, $pattern, $candidates, (int) ($lineOffsets[$i] ?? 0), $context);

            $joined = $line;
            for ($step = 1; $step <= 2 && ($i + $step) < $lineCount; $step++) {
                $next = trim((string) $boundedLines[$i + $step]);
                if ($next === '' || !$this->shouldJoinEmailWrappedLines($joined, $next)) {
                    break;
                }

                $joined = rtrim($joined) . ltrim($next);
                $joinedContext = trim(implode("\n", array_slice($boundedLines, max(0, $i - 1), min(4, $step + 2))));
                $this->collectFromText($joined, $pattern, $candidates, (int) ($lineOffsets[$i] ?? 0), $joinedContext, true);
            }
        }

        if ($candidates === []) {
            return $notFound;
        }

        uasort($candidates, static function (array $left, array $right): int {
            return ($right['score'] <=> $left['score']) ?: ($left['position'] <=> $right['position']);
        });

        $best = reset($candidates);
        if (!is_array($best) || empty($best['email'])) {
            return $notFound;
        }

        return [
            'candidate_email' => (string) $best['email'],
            'source' => 'local_parser',
            'parser_version' => self::VERSION,
        ];
    }

    /** @return bool */
    private function shouldJoinEmailWrappedLines(string $left, string $right): bool
    {
        $left = rtrim($left);
        $right = ltrim($right);
        if ($left === '' || $right === '') {
            return false;
        }

        // Common wrapped boundaries: user.name. + domain.com, user@ + gmail.com,
        // user@gmail. + com, or a domain split after the @ sign.
        if (preg_match('/[@._%+\-]$/u', $left) || preg_match('/^[@._%+\-]/u', $right)) {
            return true;
        }

        $at = strrpos($left, '@');
        if ($at !== false) {
            $domainPart = substr($left, $at + 1);
            if ($domainPart !== '' && strpos($domainPart, '.') === false && preg_match('/^[A-Z0-9\-]+$/i', $domainPart)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,array{email:string,score:int,position:int}> $candidates
     */
    private function collectFromText(
        string $sourceText,
        string $pattern,
        array &$candidates,
        int $baseOffset,
        ?string $contextOverride = null,
        bool $wrapped = false
    ): void {
        if ($sourceText === '' || !preg_match_all($pattern, $sourceText, $matches, PREG_OFFSET_CAPTURE)) {
            return;
        }

        foreach ($matches[0] as $match) {
            $raw = (string) ($match[0] ?? '');
            $matchOffset = (int) ($match[1] ?? 0);
            $email = strtolower(preg_replace('/\s+/u', '', $raw) ?? $raw);
            $email = trim($email, " \t\n\r\0\x0B,;:<>()[]{}\"'");

            if (!$this->isPlausibleCandidateEmail($email)) {
                continue;
            }

            $absoluteOffset = max(0, $baseOffset + $matchOffset);
            $context = $contextOverride ?? substr($sourceText, max(0, $matchOffset - 100), strlen($raw) + 200);
            $context = $this->sanitizeContext($context);
            $score = $this->scoreCandidate($email, $context, $absoluteOffset, $wrapped);

            if (!isset($candidates[$email]) || $score > $candidates[$email]['score']) {
                $candidates[$email] = [
                    'email' => $email,
                    'score' => $score,
                    'position' => $absoluteOffset,
                ];
            }
        }
    }

    private function isPlausibleCandidateEmail(string $email): bool
    {
        if ($email === '' || strlen($email) > 254 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return false;
        }

        [$local, $domain] = array_pad(explode('@', $email, 2), 2, '');
        if ($local === '' || strlen($local) > 64 || $domain === '' || strpos($domain, '.') === false) {
            return false;
        }

        $localLower = strtolower($local);
        $domainLower = strtolower($domain);
        $placeholderLocals = [
            'example', 'test', 'dummy', 'sample', 'username', 'yourname', 'your-email',
            'your.email', 'email', 'name', 'abc', 'xyz', 'noreply', 'no-reply',
            'donotreply', 'do-not-reply', 'admin', 'administrator', 'support', 'info',
            'contact', 'office', 'careers', 'jobs', 'recruitment', 'hr', 'sales',
        ];
        $placeholderDomains = [
            'example.com', 'example.org', 'example.net', 'test.com', 'domain.com',
            'email.com', 'yourdomain.com', 'sample.com', 'invalid', 'localhost',
        ];
        $genericMailboxLocals = [
            'admin', 'administrator', 'support', 'helpdesk', 'info', 'contact', 'office',
            'careers', 'jobs', 'recruitment', 'hr', 'sales', 'billing', 'accounts',
            'enquiry', 'enquiries', 'noreply', 'no-reply', 'donotreply', 'do-not-reply',
        ];

        if (in_array($localLower, $placeholderLocals, true)
            || in_array($localLower, $genericMailboxLocals, true)
            || in_array($domainLower, $placeholderDomains, true)) {
            return false;
        }
        foreach (['.example.com', '.example.org', '.example.net'] as $reservedSuffix) {
            if ($domainLower === ltrim($reservedSuffix, '.') || str_ends_with($domainLower, $reservedSuffix)) {
                return false;
            }
        }

        if (preg_match('/(?:^|[._+\-])(?:example|dummy|sample|yourname|username|noreply|no-reply|donotreply)(?:$|[._+\-])/i', $localLower)) {
            return false;
        }

        if (preg_match('/\.(?:invalid|local)$/i', $domainLower)) {
            return false;
        }

        return true;
    }

    private function scoreCandidate(string $email, string $context, int $offset, bool $wrapped): int
    {
        $score = 0;
        $lowerContext = strtolower($context);
        $local = strtolower((string) strstr($email, '@', true));
        $domain = strtolower(substr(strrchr($email, '@') ?: '', 1));

        if (preg_match('/\b(?:e[\s-]?mail|mail\s*(?:id|address)?|contact\s*email)\b/i', $context)) {
            $score += 70;
        }
        if (preg_match('/\b(?:personal|candidate|my)\s+(?:e[\s-]?mail|mail)\b/i', $context)) {
            $score += 15;
        }
        if ($offset <= 900) {
            $score += 36;
        } elseif ($offset <= 2200) {
            $score += 20;
        } elseif ($offset <= 5000) {
            $score += 8;
        } else {
            $score -= min(35, (int) floor(($offset - 5000) / 1800));
        }

        if (preg_match('/\b(?:gmail\.com|yahoo\.(?:com|co\.in|in)|outlook\.com|hotmail\.com|live\.com|rediffmail\.com|icloud\.com|protonmail\.com)\b/i', $domain)) {
            $score += 8;
        }
        if ($wrapped) {
            $score -= 3; // Directly extracted addresses are more reliable than reconstructed ones.
        }

        // De-prioritize emails explicitly attached to third-party/reference contacts.
        if (preg_match('/\b(?:references?|referees?|emergency\s+contact|father|mother|guardian|spouse|husband|wife|recruiter|hiring\s+manager|hr\s+contact)\b/i', $context)) {
            $score -= 90;
        }
        if (preg_match('/\b(?:no-?reply|donotreply|support|helpdesk|careers|jobs|recruitment|administrator|admin|sales|billing|accounts|enquir(?:y|ies)|info|contact|office)\b/i', $local)) {
            $score -= 70;
        }

        // Do not let a generic reference email beat a personal address in the header.
        if (str_contains($lowerContext, 'reference') || str_contains($lowerContext, 'referee')) {
            $score -= 20;
        }

        return $score;
    }

    private function sanitizeContext(string $context): string
    {
        $context = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', ' ', $context) ?? $context;
        return preg_replace('/\s+/u', ' ', trim($context)) ?? trim($context);
    }
}
