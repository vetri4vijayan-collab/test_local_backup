<?php

namespace App\Services\Recruitment\ResumeAutomation;

use DOMDocument;
use DOMXPath;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser as PdfParser;
use Symfony\Component\Process\Process;
use Throwable;
use ZipArchive;

/**
 * Extracts searchable text from supported resume formats.
 *
 * This service deliberately has no candidate-field logic and no AI dependency.
 * The parsed output is consumed by CandidateNameExtractionService for name-only
 * extraction. Unsupported or unreadable text does not prevent the uploaded file
 * from being retained by the candidate workflow.
 */
class ResumeTextExtractionService
{
    public const SUPPORTED_EXTENSIONS = [
        'pdf', 'doc', 'docx', 'docm', 'odt', 'rtf', 'txt', 'text', 'md',
        'markdown', 'html', 'htm', 'ppt', 'pptx', 'xls', 'xlsx', 'jpg',
        'jpeg', 'png', 'webp', 'bmp', 'gif', 'tif', 'tiff',
    ];

    private const MAX_ARCHIVE_ENTRIES = 2500;
    private const MAX_ARCHIVE_XML_BYTES = 5_000_000;

    /**
     * @return array{text:string,engine:string,extension:string,warning:?string}
     */
    public function extract(UploadedFile $file): array
    {
        if (!$file->isValid()) {
            throw new \RuntimeException('The uploaded resume is not valid. Please upload it again.');
        }

        $path = $file->getRealPath();
        if (!is_string($path) || !is_file($path) || !is_readable($path)) {
            throw new \RuntimeException('The uploaded resume could not be opened by the server.');
        }

        $extension = strtolower($file->getClientOriginalExtension());
        if (!self::supportsExtension($extension)) {
            throw new \InvalidArgumentException('This resume file format is not supported.');
        }

        return $this->extractPath($path, $extension);
    }

    public static function supportsExtension(string $extension): bool
    {
        return in_array(strtolower($extension), self::SUPPORTED_EXTENSIONS, true);
    }


    /**
     * Bounded name-only OCR retry for a readable PDF whose native text produced no
     * reliable name. Uses page 1 only so this fallback is safe for a synchronous ATS
     * upload request. The caller must run local parsing on the result before using AI.
     *
     * @return array{text:string,engine:string,warning:?string}
     */
    public function extractPdfNameFallback(string $path): array
    {
        if (!is_file($path) || !is_readable($path)) {
            return ['text' => '', 'engine' => 'none', 'warning' => 'pdf_name_fallback_file_unavailable'];
        }
        if (!config('recruitment_resume_ai.text.ocr_enabled', true)) {
            return ['text' => '', 'engine' => 'none', 'warning' => 'ocr_disabled'];
        }

        $tempDirectory = $this->createTempDirectory();
        if ($tempDirectory === null) {
            return ['text' => '', 'engine' => 'none', 'warning' => 'ocr_temp_directory_unavailable'];
        }

        try {
            $prefix = $tempDirectory . DIRECTORY_SEPARATOR . 'resume-name-page';
            $pdfToPpm = trim((string) config('recruitment_resume_ai.text.pdftoppm_binary', 'pdftoppm')) ?: 'pdftoppm';
            $render = $this->runCommand([
                $pdfToPpm, '-f', '1', '-l', '1', '-r', '150', '-png', $path, $prefix,
            ], 12);

            $images = glob($prefix . '-*.png') ?: [];
            natsort($images);
            if (!$render['success'] || count($images) === 0) {
                // ImageMagick is an alternate renderer on hosts without pdftoppm.
                $images = $this->renderPdfWithImagick($path, $tempDirectory, 1);
            }
            $imagePath = reset($images);
            if (!is_string($imagePath) || !is_file($imagePath)) {
                return ['text' => '', 'engine' => 'none', 'warning' => 'pdf_name_ocr_renderer_unavailable'];
            }

            $text = trim($this->extractImageWithOcr($imagePath, 12));
            if ($this->textLength($text) < 8) {
                return ['text' => '', 'engine' => 'none', 'warning' => 'pdf_name_ocr_no_text'];
            }

            return [
                'text' => $this->normalizeText($text),
                'engine' => 'pdf_ocr_name_fallback',
                'warning' => null,
            ];
        } catch (Throwable $e) {
            Log::info('Bounded PDF name OCR fallback unavailable', [
                'exception' => get_class($e),
            ]);
            return ['text' => '', 'engine' => 'none', 'warning' => 'pdf_name_ocr_failed'];
        } finally {
            $this->removeDirectory($tempDirectory);
        }
    }

    /**
     * Allows the candidate-save path to retry extraction after an upload-cache miss.
     * The caller must supply a path created/controlled by Laravel, never a request URL.
     *
     * @return array{text:string,engine:string,extension:string,warning:?string}
     */
    public function extractPath(string $path, ?string $extension = null): array
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new \RuntimeException('The uploaded resume could not be opened by the server.');
        }

        $extension = strtolower($extension ?: pathinfo($path, PATHINFO_EXTENSION));
        if (!self::supportsExtension($extension)) {
            throw new \InvalidArgumentException('This resume file format is not supported.');
        }

        $text = '';
        $engine = 'none';

        try {
            switch ($extension) {
                case 'pdf':
                    [$text, $engine] = $this->extractPdf($path);
                    break;

                case 'docx':
                case 'docm':
                    $text = $this->extractWordOpenXml($path);
                    $engine = $text !== '' ? 'openxml_word' : 'none';
                    if ($text === '') {
                        $text = $this->extractWithPhpWord($path);
                        $engine = $text !== '' ? 'phpword' : 'none';
                    }
                    if ($text === '') {
                        $text = $this->convertOfficeToText($path);
                        $engine = $text !== '' ? 'libreoffice' : 'none';
                    }
                    break;

                case 'odt':
                    $text = $this->extractOpenDocumentText($path);
                    $engine = $text !== '' ? 'opendocument_xml' : 'none';
                    if ($text === '') {
                        $text = $this->extractWithPhpWord($path);
                        $engine = $text !== '' ? 'phpword' : 'none';
                    }
                    if ($text === '') {
                        $text = $this->convertOfficeToText($path);
                        $engine = $text !== '' ? 'libreoffice' : 'none';
                    }
                    break;

                case 'doc':
                    $text = $this->runBinaryTextExtractor('antiword', $path);
                    $engine = $text !== '' ? 'antiword' : 'none';
                    if ($text === '') {
                        $text = $this->convertOfficeToText($path);
                        $engine = $text !== '' ? 'libreoffice' : 'none';
                    }
                    if ($text === '') {
                        $text = $this->extractWithPhpWord($path);
                        $engine = $text !== '' ? 'phpword' : 'none';
                    }
                    break;

                case 'pptx':
                    $text = $this->extractPowerPointOpenXml($path);
                    $engine = $text !== '' ? 'openxml_powerpoint' : 'none';
                    if ($text === '') {
                        $text = $this->convertOfficeToText($path);
                        $engine = $text !== '' ? 'libreoffice' : 'none';
                    }
                    break;

                case 'ppt':
                case 'xls':
                    $text = $this->convertOfficeToText($path);
                    $engine = $text !== '' ? 'libreoffice' : 'none';
                    break;

                case 'xlsx':
                    $text = $this->extractExcelOpenXml($path);
                    $engine = $text !== '' ? 'openxml_excel' : 'none';
                    if ($text === '') {
                        $text = $this->convertOfficeToText($path);
                        $engine = $text !== '' ? 'libreoffice' : 'none';
                    }
                    break;

                case 'rtf':
                    $text = $this->extractRtf($path);
                    $engine = $text !== '' ? 'rtf_text' : 'none';
                    break;

                case 'html':
                case 'htm':
                    $text = $this->extractHtml($path);
                    $engine = $text !== '' ? 'html_dom' : 'none';
                    break;

                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'webp':
                case 'bmp':
                case 'gif':
                case 'tif':
                case 'tiff':
                    $text = $this->extractImageWithOcr($path);
                    $engine = $text !== '' ? 'tesseract_ocr' : 'none';
                    break;

                case 'txt':
                case 'text':
                case 'md':
                case 'markdown':
                    $contents = file_get_contents($path);
                    $text = is_string($contents) ? $contents : '';
                    $engine = $text !== '' ? 'plain_text' : 'none';
                    break;
            }
        } catch (Throwable $e) {
            // Never log resume text or user-provided file names. The upload can
            // still be saved with a manual-entry prompt if extraction is unavailable.
            Log::warning('Resume text extraction failed', [
                'extension' => $extension,
                'engine' => $engine,
                'exception' => get_class($e),
            ]);
        }

        $text = $this->normalizeText($text);
        $maximumCharacters = max(10000, (int) config('recruitment_resume_ai.text.max_characters', 150000));
        if ($text !== '') {
            $text = function_exists('mb_substr')
                ? mb_substr($text, 0, $maximumCharacters, 'UTF-8')
                : substr($text, 0, $maximumCharacters);
        }

        return [
            'text' => $text,
            'engine' => $engine,
            'extension' => $extension,
            'warning' => $text === '' ? 'no_text_detected' : null,
        ];
    }

    /** @return array{0:string,1:string} */
    private function extractPdf(string $path): array
    {
        $nativeText = '';
        try {
            $parser = new PdfParser();
            $document = $parser->parseFile($path);
            $nativeText = (string) $document->getText();
        } catch (Throwable $e) {
            Log::info('Native PDF text extraction unavailable', [
                'exception' => get_class($e),
            ]);
        }

        // Smalot can return readable-length text with a damaged reading order or
        // fragmented glyphs on some PDFs. Prefer Poppler's text extractor when it
        // is installed; it keeps the header usable by both AI and local parsing.
        $popplerText = $this->extractPdfWithPoppler($path);
        if ($this->textLength($popplerText) >= 80) {
            return [$popplerText, 'pdftotext'];
        }

        if ($this->textLength($nativeText) >= 80) {
            return [$nativeText, 'pdf_text'];
        }

        if (!config('recruitment_resume_ai.text.ocr_enabled', true)) {
            $bestText = $this->textLength($popplerText) > $this->textLength($nativeText)
                ? $popplerText : $nativeText;
            return [$bestText, $bestText !== '' ? 'pdf_text_partial' : 'none'];
        }

        $ocrText = $this->ocrPdfFirstPages($path);
        $bestText = $this->textLength($popplerText) > $this->textLength($nativeText)
            ? $popplerText : $nativeText;
        if ($this->textLength($ocrText) > $this->textLength($bestText)) {
            return [$ocrText, $ocrText !== '' ? 'pdf_ocr' : 'none'];
        }

        return [$bestText, $bestText !== '' ? 'pdf_text_partial' : 'none'];
    }

    /**
     * Poppler normally ships with pdftoppm. If pdftotext is absent or fails,
     * return an empty string so the existing PHP parser/OCR path remains available.
     */
    private function extractPdfWithPoppler(string $path): string
    {
        $binary = trim((string) config('recruitment_resume_ai.text.pdftotext_binary', 'pdftotext'));
        if ($binary === '') $binary = 'pdftotext';

        $result = $this->runCommand([$binary, '-layout', '-enc', 'UTF-8', $path, '-'], 12);
        if (!$result['success']) return '';

        $text = trim((string) $result['output']);
        // Reject empty/near-empty binary output; this often means a scanned PDF.
        return $this->textLength($text) >= 20 ? $text : '';
    }

    private function ocrPdfFirstPages(string $path): string
    {
        $tempDirectory = $this->createTempDirectory();
        if ($tempDirectory === null) {
            return '';
        }

        $text = '';
        try {
            $prefix = $tempDirectory . DIRECTORY_SEPARATOR . 'resume-page';
            $pdfToPpm = (string) config('recruitment_resume_ai.text.pdftoppm_binary', 'pdftoppm');
            $maxPages = min(5, max(1, (int) config('recruitment_resume_ai.text.ocr_pdf_max_pages', 3)));
            $command = $this->runCommand([
                $pdfToPpm, '-f', '1', '-l', (string) $maxPages,
                '-r', '180', '-png', $path, $prefix,
            ], 35);

            $images = glob($prefix . '-*.png') ?: [];
            natsort($images);

            if (!$command['success'] || count($images) === 0) {
                // Optional fallback for hosts which provide ImageMagick/Ghostscript
                // but do not have Poppler's pdftoppm utility installed.
                $images = $this->renderPdfWithImagick($path, $tempDirectory, $maxPages);
            }

            foreach (array_slice($images, 0, $maxPages) as $imagePath) {
                $pageText = $this->extractImageWithOcr($imagePath);
                if ($pageText !== '') {
                    $text .= "\n" . $pageText;
                }
                // Candidate names almost always occur on the first page. Keep OCR
                // work bounded and do not spend time on the entire multi-page CV.
                if ($this->textLength($text) >= 2000) {
                    break;
                }
            }
        } catch (Throwable $e) {
            Log::info('PDF OCR fallback unavailable', ['exception' => get_class($e)]);
        } finally {
            $this->removeDirectory($tempDirectory);
        }

        return $text;
    }

    /** @return list<string> */
    private function renderPdfWithImagick(string $path, string $tempDirectory, int $maxPages): array
    {
        if (!class_exists(\Imagick::class)) {
            return [];
        }

        $paths = [];
        try {
            $pdf = new \Imagick();
            $pdf->setResolution(180, 180);
            $pdf->readImage($path . '[0-' . max(0, $maxPages - 1) . ']');
            $index = 0;
            foreach ($pdf as $page) {
                $page->setImageFormat('png');
                $imagePath = $tempDirectory . DIRECTORY_SEPARATOR . 'imagick-page-' . $index . '.png';
                $page->writeImage($imagePath);
                $paths[] = $imagePath;
                $index++;
                if ($index >= $maxPages) {
                    break;
                }
            }
            $pdf->clear();
            $pdf->destroy();
        } catch (Throwable $e) {
            Log::info('ImageMagick PDF rendering unavailable', ['exception' => get_class($e)]);
        }

        return $paths;
    }

    private function extractImageWithOcr(string $path, int $timeoutSeconds = 40): string
    {
        if (!config('recruitment_resume_ai.text.ocr_enabled', true) || !is_file($path)) {
            return '';
        }

        // Protect OCR workers from highly compressed / enormous image uploads.
        // Unknown image metadata is allowed through to Tesseract, which is bounded by timeout.
        $imageInfo = @getimagesize($path);
        if (is_array($imageInfo) && isset($imageInfo[0], $imageInfo[1])) {
            $width = max(0, (int) $imageInfo[0]);
            $height = max(0, (int) $imageInfo[1]);
            $maxPixels = max(1_000_000, (int) config('recruitment_resume_ai.text.max_image_pixels', 40000000));
            if ($width === 0 || $height === 0 || ($width * $height) > $maxPixels) {
                Log::warning('Resume image exceeds OCR dimension limit', [
                    'width' => $width,
                    'height' => $height,
                    'max_pixels' => $maxPixels,
                ]);
                return '';
            }
        }

        // Use Symfony Process directly so OCR has a hard timeout. The web request
        // must not hang indefinitely when a malformed image or missing binary occurs.
        $tesseract = (string) config('recruitment_resume_ai.text.tesseract_binary', 'tesseract');
        $result = $this->runCommand([
            $tesseract, $path, 'stdout', '-l', (string) config('recruitment_resume_ai.text.ocr_languages', 'eng'), '--psm', '6',
        ], max(3, min(40, $timeoutSeconds)));

        return $result['success'] ? $result['output'] : '';
    }

    private function extractWordOpenXml(string $path): string
    {
        $zip = $this->openArchive($path);
        if (!$zip) {
            return '';
        }

        try {
            $names = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $entry = (string) ($stat['name'] ?? '');
                $size = (int) ($stat['size'] ?? 0);
                if ($size > self::MAX_ARCHIVE_XML_BYTES) continue;
                if (preg_match('~^word/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$~i', $entry)) {
                    $names[] = $entry;
                }
            }
            sort($names, SORT_NATURAL);

            $chunks = [];
            foreach ($names as $entry) {
                $xml = $zip->getFromName($entry);
                if (!is_string($xml) || $xml === '') continue;
                $chunk = $this->extractParagraphsFromXml($xml, 'p', 't');
                if ($chunk !== '') $chunks[] = $chunk;
            }

            return implode("\n", $chunks);
        } finally {
            $zip->close();
        }
    }

    private function extractOpenDocumentText(string $path): string
    {
        $zip = $this->openArchive($path);
        if (!$zip) return '';

        try {
            $xml = $zip->getFromName('content.xml');
            if (!is_string($xml) || $xml === '' || strlen($xml) > self::MAX_ARCHIVE_XML_BYTES) {
                return '';
            }

            $dom = $this->loadXml($xml);
            if (!$dom) return '';
            $xpath = new DOMXPath($dom);
            $paragraphs = $xpath->query('//*[local-name()="p" or local-name()="h"]');
            if (!$paragraphs) return '';

            $lines = [];
            foreach ($paragraphs as $paragraph) {
                $line = trim((string) $paragraph->textContent);
                if ($line !== '') $lines[] = $line;
            }

            return implode("\n", $lines);
        } finally {
            $zip->close();
        }
    }

    private function extractPowerPointOpenXml(string $path): string
    {
        $zip = $this->openArchive($path);
        if (!$zip) return '';

        try {
            $slides = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $entry = (string) ($stat['name'] ?? '');
                if (preg_match('~^ppt/slides/slide\d+\.xml$~i', $entry) && (int) ($stat['size'] ?? 0) <= self::MAX_ARCHIVE_XML_BYTES) {
                    $slides[] = $entry;
                }
            }
            sort($slides, SORT_NATURAL);

            $chunks = [];
            foreach (array_slice($slides, 0, 100) as $slide) {
                $xml = $zip->getFromName($slide);
                if (!is_string($xml) || $xml === '') continue;
                $chunk = $this->extractParagraphsFromXml($xml, 'p', 't');
                if ($chunk !== '') $chunks[] = $chunk;
            }

            return implode("\n", $chunks);
        } finally {
            $zip->close();
        }
    }

    private function extractExcelOpenXml(string $path): string
    {
        $zip = $this->openArchive($path);
        if (!$zip) return '';

        try {
            $sharedStrings = [];
            $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
            if (is_string($sharedXml) && $sharedXml !== '' && strlen($sharedXml) <= self::MAX_ARCHIVE_XML_BYTES) {
                $dom = $this->loadXml($sharedXml);
                if ($dom) {
                    $xpath = new DOMXPath($dom);
                    $items = $xpath->query('//*[local-name()="si"]');
                    if ($items) {
                        foreach ($items as $item) {
                            $parts = $xpath->query('.//*[local-name()="t"]', $item);
                            $value = '';
                            if ($parts) foreach ($parts as $part) $value .= (string) $part->textContent;
                            $sharedStrings[] = $value;
                        }
                    }
                }
            }

            $worksheets = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $entry = (string) ($stat['name'] ?? '');
                if (preg_match('~^xl/worksheets/sheet\d+\.xml$~i', $entry) && (int) ($stat['size'] ?? 0) <= self::MAX_ARCHIVE_XML_BYTES) {
                    $worksheets[] = $entry;
                }
            }
            sort($worksheets, SORT_NATURAL);

            $lines = [];
            foreach (array_slice($worksheets, 0, 20) as $worksheet) {
                $xml = $zip->getFromName($worksheet);
                if (!is_string($xml) || $xml === '') continue;
                $dom = $this->loadXml($xml);
                if (!$dom) continue;
                $xpath = new DOMXPath($dom);
                $rows = $xpath->query('//*[local-name()="sheetData"]/*[local-name()="row"]');
                if (!$rows) continue;
                $rowCount = 0;
                foreach ($rows as $row) {
                    $cells = $xpath->query('./*[local-name()="c"]', $row);
                    if (!$cells) continue;
                    $values = [];
                    foreach ($cells as $cell) {
                        $type = $cell->attributes?->getNamedItem('t')?->nodeValue ?? '';
                        $valueNode = $xpath->query('./*[local-name()="v"]', $cell)?->item(0);
                        $value = $valueNode ? (string) $valueNode->textContent : '';
                        if ($type === 's' && ctype_digit($value)) {
                            $value = $sharedStrings[(int) $value] ?? '';
                        } elseif ($type === 'inlineStr') {
                            $textNodes = $xpath->query('.//*[local-name()="is"]//*[local-name()="t"]', $cell);
                            $value = '';
                            if ($textNodes) foreach ($textNodes as $node) $value .= (string) $node->textContent;
                        }
                        $value = trim($value);
                        if ($value !== '') $values[] = $value;
                        if (count($values) >= 60) break;
                    }
                    if ($values) $lines[] = implode(' | ', $values);
                    $rowCount++;
                    if ($rowCount >= 300 || count($lines) >= 1000) break;
                }
            }

            return implode("\n", $lines);
        } finally {
            $zip->close();
        }
    }

    private function extractParagraphsFromXml(string $xml, string $paragraphLocalName, string $textLocalName): string
    {
        if (strlen($xml) > self::MAX_ARCHIVE_XML_BYTES) return '';
        $dom = $this->loadXml($xml);
        if (!$dom) return '';

        $xpath = new DOMXPath($dom);
        $paragraphs = $xpath->query('//*[local-name()="' . $paragraphLocalName . '"]');
        if (!$paragraphs) return '';

        $lines = [];
        foreach ($paragraphs as $paragraph) {
            $nodes = $xpath->query('.//*[local-name()="' . $textLocalName . '"]', $paragraph);
            $line = '';
            if ($nodes) foreach ($nodes as $node) $line .= (string) $node->textContent;
            $line = trim($line);
            if ($line !== '') $lines[] = $line;
        }

        return implode("\n", $lines);
    }

    private function loadXml(string $xml): ?DOMDocument
    {
        $previous = libxml_use_internal_errors(true);
        try {
            $dom = new DOMDocument();
            $dom->resolveExternals = false;
            $dom->substituteEntities = false;
            if (!$dom->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT)) {
                return null;
            }
            return $dom;
        } catch (Throwable $e) {
            return null;
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    private function openArchive(string $path): ?ZipArchive
    {
        if (!class_exists(ZipArchive::class)) return null;
        $zip = new ZipArchive();
        if ($zip->open($path) !== true || $zip->numFiles > self::MAX_ARCHIVE_ENTRIES) {
            if (isset($zip) && $zip instanceof ZipArchive) $zip->close();
            return null;
        }

        // Bound uncompressed content to reduce ZIP-bomb exposure.
        $totalBytes = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $totalBytes += (int) ($stat['size'] ?? 0);
            if ($totalBytes > 40_000_000) {
                $zip->close();
                return null;
            }
        }

        return $zip;
    }

    private function extractWithPhpWord(string $path): string
    {
        if (!class_exists(IOFactory::class)) return '';
        try {
            $word = IOFactory::load($path);
            $chunks = [];
            foreach ($word->getSections() as $section) {
                $this->collectPhpWordElements($section->getElements(), $chunks);
            }
            return implode("\n", $chunks);
        } catch (Throwable $e) {
            return '';
        }
    }

    private function collectPhpWordElements(array $elements, array &$chunks): void
    {
        foreach ($elements as $element) {
            if (method_exists($element, 'getText')) {
                $value = trim((string) $element->getText());
                if ($value !== '') $chunks[] = $value;
            }
            if (method_exists($element, 'getElements')) {
                try {
                    $children = $element->getElements();
                    if (is_array($children)) $this->collectPhpWordElements($children, $chunks);
                } catch (Throwable $e) {
                    // Some elements expose getElements() but do not support recursive reads.
                }
            }
        }
    }

    private function extractRtf(string $path): string
    {
        $rtf = file_get_contents($path);
        if (!is_string($rtf) || $rtf === '') return '';

        // Decode hex-encoded ANSI characters before removing RTF control words.
        $rtf = preg_replace_callback("/\\\\'([0-9a-f]{2})/i", static function ($m) {
            return chr(hexdec($m[1]));
        }, $rtf) ?? $rtf;
        $rtf = preg_replace('/\\\\(par|line|tab)\b/i', "\n", $rtf) ?? $rtf;
        $rtf = preg_replace('/\\\\u(-?\d+)\??/i', ' ', $rtf) ?? $rtf;
        $rtf = preg_replace('/\\\\[a-zA-Z]+-?\d* ?/', ' ', $rtf) ?? $rtf;
        $rtf = str_replace(['{', '}'], ' ', $rtf);

        return html_entity_decode($rtf, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    private function extractHtml(string $path): string
    {
        $html = file_get_contents($path);
        if (!is_string($html) || $html === '') return '';
        if (!class_exists(DOMDocument::class)) {
            // Safe lightweight fallback for hosts missing ext-dom: strip active and
            // non-visible element contents before removing markup.
            $html = preg_replace('~<(script|style|noscript|svg|nav|footer|head)\b[^>]*>.*?</\1\s*>~isu', ' ', $html) ?? $html;
            return html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        $previous = libxml_use_internal_errors(true);
        try {
            $dom = new DOMDocument();
            $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT);
            $xpath = new DOMXPath($dom);
            $remove = $xpath->query('//script|//style|//noscript|//svg|//nav|//footer');
            if ($remove) {
                foreach (iterator_to_array($remove) as $node) {
                    $node->parentNode?->removeChild($node);
                }
            }
            $body = $xpath->query('//body')->item(0);
            $text = $body ? (string) $body->textContent : (string) $dom->textContent;
            return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        } catch (Throwable $e) {
            return strip_tags($html);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    private function runBinaryTextExtractor(string $binary, string $path): string
    {
        $configured = (string) config('recruitment_resume_ai.text.' . ($binary === 'antiword' ? 'antiword_binary' : 'libreoffice_binary'), $binary);
        $result = $this->runCommand([$configured, $path], 25);
        return $result['success'] ? $result['output'] : '';
    }

    private function convertOfficeToText(string $path): string
    {
        $tempDirectory = $this->createTempDirectory();
        if ($tempDirectory === null) return '';

        try {
            $binary = (string) config('recruitment_resume_ai.text.libreoffice_binary', 'libreoffice');
            $result = $this->runCommand([
                $binary, '--headless', '--convert-to', 'txt:Text', '--outdir', $tempDirectory, $path,
            ], 35);

            $baseName = pathinfo($path, PATHINFO_FILENAME);
            $convertedPath = $tempDirectory . DIRECTORY_SEPARATOR . $baseName . '.txt';
            if (is_file($convertedPath) && is_readable($convertedPath)) {
                $text = file_get_contents($convertedPath);
                if (is_string($text) && $text !== '') return $text;
            }
            return $result['success'] ? $result['output'] : '';
        } finally {
            $this->removeDirectory($tempDirectory);
        }
    }

    /** @return array{success:bool,output:string,error:string} */
    private function runCommand(array $command, int $timeoutSeconds): array
    {
        try {
            $process = new Process($command);
            $process->setTimeout($timeoutSeconds);
            $process->run();

            return [
                'success' => $process->isSuccessful(),
                'output' => (string) $process->getOutput(),
                'error' => (string) $process->getErrorOutput(),
            ];
        } catch (Throwable $e) {
            return ['success' => false, 'output' => '', 'error' => get_class($e)];
        }
    }

    private function createTempDirectory(): ?string
    {
        $directory = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . 'egc_resume_' . bin2hex(random_bytes(10));

        if (!@mkdir($directory, 0700, true) && !is_dir($directory)) {
            return null;
        }

        return $directory;
    }

    private function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) return;
        $items = scandir($directory);
        if (!is_array($items)) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $directory . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && !is_link($path)) $this->removeDirectory($path);
            else @unlink($path);
        }
        @rmdir($directory);
    }

    private function normalizeText(string $text): string
    {
        if ($text === '') return '';
        $text = str_replace("\0", '', $text);
        if (function_exists('mb_check_encoding') && !mb_check_encoding($text, 'UTF-8')) {
            $text = mb_convert_encoding($text, 'UTF-8', 'auto');
        }
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace(["\r\n", "\r", "\x0B", "\x0C"], "\n", $text);
        $text = preg_replace('/[\t ]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[\x00-\x08\x0E-\x1F\x7F]/u', ' ', $text) ?? $text;
        $text = preg_replace('/\n[ \t]+/u', "\n", $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
        return trim($text);
    }

    private function textLength(string $text): int
    {
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }
}
