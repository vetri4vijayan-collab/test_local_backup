<?php

namespace App\Services\Recruitment\ResumeAutomation;

use Illuminate\Support\Facades\DB;

/** Extracts and normalizes Indian mobile numbers locally; phone PII is not sent to the AI provider. */
class CandidateMobileService
{
    public const VERSION = '2026-10-15.1';

    /**
     * Return the most likely candidate-owned Indian mobile number from the resume.
     * The returned number is always 10 digits, without +91/91/leading 0.
     *
     * @return array{candidate_mobile:?string,source:string}
     */
    public function extractFromResume(string $resumeText): array
    {
        if (trim($resumeText) === '') {
            return ['candidate_mobile' => null, 'source' => 'not_found'];
        }

        $text = str_replace(["\r\n", "\r", "\0", "\xC2\xA0", "\xE2\x80\xAF"], ["\n", "\n", '', ' ', ' '], $resumeText);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{2060}\x{FEFF}]/u', '', $text) ?? $text;
        $text = preg_replace('/[\t ]+/u', ' ', $text) ?? $text;
        $lines = preg_split('/\R/u', $text) ?: [];

        // A phone-like pattern must represent 10 Indian mobile digits, optionally
        // preceded by +91/0091/91 or a domestic trunk zero. Bound work on very large CVs.
        $pattern = '/(?<!\d)((?:(?:\+|00)?\s*91[\s().\-]*)?(?:0[\s().\-]*)?[6-9](?:[\s().\-]*\d){9})(?!\d)/u';
        $candidates = [];
        $nonEmptyLine = 0;

        $boundedLines = array_slice($lines, 0, 180);
        foreach ($boundedLines as $index => $rawLine) {
            $line = trim((string) $rawLine);
            if ($line === '') continue;
            $nonEmptyLine++;

            // PDF extraction sometimes wraps a phone after its country code or in
            // the middle of the local digits. Inspect the original line first, then
            // at most two adjacent lines when they carry phone-like digits. This is
            // bounded and avoids flattening the entire resume into unrelated digits.
            $lineVariants = [$line];
            $joined = $line;
            $joinedDigits = preg_replace('/\D/u', '', $joined) ?? '';
            $currentLineHasCompleteMobile = $this->containsNormalizedMobileMatch($joined, $pattern);
            $hasPhoneLabel = (bool) preg_match('/\b(?:mobile|mob|phone|telephone|contact|call|whatsapp|whats\s*app)\b/iu', $joined);
            if (!$currentLineHasCompleteMobile && ($hasPhoneLabel || strlen($joinedDigits) >= 3)) {
                for ($offset = 1; $offset <= 2; $offset++) {
                    $nextLine = trim((string) ($boundedLines[$index + $offset] ?? ''));
                    if ($nextLine === '') continue;
                    if (preg_match('/^(?:about me|objective|education|technical skills|skills|projects|certifications?|work experience|professional experience|awards|achievements|references?)\b/iu', $nextLine)) {
                        break;
                    }
                    $nextDigits = preg_replace('/\D/u', '', $nextLine) ?? '';
                    if (strlen($nextDigits) < 2 || $this->containsNormalizedMobileMatch($nextLine, $pattern)) break;
                    $joined .= ' ' . $nextLine;
                    $lineVariants[] = $joined;
                    $joinedDigits = preg_replace('/\D/u', '', $joined) ?? '';
                    if (strlen($joinedDigits) >= 14) break;
                }
            }

            foreach ($lineVariants as $candidateLine) {
                // Never select parent's, spouse's, reference's, emergency, alternate
                // or government-ID numbers just because they appear in a resume.
                if (preg_match('/\b(?:aadhaar|aadhar|pan\s*(?:no|number)?|passport|date\s+of\s+birth|\bdob\b)\b/iu', $candidateLine)) {
                    continue;
                }
                if (preg_match('/\b(?:father|mother|parent|guardian|spouse|husband|wife|references?|referees?|emergencies|emergency|alternate|secondary|office|employer|s\s*\/\s*o|d\s*\/\s*o|w\s*\/\s*o|son\s+of|daughter\s+of|wife\s+of|husband\s+of)\b/iu', $candidateLine)
                    && !preg_match('/\b(?:candidate|my|personal)\s+(?:mobile|phone|contact)|\b(?:my|personal)\s+(?:mobile|phone)\b/iu', $candidateLine)) {
                    continue;
                }

                if (!preg_match_all($pattern, $candidateLine, $matches, PREG_OFFSET_CAPTURE)) continue;
                foreach ($matches[1] as $match) {
                    $rawNumber = (string) ($match[0] ?? '');
                    $number = $this->normalizeIndianMobile($rawNumber);
                    if ($number === null) continue;

                    $labelled = (bool) preg_match('/\b(?:mobile|mob|phone|telephone|contact|call|whatsapp|whats\s*app)\b/iu', $candidateLine);
                    $countryPrefix = (bool) preg_match('/(?:\+\s*91|\b91|\b0091)/u', $rawNumber);
                    $score = 0;
                    $score += $labelled ? 100 : 0;
                    $score += $nonEmptyLine <= 8 ? 45 : ($nonEmptyLine <= 20 ? 24 : 0);
                    $score += $countryPrefix ? 4 : 0;
                    if (preg_match('/@/u', $candidateLine)) $score += 5;
                    $score -= min(60, max(0, $nonEmptyLine - 20)) * 1.5;

                    $candidates[] = [
                        'number' => $number,
                        'score' => $score,
                        'position' => $nonEmptyLine,
                        'labelled' => $labelled,
                    ];
                }
            }
        }

        if ($candidates === []) {
            return ['candidate_mobile' => null, 'source' => 'not_found'];
        }

        usort($candidates, static function (array $a, array $b): int {
            return ($b['score'] <=> $a['score']) ?: ($a['position'] <=> $b['position']);
        });

        return ['candidate_mobile' => $candidates[0]['number'], 'source' => 'local_parser'];
    }

    /** True when this exact line already contains a complete Indian mobile. */
    private function containsNormalizedMobileMatch(string $text, string $pattern): bool
    {
        if (!preg_match_all($pattern, $text, $matches)) return false;
        foreach ($matches[1] ?? [] as $match) {
            if ($this->normalizeIndianMobile((string) $match) !== null) return true;
        }
        return false;
    }

    /** Normalize common Indian mobile representations to ten digits or return null. */
    public function normalizeIndianMobile(?string $value): ?string
    {
        if ($value === null) return null;
        $digits = preg_replace('/\D/u', '', $value) ?? '';
        if ($digits === '') return null;

        if (str_starts_with($digits, '0091') && strlen($digits) === 14) {
            $digits = substr($digits, 4);
        } elseif (str_starts_with($digits, '91') && strlen($digits) === 12) {
            $digits = substr($digits, 2);
        } elseif (str_starts_with($digits, '0') && strlen($digits) === 11) {
            $digits = substr($digits, 1);
        }

        if (strlen($digits) !== 10 || !preg_match('/^[6-9]\d{9}$/', $digits)) return null;
        return $digits;
    }

    /**
     * Check existing applicants without requiring a schema migration. Exact/common
     * legacy formats are queried with whereIn so an index on egc_applicant.mobile can
     * still be used. Newly saved numbers are canonical 10-digit strings.
     */
    public function existsForApplicant(string $mobile, ?int $excludeApplicantId = null): bool
    {
        $number = $this->normalizeIndianMobile($mobile);
        if ($number === null) return false;

        $first = substr($number, 0, 5);
        $last = substr($number, 5);
        $groupedFormats = array_values(array_unique([
            $number,
            $first . ' ' . $last,
            $first . '-' . $last,
            $first . '.' . $last,
            $first . '/' . $last,
            substr($number, 0, 4) . ' ' . substr($number, 4, 3) . ' ' . substr($number, 7, 3),
            substr($number, 0, 3) . ' ' . substr($number, 3, 3) . ' ' . substr($number, 6, 4),
            substr($number, 0, 3) . '-' . substr($number, 3, 3) . '-' . substr($number, 6, 4),
        ]));

        // Keep this lookup index-friendly for realtime keyup AJAX checks. Generate
        // common historic display formats instead of scanning/normalizing every row
        // in egc_applicant on every keystroke. New records are saved canonicalized.
        $variants = $groupedFormats;
        foreach (['91', '+91', '0091', '0'] as $prefix) {
            foreach ($groupedFormats as $format) {
                $variants[] = $prefix . $format;
                $variants[] = $prefix . ' ' . $format;
                $variants[] = $prefix . '-' . $format;
                $variants[] = $prefix . '.' . $format;
            }
        }
        foreach ([
            '+91 (' . $first . ') ' . $last,
            '+91 (' . $first . ')-' . $last,
            '+91-(' . $first . ')-' . $last,
            '91 (' . $first . ') ' . $last,
            '0(' . $first . ')' . $last,
        ] as $specialFormat) {
            $variants[] = $specialFormat;
        }
        $variants = array_values(array_unique($variants));

        $query = DB::table('egc_applicant')
            ->where('status', '!=', 2)
            ->whereIn('mobile', $variants);

        if ($excludeApplicantId !== null && $excludeApplicantId > 0) {
            $query->where('sno', '!=', $excludeApplicantId);
        }

        return $query->exists();
    }
}
