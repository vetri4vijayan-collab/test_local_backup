<?php

namespace App\Services\Recruitment\ResumeAutomation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/** Evidence-based mapping of resume education to the existing qualification and major masters. */
class CandidateQualificationMajorService
{
    public const VERSION = '2026-10-20.1';

    public function suggest(string $resumeText): array
    {
        $text = $this->normalize($resumeText);
        if ($text === '') return $this->emptyResult();

        $educationText = $this->educationSection($text);
        $source = $educationText !== '' ? $educationText : $text;
        $qualId = null; $qualName = null; $major = null; $majorId = null; $confidence = 'low';

        // Prefer explicit degree/qualification evidence anywhere in the resume, but do not
        // treat school subjects or a job title as a degree.
        $degreeRules = [
            3 => ['ph.d', 'phd', 'doctor of philosophy', 'doctorate', 'doctoral'],
            2 => ['m.tech', 'mtech', 'm.e.', 'master of engineering', 'mca', 'master of computer applications', 'm.sc', 'msc', 'm.com', 'mcom', 'm.b.a', 'mba', 'master of business administration', 'm.a.', 'master of arts', 'm.pharm', 'll.m', 'post graduate', 'postgraduate', 'master of'],
            1 => ['b.tech', 'btech', 'b.e.', 'bachelor of engineering', 'bca', 'bachelor of computer applications', 'b.sc', 'bsc', 'b.com', 'bcom', 'b.b.a', 'bba', 'b.a.', 'bachelor of arts', 'bachelor of', 'undergraduate', 'b.pharm', 'mbbs', 'b.ed', 'b.arch', 'll.b'],
        ];
        foreach ($degreeRules as $id => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match('/(?<![a-z])'.preg_quote($pattern,'/').'(?![a-z])/i', $source)) { $qualId=$id; break 2; }
            }
        }
        // Indian school/technical qualification fallback.
        if ($qualId === null && preg_match('/\b(12th|hsc|higher secondary|intermediate|plus\s*two)\b/i', $source)) { $qualId=4; }
        if ($qualId === null && preg_match('/\b(10th|sslc|ssc|matriculation)\b/i', $source)) { $qualId=5; }
        if ($qualId === null && preg_match('/\b(diploma in|polytechnic diploma|diploma)\b/i', $source)) { $qualId=7; }

        if ($qualId !== null) {
            $qual = DB::table('egc_qualification_level')->where('sno',$qualId)->where('status',0)->first();
            if (!$qual) $qual = DB::table('egc_qualification_level')->where('sno',$qualId)->first();
            if ($qual) { $qualName=$qual->qualification_level_name; $confidence='medium'; }
            else { $qualId=null; }
        }

        // Match majors only inside education evidence and only to active master records.
        // Status 0 is the active convention in the supplied schema; fallback to all records
        // only if this installation uses another status convention.
        $majors = DB::table('egc_major')->where('status',0)->get(['sno','qualification_id','major_name','description']);
        if ($majors->isEmpty()) $majors = DB::table('egc_major')->get(['sno','qualification_id','major_name','description']);
        $haystack = Str::lower($source);
        $best = null; $bestScore = 0;
        foreach ($majors as $row) {
            $name = trim((string)$row->major_name);
            if ($name === '' || mb_strlen($name) < 2) continue;
            $aliases = array_unique([$name, (string)($row->description ?? '')]);
            foreach ($aliases as $alias) {
                $alias = trim($alias);
                if ($alias === '' || mb_strlen($alias) < 3) continue;
                $normalizedAlias = Str::lower($this->normalize($alias));
                if (preg_match('/(?<![a-z0-9])'.preg_quote($normalizedAlias,'/').'(?![a-z0-9])/u', $haystack)) {
                    $score = mb_strlen($normalizedAlias) + (($qualId !== null && (int)$row->qualification_id === $qualId) ? 100 : 0);
                    if ($score > $bestScore) { $bestScore=$score; $best=$row; }
                }
            }
        }
        if ($best) {
            $majorId=(int)$best->sno; $major=trim((string)$best->major_name);
            if ($qualId === null) {
                $qualId=(int)$best->qualification_id;
                $q=DB::table('egc_qualification_level')->where('sno',$qualId)->first();
                $qualName=$q->qualification_level_name ?? null;
            }
            $confidence='high';
        }
        // Do not force a guessed major when only a qualification level is evident.
        return [
            'candidate_qualification' => $qualId,
            'candidate_qualification_name' => $qualName,
            'candidate_major' => $majorId,
            'candidate_major_name' => $major,
            'candidate_other_qualify' => null,
            'candidate_qualification_major_source' => $majorId ? 'database_major_match' : ($qualId ? 'database_qualification_match' : 'not_found'),
            'candidate_qualification_major_confidence' => $confidence,
            'candidate_qualification_major_parser_version' => self::VERSION,
        ];
    }

    private function educationSection(string $text): string
    {
        $lines = preg_split('/\R/u', $text) ?: [];
        $start = null; $end = count($lines);
        foreach ($lines as $i=>$line) {
            if (preg_match('/^\s*(education(?:al background)?|academic qualification|qualification|academics)\s*[:\-]?\s*$/i', trim($line))) { $start=$i; break; }
        }
        if ($start === null) return $text;
        for ($i=$start+1; $i<count($lines); $i++) {
            if (preg_match('/^\s*(work experience|professional experience|internship|skills|projects|certifications|achievements|personal details|declaration|languages)\s*[:\-]?\s*$/i', trim($lines[$i]))) { $end=$i; break; }
        }
        return implode("\n", array_slice($lines,$start,min(120,$end-$start)));
    }

    private function normalize(string $text): string
    {
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[\x{00A0}\x{200B}\x{FEFF}]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function emptyResult(): array
    {
        return ['candidate_qualification'=>null,'candidate_qualification_name'=>null,'candidate_major'=>null,'candidate_major_name'=>null,'candidate_other_qualify'=>null,'candidate_qualification_major_source'=>'not_found','candidate_qualification_major_confidence'=>'low','candidate_qualification_major_parser_version'=>self::VERSION];
    }
}
