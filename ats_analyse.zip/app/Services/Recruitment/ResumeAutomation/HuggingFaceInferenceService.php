<?php

namespace App\Services\Recruitment\ResumeAutomation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/** Small, bounded Hugging Face chat-completions adapter for name-only extraction. */
class HuggingFaceInferenceService
{
    private bool $lastRequestAttempted = false;

    public function wasLastRequestAttempted(): bool
    {
        return $this->lastRequestAttempted;
    }

    /**
     * Return model candidates in configured order. CandidateNameExtractionService
     * verifies each candidate against the original resume header before accepting it.
     *
     * @return \Generator<int,array{name:string,model:string,model_index:int}>
     */
    public function extractNameCandidates(string $redactedHeader): \Generator
    {
        $this->lastRequestAttempted = false;
        $token = $this->getToken();
        if ($token === '' || trim($redactedHeader) === '' || !config('recruitment_resume_ai.huggingface.enabled', true)) {
            return;
        }

        $models = $this->getModels();
        $endpoint = rtrim((string) config('recruitment_resume_ai.huggingface.endpoint', 'https://router.huggingface.co/v1/chat/completions'), '/');
        $timeout = min(25, max(3, (int) config('recruitment_resume_ai.huggingface.timeout_seconds', 8)));
        $connectTimeout = min($timeout, max(1, (int) config('recruitment_resume_ai.huggingface.connect_timeout_seconds', 2)));
        Log::info('Hugging Face candidate-name model request started');
        foreach ($models as $index => $model) {
            try {
                $this->lastRequestAttempted = true;
                $response = Http::acceptJson()
                    ->asJson()
                    ->withToken($token)
                    ->connectTimeout($connectTimeout)
                    ->timeout($timeout)
                    ->post($endpoint, [
                        'model' => $model,
                        'temperature' => 0,
                        'max_tokens' => 80,
                        'stream' => false,
                        'messages' => [
                            [
                                'role' => 'system',
                                'content' => 'You are an ATS candidate-identity extractor. Return exactly one JSON object with a single string property named name. Identify only the resume owner, not a certification or award title, skill/tool, project, employer, school, job title, parent/spouse, reference, or contact. Prefer a standalone personal-name line near the resume owner\'s phone/email, usually in the opening identity block. The excerpt may have PDF/OCR reading-order errors, so inspect the supplied excerpt rather than picking the first title-cased phrase. Preserve Indian initials and spelling exactly; do not expand initials, invent missing letters, or split letters into character fragments. Never emit angle brackets or markup. If uncertain, return {\"name\":\"\"}. No markdown or explanation.',
                            ],
                            [
                                'role' => 'user',
                                'content' => "Extract the resume owner's full name from the bounded resume excerpt below. The excerpt may include skills, education, projects, awards and certifications: never select a phrase from those lists. Prefer a standalone personal-name line near redacted contact details. The PDF text order may be imperfect; compare all candidate-like lines and choose only a source-supported person name. Preserve all initials when they are present; do not guess missing initials. Do not output angle brackets, markup, or a name split into character fragments. If no reliable person name is visible, return an empty string.\n\nReturn JSON only: {\"name\":\"...\"}\n\nResume excerpt (contact values are redacted):\n" . $redactedHeader,
                            ],
                        ],
                    ]);
                // Do not write the complete model response to production logs: it can
                // contain resume-derived personal data. Status/model are sufficient for diagnostics.
                // Never log the HTTP response object or generated text: either can
                // contain candidate personal data. Keep only non-sensitive metadata.
                Log::debug('Hugging Face candidate-name model response received', [
                    'model' => $model,
                    'status' => $response->status(),
                ]);
                if (!$response->successful()) {
                    Log::warning('Hugging Face candidate-name model request failed', [
                        'model' => $model,
                        'status' => $response->status(),
                    ]);
                    continue;
                }
                

                $content = $response->json('choices.0.message.content');
                if (!is_string($content) || trim($content) === '') {
                    continue;
                }

                $decoded = $this->decodeJsonContent($content);
                $name = is_array($decoded) ? trim((string) ($decoded['name'] ?? '')) : '';
                if ($name !== '') {
                    // Yield lazily so the caller can stop immediately after a verified
                    // primary-model result; fallback inference is paid for only if needed.
                    yield [
                        'name' => $name,
                        'model' => $model,
                        'model_index' => (int) $index,
                    ];
                }
            } catch (Throwable $e) {
                // Do not log request text, resume contents, access tokens, or responses.
                Log::warning('Hugging Face candidate-name model is unavailable', [
                    'model' => $model,
                    'exception' => get_class($e),
                ]);
            }
        }

    }

    private function getToken(): string
    {
        $configuredToken = trim((string) config('recruitment_resume_ai.huggingface.token', ''));
        if ($configuredToken !== '') {
            return $configuredToken;
        }

        // Backwards-compatible secret lookup for installations already storing their
        // Hugging Face key in egc_api_integration. New deployments should prefer HF_TOKEN.
        try {
            $integration = DB::table('egc_api_integration')
                ->where('api_key', 'egc_huggingface_api_1')
                ->where('status', 0)
                ->orderByDesc('sno')
                ->first(['api_fields']);

            $fields = json_decode((string) ($integration->api_fields ?? ''), true);
            if (!is_array($fields)) return '';

            foreach ($fields as $field) {
                if (is_array($field) && ($field['key'] ?? null) === 'api_key') {
                    return trim((string) ($field['value'] ?? ''));
                }
            }
        } catch (Throwable $e) {
            Log::warning('Hugging Face credential lookup was unavailable', [
                'exception' => get_class($e),
            ]);
        }

        return '';
    }

    /** @return list<string> */
    private function getModels(): array
    {
        $configured = config('recruitment_resume_ai.huggingface.models', ['meta-llama/Llama-3.1-8B-Instruct:fastest']);
        if (is_string($configured)) {
            $configured = explode(',', $configured);
        }
        if (!is_array($configured)) $configured = [];

        $models = [];
        foreach ($configured as $model) {
            if (!is_string($model)) continue;
            $model = trim($model);
            if ($model !== '' && !in_array($model, $models, true)) $models[] = $model;
        }

        // One paid inference request per resume by default. Increase only if you
        // explicitly want paid LLM fallback attempts; deterministic local parsing
        // always runs when the first model is unavailable or unverified.
        $maxAttempts = max(1, min(3, (int) config('recruitment_resume_ai.huggingface.max_model_attempts', 1)));
        return array_slice($models, 0, $maxAttempts);
    }

    private function decodeJsonContent(string $content): ?array
    {
        $content = trim($content);
        $content = preg_replace('/^```(?:json)?\s*|\s*```$/i', '', $content) ?? $content;
        $decoded = json_decode($content, true);
        if (is_array($decoded)) return $decoded;

        // Some instruction models surround their JSON response with a short thought
        // block. Extract only the first JSON object; the resulting name is still verified.
        if (preg_match('/\{(?:[^{}]|(?R))*\}/s', $content, $matches)) {
            $decoded = json_decode($matches[0], true);
            if (is_array($decoded)) return $decoded;
        }

        return null;
    }
}
