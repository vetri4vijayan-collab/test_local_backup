<?php

namespace App\Services\ApplicantResumeStorage;

use Aws\S3\S3Client;
use App\Services\CloudStorage\WasabiS3ClientFactory;
use App\Services\CloudStorage\CloudStorageManager;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * Private, S3-compatible storage for applicant resumes.
 *
 * This service deliberately uses the AWS SDK directly rather than Laravel's
 * Filesystem adapter so it can be introduced without changing existing disks.
 * Objects are private by default (no ACL is sent); access is through short-lived
 * presigned GET requests generated only after the ERP request is authorized.
 */
class WasabiResumeStorageService
{
    public function isConfigured(): bool
    {
        return (bool) config('wasabi.enabled', true)
            && $this->resumeFeatureEnabled()
            && trim((string) config('wasabi.access_key')) !== ''
            && trim((string) config('wasabi.secret_key')) !== ''
            && trim((string) config('wasabi.bucket')) !== ''
            && trim((string) config('wasabi.endpoint')) !== '';
    }

    /** Feature-specific kill switch. If the common registry exists, its DB value wins. */
    private function resumeFeatureEnabled(): bool
    {
        try {
            if (DB::getSchemaBuilder()->hasTable('egc_storage_feature_settings')) {
                $feature = DB::table('egc_storage_feature_settings')
                    ->where('feature_key', 'applicant.resume')
                    ->first();
                if (!$feature) return false;
                return (bool) $feature->enabled
                    && (bool) $feature->private_access
                    && strtolower((string) $feature->driver) === 'wasabi';
            }
        } catch (Throwable $e) {
            // During initial deployment, keep the config fallback rather than interrupting legacy resume access.
        }

        $features = (array) config('erp_storage.features', []);
        $feature = $features['applicant.resume'] ?? null;
        return is_array($feature)
            ? (bool) ($feature['enabled'] ?? false)
                && (bool) ($feature['private_access'] ?? true)
                && strtolower((string) ($feature['driver'] ?? 'wasabi')) === 'wasabi'
            : true;
    }

    public function assertConfigured(): void
    {
        if (!$this->isConfigured()) {
            throw new RuntimeException('Wasabi is disabled or not fully configured. Verify WASABI_ENABLED, access key, secret key, bucket and endpoint.');
        }

        if (!class_exists(S3Client::class)) {
            throw new RuntimeException('AWS SDK is missing. Install aws/aws-sdk-php before enabling Wasabi storage.');
        }

        if (!DB::getSchemaBuilder()->hasTable('egc_applicant_file_storage')
            || !DB::getSchemaBuilder()->hasTable('egc_applicant_storage_audit')
            || !DB::getSchemaBuilder()->hasTable('egc_storage_feature_settings')
            || !DB::getSchemaBuilder()->hasTable('egc_storage_objects')
            || !DB::getSchemaBuilder()->hasTable('egc_storage_audit')) {
            throw new RuntimeException('ERP common storage SQL has not been applied. Run database/sql/erp_common_storage.sql first.');
        }
    }

    private function client(): S3Client
    {
        return app(WasabiS3ClientFactory::class)->client();
    }

    /** Upload an existing local file, verify it exists on Wasabi, then track it in SQL. */
    public function storePath(
        int $applicantSno,
        string $sourcePath,
        string $originalName,
        string $sourceProvider = 'upload',
        ?string $sourceReference = null,
        ?int $actorId = null,
        bool $replace = false
    ): array {
        $this->assertConfigured();

        if ($applicantSno < 1 || !is_file($sourcePath) || !is_readable($sourcePath)) {
            throw new RuntimeException('Applicant id or source resume file is invalid or unreadable.');
        }

        $size = filesize($sourcePath);
        if ($size === false || $size < 1) {
            throw new RuntimeException('The source resume is empty or could not be inspected.');
        }
        $maxBytes = max(1, (int) config('wasabi.max_file_size_bytes', 52428800));
        if ($size > $maxBytes) {
            throw new RuntimeException('Resume exceeds WASABI_MAX_FILE_SIZE_BYTES (' . $maxBytes . ' bytes).');
        }

        $safeName = $this->safeOriginalName($originalName);
        $extension = strtolower((string) pathinfo($safeName, PATHINFO_EXTENSION));
        $extension = preg_replace('/[^a-z0-9]/', '', $extension) ?: 'bin';
        $mimeType = $this->detectMimeType($sourcePath);
        $sha256 = hash_file('sha256', $sourcePath);
        if (!is_string($sha256) || strlen($sha256) !== 64) {
            throw new RuntimeException('Unable to calculate resume SHA-256 checksum.');
        }

        $bucket = (string) config('wasabi.bucket');
        $prefix = trim((string) config('wasabi.prefix', 'erp'), '/');
        $objectKey = ($prefix !== '' ? $prefix . '/' : '')
            . 'applicants/' . $applicantSno . '/resumes/' . (string) Str::uuid() . '.' . $extension;

        $stream = fopen($sourcePath, 'rb');
        if ($stream === false) {
            throw new RuntimeException('Unable to open the source resume for upload.');
        }

        try {
            $this->client()->putObject([
                'Bucket' => $bucket,
                'Key' => $objectKey,
                'Body' => $stream,
                'ContentType' => $mimeType,
                'CacheControl' => 'private, max-age=0, no-cache, no-store',
                'Metadata' => [
                    'applicant-sno' => (string) $applicantSno,
                    'sha256' => $sha256,
                    'source-provider' => preg_replace('/[^a-z0-9_-]/i', '', $sourceProvider) ?: 'upload',
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Wasabi resume upload failed.', [
                'applicant_sno' => $applicantSno,
                'source_provider' => $sourceProvider,
                'message' => $e->getMessage(),
            ]);
            throw new RuntimeException('Wasabi resume upload failed. The existing resume was not changed.', 0, $e);
        } finally {
            if (is_resource($stream)) {
                fclose($stream);
            }
        }

        // Verify the stored object's length/checksum metadata before switching the active pointer.
        try {
            $head = $this->client()->headObject(['Bucket' => $bucket, 'Key' => $objectKey]);
            $storedSize = (int) ($head['ContentLength'] ?? -1);
            $storedHash = (string) ($head['Metadata']['sha256'] ?? '');
            if ($storedSize !== (int) $size || !hash_equals($sha256, $storedHash)) {
                throw new RuntimeException('Wasabi object verification failed (size or checksum metadata mismatch).');
            }
        } catch (Throwable $e) {
            try { $this->client()->deleteObject(['Bucket' => $bucket, 'Key' => $objectKey]); } catch (Throwable $cleanupError) {
                Log::warning('Failed to clean up unverified Wasabi object.', ['key' => $objectKey, 'message' => $cleanupError->getMessage()]);
            }
            throw new RuntimeException('Wasabi uploaded the resume but verification did not pass; existing storage metadata was preserved.', 0, $e);
        }

        $previousKey = null;
        $sharedObjectId = null;
        try {
            DB::transaction(function () use (
                $applicantSno, $bucket, $objectKey, $safeName, $mimeType, $size, $sha256,
                $sourceProvider, $sourceReference, $actorId, $replace, &$previousKey, &$sharedObjectId
            ) {
                $existing = DB::table('egc_applicant_file_storage')
                    ->where('applicant_sno', $applicantSno)
                    ->lockForUpdate()
                    ->first();

                $existingStatus = (string) ($existing->storage_status ?? '');
                if (in_array($existingStatus, ['active', 'deleting'], true) && !$replace) {
                    throw new RuntimeException('This applicant already has an active or changing Wasabi resume. Use replace explicitly after reviewing the current state.');
                }

                if ($existingStatus === 'active') {
                    $previousKey = (string) ($existing->object_key ?? '');
                }

                $now = now();
                $row = [
                    'applicant_sno' => $applicantSno,
                    'bucket_name' => $bucket,
                    'object_key' => $objectKey,
                    'original_name' => $safeName,
                    'mime_type' => $mimeType,
                    'file_size' => (int) $size,
                    'sha256' => $sha256,
                    'source_provider' => substr(preg_replace('/[^a-z0-9_-]/i', '', $sourceProvider) ?: 'upload', 0, 32),
                    'source_reference_hash' => $sourceReference ? hash('sha256', $sourceReference) : null,
                    'storage_status' => 'active',
                    'deleted_at' => null,
                    'updated_by' => $actorId,
                    'updated_at' => $now,
                ];

                if ($existing) {
                    DB::table('egc_applicant_file_storage')->where('applicant_sno', $applicantSno)->update($row);
                } else {
                    $row['created_by'] = $actorId;
                    $row['created_at'] = $now;
                    DB::table('egc_applicant_file_storage')->insert($row);
                }

                // Register the same verified object in the common ERP registry. This does not
                // upload a second copy; it makes Applicant Resume the first shared-storage feature.
                $sharedObjectId = app(CloudStorageManager::class)->registerExistingObject(
                    'applicant.resume', 'applicant', (string) $applicantSno,
                    $bucket, $objectKey, $safeName, $mimeType, (int) $size, $sha256,
                    $actorId, $sourceProvider, $sourceReference
                );

                $this->audit($applicantSno, 'upload', $sourceProvider, $objectKey, $sha256, 'success', 'Object uploaded, verified and registered in common ERP storage.', $actorId);
            });
        } catch (Throwable $e) {
            try { $this->client()->deleteObject(['Bucket' => $bucket, 'Key' => $objectKey]); } catch (Throwable $cleanupError) {
                Log::warning('Failed to clean up Wasabi object after database tracking failure.', ['key' => $objectKey, 'message' => $cleanupError->getMessage()]);
            }
            throw $e;
        }

        if ($previousKey && $previousKey !== $objectKey && (bool) config('wasabi.delete_previous_on_replace', true)) {
            try {
                $this->client()->deleteObject(['Bucket' => $bucket, 'Key' => $previousKey]);
            } catch (Throwable $e) {
                // The database now points at the verified replacement; a failed old-object cleanup is an orphan, not a broken resume.
                Log::warning('Old Wasabi resume could not be removed after replacement.', [
                    'applicant_sno' => $applicantSno,
                    'old_key' => $previousKey,
                    'message' => $e->getMessage(),
                ]);
                $sharedOld = DB::table('egc_storage_objects')->where('object_key', $previousKey)->where('feature_key', 'applicant.resume')->first();
                app(CloudStorageManager::class)->recordExternalAudit($sharedOld ? (int) $sharedOld->sno : null, 'applicant.resume', 'applicant', (string) $applicantSno, 'cleanup_old_object', $previousKey, null, 'warning', 'New resume is active but cleanup of old cloud object failed.', $actorId);
                $this->audit($applicantSno, 'cleanup_old_object', $sourceProvider, $previousKey, null, 'warning', 'New resume is active but old-object cleanup failed.', $actorId);
            }
        }

        return [
            'applicant_sno' => $applicantSno,
            'provider' => 'wasabi',
            'bucket' => $bucket,
            'object_key' => $objectKey,
            'original_name' => $safeName,
            'mime_type' => $mimeType,
            'file_size' => (int) $size,
            'sha256' => $sha256,
            'source_provider' => $sourceProvider,
            'shared_storage_object_sno' => $sharedObjectId,
        ];
    }

    public function activeRow(int $applicantSno): ?object
    {
        $this->assertConfigured();
        return DB::table('egc_applicant_file_storage')
            ->where('applicant_sno', $applicantSno)
            ->where('storage_status', 'active')
            ->first();
    }

    public function anyRow(int $applicantSno): ?object
    {
        $this->assertConfigured();
        return DB::table('egc_applicant_file_storage')
            ->where('applicant_sno', $applicantSno)
            ->first();
    }

    /** Confirm that the tracked object is actually readable before redirecting the browser to a signed URL. */
    public function objectAvailable(object $row): bool
    {
        try {
            $this->assertConfigured();
            $bucket = trim((string) ($row->bucket_name ?? ''));
            $key = trim((string) ($row->object_key ?? ''));
            if ($bucket === '' || $key === '') {
                return false;
            }

            $this->client()->headObject([
                'Bucket' => $bucket,
                'Key' => $key,
            ]);

            return true;
        } catch (Throwable $e) {
            // A stale key, missing object, expired credentials, or a Wasabi outage must not break legacy fallback.
            Log::notice('Tracked Wasabi resume is not currently reachable; trying the next resume source.', [
                'applicant_sno' => (int) ($row->applicant_sno ?? 0),
                'exception' => get_class($e),
                'message' => $e->getMessage(),
            ]);
            return false;
        }
    }

    public function temporaryUrl(object $row, string $disposition = 'inline', ?int $expirySeconds = null): string
    {
        $this->assertConfigured();
        if (!in_array($disposition, ['inline', 'attachment'], true)) {
            throw new RuntimeException('Invalid content disposition.');
        }

        $expiry = $expirySeconds ?? (int) config('wasabi.url_expiry_seconds', 300);
        $expiry = max(60, min(900, $expiry));
        $name = $this->safeOriginalName((string) ($row->original_name ?? 'resume'));
        $extension = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
        if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) {
            // Do not render active content inline, even when the object lives on another origin.
            $disposition = 'attachment';
        }
        $asciiName = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'resume';
        $contentDisposition = $disposition . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name);

        $command = $this->client()->getCommand('GetObject', [
            'Bucket' => (string) $row->bucket_name,
            'Key' => (string) $row->object_key,
            'ResponseContentType' => (string) ($row->mime_type ?: 'application/octet-stream'),
            'ResponseContentDisposition' => $contentDisposition,
            'ResponseCacheControl' => 'private, no-store, max-age=0',
        ]);

        return (string) $this->client()->createPresignedRequest($command, '+' . $expiry . ' seconds')->getUri();
    }

    public function downloadToPath(object $row, string $destinationPath): void
    {
        $this->assertConfigured();
        $directory = dirname($destinationPath);
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new RuntimeException('Unable to create temporary resume directory.');
        }

        $response = $this->client()->getObject([
            'Bucket' => (string) $row->bucket_name,
            'Key' => (string) $row->object_key,
        ]);
        $body = $response['Body'] ?? null;
        $out = fopen($destinationPath, 'wb');
        if ($out === false) {
            throw new RuntimeException('Unable to create destination for resume download.');
        }

        try {
            if (is_resource($body)) {
                stream_copy_to_stream($body, $out);
            } elseif (is_object($body) && method_exists($body, 'eof') && method_exists($body, 'read')) {
                while (!$body->eof()) {
                    $chunk = $body->read(1024 * 1024);
                    if ($chunk === '') break;
                    fwrite($out, $chunk);
                }
            } else {
                throw new RuntimeException('Unexpected response stream from Wasabi.');
            }
        } finally {
            fclose($out);
        }

        $downloadedSize = is_file($destinationPath) ? filesize($destinationPath) : false;
        $downloadedHash = is_file($destinationPath) ? hash_file('sha256', $destinationPath) : false;
        if ($downloadedSize !== (int) ($row->file_size ?? -1)
            || !is_string($downloadedHash)
            || !hash_equals((string) ($row->sha256 ?? ''), $downloadedHash)) {
            @unlink($destinationPath);
            throw new RuntimeException('Downloaded Wasabi resume failed size or SHA-256 verification.');
        }
    }

    /** Delete with an intermediate state so a failed database finalization does not falsely show an active object. */
    public function deleteApplicantObject(int $applicantSno, ?int $actorId = null): bool
    {
        $this->assertConfigured();
        $row = DB::table('egc_applicant_file_storage')
            ->where('applicant_sno', $applicantSno)
            ->first();

        if (!$row || ($row->storage_status ?? '') !== 'active') {
            return false;
        }

        $claimed = false;
        DB::transaction(function () use ($applicantSno, $row, $actorId, &$claimed) {
            $affected = DB::table('egc_applicant_file_storage')
                ->where('applicant_sno', $applicantSno)
                ->where('object_key', (string) $row->object_key)
                ->where('storage_status', 'active')
                ->update([
                    'storage_status' => 'deleting',
                    'updated_by' => $actorId,
                    'updated_at' => now(),
                ]);
            $claimed = $affected > 0;
            if ($claimed) {
                DB::table('egc_storage_objects')
                    ->where('object_key', (string) $row->object_key)
                    ->where('feature_key', 'applicant.resume')
                    ->where('storage_status', 'active')
                    ->update(['storage_status' => 'deleting', 'updated_by' => $actorId, 'updated_at' => now()]);
                $shared = DB::table('egc_storage_objects')->where('object_key', (string) $row->object_key)->where('feature_key', 'applicant.resume')->first();
                app(CloudStorageManager::class)->recordExternalAudit($shared ? (int) $shared->sno : null, 'applicant.resume', 'applicant', (string) $applicantSno, 'delete_started', (string) $row->object_key, (string) $row->sha256, 'pending', 'Applicant resume deletion claimed.', $actorId);
                $this->audit($applicantSno, 'delete_started', (string) $row->source_provider, (string) $row->object_key, (string) $row->sha256, 'pending', 'Deletion claimed; cloud deletion is in progress.', $actorId);
            }
        });
        if (!$claimed) return false;

        try {
            $this->client()->deleteObject([
                'Bucket' => (string) $row->bucket_name,
                'Key' => (string) $row->object_key,
            ]);
        } catch (Throwable $e) {
            DB::transaction(function () use ($applicantSno, $row, $actorId, $e) {
                DB::table('egc_applicant_file_storage')
                    ->where('applicant_sno', $applicantSno)
                    ->where('object_key', (string) $row->object_key)
                    ->where('storage_status', 'deleting')
                    ->update([
                        'storage_status' => 'active',
                        'deleted_at' => null,
                        'updated_by' => $actorId,
                        'updated_at' => now(),
                    ]);
                DB::table('egc_storage_objects')
                    ->where('object_key', (string) $row->object_key)
                    ->where('feature_key', 'applicant.resume')
                    ->where('storage_status', 'deleting')
                    ->update(['storage_status' => 'active', 'deleted_at' => null, 'updated_by' => $actorId, 'updated_at' => now()]);
                $shared = DB::table('egc_storage_objects')->where('object_key', (string) $row->object_key)->where('feature_key', 'applicant.resume')->first();
                app(CloudStorageManager::class)->recordExternalAudit($shared ? (int) $shared->sno : null, 'applicant.resume', 'applicant', (string) $applicantSno, 'delete', (string) $row->object_key, (string) $row->sha256, 'failed', 'Cloud deletion failed; active pointer restored.', $actorId);
                $this->audit($applicantSno, 'delete', (string) $row->source_provider, (string) $row->object_key, (string) $row->sha256, 'failed', 'Cloud deletion failed; active pointer restored. ' . $e->getMessage(), $actorId);
            });
            throw new RuntimeException('Wasabi object could not be deleted; the active storage pointer was restored.', 0, $e);
        }

        $markedDeleted = false;
        DB::transaction(function () use ($applicantSno, $row, $actorId, &$markedDeleted) {
            $affected = DB::table('egc_applicant_file_storage')
                ->where('applicant_sno', $applicantSno)
                ->where('object_key', (string) $row->object_key)
                ->where('storage_status', 'deleting')
                ->update([
                    'storage_status' => 'deleted',
                    'deleted_at' => now(),
                    'updated_by' => $actorId,
                    'updated_at' => now(),
                ]);
            $markedDeleted = $affected > 0;
            DB::table('egc_storage_objects')
                ->where('object_key', (string) $row->object_key)
                ->where('feature_key', 'applicant.resume')
                ->where('storage_status', 'deleting')
                ->update(['storage_status' => 'deleted', 'deleted_at' => now(), 'updated_by' => $actorId, 'updated_at' => now()]);
            $shared = DB::table('egc_storage_objects')->where('object_key', (string) $row->object_key)->where('feature_key', 'applicant.resume')->first();
            app(CloudStorageManager::class)->recordExternalAudit($shared ? (int) $shared->sno : null, 'applicant.resume', 'applicant', (string) $applicantSno, 'delete', (string) $row->object_key, (string) $row->sha256, $markedDeleted ? 'success' : 'warning', 'Applicant resume cloud object deletion finalized.', $actorId);
            $this->audit(
                $applicantSno,
                'delete',
                (string) $row->source_provider,
                (string) $row->object_key,
                (string) $row->sha256,
                $markedDeleted ? 'success' : 'warning',
                $markedDeleted ? 'Wasabi object deleted. Legacy source was preserved for rollback.' : 'Cloud object was deleted, but storage metadata changed concurrently; the current pointer was preserved.',
                $actorId
            );
        });

        return $markedDeleted;
    }

    public function audit(
        int $applicantSno,
        string $action,
        ?string $sourceProvider,
        ?string $objectKey,
        ?string $sha256,
        string $outcome,
        string $message,
        ?int $actorId = null
    ): void {
        try {
            DB::table('egc_applicant_storage_audit')->insert([
                'applicant_sno' => $applicantSno,
                'action_name' => substr($action, 0, 40),
                'source_provider' => substr((string) $sourceProvider, 0, 32) ?: null,
                'object_key' => $objectKey,
                'sha256' => $sha256,
                'outcome' => substr($outcome, 0, 20),
                'message' => mb_substr($message, 0, 4000),
                'actor_id' => $actorId,
                'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            // Audit trouble must not mask the primary failure; the database/table is checked before normal operations.
            Log::warning('Could not write applicant storage audit row.', ['applicant_sno' => $applicantSno, 'message' => $e->getMessage()]);
        }
    }

    public function safeOriginalName(string $name): string
    {
        $name = basename(str_replace('\\', '/', trim($name)));
        $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? 'resume';
        $name = trim($name, " .\t\n\r\0\x0B");
        if ($name === '' || $name === '.' || $name === '..') $name = 'resume';
        return mb_substr($name, 0, 240);
    }

    private function detectMimeType(string $path): string
    {
        $mime = function_exists('finfo_open') ? (new \finfo(FILEINFO_MIME_TYPE))->file($path) : false;
        if (!is_string($mime) || $mime === '') {
            $mime = function_exists('mime_content_type') ? mime_content_type($path) : false;
        }
        return is_string($mime) && $mime !== '' ? $mime : 'application/octet-stream';
    }
}
