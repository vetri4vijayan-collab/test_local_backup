<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\candidate_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use App\Models\ApplicantModel;
use App\Models\ApplicantLogModel;
use App\Models\InterviewCandidateModel;
use App\Models\JobRequestModel;
use App\Models\ApplicantAtsRoleAnalysisModel;
use App\Models\ApplicantAtsRoleMatchModel;
use App\Models\SourceModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use thiagoalessio\TesseractOCR\TesseractOCR;
use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser;
use Smalot\PdfParser\Parser as PdfParser;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Services\GoogleDriveService;

use App\Services\Recruitment\ResumeAutomation\ResumeTextExtractionService;
use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\CandidateMobileService;
use App\Services\Recruitment\ResumeAutomation\CandidateEmailService;
use App\Services\Recruitment\ResumeAutomation\CandidateJobRoleMatchingService;
use App\Services\Recruitment\ResumeAutomation\CandidateQualificationMajorService;
use App\Services\Recruitment\ResumeAutomation\CandidateExperienceService;

use App\Services\ApplicantResumeStorage\WasabiResumeStorageService;
use App\Models\ApplicantResumeExtractionModel;



class CandidateManagement extends Controller
{
    protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
        date_default_timezone_set('Asia/Kolkata');
    }

    public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $major_filt = $request->major_filt ?? '';
        $source_name_filt = $request->source_name_filt ?? '';
        $qualification_filt = $request->qualification_filt ?? '';
        $closing_date_filt = $request->closing_date_filt ?? '';
        $exp_type_filt = $request->exp_type_filt ?? '';
        $source_type_filt = $request->source_type_filt ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->from_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_dt_iss_rpt ?? '';
        $old_resume_fill = $request->old_resume_fill ?? '';
        //   $vip_check = $request->vip_check ?? '';
        //   $walkin_check = $request->walkin_check ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';

        $resume_keywords_filt = $request->input('resume_keywords_filt', []);

        $applicant_status_filt = $request->applicant_status_filt ?? '';

            if (is_string($resume_keywords_filt)) {
                $resume_keywords_filt = json_decode($resume_keywords_filt, true);
            }

            if (!is_array($resume_keywords_filt)) {
                $resume_keywords_filt = [];
            }

            $resume_keywords_filt = collect($resume_keywords_filt)
                ->map(function ($keyword) {
                    return trim((string) $keyword);
                })
                ->filter()
                ->unique()
                ->values()
                ->all();
            if ($request->ajax()) {

                $candidateData = ApplicantModel::where('egc_applicant.status','!=',2)
                    ->leftJoin('egc_job_request', 'egc_applicant.job_request_id', 'egc_job_request.sno')
                    ->leftJoin('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
                    ->leftJoin('egc_source', 'egc_applicant.source_id', 'egc_source.sno')
                    ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
                    ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
                    ->leftJoin('egc_major', 'egc_applicant.major', 'egc_major.sno')
                    ->leftJoin('egc_job_fair', 'egc_applicant.job_fair_id', 'egc_job_fair.sno')
                    ->leftJoin('egc_applicant_history_logs', 'egc_applicant.candidate_id', 'egc_applicant_history_logs.candidate_id')
                    ->distinct('egc_applicant.sno')
                    ->select(
                        'egc_applicant.*',
                        'egc_job_request.status as job_request_status',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_job_role.job_position_name as job_role_name',
                        'egc_company.company_name',
                        'egc_major.major_name',
                        'egc_job_fair.job_fair_name',
                        'egc_source.source_name as applicant_source_name',
                        'egc_company.company_base_color'
                        );

                if($search_filter != '') {
                    $candidateData->where(function ($subquery) use ($search_filter) {
                        $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.applicant_name', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.mobile', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.old_data', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.resume_text', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.description', 'LIKE', "%{$search_filter}%")
                            ->orWhere('egc_applicant.email', 'LIKE', "%{$search_filter}%");
                    });
                }

                if (!empty($resume_keywords_filt)) {
                    foreach ($resume_keywords_filt as $keyword) {
                        $candidateData->where(
                            'egc_applicant.resume_text',
                            'LIKE',
                            '%' . $keyword . '%'
                        );
                    }
                }

                switch ($dashboard_filter) {
                    case 'today':
                        $candidateData->whereDate('egc_applicant.created_at', now()->toDateString());
                        break;
                    case 'month':
                        $candidateData->whereMonth('egc_applicant.created_at', now()->month)->whereYear('egc_applicant.created_at', now()->year );
                        break;
                    case 'fresher':
                        $candidateData->where( 'egc_applicant.experience_id', 1);
                        break;
                    case 'experienced':
                        $candidateData->where('egc_applicant.experience_id', 2 );
                        break;
                    case 'jobfair':
                        $candidateData->where('egc_applicant.job_fair_id','>',0);
                        break;
                    case 'walkin':
                        $candidateData->where('egc_applicant.source_id', 6);
                        break;
                    case 'vip':
                        $candidateData->where('egc_applicant.vip_check',1);
                        break;
                    case 'career':
                        $candidateData->where('egc_applicant.career_portal', 1);
                        break;
                }

                if ($source_type_filt !=='') {
                if($source_type_filt =='resource'){
                    $candidateData->where('egc_applicant.job_request_id', '>',0);
                }elseif($source_type_filt =='old_data'){
                    $candidateData->where('egc_applicant.recruitment_id','>',0);
                }elseif($source_type_filt =='job_fair'){
                    $candidateData->where('egc_applicant.job_fair_id','>',0);
                }
                }

                // if ($vip_check) {
                //     $candidateData->where('egc_applicant.vip_check', 1);
                // }

                // if ($walkin_check) {
                //     $candidateData->where('egc_applicant.source_id', 6);
                // }

                if ($source_name_filt) {
                    $candidateData->where('egc_applicant.source_id', $source_name_filt);
                }
            
                if (!empty($exp_type_filt)) {
                $candidateData->where(function ($query) use ($exp_type_filt) {
                    $query->where(function ($q) use ($exp_type_filt) {
                        $q->where('egc_applicant.recruitment_id', 0)
                            ->where('egc_applicant.experience_id', $exp_type_filt);
                    });
                    $query->orWhere(function ($q) use ($exp_type_filt) {
                        $q->where('egc_applicant.recruitment_id', '>', 0);

                        if ($exp_type_filt == 1) {
                            // Fresher
                            $q->where('egc_applicant.experience_id', 2);
                        } elseif ($exp_type_filt == 2) {
                            // Experience
                            $q->where('egc_applicant.experience_id', '>=', 3);
                        }
                    });

                });
                }

                if (!empty($qualification_filt)) {
                    $candidateData->where(function ($query) use ($qualification_filt) {
                        
                        $query->where(function ($q) use ($qualification_filt) {
                            $q->where('egc_applicant.recruitment_id', 0)
                                ->where('egc_applicant.qualification_id', $qualification_filt);
                        });

                        
                        $query->orWhere(function ($q) use ($qualification_filt) {

                            $q->where('egc_applicant.recruitment_id', '>', 0);

                            if ($qualification_filt == 1) {
                                // UG → old_data qualification_id = 5
                                $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 5");
                            }

                            elseif ($qualification_filt == 2) {
                                // PG → 3,4
                                $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (3,4)");
                            }

                            elseif ($qualification_filt == 3) {
                                // Doctorate → 2
                                $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 2");
                            }

                            elseif ($qualification_filt == 'Others' || $qualification_filt == '4' || $qualification_filt == '5' || $qualification_filt == '6') {
                                // Others → 6,7
                                $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (6,7)");
                            }

                        });

                    });
                }

                if ($major_filt) {
                    $candidateData->where('egc_applicant.major', $major_filt);
                }

                if ($applicant_status_filt !='') {
                    $candidateData->where('egc_applicant_history_logs.applicant_status', $applicant_status_filt);
                }

                if ($old_resume_fill !=='') {
                $candidateData->where('egc_applicant.recruitment_id','>',0)->where('egc_applicant.recruitment_file', $old_resume_fill);
                }

                if ($date_filter == "today") {
                $todayDate = date("Y-m-d");
                $candidateData->whereDate('egc_applicant.created_at', $todayDate);
                } elseif ($date_filter == "week") {
                $today = date('l');
                if ($today == "Sunday") {
                    $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                    $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
                } else {
                    $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                    $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
                }
                $candidateData->whereBetween('egc_applicant.created_at', [$weekFromDate, $weekToDate]);
                } elseif ($date_filter == "monthly") {
                $firstDayOfMonth = date('Y-m-01');
                $lastDayOfMonth = date('Y-m-t');
                $candidateData->whereBetween('egc_applicant.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
                } elseif ($date_filter == "custom_date") {
                if ($from_date_filter && $to_date_filter) {
                    $fromDate = date('Y-m-d', strtotime($from_date_filter));
                    $toDate = date('Y-m-d', strtotime($to_date_filter));
                    $candidateData->whereBetween('egc_applicant.created_at', [$fromDate, $toDate]);
                } elseif ($from_date_filter) {
                    $fromDate = date('Y-m-d', strtotime($from_date_filter));
                    $candidateData->where('egc_applicant.created_at', '>=', $fromDate);
                } elseif ($to_date_filter) {
                    $toDate = date('Y-m-d', strtotime($to_date_filter));
                    $candidateData->where('egc_applicant.created_at', '<=', $toDate);
                }
                }else{
                if ($closing_date_filt) {
                    $candidateData->whereDate('egc_applicant.created_at',date('Y-m-d', strtotime($closing_date_filt)));
                }
                }

                $candidateData=$candidateData->orderBy('egc_applicant.sno', 'desc')
                        ->paginate($perpage);

                $aiRoleIds = $candidateData
                    ->pluck('job_role_id')
                    ->filter()
                    ->map(function ($id) {

                        $decoded = json_decode($id, true);

                        return is_array($decoded) ? $decoded : [];

                    })
                    ->flatten()
                    ->unique()
                    ->values()
                    ->toArray();

                $aiRoleNames = DB::table('egc_recruitment_roles')
                    ->whereIn('sno', $aiRoleIds)
                    ->pluck('role_name', 'sno')
                    ->toArray();

                $today_candidates = ApplicantModel::whereDate('egc_applicant.created_at', date('Y-m-d'))->where('egc_applicant.status','!=',2)->count();

                $month_candidates = ApplicantModel::whereBetween('egc_applicant.created_at', [date('Y-m-01'), date('Y-m-t')])->where('egc_applicant.status','!=',2)->count();

                $fresher_candidates = ApplicantModel::where('egc_applicant.status','!=',2)->where(function ($query) {
                    $query->where(function ($q) {
                        $q->where('egc_applicant.recruitment_id', 0)
                        ->where('egc_applicant.experience_id', 1);
                    });
                    $query->orWhere(function ($q) {
                        $q->where('egc_applicant.recruitment_id', '>', 0)
                        ->where('egc_applicant.experience_id', 2);
                        
                    });

                })->count();

                $experience_candidates = ApplicantModel::where('egc_applicant.status','!=',2)->where(function ($query) {
                    $query->where(function ($q) {
                        $q->where('egc_applicant.recruitment_id', 0)
                            ->where('egc_applicant.experience_id', 2);
                    });
                    $query->orWhere(function ($q) {
                        $q->where('egc_applicant.recruitment_id', '>', 0)
                        ->where('egc_applicant.experience_id', '>=', 3);
                    });
                })->count();

                $job_fair_candidates= ApplicantModel::where('egc_applicant.status','!=',2)->where('egc_applicant.job_fair_id','>',0)->count();
                $walkin_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.source_id', 6)->count();
                $vip_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.vip_check', 1)->count();
                $career_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.career_portal', 1)->count();

                $helper = new \App\Helpers\Helpers();

            

                $data = $candidateData->map(function ($item) use ($helper, $aiRoleNames) {

                    $roleIds = json_decode( $item->job_role_id, true);

                    if(is_array($roleIds)) {
                        $item->display_job_role_name = collect($roleIds)
                            ->map(function($id) use ($aiRoleNames){
                                return $aiRoleNames[$id] ?? null;
                            })
                            ->filter()
                            ->implode(', ');
                    } else {
                        $item->display_job_role_name = $item->job_role_name;
                    }

                    return [
                        'sno' => $item->sno,
                        'vip_check' => $item->vip_check,
                        'status' => $item->status,
                        'data' => $item,
                        'old_data' => $item->old_data,
                        'drive_data' => $item->drive_data,
                        
                        'resume_view_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/open?disposition=inline'),
                        'resume_download_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/open?disposition=attachment'),
                        'resume_urls_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/urls'),

                        'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                        'short_encrypt_id' => base64_encode($item->sno),
                    ];

                });

                return response()->json([
                    'data' => $data,
                    'current_page' => $candidateData->currentPage(),
                    'last_page' => $candidateData->lastPage(),
                    'total' => $candidateData->total(),
                    'today_candidates' => $today_candidates,
                    'month_candidates' => $month_candidates,
                    'fresher_candidates' => $fresher_candidates,
                    'experience_candidates' => $experience_candidates,
                    'job_fair_candidates' => $job_fair_candidates,
                    'walkin_candidates' => $walkin_candidates,
                    'vip_candidates' => $vip_candidates,
                    'career_candidates' => $career_candidates,
                ]);
            }

        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = DB::table('egc_company')->where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list = DB::table('egc_entity')->where('status', 0)->orderBy('sno', 'ASC')->get();
        $recruitment_roles = DB::table('egc_recruitment_roles')
                ->where('status', 0)
                ->orderBy('role_name', 'ASC')
                ->get(['sno', 'role_name']);

        return view('content.hr_management.hr_recruiter.candidate_management.candidate_list', [
            'source_list' => $source_list,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'company_list' => $company_list,
            'entity_list' => $entity_list,
            'recruitment_roles' => $recruitment_roles,
        ]);
    
    }

    public function checkCandidateMobile(Request $request, CandidateMobileService $candidateMobileService)
    {
        $validated = $request->validate([
            'mobile' => ['required', 'string', 'max:24'],
            'exclude_applicant_id' => ['nullable', 'integer', 'min:1'],
        ]);

        $mobile = $candidateMobileService->normalizeIndianMobile((string) $validated['mobile']);
        if ($mobile === null) {
            return response()->json([
                'status' => 422,
                'message' => 'Enter a valid Indian 10-digit mobile number.',
                'data' => ['exists' => false, 'valid' => false],
            ], 422);
        }

        $excludeId = isset($validated['exclude_applicant_id']) ? (int) $validated['exclude_applicant_id'] : null;
        $exists = $candidateMobileService->existsForApplicant($mobile, $excludeId);

        return response()->json([
            'status' => 200,
            'message' => $exists ? 'This mobile number already exists for another candidate.' : 'Mobile number is available.',
            'data' => [
                'valid' => true,
                'exists' => $exists,
                'normalized_mobile' => $mobile,
            ],
        ]);
    }

    public function AddNewCandidateOld(Request $request)
    {
        
        $request->validate([
            'candidate_name' => 'required',
            'candidate_mobile' => 'required',
            'candidate_email' => 'required',
            'candidate_gender'   => 'required|integer',
            'candidate_marital_status' => 'nullable|max:51200'
        ]);
        DB::beginTransaction();

        
        try {
            $resumeFile = null;
            $resumeUrl = null;
            $fullName        = $request->candidate_name;
            $mobile_no       = $request->candidate_mobile;
            $email_id        = $request->candidate_email;
            $gender          = $request->candidate_gender;
            $job_request_id  = $request->apply_job_request_id ?? NULL ;
            $apply_applicant_id  = $request->apply_applicant_id;
            

            $candidateData =  ApplicantModel::where('sno', $apply_applicant_id)->first();
            $job_role_id     = NULL;
            $marital_status  = $request->candidate_marital_status;
            $qualification   = $request->candidate_qualification;
            $major           = $request->candidate_major;
            $OtherQualification           = $request->candidate_other_qualify;
            $exper_type      = $request->candidate_exper_type;
            $exper_count     = $request->candidate_exper_count ?? 0;
            $resume_check     = $request->resume_check ?? 0;
            $source          = $request->source_name ?? 0;
            $description          = $request->description ?? NULL;
            $ipAddress = $request->ip();
            $resumeText = null;
            $userId = auth()->user()->user_id;
            $drive_data=[];

            $alreadyApplied = ApplicantModel::where('mobile', $mobile_no)
                // ->whereDate('created_at', date('Y-m-d'))
                ->where('status', '!=', 2)
                ->exists();

            if ($alreadyApplied) {
                return response()->json([
                    'status'  => 409,
                    'message' => 'You have already applied using this mobile number.',
                ], 409);
            }

            
            $candidate = InterviewCandidateModel::updateOrCreate(
            ['mobile'    => $mobile_no],
            [
                'full_name' => $fullName,
                'email'     => $email_id,
            ]);

            $candidate_id = $candidate->sno;
            
            // return $candidate;
            $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
            $year = date('y');

            if (!$lastApplicant) {
                $applicant_id = "EGCJA-0001-{$year}";
            } else {
                preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
                $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
                $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
            }

            

                if($resume_check == 0){
                    
                    if ($request->hasFile('upload_resume')) {
                        $file = $request->file('upload_resume');
                        $extension = $file->getClientOriginalExtension();

                        $folderPath = public_path('job_applications/resume_files/');

                        if (!File::exists($folderPath)) {
                            File::makeDirectory($folderPath, 0777, true);
                        }

                        // Unique filename
                        $resumeFile = $applicant_id . '.' . $extension;

                        $file->move($folderPath, $resumeFile);
                        $filePath = $folderPath . $resumeFile;
                        $resumeText = $this->extractResumeText($filePath);
                        
                        
                        if (file_exists($filePath)) {
                            $drive_data = $this->UploadFileInDrive($resumeFile);
                        }
                    }
                }
            

                function cleanUtf8($value)
                {
                    if (is_array($value)) {
                        return array_map('cleanUtf8', $value);
                    }

                    if (is_string($value)) {
                        return mb_convert_encoding($value, 'UTF-8', 'UTF-8');
                    }

                    return $value;
                }
                $resumeText  = cleanUtf8($resumeText);

                $majorData=DB::table('egc_major')->where('sno',$major)->first();

                
                if($major == 'Others'){
                    $majorName=$OtherQualification;
                }else{
                        $majorName=$majorData->major_name;
                }
                
                $applicant=ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'candidate_id'      => $candidate_id,
                'applicant_name'    => $fullName,
                'job_request_id'       => 0,
                'job_role_id'       => NULL,
                'mobile'            => $mobile_no,
                'email'             => $email_id,
                'attachment'        => $resumeFile,
                'ipaddress'         => $ipAddress ?? null,
                'resume_text'       => $resumeText ?? NULL,
                'gender'            => $gender,
                'marital_status_id' => $marital_status,
                'qualification_id'  => $qualification,
                'major'             => $major,
                // 'other_qualification' => $OtherQualification ?? NULL,
                'experience_id'     => $exper_type,
                'experience_count'  => $exper_count,
                'source_id'         => $source,
                'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
                'created_by'       => $userId,
                'updated_by'       => $userId,
                'description'       => $description,
            ]);
            
        
                $qualificationName = "Not provided"; 
                $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

                $promptTemplate = "
                    Act as an ATS resume analyzer.

                    I will provide a Resume.

                    Analyze the resume and generate a structured evaluation using metrics.

                    Your output MUST include:

                    1. Overall Resume Quality Score (0–100%)
                    2. ATS Keyword Strength Score (0–100%)
                    3. Skills Quality Score (0–100%)
                    4. Experience Quality Score (0–100%)
                    5. Impact & Metrics Score (0–100%)
                    (Check if the resume includes measurable achievements like %, $, time saved, growth, efficiency gains)

                    6. Resume Structure & Clarity Score (0–100%)

                    7. Missing Important Resume Elements (list them)
                    8. Strengths of the Resume
                    9. Weaknesses / Gaps in the Resume
                    10. Top 5 Resume Improvements (specific edits)
                    11. Rewrite 2–3 bullet points in an achievement-focused format
                    12. Suggest an optimized Professional Summary (3–4 lines)

                    Important Rules:
                    - Be strict and realistic like a recruiter.
                    - Highlight weak sections clearly.
                    - Suggest improvements for a stronger resume.
                    - Do NOT add unnecessary explanations.

                    VERY IMPORTANT:
                    Return the response ONLY in valid JSON format using this structure:

                    {
                    \"overall_resume_score\": 0,
                    \"ats_keyword_strength_score\": 0,
                    \"skills_quality_score\": 0,
                    \"experience_quality_score\": 0,
                    \"impact_metrics_score\": 0,
                    \"resume_structure_score\": 0,
                    \"missing_resume_elements\": [],
                    \"strengths\": [],
                    \"weaknesses\": [],
                    \"resume_improvements\": [],
                    \"rewritten_bullets\": [],
                    \"optimized_summary\": \"\"
                    }

                    Resume is provided below:
                    {{RESUME_TEXT}}
                    ";

                $prompt = str_replace(
                    [
                        '{{RESUME_TEXT}}',
                    ],
                    [
                        $resumeText ?? 'Resume not available',
                    ],
                    $promptTemplate
                );
                
                // $aiResponse = $this->getAIFromHuggingFace($prompt);

                // return $aiResponse;
                

                // ApplicantModel::where('sno', $applicant->sno)->update([
                //     'ai_response' => $aiResponse
                // ]);

            
            $payload = [
                'applicant_id'=>$applicant->sno,
                'stage'=>'New Candidate',
                'job_request_id'=>0,
                'interview_stage_id'=> 0,
                'interview_session_id'=> 0,
                'staff_id'=> 0,
                'created_by'=>$userId,
                'updated_by'=>$userId,
                
            ];
            $saveLog = $this->applicantLogCreate($payload);

            
            DB::commit();

            return response()->json([
                'status'         => 200,
                'message'        => 'candidate Add successfully!',
            ]);
        }catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status'  => false,
                'message' => 'Failed to Add Candidate',
                'error'   => $e->getMessage()
            ], 500);
        }
        
        return response()->json([
            'status'         => 200,
            'message'        => 'Job application submitted successfully!',
            'application_id' => base64_encode($applicant->sno),
        ]);
    }

    private function extractResumeText(string $filePath): string
    {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $text = '';

        try {
            switch ($extension) {
                case 'pdf':
                    $parser = new \Smalot\PdfParser\Parser();
                    $pdf = $parser->parseFile($filePath);
                    $text = (string) $pdf->getText();

                    if (mb_strlen(trim($text)) < 50 && method_exists($this, 'extractPdfWithOCR')) {
                        $text = (string) $this->extractPdfWithOCR($filePath);
                    }
                    break;

                case 'doc':
                case 'docx':
                    $text = $this->extractPhpWordResumeText($filePath);
                    break;

                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'webp':
                case 'bmp':
                case 'gif':
                case 'tif':
                case 'tiff':
                    if (method_exists($this, 'extractTextWithOCR')) {
                        $text = (string) $this->extractTextWithOCR($filePath);
                    }
                    break;
            }
        } catch (\Throwable $e) {
            \Log::error('Resume extraction failed', [
                'file' => $filePath,
                'extension' => $extension,
                'error' => $e->getMessage(),
            ]);
            $text = '';
        }

        return $this->normalizeResumeExtractedText($text);
    }

    private function extractPhpWordResumeText(string $filePath): string
    {
        $word = \PhpOffice\PhpWord\IOFactory::load($filePath);
        $parts = [];

        foreach ($word->getSections() as $section) {
            foreach ($section->getElements() as $element) {
                $value = $this->extractPhpWordElementText($element);
                if ($value !== '') {
                    $parts[] = $value;
                }
            }
        }

        return implode("\n", $parts);
    }

    private function extractPhpWordElementText($element): string
    {
        if ($element === null) {
            return '';
        }

        if (is_string($element) || is_numeric($element)) {
            return trim((string) $element);
        }

        $parts = [];

        if (method_exists($element, 'getText')) {
            try {
                $value = $element->getText();

                if (is_string($value) || is_numeric($value)) {
                    $value = trim((string) $value);
                    if ($value !== '') {
                        $parts[] = $value;
                    }
                } elseif (is_object($value) && $value !== $element) {
                    $nested = $this->extractPhpWordElementText($value);
                    if ($nested !== '') {
                        $parts[] = $nested;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord getText extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getElements')) {
            try {
                foreach ($element->getElements() as $child) {
                    $childText = $this->extractPhpWordElementText($child);
                    if ($childText !== '') {
                        $parts[] = $childText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord child extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getRows')) {
            try {
                foreach ($element->getRows() as $row) {
                    $rowText = $this->extractPhpWordElementText($row);
                    if ($rowText !== '') {
                        $parts[] = $rowText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord row extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getCells')) {
            try {
                foreach ($element->getCells() as $cell) {
                    $cellText = $this->extractPhpWordElementText($cell);
                    if ($cellText !== '') {
                        $parts[] = $cellText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord cell extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return trim(implode(' ', $parts));
    }

    private function normalizeResumeExtractedText(?string $text): string
    {
        $text = (string) $text;
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text) ?? $text;
        $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;

        return trim($text);
    }

    public function extractResumeTextFromDrive(string $fileId): string
    {
        
        try {
            $filePath = $this->googleDriveService->downloadFile($fileId);

            $mime = mime_content_type($filePath);

            $extension = match ($mime) {
                'application/pdf' => 'pdf',
                'application/msword' => 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                default => throw new Exception("Unsupported MIME type: {$mime}")
            };

            $finalPath = $filePath . '.' . $extension;
            rename($filePath, $finalPath);

            $text = $this->extractResumeText($finalPath);

            unlink($finalPath);

            return $text;

        } catch (Exception $e) {
            Log::error('Resume extraction failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            return '';
        }
    }

    private function extractPdfWithOCR($path)
    {
        $text = '';

        $images = $this->pdfToImages($path);

        foreach ($images as $img) {
            $text .= ' ' . $this->extractTextWithOCR($img);
            unlink($img);
        }

        return $text;
    }

    private function extractTextWithOCR($filePath)
    {
        try {
            return (new TesseractOCR($filePath))
                ->lang('eng')
                ->psm(6) // 🔥 Better layout detection
                ->run();
        } catch (\Exception $e) {
            \Log::error('OCR Error: ' . $e->getMessage());
            return '';
        }
    }

    private function pdfToImages($path)
    {
        $images = [];
        $outputDir = storage_path('app/ocr/');

        if (!file_exists($outputDir)) {
            mkdir($outputDir, 0777, true);
        }

        $output = $outputDir . uniqid();

        // Convert PDF to PNG images
        shell_exec("pdftoppm -png " . escapeshellarg($path) . " $output");

        foreach (glob($output . "*.png") as $img) {
            $images[] = $img;
        }

        return $images;
    }


    public function AddNewCandidateNew(
        Request $request,
        ResumeTextExtractionService $resumeTextExtractionService,
        CandidateNameExtractionService $candidateNameExtractionService,
        CandidateMobileService $candidateMobileService,
        CandidateEmailService $candidateEmailService,
        CandidateJobRoleMatchingService $candidateJobRoleMatchingService,
        CandidateQualificationMajorService $candidateQualificationMajorService,
        CandidateExperienceService $candidateExperienceService
    )
    {
        $validated = $request->validate([
            'candidate_name' => ['nullable', 'string', 'max:255'],
            'candidate_mobile' => ['nullable', 'string', 'max:20'],
            'candidate_email' => ['nullable', 'email', 'max:255'],
            'candidate_gender' => ['nullable', 'integer', 'between:1,3'],
            'candidate_marital_status' => ['nullable', 'integer', 'between:1,2'],
            'candidate_qualification' => ['nullable'],
            'candidate_major' => ['nullable'],
            'candidate_other_qualify' => ['nullable', 'string', 'max:250'],
            'candidate_exper_type' => ['nullable', 'integer', 'between:1,2'],
            'candidate_exper_count' => ['nullable', 'numeric', 'min:0', 'max:60'],
            'upload_resume' => ['nullable', 'file', 'max:10240', 'mimes:pdf,doc,docx,docm,odt,rtf,txt,text,md,markdown,html,htm,ppt,pptx,xls,xlsx,jpg,jpeg,png,webp,bmp,gif,tif,tiff'],
            'resume_extraction_token' => ['nullable', 'string', 'size:48'],
            'resume_check' => ['nullable', 'boolean'],
            'recruitment_role_ids_present' => ['sometimes', 'boolean'],
            'recruitment_role_ids' => ['sometimes', 'nullable', 'array', 'max:100'],
            'recruitment_role_ids.*' => ['integer', 'distinct', 'exists:egc_recruitment_roles,sno,status,0'],
            'apply_applicant_id' => ['nullable', 'integer', 'min:1'],
            'apply_job_request_id' => ['nullable', 'integer', 'min:0'],
            'source_name' => ['nullable'],
            'description' => ['nullable', 'string', 'max:5000'],
        ]);

        DB::beginTransaction();
        $movedPath = null;
        $lockName = 'egc:hr:applicant-seq:' . date('y');
        $lockAcquired = false;

        try {
            $user = auth()->user();
            $userId = (int) ($user->user_id ?? $user->id ?? 0);

            $applyApplicantId = (int) ($validated['apply_applicant_id'] ?? 0);
            $existingApplicant = $applyApplicantId > 0
                ? ApplicantModel::query()->find($applyApplicantId)
                : null;

            $file = $request->file('upload_resume');
            $parsed = [];
            $resumeText = '';
            $resumeSha = null;
            $resumeFile = null;
            $driveData = [];

            if ($file) {
                $fileSha = hash_file('sha256', $file->getRealPath());
                $token = trim((string) ($validated['resume_extraction_token'] ?? ''));
                $cached = $token !== '' ? Cache::get('hr_recruitment_resume_parse:' . $token) : null;

                $currentSessionHash = hash('sha256', (string) $request->session()->getId());
                if (
                    is_array($cached)
                    && hash_equals((string) ($cached['sha256'] ?? ''), $fileSha)
                    && hash_equals((string) ($cached['session_hash'] ?? ''), $currentSessionHash)
                ) {
                    $parsed = is_array($cached['data'] ?? null) ? $cached['data'] : [];
                    $resumeText = trim((string) ($cached['resume_text'] ?? ''));
                    $parsed['extraction_meta'] = [
                        'parser_version' => (string) ($parsed['candidate_role_match_parser_version'] ?? CandidateJobRoleMatchingService::VERSION),
                        'primary_model' => $parsed['candidate_name_model'] ?? null,
                        'ai_verified' => (bool) ($parsed['candidate_name_ai_attempted'] ?? false),
                    ];
                    $parsed['manual_review_fields'] = array_values(array_filter([
                        empty($parsed['candidate_name']) ? 'candidate_name' : null,
                        empty($parsed['candidate_mobile']) ? 'candidate_mobile' : null,
                        empty($parsed['candidate_email']) ? 'candidate_email' : null,
                    ]));
                    $parsed['confidence'] = null;
                    $resumeSha = $fileSha;
                } else {
                    // The extraction token is session-bound and file-hash-bound. If it
                    // has expired, rebuild the extraction with the same local services.
                    $textResult = $resumeTextExtractionService->extract($file);
                    $resumeText = trim((string) ($textResult['text'] ?? ''));
                    $nameResult = $candidateNameExtractionService->extract($resumeText);
                    $mobileResult = $candidateMobileService->extractFromResume($resumeText);
                    $emailResult = $candidateEmailService->extractFromResume($resumeText);
                    $roleResult = $candidateJobRoleMatchingService->matchResume($resumeText, 8);
                    try { $qualificationResult = $candidateQualificationMajorService->suggest($resumeText); }
                    catch (Throwable $e) { Log::warning('Qualification suggestion unavailable during candidate save.', ['exception' => get_class($e)]); $qualificationResult = []; }
                    try { $experienceResult = $candidateExperienceService->suggest($resumeText); }
                    catch (Throwable $e) { Log::warning('Experience suggestion unavailable during candidate save.', ['exception' => get_class($e)]); $experienceResult = []; }

                    $parsed = [
                        'candidate_name' => $nameResult['candidate_name'] ?? null,
                        'candidate_mobile' => $mobileResult['candidate_mobile'] ?? null,
                        'candidate_email' => $emailResult['candidate_email'] ?? null,
                        'candidate_exper_type' => $experienceResult['candidate_experience_type'] ?? 1,
                        'candidate_exper_count' => $experienceResult['candidate_exper_count'] ?? 0,
                        'candidate_qualification' => $qualificationResult['candidate_qualification'] ?? null,
                        'candidate_major' => $qualificationResult['candidate_major'] ?? null,
                        'candidate_other_qualify' => $qualificationResult['candidate_other_qualify'] ?? null,
                        'candidate_role_matches' => $roleResult['matches'] ?? [],
                        'suggested_job_role_ids' => $roleResult['role_ids'] ?? [],
                        'candidate_role_match_status' => $roleResult['status'] ?? 'unavailable',
                        'candidate_role_match_count' => (int) ($roleResult['match_count'] ?? 0),
                        'candidate_role_match_parser_version' => CandidateJobRoleMatchingService::VERSION,
                        'candidate_name_model' => $nameResult['model'] ?? null,
                        'candidate_name_ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                        'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                        'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                        'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                        'candidate_experience_confidence' => $experienceResult['candidate_experience_confidence'] ?? 'low',
                        'extraction_meta' => [
                            'parser_version' => CandidateJobRoleMatchingService::VERSION,
                            'primary_model' => $nameResult['model'] ?? null,
                            'ai_verified' => (bool) ($nameResult['ai_attempted'] ?? false),
                        ],
                    ];
                    $parsed['manual_review_fields'] = array_values(array_filter([
                        empty($parsed['candidate_name']) ? 'candidate_name' : null,
                        empty($parsed['candidate_mobile']) ? 'candidate_mobile' : null,
                        empty($parsed['candidate_email']) ? 'candidate_email' : null,
                    ]));
                    $parsed['confidence'] = null;
                    $parsed['resume_text'] = $resumeText;
                    $parsed['text_extraction'] = $textResult;
                    $resumeSha = $fileSha;
                }

                if ($resumeText === '') {
                    throw new \RuntimeException('Resume extraction did not produce readable text. Please review the uploaded file.');
                }

                // The full CV text is already stored in egc_applicant.resume_text.
                // Do not duplicate it inside extraction JSON or return it through the
                // candidate profile API. Keep parser metadata and field-level evidence.
                if (isset($parsed['text_extraction']['engine'])) {
                    $parsed['extraction_meta']['text_engine'] = $parsed['text_extraction']['engine'];
                }
                unset($parsed['resume_text'], $parsed['text_extraction']);
            } elseif ($existingApplicant) {
                $resumeText = trim((string) ($existingApplicant->resume_text ?? ''));
                $resumeSha = trim((string) ($existingApplicant->recruitment_resume_sha256 ?? '')) ?: ($resumeText !== '' ? hash('sha256', $resumeText) : null);
            } else {
                throw new \RuntimeException('Please upload a resume before adding a candidate.');
            }

            // User-entered values are authoritative; AI fills only blank modal fields.
            $fullName = trim((string) ($validated['candidate_name'] ?? '')) ?: trim((string) ($parsed['candidate_name'] ?? ''));
            $mobile = trim((string) ($validated['candidate_mobile'] ?? '')) ?: trim((string) ($parsed['candidate_mobile'] ?? ''));
            $email = trim((string) ($validated['candidate_email'] ?? '')) ?: trim((string) ($parsed['candidate_email'] ?? ''));
            $gender = ($validated['candidate_gender'] ?? null) !== null && ($validated['candidate_gender'] ?? '') !== ''
                ? (int) $validated['candidate_gender'] : ($parsed['candidate_gender'] ?? null);
            $maritalStatus = ($validated['candidate_marital_status'] ?? null) !== null && ($validated['candidate_marital_status'] ?? '') !== ''
                ? (int) $validated['candidate_marital_status'] : ($parsed['candidate_marital_status'] ?? null);
            $qualification = ($validated['candidate_qualification'] ?? null) !== null && ($validated['candidate_qualification'] ?? '') !== ''
                ? $validated['candidate_qualification'] : ($parsed['candidate_qualification'] ?? null);
            $major = ($validated['candidate_major'] ?? null) !== null && ($validated['candidate_major'] ?? '') !== ''
                ? $validated['candidate_major'] : ($parsed['candidate_major'] ?? null);
            $otherQualification = trim((string) ($validated['candidate_other_qualify'] ?? '')) ?: trim((string) ($parsed['candidate_other_major'] ?? ''));
            $experienceType = ($validated['candidate_exper_type'] ?? null) !== null && ($validated['candidate_exper_type'] ?? '') !== ''
                ? (int) $validated['candidate_exper_type'] : (int) ($parsed['candidate_exper_type'] ?? 1);
            $experienceCount = ($validated['candidate_exper_count'] ?? null) !== null && ($validated['candidate_exper_count'] ?? '') !== ''
                ? (float) $validated['candidate_exper_count'] : (float) ($parsed['candidate_exper_count'] ?? 0);

            // Enforce source-derived facts before persistence. These are deliberately
            // stricter than the browser validation because browser values are untrusted.
            if (!preg_match('/^[\p{L}][\p{L} .\'\-]{1,254}$/u', $fullName)) {
                throw new \RuntimeException('Candidate name could not be verified from the supplied data.');
            }
            $mobile = preg_replace('/\D+/', '', $mobile) ?? '';
            if (str_starts_with($mobile, '91') && strlen($mobile) === 12) $mobile = substr($mobile, 2);
            if (!preg_match('/^[6-9]\d{9}$/', $mobile)) {
                throw new \RuntimeException('A valid Indian mobile number is required.');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new \RuntimeException('A valid candidate email address is required.');
            }
            if ($candidateMobileService->existsForApplicant($mobile, $existingApplicant ? (int) $existingApplicant->sno : null)) {
                throw new \RuntimeException('This mobile number already exists for another candidate.');
            }
            if (!in_array($experienceType, [1,2], true)) $experienceType = $experienceCount > 0 ? 2 : 1;
            $experienceCount = max(0, min(60, round($experienceCount, 1)));
            if ($experienceType === 1) $experienceCount = 0;
            if ($experienceType === 2 && $experienceCount <= 0 && !empty($parsed['manual_review_fields'])) {
                // Do not convert ambiguous experience into a fake numeric value.
                $experienceCount = 0;
            }

            if ($qualification === 'Others' && $otherQualification === '') {
                $otherQualification = (string) ($parsed['degree_full'] ?? '');
            }
            if (($major === null || $major === '') && $otherQualification !== '') $major = 'Others';

            // Preserve recruiter-selected roles as explicit assignments. ATS-ranked
            // suggestions remain separately stored in the detailed analysis report.
            $selectedRecruitmentRoleIds = collect($validated['recruitment_role_ids'] ?? [])
                ->map(static fn ($roleId) => (int) $roleId)
                ->filter(static fn ($roleId) => $roleId > 0)
                ->unique()
                ->values()
                ->all();

            if ($selectedRecruitmentRoleIds) {
                $activeRoleIds = DB::table('egc_recruitment_roles')
                    ->where('status', 0)
                    ->whereIn('sno', $selectedRecruitmentRoleIds)
                    ->pluck('sno')->map(static fn ($id) => (int) $id)->all();
                sort($activeRoleIds);
                $requestedRoleIds = $selectedRecruitmentRoleIds;
                sort($requestedRoleIds);
                if ($activeRoleIds !== $requestedRoleIds) {
                    throw new \RuntimeException('One or more selected recruitment roles are no longer active. Refresh the role list and try again.');
                }
            }

            // Generate the human-readable applicant ID under a DB-backed advisory lock.
            $lockResult = DB::selectOne('SELECT GET_LOCK(?, 15) AS locked', [$lockName]);
            if ((int) ($lockResult->locked ?? 0) !== 1) {
                throw new \RuntimeException('Another candidate is being registered. Please retry the candidate save.');
            }
            $lockAcquired = true;

            $lastApplicant = ApplicantModel::query()->orderByDesc('sno')->lockForUpdate()->first();
            $next = 1;
            if ($lastApplicant && preg_match('/EGCJA-(\d+)-\d{2}/', (string) $lastApplicant->applicant_id, $m)) $next = (int) $m[1] + 1;
            $applicantId = 'EGCJA-' . str_pad((string) $next, 4, '0', STR_PAD_LEFT) . '-' . date('y');

            if ($file) {
                $folderPath = public_path('job_applications/resume_files/');
                if (!File::exists($folderPath)) File::makeDirectory($folderPath, 0775, true);
                $extension = strtolower((string) $file->getClientOriginalExtension());
                $extension = preg_replace('/[^a-z0-9]+/i', '', $extension) ?: 'bin';
                $resumeFile = $applicantId . '.' . $extension;
                $file->move($folderPath, $resumeFile);
                $movedPath = $folderPath . $resumeFile;

                try {
                    $driveData = $this->UploadFileInDrive($resumeFile) ?: [];
                } catch (Throwable $driveError) {
                    // Local persistence remains authoritative; Drive failure is audited/logged.
                    \Log::warning('Resume Google Drive upload failed during candidate creation.', [
                        'applicant_id' => $applicantId,
                        'message' => $driveError->getMessage(),
                    ]);
                    $driveData = [];
                }
            } else {
                $resumeFile = $existingApplicant?->attachment;
                $driveData = $existingApplicant?->drive_data ? json_decode($existingApplicant->drive_data, true) : [];
            }

            $candidate = InterviewCandidateModel::updateOrCreate(
                ['mobile' => $mobile],
                ['full_name' => $fullName, 'email' => $email]
            );

            $applicant = ApplicantModel::create([
                'applicant_id' => $applicantId,
                'candidate_id' => $candidate->sno,
                'applicant_name' => $fullName,
                'job_request_id' => 0,
                'job_role_id' => $selectedRecruitmentRoleIds
                    ? json_encode($selectedRecruitmentRoleIds, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    : null,
                'mobile' => $mobile,
                'email' => strtolower($email),
                'attachment' => $resumeFile,
                'ipaddress' => $request->ip(),
                'resume_text' => $resumeText,
                'recruitment_resume_sha256' => $resumeSha,
                'gender' => $gender,
                'marital_status_id' => $maritalStatus,
                'qualification_id' => is_numeric($qualification) ? (int) $qualification : null,
                'major' => is_numeric($major) ? (int) $major : null,
                'other_qualification' => $otherQualification ?: null,
                'experience_id' => $experienceType,
                'experience_count' => $experienceCount,
                'source_id' => $validated['source_name'] ?? null,
                'drive_data' => $driveData ? json_encode($driveData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
                'created_by' => $userId,
                'updated_by' => $userId,
                'description' => $validated['description'] ?? null,
            ]);

            // ApplicantModel's production fillable list predates this checksum field.
            // Set it explicitly so the existing Wasabi resolver can verify the same
            // SHA-256 value for the new AI-assisted intake flow.
            if ($resumeSha) {
                $applicant->recruitment_resume_sha256 = $resumeSha;
                $applicant->save();
            }

            $extractionSnapshot = ApplicantResumeExtractionModel::updateOrCreate(
                ['applicant_sno' => $applicant->sno, 'resume_sha256' => $resumeSha ?: hash('sha256', $resumeText)],
                [
                    'source_filename' => $file?->getClientOriginalName() ?: $resumeFile,
                    'parser_version' => (string) ($parsed['extraction_meta']['parser_version'] ?? config('recruitment_ats.resume_parser_version', 'resume_parser.v5')),
                    'ai_primary_model' => $parsed['extraction_meta']['primary_model'] ?? null,
                    'ai_verifier_model' => $parsed['extraction_meta']['verifier_model'] ?? null,
                    'ai_verified' => (bool) ($parsed['extraction_meta']['ai_verified'] ?? false),
                    'review_required' => !empty($parsed['manual_review_fields']),
                    'confidence' => (int) ($parsed['confidence'] ?? 0),
                    'resume_chars' => mb_strlen($resumeText),
                    'extracted_json' => json_encode($parsed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'evidence_json' => json_encode($parsed['field_evidence'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'processed_at' => now(),
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]
            );

            // Field-level provenance is immutable-at-the-analysis-level audit data.
            // It makes every populated candidate field traceable to the resume text,
            // extraction method and confidence used at the time of ingestion.
            if (\Illuminate\Support\Facades\Schema::hasTable('egc_applicant_resume_extraction_fields')) {
                DB::table('egc_applicant_resume_extraction_fields')
                    ->where('extraction_sno', $extractionSnapshot->sno)
                    ->delete();

                $provenance = is_array($parsed['field_provenance'] ?? null) ? $parsed['field_provenance'] : [];
                $fieldRows = [];
                foreach ($provenance as $field => $meta) {
                    if ($field === '_meta' || !is_array($meta)) continue;
                    $value = trim((string) ($meta['value'] ?? ''));
                    if ($value === '' && empty($meta['evidence'])) continue;

                    $fieldRows[] = [
                        'extraction_sno' => $extractionSnapshot->sno,
                        'applicant_sno' => $applicant->sno,
                        'field_name' => (string) $field,
                        'value_text' => mb_substr($value, 0, 2000),
                        'normalized_value' => mb_substr(mb_strtolower($value, 'UTF-8'), 0, 2000),
                        'source_method' => mb_substr((string) ($meta['method'] ?? 'source_evidence'), 0, 100),
                        'confidence' => max(0, min(100, (float) ($meta['confidence'] ?? 0))),
                        'verification_status' => !empty($meta['verified']) ? 'verified' : 'review',
                        'evidence_text' => mb_substr((string) ($meta['evidence'] ?? ''), 0, 3000),
                        'model_name' => mb_substr((string) ($parsed['extraction_meta']['verifier_model'] ?? $parsed['extraction_meta']['primary_model'] ?? ''), 0, 255),
                        'parser_version' => mb_substr((string) ($parsed['extraction_meta']['parser_version'] ?? 'resume_parser.v5'), 0, 80),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }
                if ($fieldRows) DB::table('egc_applicant_resume_extraction_fields')->insert($fieldRows);
            }

            $roleMatchResult = [
                'status' => (string) ($parsed['candidate_role_match_status'] ?? 'not_run'),
                'matches' => is_array($parsed['candidate_role_matches'] ?? null) ? $parsed['candidate_role_matches'] : [],
                'match_count' => (int) ($parsed['candidate_role_match_count'] ?? 0),
                'catalog_role_count' => (int) ($parsed['candidate_role_catalog_count'] ?? 0),
            ];
            if (!$roleMatchResult['matches'] && $resumeText !== '') {
                $roleMatchResult = $candidateJobRoleMatchingService->matchResume($resumeText, 8);
            }
            $atsAnalysisSaved = $this->persistCandidateAtsAnalysis(
                $applicant,
                $resumeText,
                $resumeSha,
                $roleMatchResult,
                $parsed,
                $file?->getClientOriginalName() ?: $resumeFile,
                $userId
            );

            $this->applicantLogCreate([
                'applicant_id' => $applicant->sno,
                'stage' => 'New Candidate',
                'job_request_id' => 0,
                'interview_stage_id' => 0,
                'interview_session_id' => 0,
                'staff_id' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            DB::commit();

            // Wasabi is a post-commit secondary write: an outage or incomplete cloud
            // configuration must not roll back the existing Drive/local candidate flow.
            $resumeStorageStatus = 'legacy_fallback';
            $resumeDriveVerified = is_array($driveData) && !empty($driveData['file_id']);
            $resumeLocalRemoved = false;
            if ($file && $movedPath && is_file($movedPath)) {
                try {
                    $wasabi = app(WasabiResumeStorageService::class);
                    if ($wasabi->isConfigured()) {
                        // storePath() verifies the uploaded object's length/checksum and
                        // persists the private cloud pointer before this code can unlink.
                        $wasabi->storePath(
                            (int) $applicant->sno,
                            $movedPath,
                            (string) $file->getClientOriginalName(),
                            'upload',
                            'local:' . $resumeFile,
                            $userId > 0 ? $userId : null,
                            false
                        );
                        $resumeStorageStatus = 'wasabi_verified';
                    } else {
                        $resumeStorageStatus = 'wasabi_not_configured';
                    }
                } catch (Throwable $storageError) {
                    $resumeStorageStatus = 'wasabi_failed';
                    \Log::warning('Wasabi resume write failed after candidate creation; existing local/Drive source was preserved.', [
                        'applicant_sno' => (int) $applicant->sno,
                        'message' => $storageError->getMessage(),
                    ]);
                }
            }

            // Never remove the local fallback unless BOTH cloud destinations are known
            // to contain the uploaded file. Validate the path is still inside the
            // dedicated resume directory before unlinking it.
            if ($resumeStorageStatus === 'wasabi_verified' && $resumeDriveVerified && $movedPath && is_file($movedPath)) {
                $resumeDirectory = realpath(public_path('job_applications/resume_files'));
                $localResumePath = realpath($movedPath);
                $isInsideResumeDirectory = $resumeDirectory && $localResumePath
                    && strpos($localResumePath, rtrim($resumeDirectory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) === 0;

                if ($isInsideResumeDirectory && @unlink($localResumePath) && !is_file($localResumePath)) {
                    $resumeLocalRemoved = true;
                } else {
                    \Log::warning('Cloud resume copies were verified but the local fallback could not be removed safely.', [
                        'applicant_sno' => (int) $applicant->sno,
                        'resume_file' => $resumeFile,
                    ]);
                }
            }

            return response()->json([
                'status' => 200,
                'message' => 'Candidate added successfully.',
                'data' => [
                    'applicant_sno' => (int) $applicant->sno,
                    'applicant_id' => $applicant->applicant_id,
                    'resume_review_required' => !empty($parsed['manual_review_fields']),
                    'resume_storage' => $resumeStorageStatus,
                    'resume_drive_verified' => $resumeDriveVerified,
                    'resume_local_removed' => $resumeLocalRemoved,
                    'resume_storage_warning' => ($resumeStorageStatus !== 'wasabi_verified' || !$resumeDriveVerified)
                        ? 'The local resume was retained as a safe fallback because both Google Drive and Wasabi copies were not verified.'
                        : (!$resumeLocalRemoved ? 'Both cloud copies were verified, but the local fallback could not be safely removed.' : null),
                    'ats_analysis_saved' => (bool) ($atsAnalysisSaved['saved'] ?? false),
                    'ats_analysis_warning' => $atsAnalysisSaved['warning'] ?? null,
                    'ats_analysis_sno' => $atsAnalysisSaved['analysis_sno'] ?? null,
                ],
            ]);
        } catch (Throwable $e) {
            DB::rollBack();
            if ($movedPath && is_file($movedPath)) @unlink($movedPath);
            return response()->json([
                'status' => false,
                'message' => $e->getMessage() ?: 'Failed to add candidate.',
            ], 422);
        } finally {
            if ($lockAcquired) {
                try { DB::selectOne('SELECT RELEASE_LOCK(?) AS released', [$lockName]); } catch (Throwable) {}
            }
        }
    }

    /**
     * Persist a versioned, explainable ATS report and its per-role evidence rows.
     * The report is intentionally separate from egc_applicant.ai_response so legacy
     * interview AI data is never overwritten by the new resume intake workflow.
     */
    private function persistCandidateAtsAnalysis(
        ApplicantModel $applicant,
        string $resumeText,
        ?string $resumeSha,
        array $matchResult,
        array $extractionData,
        ?string $sourceLabel,
        int $actorId
    ): array {
        if (!Schema::hasTable('egc_applicant_ats_role_analyses') || !Schema::hasTable('egc_applicant_ats_role_matches')) {
            return [
                'saved' => false,
                'warning' => 'ATS analysis tables are not installed. Apply the recruitment ATS database schema before expecting saved role-match reports.',
            ];
        }

        $matches = is_array($matchResult['matches'] ?? null) ? array_values($matchResult['matches']) : [];
        $scores = array_values(array_filter(array_map(
            static fn ($row) => isset($row['match_score']) && is_numeric($row['match_score']) ? (float) $row['match_score'] : null,
            $matches
        ), static fn ($score) => $score !== null));
        $bestScore = $scores ? max($scores) : null;
        $topScores = array_slice($scores, 0, 3);
        $overallScore = $topScores ? round(array_sum($topScores) / count($topScores), 2) : null;
        $hash = $resumeSha ?: hash('sha256', $resumeText);
        $reviewRequired = !empty($extractionData['manual_review_fields'])
            || empty($applicant->applicant_name)
            || empty($applicant->mobile)
            || empty($applicant->email)
            || !$matches;

        $roleCatalog = [];
        try {
            $roleCatalog = DB::table('egc_recruitment_roles')
                ->where('status', 0)
                ->where('match_enabled', 1)
                ->orderBy('sno')
                ->get(['sno', 'role_code', 'role_name', 'role_family'])
                ->map(static fn ($row) => [
                    'sno' => (int) $row->sno,
                    'role_code' => (string) $row->role_code,
                    'role_name' => (string) $row->role_name,
                    'role_family' => (string) ($row->role_family ?? ''),
                ])->all();
        } catch (Throwable $e) {
            Log::warning('Could not snapshot the ATS role catalogue for candidate analysis.', [
                'applicant_sno' => (int) $applicant->sno,
                'exception' => get_class($e),
            ]);
        }

        $analysisJson = [
            'report_version' => 'candidate_ats_report.v1',
            'analysis_type' => 'explainable_ats_role_match',
            'engine' => 'local_rule_based_role_matcher',
            'engine_version' => CandidateJobRoleMatchingService::VERSION,
            'decision_policy' => 'Evidence-backed role-fit ranking. This is a recruiter aid, not an automated hiring decision.',
            'status' => (string) ($matchResult['status'] ?? ($matches ? 'matched' : 'no_reliable_match')),
            'resume' => [
                'sha256' => $hash,
                'character_count' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                'source_filename' => $sourceLabel,
            ],
            'candidate_snapshot' => [
                'name' => (string) ($applicant->applicant_name ?? ''),
                'mobile' => (string) ($applicant->mobile ?? ''),
                'email' => (string) ($applicant->email ?? ''),
                'qualification_id' => $applicant->qualification_id,
                'major_id' => $applicant->major,
                'experience_type' => $applicant->experience_id,
                'experience_years' => $applicant->experience_count,
            ],
            'extraction' => [
                'parser_version' => $extractionData['candidate_role_match_parser_version']
                    ?? $extractionData['extraction_meta']['parser_version']
                    ?? CandidateJobRoleMatchingService::VERSION,
                'name_source' => $extractionData['candidate_name_source'] ?? null,
                'name_ai_model' => $extractionData['candidate_name_model'] ?? null,
                'name_ai_attempted' => (bool) ($extractionData['candidate_name_ai_attempted'] ?? false),
                'mobile_source' => $extractionData['candidate_mobile_source'] ?? null,
                'email_source' => $extractionData['candidate_email_source'] ?? null,
                'review_required' => $reviewRequired,
                'manual_review_fields' => array_values($extractionData['manual_review_fields'] ?? []),
                'confidence' => $extractionData['confidence'] ?? null,
            ],
            'score_summary' => [
                'overall_match_score' => $overallScore,
                'best_role_score' => $bestScore,
                'match_count' => count($matches),
                'catalog_role_count' => (int) ($matchResult['catalog_role_count'] ?? count($roleCatalog)),
            ],
            'selected_recruitment_role_ids' => json_decode((string) ($applicant->job_role_id ?? '[]'), true) ?: [],
            'role_matches' => $matches,
            'role_catalog_snapshot' => $roleCatalog,
            'limitations' => [
                'Role scores are generated by the configured local evidence matcher. They are not an LLM opinion, guarantee of suitability, or hiring recommendation.',
                'Missing resume details should be reviewed by a recruiter before shortlisting.',
            ],
        ];

        try {
            $analysis = DB::transaction(function () use (
                $applicant, $hash, $resumeText, $overallScore, $bestScore, $matches,
                $roleCatalog, $analysisJson, $reviewRequired, $matchResult, $actorId
            ) {
                $analysis = ApplicantAtsRoleAnalysisModel::create([
                    'applicant_sno' => (int) $applicant->sno,
                    'run_sno' => null,
                    'schema_version' => 'candidate_ats_report.v1',
                    'engine' => 'local_rule_based_role_matcher',
                    'model' => null,
                    'source_type' => 'resume_text',
                    'source_label' => 'Resume role matching',
                    'role_catalog_hash' => hash('sha256', json_encode($roleCatalog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
                    'resume_sha256' => $hash,
                    'resume_chars' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                    'overall_match_score' => $overallScore,
                    'best_role_score' => $bestScore,
                    'resume_quality_score' => null,
                    'match_count' => count($matches),
                    'role_catalog_size' => (int) ($matchResult['catalog_role_count'] ?? count($roleCatalog)),
                    'semantic_candidate_count' => 0,
                    'candidate_data_confidence' => isset($analysisJson['extraction']['confidence']) && is_numeric($analysisJson['extraction']['confidence'])
                        ? (float) $analysisJson['extraction']['confidence'] : null,
                    'review_required' => $reviewRequired,
                    'retrieval_model' => null,
                    'scoring_version' => CandidateJobRoleMatchingService::VERSION,
                    'analysis_json' => $analysisJson,
                    'processed_at' => now(),
                    'created_by' => $actorId ?: null,
                    'updated_by' => $actorId ?: null,
                ]);

                foreach ($matches as $match) {
                    $evidence = is_array($match['evidence'] ?? null) ? $match['evidence'] : [];
                    $categories = is_array($match['evidence_categories'] ?? null) ? $match['evidence_categories'] : [];
                    ApplicantAtsRoleMatchModel::create([
                        'analysis_sno' => (int) $analysis->sno,
                        'applicant_sno' => (int) $applicant->sno,
                        'role_sno' => (int) ($match['role_id'] ?? 0),
                        'role_code' => mb_substr((string) ($match['role_code'] ?? ''), 0, 100),
                        'role_name' => mb_substr((string) ($match['role_name'] ?? ''), 0, 255),
                        'role_family' => mb_substr((string) ($match['role_family'] ?? ''), 0, 150),
                        'seniority_level' => isset($match['seniority_level']) ? (int) $match['seniority_level'] : null,
                        'match_score' => isset($match['match_score']) ? (float) $match['match_score'] : null,
                        'semantic_fit_score' => null,
                        'decision' => mb_substr((string) ($match['match_band'] ?? 'review'), 0, 60),
                        'scoring_version' => CandidateJobRoleMatchingService::VERSION,
                        'reason' => mb_substr(implode('; ', array_slice(array_map('strval', $evidence), 0, 5)), 0, 1000),
                        'evidence_json' => ['items' => $evidence, 'categories' => $categories],
                        'gaps_json' => [],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                return $analysis;
            });

            return ['saved' => true, 'analysis_sno' => (int) $analysis->sno, 'warning' => null];
        } catch (Throwable $e) {
            Log::error('Candidate ATS report persistence failed.', [
                'applicant_sno' => (int) $applicant->sno,
                'exception' => get_class($e),
                'message' => $e->getMessage(),
            ]);
            return [
                'saved' => false,
                'warning' => 'Candidate was saved, but the ATS report could not be persisted. Verify the ATS SQL tables and column definitions in this environment.',
            ];
        }
    }

    /** Return a candidate profile together with the latest persisted ATS analysis. */
    public function candidateDetails(int $sno)
    {
        $applicant = ApplicantModel::query()
            ->leftJoin('egc_major', 'egc_applicant.major', '=', 'egc_major.sno')
            ->leftJoin('egc_qualification_level', 'egc_applicant.qualification_id', '=', 'egc_qualification_level.sno')
            ->where('egc_applicant.status', '!=', 2)
            ->where('egc_applicant.sno', $sno)
            ->select(
                'egc_applicant.*',
                'egc_major.major_name',
                'egc_qualification_level.qualification_level_name'
            )
            ->firstOrFail();
        $analysis = null;
        $matches = [];
        $extraction = null;

        if (Schema::hasTable('egc_applicant_ats_role_analyses')) {
            $analysis = ApplicantAtsRoleAnalysisModel::query()
                ->where('applicant_sno', $sno)
                ->orderByDesc('sno')
                ->first();
            if ($analysis && Schema::hasTable('egc_applicant_ats_role_matches')) {
                $matches = ApplicantAtsRoleMatchModel::query()
                    ->where('analysis_sno', $analysis->sno)
                    ->orderByDesc('match_score')
                    ->get()->toArray();
            }
        }

        if (Schema::hasTable('egc_applicant_resume_extractions')) {
            $extraction = ApplicantResumeExtractionModel::query()
                ->where('applicant_sno', $sno)
                ->orderByDesc('sno')
                ->first();
        }

        // Keep previously saved legacy AI quality reports visible in the restored
        // candidate modal. New ATS role-fit reports are stored separately and do
        // not overwrite this historical field.
        $legacyAiResponse = $applicant->ai_response ?? null;
        if (is_string($legacyAiResponse)) {
            $decodedLegacyAi = json_decode($legacyAiResponse, true);
            $legacyAiResponse = is_array($decodedLegacyAi) ? $decodedLegacyAi : null;
        } elseif (!is_array($legacyAiResponse)) {
            $legacyAiResponse = null;
        }

        $selectedRoleIds = json_decode((string) ($applicant->job_role_id ?? '[]'), true);
        if (!is_array($selectedRoleIds)) $selectedRoleIds = [];
        $selectedRoles = $selectedRoleIds
            ? DB::table('egc_recruitment_roles')->whereIn('sno', $selectedRoleIds)->get(['sno', 'role_code', 'role_name', 'role_family'])
            : collect();

        $rawAnswers = [];
        if (!empty($applicant->question_answers)) {
            $decodedAnswers = json_decode((string) $applicant->question_answers, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decodedAnswers)) {
                $rawAnswers = $decodedAnswers;
            }
        }
        $normalizedAnswers = collect($rawAnswers)
            ->filter(static fn ($item) => is_array($item))
            ->map(static function (array $item) {
                $answer = $item['answer'] ?? null;
                if (is_array($answer)) {
                    $answer = array_values(array_filter($answer, static fn ($value) => $value !== null && $value !== ''));
                }
                return [
                    'question_id' => $item['question_id'] ?? null,
                    'question' => $item['question'] ?? '',
                    'type' => $item['type'] ?? '',
                    'answer' => $answer,
                ];
            })
            ->values()
            ->all();
        $applicationAnswers = [
            'has_answers' => count($normalizedAnswers) > 0,
            'answer_count' => count($normalizedAnswers),
            'answers' => $normalizedAnswers,
        ];
        $hasResume = !empty($applicant->attachment) || !empty($applicant->drive_data);

        return response()->json([
            'status' => 200,
            'data' => [
                'candidate' => [
                    'sno' => (int) $applicant->sno,
                    'applicant_id' => $applicant->applicant_id,
                    'name' => $applicant->applicant_name,
                    'mobile' => $applicant->mobile,
                    'email' => $applicant->email,
                    'gender' => $applicant->gender,
                    'marital_status_id' => $applicant->marital_status_id,
                    'qualification_id' => $applicant->qualification_id,
                    'qualification_name' => $applicant->qualification_level_name
                        ?: (($applicant->qualification_id === 'Others' || $applicant->qualification_id === 0) ? $applicant->other_qualification : null),
                    'major_id' => $applicant->major,
                    'major_name' => $applicant->major_name ?: null,
                    'other_qualification' => $applicant->other_qualification,
                    'experience_id' => $applicant->experience_id,
                    'experience_count' => $applicant->experience_count,
                    'description' => $applicant->description,
                    'attachment' => $applicant->attachment,
                    'resume_filename' => $applicant->attachment,
                    'resume_url' => $hasResume ? url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=inline') : null,
                    'resume_download_url' => $hasResume ? url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=attachment') : null,
                    'resume_sha256' => $applicant->recruitment_resume_sha256,
                    'resume_chars' => function_exists('mb_strlen') ? mb_strlen((string) $applicant->resume_text, 'UTF-8') : strlen((string) $applicant->resume_text),
                    'created_at' => $applicant->created_at ?? $applicant->created_on ?? null,
                    'selected_roles' => $selectedRoles,
                ],
                'application_answers' => $applicationAnswers,
                'legacy_ai_response' => $legacyAiResponse,
                'analysis' => $analysis ? [
                    'sno' => (int) $analysis->sno,
                    'engine' => $analysis->engine,
                    'version' => $analysis->scoring_version,
                    'overall_match_score' => $analysis->overall_match_score,
                    'best_role_score' => $analysis->best_role_score,
                    'match_count' => (int) $analysis->match_count,
                    'review_required' => (bool) $analysis->review_required,
                    'processed_at' => optional($analysis->processed_at)->toIso8601String(),
                    'report' => $analysis->analysis_json,
                    'matches' => $matches,
                ] : null,
                'extraction' => $extraction ? [
                    'parser_version' => $extraction->parser_version,
                    'ai_primary_model' => $extraction->ai_primary_model,
                    'ai_verified' => (bool) $extraction->ai_verified,
                    'review_required' => (bool) $extraction->review_required,
                    'confidence' => $extraction->confidence,
                    'resume_chars' => $extraction->resume_chars,
                    'extracted' => $extraction->extracted_json,
                    'evidence' => $extraction->evidence_json,
                ] : null,
            ],
        ]);
    }

    /** Re-run the current local ATS role matcher for one candidate and save its report. */
    public function atsIndividualMatch(
        Request $request,
        int $sno,
        CandidateJobRoleMatchingService $candidateJobRoleMatchingService
    ) {
        abort_unless((int) (auth()->user()->role_id ?? 0) === 1, 403);
        $applicant = ApplicantModel::query()->where('status', '!=', 2)->findOrFail($sno);
        $resumeText = trim((string) $applicant->resume_text);
        if ($resumeText === '') {
            return response()->json(['status' => 422, 'message' => 'No readable resume text is stored for this candidate.'], 422);
        }

        $result = $candidateJobRoleMatchingService->matchResume($resumeText, 8);
        $saved = $this->persistCandidateAtsAnalysis(
            $applicant,
            $resumeText,
            $applicant->recruitment_resume_sha256 ?: hash('sha256', $resumeText),
            $result,
            [],
            $applicant->attachment,
            (int) (auth()->user()->user_id ?? auth()->id() ?? 0)
        );

        return response()->json([
            'status' => 200,
            'message' => $saved['saved'] ? 'ATS analysis completed and saved.' : 'ATS analysis completed, but its report could not be saved.',
            'data' => [
                'saved' => (bool) $saved['saved'],
                'warning' => $saved['warning'] ?? null,
                'analysis_sno' => $saved['analysis_sno'] ?? null,
                'result' => $result,
            ],
        ], 200);
    }

    /** Small, sequential batches keep bulk analysis bounded on normal web workers. */
    public function atsBulkStats()
    {
        abort_unless((int) (auth()->user()->role_id ?? 0) === 1, 403);

        $candidateQuery = ApplicantModel::query()
            ->where('status', '!=', 2)
            ->whereNotNull('resume_text')
            ->where('resume_text', '<>', '');
        $total = (clone $candidateQuery)->count();
        $analyzed = 0;
        if (Schema::hasTable('egc_applicant_ats_role_analyses')) {
            $analyzed = ApplicantAtsRoleAnalysisModel::query()
                ->whereIn('applicant_sno', (clone $candidateQuery)->select('sno'))
                ->distinct()->count('applicant_sno');
        }
        $activeRoles = DB::table('egc_recruitment_roles')->where('status', 0)->where('match_enabled', 1)->count();

        return response()->json([
            'status' => 200,
            'data' => [
                'total_candidates' => $total,
                'analyzed_count' => $analyzed,
                'pending_count' => max(0, $total - $analyzed),
                'active_role_count' => $activeRoles,
                'recommended_batch_size' => 5,
                'ats_tables_ready' => Schema::hasTable('egc_applicant_ats_role_analyses') && Schema::hasTable('egc_applicant_ats_role_matches'),
            ],
        ]);
    }

    public function atsBulkProcess(Request $request, CandidateJobRoleMatchingService $candidateJobRoleMatchingService)
    {
        abort_unless((int) (auth()->user()->role_id ?? 0) === 1, 403);
        $validated = $request->validate([
            'cursor' => ['nullable', 'integer', 'min:0'],
            'batch_size' => ['nullable', 'integer', 'min:1', 'max:10'],
            'force_reprocess' => ['nullable', 'boolean'],
        ]);

        if (!Schema::hasTable('egc_applicant_ats_role_analyses') || !Schema::hasTable('egc_applicant_ats_role_matches')) {
            return response()->json(['status' => 422, 'message' => 'ATS analysis tables are not installed. Apply the recruitment ATS SQL before running bulk analysis.'], 422);
        }

        $cursor = (int) ($validated['cursor'] ?? 0);
        $batchSize = (int) ($validated['batch_size'] ?? 5);
        $force = (bool) ($validated['force_reprocess'] ?? false);

        $query = ApplicantModel::query()
            ->where('status', '!=', 2)
            ->whereNotNull('resume_text')
            ->where('resume_text', '<>', '')
            ->where('sno', '>', $cursor)
            ->orderBy('sno');

        if (!$force) {
            $query->whereNotExists(function ($subquery) {
                $subquery->select(DB::raw(1))
                    ->from('egc_applicant_ats_role_analyses as ats_existing')
                    ->whereColumn('ats_existing.applicant_sno', 'egc_applicant.sno');
            });
        }

        $batch = $query->limit($batchSize)->get();
        $processed = 0;
        $matched = 0;
        $unmatched = 0;
        $failed = 0;
        $recent = [];
        $userId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);

        foreach ($batch as $applicant) {
            $cursor = (int) $applicant->sno;
            try {
                $resumeText = trim((string) $applicant->resume_text);
                $result = $candidateJobRoleMatchingService->matchResume($resumeText, 8);
                $saved = $this->persistCandidateAtsAnalysis(
                    $applicant,
                    $resumeText,
                    $applicant->recruitment_resume_sha256 ?: hash('sha256', $resumeText),
                    $result,
                    [],
                    $applicant->attachment,
                    $userId
                );
                if (!$saved['saved']) {
                    $failed++;
                    continue;
                }
                $processed++;
                $count = (int) ($result['match_count'] ?? count($result['matches'] ?? []));
                if ($count > 0) $matched++; else $unmatched++;
                $recent[] = [
                    'sno' => (int) $applicant->sno,
                    'name' => (string) $applicant->applicant_name,
                    'match_count' => $count,
                    'best_score' => collect($result['matches'] ?? [])->max('match_score'),
                    'status' => $count > 0 ? 'matched' : 'no_reliable_match',
                ];
            } catch (Throwable $e) {
                $failed++;
                Log::warning('Bulk ATS candidate processing failed.', [
                    'applicant_sno' => (int) $applicant->sno,
                    'exception' => get_class($e),
                ]);
            }
        }

        $remainingQuery = ApplicantModel::query()
            ->where('status', '!=', 2)
            ->whereNotNull('resume_text')
            ->where('resume_text', '<>', '')
            ->where('sno', '>', $cursor);
        if (!$force) {
            $remainingQuery->whereNotExists(function ($subquery) {
                $subquery->select(DB::raw(1))
                    ->from('egc_applicant_ats_role_analyses as ats_existing')
                    ->whereColumn('ats_existing.applicant_sno', 'egc_applicant.sno');
            });
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'cursor' => $cursor,
                'processed_count' => $processed,
                'matched_count' => $matched,
                'unmatched_count' => $unmatched,
                'failed_count' => $failed,
                'has_more' => $remainingQuery->exists(),
                'recent_items' => $recent,
            ],
        ]);
    }

    /** Active route contract: use the verified intake, ATS and Wasabi-aware save path. */
    public function AddNewCandidate(
        Request $request,
        ResumeTextExtractionService $resumeTextExtractionService,
        CandidateNameExtractionService $candidateNameExtractionService,
        CandidateMobileService $candidateMobileService,
        CandidateEmailService $candidateEmailService,
        CandidateJobRoleMatchingService $candidateJobRoleMatchingService,
        CandidateQualificationMajorService $candidateQualificationMajorService,
        CandidateExperienceService $candidateExperienceService
    ) {
        return $this->AddNewCandidateNew(
            $request,
            $resumeTextExtractionService,
            $candidateNameExtractionService,
            $candidateMobileService,
            $candidateEmailService,
            $candidateJobRoleMatchingService,
            $candidateQualificationMajorService,
            $candidateExperienceService
        );
    }

    public function AddNewCandidateLegacy(Request $request)
    {
        
        $request->validate([
            'candidate_name' => 'required',
            'candidate_mobile' => 'required',
            'candidate_email' => 'required',
            'candidate_gender'   => 'required|integer',
            'candidate_marital_status' => 'nullable|max:51200'
        ]);
        DB::beginTransaction();

        
        try {
            $resumeFile = null;
            $resumeUrl = null;
            $fullName        = $request->candidate_name;
            $mobile_no       = $request->candidate_mobile;
            $email_id        = $request->candidate_email;
            $gender          = $request->candidate_gender;
            $job_request_id  = $request->apply_job_request_id ?? NULL ;
            $apply_applicant_id  = $request->apply_applicant_id;
            $jobRequestdata =  JobRequestModel::where('sno', $job_request_id)->first();

            $candidateData =  ApplicantModel::where('sno', $apply_applicant_id)->first();
            $job_role_id     = NULL;
            $marital_status  = $request->candidate_marital_status;
            $qualification   = $request->candidate_qualification;
            $major           = $request->candidate_major;
            $OtherQualification           = $request->candidate_other_qualify;
            $exper_type      = $request->candidate_exper_type;
            $exper_count     = $request->candidate_exper_count ?? 0;
            $resume_check     = $request->resume_check ?? 0;
            $source          = $request->source_name ?? 0;
            $description          = $request->description ?? NULL;
            $ipAddress = $request->ip();
            $resumeText = null;
            $userId = auth()->user()->user_id;
            $drive_data=[];

            $alreadyApplied = ApplicantModel::where('mobile', $mobile_no)
                // ->whereDate('created_at', date('Y-m-d'))
                ->where('status', '!=', 2)
                ->exists();

            if ($alreadyApplied) {
                return response()->json([
                    'status'  => 409,
                    'message' => 'You have already applied using this mobile number.',
                ], 409);
            }

            
            $candidate = InterviewCandidateModel::updateOrCreate(
            ['mobile'    => $mobile_no],
            [
                'full_name' => $fullName,
                'email'     => $email_id,
            ]);

            $candidate_id = $candidate->sno;
            
            // return $candidate;
            $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
            $year = date('y');

            if (!$lastApplicant) {
                $applicant_id = "EGCJA-0001-{$year}";
            } else {
                preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
                $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
                $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
            }

            

                if($resume_check == 0){
                    
                    if ($request->hasFile('upload_resume')) {
                        $file = $request->file('upload_resume');
                        $extension = $file->getClientOriginalExtension();

                        $folderPath = public_path('job_applications/resume_files/');

                        if (!File::exists($folderPath)) {
                            File::makeDirectory($folderPath, 0777, true);
                        }

                        // Unique filename
                        $resumeFile = $applicant_id . '.' . $extension;

                        $file->move($folderPath, $resumeFile);
                        $filePath = $folderPath . $resumeFile;
                        $resumeText = $this->extractResumeText($filePath);
                        
                        
                        if (file_exists($filePath)) {
                            $drive_data = $this->UploadFileInDrive($resumeFile);
                        }
                    }
                }
            

                function cleanUtf8($value)
                {
                    if (is_array($value)) {
                        return array_map('cleanUtf8', $value);
                    }

                    if (is_string($value)) {
                        return mb_convert_encoding($value, 'UTF-8', 'UTF-8');
                    }

                    return $value;
                }
                $resumeText  = cleanUtf8($resumeText);

                $majorData=DB::table('egc_major')->where('sno',$major)->first();

                
                if($major == 'Others'){
                    $majorName=$OtherQualification;
                }else{
                        $majorName=$majorData->major_name;
                }

                $selectedRecruitmentRoleIds = collect($validated['recruitment_role_ids'] ?? [])
                ->map(static fn ($roleId) => (int) $roleId)
                ->unique()
                ->values()
                ->all();
                
                $applicant=ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'candidate_id'      => $candidate_id,
                'applicant_name'    => $fullName,
                'job_request_id'       => 0,
                'job_role_id' => $selectedRecruitmentRoleIds
                    ? json_encode($selectedRecruitmentRoleIds, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    : null,
                'mobile'            => $mobile_no,
                'email'             => $email_id,
                'attachment'        => $resumeFile,
                'ipaddress'         => $ipAddress ?? null,
                'resume_text'       => $resumeText ?? NULL,
                'gender'            => $gender,
                'marital_status_id' => $marital_status,
                'qualification_id'  => $qualification,
                'major'             => $major,
                // 'other_qualification' => $OtherQualification ?? NULL,
                'experience_id'     => $exper_type,
                'experience_count'  => $exper_count,
                'source_id'         => $source,
                'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
                'created_by'       => $userId,
                'updated_by'       => $userId,
                'description'       => $description,
            ]);
            
        
                $qualificationName = "Not provided"; 
                $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

                

            
            $payload = [
                'applicant_id'=>$applicant->sno,
                'stage'=>'New Candidate',
                'job_request_id'=>0,
                'interview_stage_id'=> 0,
                'interview_session_id'=> 0,
                'staff_id'=> 0,
                'created_by'=>$userId,
                'updated_by'=>$userId,
                
            ];
            $saveLog = $this->applicantLogCreate($payload);

            
            DB::commit();

            return response()->json([
                'status'         => 200,
                'message'        => 'candidate Add successfully!',
            ]);
        }catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status'  => false,
                'message' => 'Failed to Add Candidate',
                'error'   => $e->getMessage()
            ], 500);
        }
        
        return response()->json([
            'status'         => 200,
            'message'        => 'Job application submitted successfully!',
            'application_id' => base64_encode($applicant->sno),
        ]);
    }

    private function applicantLogCreate($payload){

            $applicant=ApplicantLogModel::create([
                'applicant_id'      => $payload['applicant_id'],
                'stage'      => $payload['stage'],
                'job_request_id'    => $payload['job_request_id'],
                'interview_stage_id'       => $payload['interview_stage_id'],
                'interview_session_id'       => $payload['interview_session_id'],
                'staff_id'            => $payload['staff_id'],
                'updated_by'             => $payload['updated_by'],
                'created_by'        => $payload['created_by'],
            ]);
    }

    private function UploadFileInDrive($attachment)
    {
        $uploadedFiles = [];
        $errors = [];

        if (!$attachment) {
            return ['error' => 'No attachment provided'];
        }

        $filePath = public_path('job_applications/resume_files/' . $attachment);

        // Check if the file exists on the server
        if (!file_exists($filePath)) {
            $errors[] = [
                'attachment' => $attachment,
                'error' => 'File not found on server'
            ];
            return ['errors' => $errors];  // Return errors in case file is not found
        }

        try {
            $uploadedFile = new UploadedFile(
                $filePath,
                $attachment,
                mime_content_type($filePath),
                null,
                true
            );

            // Upload the file to Google Drive
            $driveFile = $this->googleDriveService->upload(
                $uploadedFile,
                env('GOOGLE_DRIVE_FOLDER_ID') // Folder ID is taken from .env
            );

            // Check if the file was uploaded successfully
            if ($driveFile) {
                $uploadedFiles = [
                    'file_name' => $driveFile->name,
                    'file_id' => $driveFile->id,
                    'webViewLink' => $driveFile->webViewLink ?? null
                ];
            } else {
                $errors[] = ['error' => 'Google Drive upload failed'];
            }
        } catch (\Exception $e) {
            // Catch any exception during the upload process
            $errors[] = ['error' => 'Error uploading file to Google Drive: ' . $e->getMessage()];
        }

        // If there are errors, return them; otherwise, return the uploaded file details
        if (!empty($errors)) {
            return ['errors' => $errors];
        }

        return $uploadedFiles;
    }

    public function extractCandidateData(
        Request $request,
        ResumeTextExtractionService $resumeTextExtractionService,
        CandidateNameExtractionService $candidateNameExtractionService,
        CandidateMobileService $candidateMobileService,
        CandidateEmailService $candidateEmailService,
        CandidateJobRoleMatchingService $candidateJobRoleMatchingService,
        CandidateQualificationMajorService $candidateQualificationMajorService,
        CandidateExperienceService $candidateExperienceService
    ) {
        $request->validate([
            'upload_resume' => [
                'required',
                'file',
                'max:10240',
                function ($attribute, $file, $fail) {
                    if (!$file instanceof \Illuminate\Http\UploadedFile) {
                        $fail('Please select a valid resume file.');
                        return;
                    }

                    $extension = strtolower($file->getClientOriginalExtension());
                    if (!ResumeTextExtractionService::supportsExtension($extension)) {
                        $fail('Unsupported resume format. Please upload PDF, Word, ODT, RTF, text/HTML, PowerPoint, Excel, or an image file.');
                    }
                },
            ],
        ]);

        $file = $request->file('upload_resume');
        $traceId = (string) Str::uuid();

        try {
            $fileHash = hash_file('sha256', $file->getRealPath());
            if (!is_string($fileHash) || strlen($fileHash) !== 64) {
                throw new \RuntimeException('The uploaded file could not be fingerprinted.');
            }

            $textResult = $resumeTextExtractionService->extract($file);
            $resumeText = trim((string) ($textResult['text'] ?? ''));
            $nameEvidenceEngine = 'resume_text';
            $isPdf = strtolower((string) $file->getClientOriginalExtension()) === 'pdf';
            $ocrFallbackAttempted = false;
            $earlyOcrText = '';
            $ocrText = '';
            // Mobile extraction is local-only so candidate phone PII is not sent to AI.
            $mobileResult = $candidateMobileService->extractFromResume($resumeText);

            // AI-first policy: for readable resume text, call the configured model
            // before local candidate-name parsing. CandidateNameExtractionService
            // validates model output and automatically uses local parsing if AI fails.
            // If a PDF has no readable text at all, OCR is required to create model
            // input; the AI still runs before local parsing of that OCR text.
            $nameInputForAi = $resumeText;
            if ($resumeText === '' && $isPdf) {
                $earlyOcr = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $earlyOcrText = trim((string) ($earlyOcr['text'] ?? ''));
                if ($earlyOcrText !== '') {
                    $nameInputForAi = $earlyOcrText;
                    $nameEvidenceEngine = (string) ($earlyOcr['engine'] ?? 'pdf_ocr_name_fallback');
                }
            }

            $nameResult = $candidateNameExtractionService->extract($nameInputForAi);
            if (!empty($nameResult['candidate_name']) && $earlyOcrText !== ''
                && ($nameResult['source'] ?? '') === 'local_parser') {
                $nameEvidenceEngine = (string) ($earlyOcr['engine'] ?? 'pdf_ocr_name_fallback');
            }

            // After the AI-first pass and local fallback fail, OCR page one and retry
            // local parsing only. Do not invoke Hugging Face a second time for the same
            // upload: that would spend another credit without improving the source text
            // already given to the model.
            if (empty($nameResult['candidate_name']) && $isPdf && !$ocrFallbackAttempted) {
                $ocrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $ocrText = trim((string) ($ocrFallback['text'] ?? ''));
                if ($ocrText !== '') {
                    $ocrNameResult = $candidateNameExtractionService->extractLocallyOnly($ocrText);
                    if (empty($ocrNameResult['candidate_name'])) {
                        $combinedText = trim($ocrText . "\n\n" . $resumeText);
                        $ocrNameResult = $candidateNameExtractionService->extractLocallyOnly($combinedText);
                        if (!empty($ocrNameResult['candidate_name'])) {
                            $nameEvidenceEngine = 'resume_text+pdf_ocr_name_fallback';
                        }
                    } else {
                        $nameEvidenceEngine = (string) ($ocrFallback['engine'] ?? 'pdf_ocr_name_fallback');
                    }

                    if (!empty($ocrNameResult['candidate_name'])) {
                        $ocrNameResult['ai_attempted'] = (bool) ($nameResult['ai_attempted'] ?? false);
                        $nameResult = $ocrNameResult;
                    } else {
                        $nameEvidenceEngine = (string) ($ocrFallback['engine'] ?? 'pdf_ocr_name_fallback');
                    }
                }
            }

            // Email extraction is deterministic/local; do not spend inference credits
            // on a field that can be validated from its syntax. Reuse OCR text when
            // already available. If a PDF has no email in its text layer, perform one
            // bounded first-page OCR retry (only if OCR has not already been attempted).
            $contactEvidenceText = trim($resumeText . "\n" . $earlyOcrText . "\n" . $ocrText);
            $emailContactEvidenceText = $contactEvidenceText;
            $emailResult = $candidateEmailService->extractFromResume($emailContactEvidenceText);
            if (empty($emailResult['candidate_email']) && $isPdf && !$ocrFallbackAttempted) {
                $emailOcrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $emailOcrText = trim((string) ($emailOcrFallback['text'] ?? ''));
                if ($emailOcrText !== '') {
                    // Keep email-only OCR isolated from name/mobile selection, but make
                    // the same recovered page text available to role matching later.
                    $emailContactEvidenceText = trim($contactEvidenceText . "\n" . $emailOcrText);
                    $emailResult = $candidateEmailService->extractFromResume($emailContactEvidenceText);
                    $ocrText = trim($ocrText . "\n" . $emailOcrText);
                }
            }
            $mobileEvidenceText = $contactEvidenceText;
            $mobileResult = $candidateMobileService->extractFromResume($mobileEvidenceText);

            // Local, explainable ATS role matching. This step never calls an LLM and
            // never changes name/mobile/email decisions. The active role catalogue
            // and optional per-role profile table control which roles are eligible.
            $roleEvidenceText = trim($resumeText . "\n" . $earlyOcrText . "\n" . $ocrText);
            $roleEvidenceEngine = trim($ocrText . $earlyOcrText) !== '' ? 'resume_text+pdf_ocr' : 'resume_text';
            $roleMatchResult = $candidateJobRoleMatchingService->matchResume($roleEvidenceText, 8);
            if (empty($roleMatchResult['matches']) && $isPdf && !$ocrFallbackAttempted) {
                try {
                    $roleOcrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                    $roleOcrText = trim((string) ($roleOcrFallback['text'] ?? ''));
                    if ($roleOcrText !== '') {
                        $roleEvidenceText = trim($roleEvidenceText . "\n" . $roleOcrText);
                        $roleEvidenceEngine = 'resume_text+' . (string) ($roleOcrFallback['engine'] ?? 'pdf_ocr_role_fallback');
                        $roleMatchResult = $candidateJobRoleMatchingService->matchResume($roleEvidenceText, 8);
                    }
                } catch (Throwable $roleOcrError) {
                    // Role suggestions are optional; OCR failure must not break resume upload.
                    Log::debug('Candidate role matching OCR fallback skipped.', [
                        'trace_id' => $traceId,
                        'exception' => get_class($roleOcrError),
                    ]);
                }
            }

            // Qualification/major suggestions use the existing database master tables;
            // no schema mutation and no additional AI inference.
            try {
                $qualificationMajorResult = $candidateQualificationMajorService->suggest($roleEvidenceText);
            } catch (Throwable $qualificationMajorError) {
                Log::warning('Candidate qualification/major suggestion unavailable.', ['trace_id' => $traceId, 'exception' => get_class($qualificationMajorError)]);
                $qualificationMajorResult = [];
            }

            // Experience classification and date-range union are local-only. It does
            // not invoke Hugging Face and cannot interrupt the name/contact/role flows.
            try {
                $experienceResult = $candidateExperienceService->suggest($roleEvidenceText);
            } catch (Throwable $experienceError) {
                Log::warning('Candidate experience suggestion unavailable.', [
                    'trace_id' => $traceId,
                    'exception' => get_class($experienceError),
                ]);
                $experienceResult = [];
            }

            Log::info('Resume candidate-name extraction completed', [
                'trace_id' => $traceId,
                'parser_version' => CandidateNameExtractionService::VERSION,
                'text_engine' => $textResult['engine'] ?? 'none',
                'name_evidence_engine' => $nameEvidenceEngine,
                'text_chars' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                'candidate_name_found' => !empty($nameResult['candidate_name']),
                'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                'ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                'candidate_mobile_found' => !empty($mobileResult['candidate_mobile']),
                'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                'candidate_email_found' => !empty($emailResult['candidate_email']),
                'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                'candidate_email_parser_version' => CandidateEmailService::VERSION,
                'candidate_role_match_version' => CandidateJobRoleMatchingService::VERSION,
                'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                'candidate_role_catalog_count' => (int) ($roleMatchResult['catalog_role_count'] ?? 0),
                'candidate_experience_type_found' => isset($experienceResult['candidate_experience_type']),
                'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                'local_parser_diagnostics' => $candidateNameExtractionService->getLastDiagnostics(),
            ]);

            $token = bin2hex(random_bytes(24));
            $sessionHash = hash('sha256', (string) $request->session()->getId());
            $cacheTtl = max(1, (int) config('recruitment_resume_ai.cache_ttl_minutes', 20));

            // Text remains server-side in the short-lived cache; never return the CV text
            // to the browser. Bind the cache entry to this session and exact file hash.
            Cache::put('hr_recruitment_resume_parse:' . $token, [
                'sha256' => $fileHash,
                'session_hash' => $sessionHash,
                'resume_text' => $resumeText,
                'data' => [
                    'candidate_name' => $nameResult['candidate_name'] ?? null,
                    'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                    'candidate_name_model' => $nameResult['model'] ?? null,
                    'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                    'candidate_name_ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                    'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                    'candidate_name_evidence_engine' => $nameEvidenceEngine,
                    'candidate_mobile' => $mobileResult['candidate_mobile'] ?? null,
                    'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                    'candidate_mobile_parser_version' => CandidateMobileService::VERSION,
                    'candidate_email' => $emailResult['candidate_email'] ?? null,
                    'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                    'candidate_email_parser_version' => CandidateEmailService::VERSION,
                    'candidate_role_matches' => $roleMatchResult['matches'] ?? [],
                    'suggested_job_role_ids' => $roleMatchResult['role_ids'] ?? [],
                    'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                    'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                    'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                    'candidate_role_match_parser_version' => CandidateJobRoleMatchingService::VERSION,
                    'candidate_qualification' => $qualificationMajorResult['candidate_qualification'] ?? null,
                    'candidate_qualification_name' => $qualificationMajorResult['candidate_qualification_name'] ?? null,
                    'candidate_major' => $qualificationMajorResult['candidate_major'] ?? null,
                    'candidate_major_name' => $qualificationMajorResult['candidate_major_name'] ?? null,
                    'candidate_other_qualify' => $qualificationMajorResult['candidate_other_qualify'] ?? null,
                    'candidate_qualification_major_source' => $qualificationMajorResult['candidate_qualification_major_source'] ?? 'not_found',
                    'candidate_qualification_major_confidence' => $qualificationMajorResult['candidate_qualification_major_confidence'] ?? 'low',
                    'candidate_qualification_major_parser_version' => CandidateQualificationMajorService::VERSION,
                    'candidate_experience_type' => $experienceResult['candidate_experience_type'] ?? null,
                    'candidate_experience_type_name' => $experienceResult['candidate_experience_type_name'] ?? null,
                    'candidate_exper_count' => $experienceResult['candidate_exper_count'] ?? null,
                    'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                    'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                    'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                    'candidate_experience_confidence' => $experienceResult['candidate_experience_confidence'] ?? 'low',
                    'candidate_experience_date_range_count' => (int) ($experienceResult['candidate_experience_date_range_count'] ?? 0),
                    'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                ],
                'text_extraction' => [
                    'engine' => $textResult['engine'] ?? 'none',
                    'extension' => $textResult['extension'] ?? strtolower($file->getClientOriginalExtension()),
                    'warning' => $textResult['warning'] ?? null,
                ],
                'created_at' => now()->toIso8601String(),
            ], now()->addMinutes($cacheTtl));

            $readable = $resumeText !== '';
            return response()->json([
                'status' => 200,
                'message' => $readable
                    ? (!empty($nameResult['candidate_name'])
                        ? 'Resume text read. Please verify the suggested candidate fields.'
                        : (!empty($emailResult['candidate_email']) || !empty($mobileResult['candidate_mobile'])
                            ? 'Resume text read. Contact suggestions are available; verify them and enter the candidate name manually if needed.'
                            : 'Resume text read, but no reliable candidate name was found. Enter it manually.'))
                    : 'The file was selected, but text could not be read. You can still attach the resume and enter the candidate name manually.',
                'data' => [
                    'candidate_name' => $nameResult['candidate_name'] ?? null,
                    'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                    'candidate_name_model' => $nameResult['model'] ?? null,
                    'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                    'candidate_name_ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                    'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                    'candidate_name_evidence_engine' => $nameEvidenceEngine,
                    'candidate_mobile' => $mobileResult['candidate_mobile'] ?? null,
                    'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                    'candidate_mobile_parser_version' => CandidateMobileService::VERSION,
                    'candidate_email' => $emailResult['candidate_email'] ?? null,
                    'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                    'candidate_email_parser_version' => CandidateEmailService::VERSION,
                    'candidate_role_matches' => $roleMatchResult['matches'] ?? [],
                    'suggested_job_role_ids' => $roleMatchResult['role_ids'] ?? [],
                    'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                    'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                    'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                    'candidate_role_match_parser_version' => CandidateJobRoleMatchingService::VERSION,
                    'candidate_qualification' => $qualificationMajorResult['candidate_qualification'] ?? null,
                    'candidate_qualification_name' => $qualificationMajorResult['candidate_qualification_name'] ?? null,
                    'candidate_major' => $qualificationMajorResult['candidate_major'] ?? null,
                    'candidate_major_name' => $qualificationMajorResult['candidate_major_name'] ?? null,
                    'candidate_other_qualify' => $qualificationMajorResult['candidate_other_qualify'] ?? null,
                    'candidate_qualification_major_source' => $qualificationMajorResult['candidate_qualification_major_source'] ?? 'not_found',
                    'candidate_qualification_major_confidence' => $qualificationMajorResult['candidate_qualification_major_confidence'] ?? 'low',
                    'candidate_qualification_major_parser_version' => CandidateQualificationMajorService::VERSION,
                    'candidate_experience_type' => $experienceResult['candidate_experience_type'] ?? null,
                    'candidate_experience_type_name' => $experienceResult['candidate_experience_type_name'] ?? null,
                    'candidate_exper_count' => $experienceResult['candidate_exper_count'] ?? null,
                    'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                    'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                    'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                    'candidate_experience_confidence' => $experienceResult['candidate_experience_confidence'] ?? 'low',
                    'candidate_experience_date_range_count' => (int) ($experienceResult['candidate_experience_date_range_count'] ?? 0),
                    'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                    'resume_extraction_token' => $token,
                    'resume_source_sha256' => $fileHash,
                    'text_extraction_engine' => $textResult['engine'] ?? 'none',
                    'text_extraction_status' => $readable ? 'readable' : 'unreadable',
                    'text_extraction_warning' => $textResult['warning'] ?? null,
                    'resume_text_chars' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                    'review_required' => true,
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Recruitment resume extraction endpoint failed', [
                'trace_id' => $traceId,
                'extension' => strtolower((string) $file->getClientOriginalExtension()),
                'size_bytes' => (int) ($file->getSize() ?: 0),
                'exception' => get_class($e),
            ]);

            return response()->json([
                'status' => 422,
                'trace_id' => $traceId,
                'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                'message' => 'This resume could not be processed automatically. The file can still be attached; please enter the candidate name manually and try saving again.',
            ], 422);
        }
    }
}
