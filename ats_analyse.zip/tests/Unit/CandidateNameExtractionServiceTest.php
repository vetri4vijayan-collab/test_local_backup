<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\HuggingFaceInferenceService;
use Generator;
use Tests\TestCase;

class CandidateNameExtractionServiceTest extends TestCase
{
    private const DEEPIKA_RESUME = "DEEPIKA A R\n8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu\n\nABOUT ME\nA highly motivated Computer Science Engineering Diploma graduate seeking an entry-level role.\n\nEDUCATION\nGovernment Polytechnic College for Women, Madurai\n\nTECHNICAL SKILLS\nPython (Proficient)\nJava (Basics)\nCanva Designing\n\nCERTIFICATIONS\nPoetry Competition Certification\nSports Certification";

    public function test_ai_is_attempted_first_and_malformed_name_uses_local_fallback(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([['name' => 'DE<>E<>P<>IK<>A<> <>A<>', 'model' => 'test-model', 'model_index' => 0]])
        );
        $client->method('wasLastRequestAttempted')->willReturn(true);
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertNull($result['model']);
        $this->assertTrue($result['ai_attempted']);
        $this->assertSame('malformed_name', $result['ai_result_status']);
        $this->assertSame(CandidateNameExtractionService::VERSION, $result['parser_version']);
    }

    public function test_ai_result_that_matches_a_certification_is_rejected_then_local_header_wins(): void
    {
        $client = $this->fakeHuggingFace([
            ['name' => 'Poetry Competition', 'model' => 'test-model', 'model_index' => 0],
        ]);
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertTrue($result['ai_attempted']);
    }

    public function test_verified_ai_name_is_used_before_local_fallback(): void
    {
        $client = $this->fakeHuggingFace([
            ['name' => 'DEEPIKA A R', 'model' => 'test-model', 'model_index' => 0],
        ]);
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('huggingface_primary', $result['source']);
        $this->assertSame('test-model', $result['model']);
        $this->assertTrue($result['ai_attempted']);
    }

    public function test_partial_ai_name_is_completed_only_when_source_contains_trailing_initial(): void
    {
        $client = $this->fakeHuggingFace([
            ['name' => 'Deepika A', 'model' => 'test-model', 'model_index' => 0],
        ]);
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('huggingface_primary', $result['source']);
        $this->assertTrue($result['ai_attempted']);
    }

    public function test_unavailable_or_empty_ai_result_falls_back_to_local_parser(): void
    {
        $client = $this->fakeHuggingFace([]);
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertNull($result['model']);
        $this->assertTrue($result['ai_attempted']);
    }

    public function test_flattened_pdf_text_recovers_identity_name_and_not_certification_item(): void
    {
        $text = "DEEPIKA A R 8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu ABOUT ME A motivated diploma graduate EDUCATION Government Polytechnic College TECHNICAL SKILLS Python Java Canva Designing CERTIFICATIONS Poetry Competition Certification";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));

        $result = $service->extract($text);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertTrue($result['ai_attempted']);
        $this->assertGreaterThan(0, $service->getLastDiagnostics()['long_raw_line_count'] ?? 0);
    }

    public function test_no_name_in_skills_or_certification_lists_returns_not_found(): void
    {
        $text = "TECHNICAL SKILLS\nPython\nJava\nCanva Designing\nCERTIFICATIONS\nPoetry Competition\nSports Certification";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([
            ['name' => 'Poetry Competition', 'model' => 'test-model', 'model_index' => 0],
        ]));

        $result = $service->extract($text);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertTrue($result['ai_attempted']);
    }


    public function test_header_fallback_prefers_real_name_over_plausible_skill_and_award_phrases(): void
    {
        $text = "PROFILE\nCanva Designing\nPoetry Competition\nTECHNICAL SKILLS\nPython\nDEEPIKA A R\n9876543210 | deepika@example.com";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));

        $result = $service->extractLocallyOnly($text);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    public function test_objective_prose_is_not_accepted_as_a_name(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("ABOUT ME\nA highly motivated graduate seeking to contribute and drive\norganizational growth.");

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
    }

    public function test_explicit_single_word_name_is_allowed_after_ai_fails(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("Name: ARUN\nEmail: arun@example.com\nABOUT ME\nSeeking a career");

        $this->assertSame('Arun', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    public function test_wrapped_name_is_recovered_after_ai_fails(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("DEEPIKA\nA R\n8300350913 | deepijp2004@gmail.com\nABOUT ME\nA motivated candidate.");

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function fakeHuggingFace(array $items): HuggingFaceInferenceService
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->method('extractNameCandidates')->willReturn($this->candidateGenerator($items));
        $client->method('wasLastRequestAttempted')->willReturn(true);
        return $client;
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function candidateGenerator(array $items): Generator
    {
        foreach ($items as $item) {
            yield $item;
        }
    }
}
