<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateMobileService;
use Tests\TestCase;

class CandidateMobileServiceTest extends TestCase
{
    public function test_international_indian_number_is_returned_without_country_code(): void
    {
        $service = new CandidateMobileService();
        $result = $service->extractFromResume("DEEPIKA A R\nMobile: +91 98765 43210\nEmail: candidate@example.com");

        $this->assertSame('9876543210', $result['candidate_mobile']);
        $this->assertSame('local_parser', $result['source']);
    }

    public function test_domestic_zero_prefix_and_grouped_numbers_are_normalized(): void
    {
        $service = new CandidateMobileService();
        $this->assertSame('9876543210', $service->normalizeIndianMobile('098765-43210'));
        $this->assertSame('9876543210', $service->normalizeIndianMobile('0091 98765 43210'));
        $this->assertSame('9876543210', $service->normalizeIndianMobile('+91 (98765) 43210'));
    }

    public function test_recovers_mobile_split_across_adjacent_pdf_lines(): void
    {
        $service = new CandidateMobileService();
        $result = $service->extractFromResume("DEEPIKA A R\nMobile: +91 98765\n43210\nEmail: deepika@example.com");

        $this->assertSame('9876543210', $result['candidate_mobile']);
    }

    public function test_prefers_labelled_candidate_contact_over_earlier_unlabelled_number(): void
    {
        $service = new CandidateMobileService();
        $text = "Some text 9123456789\nName: Candidate\nMobile: +91 98765 43210\nFather Mobile: 9876543211";
        $result = $service->extractFromResume($text);

        $this->assertSame('9876543210', $result['candidate_mobile']);
    }

    public function test_does_not_use_parent_or_reference_mobile_as_candidate_mobile(): void
    {
        $service = new CandidateMobileService();
        $result = $service->extractFromResume("Father Mobile: 9876543210\nAadhaar: 9876 5432 1098\nReferences: 9876543211");

        $this->assertNull($result['candidate_mobile']);
        $this->assertSame('not_found', $result['source']);
    }

    public function test_rejects_non_indian_or_invalid_mobile_values(): void
    {
        $service = new CandidateMobileService();
        $this->assertNull($service->normalizeIndianMobile('1234567890'));
        $this->assertNull($service->normalizeIndianMobile('987654321'));
        $this->assertNull($service->normalizeIndianMobile('+1 202 555 0100'));
    }
}
