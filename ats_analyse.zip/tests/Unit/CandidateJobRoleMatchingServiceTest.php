<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateJobRoleMatchingService;
use Tests\TestCase;

class CandidateJobRoleMatchingServiceTest extends TestCase
{
    private function service(): CandidateJobRoleMatchingService
    {
        return new CandidateJobRoleMatchingService();
    }

    private function roles(): array
    {
        $rows = [
            [7, 'MARKETING_EXECUTIVE', 'Marketing Executive', 'Marketing', 1],
            [8, 'MARKETING_EXECUTIVE_TEAM_LEAD', 'Marketing Executive Team Lead', 'Marketing', 3],
            [9, 'MARKETING_EXECUTIVE_MANAGER', 'Marketing Executive Manager', 'Marketing', 4],
            [20, 'FRONT_END_DEVELOPER', 'Front End Developer', 'Software Engineering', 1],
            [21, 'BACK_END_DEVELOPER', 'Back End Developer', 'Software Engineering', 1],
            [22, 'FULL_STACK_DEVELOPER', 'Full Stack Developer', 'Software Engineering', 1],
            [27, 'SENIOR_BACK_END_DEVELOPER', 'Senior Back End Developer', 'Software Engineering', 2],
            [37, 'DIGITAL_MARKETING_EXECUTIVE', 'Digital Marketing Executive', 'Digital Marketing', 1],
            [39, 'DIGITAL_MARKETING_MANAGER', 'Digital Marketing Manager', 'Digital Marketing', 4],
            [52, 'ACCOUNT_EXECUTIVE', 'Account Executive', 'Finance & Accounts', 1],
            [53, 'ACCOUNT_MANAGER', 'Account Manager', 'Finance & Accounts', 4],
            [48, 'HR_EXECUTIVE', 'HR Executive', 'Human Resources', 1],
            [50, 'RECRUITMENT_EXECUTIVE', 'Recruitment Executive', 'Recruitment', 1],
        ];

        return array_map(static fn ($r) => (object) [
            'sno' => $r[0], 'role_code' => $r[1], 'role_name' => $r[2],
            'role_family' => $r[3], 'seniority_level' => $r[4],
            'description' => null, 'role_description' => $r[2],
            'mandatory_skills' => null, 'preferred_skills' => null,
            'responsibilities' => null, 'minimum_experience' => null,
            'education_requirements' => null, 'seniority' => null,
        ], $rows);
    }

    public function test_backend_intern_is_matched_without_false_frontend_or_senior_recommendations(): void
    {
        $resume = "DEEPIKA R\nEDUCATION\nBachelor of Computer Applications BCA\nINTERNSHIP\nBackend Developer Intern\nDeveloped REST API using PHP Laravel MySQL\nTECHNICAL SKILLS\nPHP Laravel MySQL REST API JavaScript";
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles());
        $ids = $result['role_ids'];

        $this->assertContains(21, $ids, 'Back End Developer should be suggested.');
        $this->assertNotContains(20, $ids, 'Backend-only evidence should not recommend Front End Developer.');
        $this->assertNotContains(27, $ids, 'Internship-only evidence should not recommend a Senior role.');
    }

    public function test_marketing_internship_can_match_multiple_related_entry_level_roles_but_not_management(): void
    {
        $resume = "CANDIDATE\nEDUCATION: Bachelor of Business Administration BBA\nINTERNSHIPS\nDigital Marketing Intern at ABC\nWorked on SEO campaign, Google Ads, Meta Ads, Google Analytics\nTECHNICAL SKILLS\nSEO Google Ads social media marketing content strategy";
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles());
        $ids = $result['role_ids'];

        $this->assertContains(37, $ids, 'Digital Marketing Executive should be suggested.');
        $this->assertContains(7, $ids, 'General Marketing Executive is a related entry-level option.');
        $this->assertNotContains(9, $ids, 'Internship-only evidence must not recommend a manager role.');
        $this->assertNotContains(39, $ids, 'Internship-only evidence must not recommend a digital marketing manager role.');
    }

    public function test_accounts_internship_matches_account_executive_not_account_manager(): void
    {
        $resume = "PROFILE\nEntry-level accounting candidate\nEDUCATION\nBachelor of Commerce B.Com\nINTERNSHIP\nAccounts Intern\nPerformed Tally Prime, GST filing, bank reconciliation\nSKILLS\nTally GST Excel bookkeeping";
        $ids = $this->service()->matchAgainstCatalog($resume, $this->roles())['role_ids'];

        $this->assertContains(52, $ids);
        $this->assertNotContains(53, $ids);
    }

    public function test_degree_alone_does_not_generate_a_long_unreliable_role_list(): void
    {
        $resume = "EDUCATION\nBachelor of Computer Applications (BCA)\nACADEMIC QUALIFICATION\nComputer Applications";
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles());

        $this->assertSame([], $result['role_ids']);
        $this->assertSame('no_reliable_match', $result['status']);
    }

    public function test_full_stack_intern_with_frontend_and_backend_evidence_can_suggest_multiple_roles(): void
    {
        $resume = "EDUCATION\nBCA Computer Applications\nINTERNSHIP\nFull Stack Developer Intern\nBuilt a web app using React, JavaScript, PHP, Laravel, MySQL and REST API\nSKILLS\nHTML CSS React JavaScript PHP Laravel MySQL REST API";
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles());
        $ids = $result['role_ids'];

        $this->assertContains(22, $ids);
        $this->assertContains(20, $ids);
        $this->assertContains(21, $ids);
        $this->assertNotContains(27, $ids);
        $this->assertLessThanOrEqual(8, count($result['matches']));
        $this->assertArrayHasKey('evidence', $result['matches'][0]);
        $this->assertArrayHasKey('match_score', $result['matches'][0]);
    }

    public function test_configured_database_profile_keywords_are_used(): void
    {
        $resume = "EDUCATION\nBSc Computer Science\nWORK EXPERIENCE\nWorked on enterprise resource planning reports and Tally Prime accounting\nSKILLS\nTally Prime, GST filing, bank reconciliation";
        $profiles = [
            'ACCOUNT_EXECUTIVE' => (object) [
                'role_title_keywords' => json_encode(['accounts executive', 'accountant']),
                'education_keywords' => json_encode(['computer science']),
                'employment_keywords' => json_encode(['enterprise resource planning reports', 'accounts executive']),
                'internship_keywords' => json_encode([]),
                'skill_keywords' => json_encode(['Tally Prime', 'GST filing', 'bank reconciliation']),
                'exclude_keywords' => json_encode([]),
                'minimum_match_score' => 25,
            ],
        ];
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles(), $profiles);

        $this->assertContains(52, $result['role_ids']);
    }

    public function test_configured_minimum_experience_rejects_a_candidate_below_the_requirement(): void
    {
        $roles = $this->roles();
        foreach ($roles as $role) {
            if ($role->role_code === 'BACK_END_DEVELOPER') {
                $role->minimum_experience = '3 years';
            }
        }

        $resume = "EDUCATION\nBCA Computer Applications\nWORK EXPERIENCE\nBack End Developer with 2 years experience\nBuilt REST API using PHP Laravel MySQL\nSKILLS\nPHP Laravel MySQL REST API";
        $ids = $this->service()->matchAgainstCatalog($resume, $roles)['role_ids'];

        $this->assertNotContains(21, $ids, 'The configured three-year minimum should not match a two-year profile.');
    }

    public function test_every_suggestion_has_a_score_and_audit_evidence(): void
    {
        $resume = "EDUCATION\nBBA Marketing\nINTERNSHIP\nMarketing Intern\nAssisted with marketing campaign and market research\nSKILLS\nCampaign management, brand strategy, copywriting";
        $result = $this->service()->matchAgainstCatalog($resume, $this->roles());

        $this->assertNotEmpty($result['matches']);
        foreach ($result['matches'] as $match) {
            $this->assertGreaterThanOrEqual(0, $match['match_score']);
            $this->assertLessThanOrEqual(100, $match['match_score']);
            $this->assertNotEmpty($match['evidence']);
            $this->assertNotEmpty($match['evidence_categories']);
        }
    }
}
