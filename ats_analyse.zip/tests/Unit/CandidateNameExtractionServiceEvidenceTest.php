<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\HuggingFaceInferenceService;
use Generator;
use Tests\TestCase;

class CandidateNameExtractionServiceEvidenceTest extends TestCase
{
    public function test_ai_first_workflow_accepts_a_name_that_matches_the_source_header(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'ADITI RAO', 'model' => 'test-model', 'model_index' => 0],
            ])
        );

        $service = new CandidateNameExtractionService($client);
        $result = $service->extract("ADITI RAO\nMobile: 9876543210\nEmail: aditi.rao@example.com\nEDUCATION\nB.Com");

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('huggingface_primary', $result['source']);
        $this->assertTrue($result['ai_attempted']);
        $this->assertSame('accepted', $result['ai_result_status']);
    }

    public function test_ai_name_with_an_omitted_middle_initial_is_recovered_from_the_source_line(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Aditi R', 'model' => 'test-model', 'model_index' => 0],
            ])
        );

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            'DOB: 01-01-2000',
            'Gender: Female',
            'Marital Status: Single',
            'Nationality: Indian',
            'Location: Chennai',
            'Address: Chennai, Tamil Nadu',
            'LinkedIn: linkedin.com/in/example',
            'Availability: Immediate',
            'Aditi A R',
            'EDUCATION',
            'B.Com',
        ]);

        $result = $service->extract($resume);

        $this->assertSame('Aditi A R', $result['candidate_name']);
        $this->assertSame('huggingface_primary', $result['source']);
        $this->assertTrue($result['ai_attempted']);
        $this->assertSame('accepted', $result['ai_result_status']);
    }

    public function test_model_name_split_over_adjacent_header_lines_is_supported(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Aditi Rao', 'model' => 'test-model', 'model_index' => 0],
            ])
        );

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            'DOB: 01-01-2000',
            'Gender: Female',
            'Marital Status: Single',
            'Nationality: Indian',
            'Location: Chennai',
            'Address: Chennai, Tamil Nadu',
            'LinkedIn: linkedin.com/in/example',
            'Availability: Immediate',
            'Aditi',
            'Rao',
            'EDUCATION',
        ]);

        $result = $service->extract($resume);

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('accepted', $result['ai_result_status']);
    }


    public function test_contact_label_attached_to_the_name_line_does_not_break_source_matching(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Aditi Rao', 'model' => 'test-model', 'model_index' => 0],
            ])
        );

        $service = new CandidateNameExtractionService($client);
        $result = $service->extract("Aditi Rao - Mobile: 9876543210 - Email: aditi.rao@example.com\nEDUCATION\nB.Com");

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('accepted', $result['ai_result_status']);
    }

    public function test_compact_uppercase_ocr_name_is_recovered_only_when_letters_match_exactly(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'D E E P I K A A R', 'model' => 'test-model', 'model_index' => 0],
            ])
        );

        $service = new CandidateNameExtractionService($client);
        $resume = "DEEPIKA A R\n8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu\nABOUT ME\nA motivated graduate.";
        $result = $service->extract($resume);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('accepted', $result['ai_result_status']);
    }

    public function test_father_or_reference_name_is_not_accepted_as_the_candidate(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Rajesh Kumar', 'model' => 'test-model', 'model_index' => 0],
            ])
        );
        $client->method('wasLastRequestAttempted')->willReturn(true);

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            "Father's Name: Rajesh Kumar",
            'DOB: 01-01-2000',
            'Gender: Male',
            'Nationality: Indian',
            'EDUCATION',
            'B.Com',
        ]);

        $result = $service->extract($resume);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertSame('source_evidence_rejected', $result['ai_result_status']);
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function candidateGenerator(array $items): Generator
    {
        foreach ($items as $item) {
            yield $item;
        }
    }
}
