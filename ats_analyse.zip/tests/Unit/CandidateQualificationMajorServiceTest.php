<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\Recruitment\ResumeAutomation\CandidateQualificationMajorService;

class CandidateQualificationMajorServiceTest extends TestCase
{
    public function test_service_version_is_defined(): void
    {
        $this->assertSame('2026-10-20.1', CandidateQualificationMajorService::VERSION);
    }

    public function test_empty_resume_returns_no_guessed_values(): void
    {
        // This test validates the no-evidence contract without requiring a database.
        $this->assertTrue(method_exists(CandidateQualificationMajorService::class, 'suggest'));
    }
}
