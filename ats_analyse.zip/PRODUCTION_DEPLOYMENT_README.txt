CANDIDATE MANAGEMENT — PRODUCTION UPDATE PATCH
Generated: 2026-11-04
Base: current_production_server_mvc.zip
Overlay: candidate_version_update_mvc.zip

PURPOSE
-------
Deploy the updated AI-assisted Candidate Management page at:
  /hr_recruitment/candidate_management

The existing /hr_recruitment/manage_candidate route and ManageCandidate controller
are retained for backward compatibility. The menu link is changed to the new URL.

WHAT WAS MERGED / RESTORED
--------------------------
1. New CandidateManagement controller and the update-version ResumeAutomation services.
2. New candidate_management Blade view and ATS modal partial.
3. New route import and candidate-specific routes merged into the CURRENT PRODUCTION
   routes/web.php. Existing production routes, imports, AI routes and Wasabi routes
   are preserved. No wholesale replacement with the update archive's route file.
4. Current production vertical menu retained, with only the Manage Candidate URL and
   slug changed to the new candidate_management route.
5. Production History and VIP modal markup restored because the update table still
   calls openCandidateHistory() and openVipModal(). Existing functions/routes remain.
6. Candidate profile modal keeps Overview, ATS & role match, Resume extraction and
   Resume quality report, and adds Resume Viewer + Application Answers tabs.
7. candidate-profile-hero and active profile tabs use --bs-primary (ERP theme color)
   rather than the hardcoded blue gradient.
8. Added the three missing Eloquent models referenced by the update controller:
   ApplicantAtsRoleAnalysisModel, ApplicantAtsRoleMatchModel and
   ApplicantResumeExtractionModel.
9. Extended candidate_ats_analysis.sql with resume extraction snapshot and field-level
   evidence tables; all statements use CREATE TABLE IF NOT EXISTS.
10. Added Illuminate UploadedFile import to CandidateManagement.
11. Local resume deletion is conditional: local file is unlinked only after both
    Google Drive upload returns a file_id and Wasabi storePath() completes its
    checksum/length verification and storage-pointer write. If either cloud upload
    fails, the local file is retained as a fallback. No file is deleted on partial
    success. The JSON response reports resume_drive_verified, resume_local_removed,
    resume_storage and resume_storage_warning.
12. Candidate details endpoint now returns normalized application_answers, human
    readable qualification/major labels and authenticated inline/download resume URLs.
13. Added config/recruitment_resume_ai.php and config/recruitment_ats.php so the Hugging Face token,
   one-request default, bounded HTTP timeouts, OCR tools and parser version are configurable.

FILES IN THIS OVERLAY
---------------------
app/Http/Controllers/hr_management/hr_recruiter/candidate_management/CandidateManagement.php
app/Models/ApplicantAtsRoleAnalysisModel.php
app/Models/ApplicantAtsRoleMatchModel.php
app/Models/ApplicantResumeExtractionModel.php
app/Services/ApplicantResumeStorage/WasabiResumeStorageService.php
app/Services/Recruitment/ResumeAutomation/*.php
routes/web.php
resources/menu/verticalMenu.json
resources/views/content/hr_management/hr_recruiter/candidate_management/candidate_list.blade.php
resources/views/content/hr_management/hr_recruiter/candidate_management/partials/ats_candidate_modals.blade.php
database/sql/candidate_ats_analysis.sql
config/recruitment_resume_ai.php
config/recruitment_ats.php
tests/Unit/Candidate*Test.php (targeted parser/service regression tests only)

IMPORTANT COMPATIBILITY DECISIONS
---------------------------------
- Do NOT replace app/Services/GoogleDriveService.php with the update archive's copy.
  The current-production implementation is intentionally retained; the update copy
  contains an incomplete authenticate() path and should not overwrite the live one.
- Do NOT replace RecruitmentRoleController.php with the update copy. The production
  controller is retained to avoid unrelated role-management behavior changes.
- The existing production ApplicantResumeStorageController.php and its routes remain
  in place. The updated WasabiResumeStorageService includes objectAvailable(), which
  that controller calls. The update archive's route namespace typo is not copied.
- The existing ManageCandidate.php, ApplicantAIController.php, applicant models,
  interview/history/VIP controllers and all unrelated menu items remain untouched.
- The route file is a full merge based on the uploaded current-production routes/web.php.
  Before replacing the live route file, compare it against the live server version if
  any routes have changed since this ZIP was exported. If they have, merge only the
  new import and route block from the delivered file.

DEPLOYMENT
----------
1. Take a database backup and file backup. Test this overlay in staging first.
2. Copy the overlay files into the Laravel project, preserving the folder structure.
3. Run database/sql/candidate_ats_analysis.sql against the ERP database. It creates
   the ATS role-analysis, ATS role-match, resume extraction snapshot and optional
   field-evidence tables. This SQL does not alter egc_applicant or existing rows.
4. Confirm current ERP common-storage SQL is already installed, including:
   egc_applicant_file_storage, egc_applicant_storage_audit,
   egc_storage_feature_settings, egc_storage_objects and egc_storage_audit.
   Those are prerequisites of WasabiResumeStorageService::storePath().
5. Confirm AWS SDK and Wasabi settings are valid and enabled. Keep credentials in
   server environment/config only; do not commit secrets.
6. Confirm Google Drive OAuth/service-account settings and folder ID are valid.
7. Configure the optional resume-AI environment values below. If HF_TOKEN is not
   set, the service continues to read the existing egc_api_integration credential.
   Default model attempts is one (not all configured models); keep it at one unless
   paid fallback attempts are explicitly approved.

   HF_TOKEN=
   RECRUITMENT_RESUME_AI_HF_ENABLED=true
   RECRUITMENT_RESUME_AI_HF_MODELS=meta-llama/Llama-3.1-8B-Instruct:fastest
   RECRUITMENT_RESUME_AI_HF_MAX_MODEL_ATTEMPTS=1
   RECRUITMENT_RESUME_AI_HF_TIMEOUT_SECONDS=8
   RECRUITMENT_RESUME_AI_HF_CONNECT_TIMEOUT_SECONDS=2
   RECRUITMENT_RESUME_AI_CACHE_TTL_MINUTES=20
   RECRUITMENT_RESUME_AI_OCR_ENABLED=true
   RECRUITMENT_RESUME_AI_PDFTOTEXT_BINARY=pdftotext
   RECRUITMENT_RESUME_AI_PDFTOPPM_BINARY=pdftoppm
   RECRUITMENT_RESUME_AI_TESSERACT_BINARY=tesseract
   RECRUITMENT_RESUME_AI_OCR_LANGUAGES=eng
   RECRUITMENT_RESUME_AI_LIBREOFFICE_BINARY=libreoffice
   RECRUITMENT_RESUME_AI_ANTIWORD_BINARY=antiword
   RECRUITMENT_ATS_RESUME_PARSER_VERSION=resume_parser.v5

   OCR/format conversion tools are optional system packages. For scanned PDFs, install
   Poppler (pdftotext + pdftoppm) and Tesseract with the required language data. For
   legacy DOC/office conversions install LibreOffice and/or Antiword. The PHP app
   should already have its project dependencies available, including the libraries
   used by this module (Smalot PDF Parser, PhpOffice PHPWord and Symfony Process),
   plus DOM and ZIP PHP extensions. The uploaded ZIPs did not include composer.json,
   so no composer dependency update is included in this overlay.
8. Clear Laravel caches after deployment:
     php artisan optimize:clear
     php artisan route:clear
     php artisan view:clear
9. Check:
     php artisan route:list --name=candidate_management
     php artisan route:list --name=save_candidate_data
     php -l app/Http/Controllers/hr_management/hr_recruiter/candidate_management/CandidateManagement.php
     php -l app/Models/ApplicantAtsRoleAnalysisModel.php
     php -l app/Models/ApplicantAtsRoleMatchModel.php
     php -l app/Models/ApplicantResumeExtractionModel.php
     php -l routes/web.php
     php -l config/recruitment_resume_ai.php
     php -l config/recruitment_ats.php
10. Verify the new menu opens /hr_recruitment/candidate_management and the old route
   still opens ManageCandidate. Verify add candidate without resume, add candidate
   with resume, AI extraction review, multi-role selection, edit/update, duplicate
   mobile validation, History, VIP, ATS individual/bulk screens, resume preview,
   resume download and Application Answers.
11. On a controlled test candidate with a resume, verify both Google Drive and Wasabi
    objects before confirming resume_local_removed=true and checking the local file
    no longer exists. Force a Drive failure and a Wasabi failure separately: each
    case must retain the local file.

SAFETY / ROLLBACK
-----------------
- Resume local deletion is intentionally conservative and requires both cloud copies
  to be verified. Partial cloud failure leaves the local fallback intact.
- Existing production resume-access routes/controllers are retained, not rewritten.
- Roll back by restoring the backed-up route/menu/view/controller/service files. The
  newly created ATS/extraction tables are additive and can be left in place during a
  code rollback; do not drop them unless you have confirmed no newer records rely on
  them.

VALIDATION SCOPE
----------------
This patch was statically assembled against the two uploaded ZIPs. PHP syntax and
package contents are checked before delivery. A live Laravel/database/Wasabi/Google
Drive integration test cannot be performed from the uploaded archives alone; run the
staging checks above before production release. Only targeted Candidate* regression
files are included. The overlay deliberately does not include/replace tests/TestCase.php,
CreatesApplication.php or generic ExampleTest.php, so it cannot overwrite the live
project's test harness.
