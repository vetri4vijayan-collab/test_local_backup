<?php

/*
|--------------------------------------------------------------------------
| Recruitment Resume AI / extraction settings
|--------------------------------------------------------------------------
|
| Keep secrets in the server environment. HF_TOKEN is optional when the ERP
| already stores the Hugging Face key in egc_api_integration.
| The default model attempt count is intentionally one to control paid usage.
| OCR/conversion binaries are optional; native PHP parsers remain available.
*/

$models = array_values(array_filter(array_map(
    'trim',
    explode(',', (string) env('RECRUITMENT_RESUME_AI_HF_MODELS', 'meta-llama/Llama-3.1-8B-Instruct:fastest'))
), static fn ($model) => $model !== ''));

return [
    'cache_ttl_minutes' => (int) env('RECRUITMENT_RESUME_AI_CACHE_TTL_MINUTES', 20),

    'huggingface' => [
        'enabled' => (bool) env('RECRUITMENT_RESUME_AI_HF_ENABLED', true),
        'token' => (string) env('HF_TOKEN', ''),
        'endpoint' => (string) env('RECRUITMENT_RESUME_AI_HF_ENDPOINT', 'https://router.huggingface.co/v1/chat/completions'),
        'models' => $models,
        'timeout_seconds' => (int) env('RECRUITMENT_RESUME_AI_HF_TIMEOUT_SECONDS', 8),
        'connect_timeout_seconds' => (int) env('RECRUITMENT_RESUME_AI_HF_CONNECT_TIMEOUT_SECONDS', 2),
        'max_model_attempts' => (int) env('RECRUITMENT_RESUME_AI_HF_MAX_MODEL_ATTEMPTS', 1),
    ],

    'text' => [
        'ocr_enabled' => (bool) env('RECRUITMENT_RESUME_AI_OCR_ENABLED', true),
        'max_characters' => (int) env('RECRUITMENT_RESUME_AI_MAX_CHARACTERS', 150000),
        'pdftotext_binary' => (string) env('RECRUITMENT_RESUME_AI_PDFTOTEXT_BINARY', 'pdftotext'),
        'pdftoppm_binary' => (string) env('RECRUITMENT_RESUME_AI_PDFTOPPM_BINARY', 'pdftoppm'),
        'ocr_pdf_max_pages' => (int) env('RECRUITMENT_RESUME_AI_OCR_PDF_MAX_PAGES', 3),
        'max_image_pixels' => (int) env('RECRUITMENT_RESUME_AI_OCR_MAX_IMAGE_PIXELS', 40000000),
        'tesseract_binary' => (string) env('RECRUITMENT_RESUME_AI_TESSERACT_BINARY', 'tesseract'),
        'ocr_languages' => (string) env('RECRUITMENT_RESUME_AI_OCR_LANGUAGES', 'eng'),
        'libreoffice_binary' => (string) env('RECRUITMENT_RESUME_AI_LIBREOFFICE_BINARY', 'libreoffice'),
        'antiword_binary' => (string) env('RECRUITMENT_RESUME_AI_ANTIWORD_BINARY', 'antiword'),
    ],
];
