<?php

return [
    'resume_parser_version' => (string) env('RECRUITMENT_ATS_RESUME_PARSER_VERSION', 'resume_parser.v5'),
];
