<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use App\Models\WarningReasonModel;
use Illuminate\Support\Facades\Validator;

class WarningReason extends Controller
{
  public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $search_filter = $request->search_filter ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $categorylist = WarningReasonModel::where('status', '!=', 2);
        if ($search_filter != '') {
              $categorylist->where(function ($subquery) use ($search_filter) {
                  $subquery->where('warning_reason', 'LIKE', "%{$search_filter}%");

              });
          }
        $categorylist=$categorylist->orderBy('sno', 'desc')
         ->paginate($perpage);

        if ($request->ajax()) {
            $data = $categorylist->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'warning_reason' => $item->warning_reason	,
                    'description' => $item->description,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });
            return response()->json([
                'data' => $data,
                'current_page' => $categorylist->currentPage(),
                'last_page' => $categorylist->lastPage(),
                'total' => $categorylist->total(),
            ]);
        }
        return view('content.settings.hrm.warning_reason.warning_reason',[
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'categorylist'=>$categorylist,
        ]);
    }

    public function Add(Request $request){
      $validator = validator::make($request->all(),['warning_reason'=>'required']);
      if($validator->fails()){
        return response()->json([
          'status'=>401,
          'message'=>'incorrect format',
          'error_msg'=>$validator->message()->get('*'),
          'data'=>NULL,
        ],200);
      }
      else{
        $warning_reason = $request->warning_reason;
        $description = $request->description;
        $user_id = $request->user()->user_id ?? 1;
        $csr = WarningReasonModel::where('warning_reason','=',$warning_reason)->where('status','=',0)->first();
        if($csr){
          return response()->json([
            'status'=>200,
            'message'=>'Already Exist',
            'data'=>NULL
          ],200);
        }
        else{
          $add_category = new WarningReasonModel();
            $add_category->warning_reason = Ucfirst($warning_reason);
            $add_category->description = $description;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;

            $add_category->save();

            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Fuel Type added Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Fuel Type!',
                ]);
            }
        }
        // return $result;
        return redirect()->back()->with('success', 'Fuel Type Created successfully!');
        }
    }

    public function Status($id, Request $request)
    {

      $upd_statusModel = WarningReasonModel::where('sno', $id)->first();
      $upd_statusModel->status = $request->input('status', 0);
      $upd_statusModel->updated_by =  $request->user()->user_id ?? 1;
      $upd_statusModel->update();

      return response([
          'status' => 200,
          'message' => 'Successfully Status Updated!',
          'error_msg' => null,
          'data' => null,
      ], 200);
    }

    public function Delete($id, Request $request)
    {
        $upd_CourseCategoryModel = WarningReasonModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->updated_by =$request->user()->user_id ?? 1;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

     public function Edit($edit_id)
    {
      $itemcategoryedit = WarningReasonModel::where('sno', $edit_id)->first();
      return  response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $itemcategoryedit
      ], 200);
    }

  public function update(Request $request){

    $validator = validator::make($request->all(),['warning_reason'=>'required']);
    if($validator->fails()){

        return  response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
          ], 200);
    }
    else{
      $warning_reason = $request->warning_reason;
      $description = $request->description;
      $edit_id = $request->edit_id;
      $userid = $request->user()->user_id ?? 1;
        $csr = WarningReasonModel::where('warning_reason',ucwords($warning_reason))->where('sno','!=',$edit_id)->where('sno','!=','2')->first();
        if($csr){
          return response()->json([
          'status'=>200,
          'message'=>'Already Exist',
          'data'=>$csr,],200);
        } else{
                $add_category = WarningReasonModel::where('sno','=',$edit_id)->first();
                $add_category->warning_reason = Ucfirst($warning_reason);
                $add_category->description = $description;
                
                $add_category -> updated_by = $userid;
                $add_category->update();
          return redirect()->back()->with('success', 'Fuel Type edited successfully!');
        }
      }
    }
}
