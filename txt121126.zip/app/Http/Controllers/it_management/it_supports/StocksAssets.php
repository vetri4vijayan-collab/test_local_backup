<?php
namespace App\Http\Controllers\it_support\Stocks_Assets;
use App\Http\Controllers\Controller;
use App\Models\StockAssetModel;
use App\Models\StockCategoryModel;
use App\Models\UnitModel;
use App\Models\VendorCategoryModel;
use App\Models\StaffModel;
use App\Models\CompanyModel;
use App\Models\RequestPurchaseModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class StocksAssets extends Controller
// in this the self functions and Private variables and functions are refered from the brower website name -> stack overflow -> you can also use it
{
    public function index(Request $request)
    {
        return view('content.it_support.stocks_assets.stocks_assets');
    }
    public function GetStocks(Request $request): JsonResponse
    {
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $search = trim((string) $request->input('search', ''));
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        $query = StockAssetModel::query()->from('egc_it_stock_asset')
        ->join('egc_it_stock_category','egc_it_stock_asset.stock_category_id','=','egc_it_stock_category.sno')
        ->join('egc_unit','egc_it_stock_asset.unit_id','=','egc_unit.sno')
        ->join('egc_locations','egc_it_stock_asset.location','=','egc_locations.sno')
        ->leftJoin('egc_company','egc_it_stock_asset.company_id','=','egc_company.sno')
        ->select('egc_it_stock_asset.*','egc_it_stock_category.stock_category','egc_unit.unit_name','egc_locations.area','egc_company.company_name')
        ->addSelect(DB::raw('CASE WHEN egc_it_stock_asset.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . ' ELSE egc_company.company_name END AS company_name'))

        ->where('egc_it_stock_asset.status', '!=', 2);
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
            $q->where('egc_it_stock_asset.item_name','LIKE','%' . $search . '%')
            ->orWhere('egc_it_stock_category.stock_category','LIKE','%' . $search . '%')
            ->orWhere('egc_unit.unit_name','LIKE','%' . $search . '%')
            ->orWhere('egc_locations.area','LIKE','%' . $search . '%')
            ->orWhere('egc_company.company_name','LIKE','%' . $search . '%');
            });
        }
        $stocks = $query->orderByDesc('egc_it_stock_asset.sno')->paginate($perPage);
        $data = collect($stocks->items())->map(function ($stock) {
                return $this->formatStock($stock);
            })->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $stocks->currentPage(),
                'last_page' => $stocks->lastPage(),
                'per_page' => $stocks->perPage(),
                'total' => $stocks->total(),
                'from' => $stocks->firstItem(),
                'to' => $stocks->lastItem(),
            ],
        ]);
    }
    public function Dashboard(): JsonResponse
    {
        $baseQuery = StockAssetModel::query()->where('status', '!=', 2);
        $lowStockCount = (clone $baseQuery)->whereColumn('quantity','<=','reorder_level')->count();
        $totalOnHand = (clone $baseQuery)->sum('quantity');
        $totalItems = (clone $baseQuery)->count();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'low_stock_count' => (int) $lowStockCount,
                'total_on_hand' => (float) $totalOnHand,
                'total_items' => (int) $totalItems,
            ],
        ]);
    }
    public function show($id): JsonResponse
    {
        $stock = $this->getStockWithRelations($id);
        if (!$stock || (int) $stock->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Stock item not found.',
            ], 404);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $this->formatStock($stock),
        ]);
    }
    public function Add(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            ['item_name' => ['required','string','max:255',],
                'stock_category_id' => ['required','integer','exists:egc_it_stock_category,sno',],
                'unit_id' => ['required','integer','exists:egc_unit,sno',],
                'quantity' => ['required','numeric','min:0',],
                'reorder_level' => ['required','numeric','min:0',],
                'location' => ['required','integer','exists:egc_locations,sno',],
                'company_id' => ['required','integer','min:0',function ($attribute, $value, $fail) {
                  if ((int) $value === 0) {
                    return;
                    }
                    if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists())
                      {
                        $fail('The selected company is invalid.');
                        }
                        },
                        ],
            ],
            [
                'item_name.required' =>'Item name is required.',
                'stock_category_id.required' =>'Category is required.',
                'stock_category_id.exists' =>'Selected category is invalid.',
                'unit_id.required' =>'Unit is required.',
                'unit_id.exists' =>'Selected unit is invalid.',
                'quantity.required' =>'Quantity on hand is required.',
                'quantity.min' =>'Quantity cannot be negative.',
                'reorder_level.required' =>'Reorder level is required.',
                'reorder_level.min' =>'Reorder level cannot be negative.',
                'location.required' =>'Location is required.',
                'location.exists' =>'Selected location is invalid.',
                'company_id.required' =>'Company is required.',
                'company_id.exists' =>'Selected company is invalid.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        DB::beginTransaction();
        try {
            $userId = $request->user()->user_id ?? 1;
            $stock = new StockAssetModel();
            $stock->item_name =trim($request->item_name);
            $stock->stock_category_id =(int) $request->stock_category_id;
            $stock->unit_id =(int) $request->unit_id;
            $stock->quantity = $request->quantity;
            $stock->reorder_level =$request->reorder_level;
            $stock->location = (int) $request->location;
            $stock->company_id =(int) $request->company_id;
            $stock->status = 0;
            $stock->created_by = $userId;
            $stock->updated_by = $userId;
            $stock->save();
            DB::commit();
            $savedStock = $this->getStockWithRelations($stock->sno);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Stock item added successfully.',
                'data' => [
                    'stock_id' => $stock->sno,
                    'stock' =>
                        $this->formatStock($savedStock),
                ],
            ], 200);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Stock Asset Store Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>'Could not add the stock item.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function update(Request $request,$id): JsonResponse {
        $stock = StockAssetModel::find($id);
        if (!$stock || (int) $stock->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Stock item not found.',
            ], 404);
        }
        $validator = Validator::make(
             ['item_name' => ['required','string','max:255',],
                'stock_category_id' => ['required','integer','exists:egc_it_stock_category,sno',],
                'unit_id' => ['required','integer','exists:egc_unit,sno',],
                'quantity' => ['required','numeric','min:0',],
                'reorder_level' => ['required','numeric','min:0',],
                'location' => ['required','integer','exists:egc_locations,sno',],
                'company_id' => ['required','integer','min:0',function ($attribute, $value, $fail) {
                  if ((int) $value === 0) {
                    return;
                    }
                    if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists())
                      {
                        $fail('The selected company is invalid.');
                        }
                        },
                        ],
            ],
             [
                'item_name.required' =>'Item name is required.',
                'stock_category_id.required' =>'Category is required.',
                'stock_category_id.exists' =>'Selected category is invalid.',
                'unit_id.required' =>'Unit is required.',
                'unit_id.exists' =>'Selected unit is invalid.',
                'quantity.required' =>'Quantity on hand is required.',
                'quantity.min' =>'Quantity cannot be negative.',
                'reorder_level.required' =>'Reorder level is required.',
                'reorder_level.min' =>'Reorder level cannot be negative.',
                'location.required' =>'Location is required.',
                'location.exists' =>'Selected location is invalid.',
                'company_id.required' =>'Company is required.',
                'company_id.exists' =>'Selected company is invalid.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }

        DB::beginTransaction();
        try {
            $userId = $request->user()->user_id ?? 1;
            $stock->item_name =trim($request->item_name);
            $stock->stock_category_id =(int) $request->stock_category_id;
            $stock->unit_id =(int) $request->unit_id;
            $stock->quantity = $request->quantity;
            $stock->reorder_level =$request->reorder_level;
            $stock->location = (int) $request->location;
            $stock->company_id =(int) $request->company_id;
            $stock->status = 0;
            $stock->updated_by = $userId;
            $stock->save();
            DB::commit();
            $updatedStock =$this->getStockWithRelations($stock->sno);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>'Stock item updated successfully.',
                'data' => [
                    'stock_id' => $stock->sno,
                    'stock' =>$this->formatStock($updatedStock),
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Stock Asset Update Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>
                    'Unable to update stock item.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function StockMove(Request $request,$id): JsonResponse {
        $stock = StockAssetModel::find($id);
        if (!$stock || (int) $stock->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Stock item not found.',
            ], 404);
        }
        $validator = Validator::make(
            $request->all(),
            [
                'type' => ['required','string','in:IN,OUT',],
                'quantity' => ['required','numeric','gt:0',],
            ],
            [
                'type.required' =>  'Stock movement type is required.',
                'type.in' =>'Movement type must be IN or OUT.',
                'quantity.required' =>'Quantity is required.',
                'quantity.gt' =>'Quantity must be greater than zero.',
            ]
        );
        $validator->after(
            function ($validator) use (
                $request,
                $stock
            ) {
                if (strtoupper((string) $request->type) === 'OUT'&&is_numeric($request->quantity)&&(float) $request->quantity >(float) $stock->quantity) {
                    $validator->errors()->add('quantity','OUT quantity cannot be greater than available stock.');
                }
            }
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        DB::beginTransaction();
        try {
            $userId =$request->user()->user_id ?? 1;
            $movementType =strtoupper((string) $request->type);
            $movementQuantity =(float) $request->quantity;
            $currentQuantity =(float) $stock->quantity;
            if ($movementType === 'IN') {
                $newQuantity =$currentQuantity +$movementQuantity;

            } else {
                $newQuantity =$currentQuantity -$movementQuantity;
            }

            if ($newQuantity < 0) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'status' => 422,
                    'message' =>'Stock quantity cannot be negative.',
                ], 422);
            }
            $stock->quantity =$newQuantity;
            $stock->updated_by =$userId;
            $stock->save();
            DB::commit();
            $updatedStock =$this->getStockWithRelations($stock->sno);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>$movementType === 'IN'? 'Stock added successfully.': 'Stock issued successfully.',
                'data' => [
                    'stock_id' => $stock->sno,
                    'movement_type' =>  $movementType,
                    'movement_quantity' => $movementQuantity,
                    'old_quantity' => $currentQuantity,
                    'new_quantity' => (float) $updatedStock->quantity,
                    'stock_status' =>$this->getStockStatus($updatedStock->quantity,$updatedStock->reorder_level),
                    'stock' =>$this->formatStock($updatedStock),
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error(
                'Stock Movement Error',
                [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'stock_id' => $id,
                ]
            );
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>'Unable to update stock quantity.',
                'error' => config('app.debug')? $e->getMessage(): null,
            ], 500);
        }
    }
    public function raisePurchaseRequest(Request $request, $id): JsonResponse
{
    $stock = StockAssetModel::find($id);
    if (!$stock || (int) $stock->status === 2) {
        return response()->json([
            'success' => false,
            'status' => 404,
            'message' => 'Stock item not found.',
        ], 404);
    }
    if ((float) $stock->quantity > (float) $stock->reorder_level) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Purchase Request can only be raised when stock is at or below the reorder level.',
        ], 422);
    }
    $validator = Validator::make(
        $request->all(),
        [
            'type_id' => ['required','integer',],
            'estimated_cost' => ['required','integer','gt:0',],
            'quantity' => ['required','numeric','gt:0',],
            'vendor_id' => ['nullable','integer','exists:egc_vendor_category,sno',],
            'requester_id' => ['required','integer','exists:egc_staff,sno',],
            'justification' => ['required','string','max:1000',],
        ],
        [
        'estimated_cost.required' => 'Estimated cost is required.',
        'estimated_cost.integer' => 'Paise not allowed.',
        'estimated_cost.gt' => 'Estimated cost must be greater than zero.',
        'quantity.required' => 'Purchase quantity is required.',
        'quantity.numeric' => 'Purchase quantity must be a valid number.',
        'quantity.gt' => 'Purchase quantity must be greater than zero.',
        'vendor_id.integer' => 'Selected vendor is invalid.',
        'vendor_id.exists' => 'Selected vendor is invalid.',
        'requester_id.required' => 'Requester is required.',
        'requester_id.exists' => 'Selected requester is invalid.',
        'justification.required' => 'Justification is required.',
        'justification.max' => 'Justification cannot exceed 1000 characters.',
    ]
    );
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }
    DB::beginTransaction();
    try {
        $userId =$request->user()->user_id ?? 1;
       $purchaseRequest = new RequestPurchaseModel();
       $purchaseRequest->item_id = (int) $stock->sno;
       $purchaseRequest->type_id = (int) $request->type_id;
       $purchaseRequest->estimated_cost = (int) $request->estimated_cost;
       $purchaseRequest->quantity = $request->quantity;
       $purchaseRequest->vendor_id = $request->filled('vendor_id')? (int) $request->vendor_id: null;
       $purchaseRequest->requester_id = (int) $request->requester_id;
       $purchaseRequest->justification = trim($request->justification);
       $purchaseRequest->company_id = (int) $stock->company_id;
       $purchaseRequest->created_by = $userId;
       $purchaseRequest->updated_by = $userId;
       $purchaseRequest->status = 0;
      $purchaseRequest->save();
        DB::commit();
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Purchase Request raised successfully.',
            'data' => [
                'pr_id' => (int) $purchaseRequest->sno,
                'item_id' => (int) $purchaseRequest->item_id,
                'estimated_cost' => (int) $purchaseRequest->estimated_cost,
                'item_name' => $stock->item_name,
                'type_id' => (int) $purchaseRequest->type_id,
                'quantity' => (float) $purchaseRequest->quantity,
                'vendor_id' => $purchaseRequest->vendor_id,
                'requester_id' => (int) $purchaseRequest->requester_id,
                'justification' => $purchaseRequest->justification,
                'company_id' => (int) $purchaseRequest->company_id,
                'status' => (int) $purchaseRequest->status,
                'created_by' => $purchaseRequest->created_by,
                'created_at' => $purchaseRequest->created_at,
            ],
        ], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        Log::error(
'Purchase Request Creation Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),'stock_id' => $id,]);
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => 'Unable to raise Purchase Request.',
            'error' => config('app.debug')
                ? $e->getMessage()
                : null,
        ], 500);
    }
}
    public function Delete(Request $request,$id): JsonResponse
    {   $userId = $request->user()->user_id ?? 1;
        $stock = StockAssetModel::find($id);
        if (!$stock) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Stock item not found.',
            ], 404);
        }
        try {
            $stock->status = 2;
            $stock->updated_by = $userId;
            $stock->save();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>'Stock item deleted successfully.',
            ]);

        } catch (\Throwable $e) {
            Log::error('Stock Asset Delete Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>'Unable to delete stock item.',
                'error' => config('app.debug') ? $e->getMessage(): null,
            ], 500);
        }
    }
    public function listStockCategories(): JsonResponse
    {
        $categories = StockCategoryModel::query()->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','stock_category',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $categories,
        ]);
    }
    public function listUnits(): JsonResponse
    {
        $units = UnitModel::query()->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','unit_name',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $units,
        ]);
    }
    public function listLocations(): JsonResponse
    {
        $locations = DB::table('egc_locations')->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','area',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $locations,
        ]);
    }
    public function listCompanies(): JsonResponse
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $companies = CompanyModel::query()->where('status', 0)->orderBy('company_name', 'ASC')->get(['sno', 'company_name']);
        if ($generalSetting) {
            $companies->prepend((object) ['sno' => 0,'company_name' => $generalSetting->title ?? '-',]);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $companies,
        ]);
    }
    private function getStockWithRelations($id)
    {
        return StockAssetModel::query()->from('egc_it_stock_asset')
            ->leftJoin('egc_it_stock_category','egc_it_stock_asset.stock_category_id','=','egc_it_stock_category.sno')
            ->leftJoin('egc_unit','egc_it_stock_asset.unit_id','=','egc_unit.sno')
            ->leftJoin('egc_locations','egc_it_stock_asset.location','=','egc_locations.sno')
            ->leftJoin('egc_company','egc_it_stock_asset.company_id','=','egc_company.sno')
            ->where('egc_it_stock_asset.sno',$id)
            ->select('egc_it_stock_asset.*','egc_it_stock_category.stock_category','egc_unit.unit_name','egc_locations.area','egc_company.company_name') ->first();
    }
    private function formatStock($stock): array
    {
        $quantity =(float) $stock->quantity;
        $reorderLevel =(float) $stock->reorder_level;
        $isLow =$quantity <= $reorderLevel;
        return [
            'sno' =>(int) $stock->sno,
            'item_name' =>$stock->item_name,
            'stock_category_id' => (int) $stock->stock_category_id,
            'stock_category' => $stock->stock_category ?? '-',
            'unit_id' =>(int) $stock->unit_id,
            'unit_name' =>$stock->unit_name ?? '-',
            'quantity' =>$quantity,
            'reorder_level' => $reorderLevel,
            'location' => (int) $stock->location,
            'area' =>$stock->area ?? '-',
            'company_id' => (int) $stock->company_id,
            'company_name' => $stock->company_name ?? '-',
            'status' =>(int) $stock->status,
            'stock_status' =>$isLow? 'Low': 'Healthy',
            'can_raise_pr' =>$isLow,
            'created_by' =>$stock->created_by,
            'updated_by' => $stock->updated_by,
            'created_at' => $stock->created_at,
            'updated_at' => $stock->updated_at,
        ];
    }
    private function getStockStatus($quantity,$reorderLevel): string {
        return (float) $quantity <=(float) $reorderLevel? 'Low': 'Healthy';
    }
    public function listVendors(): JsonResponse
{
    $vendors = VendorCategoryModel::query()->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','vendor_category_name',]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $vendors,
    ]);
}
public function listRequesters(): JsonResponse
{
    $requesters = StaffModel::query()->where('status', 0)->orderBy('staff_name', 'ASC')->get(['sno', 'staff_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $requesters,
    ]);
}
}
