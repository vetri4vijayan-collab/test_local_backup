<?php

namespace App\Http\Controllers\hr_management\hr_operation;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\DepartmentModel;
use App\Models\HrTaskModel;
use App\Models\ManageEntityModel;
use App\Models\StaffModel;
use App\Models\HrTask\HrTaskActivityModel;
use App\Models\HrTask\HrTaskAssigneeModel;
use App\Models\HrTask\HrTaskChecklistItemModel;
use App\Models\HrTask\HrTaskChecklistProgressModel;
use App\Models\HrTask\HrTaskCommentModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class HrtaskController extends Controller
{
    private const PERMISSION_MENU = 'HR Management';
    private const PERMISSION_GROUP = 'HR Tasks';

    public function index(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        return view('content.hr_management.hr_task.hrtask', $this->pageData());
    }

    public function myTasks(Request $request)
    {
        // $this->requirePermission('My Tasks');
        return view('content.hr_management.hr_task.mytask', $this->pageData());
    }

    private function pageData(): array
    {
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $mainCompanyName = $generalSettings && trim((string) $generalSettings->title) !== ''
            ? $generalSettings->title
            : 'Main Company';

        $entities = ManageEntityModel::query()
            ->where('status', 0)
            ->orderBy('entity_name')
            ->get(['sno', 'company_id', 'entity_name', 'entity_short_name']);

        return compact('mainCompanyName', 'entities');
    }

    public function entities(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        $helper = new Helpers();
        $settings = $helper->general_setting_data();
        $items = [[
            'id' => 0,
            'text' => ($settings && $settings->title) ? $settings->title : 'Main Company',
        ]];

        $entities = ManageEntityModel::query()
            ->where('status', 0)
            ->orderBy('entity_name')
            ->get(['sno', 'entity_name', 'entity_short_name']);

        foreach ($entities as $entity) {
            $label = $entity->entity_short_name ?: $entity->entity_name;
            $items[] = ['id' => (int) $entity->sno, 'text' => (string) $label];
        }

        return response()->json(['data' => $items]);
    }

    public function departments(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        $entityId = (int) $request->query('entity_id', 0);
        $context = $this->resolveEntityContext($entityId);

        $departments = DepartmentModel::query()
            ->where('status', 0)
            ->where('company_type', $context['company_type'])
            ->where('company_id', $context['company_id'])
            ->where('entity_id', $context['entity_id'])
            ->orderBy('department_name')
            ->get(['sno', 'department_name']);

        return response()->json(['data' => $departments]);
    }

    public function staffOptions(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        $validated = $request->validate([
            'entity_id' => 'required|integer|min:0',
            'department_id' => 'required|integer|min:1',
        ]);

        $context = $this->resolveEntityContext((int) $validated['entity_id']);
        $this->assertDepartmentInContext((int) $validated['department_id'], $context);
        $staff = $this->staffQuery($context, (int) $validated['department_id'])
            ->orderBy('staff_name')
            ->get(['sno', 'staff_name', 'staff_id', 'nick_name', 'email_id', 'mobile_no']);

        return response()->json([
            'data' => $staff->map(function ($person) {
                $label = trim((string) ($person->staff_name ?: $person->nick_name));
                if ($person->staff_id) {
                    $label .= ' · ' . $person->staff_id;
                }
                return ['id' => (int) $person->sno, 'text' => $label];
            }),
        ]);
    }

    public function staffDetails(Request $request, $staffId)
    {
        // $this->requirePermission('HR Tasks');
        $staff = StaffModel::query()
            ->leftJoin('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_company', 'egc_staff.company_id', '=', 'egc_company.sno')
            ->where('egc_staff.sno', (int) $staffId)
            ->whereIn('egc_staff.status', [0, 1])
            ->select([
                'egc_staff.*',
                'egc_department.department_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_entity.entity_name',
                'egc_company.company_name',
            ])
            ->first();

        abort_unless($staff, 404, 'Staff member not found.');

        return response()->json([
            'data' => [
                'id' => (int) $staff->sno,
                'name' => $staff->staff_name ?: $staff->nick_name ?: 'Staff member',
                'staff_id' => $staff->staff_id,
                'nickname' => $staff->nick_name,
                'email' => $staff->email_id,
                'mobile' => $staff->mobile_no,
                'department' => $staff->department_name,
                'job_role' => $staff->job_role_name,
                'entity' => $staff->entity_name ?: $staff->company_name ?: 'Main Company',
                'date_of_joining' => $staff->date_of_joining,
                'profile_image' => $staff->profile_image_url,
            ],
        ]);
    }

    public function myTasksData(Request $request)
    {
        // $this->requirePermission('My Tasks');
        $staffId = $this->currentStaffId();
        if ($staffId <= 0) {
            return response()->json(['data' => [], 'stats' => $this->emptyStats(), 'pagination' => $this->emptyPagination()]);
        }

        $query = HrTaskModel::query()
            ->with(['assignees.staff', 'department'])
            ->withCount('checklistItems')
            ->where('status', '!=', 'cancelled')
            ->whereHas('assignees', function ($subQuery) use ($staffId) {
                $subQuery->where('staff_id', $staffId);
            });

        $this->applyTaskFilters($query, $request, $staffId);
        $stats = $this->myTaskStats($staffId);
        $paginator = $query->orderByRaw('CASE WHEN due_at IS NULL THEN 1 ELSE 0 END')
            ->orderBy('due_at')
            ->orderByDesc('sno')
            ->paginate($this->perPage($request));

        $data = $paginator->getCollection()->map(function ($task) use ($staffId) {
            return $this->mapTask($task, $staffId);
        })->values();

        return response()->json([
            'data' => $data,
            'stats' => $stats,
            'pagination' => $this->paginationPayload($paginator),
        ]);
    }

    public function tasksData(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        $query = HrTaskModel::query()
            ->with(['assignees.staff', 'department'])
            ->withCount('checklistItems')
            ->where('status', '!=', 'cancelled');

        $this->applyTaskFilters($query, $request);
        $stats = [
            'total' => (clone $query)->count(),
            'open' => (clone $query)->whereIn('status', ['assigned', 'in_progress'])->count(),
            'in_progress' => (clone $query)->where('status', 'in_progress')->count(),
            'completed' => (clone $query)->where('status', 'completed')->count(),
            'overdue' => (clone $query)->whereNotNull('due_at')->where('due_at', '<', now())->whereNotIn('status', ['completed', 'cancelled'])->count(),
        ];

        $paginator = $query->orderByRaw('CASE WHEN due_at IS NULL THEN 1 ELSE 0 END')
            ->orderBy('due_at')
            ->orderByDesc('sno')
            ->paginate($this->perPage($request));

        $data = $paginator->getCollection()->map(function ($task) {
            return $this->mapTask($task, null);
        })->values();

        return response()->json([
            'data' => $data,
            'stats' => $stats,
            'pagination' => $this->paginationPayload($paginator),
        ]);
    }

    public function show(Request $request, $taskId)
    {
        $task = HrTaskModel::query()
            ->with(['assignees.staff', 'department', 'checklistItems'])
            ->findOrFail((int) $taskId);

        $staffId = $this->currentStaffId();
        $isAssignee = $staffId > 0 && $task->assignees->contains('staff_id', $staffId);
        $canManage = $this->userCan('HR Tasks');
        abort_unless($isAssignee || $canManage, 403, 'You do not have access to this task.');

        $checklist = $task->checklistItems->map(function ($item) use ($staffId) {
            $progress = $staffId > 0
                ? HrTaskChecklistProgressModel::query()->where('item_id', $item->sno)->where('staff_id', $staffId)->first()
                : null;
            return [
                'id' => (int) $item->sno,
                'title' => $item->item_title,
                'required' => (bool) $item->is_required,
                'completed' => $progress ? (bool) $progress->is_completed : false,
            ];
        })->values();

        $comments = HrTaskCommentModel::query()
            ->leftJoin('egc_staff', 'egc_hr_task_comments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_hr_task_comments.task_id', $task->sno)
            ->orderBy('egc_hr_task_comments.created_at')
            ->limit(100)
            ->get([
                'egc_hr_task_comments.sno',
                'egc_hr_task_comments.staff_id',
                'egc_hr_task_comments.comment',
                'egc_hr_task_comments.created_at',
                'egc_staff.staff_name',
            ]);

        return response()->json([
            'data' => $this->mapTask($task, $staffId),
            'checklist' => $checklist,
            'comments' => $comments,
        ]);
    }

    public function store(Request $request)
    {
        // $this->requirePermission('HR Tasks');
        $validated = $this->validateTaskPayload($request, true);
        $context = $this->resolveEntityContext((int) $validated['entity_id']);
        $this->assertDepartmentInContext((int) $validated['department_id'], $context);
        $staff = $this->validatedAssignees($validated['staff_ids'], $context, (int) $validated['department_id']);
        $actorId = $this->currentActorId();

        $task = DB::transaction(function () use ($validated, $context, $staff, $actorId) {
            $task = HrTaskModel::create([
                'title' => trim($validated['title']),
                'description' => $validated['description'] ?? null,
                'company_type' => $context['company_type'],
                'company_id' => $context['company_id'],
                'entity_id' => $context['entity_id'],
                'branch_id' => $this->currentBranchId(),
                'department_id' => (int) $validated['department_id'],
                'created_by' => $actorId,
                'updated_by' => $actorId,
                'priority' => $validated['priority'],
                'status' => 'assigned',
                'due_at' => $validated['due_at'] ?? null,
            ]);
            $task->task_code = 'HRT-' . str_pad((string) $task->sno, 6, '0', STR_PAD_LEFT);
            $task->save();

            foreach ($staff as $person) {
                HrTaskAssigneeModel::create([
                    'task_id' => $task->sno,
                    'staff_id' => $person->sno,
                    'assigned_by' => $actorId,
                    'status' => 'assigned',
                    'progress_percent' => 0,
                ]);
            }

            $this->syncChecklist($task, $validated['checklist'] ?? [], $actorId);
            $this->logActivity($task->sno, $actorId, 'created', 'Task created and assigned.');
            return $task;
        });

        return response()->json([
            'success' => true,
            'message' => 'Task created successfully.',
            'task_id' => (int) $task->sno,
        ], 201);
    }

    public function update(Request $request, $taskId)
    {
        // $this->requirePermission('HR Tasks');
        $task = HrTaskModel::findOrFail((int) $taskId);
        abort_if($task->status === 'cancelled', 422, 'Cancelled tasks cannot be edited.');
        $validated = $this->validateTaskPayload($request, false);
        $context = $this->resolveEntityContext((int) $validated['entity_id']);
        $this->assertDepartmentInContext((int) $validated['department_id'], $context);
        $staff = $this->validatedAssignees($validated['staff_ids'], $context, (int) $validated['department_id']);
        $actorId = $this->currentActorId();

        DB::transaction(function () use ($task, $validated, $context, $staff, $actorId) {
            $task->fill([
                'title' => trim($validated['title']),
                'description' => $validated['description'] ?? null,
                'company_type' => $context['company_type'],
                'company_id' => $context['company_id'],
                'entity_id' => $context['entity_id'],
                'department_id' => (int) $validated['department_id'],
                'updated_by' => $actorId,
                'priority' => $validated['priority'],
                'due_at' => $validated['due_at'] ?? null,
            ]);
            $task->save();

            $newStaffIds = $staff->pluck('sno')->map(function ($id) { return (int) $id; })->all();
            HrTaskAssigneeModel::query()->where('task_id', $task->sno)
                ->whereNotIn('staff_id', $newStaffIds)->delete();

            foreach ($staff as $person) {
                HrTaskAssigneeModel::firstOrCreate(
                    ['task_id' => $task->sno, 'staff_id' => $person->sno],
                    ['assigned_by' => $actorId, 'status' => 'assigned', 'progress_percent' => 0]
                );
            }

            if (array_key_exists('checklist', $validated)) {
                $this->syncChecklist($task, $validated['checklist'], $actorId);
            }

            $this->refreshTaskStatus($task);
            $this->logActivity($task->sno, $actorId, 'updated', 'Task details were updated.');
        });

        return response()->json(['success' => true, 'message' => 'Task updated successfully.']);
    }

    public function destroy(Request $request, $taskId)
    {
        // $this->requirePermission('HR Tasks');
        $task = HrTaskModel::findOrFail((int) $taskId);
        if ($task->status !== 'cancelled') {
            $task->status = 'cancelled';
            $task->cancelled_at = now();
            $task->updated_by = $this->currentActorId();
            $task->save();
            $this->logActivity($task->sno, $this->currentActorId(), 'cancelled', 'Task was cancelled.');
        }

        return response()->json(['success' => true, 'message' => 'Task cancelled.']);
    }

    public function updateAssigneeStatus(Request $request, $taskId)
    {
        $staffId = $this->currentStaffId();
        abort_if($staffId <= 0, 403, 'Your login is not linked to a staff profile.');
        $validated = $request->validate(['status' => 'required|in:assigned,in_progress,completed']);
        $task = HrTaskModel::findOrFail((int) $taskId);
        abort_if($task->status === 'cancelled', 422, 'This task has been cancelled.');

        $assignment = HrTaskAssigneeModel::query()
            ->where('task_id', $task->sno)
            ->where('staff_id', $staffId)
            ->firstOrFail();

        if ($validated['status'] === 'completed') {
            $requiredIds = HrTaskChecklistItemModel::query()
                ->where('task_id', $task->sno)
                ->where('is_required', 1)
                ->pluck('sno');
            $completedCount = $requiredIds->isEmpty() ? 0 : HrTaskChecklistProgressModel::query()
                ->where('task_id', $task->sno)
                ->where('staff_id', $staffId)
                ->whereIn('item_id', $requiredIds)
                ->where('is_completed', 1)
                ->count();

            if ($completedCount < $requiredIds->count()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Complete all required checklist items before marking this task as completed.',
                ], 422);
            }
        }

        $assignment->status = $validated['status'];
        $assignment->started_at = $validated['status'] === 'assigned'
            ? null
            : ($assignment->started_at ?: now());
        $assignment->completed_at = $validated['status'] === 'completed' ? now() : null;
        if ($validated['status'] === 'completed') {
            $assignment->progress_percent = 100;
        }
        $assignment->save();

        $this->refreshTaskStatus($task);
        $this->logActivity($task->sno, $staffId, 'assignee_status', 'Task status changed to ' . str_replace('_', ' ', $validated['status']) . '.');

        return response()->json(['success' => true, 'message' => 'Task status updated.']);
    }

    public function updateChecklist(Request $request, $taskId, $itemId)
    {
        $staffId = $this->currentStaffId();
        abort_if($staffId <= 0, 403, 'Your login is not linked to a staff profile.');
        $validated = $request->validate(['completed' => 'required|boolean']);
        $task = HrTaskModel::findOrFail((int) $taskId);
        abort_if($task->status === 'cancelled', 422, 'This task has been cancelled.');

        $assignment = HrTaskAssigneeModel::query()
            ->where('task_id', $task->sno)
            ->where('staff_id', $staffId)
            ->firstOrFail();
        $item = HrTaskChecklistItemModel::query()
            ->where('task_id', $task->sno)
            ->where('sno', (int) $itemId)
            ->firstOrFail();

        HrTaskChecklistProgressModel::updateOrCreate(
            ['item_id' => $item->sno, 'staff_id' => $staffId],
            [
                'task_id' => $task->sno,
                'is_completed' => (bool) $validated['completed'],
                'completed_at' => $validated['completed'] ? now() : null,
                'updated_by' => $staffId,
            ]
        );

        $total = HrTaskChecklistItemModel::query()->where('task_id', $task->sno)->count();
        $done = $total > 0 ? HrTaskChecklistProgressModel::query()
            ->where('task_id', $task->sno)
            ->where('staff_id', $staffId)
            ->where('is_completed', 1)
            ->count() : 0;
        $assignment->progress_percent = $total > 0 ? (int) round(($done / $total) * 100) : 0;
        if ($assignment->status === 'completed' && !$validated['completed']) {
            $assignment->status = 'in_progress';
            $assignment->completed_at = null;
        }
        $assignment->save();

        if ($assignment->status === 'assigned' && $validated['completed']) {
            $assignment->status = 'in_progress';
            $assignment->started_at = now();
            $assignment->save();
        }
        $this->refreshTaskStatus($task);

        return response()->json([
            'success' => true,
            'progress_percent' => (int) $assignment->progress_percent,
            'message' => 'Checklist updated.',
        ]);
    }

    public function comments(Request $request, $taskId)
    {
        $task = HrTaskModel::findOrFail((int) $taskId);
        $this->assertTaskAccess($task);

        $comments = HrTaskCommentModel::query()
            ->leftJoin('egc_staff', 'egc_hr_task_comments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_hr_task_comments.task_id', $task->sno)
            ->orderBy('egc_hr_task_comments.created_at')
            ->limit(100)
            ->get([
                'egc_hr_task_comments.sno',
                'egc_hr_task_comments.staff_id',
                'egc_hr_task_comments.comment',
                'egc_hr_task_comments.created_at',
                'egc_staff.staff_name',
            ]);

        return response()->json(['data' => $comments]);
    }

    public function storeComment(Request $request, $taskId)
    {
        $task = HrTaskModel::findOrFail((int) $taskId);
        $this->assertTaskAccess($task);
        $validated = $request->validate(['comment' => 'required|string|max:5000']);
        $staffId = $this->currentActorId();

        $comment = HrTaskCommentModel::create([
            'task_id' => $task->sno,
            'staff_id' => $staffId,
            'comment' => trim($validated['comment']),
        ]);
        $this->logActivity($task->sno, $staffId, 'commented', 'A comment was added.');

        return response()->json([
            'success' => true,
            'message' => 'Comment added.',
            'comment' => [
                'id' => (int) $comment->sno,
                'comment' => $comment->comment,
                'staff_name' => optional(StaffModel::find($staffId))->staff_name ?: 'You',
                'created_at' => optional($comment->created_at)->format('d M Y, h:i A'),
            ],
        ], 201);
    }

    private function validateTaskPayload(Request $request, bool $isCreate): array
    {
        $rules = [
            'title' => 'required|string|max:180',
            'description' => 'nullable|string|max:30000',
            'entity_id' => 'required|integer|min:0',
            'department_id' => 'required|integer|min:1',
            'staff_ids' => 'required|array|min:1',
            'staff_ids.*' => 'required|integer|distinct|min:1',
            'priority' => 'required|in:low,normal,high,urgent',
            'due_at' => 'nullable|date',
            'checklist' => 'sometimes|array|max:50',
            'checklist.*.id' => 'nullable|integer|min:1',
            'checklist.*.title' => 'required|string|max:255',
        ];

        return $request->validate($rules);
    }

    private function resolveEntityContext(int $entityId): array
    {
        if ($entityId === 0) {
            return ['company_type' => 1, 'company_id' => 0, 'entity_id' => 0];
        }

        $entity = ManageEntityModel::query()
            ->where('status', 0)
            ->findOrFail($entityId);

        return [
            'company_type' => 2,
            'company_id' => (int) $entity->company_id,
            'entity_id' => (int) $entity->sno,
        ];
    }

    private function assertDepartmentInContext(int $departmentId, array $context): DepartmentModel
    {
        return DepartmentModel::query()
            ->where('sno', $departmentId)
            ->where('status', 0)
            ->where('company_type', $context['company_type'])
            ->where('company_id', $context['company_id'])
            ->where('entity_id', $context['entity_id'])
            ->firstOrFail();
    }

    private function staffQuery(array $context, int $departmentId)
    {
        return StaffModel::query()
            ->where('sno', '>', 0)
            ->whereIn('status', [0, 1])
            ->where(function ($query) {
                $query->whereNull('notice_check')->orWhere('notice_check', '!=', 1);
            })
            ->where('company_type', $context['company_type'])
            ->where('company_id', $context['company_id'])
            ->where('entity_id', $context['entity_id'])
            ->where('department_id', $departmentId);
    }

    private function validatedAssignees(array $staffIds, array $context, int $departmentId)
    {
        $ids = array_values(array_unique(array_map('intval', $staffIds)));
        $staff = $this->staffQuery($context, $departmentId)->whereIn('sno', $ids)->get();

        if ($staff->count() !== count($ids)) {
            throw ValidationException::withMessages([
                'staff_ids' => ['One or more selected staff members do not belong to the selected entity and department. Refresh the staff list and try again.'],
            ]);
        }

        return $staff;
    }

    private function applyTaskFilters($query, Request $request, ?int $assigneeStaffId = null): void
    {
        if ($request->filled('search')) {
            $search = trim((string) $request->query('search'));
            $query->where(function ($subQuery) use ($search) {
                $subQuery->where('task_code', 'like', '%' . $search . '%')
                    ->orWhere('title', 'like', '%' . $search . '%')
                    ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        if ($request->filled('status') && in_array($request->query('status'), ['assigned', 'in_progress', 'completed'], true)) {
            $filterStatus = $request->query('status');
            if ($assigneeStaffId) {
                $query->whereHas('assignees', function ($subQuery) use ($assigneeStaffId, $filterStatus) {
                    $subQuery->where('staff_id', $assigneeStaffId)->where('status', $filterStatus);
                });
            } else {
                $query->where('status', $filterStatus);
            }
        }
        if ($request->filled('priority') && in_array($request->query('priority'), ['low', 'normal', 'high', 'urgent'], true)) {
            $query->where('priority', $request->query('priority'));
        }
        if ($request->filled('entity_id') && is_numeric($request->query('entity_id'))) {
            $query->where('entity_id', (int) $request->query('entity_id'));
        }
        if ($request->filled('department_id') && is_numeric($request->query('department_id'))) {
            $query->where('department_id', (int) $request->query('department_id'));
        }
    }

    private function mapTask(HrTaskModel $task, ?int $currentStaffId): array
    {
        $assignees = $task->relationLoaded('assignees') ? $task->assignees : $task->assignees()->with('staff')->get();
        $currentAssignment = $currentStaffId
            ? $assignees->firstWhere('staff_id', $currentStaffId)
            : null;
        $assigneeCount = $assignees->count();
        $avgProgress = $assigneeCount > 0 ? (int) round($assignees->avg('progress_percent')) : 0;

        return [
            'id' => (int) $task->sno,
            'task_code' => $task->task_code,
            'title' => $task->title,
            'description' => $task->description,
            'entity_id' => (int) $task->entity_id,
            'department_id' => (int) $task->department_id,
            'department_name' => optional($task->department)->department_name,
            'priority' => $task->priority,
            'status' => $task->status,
            'due_at' => $task->due_at ? $task->due_at->format('Y-m-d H:i:s') : null,
            'due_label' => $task->due_at ? $task->due_at->format('d M Y, h:i A') : 'No due date',
            'is_overdue' => $task->due_at && $task->due_at->isPast() && $task->status !== 'completed',
            'assignee_count' => $assigneeCount,
            'assignees' => $assignees->map(function ($assignment) {
                return [
                    'staff_id' => (int) $assignment->staff_id,
                    'name' => optional($assignment->staff)->staff_name ?: 'Staff member',
                    'status' => $assignment->status,
                    'progress_percent' => (int) $assignment->progress_percent,
                ];
            })->values(),
            'progress_percent' => $currentAssignment
                ? (int) $currentAssignment->progress_percent
                : $avgProgress,
            'my_status' => $currentAssignment ? $currentAssignment->status : null,
            'checklist_count' => (int) ($task->checklist_items_count ?? $task->checklistItems()->count()),
            'completed_assignees' => $assignees->where('status', 'completed')->count(),
            'created_at' => optional($task->created_at)->format('d M Y'),
        ];
    }

    private function myTaskStats(int $staffId): array
    {
        $base = HrTaskModel::query()
            ->where('status', '!=', 'cancelled')
            ->whereHas('assignees', function ($query) use ($staffId) {
                $query->where('staff_id', $staffId);
            });

        return [
            'total' => (clone $base)->count(),
            'open' => (clone $base)->whereHas('assignees', function ($query) use ($staffId) {
                $query->where('staff_id', $staffId)->where('status', 'assigned');
            })->count(),
            'in_progress' => (clone $base)->whereHas('assignees', function ($query) use ($staffId) {
                $query->where('staff_id', $staffId)->where('status', 'in_progress');
            })->count(),
            'completed' => (clone $base)->whereHas('assignees', function ($query) use ($staffId) {
                $query->where('staff_id', $staffId)->where('status', 'completed');
            })->count(),
            'overdue' => (clone $base)->whereNotNull('due_at')->where('due_at', '<', now())->whereHas('assignees', function ($query) use ($staffId) {
                $query->where('staff_id', $staffId)->where('status', '!=', 'completed');
            })->count(),
        ];
    }

    private function syncChecklist(HrTaskModel $task, array $items, int $actorId): void
    {
        $keepIds = [];
        foreach (array_values($items) as $index => $item) {
            $title = trim((string) ($item['title'] ?? ''));
            if ($title === '') {
                continue;
            }

            $checklistItem = null;
            if (!empty($item['id'])) {
                $checklistItem = HrTaskChecklistItemModel::query()
                    ->where('task_id', $task->sno)
                    ->where('sno', (int) $item['id'])
                    ->first();
            }

            if ($checklistItem) {
                $checklistItem->item_title = $title;
                $checklistItem->sort_order = $index + 1;
                $checklistItem->save();
            } else {
                $checklistItem = HrTaskChecklistItemModel::create([
                    'task_id' => $task->sno,
                    'item_title' => $title,
                    'sort_order' => $index + 1,
                    'is_required' => 1,
                    'created_by' => $actorId,
                ]);
            }
            $keepIds[] = (int) $checklistItem->sno;
        }

        HrTaskChecklistItemModel::query()->where('task_id', $task->sno)
            ->whereNotIn('sno', $keepIds ?: [0])->delete();
    }

    private function refreshTaskStatus(HrTaskModel $task): void
    {
        $assignees = HrTaskAssigneeModel::query()->where('task_id', $task->sno)->get();
        if ($assignees->isEmpty()) {
            $task->status = 'assigned';
        } elseif ($assignees->every(function ($assignment) { return $assignment->status === 'completed'; })) {
            $task->status = 'completed';
            $task->completed_at = now();
        } elseif ($assignees->contains(function ($assignment) { return in_array($assignment->status, ['in_progress', 'completed'], true); })) {
            $task->status = 'in_progress';
            $task->completed_at = null;
        } else {
            $task->status = 'assigned';
            $task->completed_at = null;
        }
        $task->save();
    }

    private function assertTaskAccess(HrTaskModel $task): void
    {
        $staffId = $this->currentStaffId();
        $isAssignee = $staffId > 0 && $task->assignees()->where('staff_id', $staffId)->exists();
        abort_unless($isAssignee || $this->userCan('HR Tasks'), 403, 'You do not have access to this task.');
    }

    private function logActivity(int $taskId, int $actorId, string $type, string $message): void
    {
        HrTaskActivityModel::create([
            'task_id' => $taskId,
            'actor_staff_id' => $actorId,
            'activity_type' => $type,
            'message' => $message,
            'metadata' => null,
        ]);
    }

    private function requirePermission(string $lastMenu): void
    {
        abort_unless($this->userCan($lastMenu), 403, 'You do not have permission to access this HR task page. Ask your administrator to enable it in User Role Permission.');
    }

    private function userCan(string $lastMenu): bool
    {
         return true;
        $user = auth()->user();
        if (!$user || empty($user->role_id)) {
            return false;
        }

        // Read the stored role JSON directly. User::hasPermission currently
        // double-decodes the model's already-decoded permission value on this project.
        $rolePermission = DB::table('egc_user_role_permission')
            ->where('role_id', (int) $user->role_id)
            ->where('status', 0)
            ->first();

        if (!$rolePermission) {
            return false;
        }

        $permissions = $rolePermission->permissions ?? [];
        // Some legacy permission rows are stored as JSON encoded twice.
        for ($decodeAttempt = 0; $decodeAttempt < 2 && is_string($permissions); $decodeAttempt++) {
            $decodedPermissions = json_decode($permissions, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                break;
            }
            $permissions = $decodedPermissions;
        }
        if (!is_array($permissions)) {
            return false;
        }

        foreach ($permissions as $menu) {
            if (($menu['menuName'] ?? null) !== self::PERMISSION_MENU || (int) ($menu['menuChecked'] ?? 0) !== 1) {
                continue;
            }
            foreach (($menu['submenu'] ?? []) as $submenu) {
                if (($submenu['submenuName'] ?? null) !== self::PERMISSION_GROUP || (int) ($submenu['submenuChecked'] ?? 0) !== 1) {
                    continue;
                }
                foreach (($submenu['lastmenu'] ?? []) as $lastMenuItem) {
                    if (($lastMenuItem['lastmenuName'] ?? null) === $lastMenu
                        && (int) ($lastMenuItem['lastmenuChecked'] ?? 0) === 1) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private function currentStaffId(): int
    {
        return (int) (auth()->user()->user_id ?? 0);
    }

    private function currentActorId(): int
    {
        return (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
    }

    private function currentBranchId(): int
    {
        return (int) (auth()->user()->branch_id ?? 0);
    }

    private function perPage(Request $request): int
    {
        $value = (int) $request->query('per_page', 15);
        return in_array($value, [10, 15, 25, 50], true) ? $value : 15;
    }

    private function paginationPayload($paginator): array
    {
        return [
            'current_page' => $paginator->currentPage(),
            'last_page' => $paginator->lastPage(),
            'per_page' => $paginator->perPage(),
            'total' => $paginator->total(),
        ];
    }

    private function emptyStats(): array
    {
        return ['total' => 0, 'open' => 0, 'in_progress' => 0, 'completed' => 0, 'overdue' => 0];
    }

    private function emptyPagination(): array
    {
        return ['current_page' => 1, 'last_page' => 1, 'per_page' => 15, 'total' => 0];
    }
}
