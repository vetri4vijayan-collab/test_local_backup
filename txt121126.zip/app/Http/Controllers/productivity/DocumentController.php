<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Document;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Models\ManageCategoryModel;
use App\Models\CompanyModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class DocumentController extends ProductivityBaseController
{
    private const MIME = 'pdf,doc,docx,xls,xlsx,ppt,pptx,zip,jpg,jpeg,png,webp,txt,csv';

    public function index(Request $request) { 
        $category_list = ManageCategoryModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $personal_category = ManageCategoryModel::where('status', 0)
            ->select('sno', 'category_name')
            ->where('category_scope','Personal')
            ->orderBy('category_name', 'asc')
            ->get();
        $official_category = ManageCategoryModel::where('status', 0)
            ->select('sno', 'category_name')
            ->where('category_scope','Official')
            ->orderBy('category_name', 'asc')
            ->get();
        return view('content.productivity.documents.index',[
            'category_list' => $category_list,
            'company_list' => $company_list,
            'personal_category' => $personal_category,
            'official_category' => $official_category,
        ]); 
    }

    public function data(Request $request)
    {
        $query = Document::query()->whereNull('egc_tool_documents.deleted_at')->where('egc_tool_documents.status', 0)
        ->select('egc_tool_documents.*','egc_tool_manage_category.category_name')
        ->join('egc_tool_manage_category', 'egc_tool_documents.category_id', 'egc_tool_manage_category.sno');
        $this->applyReadableScope('document',$query,$request,'owner_user_id','visibility');
        if ($request->filled('scope')) $query->where('scope', $request->scope);
        if ($request->filled('category_id')) $query->where('category_id', $request->category_id);
        if ($request->filled('search')) $query->where('document_name', 'like', '%'.trim((string) $request->search).'%');
        return $this->ok(['rows' => $query->orderByDesc('is_pinned')->orderByDesc('updated_at')->paginate(min(max((int) $request->get('per_page', 30), 10), 100))]);
    }

    public function upload(Request $request)
    {
        $user_id = $request->user()->user_id ?? 1;
        abort_unless($this->access->canWrite(), 403);
        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'scope' => ['required', 'in:Personal,Official'],
            'category' => ['required', 'integer'],
            'document_name' => ['nullable', 'string', 'max:220'],
            'expiry_date' => ['nullable', 'date'],
            'document' => ['required','file','max:51200','mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,zip,jpg,jpeg,png,webp,avif,txt,csv'],
        ]);

        $this->assertCompany($data['company_id'] ?? null);
        $file = $request->file('document');
        if (!$file || !$file->isValid()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid uploaded file.'
            ], 422);
        }
        $folderPath = public_path('egpk/documents');
        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0755, true);
        }
        $extension = $file->getClientOriginalExtension();
        $filename = 'doc_' . uniqid() . '_' . time() . '.' . $extension;
        $file->move($folderPath, $filename);
        $fullPath = $folderPath . DIRECTORY_SEPARATOR . $filename;
        if (!file_exists($fullPath)) {
            throw new \Exception('Document could not be saved.');
        }
        $mimeType = mime_content_type($fullPath);
        $fileSize = filesize($fullPath);
        $document = Document::create([
            'company_id' => $data['company_id'] ?? null,
            'scope_type' => $data['scope'],
            'category_id' => $data['category'],
            'document_name' => $data['document_name']
                ?: $file->getClientOriginalName(),
            'upload_doc' => $filename,
            'expiry_date' => $data['expiry_date'] ?? null,
            'mime_type' => $mimeType,
            'file_size' => $fileSize,
            'version_no' => 1,
            'created_by' => $user_id ?? 1,
            'updated_by' => $user_id ?? 1,
        ]);
        DB::table('egc_tool_document_versions')->insert([
            'document_id' => $document->sno,
            'version_no' => 1,
            'storage_path' => 'egpk/documents/' . $filename,
            'file_size' => $fileSize,
            'mime_type' => $mimeType,
            'uploaded_by' => $user_id ?? 1,
            'created_at' => now(),
        ]);
        return $this->ok(
            $document,
            'Document uploaded successfully.'
        );
    }

    public function version(Request $request, int $id)
    {
        $user_id = $request->user()->user_id;
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document',$id,$document->owner_user_id),403);
        $request->validate([
            'document' => ['required', 'file', 'max:51200', 'mimes:' . self::MIME]
        ]);
        
        $file = $request->file('document');
        if (!$file || !$file->isValid()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid uploaded file.'
            ], 422);
        }
        $mimeType = $file->getMimeType();
        $fileSize = $file->getSize();
        $extension = $file->getClientOriginalExtension();
        $version = (int) $document->version_no + 1;
        $folderPath = public_path('egpk/documents');
        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0755, true);
        }
        $filename = 'doc_' . uniqid() . '_' . time() . '.' . $extension;
        $file->move($folderPath, $filename);
        $path = 'egpk/documents/' . $filename;
        $fullPath = public_path($path);
        if (!file_exists($fullPath)) {
            throw new \Exception('Document could not be saved.');
        }
        DB::transaction(function () use ($document,$filename,$id,$version,$path,$mimeType,$fileSize,$user_id) {
        $document->update([
            'storage_path' => $path,
            'upload_doc' => $filename,
            'mime_type' => $mimeType,
            'file_size' => $fileSize,
            'version_no' => $version,
            'updated_by' => $user_id ?? 1,
        ]);
        DB::table('egc_tool_document_versions')->insert([
            'document_id' => $id,
            'version_no' => $version,
            'storage_path' => $path,
            'file_size' => $fileSize,
            'mime_type' => $mimeType,
            'uploaded_by' => $user_id ?? 1,
            'created_at' => now(),
        ]);
    });
        return $this->ok(
            $document->fresh(),
            'New document version uploaded.'
        );
    }

    
    public function versions(int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canReadResource('document', $id, $document->owner_user_id, $document->company_id, $document->visibility), 403);
        return $this->ok(DB::table('egc_tool_documents')->where('sno', $id)->orderByDesc('version_no')->get());
    }
    
    public function url(int $id)
    {
        $document = Document::query()
        ->select('egc_tool_documents.*')
        ->addSelect(['storage_path' => DB::table('egc_tool_document_versions')
            ->select('storage_path')
            ->whereColumn('document_id','egc_tool_documents.sno')
            ->orderByDesc('updated_at')
            ->orderByDesc('sno')
            ->limit(1),
            'version_no' => DB::table('egc_tool_document_versions')
                ->select('version_no')
                ->whereColumn('document_id','egc_tool_documents.sno')
                ->orderByDesc('updated_at')
                ->orderByDesc('sno')
                ->limit(1),
        ])
        ->where('egc_tool_documents.sno', $id)
        ->firstOrFail();  
        abort_unless($this->access->canReadResource('document',$id,$document->owner_user_id,$document->company_id,$document->visibility),403);
        $path = str_replace('\\', '/', $document->storage_path);
        $path = preg_replace('#^/?public/#', '', $path);
        $document->url = asset($path);
        return $this->ok($document);
    }
    
    public function pin(Request $request, int $id)
    {
        $user_id = $request->user()->user_id ?? 1;
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document',$id,$document->owner_user_id),403);
        $newStatus = (int) $document->is_pinned === 1 ? 0 : 1;
        $document->is_pinned = $newStatus;
        $document->updated_by = $user_id ?? 1;
        $document->save();
        return $this->ok([
            'id' => $document->sno,
            'pinned' => (int) $document->is_pinned
        ]);
    }

    public function delete(Request $request, int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document', $id, $document->owner_user_id), 403);
        $document->update(['status' => 2, 'deleted_at' => now(), 'updated_by' => $this->uid()]);
        return $this->ok(null, 'Document removed.');
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company document access is not permitted.');
    }


    public function AddCategory(Request $request)
    {

        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
           
            'category_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $category_name =$request->input('category_name');
            
            $chk = ManageCategoryModel::where('category_name', ucwords($category_name))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Category has been  already created!',
                ]);
            } else {
                
                $add_category = new ManageCategoryModel();
                $add_category->category_name = $category_name;
                $add_category->category_scope = $request->category_scope;
                
                $add_category->created_by = $request->user()->user_id ?? 1;
                $add_category->updated_by = $request->user()->user_id ?? 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Category added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Category!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

public function UpdateCategory($id, Request $request)
    {
        
    $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $category_name = $request->input('category_name');
            $upd_CategoryModel = ManageCategoryModel::where('sno', $id)->first();          

            $upd_CategoryModel->category_name = $category_name;
            $upd_CategoryModel->category_scope = $request->category_scope;
            $upd_CategoryModel->updated_by = $request->user()->user_id ?? 1;
            
            $upd_CategoryModel->update();

            if ($upd_CategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    
public function CategoryStatus($id, Request $request): JsonResponse
{
    try {

        $upd_CategoryModel = ManageCategoryModel::where('sno', $id)->first();
        if (!$upd_CategoryModel) {
            return response()->json([
                'success' => false,
                'message' => 'Category not found!'
            ], 404);
        }
        $upd_CategoryModel->status =((int) $upd_CategoryModel->status === 1) ? 0 : 1;
        $upd_CategoryModel->save();

        return response()->json([
            'success' => true,
            'message' => 'Category status updated successfully!',
            'status' => (int) $upd_CategoryModel->status
        ]);

    } catch (Throwable $e) {

        Log::error('Category status update failed.', [
            'id' => $id,
            'exception' => $e
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Could not update the Category!'
        ], 500);
    }
}
    
public function Category(Request $request): JsonResponse
{
    $validated = $request->validate([
        'page' => ['nullable', 'integer', 'min:1'],
        'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
        'search' => ['nullable', 'string', 'max:150'],
        'status' => ['nullable', 'integer'],
        'scope' => ['nullable', 'string'],
    ]);

    try {

        $page = (int) ($validated['page'] ?? 1);
        $perpage = (int) ($validated['perpage'] ?? 25);
        $search = trim((string) ($validated['search'] ?? ''));

        $name = 'category_name';

        $query = DB::table('egc_tool_manage_category')
            ->whereIn('status', [0, 1])
            ->select([
                'sno',
                'category_name',
                'category_scope',
                'status',
            ])
            ->orderBy('status')
            ->orderBy($name);
        if ($search !== '') {
            $query->where($name, 'like', "%{$search}%");
        }

        if (array_key_exists('status', $validated) && $validated['status'] !== null) {
            $query->where('status', (int) $validated['status']);
        }

        if (array_key_exists('scope', $validated) && $validated['scope'] !== null) {
            $query->where('category_scope', (string) $validated['scope']);
        }
        
        $paginated = $query->paginate(
            $perpage,
            ['*'],
            'page',
            $page
        );

        return response()->json([
            'success' => true,

            'data' => collect($paginated->items())->map(fn ($item) => [
                'id' => (int) $item->sno,
                'category_name' => (string) $item->category_name,
                'category_scope' => (string) $item->category_scope,
                'status' => (int) $item->status,
                'status_label' => (int) $item->status === 0
                    ? 'Active'
                    : 'Inactive',
            ])->values(),

            'pagination' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);

    } catch (Throwable $e) {

        Log::error('Category list loading failed.', [
            'exception' => $e,
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Category list could not be loaded.',
        ], 500);
    }
}
}
