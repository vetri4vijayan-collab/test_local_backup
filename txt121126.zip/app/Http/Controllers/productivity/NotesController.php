<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\StickyNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class NotesController extends ProductivityBaseController
{
    public function index() { return view('content.productivity.notes.index'); }

    public function data(Request $request)
    {
        $auth_user_id = $request->user()->user_id;

        $query = StickyNote::withoutGlobalScopes()->whereNull('deleted_at')->where('owner_user_id',$auth_user_id);
        if ($request->filled('status')) {
            if ($request->status === 'scheduled') {
                $query->whereIn('status', ['active', 'archived'])
                      ->whereNotNull('reminder_at');  
            } else {
                $query->where('status', $request->status);
            }
        } else {    
            $query->where(function ($q) {
                $q->whereNull('status')
                ->orWhereNotIn('status', ['trashed', 'archived']);
            });
        }
        if ($request->filled('search')) {
            $s = trim((string) $request->search);
            $query->where(function ($q) use ($s) {
                $q->where('title', 'like', "%{$s}%")
                ->orWhere('body', 'like', "%{$s}%");
            });
        }
        $perPage = (int) $request->input('per_page',$request->input('perpage', 10));
        $perPage = min(max($perPage, 10), 100);
        $rows = $query
            ->orderByDesc('is_pinned')
            ->orderByDesc('updated_at')
            ->paginate($perPage);
        return $this->ok([
            'rows' => $rows
        ]);
    }

    public function show(Request $request, int $id)
    {
        $note = StickyNote::whereNull('deleted_at')->whereKey($id)->firstOrFail();
        abort_unless($this->access->canReadResource('note', $id, $note->owner_user_id, $note->company_id, 'Company'), 403);
        $note->reminder_at = $note->reminder_at ? date('d-M-Y g:i A', strtotime($note->reminder_at)) : null;
        return $this->ok($note);
    }
    
    public function store(Request $request)
    {
        $user_id = $request->user()->user_id;
        $noteType = $request->input('note_type', 'text');
        $reminderAt = $request->input('reminder_at');

        if ($noteType === 'checklist') {
            $checklist = $request->input('checklist', []);
            if (is_string($checklist)) {
                $checklist = json_decode($checklist, true);
            }
            if (!is_array($checklist)) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Invalid checklist data'
                ], 422);
            }
            $body = json_encode(
                array_values($checklist),
                JSON_UNESCAPED_UNICODE
            );
            } else {
                $body = $request->input('body', '');
            }
            try {
                $add_notes = new StickyNote();
                $add_notes->title = $request->input('title');
                $add_notes->body = $body ?? '';
                $add_notes->color = $request->input('color', '#fff8c7');
                $add_notes->is_pinned = 0;
                $add_notes->note_type = $noteType ?? 'text';
                $add_notes->reminder_at = !empty($reminderAt) ? date('Y-m-d H:i:s', strtotime($reminderAt)): null;
                $add_notes->owner_user_id = $user_id ?? 0;
                $add_notes->created_by = $user_id ?? 1;
                $add_notes->updated_by = $user_id ?? 1;
                $add_notes->save();
                return response()->json([
                    'status' => 200,
                    'message' => 'Notes added successfully!',
                    'data' => $add_notes
                ], 200);

            } catch (\Exception $e) {
                return response()->json([
                    'status' => 500,
                    'message' => 'Could not add the Notes!',
                    'error' => $e->getMessage()
                ], 500);
            }
    }

    public function update(Request $request, int $id)
    {
        $user_id = $request->user()->user_id;
        $noteType = $request->input('note_type', 'text');
        $reminderAt = $request->input('reminder_at');
        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'body' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->errors(),
                'data' => null,
            ], 200);
        }
        $update_notes = StickyNote::find($id);
        if (!$update_notes) {
            return response()->json([
                'status' => 404,
                'message' => 'Notes not found',
                'data' => null,
            ], 404);
        }
        try {
            if ($noteType === 'checklist') {
                $checklist = $request->input('checklist', []);
                if (is_string($checklist)) {
                    $checklist = json_decode($checklist, true);
                }
                if (!is_array($checklist)) {
                    return response()->json([
                        'status' => 422,
                        'message' => 'Invalid checklist data'
                    ], 422);
                }
                $body = json_encode(
                    array_values($checklist),
                    JSON_UNESCAPED_UNICODE
                );
            } else {
                $body = $request->input('body', '');
            }
            $update_notes->title = $request->input('title');
            $update_notes->body = $body ?? '';
            $update_notes->color = $request->input('color', '#fff8c7');
            $update_notes->note_type = $noteType ?? 'text';
            $update_notes->reminder_at = !empty($reminderAt) ? date('Y-m-d H:i:s', strtotime($reminderAt)) : null;
            $update_notes->is_pinned = $request->input('is_pinned', $update_notes->is_pinned);
            $update_notes->updated_by = $user_id;
            $update_notes->save();
            return response()->json([
                'status' => 200,
                'message' => 'Notes updated successfully!',
                'data' => $update_notes
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Could not update the Notes!',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    
    public function action(Request $request, int $id)
    {
        $user_id = $request->user()->user_id;
        $note = StickyNote::findOrFail($id);
        abort_unless(
            $this->access->canManageResource('note',$id,$note->owner_user_id),403);

        $data = $request->validate([
            'action' => ['required','in:pin,unpin,archive,trash,restore,update_checklist'],
            'body' => ['required_if:action,update_checklist','nullable','json'],
        ]);
        switch ($data['action']) {
            case 'pin':
                $note->is_pinned = 1;
                break;
            case 'unpin':
                $note->is_pinned = 0;
                break;
            case 'archive':
                $note->status = 'archived';
                break;
            case 'trash':
                $note->status = 'trashed';
                break;
            case 'restore':
                $note->status = 'active';
                break;
            case 'update_checklist':
                if ($note->note_type !== 'checklist') {
                    abort(422, 'This note is not a checklist.');
                }
                $note->body = $data['body'];
                break;
        }
        $note->updated_by = $user_id ?? 1;
        $note->save();
        $note->refresh();
        return $this->ok($note, 'Note updated.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([          
            'title' => ['nullable', 'string', 'max:220'],
            'body' => ['nullable', 'string', 'max:20000'],
            'color' => ['nullable', 'string', 'max:20'],        
            'reminder_at' => ['nullable', 'date'],
            'checklist' => ['nullable', 'array'],     
            'status' => ['nullable', 'in:active,archived,trashed'],
            'is_pinned' => ['nullable', 'boolean'],
        ]);
    }
}
