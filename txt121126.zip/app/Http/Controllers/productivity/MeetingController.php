<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class MeetingController extends ProductivityBaseController
{
    public function index()
    {
        return view('content.productivity.meetings.index', [
            'canManageMeetingSettings' => $this->canManageSettings(request()),
        ]);
    }

    /** Shared lookups for the scheduler and the category/team management modals. */
    public function lookups(Request $request): JsonResponse
    {
        $companyId = $this->lookupCompanyId($request);

        $categoryQuery = DB::table('egc_tool_meeting_categories as c')
            ->whereNull('c.deleted_at')->where('c.status', 0)
            ->orderBy('c.sort_order')->orderBy('c.category_name');
        $this->applyCompanyOrGlobalScope($categoryQuery, $companyId, 'c.company_id');
        $categories = $categoryQuery->get(['c.sno', 'c.company_id', 'c.category_name', 'c.color', 'c.description']);

        $teamQuery = DB::table('egc_tool_meeting_teams as t')
            ->whereNull('t.deleted_at')->where('t.status', 0)
            ->orderBy('t.team_name');
        $this->applyCompanyOrGlobalScope($teamQuery, $companyId, 't.company_id');
        $teams = $teamQuery->select('t.sno', 't.company_id', 't.team_name', 't.description')
            ->selectSub(function ($q) {
                $q->from('egc_tool_meeting_team_members as tm')
                    ->selectRaw('COUNT(*)')->whereColumn('tm.team_id', 't.sno');
            }, 'member_count')->get();

        $departmentQuery = DB::table('egc_department as d')
            ->where('d.status', 0)->where('d.sno', '>', 0)
            ->orderBy('d.department_name');
        if (!$this->access->isGroupAdmin($request) && $companyId !== null) {
            $departmentQuery->where('d.company_id', $companyId);
        } elseif ($this->access->isGroupAdmin($request) && $request->filled('company_id') && $request->input('company_id') !== 'all') {
            $departmentQuery->where('d.company_id', (int) $request->input('company_id'));
        }
        $departments = $departmentQuery->get(['d.sno', 'd.company_id', 'd.department_name']);

        $staffQuery = DB::table('egc_staff as s')
            ->leftJoin('egc_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('egc_user_role as r', 'r.sno', '=', 's.role_id')
            ->where('s.status', 0)->where('s.sno', '>', 0)
            ->orderBy('s.staff_name');
        if (!$this->access->isGroupAdmin($request) && $companyId !== null) {
            $staffQuery->where('s.company_id', $companyId);
        } elseif ($this->access->isGroupAdmin($request) && $request->filled('company_id') && $request->input('company_id') !== 'all') {
            $staffQuery->where('s.company_id', (int) $request->input('company_id'));
        }
        if ($request->filled('staff_search')) {
            $term = trim((string) $request->input('staff_search'));
            $staffQuery->where(function ($q) use ($term) {
                $q->where('s.staff_name', 'like', "%{$term}%")
                    ->orWhere('s.staff_id', 'like', "%{$term}%")
                    ->orWhere('s.email_id', 'like', "%{$term}%");
            });
        }
        $staff = $staffQuery->limit(2500)->get([
            's.sno', 's.staff_name', 's.staff_id', 's.email_id', 's.company_id', 's.department_id',
            'd.department_name', 'r.role_name',
        ]);

        $companies = collect();
        if ($this->access->isGroupAdmin($request)) {
            $companies = DB::table('egc_company')->where('status', 0)->orderBy('company_name')->get(['sno', 'company_name']);
        }

        return $this->ok([
            'categories' => $categories,
            'teams' => $teams,
            'departments' => $departments,
            'staff' => $staff,
            'companies' => $companies,
            'current_user_id' => $this->uid(),
            'current_company_id' => $this->cid(),
            'can_manage_settings' => $this->canManageSettings($request),
            'is_group_admin' => $this->access->isGroupAdmin($request),
        ]);
    }

    /** Data for the right-side agenda panels. */
    public function dashboard(Request $request): JsonResponse
    {
        $uid = $this->uid();
        $todayStart = now()->startOfDay();
        $todayEnd = now()->endOfDay();

        $pending = DB::table('egc_tool_meeting_participants as mp')
            ->join('egc_tool_meetings as m', 'm.sno', '=', 'mp.meeting_id')
            ->leftJoin('egc_tool_meeting_categories as c', 'c.sno', '=', 'm.category_id')
            ->where('mp.user_id', $uid)
            ->whereIn('mp.rsvp', ['pending', 'tentative'])
            ->whereNull('m.deleted_at')->whereNotIn(DB::raw('LOWER(m.status)'), ['cancelled', 'completed'])
            ->where('m.end_at', '>=', now())
            ->orderBy('m.start_at')->limit(8)
            ->select(['m.sno', 'm.title', 'm.start_at', 'm.end_at', 'm.category_id', 'c.category_name', 'c.color', 'mp.rsvp'])
            ->get();

        $upcoming = $this->base($request)
            ->whereBetween('m.start_at', [$todayStart, $todayEnd])
            ->whereNotIn(DB::raw('LOWER(m.status)'), ['cancelled', 'completed'])
            ->orderBy('m.start_at')->limit(12)
            ->get($this->meetingSelectColumns());

        $stats = [
            'today' => (clone $this->base($request))->whereBetween('m.start_at', [$todayStart, $todayEnd])->whereNotIn(DB::raw('LOWER(m.status)'), ['cancelled'])->count(),
            'upcoming' => (clone $this->base($request))->where('m.start_at', '>=', now())->whereNotIn(DB::raw('LOWER(m.status)'), ['cancelled', 'completed'])->count(),
            'pending_rsvp' => $pending->count(),
            'in_progress' => (clone $this->base($request))->whereRaw('LOWER(m.status) = ?', ['in progress'])->count(),
        ];

        return $this->ok(['pending_rsvp' => $pending, 'upcoming_today' => $upcoming, 'stats' => $stats]);
    }

    public function data(Request $request): JsonResponse
    {
        $query = $this->base($request);
        $this->applyCalendarScope($query, $request);

        if ($request->filled('status')) {
            $status = strtolower(trim((string) $request->input('status')));
            $query->whereRaw('LOWER(m.status) = ?', [$status]);
        }
        if ($request->filled('category_id') && $request->input('category_id') !== 'all') {
            $query->where('m.category_id', (int) $request->input('category_id'));
        }
        if ($request->filled('search')) {
            $term = trim((string) $request->input('search'));
            $query->where(function ($q) use ($term) {
                $q->where('m.title', 'like', "%{$term}%")
                    ->orWhere('m.agenda', 'like', "%{$term}%")
                    ->orWhere('m.venue', 'like', "%{$term}%")
                    ->orWhere('m.meeting_url', 'like', "%{$term}%")
                    ->orWhere('s.staff_name', 'like', "%{$term}%")
                    ->orWhere('c.category_name', 'like', "%{$term}%");
            });
        }
        if ($request->filled('start') && $request->filled('end')) {
            $start = Carbon::parse($request->input('start'))->startOfDay();
            $end = Carbon::parse($request->input('end'))->endOfDay();
            $query->where('m.start_at', '<=', $end)->where('m.end_at', '>=', $start);
        }

        $perPage = min(max((int) $request->input('per_page', 30), 10), 100);
        $rows = $query->orderBy('m.start_at')->paginate($perPage);
        return $this->ok(['rows' => $rows]);
    }

    public function calendar(Request $request): JsonResponse
    {
        $request->validate(['start' => ['required', 'date'], 'end' => ['required', 'date', 'after_or_equal:start']]);
        $query = $this->base($request);
        $this->applyCalendarScope($query, $request);
        $query->where('m.start_at', '<=', Carbon::parse($request->end)->endOfDay())
            ->where('m.end_at', '>=', Carbon::parse($request->start)->startOfDay());
        if ($request->filled('category_id') && $request->input('category_id') !== 'all') {
            $query->where('m.category_id', (int) $request->input('category_id'));
        }
        if ($request->filled('search')) {
            $term = trim((string) $request->input('search'));
            $query->where(function ($q) use ($term) {
                $q->where('m.title', 'like', "%{$term}%")
                    ->orWhere('m.agenda', 'like', "%{$term}%")
                    ->orWhere('m.venue', 'like', "%{$term}%")
                    ->orWhere('m.meeting_url', 'like', "%{$term}%")
                    ->orWhere('s.staff_name', 'like', "%{$term}%")
                    ->orWhere('c.category_name', 'like', "%{$term}%");
            });
        }
        return $this->ok($query->orderBy('m.start_at')->get($this->meetingSelectColumns()));
    }

    public function externalEvents(Request $request): JsonResponse
    {
        $request->validate(['start' => ['nullable', 'date'], 'end' => ['nullable', 'date', 'after_or_equal:start']]);
        $query = DB::table('egc_tool_events as e')->whereNull('e.deleted_at');
        $this->access->applyReadableQueryScope($query, 'event', 'e.sno', 'e.owner_user_id', 'e.company_id', 'e.visibility', $request);
        if (!$this->access->isGroupAdmin($request) && !$this->access->isAuditor($request) && $this->cid() !== null) {
            $query->where(function ($q) {
                $q->whereNull('e.company_id')->orWhere('e.company_id', $this->cid());
            });
        }
        if ($request->filled('start')) $query->where('e.event_date', '>=', Carbon::parse($request->start)->toDateString());
        if ($request->filled('end')) $query->where('e.event_date', '<=', Carbon::parse($request->end)->toDateString());
        return $this->ok($query->orderBy('e.event_date')->orderBy('e.event_time')->limit(300)->get([
            'e.sno', 'e.event_name', 'e.organisation', 'e.event_type', 'e.event_date', 'e.event_time',
            'e.venue', 'e.online_link', 'e.status', 'e.visibility',
        ]));
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $meeting = $this->base($request)->where('m.sno', $id)->first($this->meetingSelectColumns());
        abort_unless($meeting, 404, 'Meeting not found or you do not have access to it.');

        $participants = DB::table('egc_tool_meeting_participants as mp')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'mp.user_id')
            ->where('mp.meeting_id', $id)
            ->orderBy('s.staff_name')
            ->get([
                'mp.sno', 'mp.user_id', 'mp.display_name', 'mp.email', 'mp.rsvp', 'mp.created_at',
                DB::raw("COALESCE(s.staff_name, mp.display_name, 'External participant') as staff_name"),
                's.staff_image', 's.email_id',
            ]);

        $reschedules = DB::table('egc_tool_meeting_reschedules as mr')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'mr.changed_by')
            ->where('mr.meeting_id', $id)->orderByDesc('mr.created_at')
            ->get(['mr.*', 's.staff_name as changed_by_name']);

        $teams = DB::table('egc_tool_meeting_team_map as mt')
            ->join('egc_tool_meeting_teams as t', 't.sno', '=', 'mt.team_id')
            ->where('mt.meeting_id', $id)->get(['t.sno', 't.team_name']);
        $departments = DB::table('egc_tool_meeting_department_map as md')
            ->join('egc_department as d', 'd.sno', '=', 'md.department_id')
            ->where('md.meeting_id', $id)->get(['d.sno', 'd.department_name']);
        $attachments = DB::table('egc_tool_meeting_attachments')->where('meeting_id', $id)
            ->orderBy('created_at')->get(['sno', 'original_name', 'mime_type', 'file_size', 'created_at'])
            ->map(function ($item) use ($id) {
                $item->download_url = route('productivity.meetings.attachment.download', ['id' => $id, 'attachmentId' => $item->sno]);
                return $item;
            });

        $rsvpCounts = [
            'accepted' => $participants->where('rsvp', 'accepted')->count(),
            'declined' => $participants->where('rsvp', 'declined')->count(),
            'tentative' => $participants->where('rsvp', 'tentative')->count(),
            'pending' => $participants->where('rsvp', 'pending')->count(),
        ];
        return $this->ok([
            'meeting' => $meeting,
            'participants' => $participants,
            'reschedules' => $reschedules,
            'teams' => $teams,
            'departments' => $departments,
            'attachments' => $attachments,
            'rsvp_counts' => $rsvpCounts,
            'can_manage' => $this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request),
            'my_rsvp' => $participants->firstWhere('user_id', $this->uid())?->rsvp,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);
        $data = $this->validateMeeting($request);
        $companyId = $this->resolveMeetingCompany($request, $data['company_id'] ?? null);
        $category = $this->resolveCategory($request, $data['category_id'] ?? null, $companyId);
        $data['category'] = $category?->category_name ?? ($data['category'] ?? null);
        $participantIds = $this->resolveParticipantIds($request, $data, $companyId);
        $this->assertParticipantsInCompany($participantIds, $companyId);
        $this->conflictCheck($participantIds, $data['start_at'], $data['end_at']);

        $meetingId = DB::transaction(function () use ($request, $data, $companyId, $participantIds) {
            $id = DB::table('egc_tool_meetings')->insertGetId([
                'company_id' => $companyId,
                'owner_user_id' => $this->uid(),
                'visibility' => $data['visibility'],
                'title' => trim($data['title']),
                'category' => $data['category'] ?? null,
                'category_id' => $data['category_id'] ?? null,
                'start_at' => Carbon::parse($data['start_at'])->format('Y-m-d H:i:s'),
                'end_at' => Carbon::parse($data['end_at'])->format('Y-m-d H:i:s'),
                'venue' => $data['venue'] ?? null,
                'meeting_url' => $data['meeting_url'] ?? null,
                'agenda' => $data['agenda'] ?? null,
                'reminder_minutes' => $data['reminder_minutes'] ?? 30,
                'status' => $data['status'] ?? 'Scheduled',
                'notes' => $data['notes'] ?? null,
                'created_by' => $this->uid(), 'updated_by' => $this->uid(),
                'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->syncParticipants($id, $participantIds, false);
            $this->syncMeetingGroups($id, $data['team_ids'] ?? [], $data['department_ids'] ?? []);
            return $id;
        });

        $this->storeAttachments($request, $meetingId);
        $this->notifyParticipants($meetingId, $participantIds, 'meeting_invitation', 'Meeting invitation', 'You have been invited to a meeting: ' . trim($data['title']));
        $this->audit($request, 'Meetings', 'created', 'meeting', $meetingId, null, ['title' => $data['title'], 'participants' => $participantIds]);
        return $this->ok(['id' => $meetingId], 'Meeting scheduled and invitations added.');
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $meeting = DB::table('egc_tool_meetings')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($meeting, 404);
        abort_unless($this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request), 403);

        $data = $this->validateMeeting($request);
        $companyId = $this->resolveMeetingCompany($request, $data['company_id'] ?? $meeting->company_id);
        $category = $this->resolveCategory($request, $data['category_id'] ?? null, $companyId);
        $data['category'] = $category?->category_name ?? ($data['category'] ?? null);
        $participantIds = $this->resolveParticipantIds($request, $data, $companyId);
        $this->assertParticipantsInCompany($participantIds, $companyId);
        $this->conflictCheck($participantIds, $data['start_at'], $data['end_at'], $id);

        DB::transaction(function () use ($request, $data, $companyId, $participantIds, $id) {
            DB::table('egc_tool_meetings')->where('sno', $id)->update([
                'company_id' => $companyId,
                'visibility' => $data['visibility'],
                'title' => trim($data['title']), 'category' => $data['category'] ?? null,
                'category_id' => $data['category_id'] ?? null,
                'start_at' => Carbon::parse($data['start_at'])->format('Y-m-d H:i:s'),
                'end_at' => Carbon::parse($data['end_at'])->format('Y-m-d H:i:s'),
                'venue' => $data['venue'] ?? null, 'meeting_url' => $data['meeting_url'] ?? null,
                'agenda' => $data['agenda'] ?? null, 'reminder_minutes' => $data['reminder_minutes'] ?? 30,
                'status' => $data['status'] ?? 'Scheduled', 'notes' => $data['notes'] ?? null,
                'reminder_sent_at' => null, 'updated_by' => $this->uid(), 'updated_at' => now(),
            ]);
            // Existing participants retain their RSVP during normal edits. New invitees are pending.
            $this->syncParticipants($id, $participantIds, false);
            $this->syncMeetingGroups($id, $data['team_ids'] ?? [], $data['department_ids'] ?? []);
        });

        $this->storeAttachments($request, $id);
        $this->notifyParticipants($id, $participantIds, 'meeting_updated', 'Meeting updated', 'Meeting details were updated: ' . trim($data['title']));
        $this->audit($request, 'Meetings', 'updated', 'meeting', $id, $meeting, ['title' => $data['title'], 'participants' => $participantIds]);
        return $this->ok(['id' => $id], 'Meeting updated successfully.');
    }

    public function reschedule(Request $request, int $id): JsonResponse
    {
        $meeting = DB::table('egc_tool_meetings')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($meeting, 404);
        abort_unless($this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request), 403);
        $data = $request->validate([
            'start_at' => ['required', 'date'],
            'end_at' => ['required', 'date', 'after:start_at'],
            'reason' => ['required', 'string', 'max:500'],
        ]);
        $participantIds = DB::table('egc_tool_meeting_participants')->where('meeting_id', $id)->whereNotNull('user_id')->pluck('user_id')->map(fn ($v) => (int) $v)->all();
        $this->conflictCheck($participantIds, $data['start_at'], $data['end_at'], $id);

        DB::transaction(function () use ($data, $meeting, $id) {
            DB::table('egc_tool_meeting_reschedules')->insert([
                'meeting_id' => $id,
                'old_start_at' => $meeting->start_at, 'old_end_at' => $meeting->end_at,
                'new_start_at' => Carbon::parse($data['start_at'])->format('Y-m-d H:i:s'),
                'new_end_at' => Carbon::parse($data['end_at'])->format('Y-m-d H:i:s'),
                'reason' => trim($data['reason']), 'changed_by' => $this->uid(), 'created_at' => now(),
            ]);
            DB::table('egc_tool_meetings')->where('sno', $id)->update([
                'start_at' => Carbon::parse($data['start_at'])->format('Y-m-d H:i:s'),
                'end_at' => Carbon::parse($data['end_at'])->format('Y-m-d H:i:s'),
                'status' => 'Scheduled', 'reminder_sent_at' => null, 'updated_by' => $this->uid(), 'updated_at' => now(),
            ]);
            // Rescheduling invalidates earlier responses; owner remains accepted.
            DB::table('egc_tool_meeting_participants')->where('meeting_id', $id)->update([
                'rsvp' => 'pending', 'updated_at' => now(),
            ]);
            DB::table('egc_tool_meeting_participants')->where('meeting_id', $id)->where('user_id', $this->uid())->update([
                'rsvp' => 'accepted', 'updated_at' => now(),
            ]);
        });

        $this->notifyParticipants($id, $participantIds, 'meeting_rescheduled', 'Meeting rescheduled', 'The meeting has been rescheduled. Please review the new time.');
        $this->audit($request, 'Meetings', 'rescheduled', 'meeting', $id, ['start_at' => $meeting->start_at, 'end_at' => $meeting->end_at], $data);
        return $this->ok(['id' => $id], 'Meeting rescheduled. Participants were notified and their previous RSVPs were reset.');
    }

    public function rsvp(Request $request, int $id): JsonResponse
    {
        $meeting = $this->base($request)->where('m.sno', $id)->first(['m.sno', 'm.owner_user_id', 'm.title']);
        abort_unless($meeting, 404);
        $data = $request->validate(['rsvp' => ['required', 'in:accepted,declined,tentative']]);
        $participant = DB::table('egc_tool_meeting_participants')->where('meeting_id', $id)->where('user_id', $this->uid())->first();
        abort_unless($participant || (int) $meeting->owner_user_id === $this->uid(), 403, 'Only invited participants can respond to this meeting.');
        DB::table('egc_tool_meeting_participants')->updateOrInsert(
            ['meeting_id' => $id, 'user_id' => $this->uid()],
            ['rsvp' => $data['rsvp'], 'updated_at' => now(), 'created_at' => $participant->created_at ?? now()]
        );
        return $this->ok(['rsvp' => $data['rsvp']], 'Your RSVP has been updated.');
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $meeting = DB::table('egc_tool_meetings')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($meeting, 404);
        abort_unless($this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request), 403);
        $data = $request->validate(['status' => ['required', 'in:Scheduled,In Progress,Completed']]);
        DB::table('egc_tool_meetings')->where('sno', $id)->update([
            'status' => $data['status'],
            'reminder_sent_at' => $data['status'] === 'Scheduled' ? null : DB::raw('reminder_sent_at'),
            'updated_by' => $this->uid(), 'updated_at' => now(),
        ]);
        $this->audit($request, 'Meetings', 'status_changed', 'meeting', $id, ['status' => $meeting->status], $data);
        return $this->ok(['status' => $data['status']], 'Meeting status updated.');
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $meeting = DB::table('egc_tool_meetings')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($meeting, 404);
        abort_unless($this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request), 403);
        $data = $request->validate(['reason' => ['required', 'string', 'max:500']]);
        DB::table('egc_tool_meetings')->where('sno', $id)->update([
            'status' => 'Cancelled', 'cancellation_reason' => trim($data['reason']),
            'updated_by' => $this->uid(), 'updated_at' => now(),
        ]);
        $participantIds = DB::table('egc_tool_meeting_participants')->where('meeting_id', $id)->whereNotNull('user_id')->pluck('user_id')->map(fn ($v) => (int) $v)->all();
        $this->notifyParticipants($id, $participantIds, 'meeting_cancelled', 'Meeting cancelled', 'The meeting has been cancelled: ' . trim($meeting->title));
        $this->audit($request, 'Meetings', 'cancelled', 'meeting', $id, ['status' => $meeting->status], $data);
        return $this->ok(null, 'Meeting cancelled. Participants were notified.');
    }

    /** Retained for compatibility with the original DELETE endpoint. */
    public function delete(Request $request, int $id): JsonResponse
    {
        $meeting = DB::table('egc_tool_meetings')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($meeting, 404);
        abort_unless($this->access->canManageResource('meeting', $id, (int) $meeting->owner_user_id, $request), 403);
        DB::table('egc_tool_meetings')->where('sno', $id)->update([
            'deleted_at' => now(), 'status' => 'Cancelled', 'updated_by' => $this->uid(), 'updated_at' => now(),
        ]);
        $this->audit($request, 'Meetings', 'deleted', 'meeting', $id, null, ['deleted_at' => now()]);
        return $this->ok(null, 'Meeting removed from active lists.');
    }

    public function downloadAttachment(Request $request, int $id, int $attachmentId)
    {
        $meeting = $this->base($request)->where('m.sno', $id)->first(['m.sno']);
        abort_unless($meeting, 404);
        $attachment = DB::table('egc_tool_meeting_attachments')->where('sno', $attachmentId)->where('meeting_id', $id)->first();
        abort_unless($attachment && Storage::disk('local')->exists($attachment->storage_path), 404);
        return Storage::disk('local')->download($attachment->storage_path, $attachment->original_name, [
            'Content-Type' => $attachment->mime_type ?: 'application/octet-stream',
        ]);
    }

    /* ---------------- Category management ---------------- */

    public function categories(Request $request): JsonResponse
    {
        $query = DB::table('egc_tool_meeting_categories as c')->whereNull('c.deleted_at')->orderBy('c.sort_order')->orderBy('c.category_name');
        $this->applySettingsCompanyScope($query, $request, 'c.company_id');
        return $this->ok([
            'categories' => $query->select('c.*')->get(),
            'can_manage' => $this->canManageSettings($request),
            'is_group_admin' => $this->access->isGroupAdmin($request),
        ]);
    }

    public function storeCategory(Request $request): JsonResponse
    {
        $this->assertSettingsManager($request);
        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'description' => ['nullable', 'string', 'max:500'],
            'company_id' => ['nullable', 'integer', 'min:1'],
        ]);
        $companyId = $this->resolveSettingsCompany($request, $data['company_id'] ?? null);
        $this->assertUniqueSettingName('egc_tool_meeting_categories', 'category_name', $data['category_name'], $companyId);
        $id = DB::table('egc_tool_meeting_categories')->insertGetId([
            'company_id' => $companyId, 'category_name' => trim($data['category_name']),
            'color' => $data['color'], 'description' => $data['description'] ?? null,
            'created_by' => $this->uid(), 'updated_by' => $this->uid(), 'created_at' => now(), 'updated_at' => now(),
        ]);
        $this->audit($request, 'Meetings', 'category_created', 'meeting_category', $id, null, $data);
        return $this->ok(['id' => $id], 'Meeting category created.');
    }

    public function updateCategory(Request $request, int $id): JsonResponse
    {
        $this->assertSettingsManager($request);
        $category = DB::table('egc_tool_meeting_categories')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($category, 404);
        $this->assertSettingsScope($request, $category->company_id);
        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'description' => ['nullable', 'string', 'max:500'],
        ]);
        $this->assertUniqueSettingName('egc_tool_meeting_categories', 'category_name', $data['category_name'], $category->company_id, $id);
        DB::table('egc_tool_meeting_categories')->where('sno', $id)->update([
            'category_name' => trim($data['category_name']), 'color' => $data['color'],
            'description' => $data['description'] ?? null, 'updated_by' => $this->uid(), 'updated_at' => now(),
        ]);
        DB::table('egc_tool_meetings')->where('category_id', $id)->update(['category' => trim($data['category_name']), 'updated_at' => now()]);
        $this->audit($request, 'Meetings', 'category_updated', 'meeting_category', $id, $category, $data);
        return $this->ok(['id' => $id], 'Meeting category updated.');
    }

    public function deleteCategory(Request $request, int $id): JsonResponse
    {
        $this->assertSettingsManager($request);
        $category = DB::table('egc_tool_meeting_categories')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($category, 404);
        $this->assertSettingsScope($request, $category->company_id);
        DB::transaction(function () use ($id, $category) {
            DB::table('egc_tool_meetings')->where('category_id', $id)->update([
                'category' => $category->category_name, 'category_id' => null, 'updated_at' => now(),
            ]);
            DB::table('egc_tool_meeting_categories')->where('sno', $id)->update([
                'status' => 1, 'deleted_at' => now(), 'updated_by' => $this->uid(), 'updated_at' => now(),
            ]);
        });
        $this->audit($request, 'Meetings', 'category_deleted', 'meeting_category', $id, $category, null);
        return $this->ok(null, 'Meeting category removed. Existing meetings retain the category label.');
    }

    /* ---------------- Team management ---------------- */

    public function teams(Request $request): JsonResponse
    {
        $query = DB::table('egc_tool_meeting_teams as t')->whereNull('t.deleted_at')->orderBy('t.team_name');
        $this->applySettingsCompanyScope($query, $request, 't.company_id');
        $rows = $query->select('t.*')->selectSub(function ($q) {
            $q->from('egc_tool_meeting_team_members as tm')->selectRaw('COUNT(*)')->whereColumn('tm.team_id', 't.sno');
        }, 'member_count')->get();
        $members = DB::table('egc_tool_meeting_team_members as tm')
            ->join('egc_staff as s', 's.sno', '=', 'tm.user_id')
            ->whereIn('tm.team_id', $rows->pluck('sno')->all())
            ->get(['tm.team_id', 's.sno as user_id', 's.staff_name', 's.email_id'])
            ->groupBy('team_id');
        $rows->each(function ($team) use ($members) { $team->members = $members->get($team->sno, collect())->values(); });
        return $this->ok(['teams' => $rows, 'can_manage' => $this->canManageSettings($request), 'is_group_admin' => $this->access->isGroupAdmin($request)]);
    }

    public function storeTeam(Request $request): JsonResponse
    {
        $this->assertSettingsManager($request);
        $data = $request->validate([
            'team_name' => ['required', 'string', 'max:160'],
            'description' => ['nullable', 'string', 'max:500'],
            'company_id' => ['nullable', 'integer', 'min:1'],
            'member_ids' => ['nullable', 'array', 'max:500'],
            'member_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
        ]);
        $companyId = $this->resolveSettingsCompany($request, $data['company_id'] ?? null);
        $this->assertUniqueSettingName('egc_tool_meeting_teams', 'team_name', $data['team_name'], $companyId);
        $memberIds = $this->validatedStaffIds($data['member_ids'] ?? [], $companyId);
        $id = DB::transaction(function () use ($data, $companyId, $memberIds) {
            $id = DB::table('egc_tool_meeting_teams')->insertGetId([
                'company_id' => $companyId, 'team_name' => trim($data['team_name']),
                'description' => $data['description'] ?? null, 'created_by' => $this->uid(),
                'updated_by' => $this->uid(), 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->syncTeamMembers($id, $memberIds);
            return $id;
        });
        $this->audit($request, 'Meetings', 'team_created', 'meeting_team', $id, null, ['team_name' => $data['team_name'], 'members' => $memberIds]);
        return $this->ok(['id' => $id], 'Meeting team created.');
    }

    public function updateTeam(Request $request, int $id): JsonResponse
    {
        $this->assertSettingsManager($request);
        $team = DB::table('egc_tool_meeting_teams')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($team, 404);
        $this->assertSettingsScope($request, $team->company_id);
        $data = $request->validate([
            'team_name' => ['required', 'string', 'max:160'],
            'description' => ['nullable', 'string', 'max:500'],
            'member_ids' => ['nullable', 'array', 'max:500'],
            'member_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
        ]);
        $this->assertUniqueSettingName('egc_tool_meeting_teams', 'team_name', $data['team_name'], $team->company_id, $id);
        $memberIds = $this->validatedStaffIds($data['member_ids'] ?? [], $team->company_id);
        DB::transaction(function () use ($data, $id, $memberIds) {
            DB::table('egc_tool_meeting_teams')->where('sno', $id)->update([
                'team_name' => trim($data['team_name']), 'description' => $data['description'] ?? null,
                'updated_by' => $this->uid(), 'updated_at' => now(),
            ]);
            $this->syncTeamMembers($id, $memberIds);
        });
        $this->audit($request, 'Meetings', 'team_updated', 'meeting_team', $id, $team, ['team_name' => $data['team_name'], 'members' => $memberIds]);
        return $this->ok(['id' => $id], 'Meeting team updated.');
    }

    public function deleteTeam(Request $request, int $id): JsonResponse
    {
        $this->assertSettingsManager($request);
        $team = DB::table('egc_tool_meeting_teams')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($team, 404);
        $this->assertSettingsScope($request, $team->company_id);
        DB::table('egc_tool_meeting_teams')->where('sno', $id)->update([
            'status' => 1, 'deleted_at' => now(), 'updated_by' => $this->uid(), 'updated_at' => now(),
        ]);
        $this->audit($request, 'Meetings', 'team_deleted', 'meeting_team', $id, $team, null);
        return $this->ok(null, 'Meeting team deactivated. Existing meeting records are retained.');
    }

    /* ---------------- Internal helpers ---------------- */

    private function base(Request $request)
    {
        $query = DB::table('egc_tool_meetings as m')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'm.owner_user_id')
            ->leftJoin('egc_tool_meeting_categories as c', 'c.sno', '=', 'm.category_id')
            ->whereNull('m.deleted_at');
        $uid = $this->uid();
        $companyId = $this->cid();

        if (!$this->access->isSuper($request) && !$this->access->isAuditor($request)) {
            $role = $this->access->role($request);
            $query->where(function ($scope) use ($uid, $companyId, $role) {
                $scope->where('m.owner_user_id', $uid)
                    ->orWhereExists(function ($participant) use ($uid) {
                        $participant->selectRaw('1')->from('egc_tool_meeting_participants as mp')
                            ->whereColumn('mp.meeting_id', 'm.sno')->where('mp.user_id', $uid);
                    })
                    ->orWhereExists(function ($team) use ($uid) {
                        $team->selectRaw('1')->from('egc_tool_meeting_team_map as mt')
                            ->join('egc_tool_meeting_team_members as tm', 'tm.team_id', '=', 'mt.team_id')
                            ->whereColumn('mt.meeting_id', 'm.sno')->where('tm.user_id', $uid);
                    })
                    ->orWhereExists(function ($grant) use ($uid, $companyId, $role) {
                        $grant->selectRaw('1')->from('egc_tool_share_grants as sg')
                            ->where('sg.resource_type', 'meeting')->whereColumn('sg.resource_id', 'm.sno')
                            ->where('sg.status', 'active')
                            ->where(function ($grantee) use ($uid, $companyId, $role) {
                                $grantee->where(fn ($q) => $q->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                                    ->orWhere(fn ($q) => $q->where('sg.grantee_type', 'role')->where('sg.grantee_id', $role))
                                    ->orWhere(fn ($q) => $q->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'))
                                    ->when($companyId !== null, fn ($q) => $q->orWhere(fn ($x) => $x->where('sg.grantee_type', 'company')->where('sg.grantee_id', (string) $companyId)));
                            })
                            ->where(fn ($expiry) => $expiry->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
                    });

                if ($companyId !== null) {
                    $scope->orWhere(function ($company) use ($companyId) {
                        $company->where(function ($specific) use ($companyId) {
                            $specific->whereIn('m.visibility', ['Company', 'Group'])->where('m.company_id', $companyId);
                        })->orWhere(function ($globalGroup) {
                            $globalGroup->where('m.visibility', 'Group')->whereNull('m.company_id');
                        });
                    });
                } else {
                    $scope->orWhere(function ($globalGroup) {
                        $globalGroup->where('m.visibility', 'Group')->whereNull('m.company_id');
                    });
                }
            });
            if ($companyId !== null) {
                $query->where(function ($company) use ($companyId) {
                    $company->whereNull('m.company_id')->orWhere('m.company_id', $companyId);
                });
            }
        }
        return $query;
    }

    private function meetingSelectColumns(): array
    {
        return [
            'm.sno', 'm.company_id', 'm.owner_user_id', 'm.visibility', 'm.title',
            'm.category', 'm.category_id', 'm.start_at', 'm.end_at', 'm.venue', 'm.meeting_url',
            'm.agenda', 'm.reminder_minutes', 'm.status', 'm.notes', 'm.cancellation_reason',
            'c.category_name', 'c.color as category_color',
            DB::raw("COALESCE(s.staff_name, 'ERP User') as organiser_name"),
            DB::raw('(SELECT COUNT(*) FROM egc_tool_meeting_participants mp WHERE mp.meeting_id = m.sno) as participant_count'),
            DB::raw("(SELECT COUNT(*) FROM egc_tool_meeting_participants mp WHERE mp.meeting_id = m.sno AND mp.rsvp = 'accepted') as accepted_count"),
            DB::raw("(SELECT mp.rsvp FROM egc_tool_meeting_participants mp WHERE mp.meeting_id = m.sno AND mp.user_id = " . (int) $this->uid() . " LIMIT 1) as my_rsvp"),
        ];
    }

    private function applyCalendarScope($query, Request $request): void
    {
        $scope = strtolower((string) $request->input('scope', 'my'));
        $uid = $this->uid();
        if ($scope === 'team') {
            $query->where(function ($q) use ($uid) {
                $q->where('m.owner_user_id', $uid)
                    ->orWhereExists(function ($team) use ($uid) {
                        $team->selectRaw('1')->from('egc_tool_meeting_team_map as mt')
                            ->join('egc_tool_meeting_team_members as tm', 'tm.team_id', '=', 'mt.team_id')
                            ->whereColumn('mt.meeting_id', 'm.sno')->where('tm.user_id', $uid);
                    });
            });
        } elseif ($scope === 'department') {
            $departmentId = (int) DB::table('egc_staff')->where('sno', $uid)->value('department_id');
            if ($departmentId > 0) {
                $query->where(function ($q) use ($departmentId) {
                    $q->whereExists(function ($dept) use ($departmentId) {
                        $dept->selectRaw('1')->from('egc_tool_meeting_department_map as md')
                            ->whereColumn('md.meeting_id', 'm.sno')->where('md.department_id', $departmentId);
                    })->orWhereExists(function ($participant) use ($departmentId) {
                        $participant->selectRaw('1')->from('egc_tool_meeting_participants as mp')
                            ->join('egc_staff as s', 's.sno', '=', 'mp.user_id')
                            ->whereColumn('mp.meeting_id', 'm.sno')->where('s.department_id', $departmentId);
                    });
                });
            } else {
                $query->where('m.owner_user_id', $uid);
            }
        } elseif ($scope === 'company') {
            if ($this->cid() !== null) {
                $companyId = $this->cid();
                $query->where(function ($company) use ($companyId) {
                    $company->where(function ($specific) use ($companyId) {
                        $specific->whereIn('m.visibility', ['Company', 'Group'])->where('m.company_id', $companyId);
                    })->orWhere(function ($globalGroup) {
                        $globalGroup->where('m.visibility', 'Group')->whereNull('m.company_id');
                    });
                });
            } else {
                $query->where('m.visibility', 'Group')->whereNull('m.company_id');
            }
        } else {
            // My Calendar: meetings where the current user is organiser or attendee.
            $query->where(function ($q) use ($uid) {
                $q->where('m.owner_user_id', $uid)->orWhereExists(function ($p) use ($uid) {
                    $p->selectRaw('1')->from('egc_tool_meeting_participants as mp')
                        ->whereColumn('mp.meeting_id', 'm.sno')->where('mp.user_id', $uid);
                });
            });
        }
    }

    private function validateMeeting(Request $request): array
    {
        $data = $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'title' => ['required', 'string', 'max:240'],
            'category_id' => ['nullable', 'integer', 'min:1'],
            'category' => ['nullable', 'string', 'max:100'],
            'start_at' => ['required', ],
            'end_at' => ['required', ],
            'venue' => ['nullable', 'string', 'max:500'],
            'meeting_url' => ['nullable', 'url', 'max:2000'],
            'agenda' => ['nullable', 'string', 'max:10000'],
            'status' => ['nullable', 'in:Scheduled,In Progress,Completed'],
            'reminder_minutes' => ['nullable', 'integer', 'in:0,10,15,30,60,120,1440'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'participant_ids' => ['nullable', 'array', 'max:500'],
            'participant_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
            'team_ids' => ['nullable', 'array', 'max:100'],
            'team_ids.*' => ['integer', 'distinct', 'exists:egc_tool_meeting_teams,sno'],
            'department_ids' => ['nullable', 'array', 'max:100'],
            'department_ids.*' => ['integer', 'distinct', 'exists:egc_department,sno'],
            'attachments' => ['nullable', 'array', 'max:10'],
            'attachments.*' => ['file', 'max:20480', 'mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,png,jpg,jpeg,txt,csv,zip'],
        ]);
        if (empty($data['venue']) && empty($data['meeting_url'])) {
            throw ValidationException::withMessages(['venue' => 'Enter a venue or provide an online meeting link.']);
        }
        return $data;
    }

    private function resolveMeetingCompany(Request $request, $requested): ?int
    {
        if ($this->access->isGroupAdmin($request)) {
            if ($requested === null || $requested === '' || $requested === 'all') return null;
            $companyId = (int) $requested;
            abort_unless(DB::table('egc_company')->where('sno', $companyId)->where('status', 0)->exists(), 422, 'Selected company is inactive.');
            return $companyId;
        }
        $companyId = $this->cid();
        if ($requested !== null && $requested !== '' && (int) $requested !== (int) $companyId) abort(403, 'Cross-company meeting access is not permitted.');
        return $companyId;
    }

    private function resolveCategory(Request $request, $categoryId, ?int $companyId)
    {
        if (!$categoryId) return null;
        $category = DB::table('egc_tool_meeting_categories')->where('sno', (int) $categoryId)
            ->where('status', 0)->whereNull('deleted_at')->first();
        abort_unless($category, 422, 'Selected meeting category is inactive or unavailable.');
        if (!$this->access->isGroupAdmin($request)) {
            abort_unless($category->company_id === null || (int) $category->company_id === (int) $companyId, 403);
        } elseif ($category->company_id !== null) {
            abort_unless($companyId !== null && (int) $category->company_id === (int) $companyId, 403);
        }
        return $category;
    }

    private function resolveParticipantIds(Request $request, array $data, ?int $companyId): array
    {
        $ids = $this->ids($data['participant_ids'] ?? []);
        foreach ($this->ids($data['team_ids'] ?? []) as $teamId) {
            $team = DB::table('egc_tool_meeting_teams')->where('sno', $teamId)->where('status', 0)->whereNull('deleted_at')->first();
            abort_unless($team, 422, 'One or more selected teams are inactive.');
            if ($team->company_id !== null) {
                abort_unless($companyId !== null && (int) $team->company_id === (int) $companyId, 403);
            }
            $ids = array_merge($ids, DB::table('egc_tool_meeting_team_members')->where('team_id', $teamId)->pluck('user_id')->map(fn ($v) => (int) $v)->all());
        }
        foreach ($this->ids($data['department_ids'] ?? []) as $departmentId) {
            $department = DB::table('egc_department')->where('sno', $departmentId)->where('status', 0)->first(['sno', 'company_id']);
            abort_unless($department, 422, 'One or more selected departments are inactive or unavailable.');
            if ($department->company_id !== null) {
                abort_unless($companyId !== null && (int) $department->company_id === (int) $companyId, 403);
            }
            $staffQuery = DB::table('egc_staff')->where('department_id', $departmentId)->where('status', 0)->where('sno', '>', 0);
            if ($companyId !== null) $staffQuery->where('company_id', $companyId);
            $ids = array_merge($ids, $staffQuery->pluck('sno')->map(fn ($v) => (int) $v)->all());
        }
        $ids[] = $this->uid();
        return $this->ids($ids);
    }

    private function assertParticipantsInCompany(array $ids, ?int $companyId): void
    {
        if (!$ids) return;
        $query = DB::table('egc_staff')->whereIn('sno', $ids)->where('status', 0)->where('sno', '>', 0);
        if ($companyId !== null) $query->where('company_id', $companyId);
        $valid = $query->pluck('sno')->map(fn ($v) => (int) $v)->all();
        $invalid = array_values(array_diff($ids, $valid));
        if ($invalid) throw ValidationException::withMessages(['participant_ids' => 'One or more selected participants are inactive or belong to another company.']);
    }

    private function conflictCheck(array $participantIds, string $startAt, string $endAt, int $ignoreId = 0): void
    {
        if (!$participantIds) return;
        $conflicts = DB::table('egc_tool_meeting_participants as mp')
            ->join('egc_tool_meetings as m', 'm.sno', '=', 'mp.meeting_id')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'mp.user_id')
            ->whereIn('mp.user_id', $participantIds)
            ->where('m.start_at', '<', Carbon::parse($endAt)->format('Y-m-d H:i:s'))
            ->where('m.end_at', '>', Carbon::parse($startAt)->format('Y-m-d H:i:s'))
            ->whereNull('m.deleted_at')
            ->whereNotIn(DB::raw('LOWER(m.status)'), ['cancelled', 'completed'])
            ->when($ignoreId > 0, fn ($q) => $q->where('m.sno', '!=', $ignoreId))
            ->orderBy('m.start_at')
            ->get(['mp.user_id', 's.staff_name', 'm.sno as meeting_id', 'm.title', 'm.start_at', 'm.end_at']);
        if ($conflicts->isNotEmpty()) {
            $details = $conflicts->map(function ($row) {
                return trim(($row->staff_name ?: 'Participant') . ' · ' . $row->title . ' (' . Carbon::parse($row->start_at)->format('g:i A') . '–' . Carbon::parse($row->end_at)->format('g:i A') . ')');
            })->unique()->values()->all();
            throw ValidationException::withMessages([
                'schedule_conflicts' => ['Scheduling conflict: ' . implode('; ', array_slice($details, 0, 8))],
            ]);
        }
    }

    private function syncParticipants(int $meetingId, array $ids, bool $resetRsvp): void
    {
        $ids = $this->ids($ids);
        $current = DB::table('egc_tool_meeting_participants')->where('meeting_id', $meetingId)->get()->keyBy('user_id');
        $removed = $current->keys()->map(fn ($v) => (int) $v)->diff($ids)->all();
        if ($removed) DB::table('egc_tool_meeting_participants')->where('meeting_id', $meetingId)->whereIn('user_id', $removed)->delete();
        $staff = DB::table('egc_staff')->whereIn('sno', $ids)->get(['sno', 'staff_name', 'email_id'])->keyBy('sno');
        foreach ($ids as $userId) {
            $person = $staff->get($userId);
            $existing = $current->get($userId);
            $rsvp = $resetRsvp ? 'pending' : ($existing->rsvp ?? 'pending');
            if ($userId === $this->uid()) $rsvp = 'accepted';
            DB::table('egc_tool_meeting_participants')->updateOrInsert(
                ['meeting_id' => $meetingId, 'user_id' => $userId],
                [
                    'display_name' => $person?->staff_name,
                    'email' => $person?->email_id,
                    'rsvp' => $rsvp,
                    'created_at' => $existing->created_at ?? now(),
                    'updated_at' => now(),
                ]
            );
        }
    }

    private function syncMeetingGroups(int $meetingId, array $teamIds, array $departmentIds): void
    {
        DB::table('egc_tool_meeting_team_map')->where('meeting_id', $meetingId)->delete();
        DB::table('egc_tool_meeting_department_map')->where('meeting_id', $meetingId)->delete();
        foreach ($this->ids($teamIds) as $teamId) {
            DB::table('egc_tool_meeting_team_map')->insert(['meeting_id' => $meetingId, 'team_id' => $teamId, 'created_at' => now()]);
        }
        foreach ($this->ids($departmentIds) as $departmentId) {
            DB::table('egc_tool_meeting_department_map')->insert(['meeting_id' => $meetingId, 'department_id' => $departmentId, 'created_at' => now()]);
        }
    }

    private function storeAttachments(Request $request, int $meetingId): void
    {
        foreach ((array) $request->file('attachments', []) as $file) {
            if (!$file || !$file->isValid()) continue;
            $path = $file->store('productivity/meetings/' . $meetingId, 'local');
            DB::table('egc_tool_meeting_attachments')->insert([
                'meeting_id' => $meetingId,
                'original_name' => mb_substr($file->getClientOriginalName(), 0, 255),
                'storage_path' => $path,
                'mime_type' => $file->getMimeType(),
                'file_size' => $file->getSize(),
                'uploaded_by' => $this->uid(), 'created_at' => now(),
            ]);
        }
    }

    private function notifyParticipants(int $meetingId, array $participantIds, string $type, string $title, string $message): void
    {
        $recipientIds = array_values(array_diff($this->ids($participantIds), [$this->uid()]));
        if (!$recipientIds) return;
        $now = now();
        $meeting = DB::table('egc_tool_meetings')->where('sno', $meetingId)->first(['company_id']);
        $rows = [];
        foreach ($recipientIds as $userId) {
            $rows[] = [
                'user_id' => $userId, 'company_id' => $meeting->company_id ?? null,
                'module_name' => 'Meetings', 'resource_type' => 'meeting', 'resource_id' => $meetingId,
                'notification_type' => $type, 'title' => $title, 'message' => $message,
                'action_url' => '/productivity/meetings', 'icon' => 'mdi-calendar-clock', 'icon_color' => '#ab2b22',
                'is_read' => 0, 'created_at' => $now,
            ];
        }
        if ($rows) DB::table('egc_tool_productivity_notifications')->insert($rows);
    }

    private function canManageSettings(Request $request): bool
    {
        return !$this->access->isAuditor($request) && ($this->access->isGroupAdmin($request) || $this->access->isCompanyAdmin($request));
    }

    private function assertSettingsManager(Request $request): void
    {
        abort_unless($this->canManageSettings($request), 403, 'Only company or group administrators can manage meeting categories and teams.');
    }

    private function lookupCompanyId(Request $request): ?int
    {
        if ($this->access->isGroupAdmin($request) && $request->filled('company_id') && $request->input('company_id') !== 'all') return (int) $request->input('company_id');
        if ($this->access->isGroupAdmin($request)) return null;
        return $this->cid();
    }

    private function applyCompanyOrGlobalScope($query, ?int $companyId, string $column): void
    {
        // Group administrators may see all settings when no company is selected;
        // once a company is selected, show only global + that company's settings.
        if ($this->access->isGroupAdmin()) {
            if ($companyId !== null) {
                $query->where(function ($q) use ($column, $companyId) {
                    $q->whereNull($column)->orWhere($column, $companyId);
                });
            }
            return;
        }
        $query->where(function ($q) use ($column, $companyId) {
            $q->whereNull($column);
            if ($companyId !== null) $q->orWhere($column, $companyId);
        });
    }

    private function applySettingsCompanyScope($query, Request $request, string $column): void
    {
        if ($this->access->isGroupAdmin($request)) {
            if ($request->filled('company_id') && $request->input('company_id') !== 'all') {
                $companyId = (int) $request->input('company_id');
                $query->where(function ($q) use ($column, $companyId) {
                    $q->whereNull($column)->orWhere($column, $companyId);
                });
            }
            return;
        }
        $companyId = $this->cid();
        $query->where(function ($q) use ($column, $companyId) {
            $q->whereNull($column);
            if ($companyId !== null) $q->orWhere($column, $companyId);
        });
    }

    private function resolveSettingsCompany(Request $request, $requested): ?int
    {
        if ($this->access->isGroupAdmin($request)) {
            if ($requested === null || $requested === '') return null;
            $companyId = (int) $requested;
            abort_unless(DB::table('egc_company')->where('sno', $companyId)->where('status', 0)->exists(), 422, 'Selected company is inactive.');
            return $companyId;
        }
        $companyId = $this->cid();
        if ($requested !== null && $requested !== '' && (int) $requested !== (int) $companyId) abort(403);
        return $companyId;
    }

    private function assertSettingsScope(Request $request, $companyId): void
    {
        if ($this->access->isGroupAdmin($request)) return;
        // Company administrators can manage only their own company settings;
        // global settings remain visible but are read-only for them.
        abort_unless($companyId !== null && (int) $companyId === (int) $this->cid(), 403);
    }

    private function assertUniqueSettingName(string $table, string $column, string $name, ?int $companyId, int $ignoreId = 0): void
    {
        $query = DB::table($table)->whereNull('deleted_at')->whereRaw('LOWER(' . $column . ') = ?', [mb_strtolower(trim($name))])
            ->when($ignoreId > 0, fn ($q) => $q->where('sno', '!=', $ignoreId));
        if ($companyId === null) $query->whereNull('company_id'); else $query->where('company_id', $companyId);
        abort_if($query->exists(), 422, 'A record with this name already exists for the selected company.');
    }

    private function validatedStaffIds(array $ids, ?int $companyId): array
    {
        $ids = $this->ids($ids);
        if (!$ids) return [];
        $query = DB::table('egc_staff')->whereIn('sno', $ids)->where('status', 0)->where('sno', '>', 0);
        if ($companyId !== null) $query->where('company_id', $companyId);
        $valid = $query->pluck('sno')->map(fn ($v) => (int) $v)->all();
        abort_unless(count($valid) === count($ids), 422, 'Choose only active staff from the selected company.');
        return $valid;
    }

    private function syncTeamMembers(int $teamId, array $memberIds): void
    {
        DB::table('egc_tool_meeting_team_members')->where('team_id', $teamId)->delete();
        if (!$memberIds) return;
        $now = now();
        $rows = array_map(fn ($userId) => ['team_id' => $teamId, 'user_id' => $userId, 'created_at' => $now], $memberIds);
        DB::table('egc_tool_meeting_team_members')->insert($rows);
    }
}
