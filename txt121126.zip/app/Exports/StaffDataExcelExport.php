<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithProperties;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithCustomValueBinder;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;

/**
 * Staff directory export.
 *
 * This export deliberately contains only the requested staff columns and accepts
 * the already-filtered dataset prepared by ManageStaff::customStaffExport().
 */
class StaffDataExcelExport extends DefaultValueBinder implements
    FromArray,
    WithHeadings,
    WithStyles,
    WithColumnWidths,
    WithColumnFormatting,
    WithTitle,
    WithProperties,
    WithEvents,
    WithCustomValueBinder
{
    /**
     * @var array<int, array<string, mixed>>
     */
    private array $rows = [];

    private string $headerColor = 'AB2B22';

    public function __construct(array $staffData)
    {
        $rows = $staffData['rows'] ?? [];

        if ($rows instanceof \Illuminate\Support\Collection) {
            $rows = $rows->all();
        }

        $this->rows = is_array($rows) ? array_values($rows) : [];

        $color = strtoupper(ltrim((string) ($staffData['company_base_color'] ?? '#AB2B22'), '#'));
        if (preg_match('/^[A-F0-9]{6}$/', $color)) {
            $this->headerColor = $color;
        }
    }

    public function headings(): array
    {
        return [
            'Sl',
            'Staff Name',
            'Company',
            'Division',
            'Designation',
            'Date of Joining',
            'Experience Duration',
            'Basic Salary',
        ];
    }

    public function array(): array
    {
        $exportRows = [];

        foreach ($this->rows as $index => $row) {
            $exportRows[] = [
                $index + 1,
                $this->textValue($row['staff_name'] ?? '-'),
                $this->textValue($row['company_name'] ?? '-'),
                $this->textValue($row['entity_name'] ?? '-'),
                $this->textValue($row['job_role_name'] ?? '-'),
                $this->textValue($row['date_of_joining_display'] ?? '-'),
                $this->textValue($row['experience_duration'] ?? '-'),
                is_numeric($row['basic_salary'] ?? null) ? (float) $row['basic_salary'] : 0,
            ];
        }

        return $exportRows;
    }

    public function columnWidths(): array
    {
        return [
            'A' => 7,
            'B' => 27,
            'C' => 24,
            'D' => 22,
            'E' => 24,
            'F' => 18,
            'G' => 25,
            'H' => 19,
        ];
    }

    public function columnFormats(): array
    {
        return [
            'H' => '"₹" #,##0.00',
        ];
    }

    public function title(): string
    {
        return 'Staff Data';
    }

    public function properties(): array
    {
        return [
            'creator' => config('app.name', 'ERP'),
            'title' => 'Staff Data Export',
            'subject' => 'Filtered staff directory',
            'description' => 'Staff data exported from Manage Staff.',
            'category' => 'Human Resources',
            'keywords' => 'staff, HR, employee export',
        ];
    }

    public function styles(Worksheet $sheet): array
    {
        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'color' => ['rgb' => 'FFFFFF'],
                    'size' => 10,
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => ['rgb' => $this->headerColor],
                ],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'wrapText' => true,
                ],
            ],
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event): void {
                $sheet = $event->sheet->getDelegate();
                $lastRow = max(1, count($this->rows) + 1);

                $sheet->freezePane('A2');
                $sheet->setAutoFilter('A1:H' . $lastRow);
                $sheet->getRowDimension(1)->setRowHeight(32);
                $sheet->getStyle('A1:H' . $lastRow)->getAlignment()
                    ->setVertical(Alignment::VERTICAL_CENTER);

                if ($lastRow > 1) {
                    $sheet->getStyle('A2:A' . $lastRow)->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('F2:F' . $lastRow)->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle('H2:H' . $lastRow)->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_RIGHT);
                    $sheet->getStyle('A1:H' . $lastRow)->getBorders()
                        ->getAllBorders()
                        ->setBorderStyle(Border::BORDER_THIN)
                        ->getColor()
                        ->setRGB('DCE2E8');
                }

                $sheet->getTabColor()->setRGB($this->headerColor);
                $sheet->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
                $sheet->getPageSetup()->setFitToWidth(1);
                $sheet->getPageSetup()->setFitToHeight(0);
                $sheet->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
                $sheet->getSheetView()->setZoomScale(90);
            },
        ];
    }

    /**
     * Prevent employee-controlled text such as names from being interpreted
     * as spreadsheet formulas when the exported workbook is opened.
     */
    public function bindValue(Cell $cell, $value): bool
    {
        if (is_string($value)) {
            $cell->setValueExplicit($value, DataType::TYPE_STRING);
            return true;
        }

        return parent::bindValue($cell, $value);
    }

    private function textValue($value): string
    {
        if ($value === null || $value === '') {
            return '-';
        }

        return trim((string) $value);
    }
}
