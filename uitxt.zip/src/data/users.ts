import type { StatusKey } from "@/constants/status";

export interface UserRow {
  id: number;
  name: string;
  email: string;
  role: string;
  status: StatusKey;
}

export const users: UserRow[] = [
  { id: 1, name: "Aarav Kumar", email: "aarav@example.com", role: "Admin", status: "active" },
  { id: 2, name: "Meera Nair", email: "meera@example.com", role: "Manager", status: "active" },
  { id: 3, name: "Rohan Das", email: "rohan@example.com", role: "Editor", status: "pending" },
  { id: 4, name: "Sana Iqbal", email: "sana@example.com", role: "Viewer", status: "inactive" },
  { id: 5, name: "Vikram Rao", email: "vikram@example.com", role: "Editor", status: "processing" },
  { id: 6, name: "Divya Menon", email: "divya@example.com", role: "Manager", status: "rejected" },
  { id: 7, name: "Karthik S", email: "karthik@example.com", role: "Viewer", status: "completed" },
  { id: 8, name: "Anita Joseph", email: "anita@example.com", role: "Admin", status: "active" },
];
