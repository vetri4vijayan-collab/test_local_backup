export { default as LogoTitle } from '../assets/images/logo-title.png';
export { default as LogoWithoutTitle} from '../assets/images/logo.png';
export { default as LogoLongTitle} from '../assets/images/logo-long-title.png';


