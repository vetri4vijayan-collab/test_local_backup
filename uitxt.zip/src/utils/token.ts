const TOKEN_KEY = "app_token";

/**
 * Static demo token. Replace with the real token returned by your API later.
 */
export const STATIC_DEMO_TOKEN = "static-demo-token";

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

/**
 * Right now a token is "valid" when it exists.
 * Later: decode the JWT here and check the `exp` claim.
 */
export function isTokenValid(token: string | null | undefined): boolean {
  return typeof token === "string" && token.trim().length > 0;
}
