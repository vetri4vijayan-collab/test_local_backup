import { Component, type ErrorInfo, type ReactNode } from "react";
import { TriangleAlert } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * Catches render errors and failed lazy-chunk loads.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[ErrorBoundary]", error, info.componentStack);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="app-fullpage">
        <div className="card app-auth-card text-center">
          <div className="card-body p-4">
            <span className="app-icon-box app-icon-box--danger mx-auto mb-3">
              <TriangleAlert size={22} />
            </span>
            <h1 className="h5">Something went wrong</h1>
            <p className="text-body-secondary small mb-4">
              {this.state.error?.message ?? "An unexpected error occurred."}
            </p>
            <button type="button" className="btn btn-primary" onClick={this.handleReload}>
              Reload page
            </button>
          </div>
        </div>
      </div>
    );
  }
}
