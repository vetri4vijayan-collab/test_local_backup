import { lazy, type ReactNode } from "react";
import { Navigate } from "react-router-dom";

import { ROUTES } from "./routePaths";
import ReportsAnalyticsPage from "@/pages/main/reports/ReportsAnalyticsPage";

// ============================================================
// LAZY PAGES (each page becomes its own chunk)
// ============================================================

const LoginPage = lazy(() => import("@/pages/auth/LoginPage"));
const DashboardPage = lazy(
  () => import("@/pages/main/dashboard/DashboardPage"),
);
const PurchaseOrdersPage = lazy(() => import("@/pages/main/purchase-order"));
const QRReworkManagementPage = lazy(
  () => import("@/pages/main/qr-rework/rework-orders"),
);
const SettingsPage = lazy(() => import("@/pages/main/settings/SettingsPage"));
const UserRoleManagementPage = lazy(
  () => import("@/pages/main/user-role-management/UserRoleManagementPage"),
);
const MasterDataManagementPage = lazy(
  () => import("@/pages/main/master-data/MasterDataManagementPage"),
);
const StationManagementPage = lazy(
  () => import("@/pages/main/station-management"),
);
const QAInspectionPage = lazy(() => import("@/pages/main/qa-inspection"));
const PackingDispatch = lazy(() => import("@/pages/main/packing-dispatch"));

const NotFoundPage = lazy(
  () => import("@/components/common/errors/NotFoundPage"),
);

// ============================================================
// TYPES
// ============================================================

export interface RouteItem {
  path?: string;
  index?: boolean;
  element: ReactNode;
  children?: RouteItem[];
}

// ============================================================
// PUBLIC ROUTES (only for logged-out visitors)
// ============================================================

export const publicRoutes: RouteItem[] = [
  {
    path: ROUTES.root,
    element: <Navigate to={ROUTES.auth.login} replace />,
  },
  {
    path: ROUTES.auth.login,
    element: <LoginPage />,
  },
];

// ============================================================
// PROTECTED ROUTES (rendered inside AppLayout, need a token)
// ============================================================

export const protectedRoutes: RouteItem[] = [
  {
    index: true,
    element: <Navigate to={ROUTES.app.dashboard} replace />,
  },
  {
    path: ROUTES.app.dashboard,
    element: <DashboardPage />,
  },
  {
    path: ROUTES.app.purchaseOrders,
    element: <PurchaseOrdersPage />,
  },
  {
    path: ROUTES.app.qrRework,
    element: <QRReworkManagementPage />,
  },
  {
    path: ROUTES.app.usersRoles,
    element: <UserRoleManagementPage />,
  },
  {
    path: ROUTES.app.masterData,
    element: <MasterDataManagementPage />,
  },
  {
    path: ROUTES.app.stationManagement,
    element: <StationManagementPage />,
  },
  {
    path: ROUTES.app.qaInspection,
    element: <QAInspectionPage />,
  },
  {
    path: ROUTES.app.packingDispatch,
    element: <PackingDispatch />,
  },
  {
    path: ROUTES.app.reportsAnalytics,
    element: <ReportsAnalyticsPage />,
  },
  {
    path: ROUTES.app.settings,
    element: <SettingsPage />,
  },
];

// ============================================================
// FALLBACK (404)
// ============================================================

export const fallbackRoute: RouteItem = {
  path: "*",
  element: <NotFoundPage />,
};
