import { Navigate, Outlet, useLocation } from "react-router-dom";

import { useAuthenticatedRoute } from "@/hooks/useAuthenticatedRoute";
import { ROUTES } from "./routePaths";

/**
 * Lets the request through only when a valid token exists,
 * otherwise sends the visitor to the login page.
 */
export function ProtectedRoute() {
  const isAuthenticated = useAuthenticatedRoute();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.auth.login} replace state={{ from: location }} />;
  }

  return <Outlet />;
}
