import { lazy, Suspense } from "react";
import { Outlet, Route, Routes } from "react-router-dom";

import { ProtectedRoute } from "./ProtectedRoute";
import { GuestRoute } from "./GuestRoute";
import { ErrorBoundary } from "./Errorboundary";

import {
  publicRoutes,
  protectedRoutes,
  fallbackRoute,
  type RouteItem,
} from "./routeConfig";

import PageLoader from "@/components/common/spinner-loader";
import { ROUTES } from "./routePaths";

const AppLayout = lazy(() =>
  import("@/layouts/AppLayout").then((module) => ({
    default: module.AppLayout,
  })),
);

// Common full-screen Suspense for every route
function RouteSuspense() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Outlet />
    </Suspense>
  );
}

function renderRoutes(routes: RouteItem[]) {
  return routes.map((route, i) => {
    if (route.index) {
      return (
        <Route
          key={`index-${i}`}
          index
          element={route.element}
        />
      );
    }

    return (
      <Route
        key={route.path ?? `route-${i}`}
        path={route.path}
        element={route.element}
      >
        {route.children && renderRoutes(route.children)}
      </Route>
    );
  });
}

export function AppRoutes() {
  return (
    <ErrorBoundary>
      <Routes>
        {/* Public routes */}
        <Route element={<GuestRoute />}>
          <Route element={<RouteSuspense />}>
            {renderRoutes(publicRoutes)}
          </Route>
        </Route>

        {/* Protected routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<RouteSuspense />}>
            <Route
              path={ROUTES.app.index}
              element={<AppLayout />}
            >
              {renderRoutes(protectedRoutes)}
            </Route>

            <Route path="/load" element={<PageLoader />} />
          </Route>
        </Route>

        {/* Fallback route */}
        <Route
          path={fallbackRoute.path}
          element={
            <Suspense fallback={<PageLoader />}>
              {fallbackRoute.element}
            </Suspense>
          }
        />
      </Routes>
    </ErrorBoundary>
  );
}