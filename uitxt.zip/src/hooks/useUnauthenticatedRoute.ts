import { getToken, isTokenValid } from "@/utils/token";

/**
 * Returns true when the visitor is logged out.
 * Used by public authentication routes.
 */
export function useUnauthenticatedRoute(): boolean {
  return !isTokenValid(getToken());
}
