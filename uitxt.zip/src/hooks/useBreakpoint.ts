import { useMediaQuery } from "./useMediaQuery";

export type Breakpoint = "mobile" | "tablet" | "desktop";

/**
 * mobile  : < 768px   (Bootstrap < md)
 * tablet  : 768-1199  (md, lg)
 * desktop : >= 1200px (xl+)
 */
export function useBreakpoint(): Breakpoint {
  const isDesktop = useMediaQuery("(min-width: 1200px)");
  const isTablet = useMediaQuery("(min-width: 768px)");
  if (isDesktop) return "desktop";
  if (isTablet) return "tablet";
  return "mobile";
}
