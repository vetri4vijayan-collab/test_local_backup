import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Bell,
  CheckCheck,
  ChevronDown,
  CircleCheck,
  Clock3,
  LogOut,
  Menu as MenuIcon,
  Search,
  Settings,
  ShieldCheck,
  UserRound,
  X,
  Rocket,
} from "lucide-react";

import { Logo } from "@/components/common/Logo";
import { ROUTES } from "@/routes/routePaths";
import { removeToken } from "@/utils/token";

// ============================================================
// TYPES
// ============================================================

interface HeaderProps {
  onToggleSidebar: () => void;
  showLogo: boolean;
}

interface NotificationItem {
  id: number;
  title: string;
  message: string;
  time: string;
  type: "success" | "info" | "warning" | "milestone";
  read: boolean;
}

// ============================================================
// INITIAL NOTIFICATIONS
// ============================================================

const initialNotifications: NotificationItem[] = [
  {
    id: 1,
    title: "Rework Order Created",
    message:
      "A new rework order has been created for garments that require additional stitching and finishing.",
    time: "5 min ago",
    type: "warning",
    read: false,
  },
  {
    id: 2,
    title: "Garment Registered & Assigned",
    message:
      "New garments have been registered successfully and assigned to the respective production operator.",
    time: "25 min ago",
    type: "milestone",
    read: false,
  },
  {
    id: 3,
    title: "QA Inspection Passed",
    message:
      "Quality inspection has been completed successfully. The inspected garments have passed all quality checks.",
    time: "1 hour ago",
    type: "success",
    read: false,
  },
  {
    id: 4,
    title: "Fabric Issued to Production",
    message:
      "Fabric materials have been issued to the production department for the latest garment order.",
    time: "3 hours ago",
    type: "info",
    read: true,
  },
  {
    id: 5,
    title: "Garment Production Completed",
    message:
      "The assigned garment production batch has been completed and is ready for the final quality review.",
    time: "Yesterday",
    type: "success",
    read: true,
  },
];

// ============================================================
// COMPONENT
// ============================================================

export function Header({ onToggleSidebar, showLogo }: HeaderProps) {
  const navigate = useNavigate();

  const [activeDropdown, setActiveDropdown] = useState<
    "profile" | "notifications" | null
  >(null);

  const [notifications, setNotifications] =
    useState<NotificationItem[]>(initialNotifications);

  const [searchValue, setSearchValue] = useState("");

  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const unreadCount = notifications.filter(
    (notification) => !notification.read,
  ).length;

  // ==========================================================
  // CLOSE DROPDOWNS ON OUTSIDE CLICK
  // ==========================================================

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setActiveDropdown(null);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setActiveDropdown(null);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  // ==========================================================
  // SEARCH SHORTCUT
  // ==========================================================

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
      }
    };

    document.addEventListener("keydown", handleShortcut);

    return () => {
      document.removeEventListener("keydown", handleShortcut);
    };
  }, []);

  // ==========================================================
  // TOGGLE DROPDOWN
  // ==========================================================

  const toggleDropdown = (dropdown: "profile" | "notifications") => {
    setActiveDropdown((current) => (current === dropdown ? null : dropdown));
  };

  // ==========================================================
  // MARK NOTIFICATION AS READ
  // ==========================================================

  const markAsRead = (id: number) => {
    setNotifications((current) =>
      current.map((notification) =>
        notification.id === id ? { ...notification, read: true } : notification,
      ),
    );
  };

  // ==========================================================
  // MARK ALL AS READ
  // ==========================================================

  const markAllAsRead = () => {
    setNotifications((current) =>
      current.map((notification) => ({
        ...notification,
        read: true,
      })),
    );
  };

  // ==========================================================
  // LOGOUT
  // ==========================================================

  const handleLogout = () => {
    setActiveDropdown(null);
    removeToken();

    navigate(ROUTES.auth.login, {
      replace: true,
    });
  };

  // ==========================================================
  // NOTIFICATION ICON
  // ==========================================================

  const getNotificationIcon = (type: NotificationItem["type"]) => {
    switch (type) {
      case "success":
        return <CircleCheck size={18} />;

      case "milestone":
        return <Rocket size={18} />;

      case "warning":
        return <Clock3 size={18} />;

      default:
        return <ShieldCheck size={18} />;
    }
  };

  return (
    <header className="app-header">
      {/* ================================================== */}
      {/* LEFT SECTION */}
      {/* ================================================== */}

      <div className="app-header__left">
        <button
          type="button"
          className="app-header__menu-btn"
          onClick={onToggleSidebar}
          aria-label="Toggle sidebar"
        >
          <MenuIcon size={21} />
        </button>

        {showLogo && (
          <div className="app-header__mobile-logo d-md-none">
            <Logo variant="dark" size={45} />
          </div>
        )}
      </div>

      {/* ================================================== */}
      {/* SEARCH */}
      {/* ================================================== */}

      <div className="app-header__search d-none d-md-flex">
        <Search size={18} className="app-header__search-icon" />

        <input
          ref={searchRef}
          type="search"
          className="app-header__search-input"
          placeholder="Search anything..."
          aria-label="Search anything"
          value={searchValue}
          onChange={(event) => setSearchValue(event.target.value)}
        />

        {searchValue ? (
          <button
            type="button"
            className="app-header__search-clear"
            onClick={() => setSearchValue("")}
            aria-label="Clear search"
          >
            <X size={15} />
          </button>
        ) : (
          <span className="app-header__search-shortcut">Ctrl K</span>
        )}
      </div>

      {/* ================================================== */}
      {/* RIGHT SECTION */}
      {/* ================================================== */}

      <div className="app-header__right" ref={dropdownRef}>
        {/* ---------------------------------------------- */}
        {/* NOTIFICATION BUTTON */}
        {/* ---------------------------------------------- */}

        <div className="app-header__dropdown-wrapper">
          <button
            type="button"
            className={`app-header__notification ${
              activeDropdown === "notifications" ? "is-active" : ""
            }`}
            onClick={() => toggleDropdown("notifications")}
            aria-label="Notifications"
            aria-expanded={activeDropdown === "notifications"}
          >
            <Bell size={20} strokeWidth={1.9} />

            {unreadCount > 0 && (
              <span className="app-header__notification-count">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>

          {/* NOTIFICATION DROPDOWN */}

          {activeDropdown === "notifications" && (
            <div className="app-notification-dropdown">
              <div className="app-notification-dropdown__header">
                <div>
                  <h6>Notifications</h6>

                  <span>You have {unreadCount} unread messages</span>
                </div>

                <button
                  type="button"
                  className="app-notification-dropdown__close"
                  onClick={() => setActiveDropdown(null)}
                  aria-label="Close notifications"
                >
                  <X size={17} />
                </button>
              </div>

              {/* NOTIFICATION ACTION */}

              {unreadCount > 0 && (
                <div className="app-notification-dropdown__actions">
                  <button type="button" onClick={markAllAsRead}>
                    <CheckCheck size={15} />
                    Mark all as read
                  </button>
                </div>
              )}

              {/* NOTIFICATION LIST */}

              <div className="app-notification-dropdown__list">
                {notifications.length > 0 ? (
                  notifications.map((notification) => (
                    <button
                      type="button"
                      key={notification.id}
                      className={`app-notification-item ${
                        !notification.read ? "is-unread" : ""
                      }`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <span
                        className={`app-notification-item__icon app-notification-item__icon--${notification.type}`}
                      >
                        {getNotificationIcon(notification.type)}
                      </span>

                      <span className="app-notification-item__content">
                        <span className="app-notification-item__top">
                          <span className="app-notification-item__title">
                            {notification.title}
                          </span>

                          {!notification.read && (
                            <span className="app-notification-item__unread-dot" />
                          )}
                        </span>

                        <span className="app-notification-item__message">
                          {notification.message}
                        </span>

                        <span className="app-notification-item__time">
                          <Clock3 size={12} />
                          {notification.time}
                        </span>
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="app-notification-empty">
                    <Bell size={28} />
                    <span>No notifications yet</span>
                    <small>You're all caught up!</small>
                  </div>
                )}
              </div>

              <div className="app-notification-dropdown__footer">
                <button type="button" onClick={() => setActiveDropdown(null)}>
                  Close notifications
                </button>
              </div>
            </div>
          )}
        </div>

        {/* DIVIDER */}

        <span className="app-header__divider d-none d-sm-block" />

        {/* ---------------------------------------------- */}
        {/* PROFILE BUTTON */}
        {/* ---------------------------------------------- */}

        <div className="app-header__dropdown-wrapper">
          <button
            type="button"
            className={`app-header__profile ${
              activeDropdown === "profile" ? "is-active" : ""
            }`}
            onClick={() => toggleDropdown("profile")}
            aria-expanded={activeDropdown === "profile"}
            aria-haspopup="true"
          >
            <span className="app-header__avatar">
              <UserRound size={20} />
            </span>

            <span className="app-header__profile-info d-none d-sm-flex">
              <span className="app-header__profile-name">Admin</span>

              <span className="app-header__profile-role">Super Admin</span>
            </span>

            <ChevronDown
              size={16}
              className={`app-header__profile-arrow d-none d-sm-block ${
                activeDropdown === "profile" ? "is-open" : ""
              }`}
            />
          </button>

          {/* PROFILE DROPDOWN */}

          {activeDropdown === "profile" && (
            <div className="app-profile-dropdown">
              <div className="app-profile-dropdown__header">
                <span className="app-profile-dropdown__avatar">
                  <UserRound size={25} />
                </span>

                <div className="app-profile-dropdown__details">
                  <span className="app-profile-dropdown__name">
                    Super Admin
                  </span>

                  <span className="app-profile-dropdown__email">
                    admin@example.com
                  </span>
                </div>
              </div>

              <div className="app-profile-dropdown__divider" />

              <div className="app-profile-dropdown__menu">
                <button
                  type="button"
                  onClick={() => {
                    setActiveDropdown(null);
                    navigate(ROUTES.app.settings);
                  }}
                >
                  <Settings size={17} />
                  <span>Settings</span>
                </button>
              </div>

              <div className="app-profile-dropdown__divider" />

              <div className="app-profile-dropdown__menu">
                <button
                  type="button"
                  className="is-logout"
                  onClick={handleLogout}
                >
                  <LogOut size={17} />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
