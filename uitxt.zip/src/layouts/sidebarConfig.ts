
import {
  LayoutDashboard,
  ShoppingCart,
  QrCode,
  Wrench,
  ClipboardCheck,
  PackageCheck,
  ChartNoAxesColumn,
  Database,
  Users,
  Settings,
  type LucideIcon,
} from "lucide-react";

import { ROUTES } from "@/routes/routePaths";

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  badge?: number;
}

export interface NavSection {
  title: string;
  items: NavItem[];
}

export const sidebarSections: NavSection[] = [
  {
    title: "Main",
    items: [
      {
        label: "Dashboard",
        to: ROUTES.app.dashboard,
        icon: LayoutDashboard,
      },
      {
        label: "Purchase Orders",
        to: ROUTES.app.purchaseOrders,
        icon: ShoppingCart,
      },
      {
        label: "QR & Rework Management",
        to: ROUTES.app.qrRework,
        icon: QrCode,
        badge: 9,
      },
      {
        label: "Station Management",
        to: ROUTES.app.stationManagement,
        icon: Wrench,
      },
      {
        label: "QA Inspection",
        to: ROUTES.app.qaInspection,
        icon: ClipboardCheck,
        badge: 2,
      },
      {
        label: "Packing & Dispatch",
        to: ROUTES.app.packingDispatch,
        icon: PackageCheck,
        badge: 8,
      },
      {
        label: "Reports & Analytics",
        to: ROUTES.app.reportsAnalytics,
        icon: ChartNoAxesColumn,
      },
      {
        label: "Master Data",
        to: ROUTES.app.masterData,
        icon: Database,
      },
      {
        label: "User & Roles",
        to: ROUTES.app.usersRoles,
        icon: Users,
      },
      {
        label: "Settings",
        to: ROUTES.app.settings,
        icon: Settings,
      },
    ],
  },
];
