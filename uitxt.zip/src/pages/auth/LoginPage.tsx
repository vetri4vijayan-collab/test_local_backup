import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type FormEvent,
} from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Eye, EyeOff, LockKeyhole, QrCode, User } from "lucide-react";

import { Logo } from "@/components/common/Logo";

import { ROUTES } from "@/routes/routePaths";
import { setToken, STATIC_DEMO_TOKEN } from "@/utils/token";

import "./LoginPage.scss";
import CommonInput from "@/components/common/ui/input/CommonInput";

interface LocationState {
  from?: { pathname: string };
}

interface LoginErrors {
  username?: string;
  password?: string;
}

/* The rework journey of one garment (lifecycle from the project document) */
const STAGES = [
  {
    title: "Register",
    text: "Unique ID and QR for every defective garment",
    status: "Registered",
  },
  {
    title: "Repair",
    text: "Assigned to a station and operator",
    status: "In repair",
  },
  {
    title: "QA check",
    text: "Checklist, then pass, reject or scrap",
    status: "QA check",
  },
  {
    title: "Pack",
    text: "Only QA-approved garments go into cartons",
    status: "Packed",
  },
];

const SEAM_PATH =
  "M65 60 C 105 22, 155 98, 195 60 S 285 22, 325 60 S 415 98, 455 60";
const NODE_X = [65, 195, 325, 455];

/* Seconds at which the needle reaches each stage (must match the SCSS) */
const STAGE_TIMES = [0.2, 1.88, 3.12, 4.36];

/* Thread reveal window (x range of the seam) and timing */
const SEAM_X_START = 40;
const SEAM_X_SPAN = 440;
const SEW_DELAY_MS = 400;
const SEW_DURATION_MS = 4200;

/* The whole sequence replays every CYCLE_MS */
const CYCLE_MS = 9600;

const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("password");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errors, setErrors] = useState<LoginErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [shake, setShake] = useState(false);

  /* each change of `cycle` remounts the journey, so every step plays again */
  const [cycle, setCycle] = useState(0);

  const timerRef = useRef<number | null>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const needleRef = useRef<SVGGElement>(null);

  /* replay the journey on a loop */
  useEffect(() => {
    if (prefersReducedMotion()) return;

    const id = window.setInterval(() => setCycle((c) => c + 1), CYCLE_MS);

    return () => window.clearInterval(id);
  }, []);

  /* move the needle along the seam in step with the thread reveal */
  useEffect(() => {
    if (prefersReducedMotion()) return;

    const path = pathRef.current;
    const needle = needleRef.current;

    if (!path || !needle) return;

    const total = path.getTotalLength();

    // x always increases along the seam, so we can search by x
    const pointAtX = (x: number) => {
      let lo = 0;
      let hi = total;

      for (let i = 0; i < 18; i += 1) {
        const mid = (lo + hi) / 2;

        if (path.getPointAtLength(mid).x < x) lo = mid;
        else hi = mid;
      }

      return path.getPointAtLength(hi);
    };

    const start = performance.now();
    let frame = 0;

    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(
        Math.max((elapsed - SEW_DELAY_MS) / SEW_DURATION_MS, 0),
        1,
      );

      const point = pointAtX(SEAM_X_START + SEAM_X_SPAN * progress);

      needle.setAttribute("transform", `translate(${point.x} ${point.y})`);

      if (elapsed < SEW_DELAY_MS + SEW_DURATION_MS + 300) {
        frame = requestAnimationFrame(tick);
      }
    };

    frame = requestAnimationFrame(tick);

    return () => cancelAnimationFrame(frame);
  }, [cycle]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const handleUsernameChange = (value: string) => {
    setUsername(value);

    if (errors.username) {
      setErrors((prev) => ({ ...prev, username: undefined }));
    }
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);

    if (errors.password) {
      setErrors((prev) => ({ ...prev, password: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: LoginErrors = {};

    if (!username.trim()) {
      newErrors.username = "Enter your username or email.";
    }

    if (!password.trim()) {
      newErrors.password = "Enter your password.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (isSubmitting) return;

    if (!validateForm()) {
      setShake(true);
      return;
    }

    setIsSubmitting(true);

    // TODO: Replace this timeout with your real authentication API call.
    timerRef.current = window.setTimeout(() => {
      setToken(STATIC_DEMO_TOKEN);

      const from = (location.state as LocationState | null)?.from?.pathname;

      navigate(from ?? ROUTES.app.dashboard, { replace: true });
    }, 900);
  };

  return (
    <main className="login-page">
      {/* LEFT BRAND PANEL (hidden on mobile) */}
      <section className="login-brand-panel" aria-hidden="true">
        <div className="login-bubbles">
          <span className="bubble bubble--a" />
          <span className="bubble bubble--b" />
          <span className="bubble bubble--c" />
          <span className="bubble bubble--d" />
          <span className="bubble bubble--e" />
          <span className="bubble bubble--f" />
        </div>

        <div className="login-brand-content">
          <div className="login-brand-main">
            <h1>Every defective garment, tracked all the way to the carton.</h1>

            <p className="login-brand-description">
              Register defects with a unique QR, send repairs to the right
              station, check them against one QA standard and pack only approved
              garments.
            </p>
          </div>

          {/* journey: remounted on every cycle so all steps replay */}
          <div className="login-seam" key={cycle}>
            <div className="login-tag">
              <QrCode size={16} />
              <span className="login-tag-id">QR-2026-001</span>

              <span className="login-tag-status">
                {STAGES.map((stage, i) => (
                  <span
                    key={stage.status}
                    className={`login-tag-step${
                      i === STAGES.length - 1 ? " is-last" : ""
                    }`}
                    style={
                      {
                        ["--d" as string]: `${STAGE_TIMES[i]}s`,
                        ["--e" as string]: `${STAGE_TIMES[i + 1] ?? 0}s`,
                      } as CSSProperties
                    }
                  >
                    {stage.status}
                  </span>
                ))}
              </span>
            </div>

            <svg
              className="login-seam-svg"
              viewBox="0 0 520 120"
              fill="none"
              focusable="false"
            >
              <defs>
                <mask id="seam-reveal" maskUnits="userSpaceOnUse">
                  <rect
                    className="login-seam-mask"
                    x={SEAM_X_START}
                    y="0"
                    width={SEAM_X_SPAN}
                    height="120"
                    fill="#fff"
                  />
                </mask>
              </defs>

              <path className="login-seam-guide" d={SEAM_PATH} />

              <g mask="url(#seam-reveal)">
                <path
                  ref={pathRef}
                  className="login-seam-thread"
                  d={SEAM_PATH}
                />
              </g>

              {NODE_X.map((x, i) => (
                <g
                  key={x}
                  className="login-seam-node"
                  style={{ ["--n" as string]: i } as CSSProperties}
                >
                  <circle className="login-seam-ring" cx={x} cy="60" r="11" />
                  <circle className="login-seam-dot" cx={x} cy="60" r="5" />
                </g>
              ))}

              <g ref={needleRef} className="login-seam-needle">
                <circle r="4.5" />
              </g>
            </svg>

            <ol className="login-seam-stages">
              {STAGES.map((stage, i) => (
                <li
                  key={stage.title}
                  style={{ ["--n" as string]: i } as CSSProperties}
                >
                  <strong>{stage.title}</strong>
                  <span>{stage.text}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="login-brand-footer">
            {/* <span>Tirupur, Coimbatore, Erode and Chennai</span> */}
            <span className="login-brand-version">
              Rework Management System
            </span>
          </div>
        </div>
      </section>

      {/* RIGHT LOGIN PANEL */}
      <section className="login-form-panel">
        <div className="login-bubbles" aria-hidden="true">
          <span className="bubble bubble--f1" />
          <span className="bubble bubble--f2" />
          <span className="bubble bubble--f3" />
        </div>

        <div className="login-form-wrapper">
          <div className="login-form-logo">
            <Logo variant="dark" size={54} />
          </div>

          <div className="login-form-heading">
            <h2>Sign in</h2>

            <p>
              Enter your username or email to access the Penguin Apparels Rework
              Management System.
            </p>
          </div>

          <form
            className={`login-form${shake ? " is-shaking" : ""}`}
            onSubmit={handleSubmit}
            onAnimationEnd={(e) => {
              if (e.target === e.currentTarget) setShake(false);
            }}
            noValidate
          >
            {/* USERNAME / EMPLOYEE CODE */}
            <CommonInput
              id="login-username"
              containerClassName="login-field"
              label="Username / Email"
              name="username"
              type="text"
              placeholder="Enter username or Email"
              value={username}
              onChange={(e: any) => handleUsernameChange(e.target.value)}
              leftElement={<User />}
              autoComplete="username"
              required
              error={errors.username}
            />

            {/* PASSWORD */}
            <div className="login-field">
              <div className="login-label-row">
                <label htmlFor="login-password">
                  Password <span className="common-input-required">*</span>
                </label>
              </div>

              <CommonInput
                id="login-password"
                name="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e: any) => handlePasswordChange(e.target.value)}
                leftElement={<LockKeyhole />}
                rightElement={
                  <button
                    type="button"
                    className="login-eye-button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                }
                autoComplete="current-password"
                required
                error={errors.password}
              />
            </div>

            <label className="login-remember">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <span className="login-custom-checkbox" />
              <span>Keep me signed in on this device</span>
            </label>

            <button
              type="submit"
              className={`login-submit-button${
                isSubmitting ? " is-loading" : ""
              }`}
              disabled={isSubmitting}
            >
              <span className="login-submit-spinner" aria-hidden="true" />
              <span>{isSubmitting ? "Signing in" : "Sign in"}</span>
            </button>
          </form>

          <p className="login-reset-note">
            Forgot your password?
            <span>Contact your administrator to reset it.</span>
          </p>

          <div className="login-copyright">
            <span>© {new Date().getFullYear()} Penguin Apparels</span>
            {/* <span>Built by EiBS Global</span> */}
          </div>
        </div>
      </section>
    </main>
  );
}
