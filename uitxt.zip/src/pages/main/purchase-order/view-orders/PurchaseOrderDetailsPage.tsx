
import { useMemo, useState } from "react";
import type { ReactNode } from "react";

import {
  ArrowLeft,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Package,
  PackageCheck,
  Palette,
  ScanLine,
  ShieldCheck,
  ShoppingBag,
  User,
  AlertCircle,
  FileText,
  TrendingUp,
} from "lucide-react";

import type { TableColumn } from "@/components/common/data-table";
import { CommonDataTable } from "@/components/common/data-table";
import CommonButton from "@/components/common/ui/button/CommonButton";

import type { PurchaseOrder } from "../index";
import type { PurchaseOrderItem } from "../modal/CreatePurchaseOrders";

import "./PurchaseOrderDetailsPage.scss";

type TabKey = "overview" | "reworks" | "quality";

interface ReworkOrder {
  id: string;
  qrId: string;
  defectCategory: string;
  severity: "Low" | "Medium" | "High";
  registeredDate: string;
  status: "Pending" | "In Progress" | "Completed" | "Scrapped";
}

interface PurchaseOrderDetailsPageProps {
  order: PurchaseOrder;
  onBack: () => void;
  initialTab?: TabKey;
}

interface InfoItemProps {
  label: string;
  value?: string | number;
  icon?: ReactNode;
}

function InfoItem({ label, value, icon }: InfoItemProps) {
  return (
    <div className="pod-info-item">
      <span className="pod-info-label">{label}</span>

      <div className="pod-info-value">
        {icon && <span className="pod-info-icon">{icon}</span>}
        <span>{value || "—"}</span>
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  description,
  icon,
  variant = "default",
}: {
  label: string;
  value: string | number;
  description: string;
  icon: ReactNode;
  variant?: "default" | "success" | "warning" | "danger";
}) {
  return (
    <div className={`pod-metric-card pod-metric-card--${variant}`}>
      <div className="pod-metric-top">
        <span className="pod-metric-icon">{icon}</span>
      </div>

      <h3>{value}</h3>
      <p className="pod-metric-label">{label}</p>
      <span className="pod-metric-description">{description}</span>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const className = status.toLowerCase().replace(/\s+/g, "-");

  return (
    <span className={`pod-status-badge pod-status-badge--${className}`}>
      {status}
    </span>
  );
}

function getOrderItems(order: PurchaseOrder): PurchaseOrderItem[] {
  if (Array.isArray(order.items) && order.items.length > 0) {
    return order.items;
  }

  // Compatibility with older purchase order records.
  return [
    {
      size: order.size || "",
      color: order.color || "",
      orderedQty: String(order.orderedQty || 0),
    },
  ];
}

function getReworkOrders(order: PurchaseOrder): ReworkOrder[] {
  const total = Math.max(0, Number(order.totalReworks) || 0);

  const categories = [
    "Stitching Defect",
    "Fabric Damage",
    "Measurement Issue",
    "Loose Thread",
    "Print Defect",
    "Colour Variation",
  ];

  const statuses: ReworkOrder["status"][] = [
    "Completed",
    "In Progress",
    "Pending",
    "Scrapped",
  ];

  return Array.from({ length: total }, (_, index) => ({
    id: `RW-${String(index + 1).padStart(4, "0")}`,
    qrId: `${order.poNumber}-QR-${String(index + 1).padStart(3, "0")}`,
    defectCategory: categories[index % categories.length],
    severity:
      index % 3 === 0
        ? "High"
        : index % 3 === 1
          ? "Medium"
          : "Low",
    registeredDate: new Date(
      Date.now() - index * 86400000,
    ).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }),
    status: statuses[index % statuses.length],
  }));
}

export default function PurchaseOrderDetailsPage({
  order,
  onBack,
  initialTab = "overview",
}: PurchaseOrderDetailsPageProps) {
  const [activeTab, setActiveTab] = useState<TabKey>(initialTab);

  const orderItems = useMemo(
    () => getOrderItems(order),
    [order],
  );

  const totalQuantity = orderItems.reduce(
    (total, item) => total + (Number(item.orderedQty) || 0),
    0,
  );

  const reworkOrders = useMemo(
    () => getReworkOrders(order),
    [order],
  );

  const totalReworks = Number(order.totalReworks) || 0;
  const completed = Number(order.completed) || 0;
  const inProgress = Number(order.inProgress) || 0;
  const irreparable = Number(order.irreparable) || 0;

  const defectRate =
    totalQuantity > 0
      ? (totalReworks / totalQuantity) * 100
      : 0;

  const completionRate =
    totalReworks > 0
      ? (completed / totalReworks) * 100
      : 0;

  const reworkColumns: TableColumn<ReworkOrder>[] = [
    {
      header: "Rework ID",
      field: "id",
      sortable: true,
      body: (row) => (
        <span className="pod-table-primary">{row.id}</span>
      ),
    },
    {
      header: "QR Code ID",
      field: "qrId",
      sortable: true,
      body: (row) => (
        <span className="pod-qr-id">
          <ScanLine size={15} />
          {row.qrId}
        </span>
      ),
    },
    {
      header: "Defect Category",
      field: "defectCategory",
      sortable: true,
    },
    {
      header: "Severity",
      field: "severity",
      body: (row) => <StatusBadge status={row.severity} />,
    },
    {
      header: "Registered Date",
      field: "registeredDate",
      sortable: true,
    },
    {
      header: "Status",
      field: "status",
      body: (row) => <StatusBadge status={row.status} />,
    },
  ];

  const tabs: {
    key: TabKey;
    label: string;
    icon: ReactNode;
  }[] = [
    {
      key: "overview",
      label: "Overview & Specifications",
      icon: <FileText size={17} />,
    },
    {
      key: "reworks",
      label: "Rework Orders",
      icon: <TrendingUp size={17} />,
    },
    {
      key: "quality",
      label: "Quality & Performance",
      icon: <TrendingUp size={17} />,
    },
  ];

  const pendingReworks = Math.max(
    0,
    totalReworks - completed - inProgress - irreparable,
  );

  const defectBreakdown = [
    "Stitching Defect",
    "Fabric Damage",
    "Measurement Issue",
    "Loose Thread",
    "Print Defect",
    "Colour Variation",
  ]
    .map((category) => {
      const count = reworkOrders.filter(
        (item) => item.defectCategory === category,
      ).length;

      return {
        category,
        count,
        percentage:
          reworkOrders.length > 0
            ? (count / reworkOrders.length) * 100
            : 0,
      };
    })
    .filter((item) => item.count > 0);

  return (
    <div className="purchase-order-details">
      {/* PAGE HEADER */}
      <div className="pod-page-header">
        <div className="pod-header-actions">
          <CommonButton
            variant="outline"
            size="md"
            leftIcon={<ArrowLeft size={16} />}
            onClick={onBack}
          >
            Back to List
          </CommonButton>
        </div>

        <StatusBadge status={order.status} />
      </div>

      {/* PO SUMMARY */}
      <section className="pod-summary-card">
        <div className="pod-summary-main">
          <div className="pod-summary-icon">
            <ShoppingBag size={25} />
          </div>

          <div>
            <span className="pod-summary-label">
              Purchase Order Number
            </span>

            <h2>{order.poNumber}</h2>

            <span className="pod-summary-description">
              {order.description || "Purchase order information"}
            </span>
          </div>
        </div>

        <div className="pod-summary-divider" />

        <div className="pod-summary-item">
          <span>Supplier</span>
          <strong>{order.supplier || "—"}</strong>
        </div>

        <div className="pod-summary-item">
          <span>Style Number</span>
          <strong>{order.style || "—"}</strong>
        </div>

        <div className="pod-summary-item">
          <span>Article SKU</span>
          <strong>{order.articleSku || "—"}</strong>
        </div>
      </section>

      {/* METRIC CARDS */}
      <section className="pod-metrics-grid">
        <MetricCard
          label="Ordered Quantity"
          value={totalQuantity.toLocaleString("en-IN")}
          description="Total garments ordered"
          icon={<Package size={21} />}
        />

        <MetricCard
          label="Total Reworks"
          value={totalReworks}
          description="Garments registered for rework"
          icon={<TrendingUp size={21} />}
          variant="warning"
        />

        <MetricCard
          label="Completed"
          value={completed}
          description="Rework completed"
          icon={<CheckCircle2 size={21} />}
          variant="success"
        />

        <MetricCard
          label="In Progress"
          value={inProgress}
          description="Currently being processed"
          icon={<Clock3 size={21} />}
        />

        <MetricCard
          label="Irreparable"
          value={irreparable}
          description="Garments marked irreparable"
          icon={<AlertCircle size={21} />}
          variant="danger"
        />
      </section>

      {/* TABS */}
      <section className="pod-content-card">
        <div className="pod-tabs">
          {tabs.map((tab) => (
            <button
              type="button"
              key={tab.key}
              className={`pod-tab ${
                activeTab === tab.key ? "active" : ""
              }`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.icon}
              <span>{tab.label}</span>

              {tab.key === "reworks" && (
                <span className="pod-tab-count">
                  {reworkOrders.length}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="pod-tab-content">
          {/* OVERVIEW */}
          {activeTab === "overview" && (
            <div className="pod-overview">
              <div className="pod-section-heading">
                <div>
                  <h3>Purchase Order Information</h3>
                  <p>
                    General information about this purchase order.
                  </p>
                </div>
              </div>

              <div className="pod-info-grid">
                <InfoItem
                  label="PO Number"
                  value={order.poNumber}
                  icon={<FileText size={17} />}
                />

                <InfoItem
                  label="Supplier Name"
                  value={order.supplier}
                  icon={<User size={17} />}
                />

                <InfoItem
                  label="Style Number"
                  value={order.style}
                  icon={<Package size={17} />}
                />

                <InfoItem
                  label="Article SKU"
                  value={order.articleSku}
                  icon={<ScanLine size={17} />}
                />

                <InfoItem
                  label="Description"
                  value={order.description}
                  icon={<FileText size={17} />}
                />

                <InfoItem
                  label="Delivery Date"
                  value={order.deliveryDate}
                  icon={<CalendarDays size={17} />}
                />

                <InfoItem
                  label="Batch / Lot"
                  value={order.batch}
                  icon={<PackageCheck size={17} />}
                />

                <InfoItem
                  label="Order Status"
                  value={order.status}
                  icon={<ShieldCheck size={17} />}
                />
              </div>

              <div className="pod-section-divider" />

              {/* INDIVIDUAL SIZE VARIATIONS */}
              <div className="pod-section-heading pod-size-heading">
                <div>
                  <h3>Garment Specifications</h3>
                  <p>
                    Individual size, color and ordered quantity details.
                  </p>
                </div>

                <span className="pod-record-count">
                  {orderItems.length} Variations
                </span>
              </div>

              <div className="pod-size-variation-grid">
                {orderItems.map((item, index) => (
                  <div
                    className="pod-size-variation-card"
                    key={`${item.size}-${item.color}-${index}`}
                  >
                    <div className="pod-size-variation-top">
                      <span className="pod-size-variation-index">
                        {String(index + 1).padStart(2, "0")}
                      </span>

                      <span className="pod-size-label">
                        {item.size || "N/A"}
                      </span>
                    </div>

                    <div className="pod-size-variation-details">
                      <div>
                        <span>
                          <Palette size={14} />
                          Color
                        </span>
                        <strong>{item.color || "—"}</strong>
                      </div>

                      <div>
                        <span>
                          <ShoppingBag size={14} />
                          Ordered Quantity
                        </span>

                        <strong>
                          {(
                            Number(item.orderedQty) || 0
                          ).toLocaleString("en-IN")}
                        </strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* TOTAL QUANTITY */}
              <div className="pod-size-total">
                <div>
                  <Package size={19} />
                  <span>Total Ordered Quantity</span>
                </div>

                <strong>
                  {totalQuantity.toLocaleString("en-IN")}
                </strong>
              </div>
            </div>
          )}

          {/* REWORK ORDERS */}
          {activeTab === "reworks" && (
            <div className="pod-reworks">
              <div className="pod-section-heading pod-rework-heading">
                <div>
                  <h3>Registered Rework Orders</h3>
                  <p>
                    Garment-level rework records associated with this
                    purchase order.
                  </p>
                </div>

                <span className="pod-record-count">
                  {reworkOrders.length} Records
                </span>
              </div>

              <CommonDataTable
                data={reworkOrders}
                columns={reworkColumns}
                dataKey="id"
                paginator
                rows={8}
                rowsPerPageOptions={[5, 8, 10, 25]}
                stripedRows={false}
                showGridlines={false}
                size="small"
                emptyMessage="No rework orders found for this purchase order"
                className="pod-rework-table"
              />
            </div>
          )}

          {/* QUALITY & PERFORMANCE */}
          {activeTab === "quality" && (
            <div className="pod-quality">
              <div className="pod-quality-banner">
                <div className="pod-quality-banner-content">
                  <span className="pod-quality-eyebrow">
                    SUPPLIER QUALITY & PERFORMANCE SCORECARD
                  </span>

                  <h2>{order.supplier || "Supplier Name"}</h2>

                  <p>
                    Purchase Order: <strong>{order.poNumber}</strong>
                    <span className="pod-quality-header-separator">
                      ·
                    </span>
                    Style: <strong>{order.style || "—"}</strong>
                  </p>
                </div>

                <div className="pod-quality-rating">
                  <span>REWORK COMPLETION RATE</span>
                  <strong>{completionRate.toFixed(1)}%</strong>
                  <small>Completed reworks</small>
                </div>
              </div>

              <div className="pod-quality-metrics">
                <div className="pod-quality-metric-card">
                  <span className="pod-quality-metric-label">
                    REWORK COMPLETION RATE
                  </span>
                  <strong className="metric-green">
                    {completionRate.toFixed(1)}%
                  </strong>
                  <small>Based on completed rework records</small>
                </div>

                <div className="pod-quality-metric-card">
                  <span className="pod-quality-metric-label">
                    DEFECT RATE
                  </span>
                  <strong className="metric-orange">
                    {defectRate.toFixed(2)}%
                  </strong>
                  <small>{totalReworks} rework cases recorded</small>
                </div>

                <div className="pod-quality-metric-card">
                  <span className="pod-quality-metric-label">
                    DELIVERY DATE
                  </span>
                  <strong className="metric-blue pod-quality-date">
                    {order.deliveryDate
                      ? new Date(
                          `${order.deliveryDate}T00:00:00`,
                        ).toLocaleDateString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })
                      : "Not Set"}
                  </strong>
                  <small>Expected purchase order delivery</small>
                </div>

                <div className="pod-quality-metric-card">
                  <span className="pod-quality-metric-label">
                    TOTAL REWORK CASES
                  </span>
                  <strong className="metric-purple">
                    {totalReworks}
                  </strong>
                  <small>
                    Out of {totalQuantity.toLocaleString("en-IN")} ordered
                    garments
                  </small>
                </div>
              </div>

              <div className="pod-quality-bottom-grid">
                <div className="pod-quality-panel">
                  <div className="pod-quality-panel-heading">
                    <h4>Defect Category Breakdown</h4>
                    <span>By rework category</span>
                  </div>

                  {defectBreakdown.length > 0 ? (
                    <div className="pod-defect-list">
                      {defectBreakdown.map((item, index) => (
                        <div
                          className="pod-defect-item"
                          key={item.category}
                        >
                          <div className="pod-defect-info">
                            <span>{item.category}</span>

                            <strong>
                              {item.percentage.toFixed(0)}%
                              <small> of defects</small>
                            </strong>
                          </div>

                          <div className="pod-defect-track">
                            <div
                              className={`pod-defect-fill pod-defect-fill--${index % 4}`}
                              style={{
                                width: `${item.percentage}%`,
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="pod-quality-empty">
                      No defect category records available.
                    </div>
                  )}
                </div>

                <div className="pod-quality-panel">
                  <div className="pod-quality-panel-heading">
                    <h4>Supplier Compliance & Audit Summary</h4>
                  </div>

                  <div className="pod-compliance-list">
                    <div className="pod-compliance-row">
                      <span>Batch Lot Verification</span>
                      <span className="pod-compliance-status passed">
                        Passed
                      </span>
                    </div>

                    <div className="pod-compliance-row">
                      <span>Color & GSM Lab Dip Approval</span>
                      <span className="pod-compliance-status approved">
                        Approved
                      </span>
                    </div>

                    <div className="pod-compliance-row">
                      <span>Final QA Inspection Signoff</span>
                      <span className="pod-compliance-status in-progress">
                        In Progress
                      </span>
                    </div>

                    <div className="pod-compliance-row">
                      <span>Pending Reworks</span>
                      <strong>{pendingReworks}</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
