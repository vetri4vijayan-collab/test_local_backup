import { useState, type FormEvent } from "react";
import { FilePlus2, PackagePlus, Plus, Trash2, X } from "lucide-react";

import "./CreatePurchaseOrder.scss";

import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";

export interface PurchaseOrderItem {
  size: string;
  color: string;
  orderedQty: string;
}

export interface PurchaseOrderFormData {
  poNumber: string;
  supplier: string;
  style: string;
  articleSku: string;
  description: string;
  batch: string;
  deliveryDate: string;
  items: PurchaseOrderItem[];
}

interface CreatePurchaseOrderDrawerProps {
  show: boolean;
  onClose: () => void;
  onSubmit: (data: PurchaseOrderFormData) => void;
}

type CommonField =
  | "poNumber"
  | "supplier"
  | "style"
  | "articleSku"
  | "description"
  | "batch"
  | "deliveryDate";

interface PurchaseOrderFormErrors {
  common: Partial<Record<CommonField, string>>;
  items: Partial<Record<keyof PurchaseOrderItem, string>>[];
}

const createEmptyItem = (): PurchaseOrderItem => ({
  size: "",
  color: "",
  orderedQty: "",
});

const createInitialForm = (): PurchaseOrderFormData => ({
  poNumber: "",
  supplier: "",
  style: "",
  articleSku: "",
  description: "",
  batch: "",
  deliveryDate: "",
  items: [createEmptyItem()],
});

const INITIAL_ERRORS: PurchaseOrderFormErrors = {
  common: {},
  items: [],
};

export default function CreatePurchaseOrderDrawer({
  show,
  onClose,
  onSubmit,
}: CreatePurchaseOrderDrawerProps) {
  const [formData, setFormData] =
    useState<PurchaseOrderFormData>(createInitialForm);

  const [errors, setErrors] = useState<PurchaseOrderFormErrors>(INITIAL_ERRORS);

  // COMMON FIELD CHANGE
  const handleChange = (field: CommonField, value: string) => {
    setFormData((previous) => ({
      ...previous,
      [field]: value,
    }));

    setErrors((previous) => ({
      ...previous,
      common: {
        ...previous.common,
        [field]: "",
      },
    }));
  };

  // SIZE VARIATION FIELD CHANGE
  const handleItemChange = (
    index: number,
    field: keyof PurchaseOrderItem,
    value: string,
  ) => {
    setFormData((previous) => ({
      ...previous,
      items: previous.items.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [field]: value } : item,
      ),
    }));

    setErrors((previous) => ({
      ...previous,
      items: previous.items.map((itemError, itemIndex) =>
        itemIndex === index ? { ...itemError, [field]: "" } : itemError,
      ),
    }));
  };

  // ADD SIZE VARIATION
  const handleAddItem = () => {
    setFormData((previous) => ({
      ...previous,
      items: [...previous.items, createEmptyItem()],
    }));

    setErrors((previous) => ({
      ...previous,
      items: [...previous.items, {}],
    }));
  };

  // REMOVE SIZE VARIATION
  const handleRemoveItem = (index: number) => {
    if (formData.items.length === 1) return;

    setFormData((previous) => ({
      ...previous,
      items: previous.items.filter((_, itemIndex) => itemIndex !== index),
    }));

    setErrors((previous) => ({
      ...previous,
      items: previous.items.filter((_, itemIndex) => itemIndex !== index),
    }));
  };

  // RESET FORM
  const resetForm = () => {
    setFormData(createInitialForm());
    setErrors(INITIAL_ERRORS);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // VALIDATION
  const validateForm = () => {
    const commonErrors: PurchaseOrderFormErrors["common"] = {};
    const itemErrors: PurchaseOrderFormErrors["items"] = [];

    const commonFields: CommonField[] = [
      "poNumber",
      "supplier",
      "style",
      "articleSku",
      "description",
      "batch",
      "deliveryDate",
    ];

    commonFields.forEach((field) => {
      const value = String(formData[field] ?? "");

      if (!value.trim()) {
        commonErrors[field] = "This field is /*  required */.";
      }
    });

    formData.items.forEach((item) => {
      const itemError: Partial<Record<keyof PurchaseOrderItem, string>> = {};

      if (!String(item.size ?? "").trim()) {
        itemError.size = "Size is /*  required */.";
      }

      if (!String(item.color ?? "").trim()) {
        itemError.color = "Color is /*  required */.";
      }

      const quantity = Number(item.orderedQty);

      if (!String(item.orderedQty ?? "").trim()) {
        itemError.orderedQty = "Quantity is /*  required */.";
      } else if (!Number.isFinite(quantity) || quantity <= 0) {
        itemError.orderedQty = "Enter a quantity greater than zero.";
      }

      itemErrors.push(itemError);
    });

    setErrors({
      common: commonErrors,
      items: itemErrors,
    });

    const hasCommonErrors = Object.keys(commonErrors).length > 0;

    const hasItemErrors = itemErrors.some(
      (itemError) => Object.keys(itemError).length > 0,
    );

    return !hasCommonErrors && !hasItemErrors;
  };

  // SUBMIT
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!validateForm()) return;

    const cleanedData: PurchaseOrderFormData = {
      ...formData,
      poNumber: formData.poNumber.trim(),
      supplier: formData.supplier.trim(),
      style: formData.style.trim(),
      articleSku: formData.articleSku.trim(),
      description: formData.description.trim(),
      batch: formData.batch.trim(),
      items: formData.items.map((item) => ({
        size: String(item.size ?? "").trim(),
        color: String(item.color ?? "").trim(),
        orderedQty: String(item.orderedQty ?? "").trim(),
      })),
    };

    onSubmit(cleanedData);
    resetForm();
  };

  // TOTAL QUANTITY
  const totalQuantity = formData.items.reduce(
    (total, item) => total + (Number(item.orderedQty) || 0),
    0,
  );

  return (
    <CommonModal
      show={show}
      onClose={handleClose}
      variant="drawer"
      width={800}
      headerIcon={<FilePlus2 size={22} />}
      title="Create Purchase Order"
      subtitle="Add purchase order information and product size variations."
      footer={
        <div className="create-po-footer">
          <button
            type="button"
            className="btn create-po-cancel-btn"
            onClick={handleClose}
          >
            <X size={17} />
            Cancel
          </button>

          <button
            type="submit"
            form="create-purchase-order-form"
            className="btn create-po-submit-btn"
          >
            <PackagePlus size={18} />
            Create Purchase Order
          </button>
        </div>
      }
      footerClassName="create-po-modal-footer"
      bodyClassName="create-po-modal-body"
      ariaLabel="Create purchase order"
    >
      <form
        id="create-purchase-order-form"
        onSubmit={handleSubmit}
        className="create-po-form"
      >
        {/* PURCHASE ORDER INFORMATION */}

        <div className="create-po-section-heading">
          <div className="create-po-section-icon">
            <FilePlus2 size={19} />
          </div>

          <div>
            <h6>Purchase Order Information</h6>
            <p>Enter the basic purchase order details.</p>
          </div>
        </div>

        <div className="row g-3">
          <div className="col-md-6">
            <CommonInput
              label="PO Number"
              placeholder="e.g. PO-2026-001"
              value={formData.poNumber}
              onChange={(event) => handleChange("poNumber", event.target.value)}
              error={errors.common.poNumber}
              /*  required */
            />
          </div>

          <div className="col-md-6">
            <CommonInput
              label="Supplier Name"
              placeholder="Enter supplier name"
              value={formData.supplier}
              onChange={(event) => handleChange("supplier", event.target.value)}
              error={errors.common.supplier}
              /*  required */
            />
          </div>

          <div className="col-md-6">
            <CommonInput
              label="Style Number"
              placeholder="Enter style number"
              value={formData.style}
              onChange={(event) => handleChange("style", event.target.value)}
              error={errors.common.style}
              /*  required */
            />
          </div>

          <div className="col-md-6">
            <CommonInput
              label="Article SKU"
              placeholder="Enter article SKU"
              value={formData.articleSku}
              onChange={(event) =>
                handleChange("articleSku", event.target.value)
              }
              error={errors.common.articleSku}
              /*  required */
            />
          </div>

          <div className="col-12">
            <label htmlFor="po-description" className="create-po-field-label">
              Product Description 
            </label>

            <textarea
              id="po-description"
              className={`form-control create-po-textarea ${
                errors.common.description ? "is-invalid" : ""
              }`}
              placeholder="Enter product description"
              rows={3}
              value={formData.description}
              onChange={(event) =>
                handleChange("description", event.target.value)
              }
            />

            {errors.common.description && (
              <small className="create-po-error">
                {errors.common.description}
              </small>
            )}
          </div>
        </div>

        {/* SIZE AND COLOR VARIATIONS */}

        <div className="create-po-variation-section">
          <div className="create-po-section-heading create-po-section-heading--second">
            <div className="create-po-section-icon">
              <PackagePlus size={19} />
            </div>

            <div>
              <h6>Size & Color Variations</h6>
              <p>
                Add separate quantities for each size and color combination.
              </p>
            </div>
          </div>

          {/* SUMMARY */}

          <div className="create-po-variation-summary">
            <div>
              <span>Total Variations</span>
              <strong>{formData.items.length}</strong>
            </div>

            <div>
              <span>Total Order Quantity</span>
              <strong>{totalQuantity.toLocaleString("en-IN")}</strong>
            </div>
          </div>

          {/* VARIATION ROWS */}

          <div className="create-po-variation-list">
            {formData.items.map((item, index) => (
              <div className="create-po-variation-card" key={index}>
                <div className="create-po-variation-header">
                  <div className="create-po-variation-title">
                    <span className="create-po-variation-number">
                      {String(index + 1).padStart(2, "0")}
                    </span>

                    <div>
                      <h6>Variation {index + 1}</h6>
                      <p>Size, color and quantity details</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    className="create-po-remove-btn"
                    onClick={() => handleRemoveItem(index)}
                    disabled={formData.items.length === 1}
                    title="Remove variation"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <div className="row g-3 align-items-start">
                  <div className="col-md-4">
                    <CommonInput
                      label="Size"
                      placeholder="e.g. S, M, L, XL"
                      value={item.size}
                      onChange={(event) =>
                        handleItemChange(index, "size", event.target.value)
                      }
                      error={errors.items[index]?.size}
                      /*  required */
                    />
                  </div>

                  <div className="col-md-4">
                    <CommonInput
                      label="Color"
                      placeholder="e.g. Blue, Black"
                      value={item.color}
                      onChange={(event) =>
                        handleItemChange(index, "color", event.target.value)
                      }
                      error={errors.items[index]?.color}
                      /*  required */
                    />
                  </div>

                  <div className="col-md-4">
                    <CommonInput
                      label="Ordered Quantity"
                      type="number"
                      min="1"
                      placeholder="Enter quantity"
                      value={item.orderedQty}
                      onChange={(event) =>
                        handleItemChange(
                          index,
                          "orderedQty",
                          event.target.value,
                        )
                      }
                      error={errors.items[index]?.orderedQty}
                      /*  required */
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            type="button"
            className="create-po-add-variation-btn"
            onClick={handleAddItem}
          >
            <Plus size={17} />
            Add Size / Color Variation
          </button>
        </div>

        {/* BATCH AND DELIVERY INFORMATION */}

        <div className="create-po-section-heading create-po-section-heading--second">
          <div className="create-po-section-icon">
            <PackagePlus size={19} />
          </div>

          <div>
            <h6>Batch & Delivery Information</h6>
            <p>Enter the common batch number and expected delivery date.</p>
          </div>
        </div>

        <div className="row g-3">
          <div className="col-md-6">
            <CommonInput
              label="Batch / Lot Number"
              placeholder="Enter batch number"
              value={formData.batch}
              onChange={(event) => handleChange("batch", event.target.value)}
              error={errors.common.batch}
              /*  required */
            />
          </div>

          <div className="col-md-6">
            <CommonInput
              label="Delivery Date"
              type="date"
              value={formData.deliveryDate}
              onChange={(event) =>
                handleChange("deliveryDate", event.target.value)
              }
              error={errors.common.deliveryDate}
              /*  required */
            />
          </div>
        </div>
      </form>
    </CommonModal>
  );
}
