import {
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import {
  UserRound,
  KeyRound,
  Bell,
  SlidersHorizontal,
  Camera,
  Save,
  Eye,
  EyeOff,
  Settings2,
  Plug,
  Server,
  Plus,
  Pencil,
  Trash2,
  X,
  Factory,
  Tags,
  ShieldCheck,
  Clock3,
  LayoutGrid,
  ScanLine,
  CircleAlert,
  CheckCircle2,
  Copy,
  ExternalLink,
} from "lucide-react";

import "./SettingsPage.scss";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

type Tab =
  | "profile"
  | "security"
  | "notifications"
  | "api"
  | "masters"
  | "preferences";

type MasterItem = {
  id: number;
  name: string;
  code: string;
  description: string;
  active: boolean;
};
type MasterKind = "station" | "defect";

const tabs: {
  id: Tab;
  label: string;
  note: string;
  icon: typeof UserRound;
  color: string;
}[] = [
  {
    id: "profile",
    label: "User Profile",
    note: "User identity and contact details",
    icon: UserRound,
    color: "blue",
  },
  {
    id: "security",
    label: "Security",
    note: "Password and session protection",
    icon: KeyRound,
    color: "violet",
  },
  {
    id: "notifications",
    label: "Notifications",
    note: "Operational alerts and updates",
    icon: Bell,
    color: "amber",
  },
  {
    id: "api",
    label: "API Configuration",
    note: "Service endpoints and integration setup",
    icon: Plug,
    color: "teal",
  },
/*   {
    id: "masters",
    label: "Master Settings",
    note: "Stations, defect categories and masters",
    icon: Settings2,
    color: "green",
  }, */
  {
    id: "preferences",
    label: "Preferences",
    note: "Production workflow defaults",
    icon: SlidersHorizontal,
    color: "orange",
  },
];

const timezoneOptions = [
  { label: "India Standard Time (IST)", value: "Asia/Kolkata" },
  { label: "UTC", value: "UTC" },
  { label: "Singapore Time", value: "Asia/Singapore" },
];
const dateOptions = [
  { label: "DD/MM/YYYY", value: "DD/MM/YYYY" },
  { label: "MM/DD/YYYY", value: "MM/DD/YYYY" },
  { label: "YYYY-MM-DD", value: "YYYY-MM-DD" },
];
const rowsOptions = [
  { label: "10 rows", value: "10" },
  { label: "25 rows", value: "25" },
  { label: "50 rows", value: "50" },
  { label: "100 rows", value: "100" },
];
const landingOptions = [
  { label: "Production Dashboard", value: "dashboard" },
  { label: "Rework Orders", value: "rework" },
  { label: "Purchase Orders", value: "purchase-orders" },
  { label: "QR Scanner", value: "qr-scanner" },
];
const stationSeed: MasterItem[] = [
  {
    id: 1,
    name: "Cutting",
    code: "ST-CUT",
    description: "Fabric cutting and preparation",
    active: true,
  },
  {
    id: 2,
    name: "Stitching",
    code: "ST-STI",
    description: "Garment stitching operations",
    active: true,
  },
  {
    id: 3,
    name: "Finishing",
    code: "ST-FIN",
    description: "Trimming, ironing and finishing",
    active: true,
  },
  {
    id: 4,
    name: "Quality Check",
    code: "ST-QC",
    description: "In-line and final quality inspection",
    active: true,
  },
  {
    id: 5,
    name: "Packing",
    code: "ST-PACK",
    description: "Final packing and dispatch preparation",
    active: true,
  },
];
const defectSeed: MasterItem[] = [
  {
    id: 1,
    name: "Stitching Defect",
    code: "DF-STI",
    description: "Skipped stitch, loose stitch or seam issue",
    active: true,
  },
  {
    id: 2,
    name: "Fabric Defect",
    code: "DF-FAB",
    description: "Hole, stain, shade or fabric damage",
    active: true,
  },
  {
    id: 3,
    name: "Measurement Issue",
    code: "DF-MEA",
    description: "Garment measurement outside tolerance",
    active: true,
  },
  {
    id: 4,
    name: "Finishing Defect",
    code: "DF-FIN",
    description: "Thread, ironing or appearance issue",
    active: true,
  },
];

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>("profile");
  const [name, setName] = useState("System Administrator");
  const [email, setEmail] = useState("admin@penguinapparels.com");
  const [phone, setPhone] = useState("+91 90000 00000");
  const [job, setJob] = useState("System Administrator");
  const [department, setDepartment] = useState("Production Operations");
  const [photo, setPhoto] = useState("");
  const photoRef = useRef<HTMLInputElement>(null);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [notice, setNotice] = useState({
    email: true,
    inApp: true,
    rework: true,
    quality: true,
    production: true,
    purchaseOrders: false,
    system: true,
  });

  const [apiBaseUrl, setApiBaseUrl] = useState(
    "https://api.penguinapparels.com/v1",
  );
  const [apiTimeout, setApiTimeout] = useState("30000");
  const [apiEnvironment, setApiEnvironment] = useState("production");
  const [apiVersion, setApiVersion] = useState("v1");
  const [apiKey, setApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiStatus, setApiStatus] = useState("");

  const [stations, setStations] = useState<MasterItem[]>(stationSeed);
  const [defects, setDefects] = useState<MasterItem[]>(defectSeed);
  const [masterKind, setMasterKind] = useState<MasterKind>("station");
  const [masterModal, setMasterModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [masterName, setMasterName] = useState("");
  const [masterCode, setMasterCode] = useState("");
  const [masterDescription, setMasterDescription] = useState("");
  const [masterError, setMasterError] = useState("");

  const [timezone, setTimezone] = useState("Asia/Kolkata");
  const [dateFormat, setDateFormat] = useState("DD/MM/YYYY");
  const [pageSize, setPageSize] = useState("25");
  const [landingPage, setLandingPage] = useState("dashboard");
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState("60");
  const [defaultWorkStatus, setDefaultWorkStatus] = useState("Assigned");
  const [qrSound, setQrSound] = useState(true);

  const [feedback, setFeedback] = useState("");
  const [error, setError] = useState("");
  const active = tabs.find((item) => item.id === tab)!;
  const masterItems = masterKind === "station" ? stations : defects;
  const activeStations = useMemo(
    () => stations.filter((item) => item.active).length,
    [stations],
  );
  const activeDefects = useMemo(
    () => defects.filter((item) => item.active).length,
    [defects],
  );

  const clearMessages = () => {
    setFeedback("");
    setError("");
  };
  const changeTab = (next: Tab) => {
    setTab(next);
    clearMessages();
    setApiStatus("");
  };

  const updatePhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose a valid image file.");
      return;
    }
    setError("");
    setPhoto(URL.createObjectURL(file));
  };

  const toggleNotice = (key: keyof typeof notice) =>
    setNotice((previous) => ({ ...previous, [key]: !previous[key] }));

  const isValidUrl = (value: string) => {
    try {
      const url = new URL(value);
      return url.protocol === "https:" || url.protocol === "http:";
    } catch {
      return false;
    }
  };

  const save = () => {
    clearMessages();
    if (tab === "profile" && (!name.trim() || !email.trim())) {
      setError("Administrator name and email are required.");
      return;
    }
    if (tab === "security") {
      if (!currentPassword || !newPassword || !confirmPassword) {
        setError("Complete all password fields.");
        return;
      }
      if (newPassword.length < 8) {
        setError("New password must contain at least 8 characters.");
        return;
      }
      if (newPassword !== confirmPassword) {
        setError("New password and confirmation do not match.");
        return;
      }
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    }
    if (tab === "api" && !isValidUrl(apiBaseUrl)) {
      setError("Enter a valid API base URL, including https://.");
      return;
    }
    setFeedback(
      `${active.label} changes are ready. Connect this action to your backend to persist them.`,
    );
  };

  const openMasterModal = (kind: MasterKind, item?: MasterItem) => {
    setMasterKind(kind);
    setEditingId(item?.id ?? null);
    setMasterName(item?.name ?? "");
    setMasterCode(item?.code ?? "");
    setMasterDescription(item?.description ?? "");
    setMasterError("");
    setMasterModal(true);
  };

  const saveMaster = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMasterError("");
    if (!masterName.trim() || !masterCode.trim()) {
      setMasterError("Name and code are required.");
      return;
    }
    const list = masterKind === "station" ? stations : defects;
    const duplicate = list.some(
      (item) =>
        item.id !== editingId &&
        (item.name.toLowerCase() === masterName.trim().toLowerCase() ||
          item.code.toLowerCase() === masterCode.trim().toLowerCase()),
    );
    if (duplicate) {
      setMasterError("A record with this name or code already exists.");
      return;
    }
    const setter = masterKind === "station" ? setStations : setDefects;
    setter((previous) =>
      editingId === null
        ? [
            ...previous,
            {
              id: Date.now(),
              name: masterName.trim(),
              code: masterCode.trim().toUpperCase(),
              description: masterDescription.trim(),
              active: true,
            },
          ]
        : previous.map((item) =>
            item.id === editingId
              ? {
                  ...item,
                  name: masterName.trim(),
                  code: masterCode.trim().toUpperCase(),
                  description: masterDescription.trim(),
                }
              : item,
          ),
    );
    setMasterModal(false);
    setFeedback(
      `${masterKind === "station" ? "Assign station" : "Defect category"} ${editingId === null ? "added" : "updated"} in this page.`,
    );
  };

  const deleteMaster = (kind: MasterKind, id: number) => {
    const label = kind === "station" ? "station" : "defect category";
    if (!window.confirm(`Delete this ${label}?`)) return;
    if (kind === "station")
      setStations((previous) => previous.filter((item) => item.id !== id));
    else setDefects((previous) => previous.filter((item) => item.id !== id));
    setFeedback(
      `${label[0].toUpperCase()}${label.slice(1)} removed from this page.`,
    );
  };

  const toggleMasterActive = (kind: MasterKind, id: number) => {
    const setter = kind === "station" ? setStations : setDefects;
    setter((previous) =>
      previous.map((item) =>
        item.id === id ? { ...item, active: !item.active } : item,
      ),
    );
  };

  const validateApi = () => {
    setApiStatus("");
    if (!isValidUrl(apiBaseUrl)) {
      setApiStatus("Enter a valid http:// or https:// endpoint.");
      return;
    }
    setApiStatus(
      "URL format looks valid. This does not contact or authenticate with the API.",
    );
  };

  const copyApiUrl = async () => {
    try {
      await navigator.clipboard.writeText(apiBaseUrl);
      setApiStatus("API base URL copied.");
    } catch {
      setApiStatus("Clipboard access is unavailable in this browser.");
    }
  };

  const renderMasterTable = (kind: MasterKind, items: MasterItem[]) => (
    <div className="settings-master-table-wrap">
      <table className="settings-master-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Code</th>
            <th>Description</th>
            <th>Status</th>
            <th className="action-col">Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td data-label="Name">
                <b>{item.name}</b>
              </td>
              <td data-label="Code">
                <span className="settings-code">{item.code}</span>
              </td>
              <td data-label="Description" className="description-cell">
                {item.description || "—"}
              </td>
              <td data-label="Status">
                <button
                  type="button"
                  className={`settings-status ${item.active ? "enabled" : "disabled"}`}
                  onClick={() => toggleMasterActive(kind, item.id)}
                >
                  <i />
                  {item.active ? "Active" : "Inactive"}
                </button>
              </td>
              <td data-label="Actions" className="action-cell">
                <div className="settings-row-actions">
                  <button
                    type="button"
                    aria-label={`Edit ${item.name}`}
                    onClick={() => openMasterModal(kind, item)}
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    className="danger"
                    aria-label={`Delete ${item.name}`}
                    onClick={() => deleteMaster(kind, item.id)}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {items.length === 0 && (
            <tr className="settings-empty-row">
              <td colSpan={5} className="settings-empty">
                No records found. Add your first item.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="settings-page">
      <CommonPageHeader
        icon={<SlidersHorizontal size={22} />}
        title="Settings & Configuration"
        subtitle="Manage administrator details, production masters, integrations and workflow defaults."
      />

      <div className="settings-layout">
        <aside className="settings-sidebar">
          <span className="settings-overline">CONFIGURATION</span>
          {tabs.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                className={`settings-nav ${tab === item.id ? "active" : ""} tone-${item.color}`}
                onClick={() => changeTab(item.id)}
              >
                <span className="settings-nav-icon">
                  <Icon size={19} />
                </span>
                <span className="settings-nav-copy">
                  <b>{item.label}</b>
                  <small>{item.note}</small>
                </span>
                {tab === item.id && <span className="settings-nav-indicator" />}
              </button>
            );
          })}
          <div className="settings-tip">
            <ShieldCheck size={21} />
            <b>Administrator controls</b>
            <p>
              Changes to production masters can affect assignment, rework and
              quality workflows.
            </p>
          </div>
        </aside>

        <main className="settings-panel">
          <header className="settings-panel-head">
            <div>
              <small>ADMINISTRATION / {active.label.toUpperCase()}</small>
              <h2>{active.label}</h2>
              <p>{active.note}</p>
            </div>
            <span className={`settings-head-icon tone-${active.color}`}>
              <active.icon size={23} />
            </span>
          </header>

          {tab === "profile" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>User profile</h3>
                  <p className="settings-description">
                    Update the administrator identity used across Penguin
                    Apparels RMS.
                  </p>
                </div>
                <span className="section-symbol blue">
                  <UserRound size={20} />
                </span>
              </div>
              <div className="settings-photo-row">
                <div className="settings-avatar">
                  {photo ? (
                    <img src={photo} alt="Administrator profile preview" />
                  ) : (
                    <b>AD</b>
                  )}
                </div>
                <div className="photo-copy">
                  <b>Profile photo</b>
                  <p>
                    Use a clear JPG, PNG or WEBP image. Recommended square
                    image.
                  </p>
                  <button
                    className="settings-light-btn"
                    type="button"
                    onClick={() => photoRef.current?.click()}
                  >
                    <Camera size={16} /> Upload photo
                  </button>
                  <input
                    ref={photoRef}
                    hidden
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={updatePhoto}
                  />
                </div>
                {photo && (
                  <button
                    type="button"
                    className="settings-remove-photo"
                    onClick={() => setPhoto("")}
                  >
                    Remove photo
                  </button>
                )}
              </div>
              <div className="settings-fields">
                <CommonInput
                  label="Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter administrator name"
                  required
                />
                <CommonInput
                  label="Official email address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@penguinapparels.com"
                  required
                />
                <CommonInput
                  label="Contact number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Enter contact number"
                />
                <CommonInput
                  label="Role"
                  value={job}
                  onChange={(e) => setJob(e.target.value)}
                  placeholder="e.g. System Administrator"
                  disabled
                />
                <CommonInput
                  label="Department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="e.g. Production Operations"
                />
                <CommonInput
                  label="Employee ID"
                  value="PENG-ADM-001"
                  disabled
                />
              </div>
              <div className="settings-callout info">
                <ShieldCheck size={20} />
                <p>
                  <b>Administrator account</b>
                  <br />
                  Role permissions and access scope should be managed through
                  the user and role administration module.
                </p>
              </div>
            </section>
          )}

          {tab === "security" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>Password & session security</h3>
                  <p className="settings-description">
                    Keep administrator access protected with a strong password.
                  </p>
                </div>
                <span className="section-symbol violet">
                  <KeyRound size={20} />
                </span>
              </div>
              <div className="settings-fields">
                <CommonInput
                  label="Current password"
                  type={showPassword ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  required
                />
                <CommonInput
                  label="New password"
                  type={showPassword ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  required
                />
                <CommonInput
                  label="Confirm new password"
                  type={showPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  required
                />
              </div>
              <button
                type="button"
                className="settings-text-btn"
                onClick={() => setShowPassword((value) => !value)}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                {showPassword ? "Hide passwords" : "Show passwords"}
              </button>
              <div className="settings-security-grid">
                <div>
                  <ShieldCheck size={20} />
                  <b>Strong password</b>
                  <p>
                    Use at least 8 characters with a mix of letters, numbers and
                    symbols.
                  </p>
                </div>
                <div>
                  <Clock3 size={20} />
                  <b>Session handling</b>
                  <p>
                    Sign out after completing work on shared production-floor
                    devices.
                  </p>
                </div>
              </div>
              <div className="settings-callout warning">
                <CircleAlert size={20} />
                <p>
                  Two-factor authentication and active-session management should
                  be enabled through your authentication service.
                </p>
              </div>
            </section>
          )}

          {tab === "notifications" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>Operational notifications</h3>
                  <p className="settings-description">
                    Choose which production and administration events should
                    notify you.
                  </p>
                </div>
                <span className="section-symbol amber">
                  <Bell size={20} />
                </span>
              </div>
              {(
                [
                  [
                    "email",
                    "Email notifications",
                    "Send selected alerts to the administrator email.",
                  ],
                  [
                    "inApp",
                    "In-app notifications",
                    "Display alerts in the RMS notification centre.",
                  ],
                  [
                    "rework",
                    "Rework order updates",
                    "New assignments, status changes and rework completion.",
                  ],
                  [
                    "quality",
                    "Quality inspection alerts",
                    "QA failures, inspection results and repeated defects.",
                  ],
                  [
                    "production",
                    "Production station alerts",
                    "Station assignment changes and production bottlenecks.",
                  ],
                  [
                    "purchaseOrders",
                    "Purchase order updates",
                    "PO approval, delivery and supplier status changes.",
                  ],
                  [
                    "system",
                    "System announcements",
                    "Maintenance notices and important administrator messages.",
                  ],
                ] as const
              ).map(([key, label, desc]) => (
                <div className="settings-toggle-row" key={key}>
                  <div>
                    <b>{label}</b>
                    <p>{desc}</p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={notice[key]}
                    aria-label={label}
                    className={`settings-switch ${notice[key] ? "on" : ""}`}
                    onClick={() => toggleNotice(key)}
                  >
                    <i />
                  </button>
                </div>
              ))}
            </section>
          )}

          {tab === "api" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>API connection settings</h3>
                  <p className="settings-description">
                    Configure the RMS service endpoint and request behaviour.
                  </p>
                </div>
                <span className="section-symbol teal">
                  <Plug size={20} />
                </span>
              </div>
              <div className="settings-api-banner">
                <span className="api-banner-icon">
                  <Server size={21} />
                </span>
                <div className="api-banner-copy">
                  <b>Backend service configuration</b>
                  <p>
                    Keep environment-specific endpoints in deployment
                    configuration. Do not expose private keys in frontend code.
                  </p>
                </div>
                <span className="api-env">{apiEnvironment.toUpperCase()}</span>
              </div>
              <div className="settings-fields">
                <CommonSelect
                  label="Environment"
                  options={[
                    { label: "Development", value: "development" },
                    { label: "Staging", value: "staging" },
                    { label: "Production", value: "production" },
                  ]}
                  value={apiEnvironment}
                  onChange={(v) => setApiEnvironment(String(v ?? "production"))}
                />
                <CommonSelect
                  label="API version"
                  options={[
                    { label: "Version 1 (v1)", value: "v1" },
                    { label: "Version 2 (v2)", value: "v2" },
                  ]}
                  value={apiVersion}
                  onChange={(v) => setApiVersion(String(v ?? "v1"))}
                />
                <div className="settings-api-url">
                  <CommonInput
                    label="API base URL"
                    value={apiBaseUrl}
                    onChange={(e) => setApiBaseUrl(e.target.value)}
                    placeholder="https://api.example.com/v1"
                  />
                  <button
                    type="button"
                    aria-label="Copy API URL"
                    onClick={copyApiUrl}
                  >
                    <Copy size={16} />
                  </button>
                </div>
                <CommonSelect
                  label="Request timeout"
                  options={[
                    { label: "15 seconds", value: "15000" },
                    { label: "30 seconds", value: "30000" },
                    { label: "60 seconds", value: "60000" },
                    { label: "120 seconds", value: "120000" },
                  ]}
                  value={apiTimeout}
                  onChange={(v) => setApiTimeout(String(v ?? "30000"))}
                />
                <div className="settings-api-key">
                  <CommonInput
                    label="API key (optional)"
                    type={showApiKey ? "text" : "password"}
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Enter key only if your integration requires one"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey((value) => !value)}
                    aria-label={showApiKey ? "Hide API key" : "Show API key"}
                  >
                    {showApiKey ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <div className="settings-api-actions">
                <button
                  type="button"
                  className="settings-light-btn"
                  onClick={validateApi}
                >
                  <CheckCircle2 size={16} /> Validate URL format
                </button>
                <span>
                  <ExternalLink size={14} /> URL validation only — no network
                  request is made.
                </span>
              </div>
              {apiStatus && (
                <div
                  className={`settings-api-status ${apiStatus.startsWith("Enter") ? "error" : "success"}`}
                >
                  {apiStatus}
                </div>
              )}
              <div className="settings-callout warning">
                <ShieldCheck size={20} />
                <p>
                  <b>Security recommendation</b>
                  <br />
                  Do not store production secrets in browser state or
                  localStorage. Keep API credentials on the server and load
                  public endpoint configuration from environment variables.
                </p>
              </div>
            </section>
          )}

          {tab === "masters" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>Production master data</h3>
                  <p className="settings-description">
                    Maintain assignable stations and standardized defect
                    categories used by rework and quality workflows.
                  </p>
                </div>
                <span className="section-symbol green">
                  <Settings2 size={20} />
                </span>
              </div>
              <div className="settings-master-summary">
                <div>
                  <span className="summary-icon green">
                    <Factory size={19} />
                  </span>
                  <div>
                    <small>Active stations</small>
                    <b>{activeStations}</b>
                  </div>
                </div>
                <div>
                  <span className="summary-icon orange">
                    <Tags size={19} />
                  </span>
                  <div>
                    <small>Active defect categories</small>
                    <b>{activeDefects}</b>
                  </div>
                </div>
              </div>
              <div className="settings-master-tabs">
                <button
                  type="button"
                  className={masterKind === "station" ? "active station" : ""}
                  onClick={() => setMasterKind("station")}
                >
                  <Factory size={17} /> Assign Stations{" "}
                  <span>{stations.length}</span>
                </button>
                <button
                  type="button"
                  className={masterKind === "defect" ? "active defect" : ""}
                  onClick={() => setMasterKind("defect")}
                >
                  <Tags size={17} /> Defect Categories{" "}
                  <span>{defects.length}</span>
                </button>
              </div>
              <div className="settings-master-toolbar">
                <div>
                  <b>
                    {masterKind === "station"
                      ? "Station directory"
                      : "Defect category directory"}
                  </b>
                  <p>
                    {masterKind === "station"
                      ? "Stations available for operator and rework assignment."
                      : "Defect types available during QR registration and quality checks."}
                  </p>
                </div>
                <button
                  type="button"
                  className="settings-add-btn"
                  onClick={() => openMasterModal(masterKind)}
                >
                  <Plus size={16} /> Add{" "}
                  {masterKind === "station" ? "station" : "category"}
                </button>
              </div>
              {renderMasterTable(masterKind, masterItems)}
              <div className="settings-callout warning">
                <CircleAlert size={20} />
                <p>
                  These sample master records are maintained in page state only.
                  Before production use, connect create, update, activate and
                  delete actions to your master-data APIs.
                </p>
              </div>
            </section>
          )}

          {tab === "preferences" && (
            <section className="settings-section">
              <div className="settings-section-title">
                <div>
                  <h3>RMS workflow preferences</h3>
                  <p className="settings-description">
                    Set defaults that make day-to-day production, rework and QR
                    operations consistent.
                  </p>
                </div>
                <span className="section-symbol orange">
                  <SlidersHorizontal size={20} />
                </span>
              </div>
              <div className="settings-preference-group">
                <h4>
                  <LayoutGrid size={18} /> Workspace defaults
                </h4>
                <div className="settings-fields">
                  <CommonSelect
                    label="Default landing page"
                    options={landingOptions}
                    value={landingPage}
                    onChange={(v) => setLandingPage(String(v ?? "dashboard"))}
                  />
                  <CommonSelect
                    label="Default table page size"
                    options={rowsOptions}
                    value={pageSize}
                    onChange={(v) => setPageSize(String(v ?? "25"))}
                  />
                  <CommonSelect
                    label="Timezone"
                    options={timezoneOptions}
                    value={timezone}
                    onChange={(v) => setTimezone(String(v ?? "Asia/Kolkata"))}
                  />
                  <CommonSelect
                    label="Date format"
                    options={dateOptions}
                    value={dateFormat}
                    onChange={(v) => setDateFormat(String(v ?? "DD/MM/YYYY"))}
                  />
                </div>
              </div>
              <div className="settings-preference-group">
                <h4>
                  <Factory size={18} /> Production & rework defaults
                </h4>
                <div className="settings-fields">
                  <CommonSelect
                    label="Default new rework status"
                    options={[
                      { label: "Assigned", value: "Assigned" },
                      { label: "In Progress", value: "In Progress" },
                    ]}
                    value={defaultWorkStatus}
                    onChange={(v) =>
                      setDefaultWorkStatus(String(v ?? "Assigned"))
                    }
                  />
                  <CommonSelect
                    label="Dashboard auto-refresh interval"
                    options={[
                      { label: "30 seconds", value: "30" },
                      { label: "1 minute", value: "60" },
                      { label: "5 minutes", value: "300" },
                      { label: "10 minutes", value: "600" },
                    ]}
                    value={refreshInterval}
                    onChange={(v) => setRefreshInterval(String(v ?? "60"))}
                  />
                </div>
                <div className="settings-toggle-row">
                  <div>
                    <b>Enable dashboard auto-refresh</b>
                    <p>
                      Refresh production summary data at the selected interval
                      when supported by the dashboard.
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={autoRefresh}
                    aria-label="Enable dashboard auto-refresh"
                    className={`settings-switch ${autoRefresh ? "on" : ""}`}
                    onClick={() => setAutoRefresh((value) => !value)}
                  >
                    <i />
                  </button>
                </div>
                <div className="settings-toggle-row">
                  <div>
                    <b>QR scan sound feedback</b>
                    <p>
                      Play a short confirmation sound after a successful scan
                      when supported by the scanner screen.
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={qrSound}
                    aria-label="QR scan sound feedback"
                    className={`settings-switch ${qrSound ? "on" : ""}`}
                    onClick={() => setQrSound((value) => !value)}
                  >
                    <i />
                  </button>
                </div>
              </div>
              <div className="settings-callout info">
                <ScanLine size={20} />
                <p>
                  These preferences are intended for the RMS dashboard, rework
                  assignment and QR registration flows. Each consuming page
                  should read the saved preference from your settings API.
                </p>
              </div>
            </section>
          )}

          {(error || feedback) && (
            <div className={`settings-feedback ${error ? "error" : "success"}`}>
              {error || feedback}
            </div>
          )}
          <footer className="settings-footer">
            <span>
              Settings are currently local UI state. Connect Save to your
              settings APIs to persist changes.
            </span>
            <button type="button" className="settings-save-btn" onClick={save}>
              <Save size={17} /> Save changes
            </button>
          </footer>
        </main>
      </div>

      {masterModal && (
        <div
          className="settings-modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setMasterModal(false);
          }}
        >
          <form className="settings-master-modal" onSubmit={saveMaster}>
            <header>
              <div>
                <span className={`modal-icon ${masterKind}`}>
                  {masterKind === "station" ? (
                    <Factory size={20} />
                  ) : (
                    <Tags size={20} />
                  )}
                </span>
                <div>
                  <h3>
                    {editingId === null ? "Add" : "Edit"}{" "}
                    {masterKind === "station"
                      ? "assign station"
                      : "defect category"}
                  </h3>
                  <p>Enter the master record details below.</p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close"
                onClick={() => setMasterModal(false)}
              >
                <X size={19} />
              </button>
            </header>
            <div className="modal-fields">
              <CommonInput
                label="Name"
                value={masterName}
                onChange={(e) => setMasterName(e.target.value)}
                placeholder={
                  masterKind === "station"
                    ? "e.g. Embroidery"
                    : "e.g. Printing Defect"
                }
                required
              />
              <CommonInput
                label="Code"
                value={masterCode}
                onChange={(e) => setMasterCode(e.target.value)}
                placeholder={
                  masterKind === "station" ? "e.g. ST-EMB" : "e.g. DF-PRI"
                }
                required
              />
              <div className="modal-description">
                <label>Description</label>
                <textarea
                  value={masterDescription}
                  onChange={(e) => setMasterDescription(e.target.value)}
                  rows={3}
                  placeholder="Add a short description..."
                />
              </div>
            </div>
            {masterError && (
              <p className="settings-modal-error">{masterError}</p>
            )}
            <footer>
              <button
                type="button"
                className="settings-cancel-btn"
                onClick={() => setMasterModal(false)}
              >
                Cancel
              </button>
              <button type="submit" className="settings-save-btn">
                <Save size={16} />{" "}
                {editingId === null ? "Add record" : "Save changes"}
              </button>
            </footer>
          </form>
        </div>
      )}
    </div>
  );
}