export type ReportTab = "overview" | "stations" | "qa" | "audit";

export type GarmentStatus =
  | "Registered"
  | "In Repair"
  | "Awaiting QA"
  | "Awaiting Rework"
  | "Awaiting Packing"
  | "Packed"
  | "Scrapped";

export type InspectionOutcome = "Pass" | "Reject" | "Scrap";

export type AuditType =
  | "Status Change"
  | "Assignment"
  | "Reassignment"
  | "QA Decision"
  | "Scrap Decision"
  | "Carton Created"
  | "Carton Closed"
  | "User Activity";

export type DatePreset = "7" | "30" | "90" | "custom";

export type PrintType = "handover" | "quality";

export interface ReportFilters {
  preset: DatePreset;
  from: string; // YYYY-MM-DD
  to: string; // YYYY-MM-DD
  factory: string; // "all" or factory id
}

export interface Factory {
  id: string;
  name: string;
}

export interface StationInfo {
  id: string;
  code: string;
  name: string;
  defectPool: string[];
  baseMinutes: number;
  operators: string[];
}

export interface InspectionEntry {
  outcome: InspectionOutcome;
  reason?: string;
  failedChecks: string[];
  at: string;
  inspector: string;
}

export interface GarmentReportRecord {
  id: string;
  qrId: string;
  poNumber: string;
  factoryId: string;
  registeredAt: string;
  stationId: string;
  operator: string;
  status: GarmentStatus;
  defectCategory: string;
  processMinutes: number;
  repairedAt?: string;
  turnaroundHours?: number;
  reworkCycles: number;
  inspections: InspectionEntry[];
}

export interface AuditEvent {
  id: string;
  at: string;
  factoryId: string;
  type: AuditType;
  action: string;
  reference: string;
  detail: string;
  user: string;
  role: string;
}

export interface ShiftInfo {
  id: string;
  label: string;
  startHour: number;
}
