/**
 * DEMO DATA for the Reports & Analytics module.
 * A deterministic generator produces garments + audit events so every
 * filter, chart, table, CSV and print view works without a backend.
 *
 * To go live: replace GARMENTS / AUDIT_EVENTS with API responses that follow
 * the same interfaces (types/reportTypes.ts). utils/reportMetrics.ts needs no changes.
 */
import type {
  AuditEvent,
  AuditType,
  Factory,
  GarmentReportRecord,
  GarmentStatus,
  InspectionEntry,
  ShiftInfo,
  StationInfo,
} from "../types/reportTypes";

export const HOUR = 3600000;
export const DAY = 24 * HOUR;
export const NOW = Date.now();
export const DATA_DAYS = 90;

export const FACTORIES: Factory[] = [
  { id: "FAC-01", name: "Madurai Unit 1" },
  { id: "FAC-02", name: "Tiruppur Unit 2" },
  { id: "FAC-03", name: "Coimbatore Unit 3" },
];

export const SHIFTS: ShiftInfo[] = [
  { id: "A", label: "Shift A (06:00 - 14:00)", startHour: 6 },
  { id: "B", label: "Shift B (14:00 - 22:00)", startHour: 14 },
  { id: "C", label: "Shift C (22:00 - 06:00)", startHour: 22 },
];

export const STATIONS: StationInfo[] = [
  { id: "STN-01", code: "ST-STITCH-01", name: "Stitching Repair Alpha", defectPool: ["Stitching Defect"], baseMinutes: 28, operators: ["Senthil Kumar", "Arunachalam Nathan"] },
  { id: "STN-02", code: "ST-STAIN-02", name: "Stain Removal & Wash", defectPool: ["Stain", "Color Defect"], baseMinutes: 22, operators: ["Divya Balaji", "Arunachalam Nathan"] },
  { id: "STN-03", code: "ST-FABRIC-03", name: "Fabric & Darning", defectPool: ["Fabric Damage", "Tear or Hole"], baseMinutes: 35, operators: ["Murugan Selvam", "Divya Balaji"] },
  { id: "STN-04", code: "ST-MEAS-04", name: "Measurement & Alteration", defectPool: ["Measurement Issue"], baseMinutes: 40, operators: ["Kavitha Ramasamy", "Ravi Chandran"] },
  { id: "STN-05", code: "ST-FINISH-05", name: "Final Finishing & Buttoning", defectPool: ["Missing Button/Accessory", "Color Defect"], baseMinutes: 18, operators: ["Murugan Selvam"] },
  { id: "STN-06", code: "ST-STITCH-02", name: "Stitching Repair Beta", defectPool: ["Stitching Defect", "Tear or Hole"], baseMinutes: 30, operators: ["Senthil Kumar"] },
];

export const DEFECT_CATEGORIES = [
  "Stitching Defect",
  "Stain",
  "Fabric Damage",
  "Tear or Hole",
  "Color Defect",
  "Measurement Issue",
  "Missing Button/Accessory",
];

export const CHECKLIST_ITEMS = [
  "Stitching uniformity",
  "Seam and stitch quality",
  "Stain removal",
  "Fabric reinforcement / darning",
  "Measurements within tolerance",
  "Accessories and trims",
  "Final finishing",
  "Other agreed inspection items",
];

const CATEGORY_REASONS: Record<string, string[]> = {
  "Stitching Defect": ["Stitch quality not uniform", "Thread ends not trimmed"],
  Stain: ["Stain still visible"],
  "Color Defect": ["Colour mismatch after repair"],
  "Fabric Damage": ["Darning visible on face fabric"],
  "Tear or Hole": ["Hole not fully reinforced"],
  "Measurement Issue": ["Measurement out of tolerance"],
  "Missing Button/Accessory": ["Accessory loose or missing"],
};

const REASON_CHECKS: Record<string, string[]> = {
  "Stitch quality not uniform": ["Stitching uniformity", "Seam and stitch quality"],
  "Thread ends not trimmed": ["Seam and stitch quality"],
  "Stain still visible": ["Stain removal"],
  "Colour mismatch after repair": ["Other agreed inspection items"],
  "Darning visible on face fabric": ["Fabric reinforcement / darning"],
  "Hole not fully reinforced": ["Fabric reinforcement / darning"],
  "Measurement out of tolerance": ["Measurements within tolerance"],
  "Accessory loose or missing": ["Accessories and trims"],
  "Finishing / pressing incomplete": ["Final finishing"],
};

const ALL_REASONS = Object.keys(REASON_CHECKS);
const SCRAP_REASONS = [
  "Fabric damage beyond repair",
  "Irreparable stain",
  "Measurement cannot be corrected",
];
const QA_INSPECTORS = ["Vijay Anand", "Nandhini Raj"];

/* ---------------- deterministic random helpers ---------------- */

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20260123);

const pick = <T>(items: T[]): T => items[Math.floor(rand() * items.length)];

function weighted<T>(items: Array<[T, number]>): T {
  const total = items.reduce((sum, [, w]) => sum + w, 0);
  let r = rand() * total;
  for (const [value, weight] of items) {
    r -= weight;
    if (r <= 0) return value;
  }
  return items[items.length - 1][0];
}

function pickStatus(daysAgo: number): GarmentStatus {
  if (daysAgo <= 3) {
    return weighted<GarmentStatus>([
      ["Registered", 15], ["In Repair", 20], ["Awaiting QA", 15],
      ["Awaiting Rework", 12], ["Awaiting Packing", 14], ["Packed", 20], ["Scrapped", 4],
    ]);
  }
  if (daysAgo <= 14) {
    return weighted<GarmentStatus>([
      ["Registered", 3], ["In Repair", 6], ["Awaiting QA", 6],
      ["Awaiting Rework", 8], ["Awaiting Packing", 12], ["Packed", 60], ["Scrapped", 5],
    ]);
  }
  return weighted<GarmentStatus>([
    ["Registered", 0.5], ["In Repair", 1.5], ["Awaiting QA", 2],
    ["Awaiting Rework", 3], ["Awaiting Packing", 5], ["Packed", 83], ["Scrapped", 5],
  ]);
}

const reasonFor = (category: string) =>
  rand() < 0.8 ? pick(CATEGORY_REASONS[category] ?? ALL_REASONS) : pick(ALL_REASONS);

function checksFor(reason: string): string[] {
  const checks = [...(REASON_CHECKS[reason] ?? [])];
  if (rand() < 0.15) {
    const extra = pick(CHECKLIST_ITEMS);
    if (!checks.includes(extra)) checks.push(extra);
  }
  return checks;
}

/* ---------------- garments ---------------- */

function buildGarments(): GarmentReportRecord[] {
  const out: GarmentReportRecord[] = [];

  for (let i = 0; i < 720; i++) {
    const daysAgo = Math.floor(Math.pow(rand(), 1.1) * DATA_DAYS);
    const day = new Date(NOW);
    day.setDate(day.getDate() - daysAgo);
    day.setHours(6 + Math.floor(rand() * 15), Math.floor(rand() * 60), 0, 0);
    let regMs = day.getTime();
    if (regMs > NOW - HOUR) regMs = NOW - HOUR * (1 + rand() * 4);

    const factoryId = weighted<string>([["FAC-01", 42], ["FAC-02", 33], ["FAC-03", 25]]);
    const station = pick(STATIONS);
    const operator = pick(station.operators);
    const defectCategory = pick(station.defectPool);
    const status = pickStatus(daysAgo);

    let rejects = 0;
    if (["Awaiting QA", "Awaiting Rework", "Awaiting Packing", "Packed", "Scrapped"].includes(status)) {
      rejects = weighted<number>([[0, 68], [1, 20], [2, 8], [3, 4]]);
    }
    if (status === "Awaiting Rework") rejects = Math.max(1, rejects);
    if (status === "In Repair") rejects = rand() < 0.3 ? 1 : 0;

    const repaired = status !== "Registered" && !(status === "In Repair" && rejects === 0);
    const repairedMs = repaired
      ? Math.min(regMs + (2 + rand() * 8) * HOUR, NOW - 10 * 60000)
      : undefined;

    const inspections: InspectionEntry[] = [];
    let cursor = repairedMs ?? regMs;
    const stamp = (minH: number, spanH: number) => {
      cursor = Math.min(cursor + (minH + rand() * spanH) * HOUR, NOW - 5 * 60000);
      return new Date(cursor).toISOString();
    };

    let prevReason: string | undefined;
    for (let r = 0; r < rejects; r++) {
      const reason = prevReason && rand() < 0.5 ? prevReason : reasonFor(defectCategory);
      prevReason = reason;
      inspections.push({
        outcome: "Reject",
        reason,
        failedChecks: checksFor(reason),
        at: stamp(r === 0 ? 1 : 5, r === 0 ? 6 : 10),
        inspector: pick(QA_INSPECTORS),
      });
    }
    if (status === "Awaiting Packing" || status === "Packed") {
      inspections.push({
        outcome: "Pass",
        failedChecks: [],
        at: stamp(rejects === 0 ? 1 : 5, rejects === 0 ? 6 : 10),
        inspector: pick(QA_INSPECTORS),
      });
    }
    if (status === "Scrapped") {
      inspections.push({
        outcome: "Scrap",
        reason: pick(SCRAP_REASONS),
        failedChecks: [],
        at: stamp(2, 8),
        inspector: pick(QA_INSPECTORS),
      });
    }

    const pass = inspections.find((x) => x.outcome === "Pass");
    const turnaroundHours = pass
      ? Math.round(((Date.parse(pass.at) - regMs) / HOUR) * 10) / 10
      : undefined;

    out.push({
      id: `GMT-${10001 + i}`,
      qrId: `QR-${700100 + i}`,
      poNumber: `PO-${2401 + Math.floor(rand() * 14)}`,
      factoryId,
      registeredAt: new Date(regMs).toISOString(),
      stationId: station.id,
      operator,
      status,
      defectCategory,
      processMinutes: Math.round(station.baseMinutes * (0.7 + rand() * 0.75)),
      repairedAt: repairedMs ? new Date(repairedMs).toISOString() : undefined,
      turnaroundHours,
      reworkCycles: inspections.filter((x) => x.outcome === "Reject").length,
      inspections,
    });
  }

  return out;
}

/* ---------------- audit events ---------------- */

interface Actor {
  name: string;
  role: string;
}

const REGISTRAR: Actor = { name: "Ananya Ramesh", role: "Rework Inspector" };
const MANAGER: Actor = { name: "Kavitha Ramasamy", role: "Production Manager" };
const PACKER: Actor = { name: "Murugan Selvam", role: "Packing Operator" };

function buildAudit(garments: GarmentReportRecord[]): AuditEvent[] {
  const events: AuditEvent[] = [];
  let seq = 1;
  let cartonSeq = 2001;

  const add = (
    at: number,
    factoryId: string,
    type: AuditType,
    action: string,
    reference: string,
    detail: string,
    actor: Actor,
  ) => {
    if (at > NOW) return;
    events.push({
      id: `EVT-${String(seq++).padStart(6, "0")}`,
      at: new Date(at).toISOString(),
      factoryId,
      type,
      action,
      reference,
      detail,
      user: actor.name,
      role: actor.role,
    });
  };

  const codeOf = (id: string) => STATIONS.find((s) => s.id === id)?.code ?? id;

  garments.forEach((g) => {
    const reg = Date.parse(g.registeredAt);
    const code = codeOf(g.stationId);

    add(reg, g.factoryId, "Status Change", "Registered", g.id, `QR scanned ${g.qrId} for ${g.poNumber}`, REGISTRAR);
    add(reg + 20 * 60000, g.factoryId, "Assignment", "Assigned", g.id, `Assigned to ${code} - ${g.operator}`, REGISTRAR);

    if (g.status !== "Registered" && rand() < 0.12) {
      const other = pick(STATIONS.filter((s) => s.id !== g.stationId));
      add(reg + HOUR, g.factoryId, "Reassignment", "Reassigned", g.id, `Moved from ${code} to ${other.code}`, MANAGER);
    }

    if (g.repairedAt) {
      add(Date.parse(g.repairedAt), g.factoryId, "Status Change", "Repair Completed", g.id, `Repair completed at ${code}`, {
        name: g.operator,
        role: "Station Operator",
      });
    }

    g.inspections.forEach((ins) => {
      const at = Date.parse(ins.at);
      const actor: Actor = { name: ins.inspector, role: "QA Inspector" };
      if (ins.outcome === "Pass") {
        add(at, g.factoryId, "QA Decision", "QA Approved", g.id, "All checklist items passed", actor);
      } else if (ins.outcome === "Reject") {
        add(at, g.factoryId, "QA Decision", "QA Rejected", g.id, `Rejected: ${ins.reason}`, actor);
        add(at + 10 * 60000, g.factoryId, "Status Change", "Sent for Rework", g.id, `Returned to ${code} for rework`, actor);
      } else {
        add(at, g.factoryId, "Scrap Decision", "Scrapped", g.id, ins.reason ?? "Scrapped", actor);
      }
    });
  });

  FACTORIES.forEach((factory) => {
    const packed = garments
      .filter((g) => g.factoryId === factory.id && g.status === "Packed")
      .map((g) => {
        const pass = g.inspections.find((x) => x.outcome === "Pass");
        return { g, at: pass ? Date.parse(pass.at) : Date.parse(g.registeredAt) };
      })
      .sort((a, b) => a.at - b.at);

    for (let i = 0; i < packed.length; i += 12) {
      const chunk = packed.slice(i, i + 12);
      const ref = `CTN-${cartonSeq++}`;
      const created = chunk[0].at + HOUR;
      const closed = chunk[chunk.length - 1].at + (1 + rand() * 4) * HOUR;

      add(created, factory.id, "Carton Created", "Carton Created", ref, `Carton opened for ${chunk[0].g.poNumber}`, PACKER);
      chunk.forEach((item, k) => {
        add(Math.max(created + (k + 1) * 4 * 60000, item.at + 20 * 60000), factory.id, "Status Change", "Packed", item.g.id, `Packed into ${ref}`, PACKER);
      });
      add(closed, factory.id, "Carton Closed", "Carton Closed", ref, `${chunk.length} garments sealed`, PACKER);
    }
  });

  const staff: Actor[] = [
    { name: "Senthil Kumar", role: "Station Operator" },
    { name: "Divya Balaji", role: "Station Operator" },
    { name: "Arunachalam Nathan", role: "Station Operator" },
    { name: "Vijay Anand", role: "QA Inspector" },
    { name: "Nandhini Raj", role: "QA Inspector" },
    PACKER,
    REGISTRAR,
    MANAGER,
  ];
  for (let d = 0; d < 60; d++) {
    staff.forEach((user) => {
      if (rand() > 0.8) return;
      const factoryId = weighted<string>([["FAC-01", 42], ["FAC-02", 33], ["FAC-03", 25]]);
      const day = new Date(NOW);
      day.setDate(day.getDate() - d);
      day.setHours(6 + Math.floor(rand() * 3), Math.floor(rand() * 60), 0, 0);
      add(day.getTime(), factoryId, "User Activity", "Login", "Session", `${user.role} signed in`, user);
      day.setHours(15 + Math.floor(rand() * 4), Math.floor(rand() * 60), 0, 0);
      add(day.getTime(), factoryId, "User Activity", "Logout", "Session", `${user.role} signed out`, user);
    });
  }

  return events.sort((a, b) => (a.at < b.at ? 1 : -1));
}

export const GARMENTS: GarmentReportRecord[] = buildGarments();
export const AUDIT_EVENTS: AuditEvent[] = buildAudit(GARMENTS);
