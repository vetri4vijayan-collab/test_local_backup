import { ChartNoAxesColumn, ClipboardCheck, ScrollText, Wrench } from "lucide-react";
import type { ReportTab } from "../types/reportTypes";

const tabs = [
  { id: "overview" as const, label: "Operational Overview", icon: ChartNoAxesColumn },
  { id: "stations" as const, label: "Station & Operator", icon: Wrench },
  { id: "qa" as const, label: "QA & Re-rework", icon: ClipboardCheck },
  { id: "audit" as const, label: "Audit & Activity", icon: ScrollText },
];

interface Props {
  activeTab: ReportTab;
  onChange: (tab: ReportTab) => void;
}

export default function ReportTabs({ activeTab, onChange }: Props) {
  return (
    <div className="rpt-tabs" role="tablist" aria-label="Report sections">
      {tabs.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          type="button"
          role="tab"
          aria-selected={activeTab === id}
          className={`rpt-tab ${activeTab === id ? "is-active" : ""}`}
          onClick={() => onChange(id)}
        >
          <Icon size={16} />
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
}
