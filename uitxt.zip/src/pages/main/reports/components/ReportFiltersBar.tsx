import { CalendarDays, RotateCcw } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

import { FACTORIES } from "../data/reportData";
import type { DatePreset, ReportFilters } from "../types/reportTypes";
import { presetFilters, toISODate } from "../utils/reportHelpers";

interface Props {
  filters: ReportFilters;
  onChange: (filters: ReportFilters) => void;
}

const presetOptions = [
  { label: "Last 7 days", value: "7" },
  { label: "Last 30 days", value: "30" },
  { label: "Last 90 days", value: "90" },
  { label: "Custom range", value: "custom" },
];

const factoryOptions = [
  { label: "All factories", value: "all" },
  ...FACTORIES.map((f) => ({ label: f.name, value: f.id })),
];

export default function ReportFiltersBar({ filters, onChange }: Props) {
  const today = toISODate(new Date());

  const changePreset = (value: string | number | null) => {
    const preset = (value ?? "30") as DatePreset;
    if (preset === "custom") onChange({ ...filters, preset });
    else onChange(presetFilters(preset, filters.factory));
  };

  return (
    <div className="rpt-filters">
      <CommonSelect
        label="Date range"
        options={presetOptions}
        value={filters.preset}
        onChange={changePreset}
      />

      <CommonInput
        type="date"
        label="From"
        value={filters.from}
        max={filters.to || today}
        leftElement={<CalendarDays size={15} />}
        onChange={(e) => onChange({ ...filters, preset: "custom", from: e.target.value })}
      />

      <CommonInput
        type="date"
        label="To"
        value={filters.to}
        min={filters.from}
        max={today}
        leftElement={<CalendarDays size={15} />}
        onChange={(e) => onChange({ ...filters, preset: "custom", to: e.target.value })}
      />

      <CommonSelect
        label="Factory"
        options={factoryOptions}
        value={filters.factory}
        onChange={(value) => onChange({ ...filters, factory: String(value ?? "all") })}
      />

      <CommonButton
        variant="ghost"
        leftIcon={<RotateCcw size={15} />}
        onClick={() => onChange(presetFilters("30"))}
        className="rpt-filters__reset"
      >
        Reset
      </CommonButton>
    </div>
  );
}
