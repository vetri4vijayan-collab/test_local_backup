import { useState } from "react";
import { ChartNoAxesColumn, FileText, Printer } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";

import PrintPreviewModal from "./components/PrintPreviewModal";
import ReportFiltersBar from "./components/ReportFiltersBar";
import ReportTabs from "./components/ReportTabs";
import AuditActivityTab from "./tabs/AuditActivityTab";
import OverviewTab from "./tabs/OverviewTab";
import QaReworkTab from "./tabs/QaReworkTab";
import StationOperatorTab from "./tabs/StationOperatorTab";
import type { PrintType, ReportFilters, ReportTab } from "./types/reportTypes";
import { presetFilters } from "./utils/reportHelpers";

import "./ReportsAnalyticsPage.scss";

export default function ReportsAnalyticsPage() {
  const [filters, setFilters] = useState<ReportFilters>(() =>
    presetFilters("30"),
  );
  const [activeTab, setActiveTab] = useState<ReportTab>("overview");
  const [printType, setPrintType] = useState<PrintType | null>(null);

  return (
    <div className="rpt-page">
      <CommonPageHeader
        className="rpt-page-header"
        icon={<ChartNoAxesColumn size={20} />}
        title="Reports & Analytics"
        subtitle="Operational, station, quality and audit reports with date range and factory filters."
        rightContent={
          <div className="rpt-header-actions">
            <CommonButton
              variant="outline"
              leftIcon={<Printer size={16} />}
              onClick={() => setPrintType("handover")}
            >
              Shift Handover
            </CommonButton>
            <CommonButton
              leftIcon={<FileText size={16} />}
              onClick={() => setPrintType("quality")}
            >
              Quality Audit Summary
            </CommonButton>
          </div>
        }
      />

      <ReportFiltersBar filters={filters} onChange={setFilters} />
      <ReportTabs activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === "overview" && <OverviewTab filters={filters} />}
      {activeTab === "stations" && <StationOperatorTab filters={filters} />}
      {activeTab === "qa" && <QaReworkTab filters={filters} />}
      {activeTab === "audit" && <AuditActivityTab filters={filters} />}

      <PrintPreviewModal
        type={printType}
        filters={filters}
        onClose={() => setPrintType(null)}
      />
    </div>
  );
}
