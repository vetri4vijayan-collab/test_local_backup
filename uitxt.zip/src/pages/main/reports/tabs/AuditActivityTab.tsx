import { useMemo, useState } from "react";
import type { ApexOptions } from "apexcharts";
import { Boxes, ClipboardCheck, GitCompareArrows, PackageCheck, ScrollText, Search, Trash2 } from "lucide-react";

import { CommonDataTable, type TableColumn } from "@/components/common/data-table";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

import ChartCard from "../components/ChartCard";
import KpiCard from "../components/KpiCard";
import ReportChart from "../components/ReportChart";
import TableCard from "../components/TableCard";
import ToneBadge from "../components/ToneBadge";
import type { AuditEvent, AuditType, ReportFilters } from "../types/reportTypes";
import { CHART, PALETTE } from "../utils/chartTheme";
import { csvName, downloadCsv, formatDateTime, formatNumber } from "../utils/reportHelpers";
import { AUDIT_TYPES, computeAudit, factoryName } from "../utils/reportMetrics";

const TYPE_TONE: Record<AuditType, "primary" | "info" | "warning" | "success" | "danger" | "secondary"> = {
  "Status Change": "info",
  Assignment: "primary",
  Reassignment: "warning",
  "QA Decision": "success",
  "Scrap Decision": "danger",
  "Carton Created": "primary",
  "Carton Closed": "success",
  "User Activity": "secondary",
};

const typeOptions = [{ label: "All activity types", value: "all" }, ...AUDIT_TYPES.map((t) => ({ label: t, value: t }))];

export default function AuditActivityTab({ filters }: { filters: ReportFilters }) {
  const data = useMemo(() => computeAudit(filters), [filters]);
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return data.events.filter(
      (e) =>
        (type === "all" || e.type === type) &&
        (!q || [e.reference, e.detail, e.user, e.action].some((v) => v.toLowerCase().includes(q))),
    );
  }, [data.events, search, type]);

  const typeOptionsChart: ApexOptions = {
    colors: PALETTE,
    legend: { show: false },
    plotOptions: { bar: { horizontal: true, distributed: true, barHeight: "60%", borderRadius: 3 } },
    dataLabels: { enabled: true },
    xaxis: { categories: data.byType.map((t) => t.type) },
  };

  const timelineOptions: ApexOptions = {
    colors: [CHART.blue, CHART.green, CHART.red, CHART.amber, CHART.slate],
    chart: { stacked: true },
    stroke: { curve: "smooth", width: 1.5 },
    fill: { type: "gradient", gradient: { opacityFrom: 0.6, opacityTo: 0.1 } },
    xaxis: { categories: data.labels, tickAmount: 10 },
  };

  const userOptions: ApexOptions = {
    colors: [CHART.teal],
    plotOptions: { bar: { columnWidth: "50%", borderRadius: 4 } },
    xaxis: { categories: data.topUsers.map((u) => u.name.split(" ")[0]) },
  };

  const columns: TableColumn<AuditEvent>[] = [
    { field: "at", header: "Timestamp", minWidth: "170px", sortable: true, body: (r) => formatDateTime(r.at) },
    { field: "type", header: "Event type", minWidth: "150px", body: (r) => <ToneBadge label={r.type} tone={TYPE_TONE[r.type]} /> },
    { field: "action", header: "Action", minWidth: "140px" },
    { field: "reference", header: "Garment / carton", minWidth: "130px" },
    { field: "detail", header: "Detail", minWidth: "280px" },
    {
      field: "user",
      header: "User",
      minWidth: "170px",
      body: (r) => (
        <div className="rpt-cell">
          <strong>{r.user}</strong>
          <small>{r.role}</small>
        </div>
      ),
    },
    { field: "factoryId", header: "Factory", minWidth: "140px", body: (r) => factoryName(r.factoryId) },
  ];

  const exportCsv = () =>
    downloadCsv(
      csvName("audit-activity-log", filters),
      ["Timestamp", "Event type", "Action", "Garment / carton", "Detail", "User", "Role", "Factory"],
      rows.map((r) => [formatDateTime(r.at), r.type, r.action, r.reference, r.detail, r.user, r.role, factoryName(r.factoryId)]),
    );

  return (
    <div className="rpt-grid">
      <div className="rpt-kpis rpt-span-12">
        <KpiCard label="Audit events" value={formatNumber(data.totals.events)} icon={<ScrollText size={20} />} tone="primary" />
        <KpiCard label="Status changes" value={formatNumber(data.totals.statusChanges)} icon={<GitCompareArrows size={20} />} tone="info" />
        <KpiCard label="Assignments" value={formatNumber(data.totals.assignments)} hint="Incl. reassignments" icon={<Boxes size={20} />} tone="warning" />
        <KpiCard label="QA decisions" value={formatNumber(data.totals.qaDecisions)} icon={<ClipboardCheck size={20} />} tone="success" />
        <KpiCard label="Scrap decisions" value={formatNumber(data.totals.scrapDecisions)} icon={<Trash2 size={20} />} tone="danger" />
        <KpiCard
          label="Cartons created / closed"
          value={`${data.totals.cartonsCreated} / ${data.totals.cartonsClosed}`}
          icon={<PackageCheck size={20} />}
          tone="secondary"
        />
      </div>

      <ChartCard span={7} title="Activity timeline" subtitle="Audit events grouped by category">
        <ReportChart
          type="area"
          options={timelineOptions}
          series={data.groupSeries.map((g) => ({ name: g.name, data: g.data }))}
        />
      </ChartCard>

      <ChartCard span={5} title="Events by type" subtitle="Status, assignment, QA, scrap, carton, user">
        <ReportChart
          type="bar"
          options={typeOptionsChart}
          series={[{ name: "Events", data: data.byType.map((t) => t.count) }]}
        />
      </ChartCard>

      <ChartCard span={12} title="Most active users" subtitle="Top 8 users by recorded activity">
        <ReportChart
          type="bar"
          height={260}
          options={userOptions}
          series={[{ name: "Activity", data: data.topUsers.map((u) => u.count) }]}
        />
      </ChartCard>

      <TableCard
        title="Audit & activity log"
        subtitle={`${formatNumber(rows.length)} events match the current filters`}
        onExport={exportCsv}
        toolbar={
          <div className="rpt-table-filters">
            <CommonInput
              placeholder="Search garment, user, detail..."
              value={search}
              leftElement={<Search size={15} />}
              onChange={(e) => setSearch(e.target.value)}
            />
            <CommonSelect options={typeOptions} value={type} onChange={(v) => setType(String(v ?? "all"))} />
          </div>
        }
      >
        <CommonDataTable data={rows} columns={columns} dataKey="id" rows={10} rowsPerPageOptions={[10, 25, 50]} />
      </TableCard>
    </div>
  );
}
