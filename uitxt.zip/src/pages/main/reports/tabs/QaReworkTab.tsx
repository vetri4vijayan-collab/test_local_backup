import { useMemo } from "react";
import type { ApexOptions } from "apexcharts";
import { ClipboardCheck, Layers3, Recycle, ShieldX, Target, Trash2 } from "lucide-react";

import { CommonDataTable, type TableColumn } from "@/components/common/data-table";

import ChartCard from "../components/ChartCard";
import KpiCard from "../components/KpiCard";
import ReportChart from "../components/ReportChart";
import TableCard from "../components/TableCard";
import ToneBadge from "../components/ToneBadge";
import type { ReportFilters } from "../types/reportTypes";
import { CHART, PALETTE } from "../utils/chartTheme";
import { csvName, downloadCsv, formatNumber } from "../utils/reportHelpers";
import { computeQa, type MultiCycleRow, type ReasonRow } from "../utils/reportMetrics";

export default function QaReworkTab({ filters }: { filters: ReportFilters }) {
  const data = useMemo(() => computeQa(filters), [filters]);

  const outcomeOptions: ApexOptions = {
    labels: ["Passed", "Rejected", "Scrapped"],
    colors: [CHART.green, CHART.amber, CHART.red],
    stroke: { width: 2, colors: ["#fff"] },
    plotOptions: { pie: { donut: { size: "66%", labels: { show: true, total: { show: true, label: "Inspections" } } } } },
  };

  const yieldOptions: ApexOptions = {
    labels: ["First-time yield", "Rework recovery"],
    colors: [CHART.navy, CHART.teal],
    plotOptions: {
      radialBar: {
        hollow: { size: "42%" },
        track: { background: "#eef0f6" },
        dataLabels: { name: { fontSize: "12px" }, value: { fontSize: "18px", fontWeight: 700 }, total: { show: true, label: "FTY", formatter: () => `${data.firstTimeYield}%` } },
      },
    },
  };

  const cycleOptions: ApexOptions = {
    colors: [CHART.green, CHART.blue, CHART.amber, CHART.red],
    plotOptions: { bar: { distributed: true, columnWidth: "52%", borderRadius: 5 } },
    legend: { show: false },
    dataLabels: { enabled: true },
    xaxis: { categories: ["0 cycles", "1 cycle", "2 cycles", "3+ cycles"] },
  };

  const reasonOptions: ApexOptions = {
    colors: PALETTE,
    legend: { show: false },
    plotOptions: { treemap: { distributed: true, enableShades: false } },
    dataLabels: { enabled: true, style: { fontSize: "12px" } },
  };

  const checklistOptions: ApexOptions = {
    colors: [CHART.violet],
    plotOptions: { bar: { horizontal: true, barHeight: "58%", borderRadius: 3 } },
    dataLabels: { enabled: true },
    xaxis: { categories: data.checklist.map((c) => c.name) },
  };

  const heatOptions: ApexOptions = {
    colors: [CHART.navy],
    legend: { show: false },
    dataLabels: { enabled: true, style: { fontSize: "11px" } },
    plotOptions: { heatmap: { radius: 4, shadeIntensity: 0.6 } },
    stroke: { width: 2, colors: ["#fff"] },
  };

  const reasonColumns: TableColumn<ReasonRow>[] = [
    { field: "reason", header: "Rejection reason", minWidth: "240px", sortable: true },
    { field: "count", header: "Rejections", align: "right", sortable: true },
    { field: "share", header: "Share", align: "right", body: (r) => `${r.share}%` },
    { field: "repeatGarments", header: "Repeat garments", align: "right", sortable: true },
    { field: "topStation", header: "Main station" },
  ];

  const cycleColumns: TableColumn<MultiCycleRow>[] = [
    { field: "id", header: "Garment", sortable: true },
    { field: "poNumber", header: "PO" },
    { field: "station", header: "Station" },
    {
      field: "cycles",
      header: "Rework cycles",
      align: "right",
      sortable: true,
      body: (r) => <ToneBadge label={`${r.cycles} cycles`} tone={r.cycles >= 3 ? "danger" : "warning"} />,
    },
    { field: "lastReason", header: "Last rejection reason", minWidth: "220px" },
    {
      field: "status",
      header: "Current status",
      body: (r) => <ToneBadge label={r.status} tone={r.status === "Scrapped" ? "danger" : r.status === "Packed" ? "success" : "info"} />,
    },
  ];

  const exportReasons = () =>
    downloadCsv(
      csvName("qa-rejection-reasons", filters),
      ["Reason", "Rejections", "Share %", "Repeat garments", "Main station"],
      data.reasonRows.map((r) => [r.reason, r.count, r.share, r.repeatGarments, r.topStation]),
    );

  const exportCycles = () =>
    downloadCsv(
      csvName("multi-cycle-garments", filters),
      ["Garment", "PO", "Station", "Rework cycles", "Last reason", "Status"],
      data.multiCycle.map((r) => [r.id, r.poNumber, r.station, r.cycles, r.lastReason, r.status]),
    );

  return (
    <div className="rpt-grid">
      <div className="rpt-kpis rpt-span-12">
        <KpiCard label="Inspections" value={formatNumber(data.inspections)} icon={<ClipboardCheck size={20} />} tone="primary" />
        <KpiCard label="First-time yield" value={`${data.firstTimeYield}%`} hint="Passed on first inspection" icon={<Target size={20} />} tone="success" />
        <KpiCard label="Rejected inspections" value={formatNumber(data.reject)} icon={<ShieldX size={20} />} tone="warning" />
        <KpiCard label="Multi-cycle garments" value={formatNumber(data.multiCycleCount)} hint="2+ rework cycles" icon={<Layers3 size={20} />} tone="info" />
        <KpiCard label="Repeat defect garments" value={formatNumber(data.repeatDefectGarments)} icon={<Recycle size={20} />} tone="secondary" />
        <KpiCard label="Scrapped" value={formatNumber(data.scrap)} icon={<Trash2 size={20} />} tone="danger" />
      </div>

      <ChartCard span={4} title="Inspection outcomes" subtitle="Pass / reject / scrap decisions">
        <ReportChart type="donut" options={outcomeOptions} series={[data.pass, data.reject, data.scrap]} />
      </ChartCard>

      <ChartCard span={4} title="First-time yield" subtitle="Yield and rework recovery rate">
        <ReportChart type="radialBar" options={yieldOptions} series={[data.firstTimeYield, data.recoveryRate]} />
      </ChartCard>

      <ChartCard span={4} title="Rework cycle counts" subtitle="Inspected garments by rejection cycles">
        <ReportChart type="bar" options={cycleOptions} series={[{ name: "Garments", data: data.cycles }]} />
      </ChartCard>

      <ChartCard span={6} title="Rejection reasons" subtitle="Size shows rejection volume">
        <ReportChart
          type="treemap"
          height={320}
          options={reasonOptions}
          series={[{ data: data.reasonRows.map((r) => ({ x: r.reason, y: r.count })) }]}
        />
      </ChartCard>

      <ChartCard span={6} title="Checklist failures" subtitle="Failed inspection checklist items">
        <ReportChart
          type="bar"
          height={320}
          options={checklistOptions}
          series={[{ name: "Failures", data: data.checklist.map((c) => c.count) }]}
        />
      </ChartCard>

      <ChartCard span={12} title="Repeat defect patterns" subtitle="Rejections by defect category and station (darker = more rejections)">
        <ReportChart type="heatmap" height={340} options={heatOptions} series={data.heatSeries} />
      </ChartCard>

      <TableCard title="Rejection reasons" subtitle="Reason breakdown with repeat defect count" onExport={exportReasons}>
        <CommonDataTable data={data.reasonRows} columns={reasonColumns} dataKey="id" rows={8} rowsPerPageOptions={[8, 16]} />
      </TableCard>

      <TableCard title="Multi-cycle garments" subtitle="Garments rejected two or more times (top 30)" onExport={exportCycles}>
        <CommonDataTable data={data.multiCycle} columns={cycleColumns} dataKey="id" rows={8} rowsPerPageOptions={[8, 16]} />
      </TableCard>
    </div>
  );
}
