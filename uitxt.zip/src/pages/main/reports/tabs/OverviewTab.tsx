import { useMemo } from "react";
import type { ApexOptions } from "apexcharts";
import {
  BadgeCheck,
  ClipboardList,
  PackageCheck,
  RotateCcw,
  ShieldX,
  Timer,
  Wrench,
} from "lucide-react";

import { CommonDataTable, type TableColumn } from "@/components/common/data-table";

import ChartCard from "../components/ChartCard";
import KpiCard from "../components/KpiCard";
import ReportChart from "../components/ReportChart";
import TableCard from "../components/TableCard";
import ToneBadge from "../components/ToneBadge";
import type { GarmentStatus, ReportFilters } from "../types/reportTypes";
import { CHART } from "../utils/chartTheme";
import { csvName, downloadCsv, formatNumber } from "../utils/reportHelpers";
import { computeOverview, type BacklogRow } from "../utils/reportMetrics";

const STATUS_COLORS: Record<string, string> = {
  Registered: CHART.slate,
  "In Repair": CHART.blue,
  "Awaiting QA": CHART.violet,
  "Awaiting Rework": CHART.amber,
  "Awaiting Packing": CHART.green,
};

const STATUS_TONE: Record<string, "secondary" | "info" | "primary" | "warning" | "success"> = {
  Registered: "secondary",
  "In Repair": "info",
  "Awaiting QA": "primary",
  "Awaiting Rework": "warning",
  "Awaiting Packing": "success",
};

export default function OverviewTab({ filters }: { filters: ReportFilters }) {
  const data = useMemo(() => computeOverview(filters), [filters]);
  const bucketLabel = data.trend.weekly ? "Weekly" : "Daily";

  const flowOptions: ApexOptions = {
    colors: [CHART.navy, CHART.blue, CHART.green],
    stroke: { curve: "smooth", width: 2.5 },
    fill: { type: "gradient", gradient: { opacityFrom: 0.35, opacityTo: 0.02 } },
    xaxis: { categories: data.trend.labels, tickAmount: 10 },
    yaxis: { labels: { formatter: (v: number) => String(Math.round(v)) } },
  };

  const backlogOptions: ApexOptions = {
    labels: data.backlog.map((b) => b.status),
    colors: data.backlog.map((b) => STATUS_COLORS[b.status]),
    stroke: { width: 2, colors: ["#fff"] },
    plotOptions: {
      pie: {
        donut: {
          size: "68%",
          labels: { show: true, total: { show: true, label: "Open backlog", fontSize: "12px" } },
        },
      },
    },
  };

  const turnaroundOptions: ApexOptions = {
    colors: [CHART.teal, CHART.orange],
    stroke: { width: [0, 3], curve: "smooth" },
    plotOptions: { bar: { columnWidth: "45%", borderRadius: 4 } },
    xaxis: { categories: data.trend.labels, tickAmount: 10 },
    yaxis: [
      { title: { text: "QA approved" }, labels: { formatter: (v: number) => String(Math.round(v)) } },
      { opposite: true, title: { text: "Avg hours" } },
    ],
  };

  const factoryOptions: ApexOptions = {
    colors: [CHART.blue, CHART.green, CHART.navy, CHART.red],
    chart: { stacked: true },
    plotOptions: { bar: { horizontal: true, barHeight: "55%", borderRadius: 3 } },
    xaxis: { categories: data.factoryFlow.map((f) => f.factory) },
    dataLabels: { enabled: true, style: { fontSize: "11px" } },
  };

  const columns: TableColumn<BacklogRow>[] = [
    {
      field: "status",
      header: "Status",
      body: (r) => <ToneBadge label={r.status as GarmentStatus} tone={STATUS_TONE[r.status]} />,
    },
    { field: "count", header: "Garments", align: "right" },
    {
      field: "share",
      header: "Share of backlog",
      minWidth: "180px",
      body: (r) => (
        <div className="rpt-progress">
          <span style={{ width: `${r.share}%`, background: STATUS_COLORS[r.status] }} />
          <em>{r.share}%</em>
        </div>
      ),
    },
    { field: "avgAgeDays", header: "Avg age (days)", align: "right" },
    { field: "oldestDays", header: "Oldest (days)", align: "right" },
  ];

  const exportCsv = () =>
    downloadCsv(
      csvName("operational-backlog", filters),
      ["Status", "Garments", "Share %", "Avg age (days)", "Oldest (days)"],
      data.backlog.map((r) => [r.status, r.count, r.share, r.avgAgeDays, r.oldestDays]),
    );

  return (
    <div className="rpt-grid">
      <div className="rpt-kpis rpt-span-12">
        <KpiCard label="Garments registered" value={formatNumber(data.registered)} icon={<ClipboardList size={20} />} tone="primary" />
        <KpiCard label="Repaired" value={formatNumber(data.repaired)} icon={<Wrench size={20} />} tone="info" />
        <KpiCard label="QA approved" value={formatNumber(data.qaApproved)} icon={<BadgeCheck size={20} />} tone="success" />
        <KpiCard label="QA rejections" value={formatNumber(data.qaRejected)} hint="Total reject decisions" icon={<ShieldX size={20} />} tone="danger" />
        <KpiCard label="Awaiting rework" value={formatNumber(data.awaitingRework)} icon={<RotateCcw size={20} />} tone="warning" />
        <KpiCard label="Awaiting packing" value={formatNumber(data.awaitingPacking)} icon={<PackageCheck size={20} />} tone="success" />
        <KpiCard label="Avg turnaround" value={`${data.avgTurnaround} h`} hint="Registered to QA approved" icon={<Timer size={20} />} tone="secondary" />
      </div>

      <ChartCard span={8} title="Garment flow" subtitle={`${bucketLabel} registered vs repaired vs QA approved`}>
        <ReportChart
          type="area"
          height={310}
          options={flowOptions}
          series={[
            { name: "Registered", data: data.trend.registered },
            { name: "Repaired", data: data.trend.repaired },
            { name: "QA approved", data: data.trend.approved },
          ]}
        />
      </ChartCard>

      <ChartCard span={4} title="Backlog by status" subtitle="Open garments in the selected period">
        <ReportChart type="donut" height={310} options={backlogOptions} series={data.backlog.map((b) => b.count)} />
      </ChartCard>

      <ChartCard span={6} title="Average turnaround" subtitle="QA approved volume and average hours to approval">
        <ReportChart
          type="line"
          height={300}
          options={turnaroundOptions}
          series={[
            { name: "QA approved", type: "column", data: data.turnaround.approved },
            { name: "Avg turnaround (h)", type: "line", data: data.turnaround.avgHours },
          ]}
        />
      </ChartCard>

      <ChartCard span={6} title="Garment status by factory" subtitle="Where garments sit in the pipeline">
        <ReportChart
          type="bar"
          height={300}
          options={factoryOptions}
          series={[
            { name: "In progress", data: data.factoryFlow.map((f) => f.open) },
            { name: "Awaiting packing", data: data.factoryFlow.map((f) => f.awaitingPacking) },
            { name: "Packed", data: data.factoryFlow.map((f) => f.packed) },
            { name: "Scrapped", data: data.factoryFlow.map((f) => f.scrapped) },
          ]}
        />
      </ChartCard>

      <TableCard title="Backlog by status" subtitle="Open garments grouped by workflow status" onExport={exportCsv}>
        <CommonDataTable data={data.backlog} columns={columns} dataKey="id" paginator={false} />
      </TableCard>
    </div>
  );
}
