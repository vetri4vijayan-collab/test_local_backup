import { useEffect, useState } from "react";
import { Factory } from "lucide-react";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import type { Station, Operator } from "../types/stationTypes";

interface Props { show: boolean; value: Station | null; operators: Operator[]; onClose: () => void; onSave: (item: Station) => void; }
export default function StationFormModal({ show, value, operators, onClose, onSave }: Props) {
  const [form, setForm] = useState<Station>({ id: "", code: "", name: "", factory: "Factory A", category: "Stitching", location: "", capacity: 30, operatorIds: [], status: "Active", remarks: "" });
  const update = (key: keyof Station, next: string | number | string[]) => setForm((p) => ({ ...p, [key]: next }));
  useEffect(() => { if (show) setForm(value ? { ...value } : { id: `STN-${Date.now()}`, code: "", name: "", factory: "Factory A", category: "Stitching", location: "", capacity: 30, operatorIds: [], status: "Active", remarks: "" }); }, [show, value]);
  const toggle = (id: string) => update("operatorIds", form.operatorIds.includes(id) ? form.operatorIds.filter(x => x !== id) : [...form.operatorIds, id]);
  const save = () => { if (!form.name.trim() || !form.code.trim() || !form.location.trim() || form.capacity < 1) return; onSave({ ...form, name: form.name.trim(), code: form.code.trim().toUpperCase() }); };
  return <CommonModal show={show} onClose={onClose} variant="drawer" size="lg" title={value ? "Edit Station" : "Create Station"} subtitle="Configure station details, workload capacity and assigned operators." headerIcon={<Factory size={18}/>} footer={<><CommonButton variant="outline" onClick={onClose}>Cancel</CommonButton><CommonButton onClick={save} disabled={!form.name.trim() || !form.code.trim() || !form.location.trim()}>{value ? "Update Station" : "Create Station"}</CommonButton></>}>
    <div className="row g-3">
      <div className="col-md-6"><CommonInput label="Station Name" value={form.name} onChange={e => update("name", e.target.value)} placeholder="e.g. Stitching Repair Station Alpha" required/></div>
      <div className="col-md-6"><CommonInput label="Station Code" value={form.code} onChange={e => update("code", e.target.value)} placeholder="ST-STITCH-01" required/></div>
      <div className="col-md-6"><CommonSelect label="Factory" value={form.factory} onChange={v => update("factory", String(v ?? ""))} options={["Factory A","Factory B","Factory C"].map(x => ({label:x,value:x}))}/></div>
      <div className="col-md-6"><CommonSelect label="Category" value={form.category} onChange={v => update("category", String(v ?? ""))} options={["Stitching","Stain Treatment","Fabric Repair","Measurement","Finishing"].map(x => ({label:x,value:x}))}/></div>
      <div className="col-md-6"><CommonInput label="Location / Zone" value={form.location} onChange={e => update("location", e.target.value)} placeholder="Floor 2, Zone B" required/></div>
      <div className="col-md-6"><CommonInput label="Configured Capacity (garments)" type="number" min={1} value={String(form.capacity)} onChange={e => update("capacity", Number(e.target.value))} required/></div>
      <div className="col-md-6"><CommonSelect label="Status" value={form.status} onChange={v => update("status", String(v ?? "Active"))} options={["Active","Inactive"].map(x => ({label:x,value:x}))}/></div>
      <div className="col-12"><label className="sm-form-label">Assigned Operators</label><div className="sm-check-grid">{operators.map(op => <label key={op.id} className="sm-check-option"><input type="checkbox" checked={form.operatorIds.includes(op.id)} onChange={() => toggle(op.id)} disabled={op.status !== "Active"}/><span><b>{op.name}</b><small>{op.employeeCode} · {op.status}</small></span></label>)}</div></div>
      <div className="col-12"><CommonTextArea label="Remarks" value={form.remarks} onChange={e => update("remarks", e.target.value)} rows={3} placeholder="Add station notes..."/></div>
    </div>
  </CommonModal>;
}
