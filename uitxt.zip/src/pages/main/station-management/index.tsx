import { useMemo, useState } from "react";
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  ClipboardList,
  Clock3,
  Eye,
  Image as ImageIcon,
  MapPin,
  Maximize2,
  Package,
  QrCode,
  Search,
  ShieldCheck,
  Users,
  Wrench,
} from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";

import { garmentImageByStyle, initialWorkOrders } from "./data/stationData";
import type { QueueStatus, WorkOrder } from "./types/stationTypes";
import QRScannerModal from "./components/QRScannerModal";

import "./StationManagementPage.scss";
import CommonModal from "@/components/common/ui/modal/CommonModal";

type FilterStatus = "All" | "Assigned" | "In Progress" | "Sent to QA";

type WorkOrderWithImage = WorkOrder & {
  garmentImage?: string;
};

const statusOptions: QueueStatus[] = [
  "Assigned",
  "In Progress",
  "Sent to QA",
  "QA Passed",
  "QA Rejected",
  "Packed",
  "Scrap",
];

const activeStatuses: QueueStatus[] = ["Assigned", "In Progress", "Sent to QA"];

const getStatusClass = (status: any) =>
  status.toLowerCase().replaceAll(" ", "-");

const formatDate = (value?: string) => {
  if (!value) return "Not started";

  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export default function StationManagementPage() {
  const [orders, setOrders] = useState<WorkOrderWithImage[]>(
    initialWorkOrders.map((order) => ({
      ...order,
      garmentImage: garmentImageByStyle[order.styleNumber],
    })),
  );

  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterStatus>("All");
  const [scanOpen, setScanOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [imagePreviewOpen, setImagePreviewOpen] = useState(false);
  const [repairStatus, setRepairStatus] = useState<QueueStatus>("In Progress");
  const [repairDetails, setRepairDetails] = useState("");
  const [repairRemarks, setRepairRemarks] = useState("");
  const [materialsUsed, setMaterialsUsed] = useState("");

  const selectedOrder =
    orders.find((order) => order.id === selectedOrderId) ?? null;

  const filteredOrders = useMemo(() => {
    const query = search.trim().toLowerCase();

    return orders.filter((order) => {
      const matchesSearch =
        !query ||
        [
          order.qrId,
          order.reworkId,
          order.poNumber,
          order.garmentId,
          order.styleNumber,
          order.defectCategory,
        ].some((value) => value.toLowerCase().includes(query));

      const matchesFilter = filter === "All" || order.status === filter;

      return matchesSearch && matchesFilter;
    });
  }, [orders, search, filter]);

  const activeCount = orders.filter((order) =>
    activeStatuses.includes(order.status),
  ).length;

  const assignedCount = orders.filter(
    (order) => order.status === "Assigned",
  ).length;

  const progressCount = orders.filter(
    (order) => order.status === "In Progress",
  ).length;

  const qaCount = orders.filter(
    (order) => order.status === "Sent to QA",
  ).length;

  const chooseOrder = (order: WorkOrderWithImage) => {
    setSelectedOrderId(order.id);
    setRepairStatus(order.status);
    setRepairDetails(order.repairDetails ?? "");
    setRepairRemarks(order.repairRemarks ?? "");
    setMaterialsUsed(order.materialsUsed ?? "");
    setNotice("");
  };

  const handleScan = (value: string) => {
    setScanOpen(false);

    const scannedValue = value.trim().toLowerCase();

    const found = orders.find(
      (order) =>
        order.qrId.toLowerCase() === scannedValue ||
        order.garmentId.toLowerCase() === scannedValue ||
        order.reworkId.toLowerCase() === scannedValue,
    );

    if (!found) {
      setNotice(`No work order found for "${value}".`);
      return;
    }

    chooseOrder(found);
    setNotice(`Work order ${found.reworkId} found successfully.`);
  };

  const saveWork = () => {
    if (!selectedOrder) return;

    const timestamp = new Date().toISOString();
    const displayDate = new Date().toLocaleString("en-IN");

    setOrders((current) =>
      current.map((order) => {
        if (order.id !== selectedOrder.id) return order;

        const isCompleted = [
          "Sent to QA",
          "QA Passed",
          "QA Rejected",
          "Packed",
        ].includes(repairStatus);

        return {
          ...order,
          status: repairStatus,
          repairDetails,
          repairRemarks,
          materialsUsed,
          startedAt: order.startedAt ?? timestamp,
          completedAt: isCompleted
            ? (order.completedAt ?? timestamp)
            : order.completedAt,
          submittedAt:
            repairStatus === "Sent to QA"
              ? (order.submittedAt ?? timestamp)
              : order.submittedAt,
          history: [
            {
              title: "Repair Progress Updated",
              description:
                `Status changed to ${repairStatus}. ${repairRemarks}`.trim(),
              date: displayDate,
            },
            ...order.history,
          ],
        };
      }),
    );

    setNotice(`${selectedOrder.reworkId} updated successfully.`);
  };

  return (
    <div className="sm-page">
      <CommonPageHeader
        icon={<Wrench size={20} />}
        title="Station Work Queue"
        subtitle="Scan garment QR codes, review assigned defects and update repair progress."
        rightContent={
          <CommonButton
            leftIcon={<QrCode size={16} />}
            onClick={() => setScanOpen(true)}
          >
            Scan QR Code
          </CommonButton>
        }
      />

      {notice && (
        <div className="sm-notice">
          <CheckCircle2 size={16} />
          <span>{notice}</span>
          <button type="button" onClick={() => setNotice("")}>
            Dismiss
          </button>
        </div>
      )}

      {/* Assigned Detail */}
      <div className="station-summary-card">
        <div className="station-summary-main">
          <div className="station-summary-icon">
            <MapPin size={21} />
          </div>

          <div className="station-summary-info">
            <h5>Stitching Repair Station Alpha</h5>

            <div className="station-summary-meta">
              <span>
                <MapPin size={13} />
                Floor 2, Zone B
              </span>

              <span className="station-meta-separator">•</span>

              <span>
                Code: <strong>ST-STITCH-01</strong>
              </span>
            </div>
          </div>
        </div>

        <div className="station-summary-stats">
          {/*     <div className="station-summary-stat pending">
            <div className="station-stat-icon">
              <Package size={16} />
            </div>

            <div>
              <span>Pending Queue</span>
              <strong>2</strong>
              <small>Garments</small>
            </div>
          </div> */}

          <div className="station-summary-stat staff">
            <div className="station-stat-icon">
              <Users size={16} />
            </div>

            <div className="station-staff-content">
              <span>Assigned Operator</span>

              <div className="station-staff-list">
                <span className="staff-name">Karthick</span>

                {/*  <span className="no-staff">No staff assigned</span> */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Queue summary */}
      <div className="sm-summary-grid">
        <article className="sm-summary-card sm-summary-card--total">
          <span className="sm-summary-icon">
            <ClipboardList size={19} />
          </span>
          <div>
            <small>Active Work Orders</small>
            <strong>{activeCount}</strong>
            <span>Current repair queue</span>
          </div>
        </article>

        <article className="sm-summary-card sm-summary-card--assigned">
          <span className="sm-summary-icon">
            <Package size={19} />
          </span>
          <div>
            <small>Assigned</small>
            <strong>{assignedCount}</strong>
            <span>Waiting to start</span>
          </div>
        </article>

        <article className="sm-summary-card sm-summary-card--progress">
          <span className="sm-summary-icon">
            <Activity size={19} />
          </span>
          <div>
            <small>In Progress</small>
            <strong>{progressCount}</strong>
            <span>Repair ongoing</span>
          </div>
        </article>

        <article className="sm-summary-card sm-summary-card--qa">
          <span className="sm-summary-icon">
            <ShieldCheck size={19} />
          </span>
          <div>
            <small>Sent to QA</small>
            <strong>{qaCount}</strong>
            <span>Awaiting QA review</span>
          </div>
        </article>
      </div>

      {/* Main workspace */}
      <div className="sm-workspace">
        {/* LEFT: Work order queue */}
        <aside className="sm-panel sm-queue-panel">
          <div className="sm-panel-heading">
            <div>
              <h3>
                <ClipboardList size={18} />
                Work Order Queue
              </h3>
              <p>Select a garment to open its repair workbench</p>
            </div>

            <span className="sm-count">{filteredOrders.length}</span>
          </div>

          <div className="sm-queue-search">
            <CommonInput
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search QR, PO, style or defect..."
              leftElement={<Search size={16} />}
            />
          </div>

          <div className="sm-filter-chips">
            {(["All", "Assigned", "In Progress", "Sent to QA"] as const).map(
              (status) => (
                <button
                  key={status}
                  type="button"
                  className={filter === status ? "active" : ""}
                  onClick={() => setFilter(status)}
                >
                  {status}
                </button>
              ),
            )}
          </div>

          <div className="sm-queue-list">
            {filteredOrders.map((order) => (
              <button
                type="button"
                key={order.id}
                className={`sm-queue-card ${
                  selectedOrderId === order.id ? "selected" : ""
                }`}
                onClick={() => chooseOrder(order)}
              >
                <div className="sm-queue-card__image">
                  <ImageIcon size={22} />
                  {order.garmentImage && (
                    <img
                      src={order.garmentImage}
                      alt={`${order.styleNumber} garment`}
                      onError={(event) => {
                        event.currentTarget.style.display = "none";
                      }}
                    />
                  )}
                </div>

                <div className="sm-queue-card__content">
                  <div className="sm-queue-card__top">
                    <span className="sm-qr-label">
                      <QrCode size={12} />
                      {order.qrId}
                    </span>
                    <span
                      className={`sm-severity sm-severity--${order.severity.toLowerCase()}`}
                    >
                      {order.severity}
                    </span>
                  </div>

                  <strong className="sm-card-po">{order.poNumber}</strong>

                  <span className="sm-card-style">
                    {order.styleNumber} · Size {order.size}
                  </span>

                  <div className="sm-card-bottom">
                    <span>{order.defectCategory}</span>
                    <span
                      className={`sm-status sm-status--${getStatusClass(order.status)}`}
                    >
                      {order.status}
                    </span>
                  </div>
                </div>
              </button>
            ))}

            {filteredOrders.length === 0 && (
              <div className="sm-no-results">
                <Search size={24} />
                <strong>No work orders found</strong>
                <span>Try changing your search or status filter.</span>
              </div>
            )}
          </div>

          <div className="sm-queue-footer">
            <span>
              Showing {filteredOrders.length} of {orders.length} work orders
            </span>
          </div>
        </aside>

        {/* RIGHT: Repair workbench */}
        <section className="sm-panel sm-workbench">
          {!selectedOrder ? (
            <div className="sm-qr-placeholder">
              <div className="sm-qr-decoration sm-qr-decoration--one" />
              <div className="sm-qr-decoration sm-qr-decoration--two" />

              <div className="sm-qr-visual">
                <div className="sm-qr-visual__corner top-left" />
                <div className="sm-qr-visual__corner top-right" />
                <div className="sm-qr-visual__corner bottom-left" />
                <QrCode size={78} strokeWidth={1.35} />
                <span className="sm-qr-center">
                  <Wrench size={23} />
                </span>
              </div>

              <span className="sm-qr-eyebrow">GARMENT IDENTIFICATION</span>
              <h2>Ready to start repair?</h2>
              <p>
                Select a work order from the queue or scan the garment QR code
                to view its defect details and repair information.
              </p>

              <CommonButton
                leftIcon={<QrCode size={16} />}
                onClick={() => setScanOpen(true)}
              >
                Scan Garment QR
              </CommonButton>

              <div className="sm-qr-hint">
                <span className="sm-live-dot" />
                Camera activates only after you click Scan QR
              </div>
            </div>
          ) : (
            <div className="sm-work-content">
              <div className="sm-workbench-heading">
                <div>
                  <span className="sm-workbench-eyebrow">
                    <Wrench size={13} />
                    REPAIR WORKBENCH
                  </span>
                  <h3>Garment Repair Details</h3>
                  <p>Review the defect and record the repair activity.</p>
                </div>

                <button
                  type="button"
                  className="sm-change-item"
                  onClick={() => setSelectedOrderId(null)}
                >
                  Change item
                </button>
              </div>

              <div className="sm-order-banner">
                <div>
                  <span className="sm-banner-qr">
                    <QrCode size={13} />
                    {selectedOrder.qrId}
                  </span>
                  <h4>{selectedOrder.reworkId}</h4>
                  <p>
                    {selectedOrder.poNumber} · {selectedOrder.styleNumber} ·
                    Size {selectedOrder.size}
                  </p>
                </div>

                <span
                  className={`sm-status sm-status--${getStatusClass(selectedOrder.status)}`}
                >
                  {selectedOrder.status}
                </span>
              </div>

              <div className="sm-detail-grid">
                <div className="sm-detail-item">
                  <small>Defect Category</small>
                  <strong>{selectedOrder.defectCategory}</strong>
                </div>
                <div className="sm-detail-item">
                  <small>Severity</small>
                  <strong
                    className={`sm-detail-severity sm-detail-severity--${selectedOrder.severity.toLowerCase()}`}
                  >
                    <AlertCircle size={14} />
                    {selectedOrder.severity}
                  </strong>
                </div>
                <div className="sm-detail-item">
                  <small>Registered On</small>
                  <strong>{formatDate(selectedOrder.registeredAt)}</strong>
                </div>
              </div>

              <div className="sm-defect-section">
                <div className="sm-section-title">
                  <span className="sm-section-icon">
                    <AlertCircle size={16} />
                  </span>
                  <div>
                    <h4>Defect Information</h4>
                    <p>Original inspection findings</p>
                  </div>
                </div>

                <div className="sm-defect-description">
                  {selectedOrder.description}
                </div>

                <div className="sm-garment-preview">
                  <button
                    type="button"
                    className="sm-garment-preview__image"
                    onClick={() => setImagePreviewOpen(true)}
                    disabled={!selectedOrder.garmentImage}
                    aria-label="View garment image"
                  >
                    <ImageIcon size={28} />

                    {selectedOrder.garmentImage && (
                      <img
                        src={selectedOrder.garmentImage}
                        alt={`${selectedOrder.styleNumber} garment`}
                        onError={(event) => {
                          event.currentTarget.style.display = "none";
                        }}
                      />
                    )}

                    <span className="sm-image-view-overlay">
                      <Maximize2 size={17} />
                    </span>
                  </button>

                  <div className="sm-garment-preview__info">
                    <strong>Garment reference image</strong>

                    <span>
                      {selectedOrder.styleNumber} · {selectedOrder.garmentId}
                    </span>
                  </div>

                  <button
                    type="button"
                    className="sm-image-view-button"
                    onClick={() => setImagePreviewOpen(true)}
                    disabled={!selectedOrder.garmentImage}
                    title="View garment image"
                    aria-label="View garment image"
                  >
                    <Eye size={17} />
                  </button>
                </div>
              </div>

              <div className="sm-repair-section">
                <div className="sm-section-title">
                  <span className="sm-section-icon sm-section-icon--repair">
                    <Wrench size={16} />
                  </span>
                  <div>
                    <h4>Repair Update</h4>
                    <p>Enter the work completed for this garment</p>
                  </div>
                </div>

                <div className="row g-3">
                  <div className="col-md-6">
                    <CommonSelect
                      label="Work Order Status"
                      value={repairStatus}
                      onChange={(value) =>
                        setRepairStatus(String(value) as QueueStatus)
                      }
                      options={statusOptions.map((status) => ({
                        label: status,
                        value: status,
                      }))}
                      placeholder="Select status"
                    />
                  </div>

                  <div className="col-md-6">
                    <div className="sm-readonly-field">
                      <label>Assigned Station</label>
                      <strong>{selectedOrder.stationId}</strong>
                    </div>
                  </div>

                  <div className="col-12">
                    <CommonTextArea
                      label="Work Performed Details"
                      value={repairDetails}
                      onChange={(event) => setRepairDetails(event.target.value)}
                      rows={3}
                      placeholder="Describe the repair work performed..."
                    />
                  </div>

                  <div className="col-md-6">
                    <CommonInput
                      label="Repair Remarks"
                      value={repairRemarks}
                      onChange={(event) => setRepairRemarks(event.target.value)}
                      placeholder="Enter additional remarks"
                    />
                  </div>

                  <div className="col-md-6">
                    <CommonInput
                      label="Materials Used"
                      value={materialsUsed}
                      onChange={(event) => setMaterialsUsed(event.target.value)}
                      placeholder="Thread, fabric, buttons..."
                    />
                  </div>
                </div>

                <div className="sm-repair-actions">
                  <CommonButton
                    leftIcon={<CheckCircle2 size={16} />}
                    onClick={saveWork}
                  >
                    Save Repair Update
                  </CommonButton>
                </div>
              </div>

              <div className="sm-history-section">
                <div className="sm-section-title">
                  <span className="sm-section-icon sm-section-icon--history">
                    <Clock3 size={16} />
                  </span>
                  <div>
                    <h4>Work Order History</h4>
                    <p>Recorded activity for this garment</p>
                  </div>
                </div>

                <div className="sm-history">
                  {selectedOrder.history.map((item, index) => (
                    <div
                      className="sm-history-row"
                      key={`${item.title}-${index}`}
                    >
                      <span className="sm-history-marker">
                        <CheckCircle2 size={13} />
                      </span>
                      <div>
                        <strong>{item.title}</strong>
                        <p>{item.description}</p>
                        <time>{item.date}</time>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Reusable QR scanner */}
      <QRScannerModal
        show={scanOpen}
        onClose={() => setScanOpen(false)}
        onDetected={handleScan}
      />
      {/* View Defect Image */}
      {selectedOrder?.garmentImage && (
        <CommonModal
          show={imagePreviewOpen}
          onClose={() => setImagePreviewOpen(false)}
          title="Garment Reference Image"
          subtitle={`${selectedOrder.styleNumber} · ${selectedOrder.garmentId}`}
          headerIcon={<Eye size={18} />}
          size="lg"
        >
          <div className="sm-image-preview-modal">
            <img
              src={selectedOrder.garmentImage}
              alt={`${selectedOrder.styleNumber} garment preview`}
            />

            <div className="sm-image-preview-caption">
              <div>
                <strong>{selectedOrder.styleNumber}</strong>
                <span>{selectedOrder.garmentId}</span>
              </div>

              <span className="sm-image-preview-size">
                Size: {selectedOrder.size}
              </span>
            </div>
          </div>
        </CommonModal>
      )}
    </div>
  );
}
