import { useMemo, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  BadgeCheck,
  Check,
  CheckCircle2,
  ClipboardCheck,
  Clock3,
  Eye,
  FileClock,
  Filter,
  History,
  ListChecks,
  PackageCheck,
  QrCode,
  RotateCcw,
  Settings2,
  ShieldAlert,
  Trash2,
  XCircle,
  Image as ImageIcon,
} from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import {
  CommonDataTable,
  type TableColumn,
} from "@/components/common/data-table";

// TODO: update this path to where your reusable scanner lives.


import {
  initialStations,
  initialOperators,
  initialWorkOrders,
  garmentImageByStyle,
} from "@/pages/main/station-management/data/stationData";
import type {
  WorkOrder,
  QueueStatus,
} from "@/pages/main/station-management/types/stationTypes";
import type {
  ChecklistItem,
  ChecklistResponse,
  InspectionDecision,
  QAInspectionRecord,
  InspectionHistoryItem,
} from "./types/qaTypes";
import { initialQAChecklist } from "./data/qaChecklist";
import QARejectPhotoCapture from "./components/QARejectPhotoCapture";

import "./QAInspectionPage.scss";
import ReusableQRScanner from "../station-management/components/ReusableQRScanner";

type QueueRecord = QAInspectionRecord & { sourceStatus: QueueStatus };

const DEMO_INSPECTOR = "Vijay Anand";
const DEMO_USER_ROLE = "QA Manager";
const SCRAP_ALLOWED_ROLES = ["QA Manager", "Admin", "Super Admin"];

const toLocalDateInput = (value: string) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const formatDate = (value: string) =>
  new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

const normalizeCode = (value: string | undefined | null) =>
  (value ?? "").trim().toLowerCase();

// A record matches a scanned value when the scanned text equals (or contains)
// its QR ID, Rework ID or Garment ID.
const matchesScannedValue = (record: QueueRecord, scanned: string) => {
  const value = normalizeCode(scanned);
  if (!value) return true;

  return [record.qrId, record.reworkId, record.garmentId].some((id) => {
    const code = normalizeCode(id);
    return !!code && (code === value || value.includes(code));
  });
};

const makeQueueRecord = (order: WorkOrder): QueueRecord => {
  const station = initialStations.find((item) => item.id === order.stationId);
  const operator = initialOperators.find(
    (item) => item.id === order.operatorId,
  );

  return {
    id: `QA-${order.id}`,
    workOrderId: order.id,
    reworkId: order.reworkId,
    qrId: order.qrId,
    garmentId: order.garmentId,
    poNumber: order.poNumber,
    size: order.size,
    stationId: order.stationId,
    stationName: station?.name ?? "Unassigned Station",
    operatorName: operator?.name ?? order.operatorId,
    defectCategory: order.defectCategory,
    severity: order.severity,
    description: order.description,
    garmentImage: order.defectImage || Object.values(garmentImageByStyle)[0],
    submittedAt: order.submittedAt ?? order.registeredAt,
    inspectionNumber: 0,
    inspectionHistory: [],
    sourceStatus: order.status,
  };
};

export default function QAInspectionPage() {
  const qaDemoOrders = useMemo<WorkOrder[]>(() => {
    const base = initialWorkOrders[1] ?? initialWorkOrders[0]!;
    const poNumbers = [
      "PO-2026-9041",
      "PO-2026-9042",
      "PO-2026-9045",
      "PO-2026-9048",
      "PO-2026-9050",
    ];
    return Array.from({ length: 18 }, (_, index) => {
      const station = initialStations[index % initialStations.length]!;
      const operator =
        initialOperators.find((item) => item.stationIds.includes(station.id)) ??
        initialOperators[0]!;
      const date = new Date(
        2026,
        10,
        18 + (index % 4),
        8 + (index % 8),
        (index * 7) % 60,
      );
      return {
        ...base,
        id: `QA-DEMO-${String(index + 1).padStart(3, "0")}`,
        reworkId: `RW-2026-${610 + index}`,
        qrId: `QR-2026-${String(9100 + index)}`,
        poNumber: poNumbers[index % poNumbers.length],
        garmentId: `GR-2026-${610 + index}`,
        stationId: station.id,
        operatorId: operator.id,
        status: "Sent to QA" as const,
        defectImage:
          Object.values(garmentImageByStyle)[
            index % Object.values(garmentImageByStyle).length
          ],
        severity: (["Minor", "Major", "Critical"] as const)[index % 3],
        defectCategory: [
          "Stitching Defect",
          "Stain",
          "Fabric Damage",
          "Measurement Issue",
          "Finishing Defect",
        ][index % 5],
        description: [
          "Loose seam stitching found near the garment side panel.",
          "Visible stain remains after the treatment process.",
          "Fabric reinforcement requires a final quality check.",
          "Garment measurement needs verification against the order specification.",
          "Finishing and trim alignment require QA confirmation.",
        ][index % 5],
        registeredAt: date.toISOString(),
        submittedAt: date.toISOString(),
      };
    });
  }, []);

  const [records, setRecords] = useState<QueueRecord[]>(() =>
    [
      ...initialWorkOrders.filter((order) => order.status === "Sent to QA"),
      ...qaDemoOrders,
    ].map(makeQueueRecord),
  );
  const [completedRecords, setCompletedRecords] = useState<QueueRecord[]>([]);
  const [checklist, setChecklist] =
    useState<ChecklistItem[]>(initialQAChecklist);
  const [activeTab, setActiveTab] = useState<"queue" | "history">("queue");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [stationFilter, setStationFilter] = useState("");
  const [poFilter, setPOFilter] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  // QR scanner
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannedQr, setScannedQr] = useState("");

  const [responses, setResponses] = useState<Record<string, ChecklistResponse>>(
    {},
  );
  const [inspectionRemarks, setInspectionRemarks] = useState("");
  const [decisionModal, setDecisionModal] = useState<InspectionDecision | null>(
    null,
  );
  const [decisionReason, setDecisionReason] = useState("");
  const [decisionRemarks, setDecisionRemarks] = useState("");
  const [returnStationId, setReturnStationId] = useState<string | null>(null);
  const [rejectedPhoto, setRejectedPhoto] = useState("");
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");
  const [configOpen, setConfigOpen] = useState(false);
  const [newChecklistTitle, setNewChecklistTitle] = useState("");
  const [newChecklistCategory, setNewChecklistCategory] =
    useState("Additional Checks");

  const selectedRecord = records.find((item) => item.id === selectedId) ?? null;
  const activeChecklist = checklist.filter((item) => item.active);

  const stationOptions = useMemo(
    () =>
      initialStations
        .filter((station) => station.status === "Active")
        .map((station) => ({ label: station.name, value: station.id })),
    [],
  );
  const poOptions = useMemo(
    () =>
      Array.from(new Set(records.map((record) => record.poNumber)))
        .sort()
        .map((value) => ({ label: value, value })),
    [records],
  );

  const filteredRecords = useMemo(
    () =>
      records.filter((record) => {
        const submittedDate = toLocalDateInput(record.submittedAt);
        return (
          matchesScannedValue(record, scannedQr) &&
          (!stationFilter || record.stationId === stationFilter) &&
          (!poFilter || record.poNumber === poFilter) &&
          (!dateFrom || submittedDate >= dateFrom) &&
          (!dateTo || submittedDate <= dateTo)
        );
      }),
    [records, scannedQr, stationFilter, poFilter, dateFrom, dateTo],
  );

  const filteredCompletedRecords = useMemo(
    () =>
      completedRecords.filter((record) =>
        matchesScannedValue(record, scannedQr),
      ),
    [completedRecords, scannedQr],
  );

  const stationCompletedRecords = stationFilter
    ? completedRecords.filter((record) => record.stationId === stationFilter)
    : completedRecords;
  const stationQueueCount = stationFilter
    ? records.filter((record) => record.stationId === stationFilter).length
    : records.length;
  const allInspections = stationCompletedRecords.flatMap(
    (record) => record.inspectionHistory,
  );
  const totalInspections = allInspections.length;
  const firstInspections = allInspections.filter(
    (item) => item.inspectionNumber === 1,
  );
  const firstPasses = firstInspections.filter(
    (item) => item.decision === "QA Passed",
  ).length;
  const firstPassRate = firstInspections.length
    ? Math.round((firstPasses / firstInspections.length) * 100)
    : 0;
  const totalRejections = allInspections.filter(
    (item) => item.decision === "QA Rejected",
  ).length;
  const scrappedCount = allInspections.filter(
    (item) => item.decision === "Scrap",
  ).length;
  const garmentsWithRepeatInspection = stationCompletedRecords.filter(
    (record) => record.inspectionHistory.length > 1,
  ).length;
  const secondaryReworkRate = stationCompletedRecords.length
    ? Math.round(
        (garmentsWithRepeatInspection / stationCompletedRecords.length) * 100,
      )
    : 0;

  const failureDistribution = useMemo(() => {
    const counts = new Map<string, number>();
    allInspections.forEach((inspection) =>
      inspection.checklist
        .filter((item) => item.result === "Fail")
        .forEach((item) =>
          counts.set(item.category, (counts.get(item.category) ?? 0) + 1),
        ),
    );
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
  }, [stationCompletedRecords]);

  const resetInspectionForm = () => {
    setResponses({});
    setInspectionRemarks("");
    setFormError("");
    setDecisionReason("");
    setDecisionRemarks("");
    setReturnStationId(null);
    setRejectedPhoto("");
  };

  const selectRecord = (record: QueueRecord) => {
    setSelectedId(record.id);
    resetInspectionForm();
  };

  // =====================================================
  // QR SCAN
  // =====================================================

  const handleQrDetected = (rawValue: string) => {
    const value = rawValue.trim();

    setScannerOpen(false);

    if (!value) return;

    const queueMatches = records.filter((record) =>
      matchesScannedValue(record, value),
    ).length;
    const historyMatches = completedRecords.filter((record) =>
      matchesScannedValue(record, value),
    ).length;

    // Leave any open inspection and show the filtered table.
    setSelectedId(null);
    resetInspectionForm();
    setScannedQr(value);

    if (queueMatches > 0) {
      setActiveTab("queue");
      setNotice(
        `Showing ${queueMatches} garment${queueMatches > 1 ? "s" : ""} in the QA queue for scanned QR ${value}.`,
      );
    } else if (historyMatches > 0) {
      setActiveTab("history");
      setNotice(
        `QR ${value} is not waiting in the queue. Showing its inspection history.`,
      );
    } else {
      setActiveTab("queue");
      setNotice(`No garment found for scanned QR ${value}.`);
    }
  };

  const clearScannedQr = () => {
    setScannedQr("");
  };

  const updateResponse = (item: ChecklistItem, result: "Pass" | "Fail") => {
    setResponses((current) => ({
      ...current,
      [item.id]: {
        itemId: item.id,
        itemTitle: item.title,
        category: item.category,
        result,
        remarks: current[item.id]?.remarks ?? "",
      },
    }));
  };

  const updateResponseRemarks = (item: ChecklistItem, remarks: string) => {
    setResponses((current) => ({
      ...current,
      [item.id]: {
        itemId: item.id,
        itemTitle: item.title,
        category: item.category,
        result: current[item.id]?.result ?? "Pending",
        remarks,
      },
    }));
  };

  const validateChecklist = () => {
    const missing = activeChecklist.filter(
      (item) => item.required && !responses[item.id]?.result,
    );
    if (missing.length) {
      setFormError(
        `Complete all required checklist items: ${missing.map((item) => item.title).join(", ")}.`,
      );
      return false;
    }
    return true;
  };

  const openDecision = (decision: InspectionDecision) => {
    setFormError("");
    setDecisionReason("");
    setDecisionRemarks("");
    setRejectedPhoto("");
    setReturnStationId(selectedRecord?.stationId ?? null);
    if (!validateChecklist()) return;
    const hasFailure = activeChecklist.some(
      (item) => responses[item.id]?.result === "Fail",
    );
    if (decision === "QA Passed" && hasFailure) {
      setFormError(
        "QA Passed is unavailable while one or more checklist items are marked Fail. Resolve the failed items or reject the garment.",
      );
      return;
    }
    if (decision === "QA Rejected" && !hasFailure) {
      setFormError(
        "Mark at least one checklist item as Fail before rejecting the garment.",
      );
      return;
    }
    if (decision === "Scrap" && !SCRAP_ALLOWED_ROLES.includes(DEMO_USER_ROLE)) {
      setFormError(
        "Your current role is not authorised to mark a garment as Scrap.",
      );
      return;
    }
    setDecisionModal(decision);
  };

  const submitInspection = () => {
    if (!selectedRecord || !decisionModal) return;
    if (
      (decisionModal === "QA Rejected" || decisionModal === "Scrap") &&
      !decisionReason.trim()
    ) {
      setFormError(
        `${decisionModal === "Scrap" ? "Scrap" : "Rejection"} reason is mandatory.`,
      );
      return;
    }
    if (decisionModal === "QA Rejected" && !returnStationId) {
      setFormError("Select a station for secondary rework.");
      return;
    }
    if (decisionModal === "QA Rejected" && !rejectedPhoto) {
      setFormError(
        "Upload or take a photo of the rejected item and mark the damaged area.",
      );
      return;
    }

    const now = new Date().toISOString();
    const checklistSnapshot = activeChecklist.map(
      (item) =>
        responses[item.id] ?? {
          itemId: item.id,
          itemTitle: item.title,
          category: item.category,
          result: "Pending" as const,
          remarks: "",
        },
    );

    const historyItem: InspectionHistoryItem = {
      id: `INSP-${Date.now()}`,
      inspectionNumber: selectedRecord.inspectionHistory.length + 1,
      decision: decisionModal,
      reason: decisionReason.trim(),
      remarks: decisionRemarks.trim() || inspectionRemarks.trim(),
      inspectedAt: now,
      inspector: DEMO_INSPECTOR,
      checklist: checklistSnapshot,
      returnedStationId:
        decisionModal === "QA Rejected"
          ? (returnStationId ?? undefined)
          : undefined,
      rejectionImage:
        decisionModal === "QA Rejected" ? rejectedPhoto : undefined,
    };

    const updated: QueueRecord = {
      ...selectedRecord,
      stationId:
        decisionModal === "QA Rejected"
          ? returnStationId!
          : selectedRecord.stationId,
      stationName:
        decisionModal === "QA Rejected"
          ? (initialStations.find((station) => station.id === returnStationId)
              ?.name ?? selectedRecord.stationName)
          : selectedRecord.stationName,
      inspectionNumber: historyItem.inspectionNumber,
      inspectionHistory: [...selectedRecord.inspectionHistory, historyItem],
      sourceStatus: decisionModal,
    };

    setCompletedRecords((current) => {
      const existingIndex = current.findIndex((item) => item.id === updated.id);
      if (existingIndex === -1) return [updated, ...current];
      return current.map((item) => (item.id === updated.id ? updated : item));
    });

    setRecords((current) =>
      current.filter((item) => item.id !== selectedRecord.id),
    );
    setSelectedId(null);
    setDecisionModal(null);
    resetInspectionForm();
    setActiveTab("history");
    setNotice(
      `${selectedRecord.reworkId} inspection submitted as ${decisionModal}. The submitted inspection is now read-only.`,
    );
  };

  const resubmitForQA = (record: QueueRecord) => {
    if (record.sourceStatus !== "QA Rejected") return;
    const reopened: QueueRecord = {
      ...record,
      sourceStatus: "Sent to QA",
      submittedAt: new Date().toISOString(),
    };
    setRecords((current) => [reopened, ...current]);
    setCompletedRecords((current) =>
      current.filter((item) => item.id !== record.id),
    );
    setActiveTab("queue");
    setNotice(
      `${record.reworkId} added back to the QA queue for its next inspection. Previous inspection history is retained.`,
    );
  };

  const addChecklistItem = () => {
    const title = newChecklistTitle.trim();
    if (!title) return;
    setChecklist((current) => [
      ...current,
      {
        id: `CHK-${Date.now()}`,
        title,
        category: newChecklistCategory,
        active: true,
        required: false,
      },
    ]);
    setNewChecklistTitle("");
  };

  const toggleChecklistItem = (id: string) => {
    setChecklist((current) =>
      current.map((item) =>
        item.id === id ? { ...item, active: !item.active } : item,
      ),
    );
  };

  const queueColumns: TableColumn<QueueRecord>[] = [
    {
      field: "reworkId",
      header: "Work Order",
      minWidth: "145px",
      body: (row) => (
        <div className="qa-table-order">
          <strong>{row.reworkId}</strong>
          <small>{row.qrId}</small>
        </div>
      ),
    },
    {
      field: "poNumber",
      header: "PO Number",
      minWidth: "135px",
      body: (row) => <strong className="qa-table-po">{row.poNumber}</strong>,
    },
    {
      field: "stationName",
      header: "Submitted Station",
      minWidth: "190px",
      body: (row) => (
        <div className="qa-table-order">
          <strong>{row.stationName}</strong>
          <small>{row.operatorName}</small>
        </div>
      ),
    },
    {
      field: "submittedAt",
      header: "Submitted On",
      minWidth: "150px",
      body: (row) => (
        <span className="qa-date-cell">{formatDate(row.submittedAt)}</span>
      ),
    },
    {
      field: "severity",
      header: "Severity",
      minWidth: "90px",
      body: (row) => (
        <span
          className={`qa-severity qa-severity--${row.severity.toLowerCase()}`}
        >
          {row.severity}
        </span>
      ),
    },
    {
      field: "id",
      header: "Action",
      // align: "center",
      minWidth: "100px",
      body: (row) => (
        <button
          type="button"
          className="qa-icon-action"
          title="Inspect garment"
          aria-label={`Inspect ${row.reworkId}`}
          onClick={() => selectRecord(row)}
        >
          <Eye size={17} />
        </button>
      ),
    },
  ];

  const historyColumns: TableColumn<QueueRecord>[] = [
    {
      field: "reworkId",
      header: "Work Order",
      minWidth: "140px",
      body: (row) => (
        <div className="qa-table-order">
          <strong>{row.reworkId}</strong>
          <small>{row.garmentId}</small>
        </div>
      ),
    },
    { field: "poNumber", header: "PO", minWidth: "125px" },
    { field: "stationName", header: "Submitted Station", minWidth: "190px" },
    {
      field: "inspectionHistory",
      header: "Inspections",
      minWidth: "100px",
      body: (row) => (
        <span className="qa-history-count">{row.inspectionHistory.length}</span>
      ),
    },
    {
      field: "sourceStatus",
      header: "Latest Decision",
      minWidth: "130px",
      body: (row) => (
        <span
          className={`qa-decision qa-decision--${row.sourceStatus.toLowerCase().replace(/-/g, " ")}`}
        >
          {row.sourceStatus}
        </span>
      ),
    },
    {
      field: "inspectionHistory",
      header: "Last Inspected",
      minWidth: "160px",
      body: (row) => {
        const latest = row.inspectionHistory[row.inspectionHistory.length - 1];
        return latest ? (
          <span className="qa-date-cell">{formatDate(latest.inspectedAt)}</span>
        ) : (
          "—"
        );
      },
    },
    {
      field: "id",
      header: "Action",
      minWidth: "145px",
      body: (row) =>
        row.sourceStatus === "QA Rejected" ? (
          <button
            type="button"
            className="qa-icon-action"
            title="Re-submit for QA"
            aria-label="Re-submit for QA"
            onClick={() => resubmitForQA(row)}
          >
            <RotateCcw size={16} />
          </button>
        ) : (
          <span
            className="qa-readonly-label"
            title="This inspection is read only"
          >
            <LockIcon />
          </span>
        ),
    },
  ];

  // Chip shown above the tables while a scanned QR filter is active.
  const scanFilterChip = scannedQr ? (
    <div className="qa-scan-filter">
      <QrCode size={15} />
      <span>
        Scanned QR: <strong>{scannedQr}</strong>
      </span>
      <button
        type="button"
        onClick={clearScannedQr}
        title="Clear scanned QR filter"
        aria-label="Clear scanned QR filter"
      >
        <XCircle size={16} />
      </button>
    </div>
  ) : null;

  return (
    <div className="qa-page">
      <CommonPageHeader
        icon={<ClipboardCheck size={21} />}
        title="QA Inspection"
        subtitle="Inspect submitted garments, record checklist results and control quality decisions."
        rightContent={
          <div className="qa-header-actions">
            {/* <span className="qa-role-chip"><ShieldAlert size={14} /> {DEMO_USER_ROLE}</span> */}
            <CommonButton
              leftIcon={<QrCode size={16} />}
              onClick={() => setScannerOpen(true)}
            >
              Scan QR
            </CommonButton>
            <CommonButton
              variant="outline"
              leftIcon={<Settings2 size={16} />}
              onClick={() => setConfigOpen(true)}
            >
              Checklist Setup
            </CommonButton>
          </div>
        }
      />

      {notice && (
        <div className="qa-notice">
          <CheckCircle2 size={16} />
          <span>{notice}</span>
          <button
            type="button"
            onClick={() => setNotice("")}
            aria-label="Dismiss notice"
          >
            <XCircle size={16} />
          </button>
        </div>
      )}

      <div className="qa-metrics-grid">
        <article className="qa-metric-card">
          <span className="qa-metric-icon">
            <ClipboardCheck size={18} />
          </span>
          <div>
            <small>
              {stationFilter ? "Station Inspections" : "Total Inspections"}
            </small>
            <strong>{stationQueueCount + totalInspections}</strong>
            <span>
              {stationQueueCount} awaiting · {totalInspections} completed
            </span>
          </div>
        </article>
        <article className="qa-metric-card">
          <span className="qa-metric-icon qa-metric-icon--pass">
            <BadgeCheck size={18} />
          </span>
          <div>
            <small>First-time QA Pass Rate</small>
            <strong>{firstPassRate}%</strong>
            <span>
              {firstPasses} / {firstInspections.length} first inspections passed
            </span>
          </div>
        </article>
        <article className="qa-metric-card">
          <span className="qa-metric-icon qa-metric-icon--reject">
            <RotateCcw size={18} />
          </span>
          <div>
            <small>Total Rejections</small>
            <strong>{totalRejections}</strong>
            <span>Returned for rework</span>
          </div>
        </article>
        <article className="qa-metric-card">
          <span className="qa-metric-icon qa-metric-icon--repeat">
            <ActivityIcon />{" "}
          </span>
          <div>
            <small>Secondary Rework Rate</small>
            <strong>{secondaryReworkRate}%</strong>
            <span>{garmentsWithRepeatInspection} garments re-inspected</span>
          </div>
        </article>
        <article className="qa-metric-card">
          <span className="qa-metric-icon qa-metric-icon--scrap">
            <Trash2 size={18} />
          </span>
          <div>
            <small>Scrap Count</small>
            <strong>{scrappedCount}</strong>
            <span>Authorised scrap decisions</span>
          </div>
        </article>
      </div>

      <div className="qa-tabs">
        <button
          type="button"
          className={activeTab === "queue" ? "is-active" : ""}
          onClick={() => {
            setActiveTab("queue");
            setSelectedId(null);
          }}
        >
          <ClipboardCheck size={16} /> Inspection Queue{" "}
          <span>{records.length}</span>
        </button>
        <button
          type="button"
          className={activeTab === "history" ? "is-active" : ""}
          onClick={() => {
            setActiveTab("history");
            setSelectedId(null);
          }}
        >
          <History size={16} /> Inspection History{" "}
          <span>{completedRecords.length}</span>
        </button>
      </div>

      {selectedRecord ? (
        <section className="qa-inspection-workspace">
          <div className="qa-workspace-heading">
            <div>
              <button
                type="button"
                className="qa-back-link"
                onClick={() => {
                  setSelectedId(null);
                  resetInspectionForm();
                }}
              >
                <ArrowLeft size={15} /> Back to queue
              </button>
              <h3>Garment Quality Inspection</h3>
              <p>
                Complete each active checklist item before submitting the
                inspection.
              </p>
            </div>
            <span className="qa-inspection-number">
              Inspection #{selectedRecord.inspectionHistory.length + 1}
            </span>
          </div>

          <div className="qa-garment-summary">
            <div className="qa-garment-image-wrap">
              <button
                type="button"
                className="qa-garment-image"
                title="Click here to view full image"
                onClick={() =>
                  selectedRecord.garmentImage &&
                  setPreviewImage(selectedRecord.garmentImage)
                }
              >
                {selectedRecord.garmentImage ? (
                  <img src={selectedRecord.garmentImage} alt="Garment" />
                ) : (
                  <PackageCheck size={28} />
                )}
              </button>
              {selectedRecord.garmentImage && (
                <button
                  type="button"
                  className="qa-image-view-link"
                  onClick={() => setPreviewImage(selectedRecord.garmentImage!)}
                >
                  Click here to view
                </button>
              )}
            </div>
            <div className="qa-garment-info">
              <span className="qa-eyebrow">{selectedRecord.qrId}</span>
              <h4>{selectedRecord.reworkId}</h4>
              <p>
                {selectedRecord.poNumber} · Size {selectedRecord.size}
              </p>
              <div className="qa-garment-tags">
                <span>{selectedRecord.stationName}</span>
                <span
                  className={`qa-severity qa-severity--${selectedRecord.severity.toLowerCase()}`}
                >
                  {selectedRecord.severity}
                </span>
              </div>
            </div>
            <div className="qa-submitted-meta">
              <small>Submitted for QA</small>
              <strong>{formatDate(selectedRecord.submittedAt)}</strong>
              <small>Operator: {selectedRecord.operatorName}</small>
            </div>
          </div>

          <div className="qa-defect-note">
            <AlertCircle size={17} />
            <div>
              <strong>Original defect / repair note</strong>
              <p>{selectedRecord.description}</p>
            </div>
          </div>

          <div className="qa-checklist-panel">
            <div className="qa-section-heading">
              <div>
                <h4>
                  <ListChecks size={18} /> Quality Checklist
                </h4>
                <p>Mark each item Pass or Fail. Remarks are optional.</p>
              </div>
              <div className="qa-checklist-header-actions">
                <span>
                  {
                    Object.values(responses).filter(
                      (item) => item.result !== "Pending",
                    ).length
                  }{" "}
                  / {activeChecklist.length} completed
                </span>
                <CommonButton
                  size="sm"
                  variant="success"
                  leftIcon={<CheckCircle2 size={14} />}
                  onClick={() => {
                    const allPassed: Record<string, ChecklistResponse> = {};
                    activeChecklist.forEach((item) => {
                      allPassed[item.id] = {
                        itemId: item.id,
                        itemTitle: item.title,
                        category: item.category,
                        result: "Pass",
                        remarks: responses[item.id]?.remarks ?? "",
                      };
                    });
                    setResponses(allPassed);
                    setFormError("");
                  }}
                >
                  Pass All
                </CommonButton>
              </div>
            </div>

            {activeChecklist.map((item, index) => {
              const response = responses[item.id];
              return (
                <div className="qa-checklist-row" key={item.id}>
                  <div className="qa-checklist-index">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <div className="qa-checklist-content">
                    <div className="qa-checklist-title">
                      <strong>{item.title}</strong>
                      {item.required && <span>Required</span>}
                      <small>{item.category}</small>
                    </div>
                    <CommonInput
                      value={response?.remarks ?? ""}
                      onChange={(event) =>
                        updateResponseRemarks(item, event.target.value)
                      }
                      placeholder="Optional remarks..."
                      containerClassName="qa-checklist-remarks"
                    />
                  </div>
                  <div className="qa-checklist-actions">
                    <CommonButton
                      size="sm"
                      variant={
                        response?.result === "Pass" ? "success" : "outline"
                      }
                      leftIcon={<Check size={14} />}
                      onClick={() => updateResponse(item, "Pass")}
                    >
                      Pass
                    </CommonButton>
                    <CommonButton
                      size="sm"
                      variant={
                        response?.result === "Fail" ? "danger" : "outline"
                      }
                      leftIcon={<XCircle size={14} />}
                      onClick={() => updateResponse(item, "Fail")}
                    >
                      Fail
                    </CommonButton>
                  </div>
                </div>
              );
            })}

            <div className="qa-overall-remarks">
              <CommonTextArea
                label="Overall Inspection Remarks"
                value={inspectionRemarks}
                onChange={(event) => setInspectionRemarks(event.target.value)}
                rows={3}
                placeholder="Add overall inspection observations..."
              />
            </div>
          </div>

          {formError && (
            <div className="qa-form-error">
              <AlertCircle size={15} />
              {formError}
            </div>
          )}

          <div className="qa-decision-actions">
            <div>
              <strong>Inspection Decision</strong>
              <small>
                Submitted inspections are locked and cannot be edited.
              </small>
            </div>
            <div className="qa-decision-buttons">
              <CommonButton
                variant="success"
                leftIcon={<CheckCircle2 size={16} />}
                onClick={() => openDecision("QA Passed")}
              >
                QA Passed
              </CommonButton>
              <CommonButton
                variant="danger"
                leftIcon={<RotateCcw size={16} />}
                onClick={() => openDecision("QA Rejected")}
              >
                QA Rejected
              </CommonButton>
              <CommonButton
                variant="outline"
                leftIcon={<Trash2 size={16} />}
                onClick={() => openDecision("Scrap")}
              >
                Irreparable / Scrap
              </CommonButton>
            </div>
          </div>
        </section>
      ) : activeTab === "queue" ? (
        <section className="qa-list-panel">
          <div className="qa-list-heading">
            <div>
              <h3>
                <ClipboardCheck size={18} /> Garments Awaiting Inspection
              </h3>
              <p>
                Only garments submitted by a repair station appear in this
                queue.
              </p>
            </div>
            <span className="qa-result-count">
              {filteredRecords.length} records
            </span>
          </div>

          {scanFilterChip}

          <div className="qa-filters">
            <div className="qa-filter-title">
              <Filter size={15} /> Filters
            </div>
            <div className="row g-3 align-items-end">
              <div className="col-xl-3 col-lg-4 col-md-6">
                <CommonSelect
                  label="Submitted Station"
                  value={stationFilter}
                  onChange={(value) => setStationFilter(String(value ?? ""))}
                  options={stationOptions}
                  placeholder="All stations"
                  filter
                  // showClear
                />
              </div>
              <div className="col-xl-3 col-lg-4 col-md-6">
                <CommonSelect
                  label="PO Number"
                  value={poFilter}
                  onChange={(value) => setPOFilter(String(value ?? ""))}
                  options={poOptions}
                  placeholder="All purchase orders"
                  filter
                  // showClear
                />
              </div>
              <div className="col-xl-2 col-lg-2 col-md-6">
                <CommonInput
                  label="From Date"
                  type="date"
                  value={dateFrom}
                  onChange={(event) => setDateFrom(event.target.value)}
                />
              </div>
              <div className="col-xl-2 col-lg-2 col-md-6">
                <CommonInput
                  label="To Date"
                  type="date"
                  value={dateTo}
                  onChange={(event) => setDateTo(event.target.value)}
                />
              </div>
              <div className="col-xl-2 col-lg-12 col-md-12 qa-reset-filter">
                <button
                  type="button"
                  className="qa-reset-icon"
                  title="Reset filters"
                  aria-label="Reset filters"
                  onClick={() => {
                    setStationFilter("");
                    setPOFilter("");
                    setDateFrom("");
                    setDateTo("");
                    setScannedQr("");
                  }}
                >
                  <RotateCcw size={17} />
                </button>
              </div>
            </div>
          </div>
          <CommonDataTable
            data={filteredRecords}
            columns={queueColumns}
            dataKey="id"
            rows={8}
            emptyMessage={
              scannedQr
                ? "No garment in the QA queue matches the scanned QR."
                : "No garments are waiting for QA inspection."
            }
          />
        </section>
      ) : (
        <section className="qa-list-panel">
          <div className="qa-list-heading">
            <div>
              <h3>
                <FileClock size={18} /> Inspection History
              </h3>
              <p>Submitted inspections are retained as immutable records.</p>
            </div>
            <span className="qa-result-count">
              {filteredCompletedRecords.length} garments
            </span>
          </div>

          {scanFilterChip}

          <CommonDataTable
            data={filteredCompletedRecords}
            columns={historyColumns}
            dataKey="id"
            rows={8}
            emptyMessage={
              scannedQr
                ? "No inspection history matches the scanned QR."
                : "No inspection records have been submitted yet."
            }
          />
          <div className="qa-history-details">
            {filteredCompletedRecords.map((record) => (
              <details key={record.id} className="qa-history-card">
                <summary>
                  <span>
                    {record.reworkId} · {record.poNumber}
                  </span>
                  <strong>
                    {record.inspectionHistory.length} inspection(s)
                  </strong>
                </summary>
                {record.inspectionHistory.map((inspection) => (
                  <div className="qa-history-entry" key={inspection.id}>
                    <div>
                      <strong>
                        Inspection #{inspection.inspectionNumber} —{" "}
                        {inspection.decision}
                      </strong>
                      <small>
                        {formatDate(inspection.inspectedAt)} ·{" "}
                        {inspection.inspector}
                      </small>
                    </div>
                    <p>
                      {inspection.reason ||
                        inspection.remarks ||
                        "No additional remarks recorded."}
                    </p>
                    {inspection.rejectionImage && (
                      <button
                        type="button"
                        className="qa-image-view-link"
                        onClick={() =>
                          setPreviewImage(inspection.rejectionImage!)
                        }
                      >
                        View rejected-item photo
                      </button>
                    )}
                    <div className="qa-history-checks">
                      {inspection.checklist.map((item) => (
                        <span
                          key={item.itemId}
                          className={
                            item.result === "Fail"
                              ? "is-fail"
                              : item.result === "Pass"
                                ? "is-pass"
                                : ""
                          }
                        >
                          {item.itemTitle}: {item.result}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </details>
            ))}
          </div>
          <div className="qa-failure-panel">
            <div>
              <h4>Checklist Failure Distribution</h4>
              <p>
                Failure count by checklist category across submitted
                inspections.
              </p>
            </div>
            {failureDistribution.length ? (
              failureDistribution.map(([category, count]) => (
                <div className="qa-failure-row" key={category}>
                  <span>{category}</span>
                  <strong>{count}</strong>
                </div>
              ))
            ) : (
              <div className="qa-empty-analytics">
                No checklist failures recorded yet.
              </div>
            )}
          </div>
        </section>
      )}

      {/* QR SCANNER MODAL */}

      <CommonModal
        show={scannerOpen}
        onClose={() => setScannerOpen(false)}
        title="Scan Garment QR"
        subtitle="Scan or enter a garment QR to show its QA records."
        headerIcon={<QrCode size={19} />}
        size="md"
        showFooter={false}
      >
        {/* Mounted only while open, so the camera is released on close. */}
        {scannerOpen && (
          <ReusableQRScanner
            onDetected={handleQrDetected}
            onClose={() => setScannerOpen(false)}
          />
        )}
      </CommonModal>

      <CommonModal
        show={!!decisionModal}
        onClose={() => {
          setDecisionModal(null);
          setFormError("");
        }}
        title={
          decisionModal === "QA Passed"
            ? "Approve garment for packing"
            : decisionModal === "QA Rejected"
              ? "Return garment for secondary rework"
              : "Record irreparable garment"
        }
        subtitle="This creates a permanent inspection record. The submitted inspection cannot be edited."
        headerIcon={
          decisionModal === "QA Passed" ? (
            <PackageCheck size={19} />
          ) : decisionModal === "QA Rejected" ? (
            <RotateCcw size={19} />
          ) : (
            <Trash2 size={19} />
          )
        }
        size="md"
        footer={
          <div className="qa-modal-footer">
            <CommonButton
              variant="outline"
              onClick={() => setDecisionModal(null)}
            >
              Cancel
            </CommonButton>
            <CommonButton
              variant={
                decisionModal === "QA Rejected" || decisionModal === "Scrap"
                  ? "danger"
                  : "primary"
              }
              onClick={submitInspection}
            >
              Confirm {decisionModal}
            </CommonButton>
          </div>
        }
      >
        <div className="qa-decision-modal">
          {decisionModal === "QA Passed" ? (
            <div className="qa-modal-info qa-modal-info--success">
              <CheckCircle2 size={19} />
              <p>
                All required checklist items passed. This garment will be
                approved for packing.
              </p>
            </div>
          ) : decisionModal === "QA Rejected" ? (
            <>
              <div className="qa-modal-info qa-modal-info--warning">
                <AlertCircle size={19} />
                <p>
                  Failed checklist items will be retained. The garment will
                  return to the selected station for secondary rework.
                </p>
              </div>
              <CommonTextArea
                label="Rejection Reason"
                value={decisionReason}
                onChange={(event) => setDecisionReason(event.target.value)}
                rows={3}
                required
                placeholder="Explain why this garment failed QA..."
              />
              <CommonSelect
                label="Return to Station"
                value={returnStationId}
                onChange={(value) =>
                  setReturnStationId(value ? String(value) : null)
                }
                options={initialStations
                  .filter((station) => station.status === "Active")
                  .map((station) => ({
                    label: station.name,
                    value: station.id,
                  }))}
                placeholder="Select rework station"
                filter
              />
              <QARejectPhotoCapture
                value={rejectedPhoto}
                onChange={setRejectedPhoto}
              />
              <CommonTextArea
                label="Additional Remarks"
                value={decisionRemarks}
                onChange={(event) => setDecisionRemarks(event.target.value)}
                rows={2}
                placeholder="Optional remarks..."
              />
            </>
          ) : (
            <>
              <div className="qa-modal-info qa-modal-info--danger">
                <ShieldAlert size={19} />
                <p>
                  Scrap decisions are restricted to authorised roles. Current
                  demo role: <strong>{DEMO_USER_ROLE}</strong>.
                </p>
              </div>
              <CommonTextArea
                label="Scrap Reason"
                value={decisionReason}
                onChange={(event) => setDecisionReason(event.target.value)}
                rows={3}
                required
                placeholder="Enter the reason this garment is irreparable..."
              />
              <CommonTextArea
                label="Inspection Details / Remarks"
                value={decisionRemarks}
                onChange={(event) => setDecisionRemarks(event.target.value)}
                rows={3}
                placeholder="Record supporting inspection details..."
              />
            </>
          )}
          {formError && (
            <div className="qa-form-error">
              <AlertCircle size={15} />
              {formError}
            </div>
          )}
        </div>
      </CommonModal>

      <CommonModal
        show={!!previewImage}
        onClose={() => setPreviewImage(null)}
        title="Garment Image Preview"
        subtitle="Full-size garment reference image."
        headerIcon={<ImageIcon size={19} />}
        size="lg"
        showFooter={false}
        className="qa-image-preview-modal"
      >
        {previewImage && (
          <img
            className="qa-full-preview-image"
            src={previewImage}
            alt="Full garment preview"
          />
        )}
      </CommonModal>

      <CommonModal
        show={configOpen}
        onClose={() => setConfigOpen(false)}
        title="QA Checklist Configuration"
        subtitle="Demo configuration controls. In production, restrict this screen to Administrator permissions."
        headerIcon={<Settings2 size={19} />}
        size="lg"
      >
        <div className="qa-config-modal">
          <div className="qa-config-list">
            {checklist.map((item) => (
              <div
                className={`qa-config-item ${!item.active ? "is-disabled" : ""}`}
                key={item.id}
              >
                <div>
                  <strong>{item.title}</strong>
                  <small>
                    {item.category} · {item.required ? "Required" : "Optional"}
                  </small>
                </div>
                <CommonButton
                  size="sm"
                  variant={item.active ? "outline" : "secondary"}
                  onClick={() => toggleChecklistItem(item.id)}
                >
                  {item.active ? "Disable" : "Enable"}
                </CommonButton>
              </div>
            ))}
          </div>
          <div className="qa-config-add">
            <div className="row g-3">
              <div className="col-md-7">
                <CommonInput
                  label="New checklist item"
                  value={newChecklistTitle}
                  onChange={(event) => setNewChecklistTitle(event.target.value)}
                  placeholder="Enter checklist item..."
                />
              </div>
              <div className="col-md-5">
                <CommonSelect
                  label="Category"
                  value={newChecklistCategory}
                  onChange={(value) =>
                    setNewChecklistCategory(
                      String(value ?? "Additional Checks"),
                    )
                  }
                  options={[
                    "Stitching & Seams",
                    "Fabric Appearance",
                    "Fabric Integrity",
                    "Measurements",
                    "Accessories & Trims",
                    "Finishing",
                    "Additional Checks",
                  ].map((value) => ({ label: value, value }))}
                />
              </div>
            </div>
            <CommonButton
              leftIcon={<Check size={15} />}
              disabled={!newChecklistTitle.trim()}
              onClick={addChecklistItem}
            >
              Add Checklist Item
            </CommonButton>
          </div>
          <p className="qa-config-note">
            Checklist changes apply to new inspections in this browser session.
            Connect this configuration to your Administrator API before
            production.
          </p>
        </div>
      </CommonModal>
    </div>
  );
}

function LockIcon() {
  return <Clock3 size={13} />;
}

function ActivityIcon() {
  return <RotateCcw size={18} />;
}