export { default } from "./QAInspectionPage";
