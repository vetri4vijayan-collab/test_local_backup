export type ChecklistResult = "Pass" | "Fail" | "Pending";
export type InspectionDecision = "QA Passed" | "QA Rejected" | "Scrap";

export interface ChecklistItem {
  id: string;
  title: string;
  category: string;
  active: boolean;
  required: boolean;
}

export interface ChecklistResponse {
  itemId: string;
  itemTitle: string;
  category: string;
  result: ChecklistResult;
  remarks: string;
}

export interface QAInspectionRecord {
  id: string;
  workOrderId: string;
  reworkId: string;
  qrId: string;
  garmentId: string;
  poNumber: string;
  size: string;
  stationId: string;
  stationName: string;
  operatorName: string;
  defectCategory: string;
  severity: "Minor" | "Major" | "Critical";
  description: string;
  garmentImage?: string;
  submittedAt: string;
  decision?: InspectionDecision;
  inspectionNumber: number;
  inspectionHistory: InspectionHistoryItem[];
}

export interface InspectionHistoryItem {
  id: string;
  inspectionNumber: number;
  decision: InspectionDecision;
  reason: string;
  remarks: string;
  inspectedAt: string;
  inspector: string;
  checklist: ChecklistResponse[];
  returnedStationId?: string;
  rejectionImage?: string;
}
