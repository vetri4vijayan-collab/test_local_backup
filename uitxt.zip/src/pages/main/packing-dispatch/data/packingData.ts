import { initialWorkOrders } from "@/pages/main/station-management/data/stationData";

import {
  QA_APPROVED_GARMENTS_STORAGE_KEY,
  type QAApprovedGarmentSnapshot,
} from "@/pages/main/qa-inspection/data/qaApprovalStorage";

import type { PackingGarment } from "../types/packingTypes";

// ======================================================
// PURCHASE ORDER DETAILS
// ======================================================

const purchaseOrderAttributes: Record<
  string,
  {
    sku: string;
    color: string;
    style: string;
  }
> = {
  "PO-2026-9041": {
    sku: "SKU-001",
    color: "Blue",
    style: "STY-OX-882",
  },
  "PO-2026-9042": {
    sku: "SKU-002",
    color: "Dark Blue",
    style: "SH-202",
  },
  "PO-2026-9045": {
    sku: "SKU-003",
    color: "Grey",
    style: "TS-305",
  },
  "PO-2026-9048": {
    sku: "SKU-004",
    color: "White",
    style: "JK-408",
  },
  "PO-2026-9050": {
    sku: "SKU-005",
    color: "Black",
    style: "PL-105",
  },
  "PO-2026-9052": {
    sku: "SKU-006",
    color: "Black",
    style: "SH-202",
  },
  "PO-2026-9055": {
    sku: "SKU-007",
    color: "Pink",
    style: "TS-305",
  },
  "PO-2026-9058": {
    sku: "SKU-008",
    color: "Beige",
    style: "JK-408",
  },
};

// ======================================================
// DEMO QA PASSED GARMENTS
// 12 GARMENTS PER PURCHASE ORDER
// ======================================================

const sizes = [
  "S",
  "M",
  "L",
  "XL",
  "XXL",
  "M",
  "L",
  "S",
  "XL",
  "M",
  "L",
  "XXL",
];

const purchaseOrders = Object.keys(purchaseOrderAttributes);

const demoApprovedGarments: QAApprovedGarmentSnapshot[] =
  purchaseOrders.flatMap((poNumber, poIndex) => {
    const attributes = purchaseOrderAttributes[poNumber];

    return Array.from({ length: 12 }, (_, index) => {
      const garmentNumber = index + 1;
      const serial = String(garmentNumber).padStart(3, "0");

      return {
        id: `QA-DEMO-${poNumber}-${serial}`,

        workOrderId: `WO-${poNumber}-${serial}`,

        garmentId: `GR-${poNumber}-${serial}`,

        qrId: `QR-${poNumber}-${serial}`,

        poNumber,

        styleNumber: attributes.style,

        size: sizes[index],

        qaApprovedAt: new Date(
          2026,
          10,
          18 + ((poIndex + index) % 6),
          9 + (index % 8),
          (index * 5) % 60
        ).toISOString(),
      };
    });
  });

// ======================================================
// CONVERT QA SNAPSHOT TO PACKING GARMENT
// ======================================================

const toPackingGarment = (
  record: QAApprovedGarmentSnapshot
): PackingGarment => {
  const attributes = purchaseOrderAttributes[record.poNumber] ?? {
    sku: "—",
    color: "—",
    style: "—",
  };

  return {
    id: record.id,
    workOrderId: record.workOrderId,
    garmentId: record.garmentId,
    qrId: record.qrId,
    poNumber: record.poNumber,
    styleNumber: record.styleNumber,
    sku: attributes.sku,
    color: attributes.color,
    size: record.size,
    qaApprovedAt: record.qaApprovedAt,
    qaStatus: "QA Passed",
  };
};

// ======================================================
// GET PACKING GARMENTS
// ======================================================

export const getPackingGarments = (): PackingGarment[] => {
  // Existing QA Passed work orders
  const seeded: QAApprovedGarmentSnapshot[] = initialWorkOrders
    .filter((workOrder) => workOrder.status === "QA Passed")
    .map((workOrder) => ({
      id: `QA-${workOrder.id}`,
      workOrderId: workOrder.id,
      garmentId: workOrder.garmentId,
      qrId: workOrder.qrId,
      poNumber: workOrder.poNumber,
      styleNumber: workOrder.styleNumber,
      size: workOrder.size,
      qaApprovedAt:
        workOrder.completedAt ?? workOrder.registeredAt,
    }));

  // Actual approvals from QA Inspection module
  let saved: QAApprovedGarmentSnapshot[] = [];

  try {
    const raw = localStorage.getItem(
      QA_APPROVED_GARMENTS_STORAGE_KEY
    );

    saved = raw
      ? (JSON.parse(raw) as QAApprovedGarmentSnapshot[])
      : [];
  } catch {
    saved = [];
  }

  // Merge existing work orders + demo data + actual QA approvals
  // Latest saved QA records take precedence for matching garment IDs.
  const byGarmentId = new Map<
    string,
    QAApprovedGarmentSnapshot
  >();

  [...seeded, ...demoApprovedGarments, ...saved].forEach(
    (record) => {
      byGarmentId.set(record.garmentId, record);
    }
  );

  return Array.from(byGarmentId.values()).map(
    toPackingGarment
  );
};

// ======================================================
// PURCHASE ORDER DROPDOWN OPTIONS
// ======================================================

export const purchaseOrderOptions = Object.keys(
  purchaseOrderAttributes
).map((poNumber) => ({
  label: poNumber,
  value: poNumber,
}));