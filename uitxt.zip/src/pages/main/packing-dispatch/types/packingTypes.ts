export type CartonStatus = "Open" | "Closed";
export type DispatchStatus = "Not Ready" | "Ready for Dispatch";

export interface PackingGarment {
  id: string;
  workOrderId: string;
  garmentId: string;
  qrId: string;
  poNumber: string;
  styleNumber: string;
  sku: string;
  color: string;
  size: string;
  qaApprovedAt: string;
  qaStatus: "QA Passed";
}

export interface CartonRemovalLog {
  id: string;
  garmentId: string;
  reason: string;
  removedAt: string;
  removedBy: string;
}

export interface PackingCarton {
  id: string;
  cartonId: string;
  poNumber: string;
  packingDateTime: string;
  packedBy: string;
  remarks: string;
  status: CartonStatus;
  dispatchStatus: DispatchStatus;
  garmentIds: string[];
  createdAt: string;
  closedAt?: string;
  removalLogs: CartonRemovalLog[];
}
