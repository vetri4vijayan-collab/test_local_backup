import { useEffect, useMemo, useState } from "react";
import {
  Archive,
  Check,
  CheckCircle2,
  ClipboardCheck,
  Clock3,
  Eye,
  History,
  Package,
  PackageCheck,
  Plus,
  QrCode,
  RefreshCw,
  ScanLine,
  Search,
  ShieldCheck,
  Trash2,
  Truck,
  X,
} from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import {
  CommonDataTable,
  type TableColumn,
} from "@/components/common/data-table";
import QRScannerModal from "@/pages/main/station-management/components/QRScannerModal";

import { getPackingGarments, purchaseOrderOptions } from "./data/packingData";
import type { PackingCarton, PackingGarment } from "./types/packingTypes";
import "./PackingDispatchPage.scss";

type ActiveTab = "ready" | "cartons" | "history";
type SelectableGarment = PackingGarment & { selected: boolean };

const STORAGE_KEY = "penguin.packing-dispatch.cartons.v1";
const currentDateTime = () => {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
};

const readStoredCartons = (): PackingCarton[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? (JSON.parse(stored) as PackingCarton[]) : [];
  } catch {
    return [];
  }
};

const formatDate = (value?: string) => {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const getNextCartonId = (cartons: PackingCarton[]) => {
  const year = new Date().getFullYear();
  const prefix = `PKG-${year}-`;
  const lastNumber = cartons.reduce((max, carton) => {
    if (!carton.cartonId.startsWith(prefix)) return max;
    const value = Number(carton.cartonId.slice(prefix.length));
    return Number.isFinite(value) ? Math.max(max, value) : max;
  }, 0);
  return `${prefix}${String(lastNumber + 1).padStart(3, "0")}`;
};

const countBy = (items: PackingGarment[], key: "size" | "color") => {
  const counts = new Map<string, number>();
  items.forEach((item) =>
    counts.set(item[key], (counts.get(item[key]) ?? 0) + 1),
  );
  return Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b));
};

export default function PackingDispatchPage() {
  const [cartons, setCartons] = useState<PackingCarton[]>(readStoredCartons);
  const [qaApprovedGarments] = useState<PackingGarment[]>(getPackingGarments);
  const [activeTab, setActiveTab] = useState<ActiveTab>("ready");
  const [selectedPO, setSelectedPO] = useState<string | null>(null);
  const [selectedCartonId, setSelectedCartonId] = useState<string | null>(null);

  const [styleFilter, setStyleFilter] = useState("");
  const [colorFilter, setColorFilter] = useState("");
  const [sizeFilter, setSizeFilter] = useState<string | null>(null);
  const [qaDateFrom, setQaDateFrom] = useState("");
  const [qaDateTo, setQaDateTo] = useState("");

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createPO, setCreatePO] = useState<string | null>(null);
  const [packedBy, setPackedBy] = useState("");
  const [packingDateTime, setPackingDateTime] = useState(currentDateTime);
  const [cartonRemarks, setCartonRemarks] = useState("");

  const [showAddModal, setShowAddModal] = useState(false);
  const [manualSearch, setManualSearch] = useState("");
  const [selectedGarmentIds, setSelectedGarmentIds] = useState<string[]>([]);
  const [showScanner, setShowScanner] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [removalTarget, setRemovalTarget] = useState<PackingGarment | null>(
    null,
  );
  const [removalReason, setRemovalReason] = useState("");
  const [historyCarton, setHistoryCarton] = useState<PackingCarton | null>(
    null,
  );
  const [notice, setNotice] = useState<{
    type: "success" | "error" | "info";
    text: string;
  } | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cartons));
  }, [cartons]);

  const assignedGarmentIds = useMemo(
    () => new Set(cartons.flatMap((carton) => carton.garmentIds)),
    [cartons],
  );

  const packingReady = useMemo(() => {
    return qaApprovedGarments.filter((garment) => {
      if (assignedGarmentIds.has(garment.garmentId)) return false;
      if (selectedPO && garment.poNumber !== selectedPO) return false;
      if (
        styleFilter &&
        !garment.styleNumber.toLowerCase().includes(styleFilter.toLowerCase())
      )
        return false;
      if (
        colorFilter &&
        !garment.color.toLowerCase().includes(colorFilter.toLowerCase())
      )
        return false;
      if (sizeFilter && garment.size !== sizeFilter) return false;
      const approvedDate = garment.qaApprovedAt.slice(0, 10);
      if (qaDateFrom && approvedDate < qaDateFrom) return false;
      if (qaDateTo && approvedDate > qaDateTo) return false;
      return true;
    });
  }, [
    assignedGarmentIds,
    selectedPO,
    styleFilter,
    colorFilter,
    sizeFilter,
    qaDateFrom,
    qaDateTo,
  ]);

  const activeCartons = cartons.filter((carton) => carton.status === "Open");
  const closedCartons = cartons.filter((carton) => carton.status === "Closed");
  const activeCarton =
    cartons.find(
      (carton) => carton.id === selectedCartonId && carton.status === "Open",
    ) ?? null;
  const activeCartonGarments = activeCarton
    ? activeCarton.garmentIds
        .map((id) =>
          qaApprovedGarments.find((garment) => garment.garmentId === id),
        )
        .filter((item): item is PackingGarment => Boolean(item))
    : [];

  const manualCandidates = useMemo(() => {
    if (!activeCarton) return [];
    return qaApprovedGarments.filter((garment) => {
      if (
        garment.poNumber !== activeCarton.poNumber ||
        assignedGarmentIds.has(garment.garmentId)
      )
        return false;
      const query = manualSearch.trim().toLowerCase();
      return (
        !query ||
        [
          garment.garmentId,
          garment.qrId,
          garment.styleNumber,
          garment.size,
          garment.color,
        ].some((value) => value.toLowerCase().includes(query))
      );
    });
  }, [activeCarton, assignedGarmentIds, manualSearch]);

  const stats = [
    {
      label: "QA Passed",
      value: qaApprovedGarments.length,
      icon: <ShieldCheck size={18} />,
      tone: "green",
    },
    {
      label: "Packing Ready",
      value: qaApprovedGarments.filter(
        (item) => !assignedGarmentIds.has(item.garmentId),
      ).length,
      icon: <PackageCheck size={18} />,
      tone: "blue",
    },
    {
      label: "Open Cartons",
      value: activeCartons.length,
      icon: <Package size={18} />,
      tone: "amber",
    },
    {
      label: "Ready for Dispatch",
      value: closedCartons.length,
      icon: <Truck size={18} />,
      tone: "purple",
    },
  ];

  const notify = (type: "success" | "error" | "info", text: string) => {
    setNotice({ type, text });
  };

  const createCarton = () => {
    if (!createPO) {
      notify("error", "Please select a purchase order.");
      return;
    }
    if (!packedBy.trim()) {
      notify("error", "Please enter the packed-by name.");
      return;
    }
    const carton: PackingCarton = {
      id: `carton-${Date.now()}`,
      cartonId: getNextCartonId(cartons),
      poNumber: createPO,
      packingDateTime,
      packedBy: packedBy.trim(),
      remarks: cartonRemarks.trim(),
      status: "Open",
      dispatchStatus: "Not Ready",
      garmentIds: [],
      createdAt: new Date().toISOString(),
      removalLogs: [],
    };
    setCartons((current) => [carton, ...current]);
    setSelectedCartonId(carton.id);
    setSelectedPO(createPO);
    setActiveTab("cartons");
    setShowCreateModal(false);
    setCartonRemarks("");
    setNotice({
      type: "success",
      text: `${carton.cartonId} created. Add QA-passed garments to this carton.`,
    });
  };

  const addGarmentsToCarton = (garmentIds: string[]) => {
    if (!activeCarton || garmentIds.length === 0) return;
    const validIds = garmentIds.filter((id) => {
      const garment = qaApprovedGarments.find((item) => item.garmentId === id);
      return (
        garment &&
        garment.poNumber === activeCarton.poNumber &&
        !assignedGarmentIds.has(id)
      );
    });
    if (validIds.length === 0) {
      notify("error", "No eligible QA-passed garments were available to add.");
      return;
    }
    setCartons((current) =>
      current.map((carton) =>
        carton.id === activeCarton.id
          ? { ...carton, garmentIds: [...carton.garmentIds, ...validIds] }
          : carton,
      ),
    );
    setSelectedGarmentIds([]);
    setManualSearch("");
    setShowAddModal(false);
    notify(
      "success",
      `${validIds.length} garment(s) added to ${activeCarton.cartonId}.`,
    );
  };

  const handleQrDetected = (value: string) => {
    setShowScanner(false);
    if (!activeCarton) return;
    const garment = qaApprovedGarments.find(
      (item) =>
        item.qrId.toLowerCase() === value.trim().toLowerCase() ||
        item.garmentId.toLowerCase() === value.trim().toLowerCase(),
    );
    if (!garment) {
      notify(
        "error",
        `QR ${value} was not found in the QA-passed garment list.`,
      );
      return;
    }
    if (garment.poNumber !== activeCarton.poNumber) {
      notify(
        "error",
        `${garment.garmentId} belongs to ${garment.poNumber}. This carton is for ${activeCarton.poNumber}.`,
      );
      return;
    }
    if (assignedGarmentIds.has(garment.garmentId)) {
      notify("error", `${garment.garmentId} is already assigned to a carton.`);
      return;
    }
    addGarmentsToCarton([garment.garmentId]);
  };

  const closeCarton = () => {
    if (!activeCarton) return;
    if (activeCarton.garmentIds.length === 0) {
      notify("error", "Add at least one garment before closing this carton.");
      setShowCloseModal(false);
      return;
    }
    const now = new Date().toISOString();
    setCartons((current) =>
      current.map((carton) =>
        carton.id === activeCarton.id
          ? {
              ...carton,
              status: "Closed",
              dispatchStatus: "Ready for Dispatch",
              closedAt: now,
            }
          : carton,
      ),
    );
    setShowCloseModal(false);
    setSelectedCartonId(null);
    setActiveTab("history");
    notify(
      "success",
      `${activeCarton.cartonId} closed and marked Ready for Dispatch.`,
    );
  };

  const removeGarment = () => {
    if (!activeCarton || !removalTarget || !removalReason.trim()) return;
    const log = {
      id: `remove-${Date.now()}`,
      garmentId: removalTarget.garmentId,
      reason: removalReason.trim(),
      removedAt: new Date().toISOString(),
      removedBy: packedBy.trim() || activeCarton.packedBy,
    };
    setCartons((current) =>
      current.map((carton) =>
        carton.id === activeCarton.id
          ? {
              ...carton,
              garmentIds: carton.garmentIds.filter(
                (id) => id !== removalTarget.garmentId,
              ),
              removalLogs: [...carton.removalLogs, log],
            }
          : carton,
      ),
    );
    setRemovalTarget(null);
    setRemovalReason("");
    notify(
      "success",
      `${removalTarget.garmentId} removed and returned to Packing Ready.`,
    );
  };

  const resetFilters = () => {
    setStyleFilter("");
    setColorFilter("");
    setSizeFilter(null);
    setQaDateFrom("");
    setQaDateTo("");
  };

  const readyColumns: TableColumn<PackingGarment>[] = [
    {
      field: "garmentId",
      header: "Garment ID",
      minWidth: "145px",
      body: (row) => (
        <div className="pkg-primary-cell">
          {/* <strong>{row.garmentId}</strong> */}
          <strong>{row.qrId}</strong>
        </div>
      ),
    },
    { field: "poNumber", header: "Purchase Order", minWidth: "145px" },
    {
      field: "styleNumber",
      header: "Style / SKU",
      minWidth: "130px",
      body: (row) => (
        <div className="pkg-primary-cell">
          <strong>{row.styleNumber}</strong>
          <small>{row.sku}</small>
        </div>
      ),
    },
    { field: "color", header: "Colour", minWidth: "105px" },
    { field: "size", header: "Size", minWidth: "70px", align: "center" },
    {
      field: "qaApprovedAt",
      header: "QA Approval Date",
      minWidth: "155px",
      body: (row) => formatDate(row.qaApprovedAt),
    },
    {
      field: "qaStatus",
      header: "QA Status",
      minWidth: "110px",
      body: () => (
        <span className="pkg-status pkg-status--success">
          <CheckCircle2 size={13} /> QA Pass
        </span>
      ),
    },
  ];

  const cartonGarmentColumns: TableColumn<PackingGarment>[] = [
    {
      field: "garmentId",
      header: "Garment ID",
      minWidth: "145px",
      body: (row) => (
        <div className="pkg-primary-cell">
          {/* <strong>{row.garmentId}</strong> */}
          <strong>{row.qrId}</strong>
        </div>
      ),
    },
    {
      field: "styleNumber",
      header: "Style / SKU",
      minWidth: "130px",
      body: (row) => (
        <div className="pkg-primary-cell">
          <strong>{row.styleNumber}</strong>
          <small>{row.sku}</small>
        </div>
      ),
    },
    { field: "color", header: "Colour", minWidth: "100px" },
    { field: "size", header: "Size", minWidth: "70px", align: "center" },
    {
      field: "id",
      header: "Action",
      minWidth: "90px",
      align: "center",
      body: (row) => (
        <button
          type="button"
          className="pkg-icon-action pkg-icon-action--danger"
          title="Remove garment"
          onClick={() => {
            setRemovalTarget(row);
            setRemovalReason("");
          }}
        >
          <Trash2 size={15} />
        </button>
      ),
    },
  ];

  const manualColumns: TableColumn<SelectableGarment>[] = [
    {
      field: "selected",
      header: "Select",
      width: "62px",
      align: "center",
      body: (row) => (
        <input
          aria-label={`Select ${row.garmentId}`}
          className="pkg-checkbox"
          type="checkbox"
          checked={selectedGarmentIds.includes(row.garmentId)}
          onChange={(event) =>
            setSelectedGarmentIds((current) =>
              event.target.checked
                ? [...current, row.garmentId]
                : current.filter((id) => id !== row.garmentId),
            )
          }
        />
      ),
    },
    {
      field: "garmentId",
      header: "Garment ID",
      minWidth: "135px",
      body: (row) => (
        <div className="pkg-primary-cell">
         {/*  <strong>{row.garmentId}</strong> */}
          <strong>{row.qrId}</strong>
        </div>
      ),
    },
    {
      field: "styleNumber",
      header: "Style / SKU",
      minWidth: "120px",
      body: (row) => (
        <div className="pkg-primary-cell">
          <strong>{row.styleNumber}</strong>
          <small>{row.sku}</small>
        </div>
      ),
    },
    { field: "color", header: "Colour", minWidth: "90px" },
    { field: "size", header: "Size", minWidth: "65px", align: "center" },
  ];

  const historyColumns: TableColumn<PackingCarton>[] = [
    {
      field: "cartonId",
      header: "Carton ID",
      minWidth: "145px",
      body: (row) => (
        <div className="pkg-primary-cell">
          <strong>{row.cartonId}</strong>
          <small>{row.garmentIds.length} garments</small>
        </div>
      ),
    },
    { field: "poNumber", header: "Purchase Order", minWidth: "145px" },
    {
      field: "packingDateTime",
      header: "Packing Date",
      minWidth: "150px",
      body: (row) => formatDate(row.packingDateTime),
    },
    {
      field: "closedAt",
      header: "Closed At",
      minWidth: "150px",
      body: (row) => formatDate(row.closedAt),
    },
    { field: "packedBy", header: "Packed By", minWidth: "125px" },
    {
      field: "dispatchStatus",
      header: "Dispatch Status",
      minWidth: "160px",
      body: () => (
        <span className="pkg-status pkg-status--success">
          <Truck size={13} /> Ready for Dispatch
        </span>
      ),
    },
    {
      field: "id",
      header: "Action",
      minWidth: "90px",
      align: "center",
      body: (row) => (
        <button
          type="button"
          className="pkg-icon-action"
          title="View carton"
          onClick={() => setHistoryCarton(row)}
        >
          <Eye size={16} />
        </button>
      ),
    },
  ];

  return (
    <div className="packing-dispatch-page">
      <CommonPageHeader
        icon={<PackageCheck size={21} />}
        title="Packing & Dispatch"
        subtitle="Pack only QA-passed garments, manage cartons and track dispatch readiness."
        rightContent={
          <CommonButton
            leftIcon={<Plus size={16} />}
            onClick={() => {
              setCreatePO(selectedPO);
              setPackedBy("");
              setPackingDateTime(currentDateTime());
              setShowCreateModal(true);
            }}
          >
            Create Carton
          </CommonButton>
        }
      />

      {notice && (
        <div className={`pkg-notice pkg-notice--${notice.type}`} role="status">
          {notice.type === "success" ? (
            <CheckCircle2 size={16} />
          ) : notice.type === "error" ? (
            <X size={16} />
          ) : (
            <Clock3 size={16} />
          )}
          <span>{notice.text}</span>
          <button
            type="button"
            aria-label="Dismiss notification"
            onClick={() => setNotice(null)}
          >
            <X size={15} />
          </button>
        </div>
      )}

      <section className="pkg-stats-grid">
        {stats.map((stat) => (
          <article className="pkg-stat-card" key={stat.label}>
            <div className={`pkg-stat-icon pkg-stat-icon--${stat.tone}`}>
              {stat.icon}
            </div>
            <div>
              <span>{stat.label}</span>
              <strong>{stat.value.toLocaleString("en-IN")}</strong>
            </div>
          </article>
        ))}
      </section>

      <section className="pkg-main-card">
        <div className="pkg-tabs" role="tablist" aria-label="Packing sections">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "ready"}
            className={activeTab === "ready" ? "active" : ""}
            onClick={() => setActiveTab("ready")}
          >
            <ClipboardCheck size={16} /> Packing Ready{" "}
            <span>{packingReady.length}</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "cartons"}
            className={activeTab === "cartons" ? "active" : ""}
            onClick={() => setActiveTab("cartons")}
          >
            <Package size={16} /> Active Cartons{" "}
            <span>{activeCartons.length}</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "history"}
            className={activeTab === "history" ? "active" : ""}
            onClick={() => setActiveTab("history")}
          >
            <History size={16} /> Carton History{" "}
            <span>{closedCartons.length}</span>
          </button>
        </div>

        {activeTab === "ready" && (
          <div className="pkg-tab-content">
            <div className="pkg-section-heading">
              <div>
                <h3>QA-passed garments</h3>
                <p>
                  Only garments with a QA Passed status are eligible for
                  packing.
                </p>
              </div>
              <div className="pkg-section-actions">
                <CommonButton
                  variant="outline"
                  size="sm"
                  leftIcon={<RefreshCw size={14} />}
                  onClick={resetFilters}
                >
                  Reset Filters
                </CommonButton>
                <CommonButton
                  size="sm"
                  leftIcon={<Plus size={14} />}
                  disabled={!selectedPO || packingReady.length === 0}
                  onClick={() => {
                    setCreatePO(selectedPO);
                    setPackedBy("");
                    setPackingDateTime(currentDateTime());
                    setShowCreateModal(true);
                  }}
                >
                  Create Carton
                </CommonButton>
              </div>
            </div>

            <div className="pkg-filter-panel">
              <div className="pkg-filter-po">
                <CommonSelect
                  label="Purchase Order"
                  options={purchaseOrderOptions}
                  value={selectedPO}
                  onChange={(value) =>
                    setSelectedPO(value ? String(value) : null)
                  }
                  placeholder="Select purchase order"
                  filter
                  showClear
                />
              </div>
              <div>
                <CommonInput
                  label="Style Number"
                  value={styleFilter}
                  onChange={(event) => setStyleFilter(event.target.value)}
                  placeholder="Search style"
                  leftElement={<Search size={15} />}
                />
              </div>
              <div>
                <CommonInput
                  label="Colour"
                  value={colorFilter}
                  onChange={(event) => setColorFilter(event.target.value)}
                  placeholder="Search colour"
                />
              </div>
              <div>
                <CommonSelect
                  label="Size"
                  options={["XS", "S", "M", "L", "XL", "XXL"].map((size) => ({
                    label: size,
                    value: size,
                  }))}
                  value={sizeFilter}
                  onChange={(value) =>
                    setSizeFilter(value ? String(value) : null)
                  }
                  placeholder="All sizes"
                  showClear
                />
              </div>
              <div>
                <CommonInput
                  label="QA Date From"
                  type="date"
                  value={qaDateFrom}
                  onChange={(event) => setQaDateFrom(event.target.value)}
                />
              </div>
              <div>
                <CommonInput
                  label="QA Date To"
                  type="date"
                  value={qaDateTo}
                  onChange={(event) => setQaDateTo(event.target.value)}
                />
              </div>
            </div>

            {!selectedPO ? (
              <div className="pkg-empty-state">
                <div>
                  <Package size={25} />
                </div>
                <strong>Select a purchase order</strong>
                <p>
                  Choose a PO to view its QA-passed garments available for
                  packing.
                </p>
              </div>
            ) : (
              <>
                <div className="pkg-table-meta">
                  <span>
                    <strong>{packingReady.length}</strong> eligible garment(s)
                  </span>
                  <span className="pkg-qa-verified">
                    <ShieldCheck size={14} /> QA Pass verified
                  </span>
                </div>
                <CommonDataTable
                  data={packingReady}
                  columns={readyColumns}
                  dataKey="garmentId"
                  paginator
                  rows={8}
                  rowsPerPageOptions={[5, 8, 10, 25]}
                  size="small"
                  emptyMessage="No QA-passed garments are available for this purchase order."
                  className="pkg-data-table"
                />
              </>
            )}
          </div>
        )}

        {activeTab === "cartons" && (
          <div className="pkg-tab-content pkg-carton-layout">
            <aside className="pkg-carton-sidebar">
              <div className="pkg-sidebar-heading">
                <div>
                  <h3>Open Cartons</h3>
                  <p>{activeCartons.length} in progress</p>
                </div>
                <button
                  type="button"
                  title="Create carton"
                  onClick={() => {
                    setCreatePO(selectedPO);
                    setPackedBy("");
                    setPackingDateTime(currentDateTime());
                    setShowCreateModal(true);
                  }}
                >
                  <Plus size={17} />
                </button>
              </div>
              {activeCartons.length === 0 ? (
                <div className="pkg-sidebar-empty">
                  No open cartons yet. Create a carton to start packing.
                </div>
              ) : (
                activeCartons.map((carton) => (
                  <button
                    type="button"
                    key={carton.id}
                    className={`pkg-carton-list-item ${selectedCartonId === carton.id ? "selected" : ""}`}
                    onClick={() => setSelectedCartonId(carton.id)}
                  >
                    <span className="pkg-carton-list-icon">
                      <Package size={17} />
                    </span>
                    <span className="pkg-carton-list-copy">
                      <strong>{carton.cartonId}</strong>
                      <small>{carton.poNumber}</small>
                      <small>{carton.garmentIds.length} garment(s)</small>
                    </span>
                    <span className="pkg-open-dot" />
                  </button>
                ))
              )}
            </aside>

            <div className="pkg-carton-workspace">
              {!activeCarton ? (
                <div className="pkg-empty-state pkg-workspace-empty">
                  <div>
                    <PackageCheck size={26} />
                  </div>
                  <strong>Select an open carton</strong>
                  <p>
                    Choose a carton from the left panel or create a new carton
                    to begin.
                  </p>
                  <CommonButton
                    leftIcon={<Plus size={15} />}
                    onClick={() => {
                      setCreatePO(selectedPO);
                      setPackedBy("");
                      setPackingDateTime(currentDateTime());
                      setShowCreateModal(true);
                    }}
                  >
                    Create Carton
                  </CommonButton>
                </div>
              ) : (
                <>
                  <div className="pkg-workspace-heading">
                    <div>
                      <div className="pkg-eyebrow">CARTON PACKING</div>
                      <h3>{activeCarton.cartonId}</h3>
                      <p>
                        {activeCarton.poNumber} <span>·</span> Created{" "}
                        {formatDate(activeCarton.createdAt)}
                      </p>
                    </div>
                    <span className="pkg-status pkg-status--warning">
                      <Clock3 size={13} /> Open
                    </span>
                  </div>
                  <div className="pkg-carton-info-grid">
                    <div>
                      <span>Purchase Order</span>
                      <strong>{activeCarton.poNumber}</strong>
                    </div>
                    <div>
                      <span>Packing Date</span>
                      <strong>
                        {formatDate(activeCarton.packingDateTime)}
                      </strong>
                    </div>
                    <div>
                      <span>Packed By</span>
                      <strong>{activeCarton.packedBy}</strong>
                    </div>
                    <div>
                      <span>Carton Quantity</span>
                      <strong>{activeCarton.garmentIds.length} garments</strong>
                    </div>
                  </div>
                  <div className="pkg-add-toolbar">
                    <div>
                      <h4>Carton Contents</h4>
                      <p>
                        Scan a garment QR or select QA-passed garments manually.
                      </p>
                    </div>
                    <div>
                      <CommonButton
                        variant="outline"
                        leftIcon={<QrCode size={15} />}
                        onClick={() => setShowScanner(true)}
                      >
                        Scan QR
                      </CommonButton>
                      <CommonButton
                        leftIcon={<Plus size={15} />}
                        onClick={() => {
                          setSelectedGarmentIds([]);
                          setManualSearch("");
                          setShowAddModal(true);
                        }}
                      >
                        Add Manually
                      </CommonButton>
                    </div>
                  </div>
                  {activeCartonGarments.length ? (
                    <CommonDataTable
                      data={activeCartonGarments}
                      columns={cartonGarmentColumns}
                      dataKey="garmentId"
                      paginator
                      rows={6}
                      rowsPerPageOptions={[5, 6, 10]}
                      size="small"
                      emptyMessage="No garments added yet."
                      className="pkg-data-table"
                    />
                  ) : (
                    <div className="pkg-empty-state pkg-carton-empty">
                      <div>
                        <ScanLine size={25} />
                      </div>
                      <strong>No garments added</strong>
                      <p>
                        Scan a garment QR code or manually select eligible
                        garments from {activeCarton.poNumber}.
                      </p>
                      <div>
                        <CommonButton
                          variant="outline"
                          leftIcon={<QrCode size={15} />}
                          onClick={() => setShowScanner(true)}
                        >
                          Scan QR
                        </CommonButton>
                        <CommonButton
                          leftIcon={<Plus size={15} />}
                          onClick={() => setShowAddModal(true)}
                        >
                          Select Garments
                        </CommonButton>
                      </div>
                    </div>
                  )}

                  {activeCartonGarments.length > 0 && (
                    <div className="pkg-quantity-summary">
                      <div className="pkg-quantity-total">
                        <span>Total Carton Quantity</span>
                        <strong>{activeCartonGarments.length}</strong>
                      </div>
                      <div className="pkg-quantity-breakdown">
                        <div>
                          <span>Quantity by Size</span>
                          <div>
                            {countBy(activeCartonGarments, "size").map(
                              ([key, count]) => (
                                <small key={key}>
                                  {key}
                                  <b>{count}</b>
                                </small>
                              ),
                            )}
                          </div>
                        </div>
                        <div>
                          <span>Quantity by Colour</span>
                          <div>
                            {countBy(activeCartonGarments, "color").map(
                              ([key, count]) => (
                                <small key={key}>
                                  {key}
                                  <b>{count}</b>
                                </small>
                              ),
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeCarton.remarks && (
                    <div className="pkg-carton-remarks">
                      <strong>Remarks</strong>
                      <p>{activeCarton.remarks}</p>
                    </div>
                  )}
                  {activeCarton.removalLogs.length > 0 && (
                    <div className="pkg-removal-log">
                      <strong>Removal history</strong>
                      <span>
                        {activeCarton.removalLogs.length} garment removal(s)
                        recorded with reason.
                      </span>
                    </div>
                  )}
                  <div className="pkg-carton-footer">
                    <span>
                      <ShieldCheck size={14} /> Only QA-passed garments can be
                      added
                    </span>
                    <CommonButton
                      leftIcon={<Check size={16} />}
                      disabled={activeCartonGarments.length === 0}
                      onClick={() => setShowCloseModal(true)}
                    >
                      Review & Close Carton
                    </CommonButton>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="pkg-tab-content">
            <div className="pkg-section-heading">
              <div>
                <h3>Closed Cartons</h3>
                <p>
                  Closed cartons are read-only and marked ready for dispatch.
                </p>
              </div>
              <span className="pkg-history-count">
                <Archive size={15} /> {closedCartons.length} records
              </span>
            </div>
            <CommonDataTable
              data={closedCartons}
              columns={historyColumns}
              dataKey="id"
              paginator
              rows={8}
              rowsPerPageOptions={[5, 8, 10, 25]}
              size="small"
              emptyMessage="No closed carton records found."
              className="pkg-data-table"
            />
            <div className="pkg-history-note">
              <Truck size={16} />
              <span>
                Carrier booking and shipping-label integrations are not included
                in this release.
              </span>
            </div>
          </div>
        )}
      </section>

      {/* CREATE CARTON */}
      <CommonModal
        show={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New Carton"
        subtitle="Create a carton for one purchase order. Garments from different POs cannot be mixed."
        headerIcon={<Package size={19} />}
        size="md"
        footer={
          <>
            <CommonButton
              variant="outline"
              onClick={() => setShowCreateModal(false)}
            >
              Cancel
            </CommonButton>
            <CommonButton leftIcon={<Plus size={15} />} onClick={createCarton}>
              Create Carton
            </CommonButton>
          </>
        }
      >
        <div className="pkg-modal-form">
          <div className="pkg-generated-id">
            <span>Next Carton ID</span>
            <strong>{getNextCartonId(cartons)}</strong>
            <small>Generated automatically</small>
          </div>
          <CommonSelect
            label="Purchase Order"
            options={purchaseOrderOptions}
            value={createPO}
            onChange={(value) => setCreatePO(value ? String(value) : null)}
            placeholder="Select purchase order"
            required
            filter
          />
          <CommonInput
            label="Packing Date & Time"
            type="datetime-local"
            value={packingDateTime}
            onChange={(event) => setPackingDateTime(event.target.value)}
            required
          />
          <CommonInput
            label="Packed By"
            value={packedBy}
            onChange={(event) => setPackedBy(event.target.value)}
            placeholder="Enter packing operator name"
            required
          />
          <CommonTextArea
            label="Remarks"
            value={cartonRemarks}
            onChange={(event) => setCartonRemarks(event.target.value)}
            placeholder="Add carton remarks (optional)"
            rows={3}
          />
        </div>
      </CommonModal>

      {/* MANUAL GARMENT SELECTION */}
      <CommonModal
        show={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add QA-passed Garments"
        subtitle={
          activeCarton
            ? `Select garments belonging to ${activeCarton.poNumber}.`
            : "Select eligible garments."
        }
        headerIcon={<ClipboardCheck size={19} />}
        size="xl"
        footer={
          <>
            <span className="pkg-modal-selection-count">
              {selectedGarmentIds.length} selected
            </span>
            <CommonButton
              variant="outline"
              onClick={() => setShowAddModal(false)}
            >
              Cancel
            </CommonButton>
            <CommonButton
              leftIcon={<Plus size={15} />}
              disabled={!selectedGarmentIds.length}
              onClick={() => addGarmentsToCarton(selectedGarmentIds)}
            >
              Add Selected Garments
            </CommonButton>
          </>
        }
      >
        <div className="pkg-manual-modal">
          <div className="pkg-manual-modal-top">
            <div className="pkg-manual-po">
              <span>Purchase Order</span>
              <strong>{activeCarton?.poNumber ?? "—"}</strong>
            </div>
            <div className="pkg-manual-search">
              <CommonInput
                value={manualSearch}
                onChange={(event) => setManualSearch(event.target.value)}
                placeholder="Search garment, QR, style, size..."
                leftElement={<Search size={15} />}
              />
            </div>
          </div>
          <CommonDataTable
            data={manualCandidates.map((item) => ({
              ...item,
              selected: selectedGarmentIds.includes(item.garmentId),
            }))}
            columns={manualColumns}
            dataKey="garmentId"
            paginator
            rows={6}
            rowsPerPageOptions={[5, 6, 10]}
            size="small"
            emptyMessage="No unassigned QA-passed garments are available for this PO."
            className="pkg-data-table"
          />
        </div>
      </CommonModal>

      {/* CLOSE CARTON CONFIRMATION */}
      <CommonModal
        show={showCloseModal}
        onClose={() => setShowCloseModal(false)}
        title="Confirm & Close Carton"
        subtitle="Please review the carton quantity before closing."
        headerIcon={<PackageCheck size={19} />}
        size="sm"
        footer={
          <>
            <CommonButton
              variant="outline"
              onClick={() => setShowCloseModal(false)}
            >
              Go Back
            </CommonButton>
            <CommonButton
              leftIcon={<CheckCircle2 size={15} />}
              onClick={closeCarton}
            >
              Confirm & Close
            </CommonButton>
          </>
        }
      >
        <div className="pkg-close-confirm">
          <div className="pkg-close-confirm-icon">
            <CheckCircle2 size={24} />
          </div>
          <strong>{activeCarton?.cartonId}</strong>
          <span>{activeCarton?.poNumber}</span>
          <div className="pkg-close-quantity">
            <span>Garments in carton</span>
            <strong>{activeCartonGarments.length}</strong>
          </div>
          <p>
            After closing, carton contents cannot be changed. The carton will be
            marked <b>Ready for Dispatch</b>.
          </p>
        </div>
      </CommonModal>

      {/* REMOVE GARMENT WITH REASON */}
      <CommonModal
        show={Boolean(removalTarget)}
        onClose={() => {
          setRemovalTarget(null);
          setRemovalReason("");
        }}
        title="Remove Garment from Carton"
        subtitle="A removal reason is required for the packing audit trail."
        headerIcon={<Trash2 size={18} />}
        size="sm"
        footer={
          <>
            <CommonButton
              variant="outline"
              onClick={() => {
                setRemovalTarget(null);
                setRemovalReason("");
              }}
            >
              Cancel
            </CommonButton>
            <CommonButton
              variant="danger"
              leftIcon={<Trash2 size={15} />}
              disabled={!removalReason.trim()}
              onClick={removeGarment}
            >
              Remove Garment
            </CommonButton>
          </>
        }
      >
        <div className="pkg-remove-form">
          <div className="pkg-remove-garment">
            <span>Garment ID</span>
            {/* <strong>{removalTarget?.garmentId}</strong> */}
            <strong>{removalTarget?.qrId}</strong>
          </div>
          <CommonTextArea
            label="Reason for Removal"
            value={removalReason}
            onChange={(event) => setRemovalReason(event.target.value)}
            placeholder="Enter the reason for removing this garment..."
            rows={4}
            required
          />
        </div>
      </CommonModal>

      {/* CARTON HISTORY DETAILS */}
      <CommonModal
        show={Boolean(historyCarton)}
        onClose={() => setHistoryCarton(null)}
        title={historyCarton?.cartonId ?? "Carton Details"}
        subtitle="Closed carton record · Read only"
        headerIcon={<Archive size={19} />}
        size="lg"
        footer={
          <CommonButton
            variant="outline"
            onClick={() => setHistoryCarton(null)}
          >
            Close
          </CommonButton>
        }
      >
        {historyCarton && (
          <div className="pkg-history-detail">
            <div className="pkg-carton-info-grid">
              <div>
                <span>Purchase Order</span>
                <strong>{historyCarton.poNumber}</strong>
              </div>
              <div>
                <span>Packing Date</span>
                <strong>{formatDate(historyCarton.packingDateTime)}</strong>
              </div>
              <div>
                <span>Closed At</span>
                <strong>{formatDate(historyCarton.closedAt)}</strong>
              </div>
              <div>
                <span>Packed By</span>
                <strong>{historyCarton.packedBy}</strong>
              </div>
            </div>
            <div className="pkg-history-detail-status">
              <span className="pkg-status pkg-status--success">
                <Truck size={13} /> Ready for Dispatch
              </span>
              <strong>{historyCarton.garmentIds.length} garments packed</strong>
            </div>
            <CommonDataTable
              data={historyCarton.garmentIds
                .map((id) =>
                  qaApprovedGarments.find((item) => item.garmentId === id),
                )
                .filter((item): item is PackingGarment => Boolean(item))}
              columns={cartonGarmentColumns.filter(
                (column) => column.field !== "id",
              )}
              dataKey="garmentId"
              paginator
              rows={6}
              size="small"
              className="pkg-data-table"
            />
          </div>
        )}
      </CommonModal>

      <QRScannerModal
        show={showScanner}
        onClose={() => setShowScanner(false)}
        onDetected={handleQrDetected}
      />
    </div>
  );
}
