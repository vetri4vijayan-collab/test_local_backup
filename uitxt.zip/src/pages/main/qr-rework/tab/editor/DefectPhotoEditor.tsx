import { useEffect, useRef, useState } from "react";
import {
  Circle,
  Square,
  Pencil,
  Eraser,
  Undo2,
  RotateCcw,
  X,
  Check,
} from "lucide-react";

import "./DefectPhotoEditor.scss";

type Tool = "circle" | "rectangle" | "pencil" | "eraser";

type Point = {
  x: number;
  y: number;
};

type Mark = {
  id: string;
  tool: Exclude<Tool, "eraser">;
  start: Point;
  end: Point;
  points: Point[];
  color: string;
  lineWidth: number;
};

type Props = {
  image: string;
  imageName: string;
  onClose: () => void;
  onSave: (annotatedImage: string, caption: string) => void;
};

const createId = () => crypto.randomUUID();

export default function DefectPhotoEditor({
  image,
  imageName,
  onClose,
  onSave,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const drawingRef = useRef(false);

  const [activeTool, setActiveTool] = useState<Tool>("circle");
  const [marks, setMarks] = useState<Mark[]>([]);
  const [activeMark, setActiveMark] = useState<Mark | null>(null);
  const [caption, setCaption] = useState(
    "Damaged area marked on garment",
  );
  const [color, setColor] = useState("#ff4242");

  const drawMark = (
    context: CanvasRenderingContext2D,
    mark: Mark,
  ) => {
    context.save();
    context.strokeStyle = mark.color;
    context.lineWidth = mark.lineWidth;
    context.lineCap = "round";
    context.lineJoin = "round";

    if (mark.tool === "circle") {
      const centerX = (mark.start.x + mark.end.x) / 2;
      const centerY = (mark.start.y + mark.end.y) / 2;
      const radiusX = Math.abs(mark.end.x - mark.start.x) / 2;
      const radiusY = Math.abs(mark.end.y - mark.start.y) / 2;

      context.beginPath();
      context.ellipse(
        centerX,
        centerY,
        Math.max(radiusX, 1),
        Math.max(radiusY, 1),
        0,
        0,
        Math.PI * 2,
      );
      context.stroke();
    }

    if (mark.tool === "rectangle") {
      context.strokeRect(
        mark.start.x,
        mark.start.y,
        mark.end.x - mark.start.x,
        mark.end.y - mark.start.y,
      );
    }

    if (mark.tool === "pencil") {
      if (!mark.points.length) {
        context.restore();
        return;
      }

      context.beginPath();
      context.moveTo(mark.points[0].x, mark.points[0].y);

      mark.points.slice(1).forEach((point) => {
        context.lineTo(point.x, point.y);
      });

      context.stroke();
    }

    context.restore();
  };

  const redrawCanvas = (
    currentMarks: Mark[],
    previewMark: Mark | null = null,
  ) => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    const loadedImage = imageRef.current;

    if (!canvas || !context || !loadedImage) return;

    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage(loadedImage, 0, 0, canvas.width, canvas.height);

    currentMarks.forEach((mark) => drawMark(context, mark));

    if (previewMark) {
      drawMark(context, previewMark);
    }
  };

  useEffect(() => {
    const loadedImage = new Image();

    loadedImage.onload = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      canvas.width = loadedImage.naturalWidth;
      canvas.height = loadedImage.naturalHeight;

      imageRef.current = loadedImage;
      redrawCanvas([]);
    };

    loadedImage.src = image;
  }, [image]);

  useEffect(() => {
    redrawCanvas(marks, activeMark);
  }, [marks, activeMark]);

  const getCanvasPoint = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ): Point => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();

    return {
      x: (event.clientX - rect.left) * (canvas.width / rect.width),
      y: (event.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const isNearMark = (mark: Mark, point: Point) => {
    const points =
      mark.tool === "pencil"
        ? mark.points
        : [mark.start, mark.end];

    return points.some(
      (item) =>
        Math.hypot(item.x - point.x, item.y - point.y) < 35,
    );
  };

  const handlePointerDown = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    if (!imageRef.current) return;

    const point = getCanvasPoint(event);

    if (activeTool === "eraser") {
      setMarks((previous) =>
        previous.filter((mark) => !isNearMark(mark, point)),
      );
      return;
    }

    event.currentTarget.setPointerCapture(event.pointerId);
    drawingRef.current = true;

    setActiveMark({
      id: createId(),
      tool: activeTool,
      start: point,
      end: point,
      points: [point],
      color,
      lineWidth: Math.max(
        3,
        Math.round((canvasRef.current?.width ?? 1000) / 250),
      ),
    });
  };

  const handlePointerMove = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    if (!drawingRef.current || !activeMark) return;

    const point = getCanvasPoint(event);

    setActiveMark((previous) => {
      if (!previous) return null;

      return {
        ...previous,
        end: point,
        points:
          previous.tool === "pencil"
            ? [...previous.points, point]
            : previous.points,
      };
    });
  };

  const handlePointerUp = () => {
    if (!drawingRef.current) return;

    drawingRef.current = false;

    if (activeMark) {
      setMarks((previous) => [...previous, activeMark]);
    }

    setActiveMark(null);
  };

  const handleUndo = () => {
    setMarks((previous) => previous.slice(0, -1));
  };

  const handleReset = () => {
    setMarks([]);
    setActiveMark(null);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;

    if (!canvas || !imageRef.current) return;

    onSave(canvas.toDataURL("image/png"), caption.trim());
  };

  return (
    <div className="defect-editor-overlay">
      <div className="defect-editor-modal">
        <div className="defect-editor-header">
          <div>
            <h3>Mark Damaged Area</h3>
            <p>
              Select a marking tool and highlight the damaged area on
              the garment.
            </p>
          </div>

          <button
            type="button"
            className="defect-editor-close"
            onClick={onClose}
            aria-label="Close editor"
          >
            <X size={19} />
          </button>
        </div>

        <div className="defect-editor-body">
          <div className="defect-editor-toolbar">
            <div className="defect-editor-tools">
              <button
                type="button"
                className={activeTool === "circle" ? "active" : ""}
                onClick={() => setActiveTool("circle")}
                title="Circle"
              >
                <Circle size={17} />
                <span>Circle</span>
              </button>

              <button
                type="button"
                className={activeTool === "rectangle" ? "active" : ""}
                onClick={() => setActiveTool("rectangle")}
                title="Rectangle"
              >
                <Square size={17} />
                <span>Rectangle</span>
              </button>

              <button
                type="button"
                className={activeTool === "pencil" ? "active" : ""}
                onClick={() => setActiveTool("pencil")}
                title="Pencil"
              >
                <Pencil size={17} />
                <span>Pencil</span>
              </button>

              <button
                type="button"
                className={activeTool === "eraser" ? "active" : ""}
                onClick={() => setActiveTool("eraser")}
                title="Eraser"
              >
                <Eraser size={17} />
                <span>Eraser</span>
              </button>
            </div>

            <div className="defect-editor-toolbar-actions">
              <button
                type="button"
                onClick={handleUndo}
                disabled={!marks.length}
                title="Undo last mark"
              >
                <Undo2 size={16} />
                <span>Undo</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                disabled={!marks.length}
                title="Reset all marks"
              >
                <RotateCcw size={16} />
                <span>Reset</span>
              </button>
            </div>
          </div>

          <div className="defect-editor-canvas-wrap">
            <canvas
              ref={canvasRef}
              className="defect-editor-canvas"
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              onPointerLeave={handlePointerUp}
            />
          </div>

          <div className="defect-editor-options">
            <div className="defect-editor-color">
              <span>Marker color</span>

              <button
                type="button"
                className={color === "#ff4242" ? "selected" : ""}
                style={{ background: "#ff4242" }}
                onClick={() => setColor("#ff4242")}
                aria-label="Red marker"
              />

              <button
                type="button"
                className={color === "#2563eb" ? "selected" : ""}
                style={{ background: "#2563eb" }}
                onClick={() => setColor("#2563eb")}
                aria-label="Blue marker"
              />

              <button
                type="button"
                className={color === "#16a34a" ? "selected" : ""}
                style={{ background: "#16a34a" }}
                onClick={() => setColor("#16a34a")}
                aria-label="Green marker"
              />
            </div>

            <span className="defect-editor-active-tool">
              {activeTool === "eraser"
                ? "Eraser Active"
                : `${activeTool[0].toUpperCase()}${activeTool.slice(1)} Active`}
            </span>
          </div>

          <div className="defect-editor-caption">
            <label htmlFor="defect-caption">
              Damage Caption / Notes
            </label>

            <input
              id="defect-caption"
              value={caption}
              onChange={(event) => setCaption(event.target.value)}
              placeholder="Describe the marked damaged area..."
            />
          </div>

          <div className="defect-editor-file-name">
            Image: {imageName}
          </div>
        </div>

        <div className="defect-editor-footer">
          <button
            type="button"
            className="defect-editor-cancel"
            onClick={onClose}
          >
            Cancel
          </button>

          <button
            type="button"
            className="defect-editor-save"
            onClick={handleSave}
          >
            <Check size={17} />
            Save Annotated Photo
          </button>
        </div>
      </div>
    </div>
  );
}