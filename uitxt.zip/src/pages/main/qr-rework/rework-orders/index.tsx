import { useState } from "react";
import { QrCode, ScanLine } from "lucide-react";

import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import { initialRecords } from "../type/reworkData";
import type { ReworkRecord } from "../type/type";

import "./QRReworkManagementPage.scss";

import QRScannerRegistrationTab from "../tab/QRScannerRegistrationTab";
import ReworkOrdersTab from "../tab/ReworkOrdersTab";
import ReworkTracePage from "../trace";

type ActiveTab = "orders" | "scanner";

export default function QRReworkManagementPage() {
  const [records, setRecords] = useState<ReworkRecord[]>(initialRecords);
  const [activeTab, setActiveTab] = useState<ActiveTab>("scanner");
  const [traceRecord, setTraceRecord] = useState<ReworkRecord | null>(null);

  const handleRegister = (record: ReworkRecord) => {
    setRecords((current) => [record, ...current]);
    setActiveTab("orders");
    setTraceRecord(null);
  };

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    setTraceRecord(null);
  };

  return (
    <div className="qr-rework-page">
      {!traceRecord && (
        <>
          <CommonPageHeader
            icon={<QrCode size={21} />}
            title="QR & Rework Management"
            subtitle="Scan garment QR labels, register defects and manage active rework orders."
          />

          <div className="qr-tab-navigation">
            <button
              type="button"
              className={`qr-header-tab ${
                activeTab === "scanner" ? "active" : ""
              }`}
              onClick={() => handleTabChange("scanner")}
            >
              <span className="qr-tab-icon">
                <ScanLine size={17} />
              </span>

              <span className="qr-tab-content">
                <strong>QR Scanner & Registration</strong>
                <small>Scan labels and register defects</small>
              </span>
            </button>

            <button
              type="button"
              className={`qr-header-tab ${
                activeTab === "orders" ? "active" : ""
              }`}
              onClick={() => handleTabChange("orders")}
            >
              <span className="qr-tab-icon">
                <QrCode size={17} />
              </span>

              <span className="qr-tab-content">
                <strong>Rework Orders</strong>
                <small>{records.length} registered orders</small>
              </span>

              <span className="qr-tab-count">{records.length}</span>
            </button>
          </div>
        </>
      )}

      {traceRecord ? (
        <ReworkTracePage
          record={traceRecord}
          onBack={() => setTraceRecord(null)}
        />
      ) : activeTab === "orders" ? (
        <ReworkOrdersTab records={records} onTrace={setTraceRecord} />
      ) : (
        <QRScannerRegistrationTab onRegister={handleRegister} />
      )}
    </div>
  );
}