import { MapPin, Pencil, ShieldCheck, Trash2 } from "lucide-react";
import type { UserRecord } from "../types/userRoleTypes";

interface UserMobileCardProps {
  user: UserRecord;
  onEdit: (user: UserRecord) => void;
  onDelete: (user: UserRecord) => void;
  onToggleStatus: (id: string) => void;
}

export default function UserMobileCard({
  user,
  onEdit,
  onDelete,
  onToggleStatus,
}: UserMobileCardProps) {
  const initials = user.name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <article className="urm-mobile-user-card">
      <div className="urm-mobile-user-top">
        <div className="urm-user-cell">
          <div className="urm-avatar">
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} />
            ) : (
              initials
            )}
          </div>

          <div className="urm-user-info">
            <strong>{user.name}</strong>
            <span>{user.id}</span>
          </div>
        </div>

        <span className={`urm-status ${user.active ? "active" : "inactive"}`}>
          <span />
          {user.active ? "Active" : "Inactive"}
        </span>
      </div>

      <div className="urm-mobile-user-details">
        <div>
          <span>Email Address</span>
          <strong className="urm-mobile-email">{user.email}</strong>
        </div>

        <div>
          <span>Role / Permission Group</span>
          <strong className="urm-role-badge">
            <ShieldCheck size={13} />
            {user.role}
          </strong>
        </div>

        <div>
          <span>Assigned Station</span>
          <strong>
            <MapPin size={14} />
            {user.station}
          </strong>
        </div>
      </div>

      <div className="urm-mobile-user-actions">
        <button
          type="button"
          className={`urm-switch-button ${user.active ? "" : "is-inactive"}`}
          onClick={() => onToggleStatus(user.id)}
        >
          {user.active ? "Deactivate User" : "Activate User"}
        </button>

        <button
          type="button"
          className="urm-icon-button"
          title="Edit user"
          onClick={() => onEdit(user)}
        >
          <Pencil size={16} />
        </button>

        <button
          type="button"
          className="urm-icon-button danger"
          title="Delete user"
          onClick={() => onDelete(user)}
        >
          <Trash2 size={16} />
        </button>
      </div>
    </article>
  );
}