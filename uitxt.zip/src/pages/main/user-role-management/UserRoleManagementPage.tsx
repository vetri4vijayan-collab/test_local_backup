import { useState } from "react";
import { ShieldCheck, Users } from "lucide-react";

import { initialRoles, initialUsers } from "./data/userRoleData";
import type { RoleRecord, UserRecord } from "./types/userRoleTypes";

import "./UserRoleManagementPage.scss";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import RoleManagementTab from "./tab/RoleManagementTab";
import SystemUsersTab from "./tab/SystemUsersTab";

type ActiveTab = "roles" | "users";

export default function UserRoleManagementPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("roles");

  const [roles, setRoles] = useState<RoleRecord[]>(initialRoles);
  const [users, setUsers] = useState<UserRecord[]>(initialUsers);

  return (
    <div className="user-role-page">
      <CommonPageHeader
        title="User & Role Management"
        icon={<ShieldCheck size={22} />}
        subtitle="Configure security roles, map module permissions, and manage system users."
      />

      {/* Tab Navigation */}
      <div className="urm-tabs-card">
        <div className="urm-tabs" role="tablist" aria-label="User management">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "roles"}
            className={`urm-tab ${activeTab === "roles" ? "active" : ""}`}
            onClick={() => setActiveTab("roles")}
          >
            <ShieldCheck size={18} />
            <span>Roles & Module Mappings</span>
            <span className="urm-tab-count">{roles.length}</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "users"}
            className={`urm-tab ${activeTab === "users" ? "active" : ""}`}
            onClick={() => setActiveTab("users")}
          >
            <Users size={18} />
            <span>System Users</span>
            <span className="urm-tab-count">{users.length}</span>
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="urm-tab-content">
        {activeTab === "roles" ? (
          <RoleManagementTab
            roles={roles}
            users={users}
            onRolesChange={setRoles}
            onUsersChange={setUsers}
          />
        ) : (
          <SystemUsersTab
            users={users}
            roles={roles}
            onUsersChange={setUsers}
          />
        )}
      </div>
    </div>
  );
}
