import { useEffect, useState } from "react";
import { Check, ShieldCheck } from "lucide-react";



import { moduleOptions } from "../data/userRoleData";
import type { RoleRecord } from "../types/userRoleTypes";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";

interface RoleFormModalProps {
  show: boolean;
  role: RoleRecord | null;
  onClose: () => void;
  onSave: (role: RoleRecord) => void;
}

export default function RoleFormModal({
  show,
  role,
  onClose,
  onSave,
}: RoleFormModalProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedModules, setSelectedModules] = useState<string[]>([]);

  useEffect(() => {
    if (show) {
      setName(role?.name ?? "");
      setDescription(role?.description ?? "");
      setSelectedModules(role?.modules ?? []);
    }
  }, [show, role]);

  const toggleModule = (id: string) => {
    setSelectedModules((previous) =>
      previous.includes(id)
        ? previous.filter((item) => item !== id)
        : [...previous, id],
    );
  };

  const toggleAll = () => {
    setSelectedModules((previous) =>
      previous.length === moduleOptions.length
        ? []
        : moduleOptions.map((item) => item.id),
    );
  };

  const handleSave = () => {
    if (!name.trim()) return;

    onSave({
      id: role?.id ?? `ROLE-${Date.now().toString().slice(-6)}`,
      name: name.trim(),
      description: description.trim(),
      modules: selectedModules,
      systemRole: role?.systemRole ?? false,
    });
  };

  return (
    <CommonModal
      show={show}
      onClose={onClose}
      variant="center"
      size="lg"
      title={role ? "Edit Role" : "Create Role"}
      subtitle="Set role details and choose the modules this role can access."
      headerIcon={<ShieldCheck size={20} />}
      showCloseButton
      showFooter
      className="urm-form-modal"
      footer={
        <>
          <button
            type="button"
            className="urm-secondary-button"
            onClick={onClose}
          >
            Cancel
          </button>

          <button
            type="button"
            className="urm-primary-button"
            disabled={!name.trim()}
            onClick={handleSave}
          >
            <Check size={16} />
            {role ? "Update Role" : "Save Role"}
          </button>
        </>
      }
    >
      <div className="urm-modal-form">
        <CommonInput
          label="Role Name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="e.g. Senior QA Manager"
          required
        />

        <CommonInput
          label="Description"
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Brief description of responsibilities..."
        />

        <div className="urm-permission-section">
          <div className="urm-permission-heading">
            <div>
              <label>Map Modules (Check Permissions)</label>
              <p>Select the modules this role is allowed to access.</p>
            </div>

            <button type="button" onClick={toggleAll}>
              {selectedModules.length === moduleOptions.length
                ? "Clear All"
                : "Select All"}
            </button>
          </div>

          <div className="urm-permission-grid">
            {moduleOptions.map((module) => {
              const checked = selectedModules.includes(module.id);

              return (
                <label
                  key={module.id}
                  className={`urm-permission-option ${checked ? "selected" : ""}`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleModule(module.id)}
                  />

                  <span className="urm-permission-icon">{module.icon}</span>
                  <span className="urm-permission-label">{module.label}</span>

                  <span className="urm-checkbox-indicator">
                    {checked && <Check size={13} />}
                  </span>
                </label>
              );
            })}
          </div>

          <div className="urm-permission-footer">
            <ShieldCheck size={15} />
            {selectedModules.length} of {moduleOptions.length} modules selected
          </div>
        </div>
      </div>
    </CommonModal>
  );
}