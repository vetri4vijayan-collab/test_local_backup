
import { useEffect, useRef, useState } from "react";
import {
  Check,
  UserRound,
  Eye,
  EyeOff,
  Upload,
  X,
} from "lucide-react";

import { stationOptions } from "../data/userRoleData";
import type { RoleRecord, UserRecord } from "../types/userRoleTypes";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

interface UserFormModalProps {
  show: boolean;
  user: UserRecord | null;
  roles: RoleRecord[];
  onClose: () => void;
  onSave: (user: UserRecord) => void;
}

export default function UserFormModal({
  show,
  user,
  roles,
  onClose,
  onSave,
}: UserFormModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [role, setRole] = useState<string | null>(null);
  const [station, setStation] = useState<string | null>("General Facility");

  const [avatar, setAvatar] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);

  useEffect(() => {
    if (!show) return;

    setName(user?.name ?? "");
    setEmail(user?.email ?? "");
    setPassword("");
    setShowPassword(false);
    setRole(user?.role ?? roles[0]?.name ?? null);
    setStation(user?.station ?? "General Facility");
    setAvatar(user?.avatar ?? "");
    setAvatarFile(null);
  }, [show, user, roles]);

  const handleAvatarChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      return;
    }

    setAvatarFile(file);

    const previewUrl = URL.createObjectURL(file);
    setAvatar(previewUrl);
  };

  const removeAvatar = () => {
    if (avatar.startsWith("blob:")) {
      URL.revokeObjectURL(avatar);
    }

    setAvatar("");
    setAvatarFile(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSave = () => {
    if (!name.trim() || !email.trim() || !role || !station) return;

    if (!user && !password.trim()) return;

    onSave({
      id: user?.id ?? `USR-${Date.now().toString().slice(-6)}`,
      name: name.trim(),
      email: email.trim(),
      password: password || undefined,
      role,
      station,
      avatar: avatar || undefined,
      avatarFile: avatarFile ?? undefined,
      active: user?.active ?? true,
    } as UserRecord);
  };

  const isFormValid =
    name.trim() &&
    email.trim() &&
    role &&
    station &&
    (user || password.trim());

  return (
    <CommonModal
      show={show}
      onClose={onClose}
      variant="center"
      size="lg"
      title={user ? "Edit System User" : "Create System User"}
      subtitle="Add user details and assign a role and factory station."
      headerIcon={<UserRound size={20} />}
      showCloseButton
      showFooter
      className="urm-form-modal"
      footer={
        <>
          <button
            type="button"
            className="urm-secondary-button"
            onClick={onClose}
          >
            Cancel
          </button>

          <button
            type="button"
            className="urm-primary-button"
            disabled={!isFormValid}
            onClick={handleSave}
          >
            <Check size={16} />
            {user ? "Update User" : "Save User"}
          </button>
        </>
      }
    >
      <div className="urm-modal-form">

        {/* Profile Picture Upload */}
        <div className="urm-avatar-upload">
          <div className="urm-avatar-preview">
            {avatar ? (
              <img src={avatar} alt="Profile preview" />
            ) : (
              <UserRound size={30} />
            )}
          </div>

          <div className="urm-avatar-content">
            <strong>Profile Picture</strong>
            <span>Upload an employee profile image</span>

            <div className="urm-avatar-actions">
              <button
                type="button"
                className="urm-upload-button"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload size={15} />
                Upload Image
              </button>

              {avatar && (
                <button
                  type="button"
                  className="urm-remove-avatar"
                  onClick={removeAvatar}
                >
                  <X size={15} />
                  Remove
                </button>
              )}
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            hidden
            onChange={handleAvatarChange}
          />
        </div>

        <CommonInput
          label="Full Name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="e.g. Johnathan Vance"
          required
        />

        <CommonInput
          label="Email Address"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="e.g. j.vance@factory.net"
          required
        />

        {/* Password */}
        <div className="urm-password-field">
          <CommonInput
            label="Password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder={
              user
                ? "Enter new password (optional)"
                : "Enter account password"
            }
            type={showPassword ? "text" : "password"}
            required={!user}
            rightElement={
              <button
                type="button"
                className="urm-password-toggle"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <EyeOff size={17} />
                ) : (
                  <Eye size={17} />
                )}
              </button>
            }
          />

          {user && (
            <span className="urm-password-hint">
              Leave empty to keep the current password.
            </span>
          )}
        </div>

        <div className="urm-user-form-grid">
          <CommonSelect
            label="Assign Role"
            options={roles.map((item) => ({
              label: item.name,
              value: item.name,
            }))}
            value={role}
            onChange={(value) =>
              setRole(value == null ? null : String(value))
            }
            placeholder="Select role"
            required
          />

          <CommonSelect
            label="Assigned Station"
            options={stationOptions}
            value={station}
            onChange={(value) =>
              setStation(value == null ? null : String(value))
            }
            placeholder="Select station"
            required
            filter
          />
        </div>

      </div>
    </CommonModal>
  );
}
