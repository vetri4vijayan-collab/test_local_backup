import { useMemo, useState } from "react";
import {
  Plus,
  Search,
  ShieldCheck,
  X,
  Trash2,
} from "lucide-react";

import type { RoleRecord, UserRecord } from "../types/userRoleTypes";

import RoleCard from "../card/RoleCard";
import RoleFormModal from "../modal/RoleFormModal";

import CommonModal from "@/components/common/ui/modal/CommonModal";

interface RoleManagementTabProps {
  roles: RoleRecord[];
  users: UserRecord[];
  onRolesChange: (roles: RoleRecord[]) => void;
  onUsersChange: (users: UserRecord[]) => void;
}

export default function RoleManagementTab({
  roles,
  users,
  onRolesChange,
  onUsersChange,
}: RoleManagementTabProps) {
  const [search, setSearch] = useState("");

  const [showModal, setShowModal] = useState(false);
  const [editingRole, setEditingRole] = useState<RoleRecord | null>(null);

  // Delete confirmation modal
  const [deleteRoleTarget, setDeleteRoleTarget] = useState<RoleRecord | null>(
    null,
  );

  // Warning modal
  const [warningMessage, setWarningMessage] = useState("");

  const filteredRoles = useMemo(() => {
    const value = search.toLowerCase().trim();

    if (!value) return roles;

    return roles.filter(
      (role) =>
        role.name.toLowerCase().includes(value) ||
        role.description.toLowerCase().includes(value),
    );
  }, [roles, search]);

  const openCreate = () => {
    setEditingRole(null);
    setShowModal(true);
  };

  const openEdit = (role: RoleRecord) => {
    setEditingRole(role);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingRole(null);
  };

  const saveRole = (updatedRole: RoleRecord) => {
    if (editingRole) {
      onRolesChange(
        roles.map((role) => (role.id === updatedRole.id ? updatedRole : role)),
      );

      if (editingRole.name !== updatedRole.name) {
        onUsersChange(
          users.map((user) =>
            user.role === editingRole.name
              ? { ...user, role: updatedRole.name }
              : user,
          ),
        );
      }
    } else {
      onRolesChange([...roles, updatedRole]);
    }

    closeModal();
  };

  // Open delete confirmation
  const deleteRole = (role: RoleRecord) => {
    if (role.systemRole) {
      setWarningMessage("System roles are protected and cannot be deleted.");
      return;
    }

    const assigned = users.some((user) => user.role === role.name);

    if (assigned) {
      setWarningMessage(
        "This role is currently assigned to users. Reassign those users before deleting this role.",
      );
      return;
    }

    setDeleteRoleTarget(role);
  };

  // Confirm deletion
  const confirmDeleteRole = () => {
    if (!deleteRoleTarget) return;

    onRolesChange(roles.filter((item) => item.id !== deleteRoleTarget.id));

    setDeleteRoleTarget(null);
  };

  const closeWarning = () => {
    setWarningMessage("");
  };

  return (
    <>
      <section className="urm-tab-panel-card">
        <div className="urm-content-toolbar">
          <div className="urm-content-heading">
            <div className="urm-content-heading-icon roles-icon">
              <ShieldCheck size={20} />
            </div>

            <div>
              <h3>Roles & Permissions</h3>
              <p>Manage access levels and module permissions.</p>
            </div>
          </div>

          <div className="urm-tab-actions">
            <div className="urm-search">
              <Search size={17} />

              <input
                type="search"
                placeholder="Search roles..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />

              {search && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setSearch("")}
                >
                  <X size={15} />
                </button>
              )}
            </div>

            <button
              type="button"
              className="urm-primary-button"
              onClick={openCreate}
            >
              <Plus size={16} />
              Create Role
            </button>
          </div>
        </div>

        <div className="urm-panel-divider" />

        <div className="urm-role-grid">
          {filteredRoles.map((role) => (
            <RoleCard
              key={role.id}
              role={role}
              onEdit={openEdit}
              onDelete={deleteRole}
            />
          ))}

          {filteredRoles.length === 0 && (
            <div className="urm-empty-state">
              <ShieldCheck size={34} />
              <h3>No roles found</h3>
              <p>Try another search or create a new role.</p>
            </div>
          )}
        </div>
      </section>
      {/* CREATE / EDIT ROLE MODAL */}
      <RoleFormModal
        show={showModal}
        role={editingRole}
        onClose={closeModal}
        onSave={saveRole}
      />
      {/* WARNING MODAL */}
      {/* DELETE CONFIRMATION MODAL */}
      <CommonModal
        show={!!deleteRoleTarget}
        onClose={() => setDeleteRoleTarget(null)}
        variant="center"
        size="sm"
        title="Delete Role"
        subtitle="Please confirm this action."
        headerIcon={<Trash2 size={20} color="#DC4545"  />}
        showCloseButton
        showFooter={false}
        className="urm-confirm-modal"
      >
        <div className="urm-confirm-content">
          <div className="urm-confirm-text">
            <h4>Are you sure you want to delete this role?</h4>

            <p>
              The role <strong>"{deleteRoleTarget?.name}"</strong> will be
              permanently removed. This action cannot be undone.
            </p>
          </div>
        </div>

        <div className="urm-confirm-actions">
          <button
            type="button"
            className="urm-secondary-button"
            onClick={() => setDeleteRoleTarget(null)}
          >
            Cancel
          </button>

          <button
            type="button"
            className="urm-delete-confirm-button"
            onClick={confirmDeleteRole}
          >
            Delete Role
          </button>
        </div>
      </CommonModal>
      {/* WARNING MODAL */}
      <CommonModal
        show={!!warningMessage}
        onClose={closeWarning}
        variant="center"
        size="sm"
        title="Unable to Delete Role"
        subtitle="This role cannot be deleted."
        showCloseButton
        showFooter={false}
        className="urm-confirm-modal"
      >
        <div className="urm-confirm-content">
          <div className="urm-confirm-text">
            <h4>Deletion is not allowed</h4>

            <p>{warningMessage}</p>
          </div>
        </div>

        <div className="urm-confirm-actions">
          <button
            type="button"
            className="urm-primary-button"
            onClick={closeWarning}
          >
            Got it
          </button>
        </div>
      </CommonModal>
    </>
  );
}
