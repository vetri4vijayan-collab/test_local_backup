import { useMemo, useState } from "react";
import {
  Check,
  Filter,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  Users,
  X,
} from "lucide-react";

import type { RoleRecord, UserRecord } from "../types/userRoleTypes";
import {
  type TableColumn,
  CommonDataTable,
} from "@/components/common/data-table";

import UserMobileCard from "../card/UserMobileCard";
import UserFormModal from "../modal/UserFormModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

interface SystemUsersTabProps {
  users: UserRecord[];
  roles: RoleRecord[];
  onUsersChange: (users: UserRecord[]) => void;
}

export default function SystemUsersTab({
  users,
  roles,
  onUsersChange,
}: SystemUsersTabProps) {
  const [search, setSearch] = useState("");
  const [selectedRole, setSelectedRole] = useState("all");
  const [selectedStation, setSelectedStation] = useState("all");

  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRecord | null>(null);

  const stationOptions = useMemo(
    () =>
      [...new Set(users.map((user) => user.station).filter(Boolean))].sort(),
    [users],
  );

  const filteredUsers = useMemo(() => {
    const value = search.toLowerCase().trim();

    return users.filter((user) => {
      const matchesSearch =
        !value ||
        user.name.toLowerCase().includes(value) ||
        user.email.toLowerCase().includes(value) ||
        user.role.toLowerCase().includes(value) ||
        user.station.toLowerCase().includes(value);

      const matchesRole = selectedRole === "all" || user.role === selectedRole;

      const matchesStation =
        selectedStation === "all" || user.station === selectedStation;

      return matchesSearch && matchesRole && matchesStation;
    });
  }, [users, search, selectedRole, selectedStation]);

  const hasActiveFilters =
    search.trim() !== "" || selectedRole !== "all" || selectedStation !== "all";

  const clearFilters = () => {
    setSearch("");
    setSelectedRole("all");
    setSelectedStation("all");
  };

  const openCreate = () => {
    setEditingUser(null);
    setShowModal(true);
  };

  const openEdit = (user: UserRecord) => {
    setEditingUser(user);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingUser(null);
  };

  const saveUser = (updatedUser: UserRecord) => {
    if (editingUser) {
      onUsersChange(
        users.map((user) => (user.id === updatedUser.id ? updatedUser : user)),
      );
    } else {
      onUsersChange([...users, updatedUser]);
    }

    closeModal();
  };

  const toggleStatus = (id: string) => {
    onUsersChange(
      users.map((user) =>
        user.id === id ? { ...user, active: !user.active } : user,
      ),
    );
  };

  const deleteUser = (user: UserRecord) => {
    if (!window.confirm(`Delete user "${user.name}"?`)) return;

    onUsersChange(users.filter((item) => item.id !== user.id));
  };

  const columns: TableColumn<UserRecord>[] = [
    {
      field: "name",
      header: "User Name",
      minWidth: "220px",
      body: (user) => {
        const initials = user.name
          .split(" ")
          .map((part) => part[0])
          .slice(0, 2)
          .join("")
          .toUpperCase();

        return (
          <div className="urm-user-cell">
            <div className="urm-avatar">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} />
              ) : (
                initials
              )}
            </div>

            <div className="urm-user-info">
              <strong>{user.name}</strong>
              <span>{user.id}</span>
            </div>
          </div>
        );
      },
    },
    {
      field: "email",
      header: "Email",
      minWidth: "240px",
      body: (user) => <span className="urm-email">{user.email}</span>,
    },
    {
      field: "role",
      header: "Role / Permission Group",
      minWidth: "190px",
      body: (user) => (
        <span className="urm-role-badge">
          <ShieldCheck size={13} />
          {user.role}
        </span>
      ),
    },
    {
      field: "station",
      header: "Assigned Station",
      minWidth: "220px",
      body: (user) => <span className="urm-station-cell">{user.station}</span>,
    },
    {
      field: "active",
      header: "Status",
      width: "110px",
      body: (user) => (
        <span className={`urm-status ${user.active ? "active" : "inactive"}`}>
          <span />
          {user.active ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      field: "id",
      header: "Actions",
      width: "160px",
      align: "right",
      body: (user) => (
        <div className="urm-table-actions">
          <button
            type="button"
            className={`urm-switch-button ${user.active ? "" : "is-inactive"}`}
            onClick={() => toggleStatus(user.id)}
          >
            {user.active ? "Deactivate" : "Activate"}
          </button>

          <button
            type="button"
            className="urm-icon-button"
            title="Edit user"
            onClick={() => openEdit(user)}
          >
            <Pencil size={15} />
          </button>

          <button
            type="button"
            className="urm-icon-button danger"
            title="Delete user"
            onClick={() => deleteUser(user)}
          >
            <Trash2 size={15} />
          </button>
        </div>
      ),
    },
  ];

  const activeUsers = users.filter((user) => user.active).length;

  return (
    <>
      <section className="urm-tab-panel-card">
        <div className="urm-content-toolbar">
          <div className="urm-content-heading">
            <div className="urm-content-heading-icon users-icon">
              <Users size={20} />
            </div>

            <div>
              <h3>System Users</h3>
              <p>Manage user accounts, roles and station assignments.</p>
            </div>
          </div>

          <button
            type="button"
            className="urm-primary-button"
            onClick={openCreate}
          >
            <Plus size={16} />
            Create User
          </button>
        </div>

        <div className="urm-user-summary">
          <div className="urm-summary-item">
            <div className="urm-summary-icon blue">
              <Users size={20} />
            </div>
            <div>
              <span>Total Users</span>
              <strong>{users.length}</strong>
            </div>
          </div>

          <div className="urm-summary-item">
            <div className="urm-summary-icon green">
              <Check size={20} />
            </div>
            <div>
              <span>Active Users</span>
              <strong>{activeUsers}</strong>
            </div>
          </div>

          <div className="urm-summary-item">
            <div className="urm-summary-icon violet">
              <ShieldCheck size={20} />
            </div>
            <div>
              <span>Available Roles</span>
              <strong>{roles.length}</strong>
            </div>
          </div>
        </div>

        {/* Filters */}

        <div className="urm-user-filters">
          <div className="urm-filter-heading">
            <Filter size={16} />
            <span>Filter Users</span>
          </div>

          <div className="urm-filter-controls">
            {/* SEARCH */}
            <div className="urm-search urm-user-search">
              <Search size={17} />

              <input
                type="search"
                placeholder="Search name, email..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />

              {search && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setSearch("")}
                >
                  <X size={15} />
                </button>
              )}
            </div>

            {/* ROLE FILTER */}
            <div className="urm-select-filter">
              <CommonSelect
                label="Role"
                options={[
                  { label: "All Roles", value: "all" },
                  ...roles.map((role) => ({
                    label: role.name,
                    value: role.name,
                  })),
                ]}
                value={selectedRole}
                onChange={(value) =>
                  setSelectedRole(value == null ? "all" : String(value))
                }
                placeholder="All Roles"
              />
            </div>

            {/* STATION FILTER */}
            <div className="urm-select-filter">
              <CommonSelect
                label="Station"
                options={[
                  { label: "All Stations", value: "all" },
                  ...stationOptions.map((station) => ({
                    label: station,
                    value: station,
                  })),
                ]}
                value={selectedStation}
                onChange={(value) =>
                  setSelectedStation(value == null ? "all" : String(value))
                }
                placeholder="All Stations"
              />
            </div>

            {/* CLEAR FILTERS */}
            {hasActiveFilters && (
              <button
                type="button"
                className="urm-clear-filters"
                onClick={clearFilters}
              >
                <X size={14} />
                Clear
              </button>
            )}
          </div>
        </div>

        <div className="urm-results-info">
          <span>
            Showing <strong>{filteredUsers.length}</strong> of{" "}
            <strong>{users.length}</strong> users
          </span>
        </div>

        {/* Desktop table */}
        <div className="urm-desktop-table">
          <CommonDataTable
            data={filteredUsers}
            columns={columns}
            dataKey="id"
            rows={8}
            paginator
            rowsPerPageOptions={[5, 8, 10, 20]}
            stripedRows
            emptyMessage="No users found"
            className="urm-data-table"
          />
        </div>

        {/* Mobile cards */}
        <div className="urm-mobile-users">
          {filteredUsers.map((user) => (
            <UserMobileCard
              key={user.id}
              user={user}
              onEdit={openEdit}
              onDelete={deleteUser}
              onToggleStatus={toggleStatus}
            />
          ))}

          {filteredUsers.length === 0 && (
            <div className="urm-empty-state">
              <Users size={34} />
              <h3>No users found</h3>
              <p>Try changing your search or filters.</p>
            </div>
          )}
        </div>
      </section>

      <UserFormModal
        show={showModal}
        user={editingUser}
        roles={roles}
        onClose={closeModal}
        onSave={saveUser}
      />
    </>
  );
}
