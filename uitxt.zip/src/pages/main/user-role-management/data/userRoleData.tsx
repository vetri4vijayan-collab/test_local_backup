
import type {
  ModuleItem,
  RoleRecord,
  UserRecord,
  SelectOption,
} from "../types/userRoleTypes";
import {
  LayoutDashboard,
  ShoppingCart,
  QrCode,
  Factory,
  ClipboardCheck,
  Package,
  Shirt,
  BarChart3,
  Database,
  Users,
  Settings,
} from "lucide-react";

// ======================================================
// MODULE OPTIONS
// ======================================================

export const moduleOptions: ModuleItem[] = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: <LayoutDashboard size={16} />,
  },
  {
    id: "purchase-orders",
    label: "Purchase Orders",
    icon: <ShoppingCart size={16} />,
  },
  {
    id: "qr-rework",
    label: "QR & Rework",
    icon: <QrCode size={16} />,
  },
  {
    id: "station-management",
    label: "Station Management",
    icon: <Factory size={16} />,
  },
  {
    id: "qa-inspection",
    label: "QA Inspection",
    icon: <ClipboardCheck size={16} />,
  },
  {
    id: "packing",
    label: "Packing",
    icon: <Package size={16} />,
  },
  {
    id: "garment-registry",
    label: "Garment Registry",
    icon: <Shirt size={16} />,
  },
  {
    id: "reports",
    label: "Reports",
    icon: <BarChart3 size={16} />,
  },
  {
    id: "master-data",
    label: "Master Data",
    icon: <Database size={16} />,
  },
  {
    id: "user-management",
    label: "User Management",
    icon: <Users size={16} />,
  },
  {
    id: "settings",
    label: "Settings",
    icon: <Settings size={16} />,
  },
];

// ======================================================
// ROLE DATA
// ======================================================

export const initialRoles: RoleRecord[] = [
  {
    id: "ROLE-01",
    name: "Admin",
    description: "Full system access and master configuration",
    modules: [
      "dashboard",
      "purchase-orders",
      "qr-rework",
      "station-management",
      "qa-inspection",
      "packing",
      "garment-registry",
      "reports",
      "master-data",
      "user-management",
      "settings",
    ],
    systemRole: true,
  },
  {
    id: "ROLE-02",
    name: "Rework Inspector",
    description: "Inspects defects and registers garments",
    modules: ["dashboard", "qr-rework", "garment-registry", "reports"],
    systemRole: true,
  },
  {
    id: "ROLE-03",
    name: "Station Operator",
    description: "Operates factory stations and repairs garments",
    modules: ["dashboard", "qr-rework", "station-management"],
    systemRole: true,
  },
  {
    id: "ROLE-04",
    name: "QA Inspector",
    description: "Quality assurance signoff and pass/reject inspection",
    modules: ["dashboard", "qa-inspection", "garment-registry", "reports"],
    systemRole: true,
  },
  {
    id: "ROLE-05",
    name: "Packing Operator",
    description: "Packs QA-passed garments and closes carton packages",
    modules: ["dashboard", "packing", "garment-registry"],
    systemRole: true,
  },
  {
    id: "ROLE-06",
    name: "Production Manager",
    description: "Monitors production progress and manages factory operations",
    modules: [
      "dashboard",
      "purchase-orders",
      "qr-rework",
      "station-management",
      "qa-inspection",
      "packing",
      "garment-registry",
      "reports",
      "master-data",
    ],
    systemRole: true,
  },
  {
    id: "ROLE-07",
    name: "Purchase Manager",
    description: "Manages purchase orders, suppliers and order tracking",
    modules: [
      "dashboard",
      "purchase-orders",
      "garment-registry",
      "reports",
      "master-data",
    ],
    systemRole: true,
  },
  {
    id: "ROLE-179494076398",
    name: "Twest",
    description: "Custom role for selected factory operations",
    modules: ["dashboard", "qr-rework", "purchase-orders"],
    systemRole: false,
  },
];

// ======================================================
// STATION OPTIONS
// ======================================================

export const stationOptions: SelectOption[] = [
  {
    label: "General Facility",
    value: "General Facility",
  },
  {
    label: "Stitching Repair Station Alpha (Floor 2, Zone B)",
    value: "Stitching Repair Station Alpha",
  },
  {
    label: "Final Finishing & Buttoning (Floor 3, Zone B)",
    value: "Final Finishing & Buttoning",
  },
  {
    label: "Stitching Repair Station Beta (Floor 2, Zone D)",
    value: "Stitching Repair Station Beta",
  },
  {
    label: "Heavy Wash & Treatment Bay (Floor 1, Zone B)",
    value: "Heavy Wash & Treatment Bay",
  },
  {
    label: "Advanced Weave Restoration (Floor 2, Zone E)",
    value: "Advanced Weave Restoration",
  },
  {
    label: "Tailoring & Fit Assessment (Floor 3, Zone C)",
    value: "Tailoring & Fit Assessment",
  },
  {
    label: "Express Quality Inspection Bay (Floor 3, Zone D)",
    value: "Express Quality Inspection Bay",
  },
  {
    label: "Stain Removal & Wash Station",
    value: "Stain Removal & Wash Station",
  },
];

// ======================================================
// SYSTEM USERS
// ======================================================

export const initialUsers: UserRecord[] = [
  {
    id: "USR-001",
    name: "Karthik Subramanian",
    email: "karthik.subramanian@penguinapparels.tn",
    role: "Admin",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-002",
    name: "Ananya Ramesh",
    email: "ananya.ramesh@penguinapparels.tn",
    role: "Rework Inspector",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-003",
    name: "Senthil Kumar",
    email: "senthil.kumar@penguinapparels.tn",
    role: "Station Operator",
    station: "Stitching Repair Station Alpha",
    avatar: "",
    active: true,
  },
  {
    id: "USR-004",
    name: "Priya Varatharajan",
    email: "priya.v@penguinapparels.tn",
    role: "QA Inspector",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-005",
    name: "Murugan Selvam",
    email: "murugan.selvam@penguinapparels.tn",
    role: "Packing Operator",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-006",
    name: "Meena Sundaram",
    email: "meena.sundaram@penguinapparels.tn",
    role: "Production Manager",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-007",
    name: "Arunachalam Nathan",
    email: "arun.nathan@penguinapparels.tn",
    role: "Station Operator",
    station: "Stitching Repair Station Alpha",
    avatar: "",
    active: true,
  },
  {
    id: "USR-008",
    name: "Divya Balaji",
    email: "divya.balaji@penguinapparels.tn",
    role: "Station Operator",
    station: "Stain Removal & Wash Station",
    avatar: "",
    active: true,
  },
  {
    id: "USR-009",
    name: "Johnathan Vance",
    email: "j.vance@penguinapparels.tn",
    role: "Purchase Manager",
    station: "General Facility",
    avatar: "",
    active: true,
  },
  {
    id: "USR-010",
    name: "Ravi Shankar",
    email: "ravi.shankar@penguinapparels.tn",
    role: "QA Inspector",
    station: "Express Quality Inspection Bay",
    avatar: "",
    active: false,
  },
];

// ======================================================
// HELPER: GET MODULE LABELS
// ======================================================

export const getModuleLabels = (moduleIds: string[]): string[] => {
  return moduleOptions
    .filter((module) => moduleIds.includes(module.id))
    .map((module) => module.label);
};

// ======================================================
// HELPER: GET ROLE BY NAME
// ======================================================

export const getRoleByName = (roleName: string): RoleRecord | undefined => {
  return initialRoles.find((role) => role.name === roleName);
};

// ======================================================
// HELPER: GET MODULE COUNT
// ======================================================

export const getModuleCount = (moduleIds: string[]): number => {
  return moduleIds.length;
};
