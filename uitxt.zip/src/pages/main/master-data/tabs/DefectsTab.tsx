import { useMemo, useState } from "react";
import {
  Pencil,
  Trash2,
  Clock3,
  AlertTriangle,
  Layers3,
} from "lucide-react";

import CommonTooltip from "@/components/common/ui/tooltip/CommonTooltip";
import CommonSelect from "@/components/common/ui/select/CommonSelect";


import MasterDataToolbar from "../components/MasterDataToolbar";
import { SeverityBadge, StatusBadge } from "../components/StatusBadge";

import type {
  CategoryRecord,
  DefectRecord,
  ViewMode,
} from "../types/masterDataTypes";
import { type TableColumn, CommonDataTable } from "@/components/common/data-table";



interface Props {
  records: DefectRecord[];
  categories: CategoryRecord[];
  onEdit: (item: DefectRecord) => void;
  onDelete: (item: DefectRecord) => void;
}

export default function DefectsTab({
  records,
  categories,
  onEdit,
  onDelete,
}: Props) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string | number>("All");
  const [severity, setSeverity] = useState<string | number>("All");
  const [category, setCategory] = useState<string | number>("All");
  const [view, setView] = useState<ViewMode>("grid");

  const filtered = useMemo(() => {
    const searchValue = search.toLowerCase().trim();

    return records.filter(
      (item) =>
        (status === "All" || item.status === status) &&
        (severity === "All" || item.severity === severity) &&
        (category === "All" || item.categoryId === category) &&
        `${item.name} ${item.code} ${item.description}`
          .toLowerCase()
          .includes(searchValue),
    );
  }, [records, search, status, severity, category]);

  const getCategoryName = (categoryId: string) =>
    categories.find((item) => item.id === categoryId)?.name ?? "Unassigned";

  const columns: TableColumn<DefectRecord>[] = [
    {
      field: "name",
      header: "Defect",
      sortable: true,
      minWidth: "210px",
      body: (item) => (
        <div className="mdm-table-record">
          <span className="mdm-table-record__icon mdm-table-record__icon--defect">
            <AlertTriangle size={17} />
          </span>
          <span className="mdm-table-record__content">
            <strong>{item.name}</strong>
            <small>{item.code}</small>
          </span>
        </div>
      ),
    },
    {
      field: "categoryId",
      header: "Category",
      sortable: true,
      minWidth: "165px",
      body: (item) => (
        <span className="mdm-table-meta">
          <Layers3 size={15} />
          {getCategoryName(item.categoryId)}
        </span>
      ),
    },
    {
      field: "severity",
      header: "Severity",
      align: "center",
      minWidth: "125px",
      body: (item) => <SeverityBadge severity={item.severity} />,
    },
    {
      field: "reworkMinutes",
      header: "Rework Time",
      sortable: true,
      minWidth: "130px",
      body: (item) => (
        <span className="mdm-table-meta">
          <Clock3 size={15} />
          {item.reworkMinutes} mins
        </span>
      ),
    },
    {
      field: "description",
      header: "Description",
      minWidth: "240px",
      body: (item) => (
        <span className="mdm-table-description">
          {item.description || "—"}
        </span>
      ),
    },
    {
      field: "status",
      header: "Status",
      align: "center",
      minWidth: "110px",
      body: (item) => <StatusBadge status={item.status} />,
    },
    {
      field: "id",
      header: "Actions",
      align: "center",
      minWidth: "110px",
      body: (item) => (
        <div className="mdm-icon-actions">
          <CommonTooltip content="Edit">
            <button
              type="button"
              aria-label={`Edit ${item.name}`}
              onClick={() => onEdit(item)}
            >
              <Pencil size={16} />
            </button>
          </CommonTooltip>

          <CommonTooltip content="Delete">
            <button
              type="button"
              className="is-danger"
              aria-label={`Delete ${item.name}`}
              onClick={() => onDelete(item)}
            >
              <Trash2 size={16} />
            </button>
          </CommonTooltip>
        </div>
      ),
    },
  ];

  return (
    <section className="mdm-tab-content mdm-tab-content--defects">
      <MasterDataToolbar
        search={search}
        onSearch={setSearch}
        status={String(status)}
        onStatus={(value) => setStatus(value ?? "All")}
        view={view}
        onView={setView}
        filters={
          <>
            <CommonSelect
              value={category}
              onChange={(value) => setCategory(value ?? "All")}
              options={[
                { label: "All Categories", value: "All" },
                ...categories.map((item) => ({
                  label: item.name,
                  value: item.id,
                })),
              ]}
              placeholder="Category"
            />

            <CommonSelect
              value={severity}
              onChange={(value) => setSeverity(value ?? "All")}
              options={[
                { label: "All Severities", value: "All" },
                ...["Minor", "Major", "Critical"].map((value) => ({
                  label: value,
                  value,
                })),
              ]}
              placeholder="Severity"
            />
          </>
        }
      />

      {filtered.length > 0 && (
        <>
          {view === "grid" ? (
            <div className="row g-3 mdm-card-grid">
              {filtered.map((item) => (
                <div className="col-12 col-md-6 col-xl-4" key={item.id}>
                  <article className="mdm-record-card mdm-defect-card">
                    <div className="mdm-card-top">
                      <span className="mdm-card-icon mdm-card-icon--defect">
                        <AlertTriangle size={19} />
                      </span>

                      <div className="mdm-card-top__badges">
                        <SeverityBadge severity={item.severity} />
                        <StatusBadge status={item.status} />
                      </div>
                    </div>

                    <div className="mdm-card-heading">
                      <h3>{item.name}</h3>
                      <span className="mdm-code">{item.code}</span>
                    </div>

                    <p className="mdm-defect-description">
                      {item.description || "No description provided."}
                    </p>

                    <div className="mdm-defect-details">
                      <div className="mdm-defect-detail">
                        <span className="mdm-defect-detail__icon">
                          <Layers3 size={16} />
                        </span>
                        <span>
                          <small>Category</small>
                          <strong>{getCategoryName(item.categoryId)}</strong>
                        </span>
                      </div>

                      <div className="mdm-defect-detail">
                        <span className="mdm-defect-detail__icon mdm-defect-detail__icon--time">
                          <Clock3 size={16} />
                        </span>
                        <span>
                          <small>Estimated Rework</small>
                          <strong>{item.reworkMinutes} minutes</strong>
                        </span>
                      </div>
                    </div>

                    <div className="mdm-card-footer">
                      <span className="mdm-card-id">{item.id}</span>

                      <div className="mdm-icon-actions">
                        <CommonTooltip content="Edit">
                          <button
                            type="button"
                            aria-label={`Edit ${item.name}`}
                            onClick={() => onEdit(item)}
                          >
                            <Pencil size={16} />
                          </button>
                        </CommonTooltip>

                        <CommonTooltip content="Delete">
                          <button
                            type="button"
                            className="is-danger"
                            aria-label={`Delete ${item.name}`}
                            onClick={() => onDelete(item)}
                          >
                            <Trash2 size={16} />
                          </button>
                        </CommonTooltip>
                      </div>
                    </div>
                  </article>
                </div>
              ))}
            </div>
          ) : (
            <div className="mdm-data-table">
              <CommonDataTable
                data={filtered}
                columns={columns}
                dataKey="id"
                paginator
                rows={10}
                rowsPerPageOptions={[5, 10, 20, 50]}
                emptyMessage="No defects found"
                stripedRows
                size="small"
                className="mdm-common-table"
              />
            </div>
          )}
        </>
      )}

      {filtered.length === 0 && (
        <div className="mdm-empty-state">
          <AlertTriangle size={30} />
          <b>No defect types found</b>
          <span>Try changing your search or filters.</span>
        </div>
      )}

      <div className="mdm-results-count">
        Showing {filtered.length} of {records.length} defect types
      </div>
    </section>
  );
}