import { useMemo, useState } from "react";
import {
  Pencil,
  Trash2,
  Layers3,
  ListChecks,
} from "lucide-react";

import CommonTooltip from "@/components/common/ui/tooltip/CommonTooltip";
import CommonSelect from "@/components/common/ui/select/CommonSelect";


import MasterDataToolbar from "../components/MasterDataToolbar";
import CategoryCard from "../cards/CategoryCard";
import { SeverityBadge, StatusBadge } from "../components/StatusBadge";

import type {
  CategoryRecord,
  DefectRecord,
  ViewMode,
} from "../types/masterDataTypes";
import { type TableColumn, CommonDataTable } from "@/components/common/data-table";



interface Props {
  records: CategoryRecord[];
  defects: DefectRecord[];
  onEdit: (item: CategoryRecord) => void;
  onDelete: (item: CategoryRecord) => void;
}

export default function CategoriesTab({
  records,
  defects,
  onEdit,
  onDelete,
}: Props) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string | number>("All");
  const [severity, setSeverity] = useState<string | number>("All");
  const [view, setView] = useState<ViewMode>("grid");

  const filtered = useMemo(() => {
    const searchValue = search.toLowerCase().trim();

    return records.filter(
      (item) =>
        (status === "All" || item.status === status) &&
        (severity === "All" || item.severity === severity) &&
        `${item.name} ${item.code} ${item.description}`
          .toLowerCase()
          .includes(searchValue),
    );
  }, [records, search, status, severity]);

  const getDefectCount = (categoryId: string) =>
    defects.filter((defect) => defect.categoryId === categoryId).length;

  const columns: TableColumn<CategoryRecord>[] = [
    {
      field: "name",
      header: "Category",
      sortable: true,
      minWidth: "210px",
      body: (item) => (
        <div className="mdm-table-record">
          <span className="mdm-table-record__icon mdm-table-record__icon--category">
            <Layers3 size={17} />
          </span>
          <span className="mdm-table-record__content">
            <strong>{item.name}</strong>
            <small>{item.code}</small>
          </span>
        </div>
      ),
    },
    {
      field: "description",
      header: "Description",
      minWidth: "250px",
      body: (item) => (
        <span className="mdm-table-description">
          {item.description || "—"}
        </span>
      ),
    },
    {
      field: "severity",
      header: "Default Severity",
      align: "center",
      minWidth: "145px",
      body: (item) => <SeverityBadge severity={item.severity} />,
    },
    {
      field: "id",
      header: "Defect Types",
      align: "center",
      minWidth: "125px",
      body: (item) => (
        <span className="mdm-table-count">
          <ListChecks size={15} />
          {getDefectCount(item.id)}
        </span>
      ),
    },
    {
      field: "status",
      header: "Status",
      align: "center",
      minWidth: "110px",
      body: (item) => <StatusBadge status={item.status} />,
    },
    {
      field: "id",
      header: "Actions",
      align: "center",
      minWidth: "110px",
      body: (item) => (
        <div className="mdm-icon-actions">
          <CommonTooltip content="Edit">
            <button
              type="button"
              aria-label={`Edit ${item.name}`}
              onClick={() => onEdit(item)}
            >
              <Pencil size={16} />
            </button>
          </CommonTooltip>

          <CommonTooltip content="Delete">
            <button
              type="button"
              className="is-danger"
              aria-label={`Delete ${item.name}`}
              onClick={() => onDelete(item)}
            >
              <Trash2 size={16} />
            </button>
          </CommonTooltip>
        </div>
      ),
    },
  ];

  return (
    <section className="mdm-tab-content mdm-tab-content--categories">
      <MasterDataToolbar
        search={search}
        onSearch={setSearch}
        status={String(status)}
        onStatus={(value) => setStatus(value ?? "All")}
        view={view}
        onView={setView}
        filters={
          <CommonSelect
            value={severity}
            onChange={(value) => setSeverity(value ?? "All")}
            options={[
              { label: "All Severities", value: "All" },
              ...["Minor", "Major", "Critical"].map((value) => ({
                label: value,
                value,
              })),
            ]}
            placeholder="Severity"
          />
        }
      />

      {filtered.length > 0 && (
        <>
          {view === "grid" ? (
            <div className="row g-3 mdm-card-grid">
              {filtered.map((item) => (
                <div className="col-12 col-md-6 col-xl-4" key={item.id}>
                  <CategoryCard
                    category={item}
                    defectCount={getDefectCount(item.id)}
                    onEdit={onEdit}
                    onDelete={onDelete}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="mdm-data-table">
              <CommonDataTable
                data={filtered}
                columns={columns}
                dataKey="id"
                paginator
                rows={10}
                rowsPerPageOptions={[5, 10, 20, 50]}
                emptyMessage="No categories found"
                stripedRows
                size="small"
                className="mdm-common-table"
              />
            </div>
          )}
        </>
      )}

      {filtered.length === 0 && (
        <div className="mdm-empty-state">
          <Layers3 size={30} />
          <b>No categories found</b>
          <span>Try changing your search or filters.</span>
        </div>
      )}

      <div className="mdm-results-count">
        Showing {filtered.length} of {records.length} categories
      </div>
    </section>
  );
}