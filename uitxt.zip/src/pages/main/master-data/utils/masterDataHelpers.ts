export const nextCode = (prefix: string, records: { code: string }[]) => {
  const max = records.reduce((highest, item) => {
    const match = item.code.match(/(\d+)$/);
    return match ? Math.max(highest, Number(match[1])) : highest;
  }, 0);
  return `${prefix}-${String(max + 1).padStart(3, "0")}`;
};

export const matchesSearch = (value: string, query: string) =>
  value.toLowerCase().includes(query.trim().toLowerCase());
