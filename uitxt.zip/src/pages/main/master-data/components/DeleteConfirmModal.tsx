import { AlertTriangle, Trash2 } from "lucide-react";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonModal from "@/components/common/ui/modal/CommonModal";

interface Props {
  show: boolean;
  title: string;
  description: string | any;
  onClose: () => void;
  onConfirm: () => void;
}

export default function DeleteConfirmModal({
  show,
  title,
  description,
  onClose,
  onConfirm,
}: Props) {
  return (
    <CommonModal
      show={show}
      onClose={onClose}
      size="sm"
      title={title}
      subtitle="This action cannot be undone."
      headerIcon={<AlertTriangle size={19} strokeWidth={2} />}
      className="mdm-delete-modal"
      footer={
        <>
          <CommonButton variant="outline" onClick={onClose}>
            Cancel
          </CommonButton>
          <CommonButton
            variant="danger"
            leftIcon={<Trash2 size={15} />}
            onClick={onConfirm}
          >
            Delete
          </CommonButton>
        </>
      }
    >
      <p className="mdm-delete-copy">{description}</p>
    </CommonModal>
  );
}
