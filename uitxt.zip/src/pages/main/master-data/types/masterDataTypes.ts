export type RecordStatus = "Active" | "Inactive";
export type Severity = "Minor" | "Major" | "Critical";

export interface StaffOption {
  id: string;
  name: string;
  role: string;
  avatar?: string;
}

export interface StationRecord {
  id: string;
  code: string;
  name: string;
  type: string;
  location: string;
  status: RecordStatus;
  operatorIds: string[];
}

export interface CategoryRecord {
  id: string;
  code: string;
  name: string;
  description: string;
  severity: Severity;
  status: RecordStatus;
}

export interface DefectRecord {
  id: string;
  code: string;
  name: string;
  categoryId: string;
  severity: Severity;
  reworkMinutes: number;
  description: string;
  status: RecordStatus;
}

export type MasterTab = "stations" | "categories" | "defects";
export type ViewMode = "grid" | "list";
