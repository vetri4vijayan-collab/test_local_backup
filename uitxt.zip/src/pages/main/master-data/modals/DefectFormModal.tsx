import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import type { CategoryRecord, DefectRecord } from "../types/masterDataTypes";

interface Props {
  show: boolean;
  defect: DefectRecord | null;
  categories: CategoryRecord[];
  onClose: () => void;
  onSave: (item: DefectRecord) => void;
}
export default function DefectFormModal({ show, defect, categories, onClose, onSave }: Props) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [severity, setSeverity] = useState<string | null>("Major");
  const [minutes, setMinutes] = useState("15");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<string | null>("Active");

  useEffect(() => {
    if (!show) return;
    setName(defect?.name ?? "");
    setCode(defect?.code ?? "");
    setCategoryId(defect?.categoryId ?? categories[0]?.id ?? null);
    setSeverity(defect?.severity ?? "Major");
    setMinutes(String(defect?.reworkMinutes ?? 15));
    setDescription(defect?.description ?? "");
    setStatus(defect?.status ?? "Active");
  }, [show, defect, categories]);

  const save = () => {
    if (!name.trim() || !code.trim() || !categoryId || !severity || !status || Number(minutes) < 0) return;
    onSave({
      id: defect?.id ?? `DEF-${Date.now().toString().slice(-5)}`,
      name: name.trim(), code: code.trim().toUpperCase(), categoryId,
      severity: severity as DefectRecord["severity"], reworkMinutes: Number(minutes),
      description: description.trim(), status: status as DefectRecord["status"],
    });
  };

  return (
    <CommonModal show={show} onClose={onClose} size="lg"
      title={defect ? "Edit Defect Type" : "Add Defect Type"}
      subtitle="Define a specific defect and its expected rework duration."
      headerIcon={<AlertTriangle size={19} />} className="mdm-form-modal"
      footer={<><CommonButton variant="outline" onClick={onClose}>Cancel</CommonButton><CommonButton disabled={!name.trim() || !code.trim() || !categoryId} onClick={save}>{defect ? "Update Defect" : "Save Defect"}</CommonButton></>}
    >
      <div className="mdm-form-grid">
        <div className="mdm-form-full"><CommonInput label="Defect Name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Skip Stitch on Collar" required /></div>
        <CommonInput label="Defect Code" value={code} onChange={(e) => setCode(e.target.value)} placeholder="e.g. DEF-ST-001" required />
        <CommonSelect label="Category" value={categoryId} onChange={(v) => setCategoryId(v == null ? null : String(v))} options={categories.map((item) => ({ label: `${item.name} (${item.code})`, value: item.id }))} placeholder="Select category" required filter />
        <CommonSelect label="Severity Level" value={severity} onChange={(v) => setSeverity(v == null ? null : String(v))} options={["Minor", "Major", "Critical"].map((v) => ({ label: v, value: v }))} required />
        <CommonInput label="Est. Rework Time (Minutes)" type="number" min={0} value={minutes} onChange={(e) => setMinutes(e.target.value)} required />
        <div className="mdm-form-full"><CommonTextArea label="Description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detailed description of the defect..." rows={3} /></div>
        <div className="mdm-form-full"><CommonSelect label="Status" value={status} onChange={(v) => setStatus(v == null ? null : String(v))} options={[{ label: "Active", value: "Active" }, { label: "Inactive", value: "Inactive" }]} required /></div>
      </div>
    </CommonModal>
  );
}
