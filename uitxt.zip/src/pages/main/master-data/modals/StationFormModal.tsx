
import { useEffect, useState } from "react";
import { Factory, Plus } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

import type {
  StaffOption,
  StationRecord,
} from "../types/masterDataTypes";

import { stationTypes as initialStationTypes } from "../data/masterData";

interface Props {
  show: boolean;
  station: StationRecord | null;
  staff: StaffOption[];
  stationTypes?: string[];
  onAddStationType?: (type: string) => void;
  onClose: () => void;
  onSave: (item: StationRecord) => void;
}

export default function StationFormModal({
  show,
  station,
  staff,
  stationTypes = initialStationTypes,
  onAddStationType,
  onClose,
  onSave,
}: Props) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [type, setType] = useState<string | null>(
    stationTypes[0] ?? null,
  );
  const [location, setLocation] = useState("");
  const [status, setStatus] = useState<string | null>("Active");
  const [operatorIds, setOperatorIds] = useState<string[]>([]);

  // Add station type modal
  const [showTypeModal, setShowTypeModal] = useState(false);
  const [newType, setNewType] = useState("");

  useEffect(() => {
    if (!show) return;

    setName(station?.name ?? "");
    setCode(station?.code ?? "");
    setType(station?.type ?? stationTypes[0] ?? null);
    setLocation(station?.location ?? "");
    setStatus(station?.status ?? "Active");
    setOperatorIds(station?.operatorIds ?? []);
    setShowTypeModal(false);
    setNewType("");
  }, [show, station]);

  const toggleOperator = (id: string) => {
    setOperatorIds((current) =>
      current.includes(id)
        ? current.filter((value) => value !== id)
        : [...current, id],
    );
  };

  // Create new station type
  const handleAddType = () => {
    const trimmedType = newType.trim();

    if (!trimmedType) return;

    const alreadyExists = stationTypes.some(
      (item) => item.toLowerCase() === trimmedType.toLowerCase(),
    );

    if (alreadyExists) {
      const existingType = stationTypes.find(
        (item) => item.toLowerCase() === trimmedType.toLowerCase(),
      );

      setType(existingType ?? trimmedType);
      setShowTypeModal(false);
      setNewType("");
      return;
    }

    onAddStationType?.(trimmedType);

    // Automatically select newly created type
    setType(trimmedType);

    setNewType("");
    setShowTypeModal(false);
  };

  const save = () => {
    if (
      !name.trim() ||
      !code.trim() ||
      !type ||
      !location.trim() ||
      !status
    ) {
      return;
    }

    onSave({
      id: station?.id ?? `STN-${Date.now().toString().slice(-5)}`,
      name: name.trim(),
      code: code.trim().toUpperCase(),
      type,
      location: location.trim(),
      status: status as StationRecord["status"],
      operatorIds,
    });
  };

  return (
    <>
      <CommonModal
        show={show}
        onClose={onClose}
        variant="drawer"
        size="lg"
        title={station ? "Edit Factory Station" : "Create Factory Station"}
        subtitle="Configure station details and assign registered staff."
        headerIcon={<Factory size={19} />}
        className="mdm-form-modal"
        footer={
          <>
            <CommonButton variant="outline" onClick={onClose}>
              Cancel
            </CommonButton>

            <CommonButton
              disabled={
                !name.trim() ||
                !code.trim() ||
                !type ||
                !location.trim() ||
                !status
              }
              onClick={save}
            >
              {station ? "Update Station" : "Save Station"}
            </CommonButton>
          </>
        }
      >
        <div className="mdm-form-grid">
          <div className="mdm-form-full">
            <CommonInput
              label="Station Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Finishing & Packing Station B"
              required
            />
          </div>

          <CommonInput
            label="Station Code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="e.g. ST-PACK-01"
            required
          />

          {/* Station Type with Add button */}
          <div className="mdm-station-type-field">
            <div className="mdm-station-type-label">
              <span>
                Station Type <span className="required">*</span>
              </span>

              <button
                type="button"
                className="mdm-add-type-trigger"
                onClick={() => setShowTypeModal(true)}
              >
                <Plus size={13} />
                Add Type
              </button>
            </div>

            <CommonSelect
              value={type}
              onChange={(v) =>
                setType(v == null ? null : String(v))
              }
              options={stationTypes.map((item) => ({
                label: item,
                value: item,
              }))}
              required
            />
          </div>

          <CommonInput
            label="Location / Zone"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g. Floor 2, Zone B"
            required
          />

          <CommonSelect
            label="Station Status"
            value={status}
            onChange={(v) =>
              setStatus(v == null ? null : String(v))
            }
            options={[
              { label: "Active", value: "Active" },
              { label: "Inactive", value: "Inactive" },
            ]}
            required
          />

          {/* Operators */}
          <div className="mdm-form-full">
            <label className="mdm-field-label">
              Assign Operators <span>({operatorIds.length} selected)</span>
            </label>

            <div className="mdm-staff-picker">
              {staff.map((person) => (
                <label
                  className={`mdm-staff-option ${
                    operatorIds.includes(person.id)
                      ? "is-selected"
                      : ""
                  }`}
                  key={person.id}
                >
                  <input
                    type="checkbox"
                    checked={operatorIds.includes(person.id)}
                    onChange={() => toggleOperator(person.id)}
                  />

                  <span className="mdm-staff-avatar">
                    {person.name
                      .split(" ")
                      .map((part) => part[0])
                      .slice(0, 2)
                      .join("")}
                  </span>

                  <span className="mdm-staff-details">
                    <b>{person.name}</b>
                    <small>{person.role}</small>
                  </span>
                </label>
              ))}
            </div>

            <small className="mdm-field-hint">
              Select one or more registered employees for this station.
            </small>
          </div>
        </div>
      </CommonModal>

      {/* Add Station Type - Center Modal */}
      <CommonModal
        show={showTypeModal}
        onClose={() => {
          setShowTypeModal(false);
          setNewType("");
        }}
        variant="center"
        size="sm"
        title="Create Station Type"
        subtitle="Add a new category for your factory stations."
        headerIcon={<Factory size={18} />}
        className="mdm-add-type-modal"
        footer={
          <>
            <CommonButton
              variant="outline"
              onClick={() => {
                setShowTypeModal(false);
                setNewType("");
              }}
            >
              Cancel
            </CommonButton>

            <CommonButton
              disabled={!newType.trim()}
              onClick={handleAddType}
            >
              <Plus size={15} />
              Add Type
            </CommonButton>
          </>
        }
      >
        <div className="mdm-add-type-content">
          <CommonInput
            label="Station Type Name"
            value={newType}
            onChange={(e) => setNewType(e.target.value)}
            placeholder="e.g. Quality Inspection"
            required
          />

          <small className="mdm-field-hint">
            The new type will be available in the Station Type dropdown.
          </small>
        </div>
      </CommonModal>
    </>
  );
}
