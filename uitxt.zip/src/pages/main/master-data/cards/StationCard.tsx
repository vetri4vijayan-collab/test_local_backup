import { MapPin, Pencil, Trash2, Users, Wrench } from "lucide-react";
import CommonTooltip from "@/components/common/ui/tooltip/CommonTooltip";
import type { StaffOption, StationRecord } from "../types/masterDataTypes";
import { StatusBadge } from "../components/StatusBadge";

interface Props {
  station: StationRecord;
  staff: StaffOption[];
  onEdit: (item: StationRecord) => void;
  onDelete: (item: StationRecord) => void;
}
export default function StationCard({
  station,
  staff,
  onEdit,
  onDelete,
}: Props) {
  const operators = staff.filter((person) =>
    station.operatorIds.includes(person.id),
  );
  return (
    <article className="mdm-record-card">
      <div className="mdm-card-top">
        <span className="mdm-code">{station.code}</span>
        <StatusBadge status={station.status} />
      </div>
      <h3>{station.name}</h3>
      <div className="mdm-card-meta">
        <span>
          <Wrench size={14} /> Type: <b>{station.type}</b>
        </span>
        <span>
          <MapPin size={14} /> Location: <b>{station.location}</b>
        </span>
      </div>
      <div className="mdm-card-operators">
        <div className="mdm-section-label">
          <Users size={14} /> Assigned Operators ({operators.length})
        </div>
        <div className="mdm-chip-list">
          {operators.length ? (
            operators.map((person) => (
              <span className="mdm-chip" key={person.id}>
                {person.name}
              </span>
            ))
          ) : (
            <span className="mdm-empty-inline">No operators assigned</span>
          )}
        </div>
      </div>
      <div className="mdm-card-footer">
        <span>ID: {station.id}</span>
        <div className="mdm-icon-actions">
          <CommonTooltip content="Edit station">
            <button
              type="button"
              onClick={() => onEdit(station)}
              aria-label="Edit station"
            >
              <Pencil size={16} />
            </button>
          </CommonTooltip>
          <CommonTooltip content="Delete station">
            <button
              type="button"
              className="is-danger"
              onClick={() => onDelete(station)}
              aria-label="Delete station"
            >
              <Trash2 size={16} />
            </button>
          </CommonTooltip>
        </div>
      </div>
    </article>
  );
}
