import { useMemo, useState } from "react";
import { Database, Plus } from "lucide-react";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import MasterDataTabs from "./components/MasterDataTabs";
import StationsTab from "./tabs/StationsTab";
import CategoriesTab from "./tabs/CategoriesTab";
import DefectsTab from "./tabs/DefectsTab";
import StationFormModal from "./modals/StationFormModal";
import CategoryFormModal from "./modals/CategoryFormModal";
import DefectFormModal from "./modals/DefectFormModal";
import DeleteConfirmModal from "./components/DeleteConfirmModal";
import {
  initialCategories,
  initialDefects,
  initialStations,
  staffOptions,
} from "./data/masterData";
import type {
  CategoryRecord,
  DefectRecord,
  MasterTab,
  StationRecord,
} from "./types/masterDataTypes";
import "./MasterDataManagementPage.scss";
import { stationTypes as initialStationTypes } from "./data/masterData";
type DeleteTarget = { kind: MasterTab; id: string; name: string } | null;

export default function MasterDataManagementPage() {
  const [activeTab, setActiveTab] = useState<MasterTab>("stations");
  const [stations, setStations] = useState(initialStations);
  const [categories, setCategories] = useState(initialCategories);
  const [defects, setDefects] = useState(initialDefects);
  const [stationTypes, setStationTypes] =
    useState<string[]>(initialStationTypes);
  const [stationModal, setStationModal] = useState(false);
  const [categoryModal, setCategoryModal] = useState(false);
  const [defectModal, setDefectModal] = useState(false);
  const [editingStation, setEditingStation] = useState<StationRecord | null>(
    null,
  );
  const [editingCategory, setEditingCategory] = useState<CategoryRecord | null>(
    null,
  );
  const [editingDefect, setEditingDefect] = useState<DefectRecord | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget>(null);
  const [deleteError, setDeleteError] = useState("");

  const counts = useMemo(
    () => ({
      stations: stations.length,
      categories: categories.length,
      defects: defects.length,
    }),
    [stations, categories, defects],
  );

  const openCreate = () => {
    if (activeTab === "stations") {
      setEditingStation(null);
      setStationModal(true);
    }
    if (activeTab === "categories") {
      setEditingCategory(null);
      setCategoryModal(true);
    }
    if (activeTab === "defects") {
      setEditingDefect(null);
      setDefectModal(true);
    }
  };

  const saveStation = (item: StationRecord) => {
    setStations((current) =>
      current.some((v) => v.id === item.id)
        ? current.map((v) => (v.id === item.id ? item : v))
        : [item, ...current],
    );
    setStationModal(false);
  };
  const saveCategory = (item: CategoryRecord) => {
    setCategories((current) =>
      current.some((v) => v.id === item.id)
        ? current.map((v) => (v.id === item.id ? item : v))
        : [item, ...current],
    );
    setCategoryModal(false);
  };
  const saveDefect = (item: DefectRecord) => {
    setDefects((current) =>
      current.some((v) => v.id === item.id)
        ? current.map((v) => (v.id === item.id ? item : v))
        : [item, ...current],
    );
    setDefectModal(false);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    if (deleteTarget.kind === "categories") {
      const linked = defects.some(
        (item) => item.categoryId === deleteTarget.id,
      );
      if (linked) {
        setDeleteError(
          "This category has linked defect types. Reassign or delete those defects before deleting the category.",
        );
        return;
      }
      setCategories((current) =>
        current.filter((item) => item.id !== deleteTarget.id),
      );
    }
    if (deleteTarget.kind === "stations")
      setStations((current) =>
        current.filter((item) => item.id !== deleteTarget.id),
      );
    if (deleteTarget.kind === "defects")
      setDefects((current) =>
        current.filter((item) => item.id !== deleteTarget.id),
      );
    setDeleteTarget(null);
    setDeleteError("");
  };

  const requestDelete = (
    kind: MasterTab,
    item: { id: string; name: string },
  ) => {
    setDeleteError("");
    setDeleteTarget({ kind, id: item.id, name: item.name });
  };

  const actionLabel =
    activeTab === "stations"
      ? "Create Station"
      : activeTab === "categories"
        ? "Add Category"
        : "Add Defect Type";
  const actionIcon = <Plus size={16} />;
  const pageIcon = <Database size={20} />;

  return (
    <div className="mdm-page">
      <CommonPageHeader
        icon={pageIcon}
        title="Master Data Management"
        subtitle="Configure factory stations, defect categories, and specific defect codes with enriched attributes."
        rightContent={
          <CommonButton leftIcon={actionIcon} onClick={openCreate}>
            {actionLabel}
          </CommonButton>
        }
        className="mdm-page-header"
      />

      <div className="mdm-workspace">
        <div className="mdm-workspace-heading">
          <div>
            <h2>Master Records</h2>
            <p>
              Manage reference data used across production and quality
              workflows.
            </p>
          </div>
          <MasterDataTabs
            activeTab={activeTab}
            counts={counts}
            onChange={setActiveTab}
          />
        </div>

        {activeTab === "stations" && (
          <StationsTab
            records={stations}
            staff={staffOptions}
            onEdit={(item) => {
              setEditingStation(item);
              setStationModal(true);
            }}
            onDelete={(item) => requestDelete("stations", item)}
          />
        )}
        {activeTab === "categories" && (
          <CategoriesTab
            records={categories}
            defects={defects}
            onEdit={(item) => {
              setEditingCategory(item);
              setCategoryModal(true);
            }}
            onDelete={(item) => requestDelete("categories", item)}
          />
        )}
        {activeTab === "defects" && (
          <DefectsTab
            records={defects}
            categories={categories}
            onEdit={(item) => {
              setEditingDefect(item);
              setDefectModal(true);
            }}
            onDelete={(item) => requestDelete("defects", item)}
          />
        )}
      </div>

      <StationFormModal
        show={stationModal}
        station={editingStation}
        staff={staffOptions}
        stationTypes={stationTypes}
        onAddStationType={(newType) => {
          setStationTypes((current) =>
            current.some((item) => item.toLowerCase() === newType.toLowerCase())
              ? current
              : [...current, newType],
          );
        }}
        onClose={() => setStationModal(false)}
        onSave={saveStation}
      />
      <CategoryFormModal
        show={categoryModal}
        category={editingCategory}
        onClose={() => setCategoryModal(false)}
        onSave={saveCategory}
      />
      <DefectFormModal
        show={defectModal}
        defect={editingDefect}
        categories={categories}
        onClose={() => setDefectModal(false)}
        onSave={saveDefect}
      />

      <DeleteConfirmModal
        show={!!deleteTarget}
        title={`Delete ${deleteTarget?.kind === "stations" ? "Station" : deleteTarget?.kind === "categories" ? "Category" : "Defect"}?`}
        description={
          deleteError || (
            <>
              Are you sure you want to delete{" "}
              <strong>{deleteTarget?.name ?? ""}</strong>?
            </>
          )
        }
        onClose={() => {
          setDeleteTarget(null);
          setDeleteError("");
        }}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
