import UnderDevelopment from "@/components/common/ui/under-development/UnderDevelopment";


export default function DashboardPage() {
  return (
   <>
    <UnderDevelopment />
   </>
  );
}
