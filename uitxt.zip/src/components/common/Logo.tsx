import { APP_NAME } from "@/config/app";
import { LogoLongTitle,LogoWithoutTitle } from "@/utils/images";


interface LogoProps {
  variant?: "light" | "dark";
  showText?: boolean;
  size?: number;
}

export function Logo({
  variant = "light",
  showText = true,
  size,
}: LogoProps) {
  return (
    <span
      className={`app-logo app-logo--${variant} ${
        showText ? "app-logo--expanded" : "app-logo--compact"
      }`}
    >
      <img
        className="app-logo__image"
        src={showText ? LogoLongTitle : LogoWithoutTitle}
        alt={`${APP_NAME} logo`}
        style={
          size
            ? {
                height: size,
              }
            : undefined
        }
      />
    </span>
  );
}