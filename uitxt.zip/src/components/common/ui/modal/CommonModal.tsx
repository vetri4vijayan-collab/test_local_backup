
import {
  useEffect,
  useId,
  type CSSProperties,
  type ReactNode,
} from "react";

import { X } from "lucide-react";

import "./CommonModal.scss";

export type ModalVariant = "center" | "drawer";
export type ModalSize = "sm" | "md" | "lg" | "xl";

interface CommonModalProps {
  // Visibility
  show: boolean;
  onClose: () => void;

  // Layout
  variant?: ModalVariant;
  size?: ModalSize;
  width?: string | number;

  // Header
  showHeader?: boolean;
  headerIcon?: ReactNode;
  title?: string;
  subtitle?: string;
  showCloseButton?: boolean;

  // Content
  children: ReactNode;

  // Footer
  footer?: ReactNode;
  showFooter?: boolean;

  // Behavior
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;

  // Custom classes
  className?: string;
  headerClassName?: string;
  bodyClassName?: string;
  footerClassName?: string;
  overlayClassName?: string;

  // Accessibility
  ariaLabel?: string;
}

export default function CommonModal({
  show,
  onClose,
  variant = "center",
  size = "md",
  width,

  showHeader = true,
  headerIcon,
  title,
  subtitle,
  showCloseButton = true,

  children,

  footer,
  showFooter = true,

  closeOnBackdrop = true,
  closeOnEscape = true,

  className = "",
  headerClassName = "",
  bodyClassName = "",
  footerClassName = "",
  overlayClassName = "",

  ariaLabel = "Dialog",
}: CommonModalProps) {
  const generatedId = useId();
  const titleId = `${generatedId}-title`;
  const descriptionId = `${generatedId}-description`;

  // Lock body scrolling and handle Escape key.
  useEffect(() => {
    if (!show) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && closeOnEscape) {
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [show, closeOnEscape, onClose]);

  if (!show) return null;

  const customWidth =
    typeof width === "number" ? `${width}px` : width;

  const modalStyle: CSSProperties = customWidth
    ? ({ "--common-modal-width": customWidth } as CSSProperties)
    : {};

  const modalClasses = [
    "common-modal-dialog",
    `common-modal-dialog--${variant}`,
    `common-modal-dialog--${size}`,
    className,
  ]
    .filter(Boolean)
    .join(" ");

  const handleBackdropClick = (
    event: React.MouseEvent<HTMLDivElement>,
  ) => {
    if (
      closeOnBackdrop &&
      event.target === event.currentTarget
    ) {
      onClose();
    }
  };

  return (
    <div
      className={[
        "common-modal-overlay",
        `common-modal-overlay--${variant}`,
        overlayClassName,
      ]
        .filter(Boolean)
        .join(" ")}
      onMouseDown={handleBackdropClick}
    >
      <div
        className={modalClasses}
        style={modalStyle}
        role="dialog"
        aria-modal="true"
        aria-label={!title ? ariaLabel : undefined}
        aria-labelledby={title ? titleId : undefined}
        aria-describedby={subtitle ? descriptionId : undefined}
      >
        {/* HEADER */}
        {showHeader && (
          <div
            className={`common-modal-header ${headerClassName}`}
          >
            <div className="common-modal-heading">
              {headerIcon && (
                <div className="common-modal-header-icon">
                  {headerIcon}
                </div>
              )}

              <div className="common-modal-heading-content">
                {title && (
                  <h5
                    className="common-modal-title"
                    id={titleId}
                  >
                    {title}
                  </h5>
                )}

                {subtitle && (
                  <p
                    className="common-modal-subtitle"
                    id={descriptionId}
                  >
                    {subtitle}
                  </p>
                )}
              </div>
            </div>

            {showCloseButton && (
              <button
                type="button"
                className="common-modal-close"
                onClick={onClose}
                aria-label="Close modal"
              >
                <X size={19} />
              </button>
            )}
          </div>
        )}

        {/* BODY */}
        <div
          className={`common-modal-body ${bodyClassName}`}
        >
          {children}
        </div>

        {/* FOOTER */}
        {showFooter && footer && (
          <div
            className={`common-modal-footer ${footerClassName}`}
          >
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
