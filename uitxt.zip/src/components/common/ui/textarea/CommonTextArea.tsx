
import { useId, type ChangeEvent } from "react";
import "./CommonTextArea.scss";

interface CommonTextAreaProps {
  label?: string;
  value: string;
  onChange: (event: ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
  rows?: number;
  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  hint?: string;
  error?: string;
  className?: string;
  name?: string;
  maxLength?: number;
  resize?: "none" | "both" | "horizontal" | "vertical";
}

export default function CommonTextArea({
  label,
  value,
  onChange,
  placeholder = "Enter text...",
  rows = 4,
  required = false,
  disabled = false,
  readOnly = false,
  hint,
  error,
  className = "",
  name,
  maxLength,
  resize = "vertical",
}: CommonTextAreaProps) {
  const id = useId();

  return (
    <div className={`common-textarea-group ${className}`}>
      {label && (
        <label htmlFor={id} className="common-textarea-label">
          {label}
          {required && <span className="required-mark"> *</span>}
        </label>
      )}

      <textarea
        id={id}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        rows={rows}
        required={required}
        disabled={disabled}
        readOnly={readOnly}
        maxLength={maxLength}
        style={{ resize }}
        className={`common-textarea-control ${error ? "has-error" : ""}`}
      />

      {error ? (
        <span className="common-textarea-error">{error}</span>
      ) : hint ? (
        <span className="common-textarea-hint">{hint}</span>
      ) : null}
    </div>
  );
}
