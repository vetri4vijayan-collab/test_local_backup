import { forwardRef, useId, type ReactNode } from "react";
import { Dropdown, type DropdownProps } from "primereact/dropdown";
import { ChevronDown, X } from "lucide-react";

import "./Select.scss";

export interface CommonSelectOption {
  label: string;
  value: string | number;
  disabled?: boolean;
}

interface CommonSelectProps extends Omit<
  DropdownProps,
  | "options"
  | "value"
  | "onChange"
  | "optionLabel"
  | "optionValue"
  | "className"
  | "placeholder"
> {
  label?: string;
  options: CommonSelectOption[];
  value?: string | number | null;
  placeholder?: string;
  error?: string;
  hint?: string;
  required?: boolean;
  disabled?: boolean;
  filter?: boolean;
  showClear?: boolean;
  containerClassName?: string;
  className?: string;
  labelIcon?: ReactNode;
  onChange?: (value: string | number | null) => void;
}

const CommonSelect = forwardRef<any, CommonSelectProps>(
  (
    {
      id,
      label,
      options,
      value = null,
      placeholder = "Select an option",
      error,
      hint,
      required = false,
      disabled = false,
      filter = false,
      showClear = false,
      containerClassName = "",
      className = "",
      labelIcon,
      onChange,
      filterPlaceholder = "Search options...",
      emptyMessage = "No options found",
      ...dropdownProps
    },
    ref,
  ) => {
    const generatedId = useId();
    const selectId = id || generatedId;
    const messageId = `${selectId}-message`;

    return (
      <div className={`common-select-group ${containerClassName}`.trim()}>
        {label && (
          <label htmlFor={selectId} className="common-select-label">
            {labelIcon && (
              <span className="common-select-label-icon">{labelIcon}</span>
            )}

            {label}

            {required && <span className="common-select-required">*</span>}
          </label>
        )}

        <div
          className={[
            "common-select-wrapper",
            error ? "has-error" : "",
            disabled ? "is-disabled" : "",
          ]
            .filter(Boolean)
            .join(" ")}
        >
          <Dropdown
            ref={ref}
            inputId={selectId}
            value={value}
            options={options}
            optionLabel="label"
            optionValue="value"
            placeholder={placeholder}
            disabled={disabled}
            filter={filter}
            showClear={showClear}
            filterPlaceholder={filterPlaceholder}
            emptyMessage={emptyMessage}
            onChange={(event) => onChange?.(event.value ?? null)}
            dropdownIcon={<ChevronDown size={17} strokeWidth={2} />}
            clearIcon={<X size={14} />}
            className={["common-select", error ? "p-invalid" : "", className]
              .filter(Boolean)
              .join(" ")}
            panelClassName="common-select-panel"
            appendTo={typeof document !== "undefined" ? document.body : undefined}
            aria-describedby={error || hint ? messageId : undefined}
            aria-invalid={!!error}
            {...dropdownProps}
          />
        </div>

        {(error || hint) && (
          <small
            id={messageId}
            className={`common-select-message ${
              error ? "is-error" : "is-hint"
            }`}
          >
            {error || hint}
          </small>
        )}
      </div>
    );
  },
);

CommonSelect.displayName = "CommonSelect";

export default CommonSelect;