
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import "./CommonButton.scss";

export type ButtonVariant =
  | "primary"
  | "secondary"
  | "success"
  | "danger"
  | "warning"
  | "outline"
  | "outline-primary"
  | "ghost"
  | "link";

export type ButtonSize = "sm" | "md" | "lg";

interface CommonButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  loading?: boolean;
  fullWidth?: boolean;
  children: ReactNode;
}

export default function CommonButton({
  variant = "primary",
  size = "md",
  leftIcon,
  rightIcon,
  loading = false,
  fullWidth = false,
  disabled = false,
  children,
  className = "",
  type = "button",
  ...props
}: CommonButtonProps) {
  const buttonClasses = [
    "common-btn",
    `common-btn--${variant}`,
    `common-btn--${size}`,
    fullWidth ? "common-btn--full-width" : "",
    loading ? "common-btn--loading" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <button
      type={type}
      className={buttonClasses}
      disabled={disabled || loading}
      aria-busy={loading}
      {...props}
    >
      {loading ? (
        <LoaderCircle className="common-btn__spinner" size={16} />
      ) : (
        leftIcon && (
          <span className="common-btn__icon">
            {leftIcon}
          </span>
        )
      )}

      <span className="common-btn__label">{children}</span>

      {!loading && rightIcon && (
        <span className="common-btn__icon">
          {rightIcon}
        </span>
      )}
    </button>
  );
}
