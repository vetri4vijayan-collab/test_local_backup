import { STATUS_META, type StatusKey } from "@/constants/status";

interface StatusBadgeProps {
  status: StatusKey;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const { label, tone } = STATUS_META[status];

  return (
    <span className={`app-status app-status--${tone}`}>
      <span className="app-status__dot" />
      {label}
    </span>
  );
}
