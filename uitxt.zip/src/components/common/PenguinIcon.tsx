interface PenguinIconProps {
  size?: number;
  className?: string;
}

/**
 * Placeholder penguin glyph (inline SVG).
 * Later you can replace the body of <Logo /> with an <img src="..."/>
 * and this file can be deleted.
 */
export function PenguinIcon({ size = 28, className }: PenguinIconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label="Penguin"
    >
      {/* flippers */}
      <ellipse cx="13" cy="37" rx="5" ry="13" transform="rotate(14 13 37)" fill="var(--app-penguin-body)" />
      <ellipse cx="51" cy="37" rx="5" ry="13" transform="rotate(-14 51 37)" fill="var(--app-penguin-body)" />
      {/* body */}
      <ellipse cx="32" cy="34" rx="19" ry="25" fill="var(--app-penguin-body)" />
      {/* belly */}
      <ellipse cx="32" cy="39" rx="12" ry="17" fill="var(--app-penguin-belly)" />
      {/* eyes */}
      <circle cx="25.5" cy="23" r="4" fill="var(--app-penguin-belly)" />
      <circle cx="38.5" cy="23" r="4" fill="var(--app-penguin-belly)" />
      <circle cx="26.2" cy="23.4" r="1.8" fill="var(--app-penguin-body)" />
      <circle cx="37.8" cy="23.4" r="1.8" fill="var(--app-penguin-body)" />
      {/* beak */}
      <path d="M27.5 29h9L32 35.5z" fill="var(--app-penguin-beak)" />
      {/* feet */}
      <ellipse cx="24" cy="58.5" rx="7" ry="2.8" fill="var(--app-penguin-beak)" />
      <ellipse cx="40" cy="58.5" rx="7" ry="2.8" fill="var(--app-penguin-beak)" />
    </svg>
  );
}
