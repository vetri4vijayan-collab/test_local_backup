<?php

namespace App\Http\Controllers;

use App\Models\App;
use App\Models\Category;
use App\Models\Download;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    // Middleware is handled in routes/web.php


    public function dashboard()
    {
        $pendingApps    = App::with('developer')->where('publish_status', 'review')->get();
        $recentApps     = App::with(['developer', 'category'])->latest()->take(8)->get();
        $topApps        = App::with(['category', 'latestVersion'])->orderByDesc('total_downloads')->take(5)->get();
        $totalDownloads = Download::count();

        $downloadsChart = Download::selectRaw("DATE_FORMAT(created_at, '%Y-%m-%d') as date, count(*) as count")
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return view('admin.dashboard', compact('pendingApps', 'recentApps', 'topApps', 'totalDownloads', 'downloadsChart'));
    }

    // ─── Apps ─────────────────────────────────────────────────────────────────

    public function apps(Request $request)
    {
        $query = App::with(['developer', 'category', 'latestVersion']);

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q->where('app_name', 'like', "%$s%")->orWhere('package_name', 'like', "%$s%"));
        }
        if ($request->filled('status')) {
            $query->where('publish_status', $request->status);
        }

        $apps = $query->latest()->paginate(15)->withQueryString();
        return view('admin.apps.index', compact('apps'));
    }

    public function approveApp(App $app)
    {
        $app->update(['publish_status' => 'published', 'status' => 'active']);
        return back()->with('success', "App '{$app->app_name}' approved and published.");
    }

    public function rejectApp(App $app)
    {
        $app->update(['publish_status' => 'draft']);
        return back()->with('success', "App '{$app->app_name}' rejected.");
    }

    public function toggleFeatured(App $app)
    {
        $app->update(['is_featured' => !$app->is_featured]);
        return back()->with('success', 'Featured status updated.');
    }

    public function deleteApp(App $app)
    {
        $app->delete();
        return back()->with('success', 'App deleted.');
    }

    // ─── Categories ───────────────────────────────────────────────────────────

    public function categories()
    {
        $categories = Category::withCount('apps')->orderBy('sort_order')->get();
        return view('admin.categories.index', compact('categories'));
    }

    public function storeCategory(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:100|unique:categories',
            'icon'        => 'required|string|max:10',
            'color'       => 'required|string|max:20',
            'description' => 'nullable|string',
            'sort_order'  => 'integer',
        ]);
        $data['slug'] = \Illuminate\Support\Str::slug($data['name']);
        Category::create($data);
        return back()->with('success', 'Category created.');
    }

    public function updateCategory(Request $request, Category $category)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:100|unique:categories,name,' . $category->id,
            'icon'        => 'required|string|max:10',
            'color'       => 'required|string|max:20',
            'description' => 'nullable|string',
            'sort_order'  => 'integer',
        ]);
        $data['slug'] = \Illuminate\Support\Str::slug($data['name']);
        $category->update($data);
        return back()->with('success', 'Category updated.');
    }

    public function deleteCategory(Category $category)
    {
        $category->delete();
        return back()->with('success', 'Category deleted.');
    }

    // ─── Users ────────────────────────────────────────────────────────────────

    public function users(Request $request)
    {
        $users = User::withCount('apps')->latest()->paginate(15);
        return view('admin.users.index', compact('users'));
    }

    public function storeUser(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users',
            'role'     => 'required|in:admin,developer,user',
            'password' => 'required|min:8',
        ]);
        $data['password'] = Hash::make($data['password']);
        User::create($data);
        return back()->with('success', 'User created.');
    }

    public function toggleUser(User $user)
    {
        $user->update(['is_active' => !$user->is_active]);
        return back()->with('success', 'User status updated.');
    }

    public function deleteUser(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->withErrors(['error' => 'Cannot delete yourself.']);
        }
        $user->delete();
        return back()->with('success', 'User deleted.');
    }

    // ─── Analytics ────────────────────────────────────────────────────────────

    public function analytics()
    {
        $topApps = App::with('latestVersion')
            ->orderByDesc('total_downloads')
            ->take(10)
            ->get();

        $downloadsChart = Download::selectRaw("DATE_FORMAT(created_at, '%Y-%m-%d') as date, count(*) as count")
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $categoryStats = Category::withCount(['apps as total_downloads' => fn($q) =>
            $q->select(\DB::raw('sum(total_downloads)'))->where('publish_status', 'published')
        ])->get();

        return view('admin.analytics', compact('topApps', 'downloadsChart', 'categoryStats'));
    }
}
