<?php

namespace App\Http\Controllers;

use App\Models\App;
use App\Models\Category;
use App\Models\Download;
use Illuminate\Http\Request;

class StoreController extends Controller
{
    public function index(Request $request)
    {
        $query = App::with(['category', 'latestVersion'])
            ->where('publish_status', 'published')
            ->where('status', 'active');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('app_name', 'like', "%$s%")
                  ->orWhere('description', 'like', "%$s%")
                  ->orWhere('developer_name', 'like', "%$s%")
                  ->orWhere('package_name', 'like', "%$s%");
            });
        }

        if ($request->filled('category')) {
            $query->whereHas('category', fn($q) => $q->where('slug', $request->category));
        }

        $apps       = $query->orderByDesc('total_downloads')->paginate(12)->withQueryString();
        $featured   = App::with(['category', 'latestVersion'])
                        ->where('publish_status', 'published')
                        ->where('is_featured', true)
                        ->latest()
                        ->take(5)
                        ->get();
        $recent     = App::with(['category', 'latestVersion'])
                        ->where('publish_status', 'published')
                        ->latest()
                        ->take(8)
                        ->get();
        $popular    = App::with(['category', 'latestVersion'])
                        ->where('publish_status', 'published')
                        ->orderByDesc('total_downloads')
                        ->take(8)
                        ->get();
        $categories = Category::withCount(['apps' => fn($q) => $q->where('publish_status', 'published')])->get();

        $totalApps      = App::where('publish_status', 'published')->count();
        $totalDownloads = Download::count();

        return view('store.index', compact(
            'apps', 'featured', 'recent', 'popular', 'categories',
            'totalApps', 'totalDownloads'
        ));
    }

    public function show($slug)
    {
        $app = App::with(['category', 'developer', 'versions', 'screenshots', 'latestVersion'])
            ->where('slug', $slug)
            ->where('publish_status', 'published')
            ->firstOrFail();

        $related = App::with(['category', 'latestVersion'])
            ->where('publish_status', 'published')
            ->where('category_id', $app->category_id)
            ->where('id', '!=', $app->id)
            ->take(6)
            ->get();

        return view('store.show', compact('app', 'related'));
    }

    public function download($appId, $versionId)
    {
        $app     = App::findOrFail($appId);
        $version = $app->versions()->findOrFail($versionId);

        // Track download
        Download::create([
            'app_id'     => $app->id,
            'version_id' => $version->id,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);

        $version->increment('download_count');
        $app->increment('total_downloads');

        $filePath = storage_path('app/public/' . $version->apk_path);
        if (!file_exists($filePath)) {
            abort(404, 'APK file not found.');
        }

        return response()->download($filePath, $version->apk_original_name ?? $app->app_name . '-' . $version->version_name . '.apk');
    }
}
