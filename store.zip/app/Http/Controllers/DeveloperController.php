<?php

namespace App\Http\Controllers;

use App\Models\App;
use App\Models\AppVersion;
use App\Models\AppScreenshot;
use App\Models\Category;
use App\Models\Download;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DeveloperController extends Controller
{
    public function dashboard()
    {
        $user = Auth::user();
        $apps = App::with(['category', 'latestVersion'])
            ->where('developer_id', $user->id)
            ->get();

        $downloadsChart = Download::selectRaw("DATE_FORMAT(created_at, '%Y-%m-%d') as date, count(*) as count")
            ->whereIn('app_id', $apps->pluck('id'))
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return view('developer.dashboard', compact('apps', 'downloadsChart'));
    }

    public function apps()
    {
        $apps = App::with(['category', 'latestVersion'])
            ->where('developer_id', Auth::id())
            ->latest()
            ->paginate(12);

        return view('developer.apps.index', compact('apps'));
    }

    public function createApp()
    {
        $categories = Category::orderBy('name')->get();
        return view('developer.apps.create', compact('categories'));
    }

    public function storeApp(Request $request)
    {
        $data = $request->validate([
            'app_name'          => 'required|string|max:255',
            'package_name'      => 'required|string|max:255|unique:apps',
            'developer_name'    => 'required|string|max:255',
            'client_name'       => 'nullable|string|max:255',
            'category_id'       => 'required|exists:categories,id',
            'description'       => 'required|string',
            'short_description' => 'nullable|string|max:255',
            'support_email'     => 'nullable|email',
            'support_phone'     => 'nullable|string|max:50',
            'website_url'       => 'nullable|url',
            'tags'              => 'nullable|string',
            'demo_username'     => 'nullable|string|max:255',
            'demo_password'     => 'nullable|string|max:255',
            'status'            => 'in:active,inactive,pending',
            'publish_status'    => 'in:published,draft,review',
            'is_featured'       => 'boolean',
            'icon'              => 'nullable|image|mimes:png,jpg,jpeg,webp|max:5120',

            'banner'            => 'nullable|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        $iconPath   = null;
        $bannerPath = null;

        if ($request->hasFile('icon')) {
            $iconPath = $request->file('icon')->store('icons', 'public');
        }
        if ($request->hasFile('banner')) {
            $bannerPath = $request->file('banner')->store('banners', 'public');
        }

        $tags      = null;
        $demoLogin = null;

        if ($request->filled('tags')) {
            $tags = array_map('trim', explode(',', $request->tags));
        }
        if ($request->filled('demo_username')) {
            $demoLogin = ['username' => $request->demo_username, 'password' => $request->demo_password ?? ''];
        }

        $app = App::create([
            'app_name'          => $data['app_name'],
            'package_name'      => $data['package_name'],
            'developer_name'    => $data['developer_name'],
            'client_name'       => $data['client_name'] ?? null,
            'category_id'       => $data['category_id'],
            'developer_id'      => Auth::id(),
            'description'       => $data['description'],
            'short_description' => $data['short_description'] ?? null,
            'support_email'     => $data['support_email'] ?? null,
            'support_phone'     => $data['support_phone'] ?? null,
            'website_url'       => $data['website_url'] ?? null,
            'tags'              => $tags,
            'demo_login'        => $demoLogin,
            'status'            => $data['status'] ?? 'active',
            'publish_status'    => $data['publish_status'] ?? 'draft',
            'is_featured'       => $request->boolean('is_featured'),
            'icon_path'         => $iconPath,
            'banner_path'       => $bannerPath,
        ]);

        // Handle screenshots
        if ($request->hasFile('screenshots')) {
            foreach ($request->file('screenshots') as $index => $screenshot) {
                $path = $screenshot->store('screenshots', 'public');
                $app->screenshots()->create(['path' => $path, 'sort_order' => $index]);
            }
        }

        return redirect()->route('developer.apps')->with('success', "App '{$app->app_name}' created successfully!");
    }

    public function editApp(App $app)
    {
        $this->authorizeApp($app);
        $categories = Category::orderBy('name')->get();
        return view('developer.apps.edit', compact('app', 'categories'));
    }

    public function updateApp(Request $request, App $app)
    {
        $this->authorizeApp($app);

        $data = $request->validate([
            'app_name'          => 'required|string|max:255',
            'package_name'      => 'required|string|max:255|unique:apps,package_name,' . $app->id,
            'developer_name'    => 'required|string|max:255',
            'client_name'       => 'nullable|string|max:255',
            'category_id'       => 'required|exists:categories,id',
            'description'       => 'required|string',
            'short_description' => 'nullable|string|max:255',
            'support_email'     => 'nullable|email',
            'support_phone'     => 'nullable|string|max:50',
            'website_url'       => 'nullable|url',
            'tags'              => 'nullable|string',
            'demo_username'     => 'nullable|string|max:255',
            'demo_password'     => 'nullable|string|max:255',
            'status'            => 'in:active,inactive,pending',
            'publish_status'    => 'in:published,draft,review',
            'is_featured'       => 'boolean',
            'icon'              => 'nullable|image|mimes:png,jpg,jpeg,webp|max:5120',

            'banner'            => 'nullable|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        if ($request->hasFile('icon')) {
            if ($app->icon_path) Storage::disk('public')->delete($app->icon_path);
            $data['icon_path'] = $request->file('icon')->store('icons', 'public');
        }
        if ($request->hasFile('banner')) {
            if ($app->banner_path) Storage::disk('public')->delete($app->banner_path);
            $data['banner_path'] = $request->file('banner')->store('banners', 'public');
        }

        $tags      = null;
        $demoLogin = null;
        if ($request->filled('tags')) {
            $tags = array_map('trim', explode(',', $request->tags));
        }
        if ($request->filled('demo_username')) {
            $demoLogin = ['username' => $request->demo_username, 'password' => $request->demo_password ?? ''];
        }

        $app->update(array_merge($data, [
            'tags'         => $tags,
            'demo_login'   => $demoLogin,
            'is_featured'  => $request->boolean('is_featured'),
        ]));

        // Handle screenshot deletions
        if ($request->filled('delete_screenshots')) {
            foreach ($request->delete_screenshots as $screenshotId) {
                $screenshot = $app->screenshots()->find($screenshotId);
                if ($screenshot) {
                    Storage::disk('public')->delete($screenshot->path);
                    $screenshot->delete();
                }
            }
        }

        if ($request->hasFile('screenshots')) {
            foreach ($request->file('screenshots') as $index => $screenshot) {
                $path = $screenshot->store('screenshots', 'public');
                $app->screenshots()->create(['path' => $path, 'sort_order' => $app->screenshots()->count() + $index]);
            }
        }

        return redirect()->route('developer.apps')->with('success', "App updated successfully!");

    }

    public function deleteApp(App $app)
    {
        $this->authorizeApp($app);
        if ($app->icon_path)   Storage::disk('public')->delete($app->icon_path);
        if ($app->banner_path) Storage::disk('public')->delete($app->banner_path);
        foreach ($app->screenshots as $s) Storage::disk('public')->delete($s->path);
        foreach ($app->versions as $v)   Storage::disk('public')->delete($v->apk_path);
        $app->delete();
        return redirect()->route('developer.apps')->with('success', 'App deleted.');
    }

    // ─── Versions ────────────────────────────────────────────────────────────

    public function versions(App $app)
    {
        $this->authorizeApp($app);
        $versions = $app->versions()->latest()->get();
        return view('developer.versions.index', compact('app', 'versions'));
    }

    public function uploadVersion(App $app)
    {
        $this->authorizeApp($app);
        return view('developer.versions.upload', compact('app'));
    }

    public function storeVersion(Request $request, App $app)
    {
        $this->authorizeApp($app);

        $data = $request->validate([
            'version_name'       => 'required|string|max:50',
            'build_number'       => 'required|string|max:50',
            'release_notes'      => 'nullable|string',
            'min_android_version'=> 'nullable|string|max:20',
            'force_update'       => 'boolean',
            'is_stable'          => 'boolean',
            'apk_file'           => 'required|file|max:512000', // Removed strict mimes:apk
        ]);

        $file = $request->file('apk_file');
        
        // Manual extension check as a fallback for strict MIME detection
        if (strtolower($file->getClientOriginalExtension()) !== 'apk') {
            return back()->withErrors(['apk_file' => 'The file must have a .apk extension.'])->withInput();
        }

        // Check duplicate build
        if ($app->versions()->where('build_number', $data['build_number'])->exists()) {
            return back()->withErrors(['build_number' => 'Build number already exists for this app.'])->withInput();
        }

        $apkPath  = $file->store('apks/' . $app->id, 'public');
        $apkSize  = $file->getSize();
        $md5      = md5_file($file->getRealPath());


        // Mark all previous as not latest
        $app->versions()->update(['is_latest' => false]);

        $version = $app->versions()->create([
            'version_name'        => $data['version_name'],
            'build_number'        => $data['build_number'],
            'apk_path'            => $apkPath,
            'apk_original_name'   => $file->getClientOriginalName(),
            'apk_size'            => $apkSize,
            'release_notes'       => $data['release_notes'] ?? null,
            'min_android_version' => $data['min_android_version'] ?? '5.0',
            'force_update'        => $request->boolean('force_update'),
            'is_latest'           => true,
            'is_stable'           => $request->boolean('is_stable', true),
            'md5_hash'            => $md5,
            'released_at'         => now(),
        ]);

        return redirect()->route('developer.versions', $app)->with('success', "Version {$version->version_name} uploaded!");
    }

    public function deleteVersion(App $app, AppVersion $version)
    {
        $this->authorizeApp($app);
        Storage::disk('public')->delete($version->apk_path);
        $wasLatest = $version->is_latest;
        $version->delete();

        if ($wasLatest) {
            $latest = $app->versions()->latest()->first();
            if ($latest) $latest->update(['is_latest' => true]);
        }

        return back()->with('success', 'Version deleted.');
    }

    public function downloadVersion(App $app, AppVersion $version)
    {
        $this->authorizeApp($app);
        $filePath = storage_path('app/public/' . $version->apk_path);
        if (!file_exists($filePath)) abort(404, 'APK not found.');
        return response()->download($filePath, $version->apk_original_name ?? $app->app_name . '.apk');
    }

    public function analytics(App $app)
    {
        $this->authorizeApp($app);
        $downloads = Download::where('app_id', $app->id)
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m-%d') as date, count(*) as count")
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $versionBreakdown = Download::where('app_id', $app->id)
            ->selectRaw('version_id, count(*) as count')
            ->groupBy('version_id')
            ->with('version')
            ->get();

        return view('developer.analytics', compact('app', 'downloads', 'versionBreakdown'));
    }

    public function deleteScreenshot(AppScreenshot $screenshot)
    {
        $app = $screenshot->app;
        $this->authorizeApp($app);
        Storage::disk('public')->delete($screenshot->path);
        $screenshot->delete();
        return back()->with('success', 'Screenshot deleted.');
    }

    private function authorizeApp(App $app)
    {
        $user = Auth::user();
        if (!$user->isAdmin() && $app->developer_id !== $user->id) {
            abort(403);
        }
    }
}
