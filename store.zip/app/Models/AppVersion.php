<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppVersion extends Model
{
    use HasFactory;

    protected $fillable = [
        'app_id', 'version_name', 'build_number', 'apk_path', 'apk_original_name',
        'apk_size', 'release_notes', 'min_android_version', 'force_update',
        'is_latest', 'is_stable', 'md5_hash', 'download_count', 'released_at',
    ];

    protected $casts = [
        'force_update' => 'boolean',
        'is_latest'    => 'boolean',
        'is_stable'    => 'boolean',
        'released_at'  => 'datetime',
        'apk_size'     => 'integer',
    ];

    public function app()
    {
        return $this->belongsTo(App::class);
    }

    public function downloads()
    {
        return $this->hasMany(Download::class, 'version_id');
    }

    public function getApkUrlAttribute()
    {
        return route('download.apk', ['app' => $this->app_id, 'version' => $this->id]);
    }

    public function getFormattedSizeAttribute()
    {
        $bytes = $this->apk_size;
        if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
        if ($bytes >= 1048576)    return number_format($bytes / 1048576, 2) . ' MB';
        if ($bytes >= 1024)       return number_format($bytes / 1024, 2) . ' KB';
        return $bytes . ' B';
    }
}
