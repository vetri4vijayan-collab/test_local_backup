<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Download extends Model
{
    use HasFactory;

    protected $fillable = ['app_id', 'version_id', 'ip_address', 'user_agent', 'country'];

    public function app()
    {
        return $this->belongsTo(App::class);
    }

    public function version()
    {
        return $this->belongsTo(AppVersion::class, 'version_id');
    }
}
