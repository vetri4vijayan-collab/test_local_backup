<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class App extends Model
{
    use HasFactory;

    protected $fillable = [
        'app_name', 'slug', 'package_name', 'developer_name', 'client_name',
        'description', 'short_description', 'icon_path', 'banner_path',
        'category_id', 'developer_id', 'tags', 'demo_login', 'support_email',
        'support_phone', 'website_url', 'status', 'publish_status',
        'is_featured', 'total_downloads',
    ];

    protected $casts = [
        'tags'       => 'array',
        'demo_login' => 'array',
        'is_featured' => 'boolean',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($app) {
            if (empty($app->slug)) {
                $app->slug = Str::slug($app->app_name) . '-' . Str::random(4);
            }
        });
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function developer()
    {
        return $this->belongsTo(User::class, 'developer_id');
    }

    public function versions()
    {
        return $this->hasMany(AppVersion::class)->orderByDesc('id');
    }

    public function latestVersion()
    {
        return $this->hasOne(AppVersion::class)->where('is_latest', true);
    }

    public function screenshots()
    {
        return $this->hasMany(AppScreenshot::class)->orderBy('sort_order');
    }

    public function downloads()
    {
        return $this->hasMany(Download::class);
    }

    public function getIconUrlAttribute()
    {
        return $this->icon_path ? asset('storage/' . $this->icon_path) : null;
    }

    public function getBannerUrlAttribute()
    {
        return $this->banner_path ? asset('storage/' . $this->banner_path) : null;
    }
}
