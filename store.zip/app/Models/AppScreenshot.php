<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppScreenshot extends Model
{
    use HasFactory;

    protected $fillable = ['app_id', 'path', 'caption', 'sort_order'];

    public function app()
    {
        return $this->belongsTo(App::class);
    }

    public function getUrlAttribute()
    {
        return asset('storage/' . $this->path);
    }
}
