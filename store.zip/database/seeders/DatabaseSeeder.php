<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin User
        User::firstOrCreate(['email' => 'admin@elysium.app'], [
            'name'     => 'Admin',
            'password' => Hash::make('password'),
            'role'     => 'admin',
            'company'  => 'Elysium',
            'is_active'=> true,
        ]);

        // Developer User
        User::firstOrCreate(['email' => 'dev@elysium.app'], [
            'name'     => 'Developer',
            'password' => Hash::make('password'),
            'role'     => 'developer',
            'company'  => 'Elysium Dev',
            'is_active'=> true,
        ]);

        // Categories
        $categories = [
            ['name' => 'EIBS', 'icon' => '🏢', 'color' => '#10b981', 'sort_order' => 1],
            ['name' => 'EAPL', 'icon' => '🏭', 'color' => '#6366f1', 'sort_order' => 2],
            ['name' => 'APF',  'icon' => '🏗️', 'color' => '#f59e0b', 'sort_order' => 3],
            ['name' => 'ETPL', 'icon' => '💻', 'color' => '#8b5cf6', 'sort_order' => 4],
        ];

        foreach ($categories as $cat) {
            Category::firstOrCreate(['name' => $cat['name']], [
                'slug'       => \Illuminate\Support\Str::slug($cat['name']),
                'icon'       => $cat['icon'],
                'color'      => $cat['color'],
                'sort_order' => $cat['sort_order'],
            ]);
        }
    }
}
