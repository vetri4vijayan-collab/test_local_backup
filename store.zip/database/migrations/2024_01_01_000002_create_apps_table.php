<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('apps', function (Blueprint $table) {
            $table->id();
            $table->string('app_name');
            $table->string('slug')->unique();
            $table->string('package_name')->unique();
            $table->string('developer_name');
            $table->string('client_name')->nullable();
            $table->text('description');
            $table->string('short_description')->nullable();
            $table->string('icon_path')->nullable();
            $table->string('banner_path')->nullable();
            $table->foreignId('category_id')->constrained()->onDelete('cascade');
            $table->foreignId('developer_id')->constrained('users')->onDelete('cascade');
            $table->json('tags')->nullable();
            $table->json('demo_login')->nullable();
            $table->string('support_email')->nullable();
            $table->string('support_phone')->nullable();
            $table->string('website_url')->nullable();
            $table->enum('status', ['active', 'inactive', 'pending'])->default('active');
            $table->enum('publish_status', ['published', 'draft', 'review'])->default('draft');
            $table->boolean('is_featured')->default(false);
            $table->integer('total_downloads')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('apps');
    }
};
