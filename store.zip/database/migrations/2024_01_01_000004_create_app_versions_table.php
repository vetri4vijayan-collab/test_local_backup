<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('app_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('app_id')->constrained()->onDelete('cascade');
            $table->string('version_name');
            $table->string('build_number');
            $table->string('apk_path');
            $table->string('apk_original_name')->nullable();
            $table->unsignedBigInteger('apk_size')->default(0);
            $table->text('release_notes')->nullable();
            $table->string('min_android_version')->default('5.0');
            $table->boolean('force_update')->default(false);
            $table->boolean('is_latest')->default(false);
            $table->boolean('is_stable')->default(true);
            $table->string('md5_hash')->nullable();
            $table->integer('download_count')->default(0);
            $table->timestamp('released_at')->nullable();
            $table->timestamps();

            $table->unique(['app_id', 'build_number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('app_versions');
    }
};
