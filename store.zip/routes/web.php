<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DeveloperController;
use App\Http\Controllers\StoreController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public Store Routes
|--------------------------------------------------------------------------
*/
Route::get('/', [StoreController::class, 'index'])->name('store.index');
Route::get('/app/{slug}', [StoreController::class, 'show'])->name('store.show');
Route::get('/download/{app}/{version}', [StoreController::class, 'download'])->name('download.apk');

/*
|--------------------------------------------------------------------------
| Auth Routes
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
});
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

/*
|--------------------------------------------------------------------------
| Developer Routes
|--------------------------------------------------------------------------
*/
Route::prefix('developer')->name('developer.')->middleware(['auth', 'developer'])->group(function () {
    Route::get('/dashboard', [DeveloperController::class, 'dashboard'])->name('dashboard');
    Route::get('/apps', [DeveloperController::class, 'apps'])->name('apps');
    Route::get('/apps/create', [DeveloperController::class, 'createApp'])->name('apps.create');
    Route::post('/apps', [DeveloperController::class, 'storeApp'])->name('apps.store');
    Route::get('/apps/{app}/edit', [DeveloperController::class, 'editApp'])->name('apps.edit');
    Route::put('/apps/{app}', [DeveloperController::class, 'updateApp'])->name('apps.update');
    Route::delete('/apps/{app}', [DeveloperController::class, 'deleteApp'])->name('apps.delete');

    Route::get('/apps/{app}/versions', [DeveloperController::class, 'versions'])->name('versions');
    Route::get('/apps/{app}/versions/upload', [DeveloperController::class, 'uploadVersion'])->name('versions.upload');
    Route::post('/apps/{app}/versions', [DeveloperController::class, 'storeVersion'])->name('versions.store');
    Route::delete('/apps/{app}/versions/{version}', [DeveloperController::class, 'deleteVersion'])->name('versions.delete');
    Route::get('/apps/{app}/versions/{version}/download', [DeveloperController::class, 'downloadVersion'])->name('versions.download');

    Route::get('/apps/{app}/analytics', [DeveloperController::class, 'analytics'])->name('analytics');
    Route::delete('/screenshots/{screenshot}', [DeveloperController::class, 'deleteScreenshot'])->name('screenshots.delete');
});

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');

    Route::get('/apps', [AdminController::class, 'apps'])->name('apps');
    Route::post('/apps/{app}/approve', [AdminController::class, 'approveApp'])->name('apps.approve');
    Route::post('/apps/{app}/reject', [AdminController::class, 'rejectApp'])->name('apps.reject');
    Route::post('/apps/{app}/featured', [AdminController::class, 'toggleFeatured'])->name('apps.featured');
    Route::delete('/apps/{app}', [AdminController::class, 'deleteApp'])->name('apps.delete');

    Route::get('/categories', [AdminController::class, 'categories'])->name('categories');
    Route::post('/categories', [AdminController::class, 'storeCategory'])->name('categories.store');
    Route::put('/categories/{category}', [AdminController::class, 'updateCategory'])->name('categories.update');
    Route::delete('/categories/{category}', [AdminController::class, 'deleteCategory'])->name('categories.delete');

    Route::get('/users', [AdminController::class, 'users'])->name('users');
    Route::post('/users', [AdminController::class, 'storeUser'])->name('users.store');
    Route::post('/users/{user}/toggle', [AdminController::class, 'toggleUser'])->name('users.toggle');
    Route::delete('/users/{user}', [AdminController::class, 'deleteUser'])->name('users.delete');

    Route::get('/analytics', [AdminController::class, 'analytics'])->name('analytics');
});
