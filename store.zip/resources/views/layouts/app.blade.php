<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name', 'Elysium App Store') }}</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>
    <div class="layout-wrapper">
        @auth
            @if(request()->is('developer*') || request()->is('admin*'))
                <aside class="sidebar">
                    <div style="padding-bottom: 2rem; margin-bottom: 1.5rem; text-align: left; padding-left: 0.5rem;">
                        <a href="{{ route('store.index') }}">
                            <img src="/images/logo.png" alt="Elysium Groups" style="height: 50px; width: auto;">
                        </a>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        @if(auth()->user()->isAdmin() && request()->is('admin*'))
                            <a href="{{ route('admin.dashboard') }}" class="cat-pill {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" style="border:none; box-shadow:none;">Dashboard</a>
                            <a href="{{ route('admin.apps') }}" class="cat-pill {{ request()->routeIs('admin.apps') ? 'active' : '' }}" style="border:none; box-shadow:none;">Applications</a>
                            <a href="{{ route('admin.categories') }}" class="cat-pill {{ request()->routeIs('admin.categories') ? 'active' : '' }}" style="border:none; box-shadow:none;">Categories</a>
                            <a href="{{ route('admin.users') }}" class="cat-pill {{ request()->routeIs('admin.users') ? 'active' : '' }}" style="border:none; box-shadow:none;">Users</a>
                            <a href="{{ route('admin.analytics') }}" class="cat-pill {{ request()->routeIs('admin.analytics') ? 'active' : '' }}" style="border:none; box-shadow:none;">Analytics</a>
                        @elseif(auth()->user()->isDeveloper() && request()->is('developer*'))
                            <a href="{{ route('developer.dashboard') }}" class="cat-pill {{ request()->routeIs('developer.dashboard') ? 'active' : '' }}" style="border:none; box-shadow:none;">Dashboard</a>
                            <a href="{{ route('developer.apps') }}" class="cat-pill {{ request()->routeIs('developer.apps*') ? 'active' : '' }}" style="border:none; box-shadow:none;">My Portfolio</a>

                        @endif
                    </div>

                    <div style="margin-top: auto; padding-top: 1.5rem; border-top: 1px solid var(--border); display: flex; flex-direction: column; gap: 0.5rem;">
                        <a href="{{ route('store.index') }}" class="cat-pill" style="border:none; box-shadow:none;">Back to Store</a>
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="cat-pill" style="width: 100%; border: none; background: none; cursor: pointer; text-align: left; box-shadow:none;">Logout Account</button>
                        </form>
                    </div>
                </aside>
            @endif
        @endauth

        <div class="content-wrapper" style="{{ !request()->is('developer*') && !request()->is('admin*') ? 'max-width: 1200px;' : '' }} {{ request()->routeIs('login') ? 'padding: 0; max-width: 100%; background: #fff;' : '' }}">
            @if(!request()->is('developer*') && !request()->is('admin*'))
                <nav style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding: 0.75rem 0; border-bottom: 1px solid rgba(0,0,0,0.03);">
                    <a href="{{ route('store.index') }}">
                        <img src="/images/logo.png" alt="Elysium Groups" style="height: 45px; width: auto;">
                    </a>
                    <div style="display: flex; gap: 1.25rem; align-items: center;">
                        <a href="{{ route('store.index') }}" style="text-decoration: none; font-weight: 600; color: var(--text-main); font-size: 0.9rem;">Store</a>
                        @auth
                            <a href="{{ auth()->user()->isAdmin() ? route('admin.dashboard') : route('developer.dashboard') }}" class="btn btn-primary" style="padding: 0.5rem 1.25rem; font-size: 0.85rem;">Dashboard</a>
                        @else
                            <a href="{{ route('login') }}" class="btn btn-primary" style="padding: 0.5rem 1.25rem; font-size: 0.85rem;">Member Login</a>
                        @endauth
                    </div>
                </nav>
            @endif

            @if(session('success'))
                <div class="card" style="background: #e8fadf; color: #28c76f; margin-bottom: 2rem; display: flex; align-items: center; gap: 1rem; padding: 1.25rem; border: 1px solid #c3eec1; box-shadow:none;">
                    <span style="font-size: 1.25rem;">✅</span> 
                    <div style="font-weight: 700;">{{ session('success') }}</div>
                </div>
            @endif

            @yield('content')

            <footer style="margin-top: 4rem; padding: 2rem 0; border-top: 1px solid var(--border); display: flex; justify-content: center; align-items: center; gap: 1rem; color: var(--text-muted); font-size: 0.8rem; font-weight: 600;">
                <span>&copy; {{ date('Y') }} Elysium</span>
                <span style="opacity: 0.3;">|</span>
                <span>Elysium App Store</span>
            </footer>
        </div>
    </div>
</body>
</html>
