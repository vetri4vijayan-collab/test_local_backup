@extends('layouts.app')

@section('content')
<div class="responsive-stack">
    <section>
        {{-- App Header Card --}}
        <div class="card" style="display: flex; gap: 1.25rem; align-items: center; margin-bottom: 0.75rem; padding: 1.25rem; border: none; box-shadow: var(--shadow); flex-wrap: wrap;">

            <div style="flex-shrink: 0;">
                <img src="{{ $app->icon_url }}" 
                     style="width: 80px; height: 80px; border-radius: 16px; box-shadow: 0 8px 20px rgba(115, 103, 240, 0.15); border: 2px solid #fff;" 
                     alt="{{ $app->app_name }}">
            </div>
            <div style="flex-grow: 1; min-width: 200px;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 1rem;">
                    <div>
                        <h1 style="font-size: 1.5rem; font-weight: 800; margin: 0 0 0.1rem; color: var(--text-main); letter-spacing: -0.5px;">{{ $app->app_name }}</h1>
                        <p style="font-size: 0.9rem; color: var(--primary); font-weight: 700; margin: 0;">{{ $app->developer_name }}</p>
                    </div>


                    <div style="display: flex; gap: 0.5rem;">
                        <button onclick="shareApp()" class="btn" style="background: var(--primary-soft); color: var(--primary); border-radius: 8px; padding: 0.4rem 0.75rem; font-size: 0.8rem; font-weight: 700;">
                            🔗 Share App
                        </button>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; background: #f8f7fa; padding: 0.75rem; border-radius: 12px; border: 1px solid #f0eff5;">
                    <div style="text-align: center; border-right: 1px solid #eaeaef;">
                        <div style="font-weight: 800; font-size: 1rem; color: var(--text-main);">{{ number_format($app->total_downloads) }}</div>
                        <div style="color: var(--text-muted); font-size: 0.55rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Installs</div>
                    </div>
                    <div style="text-align: center; border-right: 1px solid #eaeaef;">
                        <div style="font-weight: 800; font-size: 1rem; color: var(--text-main);">{{ $app->latestVersion->version_name ?? 'v1.0' }}</div>
                        <div style="color: var(--text-muted); font-size: 0.55rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Version</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-weight: 800; font-size: 1rem; color: var(--text-main);">{{ $app->latestVersion->min_android_version ?? '5.0' }}+</div>
                        <div style="color: var(--text-muted); font-size: 0.55rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Android</div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Screenshots Section --}}
        @if($app->screenshots->count() > 0)
            <div style="margin-bottom: 1rem;">
                <div style="display: flex; gap: 0.5rem; overflow-x: auto; padding: 0.25rem; scroll-snap-type: x mandatory; scrollbar-width: none;">
                    @foreach($app->screenshots as $screenshot)
                        <img src="{{ $screenshot->url }}" 
                             style="height: 320px; border-radius: 12px; scroll-snap-align: start; box-shadow: 0 4px 10px rgba(0,0,0,0.05); flex-shrink: 0;" 
                             alt="Screenshot">
                    @endforeach
                </div>
            </div>
        @endif

        {{-- About --}}
        <div class="card" style="margin-bottom: 1rem; padding: 1.25rem;">
            <h3 style="margin: 0 0 0.5rem; font-weight: 800; font-size: 1.1rem; color: var(--text-main);">Product Overview</h3>
            <div style="font-size: 0.9rem; line-height: 1.5; color: var(--text-main); white-space: pre-line; opacity: 0.8;">
                {{ $app->description }}
            </div>
        </div>
    </section>

    {{-- Sidebar --}}
    <aside>
        <div style="position: sticky; top: 1.5rem; display: flex; flex-direction: column; gap: 0.75rem;">
            {{-- Install Card --}}
            <div class="card" style="padding: 1rem; text-align: center; border: 1px solid rgba(115, 103, 240, 0.1); background: #fff; box-shadow: 0 4px 15px rgba(75, 70, 92, 0.05); overflow: hidden;">
                <div style="font-size: 0.55rem; font-weight: 800; color: var(--primary); text-transform: uppercase; margin-bottom: 0.5rem; letter-spacing: 1px; opacity: 0.8;">Ready to Install</div>

                
                @if($app->latestVersion)
                    <div style="padding: 0 0.25rem;">
                        <a href="{{ $app->latestVersion->apk_url }}" class="btn btn-primary" style="display: block; width: 100%; padding: 0.9rem; font-size: 1.1rem; border-radius: 12px; margin-bottom: 0.75rem; text-align: center;">
                            Download Now
                        </a>
                    </div>
                    <div style="font-size: 0.8rem; font-weight: 600; color: var(--text-muted);">
                        {{ $app->latestVersion->formatted_size }} <span style="margin: 0 2px; opacity: 0.3;">|</span> v{{ $app->latestVersion->version_name }}
                    </div>
                @else
                    <button class="btn" style="width: 100%; background: #f8f7fa; color: var(--text-muted); cursor: not-allowed;" disabled>No Version</button>
                @endif
            </div>

            {{-- Demo Access --}}
            @if($app->demo_login)
                <div class="card" style="background: #fff9e6; border: 1px solid #ffeeba; padding: 1.25rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="background: #ff9f43; color: white; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 0.9rem;">🔑</div>
                        <h4 style="margin: 0; font-size: 0.9rem; font-weight: 800; color: #856404;">DEMO ACCESS</h4>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 0.6rem;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.9rem; font-weight: 600;">
                            <span style="color: #856404; opacity: 0.7;">User</span>
                            <span style="color: #856404;">{{ $app->demo_login['username'] }}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9rem; font-weight: 600;">
                            <span style="color: #856404; opacity: 0.7;">Pass</span>
                            <span style="color: #856404;">{{ $app->demo_login['password'] }}</span>
                        </div>
                    </div>
                </div>
            @endif

            {{-- Information --}}
            <div class="card" style="padding: 1.25rem;">
                <h4 style="margin: 0 0 1rem; font-weight: 800; font-size: 1rem; color: var(--text-main);">Information</h4>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem;">
                        <span style="color: var(--text-muted); font-weight: 600;">Developer</span>
                        <span style="color: var(--primary); font-weight: 700;">{{ $app->developer_name }}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem; align-items: center;">
                        <span style="color: var(--text-muted); font-weight: 600;">Package</span>
                        <span style="font-family: monospace; font-size: 0.7rem; background: #f1f5f9; padding: 0.2rem 0.5rem; border-radius: 6px; color: #4b5563;">{{ $app->package_name }}</span>
                    </div>
                </div>
            </div>
        </div>
    </aside>
</div>

<script>
    function shareApp() {
        const shareData = {
            title: '{{ $app->app_name }}',
            text: 'Check out this app on Elysium Store: {{ $app->app_name }}',
            url: window.location.href
        };

        if (navigator.share) {
            navigator.share(shareData).catch(err => console.log('Error sharing', err));
        } else {
            navigator.clipboard.writeText(window.location.href).then(() => {
                alert('App link copied to clipboard!');
            });
        }
    }
</script>
@endsection
