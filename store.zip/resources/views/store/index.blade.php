@extends('layouts.app')

@section('content')
<div style="background: linear-gradient(135deg, var(--primary), var(--secondary)); padding: 4rem 2rem; border-radius: 24px; margin-bottom: 2.5rem; text-align: center; color: white; position: relative; overflow: hidden; box-shadow: var(--shadow-lg);">
    <div style="position: absolute; top: -10%; left: -5%; width: 250px; height: 250px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
    <div style="position: absolute; bottom: -15%; right: -5%; width: 350px; height: 350px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
    
    <h1 style="font-size: 2.75rem; font-weight: 800; margin-bottom: 1rem; position: relative; z-index: 1; letter-spacing: -1px;">Explore Internal Apps</h1>
    <p style="font-size: 1.1rem; opacity: 0.9; margin-bottom: 2.5rem; position: relative; z-index: 1; font-weight: 500;">Find the best applications to accelerate your workflow.</p>
    
    <form action="{{ route('store.index') }}" method="GET" style="max-width: 650px; margin: 0 auto; width: 100%; position: relative; z-index: 1;">
        <div style="position: relative; display: flex; align-items: center; width: 100%;">
            <div style="position: absolute; left: 1.25rem; font-size: 1.25rem; opacity: 0.4; color: #000;">🔍</div>
            <input type="text" name="search" value="{{ request('search') }}" 
                   placeholder="Search for applications..." 
                   class="form-control" 
                   style="padding: 1.1rem 8rem 1.1rem 3.5rem; border-radius: 100px; font-size: 1.05rem; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15); border: none; width: 100%; font-weight: 500;">
            <button type="submit" class="btn btn-primary" 
                    style="position: absolute; right: 8px; border-radius: 100px; padding: 0.8rem 1.75rem; font-size: 0.95rem; background: var(--text-main); color: #fff; box-shadow: none;">
                Search
            </button>
        </div>
    </form>
</div>

    <div style="display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap; margin-bottom: 3rem;">
        <a href="{{ route('store.index') }}" 
           class="cat-pill {{ !request('category') ? 'active' : '' }}" style="padding: 0.75rem 1.75rem; font-size: 0.95rem; border-radius: 14px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); {{ !request('category') ? 'background: linear-gradient(135deg, var(--primary), var(--secondary)); border-color: transparent;' : '' }}">
           All Apps
        </a>
        @foreach($categories as $category)
            <a href="{{ route('store.index', ['category' => $category->slug]) }}" 
               class="cat-pill {{ request('category') == $category->slug ? 'active' : '' }}" style="padding: 0.75rem 1.75rem; font-size: 0.95rem; border-radius: 14px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); {{ request('category') == $category->slug ? 'background: linear-gradient(135deg, var(--primary), var(--secondary)); border-color: transparent;' : '' }}">
                {{ $category->name }}
            </a>
        @endforeach
    </div>

<div style="margin-top: 0.5rem;">
    <section>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 1rem;">
            <h2 style="margin: 0; font-weight: 800; font-size: 1.25rem; color: var(--text-main);">
                @if(request('search'))
                    Results for "{{ request('search') }}"
                @elseif(request('category'))
                    {{ $categories->where('slug', request('category'))->first()->name ?? 'Category' }} Apps
                @else
                    Available Apps
                @endif
            </h2>
            <div class="text-muted" style="font-weight: 600; font-size: 0.9rem;">{{ $apps->total() }} apps available</div>
        </div>

        @if($apps->count() > 0)
            <div class="grid-4">
                @foreach($apps as $app)
                    <a href="{{ route('store.show', $app->slug) }}" style="text-decoration: none; color: inherit;">
                        <div class="card" style="display: flex; flex-direction: column; gap: 1.25rem; height: 100%; padding: 1.5rem; border-top: 5px solid var(--primary); transition: all 0.3s ease; position: relative; overflow: hidden; background: #fff;">
                            <div style="position: absolute; top: -40px; right: -40px; width: 120px; height: 120px; background: var(--primary-soft); border-radius: 50%; opacity: 0.6; z-index: 0; transition: transform 0.3s ease;" class="card-bg-shape"></div>
                            
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; z-index: 1;">
                                <div style="width: 68px; height: 68px; border-radius: 16px; background: #fff; box-shadow: 0 8px 20px rgba(0,0,0,0.08); display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 0.4rem; border: 1px solid var(--border);">
                                    <img src="{{ $app->icon_url }}" style="width: 100%; height: 100%; object-fit: contain;" alt="{{ $app->app_name }}">
                                </div>
                            </div>

                            <div style="flex-grow: 1; z-index: 1;">
                                <h3 style="margin: 0 0 0.4rem; font-size: 1.25rem; font-weight: 800; color: var(--text-main);">{{ $app->app_name }}</h3>
                                <p class="text-muted" style="margin: 0; font-size: 0.9rem; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                                    {{ $app->short_description ?? $app->description }}
                                </p>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1.25rem; border-top: 1px dashed var(--border); z-index: 1;">
                                <span style="background: var(--primary-soft); color: var(--primary); padding: 0.4rem 0.8rem; border-radius: 8px; font-weight: 800; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">{{ $app->category->name }}</span>
                                <span style="font-size: 0.8rem; font-weight: 800; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem;">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                    {{ number_format($app->total_downloads) }}
                                </span>
                            </div>
                        </div>
                    </a>
                @endforeach
            </div>
            <div style="margin-top: 4rem;">
                {{ $apps->links() }}
            </div>
        @else
            <div style="text-align: center; padding: 3rem 0; background: #fff; border-radius: 20px; box-shadow: var(--shadow);">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🔍</div>
                <h3 style="margin-bottom: 0.25rem; font-weight: 800; font-size: 1.1rem;">No apps found</h3>
                <p class="text-muted" style="font-size: 0.9rem;">Adjust your search or filters.</p>
                <a href="{{ route('store.index') }}" class="btn btn-primary" style="margin-top: 1rem; padding: 0.5rem 1.5rem; font-size: 0.85rem;">Reset All</a>
            </div>
        @endif
    </section>
</div>
@endsection
