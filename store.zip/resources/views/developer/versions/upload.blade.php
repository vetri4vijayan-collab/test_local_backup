@extends('layouts.app')

@section('content')
<div style="max-width: 600px; margin: 0 auto;">
    <div style="margin-bottom: 3rem;">
        <a href="{{ route('developer.versions', $app->id) }}" style="color: var(--text-muted); text-decoration: none; font-size: 0.9rem;">
            ← Back to Versions
        </a>
        <h1 style="font-weight: 800; margin: 0.5rem 0 0;">Upload New Version</h1>
        <p class="text-muted">For {{ $app->app_name }}</p>
    </div>

    <form action="{{ route('developer.versions.store', $app->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        
        <div class="card">
            <div class="form-group">
                <label class="form-label">Version Name *</label>
                <input type="text" name="version_name" class="form-control" placeholder="e.g. 1.0.4" required>
                <p class="text-muted" style="font-size: 0.75rem; margin-top: 0.25rem;">The public version name (e.g. 2.1.0)</p>
            </div>

            <div class="form-group">
                <label class="form-label">Build Number *</label>
                <input type="text" name="build_number" class="form-control" placeholder="e.g. 104" required>
                <p class="text-muted" style="font-size: 0.75rem; margin-top: 0.25rem;">Internal integer build number</p>
            </div>

            <div class="form-group">
                <label class="form-label">APK File *</label>
                <input type="file" name="apk_file" class="form-control" accept=".apk" required>
                <p class="text-muted" style="font-size: 0.75rem; margin-top: 0.25rem;">Max size: 500MB</p>
            </div>

            <div class="form-group">
                <label class="form-label">Release Notes</label>
                <textarea name="release_notes" class="form-control" rows="5" placeholder="What's new in this version..."></textarea>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Min Android Version</label>
                    <input type="text" name="min_android_version" class="form-control" value="5.0">
                </div>
                <div class="form-group" style="padding-top: 2rem;">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" name="is_stable" value="1" checked>
                        <span style="font-size: 0.875rem;">Stable Release</span>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                    <input type="checkbox" name="force_update" value="1">
                    <span style="font-size: 0.875rem;">Force Update Required</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 1rem; margin-top: 1rem;">
                Upload & Publish
            </button>
        </div>
    </form>
</div>
@endsection
