@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 1rem;">
        <a href="{{ route('developer.apps') }}" style="color: var(--text-muted); text-decoration: none;">← Back</a>
    </div>
    <div style="display: flex; justify-content: space-between; align-items: end;">
        <div>
            <h1 style="font-weight: 800; margin: 0;">{{ $app->app_name }} <span class="text-muted" style="font-weight: 400; font-size: 1.5rem;">Versions</span></h1>
            <p class="text-muted">Manage APK uploads and release history</p>
        </div>
        <a href="{{ route('developer.versions.upload', $app->id) }}" class="btn btn-primary">
            + Upload New Version
        </a>
    </div>
</div>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse; text-align: left;">
        <thead>
            <tr style="border-bottom: 1px solid var(--border);">
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Version</th>
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Build</th>
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Status</th>
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Size</th>
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Released</th>
                <th style="padding: 1rem 1.5rem; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($versions as $version)
                <tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 1rem 1.5rem;">
                        <div style="font-weight: 700;">{{ $version->version_name }}</div>
                        @if($version->is_latest)
                            <span class="badge badge-info" style="font-size: 0.6rem;">Latest</span>
                        @endif
                    </td>
                    <td style="padding: 1rem 1.5rem;">{{ $version->build_number }}</td>
                    <td style="padding: 1rem 1.5rem;">
                        <span class="badge {{ $version->is_stable ? 'badge-success' : 'badge-warning' }}">
                            {{ $version->is_stable ? 'Stable' : 'Beta' }}
                        </span>
                    </td>

                    <td style="padding: 1rem 1.5rem;" class="text-muted">{{ $version->formatted_size }}</td>
                    <td style="padding: 1rem 1.5rem;" class="text-muted">{{ $version->released_at->format('M d, Y') }}</td>
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem;">
                            <a href="{{ route('developer.versions.download', [$app->id, $version->id]) }}" title="Download APK" style="color: var(--primary);">⬇️</a>
                            <form action="{{ route('developer.versions.delete', [$app->id, $version->id]) }}" method="POST" onsubmit="return confirm('Delete this version?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" style="background: none; border: none; cursor: pointer; color: var(--danger); padding: 0;">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    @if($versions->isEmpty())
        <div style="padding: 4rem; text-align: center;" class="text-muted">No versions uploaded yet.</div>
    @endif
</div>
@endsection
