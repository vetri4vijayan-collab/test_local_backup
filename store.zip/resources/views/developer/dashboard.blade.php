@extends('layouts.app')

@section('content')
<div style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center;">
    <div>
        <h1 style="font-weight: 800; margin: 0; font-size: 1.75rem;">Hello, {{ auth()->user()->name }}! 👋</h1>
        <p class="text-muted" style="margin: 0;">Here's what's happening in your app portfolio.</p>
    </div>
    <div style="display: flex; gap: 0.75rem;">
        <a href="{{ route('developer.apps.create') }}" class="btn btn-primary">+ Create New App</a>
    </div>
</div>

<div class="grid-bento">
    <div class="stat-card stat-primary">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Total Apps</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ $apps->count() }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">LIVE PORTFOLIO</div>
    </div>
    <div class="stat-card stat-success">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Published</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ $apps->where('publish_status', 'published')->count() }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">STORE VISIBLE</div>
    </div>
    <div class="stat-card stat-warning">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Pending Review</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ $apps->where('publish_status', 'review')->count() }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">AWAITING APPROVAL</div>
    </div>
    <div class="stat-card stat-info">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Total Downloads</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ number_format($apps->sum('total_downloads')) }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">+{{ rand(5, 15) }}% GROWTH</div>
    </div>
</div>

<div class="grid-dashboard">
    <div class="card" style="padding: 0;">
        <div style="padding: 1.5rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 1.1rem; font-weight: 800;">Recent Applications</h3>
            <a href="{{ route('developer.apps') }}" class="text-muted" style="text-decoration: none; font-size: 0.85rem; font-weight: 600;">View All →</a>
        </div>
        <div class="table-responsive">
            <table class="table-modern">
                <thead>
                    <tr>
                        <th>APP</th>
                        <th>STATUS</th>
                        <th>DOWNLOADS</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($apps->take(5) as $app)
                        <tr>
                            <td>
                                <div style="display: flex; gap: 0.75rem; align-items: center;">
                                    <img src="{{ $app->icon_url }}" style="width: 36px; height: 36px; border-radius: 10px;">
                                    <div>
                                        <div style="font-weight: 700; font-size: 0.9rem;">{{ $app->app_name }}</div>
                                        <div class="text-muted" style="font-size: 0.7rem;">{{ $app->package_name }}</div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge {{ $app->publish_status == 'published' ? 'badge-success' : ($app->publish_status == 'draft' ? 'badge-muted' : 'badge-warning') }}">
                                    {{ $app->publish_status }}
                                </span>
                            </td>
                            <td style="font-weight: 700; font-size: 0.9rem;">{{ number_format($app->total_downloads) }}</td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="{{ route('developer.versions', $app->id) }}" class="btn" style="background: var(--primary-soft); color: var(--primary); padding: 0.3rem 0.75rem; font-size: 0.75rem;">Versions</a>
                                    <a href="{{ route('developer.apps.edit', $app->id) }}" class="btn" style="background: var(--subsurface); color: var(--text-muted); padding: 0.3rem 0.75rem; font-size: 0.75rem;">Edit</a>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h3 style="margin: 0 0 1.5rem; font-size: 1.1rem; font-weight: 800;">Distribution</h3>
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
            @foreach(['HR Tool', 'Sales CRM', 'Operations'] as $index => $label)
                <div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.8rem; margin-bottom: 0.5rem; font-weight: 600;">
                        <span>{{ $label }}</span>
                        <span class="text-muted">{{ rand(20, 90) }}%</span>
                    </div>
                    <div style="height: 8px; background: var(--subsurface); border-radius: 4px; overflow: hidden;">
                        <div style="width: {{ rand(20, 90) }}%; height: 100%; background: {{ ['var(--primary)', 'var(--success)', 'var(--accent)'][$index] }};"></div>
                    </div>
                </div>
            @endforeach
        </div>
        
        <div style="margin-top: 2rem; background: var(--subsurface); border-radius: 16px; padding: 1.25rem; text-align: center;">
            <div style="font-size: 1.5rem; margin-bottom: 0.5rem;">💡</div>
            <p style="font-size: 0.8rem; font-weight: 600; margin: 0;">Try publishing new versions on Mondays to maximize user updates.</p>
        </div>
    </div>
</div>
@endsection
