@extends('layouts.app')

@section('content')
<div style="margin-bottom: 2rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h1 style="font-weight: 800; margin: 0; font-size: 1.75rem;">My Applications</h1>
            <p class="text-muted" style="margin: 0;">Manage your uploaded apps and versions</p>
        </div>
        <a href="{{ route('developer.apps.create') }}" class="btn btn-primary">
            + Create New App
        </a>
    </div>
</div>

<div class="grid-4">
    @foreach($apps as $app)
        <div class="card" style="display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 1.25rem;">
                <img src="{{ $app->icon_url ?? 'https://ui-avatars.com/api/?name='.urlencode($app->app_name) }}" 
                     class="app-icon" alt="{{ $app->app_name }}">
                <div style="flex-grow: 1; min-width: 0;">
                    <h3 style="margin: 0; font-size: 1rem; font-weight: 800; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ $app->app_name }}</h3>
                    <div class="text-muted" style="font-size: 0.75rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ $app->package_name }}</div>
                </div>
            </div>
            
            <div style="margin-bottom: 1.25rem;">
                <span class="badge {{ $app->publish_status == 'published' ? 'badge-success' : ($app->publish_status == 'review' ? 'badge-warning' : 'badge-muted') }}" style="font-size: 0.65rem;">
                    {{ $app->publish_status }}
                </span>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; background: #fcfcfd; padding: 0.75rem; border-radius: 12px; margin-bottom: 1.5rem; border: 1px solid var(--border);">
                <div>
                    <div class="text-muted" style="font-size: 0.65rem; text-transform: uppercase; font-weight: 800; letter-spacing: 0.5px;">Installs</div>
                    <div style="font-weight: 800; font-size: 0.9rem; color: var(--text-main);">{{ number_format($app->total_downloads) }}</div>
                </div>
                <div>
                    <div class="text-muted" style="font-size: 0.65rem; text-transform: uppercase; font-weight: 800; letter-spacing: 0.5px;">Version</div>
                    <div style="font-weight: 800; font-size: 0.9rem; color: var(--text-main);">{{ $app->latestVersion->version_name ?? 'N/A' }}</div>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-top: auto;">
                <a href="{{ route('developer.versions', $app->id) }}" class="btn" style="border: 1px solid var(--border); font-size: 0.8rem; justify-content: center; font-weight: 800;">
                    Versions
                </a>
                <a href="{{ route('developer.apps.edit', $app->id) }}" class="btn" style="border: 1px solid var(--border); font-size: 0.8rem; justify-content: center; font-weight: 800;">
                    Edit App
                </a>
                <a href="{{ route('developer.analytics', $app->id) }}" class="btn" style="grid-column: span 2; background: var(--primary-soft); color: var(--primary); font-size: 0.8rem; justify-content: center; font-weight: 800; border: none;">
                    View Analytics
                </a>
            </div>
        </div>
    @endforeach
</div>

@if($apps->isEmpty())
    <div style="text-align: center; padding: 6rem 0;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🚀</div>
        <h3>No applications yet</h3>
        <p class="text-muted">Register your first application to start distributing it.</p>
        <a href="{{ route('developer.apps.create') }}" class="btn btn-primary" style="margin-top: 1rem;">Create App</a>
    </div>
@endif

<div style="margin-top: 3rem;">
    {{ $apps->links() }}
</div>
@endsection
