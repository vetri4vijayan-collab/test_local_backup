@extends('layouts.app')

@section('content')
<div style="max-width: 1000px; margin: 0 auto;">
    <div style="margin-bottom: 2rem;">
        <a href="{{ route('developer.dashboard') }}" style="color: var(--text-muted); text-decoration: none; font-size: 0.85rem; font-weight: 600; display: flex; align-items: center; gap: 0.4rem; margin-bottom: 0.75rem;">
            ← Dashboard
        </a>
        <h1 style="font-weight: 800; margin: 0; font-size: 1.75rem;">Create New Application</h1>
        <p class="text-muted" style="font-size: 0.9rem;">Register a new internal tool for the Elysium App Store.</p>
    </div>

    <form action="{{ route('developer.apps.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        
        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Basic Information</h3>
            
            <div class="grid-2">

                <div class="form-group">
                    <label class="form-label">App Name *</label>
                    <input type="text" name="app_name" class="form-control" placeholder="e.g. Finance Pro" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Package Name *</label>
                    <input type="text" name="package_name" class="form-control" placeholder="e.g. com.company.finance" required>
                </div>
            </div>

            <div class="grid-2">

                <div class="form-group">
                    <label class="form-label">Developer Name *</label>
                    <input type="text" name="developer_name" class="form-control" value="{{ auth()->user()->name }}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Category *</label>
                    <select name="category_id" class="form-control" required>
                        <option value="">Select Category</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Short Description</label>
                <input type="text" name="short_description" class="form-control" placeholder="One-line summary of the app">
            </div>

            <div class="form-group">
                <label class="form-label">Full Description *</label>
                <textarea name="description" class="form-control" rows="6" placeholder="Detailed description of features and usage..." required></textarea>
            </div>
        </div>

        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Media & Assets</h3>
            
            <div class="grid-2">

                <div class="form-group">
                    <label class="form-label">App Icon (PNG/JPG, 1:1) *</label>
                    <input type="file" name="icon" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Feature Banner (PNG/JPG, 16:9)</label>
                    <input type="file" name="banner" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Screenshots (Select multiple)</label>
                <input type="file" name="screenshots[]" class="form-control" multiple>
                <p class="text-muted" style="font-size: 0.75rem; margin-top: 0.5rem;">Upload up to 8 screenshots of your application.</p>
            </div>
        </div>

        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Additional Details</h3>
            
            <div class="grid-2">

                <div class="form-group">
                    <label class="form-label">Support Email</label>
                    <input type="email" name="support_email" class="form-control" placeholder="support@company.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Tags (comma separated)</label>
                    <input type="text" name="tags" class="form-control" placeholder="finance, tools, internal">
                </div>
            </div>

            <div class="grid-2">

                <div class="form-group">
                    <label class="form-label">Demo Username</label>
                    <input type="text" name="demo_username" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Demo Password</label>
                    <input type="text" name="demo_password" class="form-control">
                </div>
            </div>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-bottom: 4rem;">
            <a href="{{ route('developer.dashboard') }}" class="btn" style="border: 1px solid var(--border);">Cancel</a>
            <button type="submit" class="btn btn-primary" style="padding: 0.8rem 2.5rem;">Create Application</button>
        </div>
    </form>
</div>
@endsection
