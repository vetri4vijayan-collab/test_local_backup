@extends('layouts.app')

@section('content')
<div style="max-width: 800px; margin: 0 auto;">
    <div style="margin-bottom: 3rem;">
        <a href="{{ route('developer.apps') }}" style="color: var(--text-muted); text-decoration: none; font-size: 0.9rem; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
            ← Back to Applications
        </a>
        <h1 style="font-weight: 800; margin: 0;">Edit Application</h1>
        <p class="text-muted">Update your application details and assets.</p>
    </div>

    <form action="{{ route('developer.apps.update', $app->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        
        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Basic Information</h3>
            
            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">App Name *</label>
                    <input type="text" name="app_name" class="form-control" value="{{ old('app_name', $app->app_name) }}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Package Name *</label>
                    <input type="text" name="package_name" class="form-control" value="{{ old('package_name', $app->package_name) }}" required>
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">Developer Name *</label>
                    <input type="text" name="developer_name" class="form-control" value="{{ old('developer_name', $app->developer_name) }}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Category *</label>
                    <select name="category_id" class="form-control" required>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ $app->category_id == $category->id ? 'selected' : '' }}>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Short Description</label>
                <input type="text" name="short_description" class="form-control" value="{{ old('short_description', $app->short_description) }}">
            </div>

            <div class="form-group">
                <label class="form-label">Full Description *</label>
                <textarea name="description" class="form-control" rows="6" required>{{ old('description', $app->description) }}</textarea>
            </div>
        </div>

        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Media & Assets</h3>
            
            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">App Icon (Leave blank to keep current)</label>
                    <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 0.5rem;">
                        <img src="{{ $app->icon_url }}" style="width: 40px; height: 40px; border-radius: 8px;">
                        <span class="text-muted" style="font-size: 0.8rem;">Current Icon</span>
                    </div>
                    <input type="file" name="icon" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Feature Banner (Optional)</label>
                    @if($app->banner_path)
                        <div style="margin-bottom: 0.5rem;">
                            <img src="{{ $app->banner_url }}" style="width: 100%; height: 60px; object-fit: cover; border-radius: 8px;">
                        </div>
                    @endif
                    <input type="file" name="banner" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Screenshots</label>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
                    @foreach($app->screenshots as $screenshot)
                        <div style="position: relative; aspect-ratio: 9/16; border-radius: 8px; overflow: hidden; border: 1px solid var(--border);">
                            <img src="{{ $screenshot->url }}" style="width: 100%; height: 100%; object-fit: cover;">
                            <div style="position: absolute; top: 5px; right: 5px;">
                                <input type="checkbox" name="delete_screenshots[]" value="{{ $screenshot->id }}" id="del_ss_{{ $screenshot->id }}" style="display:none;">
                                <label for="del_ss_{{ $screenshot->id }}" style="background: rgba(239, 68, 68, 0.9); color: white; width: 24px; height: 24px; border-radius: 50%; cursor: pointer; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; transition: all 0.2s;" onclick="this.innerHTML = this.parentElement.querySelector('input').checked ? '×' : '🗑️'; this.style.background = this.parentElement.querySelector('input').checked ? 'rgba(239, 68, 68, 0.9)' : '#ef4444';">
                                    ×
                                </label>
                            </div>
                        </div>

                    @endforeach
                </div>
                <input type="file" name="screenshots[]" class="form-control" multiple>
                <p class="text-muted" style="font-size: 0.75rem; margin-top: 0.5rem;">Upload additional screenshots (up to 8 total).</p>
            </div>
        </div>

        <div class="card" style="margin-bottom: 2rem;">
            <h3 style="margin-top: 0; margin-bottom: 1.5rem; font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Additional Details</h3>
            
            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">Support Email</label>
                    <input type="email" name="support_email" class="form-control" value="{{ old('support_email', $app->support_email) }}">
                </div>
                <div class="form-group">
                    <label class="form-label">Tags (comma separated)</label>
                    <input type="text" name="tags" class="form-control" value="{{ old('tags', is_array($app->tags) ? implode(', ', $app->tags) : $app->tags) }}">
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">Demo Username</label>
                    <input type="text" name="demo_username" class="form-control" value="{{ old('demo_username', $app->demo_login['username'] ?? '') }}">
                </div>
                <div class="form-group">
                    <label class="form-label">Demo Password</label>
                    <input type="text" name="demo_password" class="form-control" value="{{ old('demo_password', $app->demo_login['password'] ?? '') }}">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Publishing Status</label>
                <select name="publish_status" class="form-control">
                    <option value="draft" {{ $app->publish_status == 'draft' ? 'selected' : '' }}>Draft</option>
                    <option value="review" {{ $app->publish_status == 'review' ? 'selected' : '' }}>In Review</option>
                    <option value="published" {{ $app->publish_status == 'published' ? 'selected' : '' }}>Published</option>
                </select>
            </div>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1rem;">
            <a href="{{ route('developer.apps') }}" class="btn" style="border: 1px solid var(--border);">Cancel</a>
            <button type="submit" class="btn btn-primary" style="padding: 0.8rem 2.5rem;">Update Application</button>
        </div>
    </form>

    <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border); margin-bottom: 4rem;">
        <form action="{{ route('developer.apps.delete', $app->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this app and all its versions?');">
            @csrf
            @method('DELETE')
            <button type="submit" style="color: var(--danger); background: none; border: none; font-weight: 600; cursor: pointer; padding: 0;">
                Delete Application
            </button>
        </form>
    </div>
</div>
@endsection
