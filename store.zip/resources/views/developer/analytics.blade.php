@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <a href="{{ route('developer.dashboard') }}" style="color: var(--text-muted); text-decoration: none; font-size: 0.9rem; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
        ← Back to Dashboard
    </a>
    <div style="display: flex; gap: 2rem; align-items: center;">
        <img src="{{ $app->icon_url }}" style="width: 64px; height: 64px; border-radius: 12px;">
        <div>
            <h1 style="font-weight: 800; margin: 0;">{{ $app->app_name }} Analytics</h1>
            <p class="text-muted">Performance tracking and download insights</p>
        </div>
    </div>
</div>

<div class="grid-3" style="margin-bottom: 3rem;">
    <div class="card" style="border-bottom: 4px solid var(--primary);">
        <div class="text-muted" style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700; margin-bottom: 0.5rem;">Total Installs</div>
        <div style="font-size: 1.5rem; font-weight: 800;">{{ number_format($app->total_downloads) }}</div>
    </div>
    <div class="card" style="border-bottom: 4px solid var(--success);">
        <div class="text-muted" style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700; margin-bottom: 0.5rem;">Latest Version</div>
        <div style="font-size: 1.5rem; font-weight: 800;">{{ $app->latestVersion->version_name ?? 'N/A' }}</div>
    </div>
    <div class="card" style="border-bottom: 4px solid var(--accent);">
        <div class="text-muted" style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700; margin-bottom: 0.5rem;">Avg daily</div>
        <div style="font-size: 1.5rem; font-weight: 800;">{{ number_format($downloads->avg('count') ?? 0, 1) }}</div>
    </div>
</div>

<div class="grid-dashboard">
    <section>
        <h3 style="margin-bottom: 1.5rem;">Install Trends (Last 30 Days)</h3>
        <div class="card" style="height: 400px; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <div style="position: absolute; bottom: 0; left: 0; width: 100%; height: 100%; padding: 2rem; display: flex; align-items: flex-end; gap: 0.5rem;">
                @foreach($downloads as $d)
                    <div style="flex-grow: 1; background: var(--primary); opacity: 0.6; height: {{ ($d->count / ($downloads->max('count') ?: 1)) * 100 }}%; border-radius: 4px 4px 0 0;" title="{{ $d->date }}: {{ $d->count }}"></div>
                @endforeach
            </div>
            @if($downloads->isEmpty())
                <p class="text-muted">No download data available yet.</p>
            @endif
        </div>
    </section>

    <aside>
        <h3 style="margin-bottom: 1.5rem;">Version Breakdown</h3>
        <div class="card">
            <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                @foreach($versionBreakdown as $vb)
                    <div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 0.5rem;">
                            <span style="font-weight: 700;">v{{ $vb->version->version_name ?? 'Unknown' }}</span>
                            <span class="text-muted">{{ $vb->count }} installs</span>
                        </div>
                        <div style="height: 6px; background: var(--subsurface); border-radius: 3px; overflow: hidden;">
                            <div style="width: {{ ($vb->count / ($app->total_downloads ?: 1)) * 100 }}%; height: 100%; background: var(--primary);"></div>
                        </div>
                    </div>
                @endforeach
                @if($versionBreakdown->isEmpty())
                    <p class="text-muted" style="text-align: center; font-size: 0.9rem;">No version data yet.</p>
                @endif
            </div>
        </div>
    </aside>
</div>
@endsection
