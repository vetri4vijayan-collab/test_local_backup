@extends('layouts.app')

@section('content')
<style>
    @media (max-width: 768px) {
        .login-split { flex-direction: column !important; }
        .login-branding { display: none !important; }
        .login-form-container { padding: 2rem !important; min-height: 100vh !important; }
    }
</style>

<div class="login-split" style="display: flex; min-height: 100vh; background: #fff; width: 100vw; margin: 0; padding: 0; position: absolute; top: 0; left: 0; z-index: 1000;">
    {{-- Left Side: Branding --}}
    <div class="login-branding" style="flex: 1.2; background: linear-gradient(135deg, #f39c12 0%, #c0392b 100%); display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 4rem; color: white; text-align: center; position: relative; overflow: hidden;">

        <div style="position: absolute; top: -10%; right: -10%; width: 300px; height: 300px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
        <div style="position: absolute; bottom: -5%; left: -5%; width: 200px; height: 200px; background: rgba(255,255,255,0.05); border-radius: 50%;"></div>
        
        <img src="/images/logo.png" alt="Elysium Groups" style="height: 80px; width: auto; margin-bottom: 2rem; z-index: 1;">
        <h1 style="font-size: 3rem; font-weight: 800; margin-bottom: 1rem; letter-spacing: -1.5px; z-index: 1;">Elysium App Store</h1>
        <p style="font-size: 1.2rem; opacity: 0.9; max-width: 340px; line-height: 1.6; z-index: 1; font-weight: 500;">Authorized internal application access for employees.</p>
    </div>

    {{-- Right Side: Form --}}
    <div class="login-form-container" style="flex: 1; display: flex; justify-content: center; align-items: center; padding: 4rem; background: #fff;">
        <div style="width: 100%; max-width: 350px;">
            <div style="margin-bottom: 2.5rem;">
                <img src="/images/logo.png" alt="Elysium Groups" style="height: 45px; width: auto; margin-bottom: 1.5rem;">
                <h2 style="font-size: 2rem; font-weight: 800; color: var(--text-main); margin-bottom: 0.5rem; letter-spacing: -0.5px;">Employee Login</h2>
                <p class="text-muted" style="font-weight: 500;">Sign in with your corporate ID</p>
            </div>

            <form action="{{ route('login.post') }}" method="POST">
                @csrf
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; font-size: 0.75rem; font-weight: 800; color: var(--text-muted); margin-bottom: 0.6rem; text-transform: uppercase; letter-spacing: 1px;">Corporate Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email') }}" required autofocus placeholder="name@company.com" style="padding: 0.85rem 1.25rem; border-radius: 12px; border-color: #eee; background: #fcfcfd;">
                </div>
                
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; font-size: 0.75rem; font-weight: 800; color: var(--text-muted); margin-bottom: 0.6rem; text-transform: uppercase; letter-spacing: 1px;">Secure Password</label>
                    <input type="password" name="password" class="form-control" required placeholder="••••••••" style="padding: 0.85rem 1.25rem; border-radius: 12px; border-color: #eee; background: #fcfcfd;">
                </div>

                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 2rem;">
                    <input type="checkbox" name="remember" id="remember" style="width: 18px; height: 18px; accent-color: var(--primary);">
                    <label for="remember" style="font-size: 0.9rem; cursor: pointer; font-weight: 600; color: var(--text-muted);">Stay logged in</label>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 1rem; border-radius: 14px; font-weight: 800; font-size: 1.1rem; box-shadow: 0 10px 30px rgba(115, 103, 240, 0.3);">
                    Access Apps
                </button>
            </form>

            <div style="margin-top: 3rem; text-align: center;">
                <p style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600; opacity: 0.7;">&copy; {{ date('Y') }} Elysium App Store • Secure Access</p>
            </div>
        </div>
    </div>
</div>


@endsection
