@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: end;">
        <div>
            <h1 style="font-weight: 800; margin: 0;">User Management</h1>
            <p class="text-muted">Manage platform administrators and application developers</p>
        </div>
        <button onclick="document.getElementById('addUserModal').style.display='flex'" class="btn btn-primary">
            + Add User
        </button>
    </div>
</div>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse; text-align: left;">
        <thead>
            <tr>
                <th style="padding: 1rem 1.5rem;">User</th>
                <th style="padding: 1rem 1.5rem;">Role</th>
                <th style="padding: 1rem 1.5rem;">Company</th>
                <th style="padding: 1rem 1.5rem;">Apps</th>
                <th style="padding: 1rem 1.5rem;">Status</th>
                <th style="padding: 1rem 1.5rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
                <tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem; align-items: center;">
                            <img src="https://ui-avatars.com/api/?name={{ urlencode($user->name) }}&background=random" style="width: 32px; height: 32px; border-radius: 50%;">
                            <div>
                                <div style="font-weight: 700;">{{ $user->name }}</div>
                                <div class="text-muted" style="font-size: 0.75rem;">{{ $user->email }}</div>
                            </div>
                        </div>
                    </td>
                    <td style="padding: 1rem 1.5rem;">
                        <span class="badge {{ $user->role == 'admin' ? 'badge-info' : ($user->role == 'developer' ? 'badge-success' : 'badge-muted') }}">
                            {{ $user->role }}
                        </span>
                    </td>
                    <td style="padding: 1rem 1.5rem;">{{ $user->company ?? '-' }}</td>
                    <td style="padding: 1rem 1.5rem;">{{ $user->apps_count }}</td>
                    <td style="padding: 1rem 1.5rem;">
                        <span class="badge {{ $user->is_active ? 'badge-success' : 'badge-danger' }}">
                            {{ $user->is_active ? 'Active' : 'Deactivated' }}
                        </span>
                    </td>
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem;">
                            <form action="{{ route('admin.users.toggle', $user->id) }}" method="POST">
                                @csrf
                                <button type="submit" style="background: none; border: none; color: var(--primary); cursor: pointer; font-weight: 600;">
                                    {{ $user->is_active ? 'Deactivate' : 'Activate' }}
                                </button>
                            </form>
                            @if($user->id !== auth()->id())
                                <form action="{{ route('admin.users.delete', $user->id) }}" method="POST" onsubmit="return confirm('Delete user account?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" style="background: none; border: none; color: var(--danger); cursor: pointer;">Delete</button>
                                </form>
                            @endif
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div style="padding: 1.5rem;">
        {{ $users->links() }}
    </div>
</div>

<!-- Add User Modal -->
<div id="addUserModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
    <div class="card" style="width: 450px; padding: 2rem;">
        <h3 style="margin-top: 0;">Add New User</h3>
        <form action="{{ route('admin.users.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-control" required>
                        <option value="user">User</option>
                        <option value="developer">Developer</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1rem;">
                <button type="button" onclick="document.getElementById('addUserModal').style.display='none'" class="btn">Cancel</button>
                <button type="submit" class="btn btn-primary">Create User</button>
            </div>
        </form>
    </div>
</div>
@endsection
