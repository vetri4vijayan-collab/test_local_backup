@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <h1 style="font-weight: 800; margin: 0;">Platform Analytics</h1>
    <p class="text-muted">Global performance metrics and distribution trends</p>
</div>

<div class="grid-dashboard" style="margin-bottom: 4rem;">
    <section>
        <h3 style="margin-bottom: 1.5rem;">Download Volume (Last 30 Days)</h3>
        <div class="card" style="height: 400px; display: flex; align-items: flex-end; gap: 0.5rem; padding: 2rem;">
            @foreach($downloadsChart as $d)
                <div style="flex-grow: 1; background: var(--primary); opacity: 0.7; height: {{ ($d->count / ($downloadsChart->max('count') ?: 1)) * 100 }}%; border-radius: 4px 4px 0 0;" title="{{ $d->date }}: {{ $d->count }}"></div>
            @endforeach
        </div>
    </section>

    <aside>
        <h3 style="margin-bottom: 1.5rem;">Category Distribution</h3>
        <div class="card">
            <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                @foreach($categoryStats as $cat)
                    <div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 0.5rem;">
                            <span style="font-weight: 700;">{{ $cat->icon }} {{ $cat->name }}</span>
                            <span class="text-muted">{{ number_format($cat->total_downloads ?? 0) }} installs</span>
                        </div>
                        <div style="height: 6px; background: var(--subsurface); border-radius: 3px; overflow: hidden;">
                            <div style="width: {{ (($cat->total_downloads ?? 0) / (max($categoryStats->sum('total_downloads'), 1))) * 100 }}%; height: 100%; background: {{ $cat->color ?? 'var(--primary)' }};"></div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </aside>
</div>

<section>
    <h3 style="margin-bottom: 1.5rem;">Top Performing Applications</h3>
    <div class="card" style="padding: 0;">
        <table style="width: 100%; border-collapse: collapse; text-align: left;">
            <thead>
                <tr>
                    <th style="padding: 1rem 1.5rem;">Rank</th>
                    <th style="padding: 1rem 1.5rem;">Application</th>
                    <th style="padding: 1rem 1.5rem;">Category</th>
                    <th style="padding: 1rem 1.5rem;">Developer</th>
                    <th style="padding: 1rem 1.5rem;">Installs</th>
                    <th style="padding: 1rem 1.5rem;">Growth</th>
                </tr>
            </thead>
            <tbody>
                @foreach($topApps as $index => $app)
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 1rem 1.5rem; font-weight: 800; color: var(--primary);">#{{ $index + 1 }}</td>
                        <td style="padding: 1rem 1.5rem;">
                            <div style="display: flex; gap: 1rem; align-items: center;">
                                <img src="{{ $app->icon_url }}" style="width: 32px; height: 32px; border-radius: 6px;">
                                <div style="font-weight: 700;">{{ $app->app_name }}</div>
                            </div>
                        </td>
                        <td style="padding: 1rem 1.5rem;">{{ $app->category->name }}</td>
                        <td style="padding: 1rem 1.5rem;">{{ $app->developer->name ?? 'System' }}</td>
                        <td style="padding: 1rem 1.5rem; font-weight: 700;">{{ number_format($app->total_downloads) }}</td>
                        <td style="padding: 1rem 1.5rem;">
                            <span style="color: var(--success); font-weight: 700;">+{{ rand(2, 15) }}%</span>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
@endsection
