@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <h1 style="font-weight: 800; margin: 0;">Application Catalog</h1>
    <p class="text-muted">Review and manage all internal applications</p>
</div>

<div class="card" style="margin-bottom: 2rem;">
    <form action="{{ route('admin.apps') }}" method="GET" style="display: flex; gap: 1rem; align-items: end;">
        <div style="flex-grow: 1;">
            <label class="form-label">Search Apps</label>
            <input type="text" name="search" class="form-control" value="{{ request('search') }}" placeholder="Name or package...">
        </div>
        <div>
            <label class="form-label">Status</label>
            <select name="status" class="form-control" style="width: 150px;">
                <option value="">All Status</option>
                <option value="published" {{ request('status') == 'published' ? 'selected' : '' }}>Published</option>
                <option value="review" {{ request('status') == 'review' ? 'selected' : '' }}>Pending</option>
                <option value="draft" {{ request('status') == 'draft' ? 'selected' : '' }}>Draft</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="{{ route('admin.apps') }}" class="btn">Clear</a>
    </form>
</div>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse; text-align: left;">
        <thead>
            <tr style="border-bottom: 1px solid var(--border); background: #f8fafc;">
                <th style="padding: 1rem 1.5rem;">App</th>
                <th style="padding: 1rem 1.5rem;">Developer</th>
                <th style="padding: 1rem 1.5rem;">Category</th>
                <th style="padding: 1rem 1.5rem;">Status</th>
                <th style="padding: 1rem 1.5rem;">Installs</th>
                <th style="padding: 1rem 1.5rem;">Featured</th>
                <th style="padding: 1rem 1.5rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($apps as $app)
                <tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem; align-items: center;">
                            <img src="{{ $app->icon_url ?? 'https://ui-avatars.com/api/?name='.urlencode($app->app_name) }}" style="width: 32px; height: 32px; border-radius: 6px;">
                            <div>
                                <div style="font-weight: 700;">{{ $app->app_name }}</div>
                                <div class="text-muted" style="font-size: 0.75rem;">{{ $app->package_name }}</div>
                            </div>
                        </div>
                    </td>
                    <td style="padding: 1rem 1.5rem;">{{ $app->developer->name ?? 'System' }}</td>
                    <td style="padding: 1rem 1.5rem;">{{ $app->category->name }}</td>
                    <td style="padding: 1rem 1.5rem;">
                         <span style="font-size: 0.7rem; font-weight: 700; padding: 0.2rem 0.5rem; border-radius: 4px; {{ $app->publish_status == 'published' ? 'background: #dcfce7; color: #166534;' : ($app->publish_status == 'review' ? 'background: #fef9c3; color: #854d0e;' : 'background: #f1f5f9; color: #64748b;') }}">
                            {{ strtoupper($app->publish_status) }}
                        </span>
                    </td>
                    <td style="padding: 1rem 1.5rem; font-weight: 700;">{{ number_format($app->total_downloads) }}</td>
                    <td style="padding: 1rem 1.5rem;">
                        <form action="{{ route('admin.apps.featured', $app->id) }}" method="POST">
                            @csrf
                            <button type="submit" style="background: none; border: none; cursor: pointer; font-size: 1.25rem;">
                                {{ $app->is_featured ? '⭐' : '☆' }}
                            </button>
                        </form>
                    </td>
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem; align-items: center;">
                            @if($app->publish_status == 'review')
                                <form action="{{ route('admin.apps.approve', $app->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" style="color: var(--success); background: none; border: none; font-weight: 700; cursor: pointer;">Approve</button>
                                </form>
                            @endif
                            <form action="{{ route('admin.apps.delete', $app->id) }}" method="POST" onsubmit="return confirm('Delete app?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" style="color: var(--danger); background: none; border: none; cursor: pointer;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div style="padding: 1.5rem;">
        {{ $apps->links() }}
    </div>
</div>
@endsection
