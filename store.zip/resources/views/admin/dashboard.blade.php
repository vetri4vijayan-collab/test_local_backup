@extends('layouts.app')

@section('content')
<div style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center;">
    <div>
        <h1 style="font-weight: 800; margin: 0; font-size: 1.75rem;">Platform Overview 🛡️</h1>
        <p class="text-muted" style="margin: 0;">Managing Elysium Enterprise Hub</p>
    </div>
</div>

<div class="bento-grid">
    <div class="card card-stat primary">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Active Users</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ \App\Models\User::count() }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">TOTAL ACCOUNTS</div>
    </div>
    <div class="card card-stat success">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Total Applications</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ $pendingApps->count() + 12 }}</div> {{-- Mock + actual --}}
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">PLATFORM CATALOG</div>
    </div>
    <div class="card card-stat warning">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Pending Approval</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ $pendingApps->count() }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">ACTION REQUIRED</div>
    </div>
    <div class="card card-stat info">
        <div>
            <div style="font-size: 0.85rem; opacity: 0.9; font-weight: 600;">Daily Downloads</div>
            <div style="font-size: 2rem; font-weight: 800;">{{ number_format($totalDownloads ?? 0) }}</div>
        </div>
        <div style="background: rgba(255,255,255,0.2); padding: 0.4rem; border-radius: 8px; font-size: 0.7rem; font-weight: 700;">UP 12% TODAY</div>
    </div>
</div>

<div class="grid-dashboard">
    <div class="card" style="padding: 0;">
        <div style="padding: 1.5rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 1.1rem; font-weight: 800;">Apps Awaiting Review</h3>
        </div>
        @if($pendingApps->isEmpty())
            <div style="padding: 3rem; text-align: center; color: var(--text-muted);">
                <div style="font-size: 2rem; margin-bottom: 1rem;">✨</div>
                <p style="font-weight: 600;">All clear! No pending reviews.</p>
            </div>
        @else
            <div class="table-responsive">
                <table class="table-modern">
                    <thead>
                        <tr>
                            <th>APPLICATION</th>
                            <th>DEVELOPER</th>
                            <th>SUBMITTED</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($pendingApps as $app)
                            <tr>
                                <td>
                                    <div style="display: flex; gap: 0.75rem; align-items: center;">
                                        <img src="{{ $app->icon_url }}" style="width: 36px; height: 36px; border-radius: 10px;">
                                        <div style="font-weight: 700;">{{ $app->app_name }}</div>
                                    </div>
                                </td>
                                <td style="font-weight: 600;">{{ $app->developer->name ?? 'Unknown' }}</td>
                                <td class="text-muted">{{ $app->created_at->diffForHumans() }}</td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <form action="{{ route('admin.apps.approve', $app->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="btn" style="background: #dff7e9; color: #28c76f; padding: 0.3rem 0.75rem; font-size: 0.75rem;">Approve</button>
                                        </form>
                                        <form action="{{ route('admin.apps.reject', $app->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="btn" style="background: #fce5e6; color: #ea5455; padding: 0.3rem 0.75rem; font-size: 0.75rem;">Reject</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>

    <div class="card">
        <h3 style="margin: 0 0 1.5rem; font-size: 1.1rem; font-weight: 800;">Platform Health</h3>
        <div style="padding: 1.5rem; background: var(--primary-soft); border-radius: 16px; margin-bottom: 1rem;">
            <div style="font-size: 0.8rem; font-weight: 700; color: var(--primary); margin-bottom: 0.25rem;">STORAGE USAGE</div>
            <div style="font-size: 1.25rem; font-weight: 800;">4.2 GB / 10 GB</div>
            <div style="height: 6px; background: white; border-radius: 3px; margin-top: 0.75rem; overflow: hidden;">
                <div style="width: 42%; height: 100%; background: var(--primary);"></div>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
            <div style="padding: 1rem; background: var(--subsurface); border-radius: 12px; text-align: center;">
                <div style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted);">UPTIME</div>
                <div style="font-size: 1rem; font-weight: 800; color: var(--success);">99.9%</div>
            </div>
            <div style="padding: 1rem; background: var(--subsurface); border-radius: 12px; text-align: center;">
                <div style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted);">API SPEED</div>
                <div style="font-size: 1rem; font-weight: 800; color: var(--primary);">124ms</div>
            </div>
        </div>
    </div>
</div>
@endsection
