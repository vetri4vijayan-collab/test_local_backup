@extends('layouts.app')

@section('content')
<div style="margin-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: end;">
        <div>
            <h1 style="font-weight: 800; margin: 0;">Categories</h1>
            <p class="text-muted">Manage application categories and store organization</p>
        </div>
        <button onclick="document.getElementById('addCategoryModal').style.display='flex'" class="btn btn-primary">
            + Add Category
        </button>
    </div>
</div>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse; text-align: left;">
        <thead>
            <tr style="border-bottom: 1px solid var(--border); background: #f8fafc;">
                <th style="padding: 1rem 1.5rem; width: 80px;">Icon</th>
                <th style="padding: 1rem 1.5rem;">Name</th>
                <th style="padding: 1rem 1.5rem;">Slug</th>
                <th style="padding: 1rem 1.5rem;">Apps</th>
                <th style="padding: 1rem 1.5rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($categories as $category)
                <tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 1rem 1.5rem; font-size: 1.5rem; text-align: center;">
                        <div style="width: 40px; height: 40px; background: {{ $category->color }}15; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                            {{ $category->icon }}
                        </div>
                    </td>
                    <td style="padding: 1rem 1.5rem; font-weight: 700;">{{ $category->name }}</td>
                    <td style="padding: 1rem 1.5rem;" class="text-muted">{{ $category->slug }}</td>
                    <td style="padding: 1rem 1.5rem;">{{ $category->apps_count }}</td>
                    <td style="padding: 1rem 1.5rem;">
                        <div style="display: flex; gap: 1rem;">
                            <form action="{{ route('admin.categories.delete', $category->id) }}" method="POST" onsubmit="return confirm('Delete category? This will affect all apps in it.');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" style="background: none; border: none; color: var(--danger); cursor: pointer;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

<!-- Simple Modal (Hidden by default) -->
<div id="addCategoryModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
    <div class="card" style="width: 400px; padding: 2rem;">
        <h3 style="margin-top: 0;">Add New Category</h3>
        <form action="{{ route('admin.categories.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label class="form-label">Category Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Emoji Icon</label>
                    <input type="text" name="icon" class="form-control" placeholder="📦" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Brand Color</label>
                    <input type="color" name="color" class="form-control" value="#6366f1" style="height: 45px;">
                </div>
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1rem;">
                <button type="button" onclick="document.getElementById('addCategoryModal').style.display='none'" class="btn">Cancel</button>
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
        </form>
    </div>
</div>
@endsection
