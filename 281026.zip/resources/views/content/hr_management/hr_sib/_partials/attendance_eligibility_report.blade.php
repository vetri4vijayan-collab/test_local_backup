@php
    $isEarlyBird = $reportType === 'early_bird';
@endphp

<style>
    .attendance-report {
        --attendance-primary: #ab2b22;
        --attendance-primary-dark: #851e18;
        --attendance-border: #e8edf3;
        --attendance-muted: #64748b;
        color: #263244;
    }
    .attendance-report .report-hero {
        position: relative;
        overflow: hidden;
        border: 1px solid #f0d9d5;
        border-radius: 16px;
        padding: 22px 24px;
        background: linear-gradient(115deg, #fffaf7 0%, #fff 57%, #fff3e9 100%);
        box-shadow: 0 7px 22px rgba(67, 33, 29, .045);
    }
    .attendance-report .report-hero::after {
        content: "";
        position: absolute;
        top: -50px;
        right: -35px;
        width: 190px;
        height: 190px;
        border-radius: 50%;
        background: rgba(171, 43, 34, .045);
        pointer-events: none;
    }
    .attendance-report .report-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 48px;
        height: 48px;
        flex: 0 0 48px;
        border-radius: 14px;
        background: var(--attendance-primary);
        color: #fff;
        font-size: 23px;
        box-shadow: 0 7px 16px rgba(171, 43, 34, .18);
    }
    .attendance-report .report-title {
        margin: 0;
        color: #222b3a;
        font-size: 1.35rem;
        font-weight: 800;
        letter-spacing: -.02em;
    }
    .attendance-report .report-subtitle {
        color: var(--attendance-muted);
        margin-top: 5px;
        margin-bottom: 0;
        font-size: .88rem;
        max-width: 820px;
    }
    .attendance-report .filter-card,
    .attendance-report .table-card {
        border: 1px solid var(--attendance-border);
        border-radius: 14px;
        background: #fff;
        box-shadow: 0 5px 20px rgba(15, 23, 42, .035);
    }
    .attendance-report .filter-card { padding: 16px; }
    .attendance-report .filter-card label {
        margin-bottom: 6px;
        font-size: .75rem;
        font-weight: 700;
        color: #475569;
        letter-spacing: .02em;
    }
    .attendance-report .form-control,
    .attendance-report .form-select {
        min-height: 40px;
        border-color: #dfe5ec;
        border-radius: 9px;
        font-size: .84rem;
        box-shadow: none;
    }
    .attendance-report .form-control:focus,
    .attendance-report .form-select:focus {
        border-color: #d58b84;
        box-shadow: 0 0 0 3px rgba(171, 43, 34, .08);
    }
    .attendance-report .select2-container { width: 100% !important; }
    .attendance-report .select2-container--default .select2-selection--single {
        min-height: 40px;
        border: 1px solid #dfe5ec;
        border-radius: 9px;
        background: #fff;
    }
    .attendance-report .select2-container--default .select2-selection--single .select2-selection__rendered {
        line-height: 38px;
        padding-left: 12px;
        color: #364152;
        font-size: .84rem;
    }
    .attendance-report .select2-container--default .select2-selection--single .select2-selection__arrow {
        min-height: 38px;
        right: 5px;
    }
    .attendance-report .select2-container--default.select2-container--focus .select2-selection--single {
        border-color: #d58b84;
        box-shadow: 0 0 0 3px rgba(171, 43, 34, .08);
    }
    .attendance-report .btn-report-primary {
        background: var(--attendance-primary);
        border-color: var(--attendance-primary);
        color: #fff;
        border-radius: 9px;
        font-weight: 700;
    }
    .attendance-report .btn-report-primary:hover {
        background: var(--attendance-primary-dark);
        border-color: var(--attendance-primary-dark);
        color: #fff;
    }
    .attendance-report .btn-report-outline {
        color: var(--attendance-primary);
        border: 1px solid #e6c1bc;
        background: #fff;
        border-radius: 9px;
        font-weight: 700;
    }
    .attendance-report .btn-report-outline:hover { background: #fff5f3; }
    .attendance-report .metric-card {
        height: 100%;
        position: relative;
        overflow: hidden;
        background: #fff;
        border: 1px solid var(--attendance-border);
        border-radius: 13px;
        padding: 15px 16px;
        box-shadow: 0 4px 15px rgba(15, 23, 42, .025);
    }
    /* .attendance-report .metric-card::after {
        content: "";
        position: absolute;
        right: -17px;
        bottom: -23px;
        width: 76px;
        height: 76px;
        border-radius: 50%;
        background: var(--metric-tint, #f8fafc);
        opacity: .78;
    } */
    .attendance-report .metric-label {
        position: relative;
        z-index: 1;
        color: #64748b;
        font-size: .75rem;
        font-weight: 700;
    }
    .attendance-report .metric-value {
        position: relative;
        z-index: 1;
        color: #1e293b;
        font-size: 1.65rem;
        font-weight: 800;
        line-height: 1.25;
        margin-top: 6px;
        font-variant-numeric: tabular-nums;
    }
    .attendance-report .metric-hint {
        position: relative;
        z-index: 1;
        color: #94a3b8;
        font-size: .69rem;
        margin-top: 3px;
    }
    .attendance-report .metric-success { --metric-tint: #dcfce7; }
    .attendance-report .metric-danger { --metric-tint: #fee2e2; }
    .attendance-report .metric-primary { --metric-tint: #fce7e4; }
    .attendance-report .metric-neutral { --metric-tint: #e2e8f0; }
    .attendance-report .table-card { overflow: hidden; }
    .attendance-report .table-card-header {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 16px 18px;
        border-bottom: 1px solid var(--attendance-border);
    }
    .attendance-report .table-heading {
        margin: 0;
        color: #253044;
        font-size: .98rem;
        font-weight: 800;
    }
    .attendance-report .table-help { color: #7b8797; font-size: .76rem; margin-top: 3px; }
    /* .attendance-report .table-responsive { max-height: 68vh; } */
    .attendance-report .eligibility-table { min-width: 1180px; margin-bottom: 0; }
    .attendance-report .eligibility-table thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        /* white-space: nowrap; */
        /* padding: 13px 12px; */
        /* background: #f8fafc; */
        /* border-bottom: 1px solid #e7edf3; */
        /* color: #566275; */
        font-size: .72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .035em;
    }
    .attendance-report .eligibility-table tbody td {
        vertical-align: middle;
        padding: 12px;
        border-bottom-color: #edf1f5;
        color: #364152;
        font-size: .8rem;
    }
    .attendance-report .eligibility-table tbody tr:last-child td { border-bottom: 0; }
    .attendance-report .eligibility-table tbody tr:hover td { background: #fffdfb; }
    .attendance-report .eligibility-table tbody tr.row-eligible td { background: #f1fbf4; }
    .attendance-report .eligibility-table tbody tr.row-not-eligible td { background: #fff6f4; }
    .attendance-report .eligibility-table tbody tr.row-eligible:hover td { background: #eaf8ee; }
    .attendance-report .eligibility-table tbody tr.row-not-eligible:hover td { background: #ffefeb; }
    .attendance-report .staff-cell { display: flex; align-items: center; gap: 10px; min-width: 200px; }
    .attendance-report .staff-avatar {
        display: inline-flex;
        position: relative;
        overflow: hidden;
        flex: 0 0 40px;
        height: 40px;
        width: 40px;
        border-radius: 50%;
        align-items: center;
        justify-content: center;
        background: #f9e4e0;
        color: #96271e;
        font-size: .76rem;
        font-weight: 800;
    }
    .attendance-report .staff-avatar img {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: fill;
        border-radius: inherit;
    }
    .attendance-report .staff-avatar-fallback { position: relative; z-index: 0; }
    .attendance-report .staff-name { color: #202b3b; font-size: .84rem; font-weight: 800; }
    .attendance-report .staff-code { color: #8591a2; font-size: .7rem; margin-top: 3px; }
    .attendance-report .tiny-muted { color: #8490a1; font-size: .72rem; line-height: 1.5; }
    .attendance-report .count-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 32px;
        padding: 4px 8px;
        border-radius: 7px;
        background: #f1f5f9;
        color: #344256;
        font-weight: 800;
        font-variant-numeric: tabular-nums;
    }
    .attendance-report .count-good { background: #dff7e7; color: #14743a; }
    .attendance-report .count-bad { background: #ffe4df; color: #ae3024; }
    .attendance-report .early-bird-breakdown { display: grid; gap: 5px; min-width: 112px; }
    .attendance-report .early-bird-breakdown-line { display: flex; align-items: center;  gap: 2px; }
    .attendance-report .early-bird-breakdown-label { color: #64748b; font-size: .68rem; font-weight: 700; white-space: nowrap; }
    .attendance-report .count-not-early { background: #fff3cd; color: #8a5a00; }
    .attendance-report .count-late { background: #ffe4e6; color: #be123c; }
    .attendance-report .count-no-punch { background: #eef2f7; color: #526174; }
    .attendance-report .decision-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        border-radius: 30px;
        padding: 6px 10px;
        font-size: .7rem;
        font-weight: 800;
        white-space: nowrap;
    }
    .attendance-report .decision-eligible { color: #14743a; background: #dcfce7; border: 1px solid #b7ebc8; }
    .attendance-report .decision-not-eligible { color: #a62b21; background: #ffe5df; border: 1px solid #ffc9be; }
    .attendance-report .confirmed-meta {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        margin-top: 6px;
        color: #16734a;
        font-size: .68rem;
        font-weight: 700;
    }
    .attendance-report .confirm-modal-content { border: 1px solid #e8edf3; border-radius: 16px; box-shadow: 0 24px 70px rgba(15, 23, 42, .18); }
    .attendance-report .confirm-modal-icon {
        display: inline-flex; align-items: center; justify-content: center;
        width: 54px; height: 54px; border-radius: 16px;
        color: #a52c23; background: #fff0ed; font-size: 26px;
    }
    .attendance-report .confirm-modal-icon.is-success { color: #16734a; background: #e4f8eb; }
    .attendance-report .confirm-modal-title { color: #202b3b; font-size: 1.05rem; font-weight: 800; }
    .attendance-report .confirm-modal-description { color: #6b7788; font-size: .82rem; line-height: 1.55; }
    .attendance-report .confirm-info-panel { border: 1px solid #e8edf3; border-radius: 11px; background: #f8fafc; padding: 11px 12px; text-align: left; }
    .attendance-report .confirm-info-label { color: #8190a3; font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; }
    .attendance-report .confirm-info-value { color: #273449; font-size: .84rem; font-weight: 800; margin-top: 3px; overflow-wrap: anywhere; }
    .attendance-report .confirm-count-box { border: 1px solid #e8edf3; border-radius: 10px; padding: 10px 8px; background: #fff; }
    .attendance-report .confirm-count-value { font-size: 1.15rem; font-weight: 800; line-height: 1.2; }
    .attendance-report .confirm-count-label { color: #8190a3; font-size: .68rem; margin-top: 4px; }
    .attendance-report .confirm-modal-error { color: #a62b21; background: #fff0ed; border: 1px solid #ffc9be; border-radius: 9px; padding: 9px 11px; font-size: .78rem; text-align: left; }
    /* .attendance-report .detail-button {
        border: 1px solid #d8e0e9;
        background: #fff;
        color: #475569;
        border-radius: 8px;
        padding: 6px 9px;
        font-size: .74rem;
        font-weight: 800;
    } */
    /* .attendance-report .detail-button:hover { border-color: #ca8a83; color: #9b241b; background: #fff9f7; } */
    .attendance-report .pagination-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        padding: 13px 17px;
        border-top: 1px solid var(--attendance-border);
        background: #fff;
    }
    .attendance-report .pagination { gap: 4px; margin: 0; }
    .attendance-report .pagination .page-link {
        /* border-radius: 8px !important;
        border: 1px solid #e0e6ee; */
        color: #596579;
        min-width: 33px;
        height: 33px;
        font-size: .75rem;
        font-weight: 700;
    }
    .attendance-report .pagination .active .page-link { 
        background: var(--attendance-primary); 
        border-color: var(--attendance-primary); 
        color: #fff; 
    }

    .attendance-report .pagination .disabled .page-link { 
        color: #b5bfcb; 
        background: #f8fafc; 
    }

    .attendance-report .report-loading { 
        padding: 36px 18px; 
        text-align: center; 
        color: #7b8797; 
    }

    .attendance-report .report-loading .spinner-border { 
        color: var(--attendance-primary); 
        width: 1.5rem; 
        height: 1.5rem; 
    }

    .attendance-report .error-message { 
        display: none; 
        border: 1px solid #fecaca; 
        border-radius: 10px; 
        padding: 11px 14px; 
        background: #fff1f2; 
        color: #9f1239; 
        font-size: .82rem; 
    }

    .attendance-report .report-period { 
        font-size: .78rem; 
        color: #7a5260; 
        font-weight: 700; 
    }

    .attendance-report .modal-content { 
        border: 0; 
        border-radius: 
        15px; overflow: hidden; 
    }

    .attendance-report .modal-header { 
        border-bottom: 1px solid #edf1f5; 
        background: #fffaf8; 
    }
    .attendance-report .detail-modal-title { 
        margin: 0; 
        font-size: 1rem; 
        font-weight: 800; 
        color: #253044; 
    }

    .attendance-report .confirm-mode-group { display: grid; gap: 8px; text-align: left; }
    .attendance-report .confirm-mode-option { display: flex; gap: 10px; align-items: flex-start; padding: 10px 11px; border: 1px solid #e2e8f0; border-radius: 10px; background: #fff; cursor: pointer; transition: border-color .15s ease, background .15s ease; }
    .attendance-report .confirm-mode-option:has(input:checked) { border-color: #b63a30; background: #fff7f5; box-shadow: 0 0 0 2px rgba(171,43,34,.06); }
    .attendance-report .confirm-mode-option input { margin-top: 3px; accent-color: #ab2b22; }
    .attendance-report .confirm-mode-option strong { display: block; color: #273449; font-size: .78rem; }
    .attendance-report .confirm-mode-option small { display: block; color: #718096; font-size: .7rem; line-height: 1.4; margin-top: 2px; }
    .attendance-report .report-success { display: none; border: 1px solid #b7ebc8; border-radius: 10px; padding: 11px 14px; background: #f0fdf4; color: #166534; font-size: .82rem; }
    .attendance-report .detail-profile { padding: 18px; border-bottom: 1px solid #e8edf3; background: linear-gradient(120deg, #fffaf8 0%, #ffffff 65%, #f8fafc 100%); }
    .attendance-report .detail-profile-head { display: flex; flex-wrap: wrap; align-items: center; gap: 14px; }
    .attendance-report .detail-avatar { width: 66px; height: 66px; flex: 0 0 66px; display: grid; place-items: center; position: relative; border-radius: 18px; overflow: hidden; background: #f3e3e0; border: 1px solid #ead1cd; color: #972d25; font-weight: 800; font-size: 1rem; }
    .attendance-report .detail-avatar img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
    .attendance-report .detail-avatar-initials { display: none; }
    .attendance-report .detail-avatar.show-fallback img { display: none; }
    .attendance-report .detail-avatar.show-fallback .detail-avatar-initials { display: block; }
    .attendance-report .detail-person-name { color: #1e293b; font-size: 1.05rem; font-weight: 800; margin: 0; }
    .attendance-report .detail-person-meta { color: #64748b; font-size: .76rem; margin-top: 4px; line-height: 1.5; }
    .attendance-report .detail-decision-panel { margin-left: auto; min-width: 165px; display: grid; gap: 6px; justify-items: start; }
    .attendance-report .detail-decision-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin-top: 16px; }
    .attendance-report .detail-decision-item { padding: 10px 12px; border: 1px solid #e5eaf0; border-radius: 10px; background: rgba(255,255,255,.88); min-width: 0; }
    .attendance-report .detail-decision-label { color: #8490a1; text-transform: uppercase; letter-spacing: .035em; font-size: .64rem; font-weight: 800; }
    .attendance-report .detail-decision-value { color: #263244; font-size: .78rem; font-weight: 800; margin-top: 4px; overflow-wrap: anywhere; }
    .attendance-report .detail-reason { margin-top: 12px; border: 1px solid #e5eaf0; border-left: 3px solid #c76a60; border-radius: 8px; background: #fff; padding: 10px 12px; }
    .attendance-report .detail-reason-label { color: #64748b; font-size: .67rem; font-weight: 800; text-transform: uppercase; }
    .attendance-report .detail-reason-text { color: #475569; font-size: .77rem; line-height: 1.55; margin: 4px 0 0; white-space: normal; }
    .attendance-report .detail-stat-card { display: inline-flex; flex-direction: column; gap: 3px; min-width: 112px; padding: 10px 13px; border: 1px solid #e5eaf0; border-radius: 10px; background: #fff; }
    .attendance-report .detail-stat-label { color: #8490a1; font-size: .67rem; font-weight: 700; }
    .attendance-report .detail-stat-value { color: #263244; font-size: 1.05rem; font-weight: 800; }
    .attendance-report .detail-days-table { 
        min-width: 900px; 
    }
    .attendance-report .detail-days-table th { 
        position: sticky; top: 0; z-index: 1; font-size: .68rem; text-transform: uppercase;
        white-space: nowrap;
        /* background: #f8fafc;
        color: #566275;  */
        border-bottom: 1px solid #e1e8ef;
    }
    .attendance-report .detail-days-table { 
        min-width: 1050px; 
        /* border-collapse: separate;  */
        border-spacing: 0; 
    }
    .attendance-report .detail-days-table tbody tr:nth-child(even) td { background: #fbfcfe; }
    .attendance-report .detail-days-table tbody td { border-color: #e7edf4; padding: .68rem .72rem; line-height: 1.4; transition: background-color .15s ease; }
    .attendance-report .detail-days-table tbody tr > td:first-child { border-left: 3px solid transparent; }
    .attendance-report .detail-days-table tbody tr.detail-row-early > td { background: #f0fdf4 !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-early > td:first-child { border-left-color: #22a06b; }
    .attendance-report .detail-days-table tbody tr.detail-row-late > td { background: #fff1f2 !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-late > td:first-child { border-left-color: #e11d48; }
    .attendance-report .detail-days-table tbody tr.detail-row-not-early > td { background: #fffbeb !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-not-early > td:first-child { border-left-color: #d97706; }
    .attendance-report .detail-days-table tbody tr.detail-row-present > td { background: #f0fdf4 !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-present > td:first-child { border-left-color: #22a06b; }
    .attendance-report .detail-days-table tbody tr.detail-row-permission > td { background: #eff6ff !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-permission > td:first-child { border-left-color: #3b82f6; }
    .attendance-report .detail-days-table tbody tr.detail-row-absence > td { background: #fff1f2 !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-absence > td:first-child { border-left-color: #e11d48; }
    .attendance-report .detail-days-table tbody tr.detail-row-exception > td { background: #f8fafc !important; }
    .attendance-report .detail-days-table tbody tr.detail-row-exception > td:first-child { border-left-color: #94a3b8; }
    .attendance-report .detail-days-table tbody tr:hover > td { filter: brightness(.985); }
    .attendance-report .day-result-late { color: #be123c; background: #ffe4e6; }
    .attendance-report .day-result-not-early { color: #92400e; background: #fef3c7; }
    .attendance-report .day-result-permission { color: #1d4ed8; background: #dbeafe; }
    .attendance-report .threshold-summary { display: grid; gap: 3px; min-width: 175px; }
    .attendance-report .threshold-summary span { display: block; font-size: .69rem; font-weight: 700; white-space: nowrap; }
    .attendance-report .threshold-early { color: #15803d; }
    .attendance-report .threshold-not-early { color: #a16207; }
    .attendance-report .threshold-late { color: #be123c; }
    .attendance-report .detail-status-legend { display: flex; flex-wrap: wrap; align-items: center; gap: 7px; }
    .attendance-report .detail-legend-chip { display: inline-flex; align-items: center; gap: 5px; padding: 4px 8px; border: 1px solid #e2e8f0; border-radius: 20px; color: #475569; background: #fff; font-size: .66rem; font-weight: 700; white-space: nowrap; }
    .attendance-report .detail-legend-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }
    .attendance-report .detail-days-table td { 
        font-size: .76rem; 
        vertical-align: middle; 
    }
    .attendance-report .day-result { 
        display: inline-flex; 
        border-radius: 6px; 
        padding: 4px 7px; 
        font-size: .68rem; 
        font-weight: 800; 
        white-space: nowrap; 
    }
    .attendance-report .day-result-pass { 
        color: #14743a; 
        background: #dcfce7; 
    }
    .attendance-report .day-result-fail { 
        color: #a62b21; 
        background: #ffe5df; 
    }
    .attendance-report .day-result-skip { 
        color: #64748b; 
        background: #f1f5f9; 
    }
    @media (max-width: 767.98px) {
        .attendance-report .detail-decision-grid { grid-template-columns: 1fr; }
        .attendance-report .detail-decision-panel { margin-left: 0; width: 100%; }
        .attendance-report .detail-avatar { width: 56px; height: 56px; flex-basis: 56px; }
        .attendance-report .report-hero { padding: 18px; }
        .attendance-report .report-title { font-size: 1.1rem; }
        .attendance-report .metric-value { font-size: 1.4rem; }
        .attendance-report .filter-card { padding: 12px; }
        .attendance-report .table-card-header { padding: 14px; }
    }
</style>

<div class="attendance-report container-fluid px-0">
    <div class="report-hero mb-4">
        <div class="d-flex align-items-center gap-3 position-relative" style="z-index:1;">
            <div class="report-icon"><i class="mdi {{ $isEarlyBird ? 'mdi-weather-sunset-up' : 'mdi-calendar-check-outline' }}"></i></div>
            <div class="flex-grow-1">
                <h4 class="report-title">{{ $reportTitle }}</h4>
                <!-- <p class="report-subtitle">{{ $reportDescription }}</p> -->
                <div class="report-period mt-2" id="report-period-label">Report period will appear after loading.</div>
            </div>
            <div class="d-none d-md-flex align-items-center gap-2">
                <a id="attendance-report-export" href="#" target="_blank" class="btn btn-sm btn-label-success border border-success" data-bs-toggle="tooltip" title="Export CSV"><i class="mdi mdi-file-export-outline"></i> </a>
                <div class="">
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input class="form-control" type="text" id="attendance-report-month"   value="{{ $currentMonth }}" readonly onchange="monthFilterChange()">
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <div id="attendance-report-error" class="error-message mb-3" role="alert"></div>
    <div id="attendance-report-success" class="report-success mb-3" role="status" aria-live="polite"></div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <div class="metric-card metric-neutral">
                <div class="metric-label"><i class="mdi mdi-account-multiple-outline me-1"></i> Total Staff</div>
                <div class="metric-value" id="metric-total">—</div>
                <!-- <div class="metric-hint">Staff matching the current scope and search</div> -->
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="metric-card metric-success">
                <div class="metric-label"><i class="mdi mdi-check-circle-outline me-1"></i> Eligible</div>
                <div class="metric-value" id="metric-eligible">—</div>
                <!-- <div class="metric-hint">Meets all report rules for the selected month</div> -->
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="metric-card metric-danger">
                <div class="metric-label"><i class="mdi mdi-alert-circle-outline me-1"></i> Not Eligible</div>
                <div class="metric-value" id="metric-not-eligible">—</div>
                <!-- <div class="metric-hint">Requires HR review or does not meet the criteria</div> -->
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="metric-card metric-primary">
                <div class="metric-label"><i class="mdi mdi-calendar-clock-outline me-1"></i> Workdays</div>
                <div class="metric-value" id="metric-workdays">—</div>
                <!-- <div class="metric-hint">Total scheduled employee-days in this result set</div> -->
            </div>
        </div>
    </div>

    <div class="row">
        <div class="filter-card mb-4">
            <div class="row g-3 align-items-end">
                
                <div class="col-12 col-sm-6 col-lg-3">
                    <label for="attendance-report-scope">Entity </label>
                    <select id="attendance-report-scope" class="form-select select3">
                        <option value="all">All Staff / Entities</option>
                        <option value="egc">Elysium Groups</option>
                        @foreach ($entities as $entity)
                            <option value="{{ $entity->sno }}">{{ $entity->entity_name ? $entity->entity_name : '-' }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 col-sm-6 col-lg-3">
                    <label for="attendance-report-search">Search</label>
                    <input id="attendance-report-search" type="search" class="form-control" placeholder="Name, staff ID or mobile number" autocomplete="off">
                </div>
                <div class="col-6 col-sm-3 col-lg-2">
                    <label for="attendance-report-status">Eligibility</label>
                    <select id="attendance-report-status" class="form-select select3">
                        <option value="all">All Staff</option>
                        <option value="eligible">Eligible First</option>
                        <option value="not_eligible">Not Eligible</option>
                    </select>
                </div>
                <div class="col-6 col-sm-3 col-lg-2">
                    <label for="attendance-report-per-page">Rows Per Page</label>
                    <select id="attendance-report-per-page" class="form-select select3">
                        @foreach ([10, 25, 50, 100] as $option)
                            <option value="{{ $option }}" {{ $perPage === $option ? 'selected' : '' }}>{{ $option }} rows</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-sm-3 col-lg-2">
                    <!-- <div class="tiny-muted"><i class="mdi mdi-information-outline me-1"></i> Sundays and configured holidays are excluded. Staff are checked only on days covered by the effective shift log.</div> -->
                    <div class="d-flex flex-wrap align-items-center gap-1 justify-content-end mb-2">
                        <button type="button" id="attendance-report-reset" class="btn btn-sm btn-report-outline" data-bs-toggle="tooltip" title="Reset"><i class="mdi mdi-refresh me-1"></i> </button>
                        <!-- <button type="button" id="attendance-report-apply" class="btn btn-sm btn-report-primary" data-bs-toggle="tooltip" title="Search"><i class="mdi mdi-magnify"></i></button> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="table-card">
            <div class="table-card-header">
                <div>
                    <h5 class="table-heading">Monthly Staff Eligibility Register</h5>
                    <!-- <div class="table-help" id="attendance-report-table-help">Eligible staff are listed first, followed by staff who need review.</div> -->
                </div>
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <div class="tiny-muted"><span class="me-3"><span style="display:inline-block;width:9px;height:9px;border-radius:3px;background:#c8efd3;margin-right:5px;"></span>Eligible</span><span><span style="display:inline-block;width:9px;height:9px;border-radius:3px;background:#ffd1c7;margin-right:5px;"></span>Not eligible</span></div>
                    <span id="attendance-report-selected-count" class="tiny-muted">0 selected</span>
                    <button type="button" id="attendance-report-confirm" class="btn btn-sm btn-report-primary" disabled>
                        <i class="mdi mdi-check-all me-1"></i> Confirm Selected
                    </button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table eligibility-table align-middle">
                    <thead class="sticky-top">
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="text-center" style="width:44px"><input class="form-check-input" type="checkbox" id="attendance-report-select-page" aria-label="Select all staff on this page"></th>
                            <th>Staff</th>
                            <th>Working Days</th>
                            <th>Attended</th>
                            @if ($isEarlyBird)
                                <th>Early Arrivals</th>
                                <th>Not Early / Late</th>
                            @endif
                            <th>Leave</th>
                            <th>Permission</th>
                            <th>Eligibility</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="attendance-report-body">
                        <tr><td colspan="{{ $isEarlyBird ? 10 : 8 }}" class="report-loading"><span class="spinner-border me-2" role="status" aria-hidden="true"></span> Loading monthly attendance...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination-footer">
                <div id="attendance-report-pagination-info" class="tiny-muted">Loading records…</div>
                <nav aria-label="Attendance report pagination"><ul class="pagination" id="attendance-report-pagination"></ul></nav>
            </div>
        </div>
    </div>
    
</div>

<div class="modal fade attendance-report" id="attendance-report-confirm-modal" tabindex="-1" aria-labelledby="attendance-report-confirm-title" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content confirm-modal-content">
            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <span class="confirm-modal-icon" id="attendance-report-confirm-icon">
                        <i class="mdi mdi-shield-check-outline"></i>
                    </span>
                    <h5 class="confirm-modal-title mb-2" id="attendance-report-confirm-title">Confirm monthly eligibility?</h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-3">
                
                <p class="confirm-modal-description mb-3" id="attendance-report-confirm-description">This saves the eligibility result for the selected staff and month. If a record already exists, it will be updated.</p>
                <div class="confirm-info-panel mb-3">
                    <div class="row">
                        <div class="col-4">
                            <div class="confirm-info-label">Report</div>
                            <div class="confirm-info-value" id="attendance-report-confirm-report">Master Attendance</div>
                        </div>
                        <div class="col-4">
                            <div class="confirm-info-label mt-2">Report month</div>
                            <div class="confirm-info-value" id="attendance-report-confirm-month">Oct-2026</div>
                        </div>
                        <div class="col-4">
                            <div class="confirm-info-label mt-2">Selected staff</div>
                            <div class="confirm-info-value" id="attendance-report-confirm-selected">0</div>
                        </div>
                    </div>
                    
                    
                    
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <div class="confirm-count-box h-100">
                            <div class="confirm-count-value text-success" id="attendance-report-confirm-eligible">0</div>
                            <div class="confirm-count-label">Eligible</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="confirm-count-box h-100">
                            <div class="confirm-count-value text-danger" id="attendance-report-confirm-not-eligible">0</div>
                            <div class="confirm-count-label">Not eligible</div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="confirm-info-label mb-2">Choose the HR decision to save</div>
                    <div class="confirm-mode-group" role="radiogroup" aria-label="Eligibility confirmation decision">
                        <!-- <label class="confirm-mode-option" for="attendance-report-mode-calculated">
                            <input type="radio" name="attendance-report-decision-mode" id="attendance-report-mode-calculated" value="calculated" checked>
                            <span><strong>Use system recommendation</strong><small>Save each selected employee's calculated result.</small></span>
                        </label> -->
                        <label class="confirm-mode-option" for="attendance-report-mode-eligible">
                            <input type="radio" name="attendance-report-decision-mode" id="attendance-report-mode-eligible" value="manual_eligible" checked>
                            <span><strong>Mark selected as Eligible</strong>
                            <!-- <small>HR manually approves all selected staff for this month.</small> -->
                        </span>
                        </label>
                        <label class="confirm-mode-option" for="attendance-report-mode-not-eligible">
                            <input type="radio" name="attendance-report-decision-mode" id="attendance-report-mode-not-eligible" value="manual_not_eligible">
                            <span><strong>Mark selected as Not Eligible</strong>
                            <!-- <small>HR manually declines all selected staff for this month.</small> -->
                        </span>
                        </label>
                    </div>
                </div>
                <div class="confirm-modal-error" id="attendance-report-confirm-error" role="alert" style="display:none"></div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-sm btn-light border" id="attendance-report-confirm-cancel" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-report-primary" id="attendance-report-confirm-submit"><i class="mdi mdi-check-all me-1"></i> Confirm eligibility</button>
                <!-- <button type="button" class="btn btn-sm btn-success" id="attendance-report-confirm-done" data-bs-dismiss="modal" style="display:none"><i class="mdi mdi-check me-1"></i> Done</button> -->
            </div>
        </div>
    </div>
</div>

<div class="modal fade attendance-report" id="attendance-report-detail-modal" tabindex="-1" aria-labelledby="attendance-report-detail-title" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="detail-modal-title" id="attendance-report-detail-title">Staff Attendance Detail</h5>
                    <div class="tiny-muted mt-1" id="attendance-report-detail-subtitle"></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4">
                <section class="detail-profile" id="attendance-report-detail-profile" aria-label="Staff and eligibility summary">
                    <div class="detail-profile-head">
                        <div class="detail-avatar"><img id="attendance-report-detail-avatar" src="" alt="Staff profile"><span class="detail-avatar-initials" id="attendance-report-detail-avatar-fallback">ST</span></div>
                        <div class="flex-grow-1">
                            <h6 class="detail-person-name" id="attendance-report-detail-person-name">Staff name</h6>
                            <div class="detail-person-meta" id="attendance-report-detail-person-meta"></div>
                        </div>
                        <div class="detail-decision-panel" id="attendance-report-detail-decision-badges"></div>
                    </div>
                    <div class="detail-decision-grid" id="attendance-report-detail-decision-grid"></div>
                    <!-- <div class="detail-reason">
                        <div class="detail-reason-label">Eligibility review note</div>
                        <p class="detail-reason-text" id="attendance-report-detail-reason">—</p>
                    </div> -->
                </section>
                <div class="p-3 d-flex flex-wrap gap-2" id="attendance-report-detail-stats"></div>
                <div class="px-3 pb-2 d-flex align-items-start justify-content-between gap-3 flex-wrap">
                    <div>
                        <div class="fw-bold text-dark small mb-2"><i class="mdi mdi-calendar-month-outline me-1"></i> Daily attendance breakdown</div>
                        
                    </div>
                    <div class="detail-status-legend">
                        @if ($isEarlyBird)
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#22a06b"></span>Early</span>
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#d97706"></span>Not early</span>
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#e11d48"></span>Late</span>
                        @else
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#22a06b"></span>Present / On Duty</span>
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#3b82f6"></span>Permission</span>
                            <span class="detail-legend-chip"><span class="detail-legend-dot" style="background:#e11d48"></span>Leave / Absent</span>
                        @endif
                    </div>
                    <!-- <div class="tiny-muted">Sundays, holidays and excluded dates remain visible but do not affect eligibility totals.</div> -->
                </div>
                <div class="table-responsive" style="max-height: 58vh;">
                    <table class="table table-sm table-bordered detail-days-table mb-0">
                        <thead class="sticky-top">
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Date</th>
                                <th>Day</th>
                                <th>Shift</th>
                                <th>Shift Start</th>
                                <th>Shift End</th>
                                <th>In Time</th>
                                <th>Out Time</th>
                                @if ($isEarlyBird)
                                    <th>Arrival Windows</th>
                                @endif
                                <th>Attendance</th>
                                <th>Day Result</th>
                                <!-- <th>Review Note</th> -->
                            </tr>
                        </thead>
                        <tbody id="attendance-report-detail-body"></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-sm btn-report-outline shadow-none" data-bs-dismiss="modal">Close</button></div>
        </div>
    </div>
</div>

<script>
const attendanceEligibilityConfig = {
    type: @json($reportType),
    dataUrl: @json($dataUrl),
    exportUrl: @json($exportUrl),
    confirmUrl: @json($confirmUrl),
    csrfToken: @json($csrfToken),
    currentMonth: @json($currentMonth),
    earlyBird: @json($isEarlyBird),
};

const attendanceReportMonthInput = document.getElementById('attendance-report-month');
const attendanceReportScopeInput = document.getElementById('attendance-report-scope');
const attendanceReportSearchInput = document.getElementById('attendance-report-search');
const attendanceReportStatusInput = document.getElementById('attendance-report-status');
const attendanceReportPerPageInput = document.getElementById('attendance-report-per-page');
const attendanceReportTableBody = document.getElementById('attendance-report-body');
const attendanceReportPagination = document.getElementById('attendance-report-pagination');
const attendanceReportPaginationInfo = document.getElementById('attendance-report-pagination-info');
const attendanceReportErrorBox = document.getElementById('attendance-report-error');
const attendanceReportSuccessBox = document.getElementById('attendance-report-success');
const attendanceReportExportLink = document.getElementById('attendance-report-export');
const attendanceReportConfirmButton = document.getElementById('attendance-report-confirm');
const attendanceReportSelectedCount = document.getElementById('attendance-report-selected-count');
const attendanceReportSelectPage = document.getElementById('attendance-report-select-page');

let attendanceReportCurrentPage = 1;
let attendanceReportRows = [];
let attendanceReportSelectedIds = new Set();
let attendanceReportRequestToken = 0;
let attendanceReportAbortController = null;
let attendanceReportSearchDebounce = null;
let attendanceReportInitialized = false;

function escapeAttendanceReportHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (character) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;',
    })[character]);
}

function attendanceReportInitials(name) {
    const parts = String(name ?? '').trim().split(/\s+/).filter(Boolean);
    return parts.slice(0, 2).map((part) => part.charAt(0)).join('').toUpperCase() || 'ST';
}

function attendanceReportNumber(value) {
    return Number(value ?? 0).toLocaleString('en-IN');
}

function attendanceReportQueryParams(page = 1) {
    return {
        month: attendanceReportMonthInput.value || attendanceEligibilityConfig.currentMonth,
        scope: attendanceReportScopeInput.value || 'all',
        search: attendanceReportSearchInput.value.trim(),
        row_filter: attendanceReportStatusInput.value || 'all',
        per_page: attendanceReportPerPageInput.value || '25',
        page: page || 1,
    };
}

function updateAttendanceReportExportLink() {
    const params = attendanceReportQueryParams(1);
    delete params.page;
    delete params.row_filter;
    const query = new URLSearchParams(params).toString();
    attendanceReportExportLink.href = `${attendanceEligibilityConfig.exportUrl}?${query}`;
    attendanceReportExportLink.setAttribute('aria-label', 'Export eligible staff as CSV for selected month and filters');
}

function setAttendanceReportLoading() {
    const colspan = attendanceEligibilityConfig.earlyBird ? 10 : 8;
    attendanceReportTableBody.innerHTML = `
        <tr>
            <td colspan="${colspan}" class="report-loading">
                <span class="spinner-border me-2" role="status" aria-hidden="true"></span>
                Checking shift logs and attendance records…
            </td>
        </tr>
    `;
}

function updateAttendanceReportMetrics(summary = {}) {
    document.getElementById('metric-total').textContent = attendanceReportNumber(summary.total_staff);
    document.getElementById('metric-eligible').textContent = attendanceReportNumber(summary.eligible);
    document.getElementById('metric-not-eligible').textContent = attendanceReportNumber(summary.not_eligible);
    document.getElementById('metric-workdays').textContent = attendanceReportNumber(summary.scheduled_workdays);
}

function attendanceReportStaffHtml(row) {
    const code = row.employee_id ? String(row.employee_id) : `#${row.staff_pk ?? ''}`;
    return `
            <div class="d-flex align-items-center ps-2">
                <!-- Staff Image -->
                <div class="symbol symbol-40px me-3">
                    <div class="image-input image-input-circle staff-avatar" >
                        <span class="staff-avatar-fallback">${escapeAttendanceReportHtml(attendanceReportInitials(row.staff_name))}</span>
                        <img src="${escapeAttendanceReportHtml(row.profile_image_url || '')}"  alt="${escapeAttendanceReportHtml(row.staff_name || 'Staff')} profile"  class="rounded-circle" style="width:40px; height:40px; object-fit:fill;" loading="lazy" onerror="this.remove()"/>
                    </div>
                </div>

                <!-- Staff Info -->
                <div class="d-flex flex-column flex-grow-1">
                    <!-- Name  -->
                    <div class="d-flex align-items-center flex-wrap">
                        <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                            data-bs-toggle="tooltip" title="${escapeAttendanceReportHtml(row.staff_name || '—')}">
                            ${escapeAttendanceReportHtml(row.staff_name || '—')}
                        </span>
                    </div>
                    <!-- Employee ID + Nickname -->
                    <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                        <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${escapeAttendanceReportHtml(code)}</span>
                    </div>

                    <!-- Company Badge -->
                    <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                        style="background-color:${row.company_base_color || '#6c757d'}; color:#fff; max-width:150px;"
                        data-bs-toggle="tooltip" title="${row.company_name || 'Elysium Groups'}">
                        ${row.company_name || 'Elysium Groups'}
                    </span>

                    <!-- Department Badge -->
                    <span class="badge bg-warning fs-8 text-truncate mb-1 text-black" 
                        style="max-width: 120px;" 
                        data-bs-toggle="tooltip" title="${row.department_name || '-'}">
                        ${row.department_name || '-'}
                    </span>

                    <!-- Job Role Badge (truncated) -->
                    <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                        style="color: #046d85 !important; max-width:150px;" 
                        data-bs-toggle="tooltip" title="${row.job_role_name || '-'}">
                        ${row.job_role_name || '-'}
                    </span>
                </div>
            </div>
    `;
}

function attendanceReportDepartmentHtml(row) {
    const role = row.job_role_name && row.job_role_name !== '—' ? row.job_role_name : '';
    const entity = row.entity_name || (Number(row.company_type) === 1 ? 'EGC Management' : '—');
    const roleText = [row.division_name, role].filter((value) => value && value !== '—').join(' · ');

    return `
        <div >
            <span class="fw-bold badge bg-label-warning border border-warning text-black rounded mb-1">
                ${escapeAttendanceReportHtml(row.department_name || '—')}
            </span>
        </div>
        <div class="tiny-muted">
            <span class="fw-bold badge  rounded mb-1" style="color:${row.entity_base_color};border:1px solid ${row.entity_base_color}; background:${hexToRGBA(row.entity_base_color,0.1)}">
                ${escapeAttendanceReportHtml(entity)}
            </span>
        </div>
        ${roleText ? `<div class="tiny-muted badge bg-label-info border border-info text-black rounded mb-1">${escapeAttendanceReportHtml(roleText)}</div>` : ''}
       
    `;
}
//  ${row.company_name ? `<div class="tiny-muted">${escapeAttendanceReportHtml(row.company_name)}</div>` : ''}
function attendanceReportCountPill(value, type = '') {
    const className = type === 'good' && Number(value) > 0
        ? ' count-good'
        : (type === 'bad' && Number(value) > 0 ? ' count-bad' : '');

    return `<span class="count-pill${className}">${attendanceReportNumber(value)}</span>`;
}

function attendanceReportReasonLine(row) {
    const reason = String(row.reason ?? '');
    const eligible = [true, 1, '1', 'true'].includes(row.eligible);
    const calculatedEligible = row.calculated_eligible === undefined
        ? eligible
        : [true, 1, '1', 'true'].includes(row.calculated_eligible);
    const manualOverride = [true, 1, '1'].includes(row.is_confirmed)
        && ['manual_eligible', 'manual_not_eligible'].includes(row.decision_mode)
        && eligible !== calculatedEligible;
    const prefix = manualOverride
        ? `HR manually confirmed ${eligible ? 'Eligible' : 'Not Eligible'}; system recommended ${calculatedEligible ? 'Eligible' : 'Not Eligible'}. `
        : '';
    const fullReason = `${prefix}${reason}`;
    const clipped = fullReason.length > 108 ? `${fullReason.slice(0, 105)}…` : fullReason;
    return `<div class="tiny-muted mt-1">${escapeAttendanceReportHtml(clipped)}</div>`;
}

function renderAttendanceReportRows(rows = []) {
    attendanceReportRows = Array.isArray(rows) ? rows : [];

    if (!attendanceReportRows.length) {
        const colspan = attendanceEligibilityConfig.earlyBird ? 10 : 8;
        attendanceReportTableBody.innerHTML = `
            <tr>
                <td colspan="${colspan}" class="text-center py-5">
                    <div class="fw-bold text-muted">No staff found for the selected filters.</div>
                    <div class="tiny-muted mt-1">Try another month, entity or search term.</div>
                </td>
            </tr>
        `;
        return;
    }

    attendanceReportTableBody.innerHTML = attendanceReportRows.map((row, index) => {
        const eligible = [true, 1, '1', 'true'].includes(row.eligible);
        const statusBadge = eligible
            ? `<span class="decision-badge decision-eligible"><i class="mdi mdi-check-circle"></i> Eligible</span>`
            : `<span class="decision-badge decision-not-eligible"><i class="mdi mdi-alert-circle"></i> Not Eligible</span>`;
        const confirmedMeta = [true, 1, '1'].includes(row.is_confirmed)
            ? `<div class="confirmed-meta"><i class="mdi mdi-shield-check-outline"></i> HR Confirmed${row.confirmed_at ? ` · ${escapeAttendanceReportHtml(String(row.confirmed_at).slice(0, 10))}` : ''}</div>`
            : '';

        const basicCells = `
            <td class="text-center" style="position:relative;">
                <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${row.company_base_color || ''};"></div>
                <div class="">
                    <input type="checkbox" class="form-check-input js-attendance-select" value="${Number(row.staff_pk)}" aria-label="Select ${escapeAttendanceReportHtml(row.staff_name || 'staff')}" ${attendanceReportSelectedIds.has(Number(row.staff_pk)) ? 'checked' : ''}>
                </div>
            </td>
            <td>${attendanceReportStaffHtml(row)}</td>
            <td>${attendanceReportCountPill(row.scheduled_days)}</td>
            <td>
                ${attendanceReportCountPill(row.attended_days, 'good')}
                <div class="tiny-muted">${escapeAttendanceReportHtml(row.attendance_percent ?? 0)}%</div>
            </td>
        `;

        const metricCells = [];
        if (attendanceEligibilityConfig.earlyBird) {
            metricCells.push(`
                <td>
                    ${attendanceReportCountPill(row.early_days, 'good')}
                    <div class="tiny-muted">${escapeAttendanceReportHtml(row.early_percent ?? 0)}%</div>
                </td>
                <td>
                    <div class="early-bird-breakdown">
                        <div class="early-bird-breakdown-line">
                            <span class="count-pill count-not-early" data-bs-toggle="tooltip" title="Not Early">${attendanceReportNumber(row.not_early_days)}</span>
                            <span class="count-pill count-late" data-bs-toggle="tooltip" title="Late Count">${attendanceReportNumber(row.late_days)}</span>
                        </div>
                        ${Number(row.missing_in_time_days || 0) > 0 ? `<div class="early-bird-breakdown-line"><span class="early-bird-breakdown-label">No in-time</span><span class="count-pill count-no-punch">${attendanceReportNumber(row.missing_in_time_days)}</span></div>` : ''}
                    </div>
                </td>
            `);
        }

        metricCells.push(`
            <td>
                <span class="count-pill  text-black bg-warning">
                    ${row.leave_days + row.absent_days}
                </span>
            </td>
            <td>
                <span class="badge text-black fw-bold px-3  py-1 count-pill" style="background-color: #DCE2FC !important; border:1px solid #2856FA !important; ">
                    ${row.permission_days}
                </span>
            </td>
            <!-- <td>${attendanceReportCountPill(row.missing_days, 'bad')}</td> -->
        `);

        return `
            <tr class="${eligible ? 'row-eligible' : 'row-not-eligible'}">
                ${basicCells}
                ${metricCells.join('')}
                <td>
                    ${statusBadge}
                    ${confirmedMeta}
                    <!--${attendanceReportReasonLine(row)} -->
                </td>
                <td>
                    <button type="button" class="detail-button js-attendance-details btn btn-icon btn-sm fs-3 text-black" data-row-index="${index}">
                        <i class="mdi mdi-eye-outline "></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function updateAttendanceReportSelectionUi() {
    attendanceReportSelectedCount.textContent = `${attendanceReportSelectedIds.size} selected`;
    attendanceReportConfirmButton.disabled = attendanceReportSelectedIds.size === 0;
    const pageIds = attendanceReportRows.map((row) => Number(row.staff_pk));
    attendanceReportSelectPage.checked = pageIds.length > 0 && pageIds.every((id) => attendanceReportSelectedIds.has(id));
    attendanceReportSelectPage.indeterminate = pageIds.some((id) => attendanceReportSelectedIds.has(id)) && !attendanceReportSelectPage.checked;
}

function clearAttendanceReportSelection() {
    attendanceReportSelectedIds.clear();
    updateAttendanceReportSelectionUi();
}

function attendanceReportModalInstance() {
    const modalElement = document.getElementById('attendance-report-confirm-modal');
    if (window.bootstrap && window.bootstrap.Modal) {
        const instance = window.bootstrap.Modal.getOrCreateInstance(modalElement);
        instance.show();
        return instance;
    }
    if (window.jQuery && window.jQuery.fn.modal) {
        window.jQuery(modalElement).modal('show');
        return null;
    }
    return null;
}

function attendanceReportConfirmationDecisionMode() {
    const selected = document.querySelector('input[name="attendance-report-decision-mode"]:checked');
    return selected ? selected.value : 'calculated';
}

function updateAttendanceReportConfirmationChoice() {
    const modal = document.getElementById('attendance-report-confirm-modal');
    const mode = attendanceReportConfirmationDecisionMode();
    const selectedCount = Number(modal.dataset.selectedCount || 0);
    const calculatedEligible = Number(modal.dataset.calculatedEligible || 0);
    const calculatedNotEligible = Number(modal.dataset.calculatedNotEligible || 0);
    let eligible = calculatedEligible;
    let notEligible = calculatedNotEligible;
    let buttonLabel = '<i class="mdi mdi-check-all me-1"></i> Save calculated results';
    if (mode === 'manual_eligible') {
        eligible = selectedCount;
        notEligible = 0;
        buttonLabel = '<i class="mdi mdi-check-circle me-1"></i> Confirm as Eligible';
    } else if (mode === 'manual_not_eligible') {
        eligible = 0;
        notEligible = selectedCount;
        buttonLabel = '<i class="mdi mdi-close-circle me-1"></i> Confirm as Not Eligible';
    }
    document.getElementById('attendance-report-confirm-eligible').textContent = attendanceReportNumber(eligible);
    document.getElementById('attendance-report-confirm-not-eligible').textContent = attendanceReportNumber(notEligible);
    const submit = document.getElementById('attendance-report-confirm-submit');
    if (modal.dataset.saving !== '1') submit.innerHTML = buttonLabel;
}

function hideAttendanceReportConfirmationModal() {
    const modal = document.getElementById('attendance-report-confirm-modal');
    if (window.bootstrap && window.bootstrap.Modal) {
        window.bootstrap.Modal.getOrCreateInstance(modal).hide();
    } else if (window.jQuery && window.jQuery.fn.modal) {
        window.jQuery(modal).modal('hide');
    }
}

function resetAttendanceReportConfirmationModal() {
    const modal = document.getElementById('attendance-report-confirm-modal');
    modal.querySelector('#attendance-report-confirm-error').style.display = 'none';
    modal.querySelector('#attendance-report-confirm-error').textContent = '';
    modal.querySelector('#attendance-report-confirm-title').textContent = 'Confirm monthly eligibility?';
    modal.querySelector('#attendance-report-confirm-description').textContent = 'Choose whether to save the system recommendation or explicitly confirm the selected staff as Eligible or Not Eligible. Existing records for the same staff and month will be updated.';
    modal.querySelector('#attendance-report-confirm-icon').classList.remove('is-success');
    modal.dataset.mode = 'confirm';
    modal.dataset.saving = '0';
    // document.getElementById('attendance-report-mode-calculated').checked = true;
    document.getElementById('attendance-report-mode-eligible').checked = true;
    document.getElementById('attendance-report-mode-not-eligible').checked = false;
    modal.querySelector('#attendance-report-confirm-icon').innerHTML = '<i class="mdi mdi-shield-check-outline"></i>';
    modal.querySelector('#attendance-report-confirm-cancel').style.display = '';
    modal.querySelector('#attendance-report-confirm-cancel').disabled = false;
    modal.querySelector('#attendance-report-confirm-submit').style.display = '';
    // modal.querySelector('#attendance-report-confirm-done').style.display = 'none';
    modal.querySelector('#attendance-report-confirm-submit').disabled = false;
    modal.querySelector('#attendance-report-confirm-submit').innerHTML = '<i class="mdi mdi-check-all me-1"></i> Confirm eligibility';
    modal.dataset.mode = 'confirm';
}

function confirmSelectedAttendanceReport() {
    const staffIds = Array.from(attendanceReportSelectedIds);
    if (!staffIds.length) return;

    attendanceReportSuccessBox.style.display = 'none';
    resetAttendanceReportConfirmationModal();
    const selectedRows = attendanceReportRows.filter((row) => staffIds.includes(Number(row.staff_pk)));
    const selectedEligible = selectedRows.filter((row) => [true, 1, '1', 'true'].includes(row.eligible)).length;
    const selectedNotEligible = selectedRows.length - selectedEligible;
    const month = attendanceReportMonthInput.value || attendanceEligibilityConfig.currentMonth;
    const reportName = attendanceEligibilityConfig.earlyBird ? 'Staff Early Bird' : 'Master Attendance';
    const modal = document.getElementById('attendance-report-confirm-modal');

    document.getElementById('attendance-report-confirm-report').textContent = reportName;
    document.getElementById('attendance-report-confirm-month').textContent = month;
    document.getElementById('attendance-report-confirm-selected').textContent = attendanceReportNumber(staffIds.length);
    document.getElementById('attendance-report-confirm-eligible').textContent = attendanceReportNumber(selectedEligible);
    document.getElementById('attendance-report-confirm-not-eligible').textContent = attendanceReportNumber(selectedNotEligible);
    modal.dataset.month = month;
    modal.dataset.staffIds = JSON.stringify(staffIds);
    modal.dataset.selectedCount = String(staffIds.length);
    modal.dataset.calculatedEligible = String(selectedEligible);
    modal.dataset.calculatedNotEligible = String(selectedNotEligible);
    updateAttendanceReportConfirmationChoice();

    const modalInstance = attendanceReportModalInstance();
    if (!modalInstance && !(window.jQuery && window.jQuery.fn.modal)) {
        const errorBox = document.getElementById('attendance-report-error');
        errorBox.textContent = 'Bootstrap modal is unavailable. Please reload this page and try again.';
        errorBox.style.display = 'block';
    }
}

async function submitAttendanceReportConfirmation() {
    const modal = document.getElementById('attendance-report-confirm-modal');
    if (modal.dataset.mode === 'done') {
        if (window.bootstrap && window.bootstrap.Modal) {
            window.bootstrap.Modal.getOrCreateInstance(modal).hide();
        } else if (window.jQuery && window.jQuery.fn.modal) {
            window.jQuery(modal).modal('hide');
        }
        return;
    }

    const staffIds = JSON.parse(modal.dataset.staffIds || '[]');
    if (!staffIds.length) return;

    const submitButton = document.getElementById('attendance-report-confirm-submit');
    const cancelButton = document.getElementById('attendance-report-confirm-cancel');
    const errorBox = document.getElementById('attendance-report-confirm-error');
    const month = modal.dataset.month || attendanceEligibilityConfig.currentMonth;
    const buttonText = submitButton.innerHTML;
    errorBox.style.display = 'none';
    submitButton.disabled = true;
    cancelButton.disabled = true;
    modal.dataset.saving = '1';
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Saving…';

    try {
        const response = await fetch(attendanceEligibilityConfig.confirmUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': attendanceEligibilityConfig.csrfToken,
            },
            body: JSON.stringify({
                month,
                staff_ids: staffIds,
                decision_mode: attendanceReportConfirmationDecisionMode(),
                scope: attendanceReportScopeInput.value || 'all',
                search: attendanceReportSearchInput.value.trim(),
            }),
        });

        let result;
        try {
            result = await response.json();
        } catch (error) {
            throw new Error('The server returned an invalid response while saving confirmations.');
        }
        if (!response.ok || Number(result.status) !== 200) {
            throw new Error(result.message || 'Unable to save eligibility confirmations.');
        }

        const decisionMode = result.decision_mode || attendanceReportConfirmationDecisionMode();
        const decisionLabels = {
            calculated: 'system-calculated results',
            manual_eligible: 'manually confirmed Eligible',
            manual_not_eligible: 'manually confirmed Not Eligible',
        };
        attendanceReportSuccessBox.textContent = `${result.saved_count ?? staffIds.length} staff record(s) ${decisionLabels[decisionMode] || 'confirmed'} for ${month}. The staff list and Eligible CSV export now use the saved monthly decision.`;
        attendanceReportSuccessBox.style.display = 'block';

        // Close immediately after a successful save. Do not keep the modal open on a Done
        // screen, and reset the submit button so a stale spinner can never remain visible.
        hideAttendanceReportConfirmationModal();
        modal.dataset.saving = '0';
        modal.dataset.mode = 'confirm';
        submitButton.disabled = false;
        cancelButton.disabled = false;
        submitButton.innerHTML = '<i class="mdi mdi-check-all me-1"></i> Save calculated results';
        submitButton.style.display = '';
        cancelButton.style.display = '';
        // document.getElementById('attendance-report-confirm-done').style.display = 'none';
        clearAttendanceReportSelection();
        void loadAttendanceReport(attendanceReportCurrentPage);
    } catch (error) {
        errorBox.textContent = error.message || 'Unable to save eligibility confirmations.';
        errorBox.style.display = 'block';
        modal.dataset.saving = '0';
        submitButton.disabled = false;
        cancelButton.disabled = false;
        submitButton.innerHTML = buttonText;
    }
}

function updateAttendanceReportPagination(currentPage, lastPage, total, perPage, from = null, to = null) {
    const safeTotal = Math.max(0, Number(total) || 0);
    const safePerPage = Math.max(1, Number(perPage) || 25);
    const safeLastPage = Math.max(1, Number(lastPage) || 1);
    const safeCurrentPage = Math.min(Math.max(1, Number(currentPage) || 1), safeLastPage);
    const start = safeTotal ? (Number(from) || ((safeCurrentPage - 1) * safePerPage + 1)) : 0;
    const end = safeTotal ? (Number(to) || Math.min(safeCurrentPage * safePerPage, safeTotal)) : 0;

    attendanceReportPaginationInfo.textContent = safeTotal
        ? `Showing ${attendanceReportNumber(start)} to ${attendanceReportNumber(end)} of ${attendanceReportNumber(safeTotal)} results`
        : 'No records to display';

    const pageItems = [];
    const addButton = (label, targetPage, disabled, active, title) => {
        pageItems.push(`
            <li class="page-item ${disabled ? 'disabled' : ''} ${active ? 'active' : ''}" title="${escapeAttendanceReportHtml(title)}">
                <button type="button" class="page-link" data-page="${targetPage}" aria-label="${escapeAttendanceReportHtml(title)}" ${disabled ? 'disabled' : ''} ${active ? 'aria-current="page"' : ''}>${label}</button>
            </li>
        `);
    };

    addButton('«', 1, safeCurrentPage <= 1, false, 'First page');
    addButton('‹', Math.max(1, safeCurrentPage - 1), safeCurrentPage <= 1, false, 'Previous page');

    const range = 2;
    const startPage = Math.max(1, safeCurrentPage - range);
    const endPage = Math.min(safeLastPage, safeCurrentPage + range);
    for (let page = startPage; page <= endPage; page += 1) {
        addButton(String(page), page, false, page === safeCurrentPage, `Page ${page}`);
    }

    addButton('›', Math.min(safeLastPage, safeCurrentPage + 1), safeCurrentPage >= safeLastPage, false, 'Next page');
    addButton('»', safeLastPage, safeCurrentPage >= safeLastPage, false, 'Last page');
    attendanceReportPagination.innerHTML = pageItems.join('');
}

function formatAttendanceReportPeriod(period = {}) {
    const dateLabel = (value) => {
        const parts = String(value ?? '').split('-');
        if (parts.length !== 3) return value || '—';
        const date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    };

    document.getElementById('report-period-label').textContent = `Reviewing ${dateLabel(period.start_date)} – ${dateLabel(period.end_date)}${period.is_current_month ? ' · Current month stops at today' : ' · Full selected month'}`;
}

async function loadAttendanceReport(page = 1) {
    attendanceReportCurrentPage = Math.max(1, Number(page) || 1);
    clearAttendanceReportSelection();
    const requestToken = ++attendanceReportRequestToken;

    if (attendanceReportAbortController) {
        attendanceReportAbortController.abort();
    }
    attendanceReportAbortController = new AbortController();

    attendanceReportErrorBox.style.display = 'none';
    setAttendanceReportLoading();
    updateAttendanceReportExportLink();

    const query = new URLSearchParams(attendanceReportQueryParams(attendanceReportCurrentPage)).toString();

    try {
        const response = await fetch(`${attendanceEligibilityConfig.dataUrl}?${query}`, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
            signal: attendanceReportAbortController.signal,
        });

        let result;
        try {
            result = await response.json();
        } catch (parseError) {
            throw new Error('The server returned an invalid response. Please reload and try again.');
        }

        if (requestToken !== attendanceReportRequestToken) return;
        if (!response.ok || Number(result.status) !== 200) {
            throw new Error(result.message || 'Unable to load the attendance report.');
        }

        const summary = result.summary || {};
        const pagination = result.pagination || {};
        const currentPage = Number(pagination.current_page || attendanceReportCurrentPage);
        const lastPage = Number(pagination.last_page || 1);
        const total = pagination.total ?? summary.total_staff ?? (result.data || []).length;
        const perPage = pagination.per_page || attendanceReportPerPageInput.value || 25;

        updateAttendanceReportMetrics(summary);
        formatAttendanceReportPeriod(result.period || {});
        renderAttendanceReportRows(result.data || []);
        updateAttendanceReportPagination(currentPage, lastPage, total, perPage, pagination.from, pagination.to);
        $('[data-bs-toggle="tooltip"]').tooltip();

        // document.getElementById('attendance-report-table-help').textContent = `${attendanceReportNumber(summary.eligible)} eligible · ${attendanceReportNumber(summary.not_eligible)} not eligible `;
    } catch (error) {
        if (requestToken !== attendanceReportRequestToken || error.name === 'AbortError') return;

        const colspan = attendanceEligibilityConfig.earlyBird ? 10 : 8;
        attendanceReportTableBody.innerHTML = `
            <tr>
                <td colspan="${colspan}" class="text-center text-danger py-4">Unable to load attendance details.</td>
            </tr>
        `;
        attendanceReportErrorBox.textContent = error.message || 'Unexpected error while loading attendance details.';
        attendanceReportErrorBox.style.display = 'block';
        attendanceReportPaginationInfo.textContent = 'Report could not be loaded';
        attendanceReportPagination.innerHTML = '';
    }
}

function attendanceReportResultClass(day) {
    const result = String(day.day_result || '').toLowerCase();
    if (['early bird', 'present'].includes(result)) return 'day-result-pass';
    if (result === 'late') return 'day-result-late';
    if (result === 'not early') return 'day-result-not-early';
    if (result === 'permission') return 'day-result-permission';
    if (['leave', 'absent', 'attendance missing', 'in-time missing', 'shift start missing', 'shift not configured'].includes(result)) return 'day-result-fail';
    return 'day-result-skip';
}

function attendanceReportDetailRowClass(day) {
    const result = String(day.day_result || '').trim().toLowerCase();
    const attendance = String(day.attendance_label || '').trim().toLowerCase();

    if (attendanceEligibilityConfig.earlyBird) {
        if (result === 'early bird') return 'detail-row-early';
        if (result === 'late') return 'detail-row-late';
        if (result === 'not early') return 'detail-row-not-early';
        if (['in-time missing', 'shift start missing', 'attendance missing', 'shift not configured'].includes(result)) return 'detail-row-exception';
        return '';
    }

    if (result === 'present' || attendance === 'on duty') return 'detail-row-present';
    if (result === 'permission') return 'detail-row-permission';
    if (['leave', 'absent'].includes(result)) return 'detail-row-absence';
    if (['attendance missing', 'shift not configured'].includes(result)) return 'detail-row-exception';
    return '';
}

function openAttendanceReportDetails(row) {
    const reportName = attendanceEligibilityConfig.earlyBird ? 'Staff Early Bird' : 'Master Attendance';
    document.getElementById('attendance-report-detail-title').textContent = `${reportName} — Staff Review`;
    document.getElementById('attendance-report-detail-subtitle').textContent = `Monthly record for ${attendanceReportMonthInput.value || attendanceEligibilityConfig.currentMonth}`;

    const avatar = document.getElementById('attendance-report-detail-avatar');
    const avatarHolder = avatar.parentElement;
    avatarHolder.classList.remove('show-fallback');
    document.getElementById('attendance-report-detail-avatar-fallback').textContent = attendanceReportInitials(row.staff_name);
    avatar.style.display = '';
    avatar.src = row.profile_image_url || '';
    avatar.alt = `${row.staff_name || 'Staff'} profile photo`;
    avatar.onerror = () => {
        avatarHolder.classList.add('show-fallback');
        avatar.style.display = 'none';
    };
    document.getElementById('attendance-report-detail-person-name').textContent = row.staff_name || 'Staff';
    

    document.getElementById('attendance-report-detail-person-meta').innerHTML = `
        <div class="d-flex gap-1 align-items-center">
            <span class="" style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${row.employee_id || row.staff_pk || '—'}</span>
            <span class="fw-bold badge bg-label-warning border border-warning text-black rounded mb-1">
                ${escapeAttendanceReportHtml(row.department_name || '—')}
            </span>
            <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                style="color: #046d85 !important; max-width:175px;" 
                data-bs-toggle="tooltip" title="${row.job_role_name || '-'}">
                ${row.job_role_name || '-'}
            </span>
            <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                style="background-color:${row.entity_base_color || '#6c757d'}; color:#fff; max-width:200px;"
                data-bs-toggle="tooltip" title="${row.entity_name || 'Elysium Groups'}">
                ${row.company_name || 'Elysium Groups'}
            </span>
        </div>
    `;

  

    const eligible = [true, 1, '1', 'true'].includes(row.eligible);
    const calculatedEligible = row.calculated_eligible === undefined
        ? eligible
        : [true, 1, '1', 'true'].includes(row.calculated_eligible);
    const decisionMode = row.decision_mode || 'calculated';
    const isConfirmed = [true, 1, '1'].includes(row.is_confirmed);
    const decisionLabel = eligible ? 'Eligible' : 'Not Eligible';
    const recommendationLabel = calculatedEligible ? 'Eligible' : 'Not Eligible';
    const modeLabel = decisionMode === 'manual_eligible'
        ? 'HR approval'
        : (decisionMode === 'manual_not_eligible' ? 'HR decision' : 'System-calculated');
    document.getElementById('attendance-report-detail-decision-badges').innerHTML = `
        <span class="decision-badge ${eligible ? 'decision-eligible' : 'decision-not-eligible'}"><i class="mdi ${eligible ? 'mdi-check-circle' : 'mdi-alert-circle'}"></i>${decisionLabel}</span>
        <span class="confirmed-meta"><i class="mdi ${isConfirmed ? 'mdi-shield-check-outline' : 'mdi-clipboard-search-outline'}"></i>${isConfirmed ? 'HR Confirmed' : 'Awaiting HR confirmation'}</span>
        <span class="tiny-muted">${escapeAttendanceReportHtml(modeLabel)}</span>
    `;
    document.getElementById('attendance-report-detail-decision-grid').innerHTML = `
        <div class="detail-decision-item"><div class="detail-decision-label">Saved HR decision</div><div class="detail-decision-value">${escapeAttendanceReportHtml(decisionLabel)}</div></div>
        <div class="detail-decision-item"><div class="detail-decision-label">System recommendation</div><div class="detail-decision-value">${escapeAttendanceReportHtml(recommendationLabel)}</div></div>
        <div class="detail-decision-item"><div class="detail-decision-label">Confirmed on</div><div class="detail-decision-value">${isConfirmed && row.confirmed_at ? escapeAttendanceReportHtml(String(row.confirmed_at).slice(0, 16)) : 'Not confirmed'}</div></div>
        <div class="detail-decision-item"><div class="detail-decision-label">Confirmed by</div><div class="detail-decision-value">${isConfirmed && row.confirmed_by ? `User #${escapeAttendanceReportHtml(row.confirmed_by)}` : '—'}</div></div>
    `;
    const reason = String(row.reason || 'No review note was provided.');
    const overrideNote = isConfirmed && decisionMode !== 'calculated' && eligible !== calculatedEligible
        ? `HR manually overrode the system recommendation (${recommendationLabel}). ${reason}`
        : reason;
    // document.getElementById('attendance-report-detail-reason').textContent = overrideNote;

    const stats = [
        ['Scheduled', row.scheduled_days],
        ['Attended', row.attended_days],
        ['Leave', row.leave_days],
        ['Permission', row.permission_days],
        ['Absent', row.absent_days],
        // ['Missing', row.missing_days],
    ];

    if (attendanceEligibilityConfig.earlyBird) {
        stats.push(['Early', row.early_days]);
        stats.push(['Not early', row.not_early_days]);
        stats.push(['Late', row.late_days]);
        stats.push(['Missing in-time', row.missing_in_time_days]);
    }

    document.getElementById('attendance-report-detail-stats').innerHTML = stats.map(([label, value]) => `
        <div class="detail-stat-card"><span class="detail-stat-label">${escapeAttendanceReportHtml(label)}</span><strong class="detail-stat-value">${attendanceReportNumber(value)}</strong></div>
    `).join('');

    const details = Array.isArray(row.details) ? row.details : [];
    document.getElementById('attendance-report-detail-body').innerHTML = details.map((day) => {
        const resultBadge = `<span class="day-result ${attendanceReportResultClass(day)}">${escapeAttendanceReportHtml(day.day_result || '—')}</span>`;
        const arrivalWindows = attendanceEligibilityConfig.earlyBird
            ? `<td><div class="threshold-summary">
                    <span class="threshold-early">Early ≤ ${escapeAttendanceReportHtml(day.expected_early_by || '—')}</span>
                    <span class="threshold-not-early">Not early ${escapeAttendanceReportHtml(day.not_early_from || '—')}–${escapeAttendanceReportHtml(day.not_early_until || '—')}</span>
                    <span class="threshold-late">Late ≥ ${escapeAttendanceReportHtml(day.late_threshold_from || '—')}</span>
                </div></td>`
            : '';
        const detailRowClass = attendanceReportDetailRowClass(day);

        return `
            <tr class="${detailRowClass}">
                <td class="text-nowrap fw-semibold">${escapeAttendanceReportHtml(day.date_label || day.date || '—')}</td>
                <td>${escapeAttendanceReportHtml(day.day_name || '—')}</td>
                <td>${escapeAttendanceReportHtml(day.shift_name || '—')}</td>
                <td class="text-nowrap">${escapeAttendanceReportHtml(day.shift_start || '—')}</td>
                <td class="text-nowrap">${escapeAttendanceReportHtml(day.shift_end || '—')}</td>
                <td class="text-nowrap">${escapeAttendanceReportHtml(day.in_time || '—')}</td>
                <td class="text-nowrap">${escapeAttendanceReportHtml(day.out_time || '—')}</td>
                ${arrivalWindows}
                <td>${escapeAttendanceReportHtml(day.attendance_label || '—')}</td>
                <td>
                    ${resultBadge}
                    <div>${(day.in_time && day.out_time) ? calculateDuration(day.in_time,day.out_time) : ''}</div>
                </td>
                <!-- <td style="min-width:250px;white-space:normal;">${escapeAttendanceReportHtml(day.message || '')}</td> -->
            </tr>
        `;
    }).join('') || `
        <tr>
            <td colspan="${attendanceEligibilityConfig.earlyBird ? 10 : 9}" class="text-center text-muted py-4">No daily details available.</td>
        </tr>
    `;

    const modalElement = document.getElementById('attendance-report-detail-modal');
    if (window.bootstrap && window.bootstrap.Modal) {
        window.bootstrap.Modal.getOrCreateInstance(modalElement).show();
    } else if (window.jQuery && window.jQuery.fn.modal) {
        window.jQuery(modalElement).modal('show');
    }
}

function initializeAttendanceEligibilityReport() {
    if (attendanceReportInitialized) return;
    attendanceReportInitialized = true;

    if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
        window.jQuery('.attendance-report .select3').each((index, element) => {
            const select = window.jQuery(element);
            if (select.hasClass('select2-hidden-accessible')) {
                select.select2('destroy');
            }
            select.select2({
                width: '100%',
                placeholder: 'Select',
            });
        });
    }

    // document.getElementById('attendance-report-apply').addEventListener('click', () => loadAttendanceReport(1));

    document.getElementById('attendance-report-reset').addEventListener('click', () => {
        attendanceReportMonthInput.value = attendanceEligibilityConfig.currentMonth;
        attendanceReportScopeInput.value = 'all';
        attendanceReportSearchInput.value = '';
        attendanceReportStatusInput.value = 'all';
        attendanceReportPerPageInput.value = '25';

        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
            window.jQuery(attendanceReportScopeInput).trigger('change.select2');
            window.jQuery(attendanceReportStatusInput).trigger('change.select2');
            window.jQuery(attendanceReportPerPageInput).trigger('change.select2');
        }

        loadAttendanceReport(1);
    });

    

    
    const selectFilterControls = [
        attendanceReportScopeInput,
        attendanceReportStatusInput,
        attendanceReportPerPageInput,
    ];

    if (window.jQuery) {
        window.jQuery(selectFilterControls)
            .off('change.attendanceEligibilityReport')
            .on('change.attendanceEligibilityReport', () => loadAttendanceReport(1));
    } else {
        selectFilterControls.forEach((input) => {
            input.addEventListener('change', () => loadAttendanceReport(1));
        });
    }

    attendanceReportSearchInput.addEventListener('input', () => {
        window.clearTimeout(attendanceReportSearchDebounce);
        attendanceReportSearchDebounce = window.setTimeout(() => loadAttendanceReport(1), 320);
    });

    attendanceReportSearchInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            window.clearTimeout(attendanceReportSearchDebounce);
            loadAttendanceReport(1);
        }
    });

    attendanceReportPagination.addEventListener('click', (event) => {
        const target = event.target instanceof Element ? event.target.closest('button[data-page]') : null;
        if (!target || target.disabled) return;
        loadAttendanceReport(Number(target.dataset.page));
    });

    attendanceReportTableBody.addEventListener('click', (event) => {
        const target = event.target instanceof Element ? event.target.closest('.js-attendance-details') : null;
        if (!target) return;
        const index = Number(target.dataset.rowIndex);
        if (attendanceReportRows[index]) {
            openAttendanceReportDetails(attendanceReportRows[index]);
        }
    });

    attendanceReportTableBody.addEventListener('change', (event) => {
        const target = event.target instanceof Element ? event.target.closest('.js-attendance-select') : null;
        if (!target) return;
        const staffId = Number(target.value);
        if (target.checked) attendanceReportSelectedIds.add(staffId);
        else attendanceReportSelectedIds.delete(staffId);
        updateAttendanceReportSelectionUi();
    });

    attendanceReportSelectPage.addEventListener('change', () => {
        attendanceReportRows.forEach((row) => {
            const staffId = Number(row.staff_pk);
            if (attendanceReportSelectPage.checked) attendanceReportSelectedIds.add(staffId);
            else attendanceReportSelectedIds.delete(staffId);
        });
        renderAttendanceReportRows(attendanceReportRows);
        updateAttendanceReportSelectionUi();
    });

    attendanceReportConfirmButton.addEventListener('click', confirmSelectedAttendanceReport);
    document.querySelectorAll('input[name="attendance-report-decision-mode"]').forEach((input) => {
        input.addEventListener('change', updateAttendanceReportConfirmationChoice);
    });
    document.getElementById('attendance-report-confirm-submit').addEventListener('click', submitAttendanceReportConfirmation);
    // document.getElementById('attendance-report-confirm-done').addEventListener('click', hideAttendanceReportConfirmationModal);

    updateAttendanceReportSelectionUi();
    updateAttendanceReportExportLink();
    loadAttendanceReport(1);
}

function hexToRGBA(hex, opacity) {
    let r = 0,
        g = 0,
        b = 0;

    if (hex.length == 7) {
        r = parseInt(hex.substring(1, 3), 16);
        g = parseInt(hex.substring(3, 5), 16);
        b = parseInt(hex.substring(5, 7), 16);
    }

    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

function monthFilterChange(){
    loadAttendanceReport(1);
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAttendanceEligibilityReport, { once: true });
} else {
    initializeAttendanceEligibilityReport();
}

function calculateDuration(intime, outtime) {
    if (!intime || !outtime) return '-';

    function parseTime(timeStr) {
        // "09:36 AM"
        const [time, modifier] = timeStr.split(' ');
        let [hours, minutes] = time.split(':').map(Number);

        if (modifier === 'PM' && hours !== 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0;

        return {
            hours,
            minutes
        };
    }

    const inTime = parseTime(intime);
    const outTime = parseTime(outtime);

    const inMinutes = inTime.hours * 60 + inTime.minutes;
    const outMinutes = outTime.hours * 60 + outTime.minutes;

    let diff = outMinutes - inMinutes;

    // handle overnight shift (eg: 10:00 PM → 06:00 AM)
    if (diff < 0) diff += 24 * 60;

    const hours = Math.floor(diff / 60);
    const minutes = diff % 60;

    return `${hours}h ${minutes}m`;
}
</script>
<script>
    $('#attendance-report-month').datepicker({
        format: 'M-yyyy',
        viewMode: 'months',
        minViewMode: 'months',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>
