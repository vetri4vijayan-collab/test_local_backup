@extends('layouts/layoutMaster')

<title>CUG Call Monitor</title>

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
      $module_name = 'Sales Management';
     $menu_name = 'Manage Calls';

    if(auth()->user()->hasPermission($module_name, 'Location', $menu_name)){
        $location_check = 1;
    }else{
            $location_check = 0;
    }
@endphp

  

<style>

    body{
     background:#f5f7fb;
    }

    /*== Page Header ===*/
    .monitor-header{
        background:#fff;
        padding:20px;
        border-radius:12px;
        box-shadow:0 2px 12px rgba(0,0,0,.05);
        margin-bottom:20px;
    }

    .monitor-title{
        font-size:24px;
        font-weight:700;
        color:#233044;
    }

    .monitor-subtitle{
        font-size:13px;
        color:#7b8794;
    }


    .location-filter-card {
        background: #ffffff;
        border: 1px solid #e5eaf0;
        border-radius: 14px;
        padding: 14px;
        margin-bottom: 12px;
        box-shadow: 0 3px 15px rgba(15, 23, 42, .05);
    }


    .location-filter-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        /* margin-bottom: 12px; */
    }

    .location-filter-title {
        display: flex;
        align-items: center;
        gap: 9px;
    }

    .location-filter-title-icon {
        width: 36px;
        height: 36px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #eff6ff;
        color: #2563eb;
        font-size: 19px;
    }

    .location-filter-title h4 {
        margin: 0;
        color: #172033;
        font-size: 15px;
        font-weight: 750;
    }

    .location-filter-title small {
        display: block;
        margin-top: 2px;
        color: #94a3b8;
        font-size: 10px;
    }

    .location-filter-actions {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /*=========================================
    Dashboard Cards
    =========================================*/

    .monitor-card{
        background:#fff;
        border-radius:14px;
        padding:18px;
        box-shadow:0 2px 10px rgba(0,0,0,.05);
        transition:.25s;
        height:100%;
    }

    .monitor-card:hover{
        transform:translateY(-3px);
    }

    .monitor-card h5{
        font-size:13px;
        color:#7d8896;
        margin-bottom:10px;
    }

    .monitor-card h2{
        font-size:28px;
        font-weight:700;
        margin:0;
    }

    .monitor-icon{
        width:52px;
        height:52px;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:22px;
        color:#fff;
    }

    .bg-online{
        background:#16c784;
    }

    .bg-offline{
        background:#f04438;
    }

    .bg-call{
        background:#3b82f6;
    }

    .bg-missed{
        background:#ff9800;
    }

    /*=========================================
    Department Tabs
    =========================================*/

    .department-tabs{
        display:flex;
        overflow-x:auto;
        white-space:nowrap;
        gap:10px;
        padding-bottom:5px;
        margin-bottom:20px;
    }

    .department-tabs::-webkit-scrollbar{
        height:5px;
    }

    .department-tabs::-webkit-scrollbar-thumb{
        background:#d5d5d5;
        border-radius:10px;
    }

    .department-tab{
        min-width:160px;
        padding:12px 20px;
        border-radius:12px;
        background:#fff;
        border:1px solid #e6e9ef;
        cursor:pointer;
        transition:.25s;
        position:relative;
    }

    .department-tab:hover{
        transform:translateY(-2px);
        box-shadow:0 6px 16px rgba(0,0,0,.08);
    }

    .department-tab.active{
        background:#39484f;
        color:#fff;
        border-color:#39484f;
    }

    .department-tab small{
        opacity:.75;
        display:block;
        margin-top:3px;
    }

    /*=========================================
    Toolbar
    =========================================*/

    .monitor-toolbar{
        background:#fff;
        padding:15px;
        border-radius:12px;
        margin-bottom:20px;
        box-shadow:0 2px 10px rgba(0,0,0,.05);
    }

    /*=========================================
    Table
    =========================================*/

    .table-card{
        background:#fff;
        /* border-radius:12px; */
        overflow:hidden;
        box-shadow:0 2px 12px rgba(0,0,0,.05);
    }

    .table-monitor{
        margin-bottom:0;
    }

    .table-monitor thead{
        position:sticky;
        top:0;
        background:#eef3fb;
        z-index:20;
    }

    .table-monitor thead th{
        /* font-size:12px; */
        font-weight:700;
        /* color:#5b6574; */
        padding:13px;
        white-space:nowrap;
    }

    .table-monitor tbody td{
        vertical-align:middle;
        padding:12px;
        font-size:20px;
    }

    .table-monitor tbody tr{
        transition:.2s;
    }

    .table-monitor tbody tr:hover{
        background:#f9fbff;
    }

    /*=========================================
    Avatar
    =========================================*/

    .staff-avatar{
        width:46px;
        height:46px;
        border-radius:50%;
        overflow:hidden;
        background:#e9ecef;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:18px;
        font-weight:700;
        color:#4d5969;
    }

    .staff-avatar img{
        width:100%;
        height:100%;
        object-fit:fill;
    }

    .last-call-info {
        display: flex;
        flex-direction: column;
        gap: 3px;
        padding: 4px 7px;
        border-radius: 6px;
        transition: background-color .15s ease;
    }

    .last-call-info:hover {
        background: rgba(108, 117, 125, .06);
    }

    .last-call-label {
        display: flex;
        align-items: center;
        gap: 5px;
        color: #495057;
        font-size: 11px;
        font-weight: 600;
        line-height: 1;
        white-space: nowrap;
    }

    .last-call-label i {
        font-size: 13px;
    }

    .last-call-time {
        display: flex;
        align-items: center;
        color: #7d8797;
        font-size: 10px;
        font-weight: 500;
        line-height: 1;
        white-space: nowrap;
    }

    .last-call-time .mx-1 {
        color: #c5cad1;
    }

    .last-call-info.text-muted .last-call-label {
        color: #adb5bd;
    }

    .last-call-info.text-muted .last-call-label i {
        color: #c7ccd2;
    }

    .last-call-info.text-muted .last-call-label {
        opacity: .85;
    }

    /*=========================================
    Status
    =========================================*/

    .online-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        font-size: 18px;
        font-weight: 600;
        color: #16c784;
        white-space: nowrap;
    }

    .online-dot,
    .offline-dot {
        width: 10px;
        height: 10px;
        min-width: 10px;
        border-radius: 50%;
        display: inline-block;
    }

    .online-dot {
        background: #16c784;
        animation: pulse 1.5s infinite;
    }

    .offline-dot {
        background: #adb5bd;
    }

    .offline-status {
        display: flex;
        flex-direction: column;
        gap: 3px;
    }

    .offline-main {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        color: #6c757d;
        font-size: 18px;
        font-weight: 600;
    }

    .last-seen {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        color: #8a94a6;
        font-size: 12px;
        font-weight: 500;
        white-space: nowrap;
    }

    .last-seen i {
        font-size: 11px;
    }

    .last-seen-time {
        color: #adb5bd;
        font-size: 11px;
        white-space: nowrap;
    }

    @keyframes pulse {

        0% {
            box-shadow: 0 0 0 0 rgba(22, 199, 132, .6);
        }

        70% {
            box-shadow: 0 0 0 8px rgba(22, 199, 132, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(22, 199, 132, 0);
        }
    }

    /*=========================================
    Progress
    =========================================*/

    .progress{
        height:7px;
        background:#edf1f7;
    }

    .progress-bar{
        border-radius:10px;
    }

    /*=========================================
    Skeleton
    =========================================*/

    .skeleton{
        height:20px;
        border-radius:6px;
        background:linear-gradient(
        90deg,
        #ececec 25%,
        #f5f5f5 37%,
        #ececec 63%
        );
        background-size:400% 100%;
        animation:loading 1.2s infinite;
    }

    @keyframes loading{

        0%{

            background-position:100% 0;

        }

        100%{

            background-position:-100% 0;

        }

    }

    .skeleton-circle{
        width:46px;
        height:46px;
        border-radius:50%;
    }

    .skeleton-row td{
        padding:16px;
    }

    /*=========================================
    Last Login
    =========================================*/

    .last-login{
        font-size:12px;
        color:#6c757d;
        line-height:20px;
    }

    /*=========================================
    Responsive
    =========================================*/

    @media(max-width:991px){
        .table-responsive{
            overflow-x:auto;
        }
        .department-tab{
            font-size:12px;
            padding:8px 15px;
        }
    }

    .staff-row{

    transition:.25s;

    }

    .staff-row:hover{

    transform:translateX(3px);

    background:#f8fbff;

    }

    .table-success{

    animation:flashRow .8s;

    }

    @keyframes flashRow{

    0%{

    background:#d1e7dd;

    }

    100%{

    background:transparent;

    }

    }

</style>


<style>

    #kt_modal_mapCallModal .modal-content {
        border: 0;
        border-radius: 16px;
        overflow: hidden;
        background: #f8fafc;
        box-shadow: 0 25px 80px rgba(15, 23, 42, 0.25);
    }

    .location-modal-header {
        min-height: 86px;
        padding: 15px 20px;
        background: #ffffff;
        border-bottom: 1px solid #e9edf3;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .location-staff-profile {
        display: flex;
        align-items: center;
        min-width: 0;
    }

    .staff-avatar-wrapper {
        width: 52px;
        height: 52px;
        position: relative;
        flex-shrink: 0;
    }

    .staffmap-avatar {
        width: 52px;
        height: 52px;
        object-fit: fill;
        border-radius: 50%;
        border: 2px solid #39484f;
        box-shadow: 0 3px 12px rgba(15, 23, 42, .15);
    }

    .staff-online-dot {
        position: absolute;
        right: 0;
        bottom: 1px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #22c55e;
        border: 2px solid #ffffff;
    }

    .staff-online-dot.offline {
        background: #94a3b8;
    }

    .staff-profile-details {
        margin-left: 12px;
        min-width: 0;
    }

    .staff-name {
        font-size: 17px;
        font-weight: 700;
        color: #172033;
        line-height: 1.3;
        max-width: 450px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .calls-badge {
        display: inline-flex;
        align-items: center;
        padding: 3px 8px;
        border-radius: 20px;
        background: #eef4ff;
        color: #2563eb;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
    }

    .staff-position {
        margin-top: 2px;
        color: #718096;
        font-size: 12px;
    }

    .staff-meta {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 3px;
        color: #64748b;
        font-size: 11px;
    }

    .staff-meta i {
        margin-right: 3px;
    }

    .meta-divider {
        color: #cbd5e1;
    }

    .location-close-btn {
        width: 36px;
        height: 36px;
        border: 0;
        border-radius: 9px;
        background: #f1f5f9;
        color: #64748b;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all .2s ease;
    }

    .location-close-btn:hover {
        background: #fee2e2;
        color: #dc2626;
    }

    .location-modal-body {
        /* padding: 14px; */
        background: #f8fafc;
    }

    .location-summary-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 10px;
        /* margin-bottom: 12px; */
    }

    .location-stat-card {
        min-height: 70px;
        background: #ffffff;
        border: 1px solid #e7ebf1;
        border-radius: 11px;
        padding: 11px;
        display: flex;
        align-items: center;
        transition: transform .2s ease, box-shadow .2s ease;
    }

    .location-stat-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 5px 18px rgba(15, 23, 42, .07);
    }

    .stat-icon {
        width: 38px;
        height: 38px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 20px;
    }

    .stat-icon-blue {
        color: #2563eb;
        background: #eff6ff;
    }

    .stat-icon-green {
        color: #059669;
        background: #ecfdf5;
    }

    .stat-icon-purple {
        color: #7c3aed;
        background: #f5f3ff;
    }

    .stat-icon-orange {
        color: #ea580c;
        background: #fff7ed;
    }

    .stat-icon-red {
        color: #dc2626;
        background: #fef2f2;
    }

    .stat-icon-yellow {
        color: #d97706;
        background: #fffbeb;
    }

    .stat-content {
        margin-left: 9px;
        min-width: 0;
    }

    .stat-label {
        font-size: 10px;
        color: #8490a5;
        font-weight: 600;
        white-space: nowrap;
    }

    .stat-value {
        margin-top: 1px;
        color: #172033;
        font-size: 17px;
        line-height: 1.2;
        font-weight: 750;
    }

    .stat-value-small {
        font-size: 12px;
    }
    .location-tracker-toolbar {
        min-height: 48px;
        padding: 8px 12px;
        background: #ffffff;
        border: 1px solid #e7ebf1;
    }

    .location-tracker-toolbar {
        position: sticky;
        top: 0;
        z-index: 1000;
        background: #fff;
        border-bottom: 1px solid #e9ecef;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        flex-shrink: 0;
    }

    .location-tracker-toolbar {
        isolation: isolate;
    }

    .tracker-title-section {
        display: flex;
        align-items: center;
        min-width: 0;
    }

    .tracker-title {
        color: #1e293b;
        font-size: 13px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 7px;
    }

    .tracker-title i {
        color: #2563eb;
        font-size: 18px;
    }

    .toolbar-divider {
        width: 1px;
        height: 18px;
        background: #dce2ea;
        margin: 0 10px;
    }

    .tracker-date-range {
        color: #8a94a6;
        font-size: 11px;
    }

    .tracker-actions {
        display: flex;
        gap: 6px;
    }

    .tracker-action-btn {
        width: 34px;
        height: 32px;
        border: 1px solid #e2e8f0;
        background: #ffffff;
        color: #64748b;
        border-radius: 7px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all .2s ease;
    }

    .tracker-action-btn:hover {
        color: #2563eb;
        border-color: #bfdbfe;
        background: #eff6ff;
    }

    .location-tracker-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 360px;
        height: calc(100vh - 300px);
        min-height: 450px;
        overflow: hidden;
        min-height: 0;
    }

    .location-map-panel {
        position: relative;
        min-width: 0;
        background: #e2e8f0;
    }

    .call-location-map {
        width: 100%;
        height: 100%;
        min-height: 500px;
        background: #e2e8f0;
    }

    .call-location-map.leaflet-container {
        font-family: inherit;
    }

    .map-overlay-top {
        position: absolute;
        top: 12px;
        left: 12px;
        right: 12px;
        z-index: 500;
        display: flex;
        justify-content: space-between;
        pointer-events: none;
    }

    .map-live-indicator,
    .map-coordinate-count {
        background: rgba(255, 255, 255, .94);
        border: 1px solid rgba(226, 232, 240, .9);
        border-radius: 8px;
        padding: 6px 9px;
        box-shadow: 0 3px 12px rgba(15, 23, 42, .12);
        font-size: 10px;
        font-weight: 600;
        color: #475569;
    }

    .map-live-indicator {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .live-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #22c55e;
        box-shadow: 0 0 0 3px rgba(34, 197, 94, .15);
    }

    .location-list-panel {
        background: #ffffff;
        border-left: 1px solid #e5eaf0;
        display: flex;
        flex-direction: column;
        min-width: 0;
    }

    .location-list-header {
        min-height: 60px;
        padding: 11px 13px;
        border-bottom: 1px solid #edf0f4;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .location-list-title {
        color: #1e293b;
        font-size: 13px;
        font-weight: 700;
    }

    .location-list-subtitle {
        color: #94a3b8;
        font-size: 10px;
        margin-top: 2px;
    }

    .location-list-count {
        min-width: 28px;
        height: 25px;
        padding: 0 7px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        background: #eff6ff;
        color: #2563eb;
        font-size: 11px;
        font-weight: 700;
    }

    .location-call-list {
        flex: 1;
        overflow-y: auto;
        padding: 5px;
    }

    .location-call-list::-webkit-scrollbar {
        width: 5px;
    }

    .location-call-list::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }

    .location-call-item {
        position: relative;
        padding: 10px;
        margin-bottom: 4px;
        border-radius: 9px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: all .2s ease;
    }

    .location-call-item:hover {
        background: #f8fafc;
        border-color: #e2e8f0;
    }

    .location-call-item.active {
        background: #eff6ff;
        border-color: #bfdbfe;
    }

    .location-call-top {
        display: flex;
        justify-content: space-between;
        gap: 7px;
    }

    .location-contact {
        color: #1e293b;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .location-time {
        color: #94a3b8;
        font-size: 9px;
        white-space: nowrap;
    }

    .location-call-phone {
        color: #64748b;
        font-size: 10px;
        margin-top: 2px;
    }

    .location-call-bottom {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 6px;
    }

    .call-status {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        padding: 3px 6px;
        border-radius: 20px;
        font-size: 9px;
        font-weight: 700;
    }

    .call-status.outgoing {
        background: #eff6ff;
        color: #2563eb;
    }

    .call-status.incoming {
        background: #ecfdf5;
        color: #059669;
    }

    .call-status.missed {
        background: #fef2f2;
        color: #dc2626;
    }

    .call-status.rejected {
        background: #fff7ed;
        color: #ea580c;
    }

    .call-status.dialed {
        background: #f8fafc;
        color: #64748b;
    }

    .call-duration {
        color: #94a3b8;
        font-size: 9px;
    }

    .call-map-marker {
        width: 38px;
        height: 38px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid #ffffff;
        /* box-shadow: 0 4px 12px rgba(15, 23, 42, .28); */
    }

    .call-map-marker i {
        transform: rotate(45deg);
        color: #ffffff;
        font-size: 18px;
    }

    .marker-blue {
        background: #2563eb;
    }

    .marker-green {
        background: #059669;
    }

    .marker-red {
        background: #dc2626;
    }

    .marker-orange {
        background: #ea580c;
    }

    .call-location-popup {
        min-width: 285px;
        max-width: 360px;
    }

    .call-location-popup .popup-header {
        display: flex;
        align-items: center;
        gap: 9px;
        padding-bottom: 9px;
        border-bottom: 1px solid #edf0f4;
    }

    .popup-staff-image {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        object-fit: cover;
    }

    .popup-header-name {
        font-weight: 700;
        font-size: 13px;
        color: #172033;
    }

    .popup-header-sub {
        color: #94a3b8;
        font-size: 9px;
        margin-top: 2px;
    }

    .popup-location-summary {
        margin-top: 9px;
        padding: 8px;
        border-radius: 8px;
        background: #f8fafc;
        display: flex;
        gap: 8px;
    }

    .popup-location-summary i {
        color: #2563eb;
        font-size: 17px;
    }

    .popup-location-title {
        font-weight: 700;
        font-size: 11px;
        color: #334155;
    }

    .popup-location-coordinates {
        color: #94a3b8;
        font-size: 9px;
        margin-top: 2px;
    }

    .popup-call-list {
        margin-top: 8px;
        max-height: 230px;
        overflow-y: auto;
    }

    .popup-call-row {
        padding: 8px 0;
        border-bottom: 1px solid #f1f5f9;
    }

    .popup-call-row:last-child {
        border-bottom: 0;
    }

    .popup-contact {
        font-size: 11px;
        font-weight: 700;
        color: #334155;
    }

    .popup-phone {
        font-size: 9px;
        color: #94a3b8;
    }

    .popup-call-meta {
        margin-top: 4px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .location-loading {
        min-height: 500px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: #ffffff;
        border-radius: 12px;
    }

    .location-loader {
        width: 38px;
        height: 38px;
        border: 3px solid #e2e8f0;
        border-top-color: #2563eb;
        border-radius: 50%;
        animation: locationSpin .8s linear infinite;
    }

    @keyframes locationSpin {
        to {
            transform: rotate(360deg);
        }
    }

    .loading-title {
        margin-top: 13px;
        font-size: 14px;
        font-weight: 700;
        color: #334155;
    }

    .loading-text {
        margin-top: 4px;
        font-size: 11px;
        color: #94a3b8;
    }

    .location-error {
        min-height: 180px;
        padding: 30px;
        background: #ffffff;
        border: 1px solid #fecaca;
        border-radius: 12px;
        display: flex;
        align-items: center;
    }

    .error-icon {
        width: 48px;
        height: 48px;
        margin-right: 14px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #fef2f2;
        color: #dc2626;
        font-size: 23px;
    }

    .error-title {
        color: #991b1b;
        font-size: 14px;
        font-weight: 700;
    }

    .error-message {
        color: #b91c1c;
        font-size: 11px;
        margin-top: 3px;
    }

    .location-empty {
        padding: 35px 15px;
        text-align: center;
        color: #94a3b8;
    }

    .location-empty i {
        font-size: 35px;
        display: block;
        margin-bottom: 8px;
        color: #cbd5e1;
    }

    .location-empty-title {
        color: #64748b;
        font-size: 12px;
        font-weight: 700;
    }

    @media (max-width: 1100px) {

        .location-summary-grid {
            grid-template-columns: repeat(3, 1fr);
        }

        .location-tracker-layout {
            grid-template-columns: 1fr;
            height: auto;
        }

        .location-map-panel {
            height: 500px;
        }

        .location-list-panel {
            height: 300px;
            border-left: 0;
            border-top: 1px solid #e5eaf0;
        }

    }

    @media (max-width: 768px) {

        .location-modal-header {
            padding: 12px;
        }

        .staff-name {
            max-width: 220px;
            font-size: 14px;
        }

        .staff-meta {
            display: none;
        }

        .location-summary-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .location-modal-body {
            /* padding: 8px; */
        }

        .tracker-date-range {
            display: none;
        }

        .toolbar-divider {
            display: none;
        }

        .location-map-panel {
            height: 420px;
        }

    }

    @media (max-width: 480px) {

        .location-summary-grid {
            grid-template-columns: 1fr 1fr;
            gap: 6px;
        }

        .location-stat-card {
            padding: 8px;
        }

        .stat-icon {
            width: 32px;
            height: 32px;
            font-size: 17px;
        }

        .stat-value {
            font-size: 14px;
        }

        .stat-label {
            font-size: 9px;
        }

    }

    .location-tracker-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 360px;
        height: calc(100vh - 300px);
        min-height: 450px;
        overflow: hidden;
        min-height: 0;
    }

    /* Map side */
    .location-tracker-map {
        min-width: 0;
        min-height: 0;
        height: 100%;
        overflow: hidden;
    }

    /* Call list side */
    .location-call-list {
        min-width: 0;
        min-height: 0;
        height: 100%;
        overflow-y: auto;
        overflow-x: hidden;
        border-left: 1px solid #e9ecef;
        background: #fff;
    }

    /* Better scrollbar */
    .location-call-list::-webkit-scrollbar {
        width: 6px;
    }

    .location-call-list::-webkit-scrollbar-track {
        background: transparent;
    }

    .location-call-list::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }

    .location-call-list::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
    }

    @media (max-width: 991px) {

        .location-tracker-layout {
            grid-template-columns: 1fr;
            height: calc(100vh - 330px);
        }

        .location-call-list {
            display: none;
        }

    }


    .location-tracker-layout {
        min-height: 0 !important;
        overflow: hidden !important;
    }

    /* Right side must not create the scroll itself */
    .location-list-panel {
        min-height: 0 !important;
        height: 100% !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
    }

    /* Header stays fixed */
    .location-list-header {
        flex: 0 0 auto !important;
    }

    /* ONLY THIS AREA SCROLLS */
    #locationCallList {
        flex: 1 1 auto !important;

        height: 0 !important;
        min-height: 0 !important;

        overflow-y: auto !important;
        overflow-x: hidden !important;

        padding: 5px !important;

        overscroll-behavior: contain;
        -webkit-overflow-scrolling: touch;
    }

    /* Scrollbar */
    #locationCallList::-webkit-scrollbar {
        width: 6px;
    }

    #locationCallList::-webkit-scrollbar-track {
        background: transparent;
    }

    #locationCallList::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }

    #locationCallList::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
    }

.location-tracker-map .leaflet-control-layers {
    border: 0;
    border-radius: 10px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    overflow: hidden;
}

.location-tracker-map .leaflet-control-layers-toggle {
    width: 38px;
    height: 38px;
    background-size: 20px 20px;
}

.location-tracker-map .leaflet-control-layers-expanded {
    padding: 10px 12px;
    font-size: 12px;
    font-weight: 500;
}

.location-tracker-map .leaflet-control-layers label {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 6px;
    cursor: pointer;
}

.location-tracker-map .leaflet-control-layers label:last-child {
    margin-bottom: 0;
}

.call-location-status {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 2px 6px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 600;
    line-height: 1.4;
    white-space: nowrap;
}

.call-location-status.available {
    color: #087f5b;
    background: #e6fcf5;
    border: 1px solid #b2f2df;
}

.call-location-status.unavailable {
    color: #868e96;
    background: #f1f3f5;
    border: 1px solid #dee2e6;
}


</style>


<div class="container-fluid">
    <div class="location-filter-card">
        <div class="location-filter-header">
            <div class="location-filter-title">
                <div class="location-filter-title-icon">
                    <i class="mdi mdi-phone-forward text-primary me-2"></i>
                </div>
                <div class="">
                    <h4>
                        CUG Call Monitor
                    </h4>
                    <small>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                                </li>
                                <span class="text-dark opacity-75 me-1 ms-1">
                                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                                </span>
                                <li class="breadcrumb-item">
                                    <a href="javascript:;" class="d-flex align-items-center">Team Management</a>
                                </li>
                            </ol>
                        <nav>
                    </small>
                </div>
            </div>
            <div class="location-filter-actions">
                <button  type="button" class="location-filter-btn btn btn-sm shadow-none border border-primary bg-primary text-white" id="btnRefresh" >
                    <i class="mdi mdi-refresh"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Min Dashboard -->
    <div class="row g-3 mb-4">
        <div class="col-lg-3">
            <div class="monitor-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5>Online Staff</h5>
                        <h2 id="onlineCount">0</h2>
                    </div>
                    <div class="monitor-icon bg-online">
                        <i class="mdi mdi-wifi"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="monitor-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5>Offline Staff</h5>
                        <h2 id="offlineCount">0</h2>
                    </div>
                    <div class="monitor-icon bg-offline">
                        <i class="mdi mdi-wifi-off"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="monitor-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5>Total Calls</h5>
                        <h2 id="totalCalls">0</h2>
                    </div>
                    <div class="monitor-icon bg-call">
                        <i class="mdi mdi-phone"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="monitor-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5>Missed Calls</h5>
                        <h2 id="missedCalls">0</h2>
                    </div>
                    <div class="monitor-icon bg-missed">
                        <i class="mdi mdi-phone-remove"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Department Tabs -->
    <div class="department-tabs" id="departmentTabs"> </div>

    <div class="monitor-toolbar ">
        <div class="row g-2 mb-4">
            <div class="col-lg-4">
                <input type="text" id="searchStaff" class="form-control"  placeholder="Search staff, mobile..." >
            </div>
            <div class="col-lg-2">
                <select id="onlineFilter" class="form-select select3">
                    <option value="">All Status</option>
                    <option value="1">Online</option>
                    <option value="0">Offline</option>
                </select>
            </div>
            <div class="col-lg-2">
                <input type="text" id="monthFilter" class="form-control month_filter_common_class" value="{{date('M-Y')}}" readonly>
            </div>
            <div class="col-lg-2">
                <button class="btn btn-primary w-100" id="btnSearch"><i class="mdi mdi-magnify"></i>Search</button>
            </div>
            <div class="col-lg-2">
                <button class="btn btn-light w-100" id="btnReset">Reset</button>
            </div>
        </div>
   
        <div class="table-responsive" id="staffTableWrapper">
            <table class="table table-monitor align-middle table-row-dashed table-striped table-hover gy-1 gs-2">
                <thead>
                    <tr  class="text-start  fw-bold fs-6 gs-0 bg-primary text-white">
                        <th style="min-width:260px;">Staff</th>
                        <th>Status</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Incoming Call">IC</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Outgoing Call">OC</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Missed Call">MC</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Rejected Call">RC</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Dialed Call">DC</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Outgoing Call Rate">OCR</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Recieved Call Rate">RCR</th>
                        <th class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Missed Call Rate">MCR</th>
                        <th>Last Call At</th>
                        @if(auth()->user()->hasPermission($module_name, 'Location', $menu_name))
                            <th class="min-w-50px px-1">Location</th>
                        @endif
                    </tr>
                </thead>
                <tbody id="staffTableBody">
                {{-- AJAX Skeleton Here --}}
                </tbody>
            </table>
        </div>
    </div>

</div>




<div class="modal fade" id="kt_modal_mapCallModal" tabindex="-1" aria-labelledby="mapCallModal" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-fullscreen-xl-down modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0 pt-0 px-0">
                <div class="location-modal-header W-100 pt-5">
                    <div class="location-staff-profile">
                        <div class="staff-avatar-wrapper">
                            <img id="map_staff_image" src="" alt="Staff" class="staffmap-avatar" onerror="this.src='{{ asset('assets/eapl_images/user_1.png') }}'">
                            <span id="map_staff_online" class="staff-online-dot"></span>
                        </div>
                        <div class="staff-profile-details">
                            <div class="d-flex align-items-center gap-2">
                                <h5 id="map_staff_name" class="staff-name mb-0">
                                    Loading...
                                </h5>
                                <span id="map_staff_call_badge" class="calls-badge">
                                    0 Calls
                                </span>
                            </div>
                            <div id="map_staff_position" class="staff-position" >
                                Loading staff details...
                            </div>
                            <div class="staff-meta">
                                <span>
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span id="map_staff_mobile">-</span>
                                </span>
                                <span class="meta-divider">•</span>
                                <span>
                                    <i class="mdi mdi-office-building-outline"></i>
                                    <span id="map_staff_department">-</span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="location-close-btn" data-bs-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
            </div>
            <div class="modal-body pt-0 pb-0 px-0 px-xl-0">
                <div class="location-modal-body">
                    <div id="locationMapLoading" class="location-loading" >
                        <div class="location-loader"></div>
                        <div class="loading-title">
                            Loading call locations
                        </div>
                        <div class="loading-text">
                            Please wait while we prepare the location tracker...
                        </div>
                    </div>
                    <div id="locationMapError" class="location-error d-none" >
                        <div class="error-icon">
                            <i class="mdi mdi-map-marker-off-outline"></i>
                        </div>
                        <div>
                            <div class="error-title">
                                Unable to load locations
                            </div>
                            <div id="locationMapErrorText" class="error-message">
                                Something went wrong.
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-danger ms-auto" onclick="retryLocationTracker()" >
                            <i class="mdi mdi-refresh"></i>
                            Retry
                        </button>
                    </div>
                    <!-- Main Content -->
                    <div id="locationMapContent" class="d-none" >
                        <div class="location-tracker-toolbar">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="tracker-title-section">
                                    <div class="tracker-title">
                                        <i class="mdi mdi-map-outline"></i>
                                        <span>
                                            Call Location Tracker
                                        </span>
                                    </div>
                                    <span class="toolbar-divider"></span>
                                    <span id="map_date_range"  class="tracker-date-range" >
                                        -
                                    </span>
                                </div>
                                <div class="tracker-actions">
                                    <button type="button"  class="tracker-action-btn" onclick="fitAllCallLocations()" title="Fit all locations" >
                                        <i class="mdi mdi-fit-to-screen-outline"></i>
                                    </button>

                                    <button
                                        type="button"
                                        class="tracker-action-btn"
                                        onclick="refreshLocationTracker()"
                                        title="Refresh locations"
                                    >
                                        <i class="mdi mdi-refresh"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="location-summary-grid">
                                <!-- Locations -->
                                <div class="location-stat-card">
                                    <div class="stat-icon stat-icon-blue">
                                        <i class="mdi mdi-map-marker-radius"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Locations
                                        </div>
                                        <div id="map_unique_locations" class="stat-value" >
                                            0
                                        </div>
                                    </div>
                                </div>
                                <div class="location-stat-card">
                                    <div class="stat-icon stat-icon-green">
                                        <i class="mdi mdi-phone-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Total Calls
                                        </div>
                                        <div id="map_total_calls" class="stat-value">
                                            0
                                        </div>
                                    </div>
                                </div>
                                 <!-- Outgoing -->
                                <div class="location-stat-card">
                                    <div class="stat-icon stat-icon-orange">
                                        <i class="mdi mdi-phone-outgoing-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Outgoing
                                        </div>
                                        <div id="map_outgoing_calls" class="stat-value">
                                            0
                                        </div>
                                    </div>
                                </div>
                                <!-- Incoming -->
                                <div class="location-stat-card">
                                    <div class="stat-icon stat-icon-purple">
                                        <i class="mdi mdi-phone-incoming-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Incoming
                                        </div>
                                        <div id="map_incoming_calls" class="stat-value" >
                                            0
                                        </div>
                                    </div>
                                </div>

                               
                                <!-- Missed -->
                                <div class="location-stat-card">
                                    <div class="stat-icon stat-icon-red">
                                        <i class="mdi mdi-phone-missed-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Missed
                                        </div>
                                        <div id="map_missed_calls" class="stat-value" >
                                            0
                                        </div>
                                    </div>
                                </div>
                                <!-- Last Call -->
                                <div class="location-stat-card last-call-card">
                                    <div class="stat-icon stat-icon-yellow">
                                        <i class="mdi mdi-clock-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">
                                            Last Call
                                        </div>
                                        <div id="map_last_call" class="stat-value stat-value-small" >
                                            -
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="location-tracker-layout">
                            <!-- MAP -->
                            <div class="location-map-panel">
                                <div id="callMap" class="call-location-map"></div>
                                <!-- Map Overlay -->
                                <div class="map-overlay-top">
                                    <div class="map-live-indicator">
                                        <span class="live-dot"></span>
                                        <span> Location Tracking</span>
                                    </div>
                                    <div id="map_coordinate_count" class="map-coordinate-count">
                                        0 coordinates
                                    </div>
                                </div>
                            </div>
                            <!-- LOCATION LIST -->
                            <div class="location-list-panel">
                                <div class="location-list-header">
                                    <div>
                                        <div class="location-list-title">
                                            Call Locations
                                        </div>
                                        <div class="location-list-subtitle">
                                            Latest activity first
                                        </div>
                                    </div>
                                    <span id="map_location_list_count" class="location-list-count" >
                                        0
                                    </span>
                                </div>
                                <div  id="locationCallList" class="location-call-list"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
     let locationCheck =@json($location_check);
</script>

<script>

"use strict";

/*==========================================================
    CUG Call Monitor
==========================================================*/



const CUGMonitor = {
    /*---------------------------------------
        API
    ---------------------------------------*/
    api:{
        departments:"{{ route('ajax.cug.monitor.departments') }}",
        staffList:"{{ route('ajax.cug.monitor.list') }}"
    },
    currentXHR:null,
    lastResponse:null,
    rowCache:{},

    requestId:0,

    currentRequestId:0,
    /*---------------------------------------
        Current State
    ---------------------------------------*/
    state:{
        department_id:"",
        search:"",
        online:"",
        month_filter: "{{ now()->format('M-Y') }}",
        month:"{{ now()->format('m') }}",
        year:"{{ now()->format('Y') }}",
        page:1,
        limit:50,
        sort:"staff_name",
        direction:"asc",
        isAppending:false,
        hasMore:true,
        loading:false,
        autoRefresh:null
    },
    /*---------------------------------------
        Cache Selectors
    ---------------------------------------*/
    ui:{

    },

    /*---------------------------------------
        Initialize
    ---------------------------------------*/
    init:function(){
        this.cacheDom();
        this.bindEvents();
        this.loadDepartments();
        this.startRefresh();
    },
    cacheDom:function(){
        this.ui.body=$("#staffTableBody");
        this.ui.wrapper=$("#staffTableWrapper");
        this.ui.tabs=$("#departmentTabs");
        this.ui.search=$("#searchStaff");
        this.ui.filter=$("#onlineFilter");
        this.ui.month=$("#monthFilter");
        this.ui.refresh=$("#btnRefresh");
        this.ui.searchBtn=$("#btnSearch");
        this.ui.reset=$("#btnReset");
        this.ui.onlineCount=$("#onlineCount");
        this.ui.offlineCount=$("#offlineCount");
        this.ui.totalCalls=$("#totalCalls");
        this.ui.missedCalls=$("#missedCalls");
    },

    loadFiltersFromUrl: function () {

        const url = new URL(window.location);

        this.state.department_id =
            url.searchParams.get("department") ?? "";

        this.state.search =
            url.searchParams.get("search") ?? "";

        this.state.online =
            url.searchParams.get("online") ?? "";

        this.state.month_filter =
            url.searchParams.get("month_filter")
            ?? this.ui.month.val()
            ?? "{{ now()->format('M-Y') }}";

    },
   
    // loadFiltersFromUrl:function(){
    //     let url=new URL(window.location);
    //     this.state.department_id=url.searchParams.get("department") ?? "";
    //     this.state.search=url.searchParams.get("search") ?? "";
    //     this.state.online=url.searchParams.get("online") ?? "";
    // },
    // loadFiltersFromUrl:function(){
    //     let url=new URL(window.location);
    //     this.state.department_id=url.searchParams.get("department") ?? "";
    //     this.state.search=url.searchParams.get("search") ?? "";
    //     this.state.online=url.searchParams.get("online") ?? "";
    // },
    bindEvents:function(){
        this.bindSearch();
        this.bindSearchButton();
        this.bindStatusFilter();
        this.bindMonth();
        this.bindRefresh();
        this.bindReset();
    },
    bindMonth:function(){

        const self = this;

        self.ui.month.off("change.cugMonitor");

        self.ui.month.on("change.cugMonitor", function () {

            const selectedMonth = $(this).val();

            if (!selectedMonth) {
                return;
            }

            self.state.month_filter = selectedMonth;

            const url = new URL(window.location);
            url.searchParams.set("month_filter", selectedMonth);
            window.history.replaceState({}, "", url);

            self.state.page = 1;
            self.state.hasMore = true;
            self.state.isAppending = false;

            self.reload();

        });

        // let self = this;

        // self.ui.month.off("change");

        // self.ui.month.on("change", function(){

        //     self.state.page = 1;

        //     self.loadStaff();

        // });

    },
    debounceTimer:null,
    search:function(){
        let self=this;
        clearTimeout(self.debounceTimer);

        self.debounceTimer=setTimeout(function(){
            self.state.search=self.ui.search.val();
            self.reload();
        },400);

    },
    bindReset:function(){

        let self=this;
        self.ui.reset.off("click");
        self.ui.reset.on("click",function(){
          
            self.reset();
        });

    },
    
    reset:function(){
        let self=this;
        self.ui.search.val("");
        self.ui.filter.val("");
        self.ui.month.val("{{ now()->format('Y-m') }}");
        self.state.search="";
        self.state.online="";
        self.state.department_id="";
        self.state.month="{{ now()->format('m') }}";
        self.state.year="{{ now()->format('Y') }}";
        self.state.page=1;
        $(".department-tab").removeClass("active");
        $(".department-tab:first").addClass("active");
        self.loadStaff();
    },
    reload: function () {

        this.state.page = 1;
        this.state.hasMore = true;
        this.state.isAppending = false;

        this.rowCache = {};

        this.ui.body.empty();

        this.loadStaff();

    },
    // reload:function(){
    //     this.loadStaff();
    // },
    bindSearchButton:function(){

        let self=this;

        self.ui.searchBtn.off("click");

        self.ui.searchBtn.on("click",function(){

            self.state.search=$.trim(self.ui.search.val());

            self.state.page=1;

            self.loadStaff();

        });

    },
    bindRefresh:function(){

        let self=this;

        self.ui.refresh.off("click");
       

        self.ui.refresh.on("click",function(){

            self.loadStaff(false);

        });
      

    },
    
    
    showSkeleton:function(rows=8){

        let html="";
        for(let i=0;i<rows;i++){
            html+=`
            <tr class="skeleton-row">
                <td>
                    <div class="d-flex">
                        <div class="skeleton skeleton-circle me-3"></div>
                        <div class="w-100">
                            <div class="skeleton mb-2" style="height:15px;width:160px">
                            </div>
                            <div class="skeleton" style="height:12px;width:100px">
                            </div>
                        </div>
                    </div>
                </td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                <td><div class="skeleton"></div></td>
                ${locationCheck == 1 ? '<td><div class="skeleton"></div></td>': ''}
                
            </tr>
            `;
        }

        this.ui.body.html(html);

        // const tbody=self.ui.body;

        // tbody.innerHTML=html;
    },
    empty:function(){

        this.ui.body.html(`
            <tr>
                <td colspan="11">
                    <div class="text-center py-5">

                        <i class="mdi mdi-magnify fs-1 text-secondary"></i>

                        <h5 class="mt-3">

                        No Matching Staff

                        </h5>

                        <p class="text-muted">

                        Try changing filters

                        </p>

                    </div>
                </td>
            </tr>
        `);

    },

    error:function(message="Unable to load data"){
        this.ui.body.html(`
            <tr>
                <td colspan="11">
                    <div class="alert alert-danger">
                        ${message}
                    </div>
                </td>
            </tr>
        `);
    },
    // startRefresh:function(){
    //     let self=this;

    //     if(self.state.autoRefresh!=null){
    //         clearInterval(self.state.autoRefresh);
    //     }

    //     self.state.autoRefresh=setInterval(function(){
    //         self.loadStaff(false);
    //     },20000);
    // },
    startRefresh:function(){

        clearInterval(this.state.autoRefresh);

        const interval=document.hidden ? 60000 : 20000;

        this.state.autoRefresh=setInterval(()=>{

            this.loadStaff(false);

        },interval);

    },
    number:function(value){
        return parseInt(value||0).toLocaleString();
    },

    percent:function(value){
        return parseFloat(value||0).toFixed(1)+"%";
    },

    badge:function(status,lastOfflineDate,lastOfflineTime,lastOfflineDuration){
        if(status==1){
            return `
            <span class="online-badge ">
                <span class="online-dot"></span>
                Online
            </span>
            `;
        }

        if (lastOfflineDate && lastOfflineTime) {

            return `
                <div class="offline-status">

                    <div class="offline-main">
                        <span class="offline-dot"></span>
                        <span>Offline</span>
                    </div>

                    <div class="last-seen">
                        <i class="mdi mdi-clock-outline"></i>
                        <span>
                            Last seen ${this.escapeHtml(lastOfflineDuration || 'recently')}
                        </span>
                    </div>

                    <div class="last-seen-time">
                        ${this.escapeHtml(lastOfflineDate)}
                        <span class="mx-1">•</span>
                        ${this.escapeHtml(lastOfflineTime)}
                    </div>

                </div>
            `;

        }
        return `
            <div class="offline-status">

                <div class="offline-main">
                    <span class="offline-dot"></span>
                    <span>Offline</span>
                </div>

                <div class="last-seen">
                    <i class="mdi mdi-clock-outline"></i>
                    <span>Last seen unavailable</span>
                </div>

            </div>
        `;
    },
    escapeHtml: function (value) {

        if (value === null || value === undefined) {
            return '';
        }

        return $('<div>')
            .text(String(value))
            .html();
    },
    loadDepartments: function () {

        let self = this;

        self.ui.tabs.html(self.departmentSkeleton());

        $.ajax({
            url: self.api.departments,
            type: "GET",
            dataType: "json",
            success: function (response) {
                if (response.status) {
                    self.renderDepartments(response.data);
                    self.loadStaff();
                } else {
                    self.ui.tabs.html("");
                }
            },
            error: function () {
                self.ui.tabs.html("");
            }
        });
    },
    departmentSkeleton: function () {
        let html = "";
        for (let i = 0; i < 6; i++) {
            html += `
            <div class="department-tab">
                <div class="placeholder-glow">
                    <span class="placeholder col-12"></span>
                </div>
            </div>
            `;
        }
        return html;
    },
    renderDepartments: function (departments) {

        let html = "";
        let totalStaff = 0;
        let totalOnline = 0;

        departments.forEach(function (item) {
            totalStaff += Number(item.staff_count);
            totalOnline += Number(item.online_count ?? 0);
        });
        html += `

        <div class="department-tab active"
            data-id="">
            <div class="fw-bold">
                All
            </div>
            <small>
                ${totalStaff} Staff
            </small>
        </div>

        `;

        departments.forEach(function (item) {

            html += `

            <div class="department-tab" data-id="${item.department_id}">
                <div class="fw-bold max-w-150px text-truncate" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="${item.department_name}">
                    ${item.department_name}
                </div>
                <small>
                    ${item.staff_count} Staff
                </small>
            </div>

            `;

        });

        this.ui.tabs.html(html);
        this.bindDepartmentEvents();

    },
    bindDepartmentEvents: function () {

        let self = this;

        self.ui.tabs.find(".department-tab").off("click");

        self.ui.tabs.find(".department-tab").on("click", function () {

            self.ui.tabs.find(".department-tab").removeClass("active");

            $(this).addClass("active");

            self.state.department_id = $(this).data("id");

            self.state.page = 1;

            self.loadStaff();

        });

    },

    tabLoading: function () {

        this.ui.tabs.find(".department-tab")

            .css("pointer-events", "none");

    },
    tabLoaded: function () {

        this.ui.tabs.find(".department-tab")

            .css("pointer-events", "auto");

    },
    loadStaff:function(showLoader=true){

        const requestId = ++this.requestId;

        this.currentRequestId = requestId;

        let self=this;

        if(self.state.loading)
            return;

        if(self.currentXHR){
            self.currentXHR.abort();
        }

        self.state.loading=true;

        if(showLoader){
            self.showSkeleton();
        }

        self.currentXHR=$.ajax({

            url:self.api.staffList,

            type:"GET",

            dataType:"json",

            data:{

                department_id:self.state.department_id,

                search:self.state.search,

                online:self.state.online,

                month_filter: self.state.month_filter,

                month:self.state.month,

                year:self.state.year,

                page:self.state.page,

                limit:self.state.limit

            },

            success:function(response){

                self.state.loading=false;

                if(requestId !== self.currentRequestId){
                    return;
                }

                if(!response.status){

                    self.error();

                    return;

                }

                self.lastResponse=response;

                self.updateCards(response.summary);

                if(self.state.isAppending){

                    self.appendRows(response.data);

                }else{

                    self.renderTable(response.data);

                }

                self.state.hasMore=response.pagination.has_more;
                
                // self.updateUrl();


            },
            

            error:function(xhr){

                self.state.loading=false;

                if(xhr.statusText==="abort"){
                    return;
                }

                self.error();

            }

        });

    },

    appendRows:function(rows){

        let html="";

        rows.forEach((row)=>{

            html+=this.buildRow(row);

        });

        this.ui.body.append(html);

        this.initializeTooltips();

        this.state.isAppending=false;

    },

    showEndMessage:function(){

        this.ui.body.append(`

        <tr>

            <td colspan="11">

                <div class="text-center text-muted py-3">

                    All staff loaded

                </div>

            </td>

        </tr>

        `);

    },

    showBottomLoader:function(){

        if($("#bottomLoader").length)
            return;

        this.ui.body.append(`

        <tr id="bottomLoader">

            <td colspan="11">

                <div class="text-center py-3">

                    <div class="spinner-border spinner-border-sm"></div>

                    Loading more...

                </div>

            </td>

        </tr>

        `);

    },

    loadingButton:function(btn){

        btn.prop("disabled",true);

        btn.html(

            '<span class="spinner-border spinner-border-sm me-2"></span>Loading'

        );

    },

    normalButton:function(btn,text){

        btn.prop("disabled",false);

        btn.html(text);

    },
    highlight:function(text){

        if(this.state.search==="")
            return text;

        let regex=new RegExp(this.state.search,"gi");

        return text.replace(

            regex,

            function(match){

                return "<mark>"+match+"</mark>";

            }

        );

    },
    updateCards:function(summary){

        if(!summary){

            return;

        }

        this.ui.onlineCount.text(

            this.number(summary.online)

        );

        this.ui.offlineCount.text(

            this.number(summary.offline)

        );

        this.ui.totalCalls.text(

            this.number(summary.total_calls)

        );

        this.ui.missedCalls.text(

            this.number(summary.missed)

        );

    },
    renderTable:function(rows){

            if(rows.length==0){

                this.empty();

                return;

            }

            let html="";

            rows.forEach((row)=>{

                html+=this.buildRow(row);

            });

            this.ui.body.html(html);

            this.initializeTooltips();

        },
    // renderTable:function(rows){

    //     if(rows.length===0){

    //         this.empty();

    //         return;

    //     }

    //     const tbody=self.ui.body[0];

    //     const existing={};

    //     tbody.querySelectorAll("tr[data-id]").forEach(function(tr){

    //         existing[tr.dataset.id]=tr;

    //     });

    //     const receivedIds=[];

    //     rows.forEach((row)=>{

    //         receivedIds.push(String(row.staff_id));

    //         this.renderSingleRow(row,existing);

    //     });

    //     Object.keys(existing).forEach((id)=>{

    //         if(!receivedIds.includes(id)){

    //             existing[id].remove();

    //             delete this.rowCache[id];

    //         }

    //     });

    // }.bind(this),
    renderSingleRow:function(row,existing){

        const id=String(row.staff_id);

        const html=this.buildRow(row);

        // const hash=JSON.stringify(row);
        const hash=this.rowHash(row);

        if(this.rowCache[id]===hash){

            return;

        }

        this.rowCache[id]=hash;

        if(existing[id]){

            existing[id].outerHTML=html;

            this.highlightRow(id);

        }else{

            this.ui.body.append(html);

        }

    },
    rowHash:function(row){

        return [

            row.online_status,

            row.incoming,

            row.outgoing,

            row.missed,

            row.rejected,

            row.dialed,

            row.last_login_date,

            row.last_login_time

        ].join("|");

    },
    updateCounter:function(row){

        const tr=$("tr[data-id='"+row.staff_id+"']");

        tr.find(".incoming").text(row.incoming);

        tr.find(".outgoing").text(row.outgoing);

        tr.find(".missed").text(row.missed);

    },
    initializeTooltips:function(){

        let tooltipTriggerList=[].slice.call(

            document.querySelectorAll(

                '[data-bs-toggle="tooltip"]'

            )

        );

        tooltipTriggerList.map(function(el){

            return new bootstrap.Tooltip(el);

        });

    },
    escape:function(text){

        return $("<div>")

        .text(text??"")

        .html();

    },
    formatDate:function(date,time){

        if(!date){

            return "-";

        }

        return `

        <div class="last-login">

            <div>${date}</div>

            <div>${time}</div>

        </div>

        `;

    },

    bindSearch:function(){

        let self=this;

        let timer=null;

        self.ui.search.off("keyup");

        self.ui.search.on("keyup",function(){

            clearTimeout(timer);

            timer=setTimeout(function(){

                self.state.search=$.trim(self.ui.search.val());

                self.state.page=1;

                self.loadStaff();

            },350);

        });

    },
    bindStatusFilter:function(){

        let self=this;

        self.ui.filter.off("change");

        self.ui.filter.on("change",function(){

            self.state.online=$(this).val();

            self.state.page=1;

            self.loadStaff();

        });

    },

    bindStatusFilter:function(){

        let self=this;

        self.ui.filter.off("change");

        self.ui.filter.on("change",function(){

            self.state.online=$(this).val();

            self.state.page=1;

            self.loadStaff();

        });

    },
    

    progress:function(value,color){

        value=parseFloat(value);

        if(isNaN(value))
            value=0;

        return `

        <div>

            <div class="progress">

                <div

                class="progress-bar bg-${color}"

                style="width:${value}%">

                </div>

            </div>

            <small>

                ${value.toFixed(1)}%

            </small>

        </div>

        `;

    },
    status:function(status){

        if(status==1){
            return `
            <span class="online-badge">
                <span class="online-dot"></span>
                Online
            </span>

            `;

        }

        return `
        <span class="text-secondary">
            <span class="offline-dot"></span>
            Offline
        </span>

        `;

    },
    serial:function(index){

        return (

            ((this.state.page-1)*50)

            +index

            +1

        );

    },
    buildRow:function(row){

        // const name=this.escape(row.staff_name);
        const name=this.highlight(
            this.escape(row.staff_name)
        );

        const mobile=this.escape(row.cug_mobile ?? '');

        const designation=this.escape(row.job_position_name ?? '');

        const avatar=this.buildAvatar(row);

        const statusBadge=this.staffStatusBadge(row.staff_status);

        const online = this.badge(
                    row.last_checking_status,
                    row.last_live_date,
                    row.last_live_time,
                    row.last_live_duration
                );
                let lastCallDuration = row.last_call_duration;

        const lastCall = row.last_call_date && row.last_call_time
                ? `
                    <div class="last-call-info">
                        <div class="last-call-label">
                            <i class="mdi mdi-phone-outline"></i>
                             Last Call ${this.escapeHtml(lastCallDuration || '-')}
                        </div>

                        <div class="last-call-time">
                            ${row.last_call_date}
                            <span class="mx-1">•</span>
                            ${row.last_call_time}
                        </div>
                    </div>
                `
                : `
                    <div class="last-call-info text-muted">
                        <div class="last-call-label">
                            <i class="mdi mdi-phone-off-outline"></i>
                            No Calls
                        </div>
                    </div>
                `;

        return `

        <tr
            class="staff-row"
            data-id="${row.staff_id}">

            <!-- Staff Information -->

            <td class="min-w-300px">

                <div class="d-flex align-items-center">

                    ${avatar}

                    <div class="ms-3 flex-grow-1">

                        <a
                            href="javascript:void(0)"
                            class="text-decoration-none"
                            onclick="openCallHistoryModal(
                                '${row.staff_id}',
                                '${name}',
                                '${mobile}',
                                '${this.state.month}',
                                '${this.state.year}'
                            )">

                            <div
                                class="fw-bold text-dark">

                                ${name}

                            </div>

                        </a>

                        <div
                            class="text-primary small mt-1">

                            <i class="mdi mdi-phone me-1"></i>

                            ${mobile}

                        </div>

                        <div class="mt-2">

                            <span
                                class="badge bg-info">

                                ${designation}

                            </span>

                            ${statusBadge}

                        </div>

                    </div>

                </div>

            </td>

            <!-- Online Status -->

            <td class="status-cell">

                ${online}

            </td>

            <!-- Incoming -->

            <td class="text-center fw-bold incoming ">

                ${this.number(row.incoming)}

            </td>

            <!-- Outgoing -->

            <td class="text-center fw-bold outgoing ">

                ${this.number(row.outgoing)}

            </td>

            <!-- Missed -->

            <td class="text-center missed ">

                <span class="badge bg-warning text-dark">

                    ${this.number(row.missed)}

                </span>

            </td>

            <!-- Rejected -->

            <td class="text-center">

                <span class="badge bg-danger ">

                    ${this.number(row.rejected)}

                </span>

            </td>

            <!-- Dialed -->

            <td class="text-center">

                <span class="badge bg-secondary">

                    ${this.number(row.dialed)}

                </span>

            </td>

            <!-- OCR -->

            <td class="text-center">
                ${this.number(row.ocr)}
            </td>

            <!-- RCR -->

            <td class="text-center">
             ${this.number(row.rcr)}

            </td>

            <!-- MCR -->

            <td class="text-center">
                ${this.number(row.mcr)}

            </td>

            <!-- Last Login -->

            <td>

                ${lastCall}

            </td>
            ${locationCheck == 1 ? 
                `<td>
                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_mapCallModal" class="border border-gray-400 rounded px-1 py-2 location-track-btn"   onclick="multi_location_view('${row.staff_id}', '${escapeHtml(row.staff_name || row.name || 'Staff')}','${row.encrypted_id}')">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Location"> <i class="mdi mdi-map-marker-radius text-primary fs-4"></i></span>
                    </a>
                </td>`
                : ''
            }
            

        </tr>

        `;

    },
    buildAvatar:function(row){

        let image=row.staff_image ?? "";

        image=image.trim();

        if(image!=""){

            return `

            <div class="symbol symbol-45px">

                <img

                    src="/staff_images/${image}"

                    class="rounded-circle w-50px h-50px"

                    loading="lazy"

                   

                >

            </div>

            `;

        }

        return this.avatarFallback(row);

    },
    avatarFallback:function(row){

        const name=(row.staff_name ?? "A").trim();

        const letter=name.substring(0,1).toUpperCase();

        const gender=row.gender ?? "";

        let color="primary";

        switch(gender){

            case "Female":

                color="danger";

            break;

            case "Male":

                color="primary";

            break;

            default:

                color="secondary";

        }

        return `

        <div
            class="symbol symbol-45px">

            <div
                class="rounded-circle
                bg-${color}
                text-white
                d-flex
                align-items-center
                justify-content-center
                fw-bold"

                style="width:45px;height:45px;">

                ${letter}

            </div>

        </div>

        `;

    },
    staffStatusBadge:function(status){

        switch(parseInt(status)){

            case 4:

                return `

                <span
                    class="badge bg-warning text-dark ms-2">

                    Notice Period

                </span>

                `;

            case 5:

                return `

                <span
                    class="badge bg-info ms-2">

                    Relieved

                </span>

                `;

            case 6:

                return `

                <span
                    class="badge bg-secondary ms-2">

                    Abscond

                </span>

                `;

            case 7:

                return `

                <span
                    class="badge bg-danger ms-2">

                    Terminated

                </span>

                `;

            default:

                return "";

        }

    },
    // formatDate:function(date,time){

    //     if(!date){

    //         return "-";

    //     }

    //     let today=moment().format("YYYY-MM-DD");

    //     let yesterday=moment()

    //         .subtract(1,"day")

    //         .format("YYYY-MM-DD");

    //     let label=date;

    //     if(date==today){

    //         label="Today";

    //     }
    //     else if(date==yesterday){

    //         label="Yesterday";

    //     }

    //     return `

    //     <div class="last-login">

    //         <div class="fw-semibold">

    //             ${label}

    //         </div>

    //         <small>

    //             ${time}

    //         </small>

    //     </div>

    //     `;

    // },

    progress:function(value,color){

        value=parseFloat(value);

        if(isNaN(value))
            value=0;

        let cls="bg-success";

        switch(color){

            case "primary":

                cls="bg-primary";

            break;

            case "warning":

                cls="bg-warning";

            break;

            case "danger":

                cls="bg-danger";

            break;

        }

        return `

        <div style="min-width:70px;">

            <div class="progress">

                <div

                    class="progress-bar

                    ${cls}"

                    style="width:${value}%">

                </div>

            </div>

            <div
                class="text-center
                small
                mt-1">

                ${value.toFixed(1)}%

            </div>

        </div>

        `;

    },
    highlightRow:function(id){

        const row=$("tr[data-id='"+id+"']");

        row.addClass("table-success");

        setTimeout(function(){

            row.removeClass("table-success");

        },1200);

    },
    avatarCache:{},
    bindInfiniteScroll:function(){

        let self=this;

        self.ui.wrapper.off("scroll");

        self.ui.wrapper.on("scroll",function(){

            if(self.state.loading)
                return;

            if(!self.state.hasMore)
                return;

            const container=this;

            const scrollPosition=
                container.scrollTop+
                container.clientHeight;

            const threshold=
                container.scrollHeight-150;

            if(scrollPosition>=threshold){

                self.loadNextPage();

            }

        });

    },
    loadNextPage:function(){

        if(this.state.loading)
            return;

        if(!this.state.hasMore)
            return;

        this.state.page++;

        this.state.isAppending=true;

        this.loadStaff(false);

    },
};

$(function(){
    CUGMonitor.init();
});

</script>


<!-- Leaflet JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>

    let callMap = null;
    let callMarkers = [];
    let locationTrackerData = [];
    let currentLocationStaffId = null;
    let currentEncryptedStaffId = null;
    let currentLocationResponse = null;


const LOCATION_TRACKER = {
    endpoint: function(staffId) {
        return `/get-call-locations/${encodeURIComponent(staffId)}`;
    },
    defaultCenter: [20.5937, 78.9629],
    defaultZoom: 5
};
function escapeHtml(value) {

    if (value === null || value === undefined) {
        return '';
    }

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');

}
function multi_location_view(staffId, staffName,encryptedId) {

  
    currentEncryptedStaffId = encryptedId;

    resetLocationTracker();

    $('#map_staff_name').text(
        staffName || 'Loading...'
    );

    openLocationModal();

    fetchLocationsAndShowMap(currentEncryptedStaffId);

}

function openLocationModal() {

    const modalElement = document.getElementById('kt_modal_mapCallModal');

    if (!modalElement) {
        console.error('kt_modal_mapCallModal not found');
        return;
    }

    if (
        typeof bootstrap !== 'undefined' &&
        bootstrap.Modal
    ) {

        const modal =
            bootstrap.Modal.getOrCreateInstance(
                modalElement
            );

        modal.show();

    } else {

        $('#kt_modal_mapCallModal').modal('show');

    }

}

function fetchLocationsAndShowMap(staffId) {

    showLocationLoading();

    const url = LOCATION_TRACKER.endpoint(staffId);
    let month_filter =$('#monthFilter').val();

    const params = new URLSearchParams({
            month_filter: month_filter,
        });

        const locationUrl = `${url}?${params.toString()}`;

    fetch(locationUrl, {

        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'

        },
        credentials: 'same-origin'

    })

    .then(function(response) {

        if (!response.ok) {

            throw new Error(
                'Server returned HTTP ' +
                response.status
            );

        }

        return response.json();

    })

    .then(function(response) {

        console.log(
            'Location tracker response:',
            response
        );


        if (
            !response ||
            response.status !== true
        ) {

            throw new Error(
                response?.message ||
                'Unable to load call locations.'
            );

        }


        currentLocationResponse = response;

        locationTrackerData =
            Array.isArray(response.data)
                ? response.data
                : [];


        renderStaffHeader(
            response.staff || {},
            response.summary || {}
        );


        renderSummary(
            response.summary || {},
            response.filter || {}
        );


        renderLocationList(
            locationTrackerData
        );


        hideLocationLoading();


        requestAnimationFrame(function() {

            initializeCallMap(
                locationTrackerData
            );

        });

    })

    .catch(function(error) {

        console.error(
            'Location tracker error:',
            error
        );

        showLocationError(
            error.message ||
            'Failed to load call locations.'
        );

    });

}

function renderStaffHeader(staff, summary) {

    $('#map_staff_name').text(
        staff.name || 'Unknown Staff'
    );


    $('#map_staff_position').text(
        staff.position ||
        'Staff Member'
    );


    $('#map_staff_mobile').text(
        staff.mobile ||
        '-'
    );


    $('#map_staff_department').text(
        staff.department ||
        '-'
    );


    $('#map_staff_call_badge').text(
        Number(summary.total_calls || 0) +
        ' Calls'
    );


    if (staff.image) {

        $('#map_staff_image')
            .attr('src', staff.image);

    }


    const online =
        Number(staff.online) === 1;


    $('#map_staff_online')
        .toggleClass(
            'offline',
            !online
        );

}

function renderSummary(summary, filter) {

    const totalCalls = Number(summary.total_calls || 0);
    const uniqueLocations =  Number(summary.unique_locations || 0);
    const incoming = Number(summary.incoming || 0);
    const outgoing = Number(summary.outgoing || 0);
    const missed = Number(summary.missed || 0);

    $('#map_unique_locations').text(uniqueLocations);
    $('#map_total_calls').text(totalCalls);
    $('#map_incoming_calls').text(incoming);
    $('#map_outgoing_calls').text(outgoing);
    $('#map_missed_calls').text(missed);


    const lastCall = locationTrackerData.length ? locationTrackerData[0] : null;

    if (lastCall) {
        $('#map_last_call').text(formatDateTime(lastCall.datetime));
    } else {
        $('#map_last_call').text('-');
    }
    const startDate = filter.start_date || '';
    const endDate = filter.end_date || '';


    if (startDate && endDate) {
        $('#map_date_range').text(formatDateOnly(startDate) + ' → ' + formatDateOnly(endDate) );
    } else {
        $('#map_date_range').text('All dates');
    }
    $('#map_coordinate_count').text(uniqueLocations +' coordinates');
    $('#map_location_list_count').text(locationTrackerData.length);
}

function showLocationLoading() {
    $('#locationMapLoading').removeClass('d-none');
    $('#locationMapError').addClass('d-none');
    $('#locationMapContent').addClass('d-none');
}

function hideLocationLoading() {
    $('#locationMapLoading').addClass('d-none');
    $('#locationMapError').addClass('d-none');
    $('#locationMapContent').removeClass('d-none');
}

function showLocationError(message) {
    $('#locationMapLoading').addClass('d-none');
    $('#locationMapContent').addClass('d-none');
    $('#locationMapError').removeClass('d-none');
    $('#locationMapErrorText').text(message);
}


function retryLocationTracker() {

    if (!currentEncryptedStaffId) {
        return;
    }

    fetchLocationsAndShowMap(currentEncryptedStaffId);

}

function resetLocationTracker() {

    locationTrackerData = [];
    currentLocationResponse = null;

    $('#locationCallList').empty();
    $('#map_unique_locations').text('0');
    $('#map_total_calls').text('0');
    $('#map_incoming_calls').text('0');
    $('#map_outgoing_calls').text('0');
    $('#map_missed_calls').text('0');
    $('#map_last_call').text('-');
    $('#map_location_list_count').text('0');
    $('#map_coordinate_count').text('0 coordinates');

    if (callMap) {
        callMap.remove();
        callMap = null;
    }

    callMarkers = [];

}


// function initializeCallMap(locations) {

//     if (!document.getElementById('callMap')) {
//         console.error('callMap container not found.');
//         return;
//     }


//     if (callMap) {
//         callMap.remove();
//         callMap = null;
//     }


//     callMarkers = [];

//        callMap = L.map('callMap', {
//             zoomControl: true,
//             attributionControl: true,
//             preferCanvas: true,
//             minZoom: 2,
//             maxZoom: 19
//         });

//     const streetLayer = L.tileLayer(
//         'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
//         {
//             maxZoom: 19,
//             minZoom: 2,

//             attribution:
//                 '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors'
//         }
//     );

//     /* Satellite */
//     const satelliteLayer = L.tileLayer(
//         'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
//         {
//             maxZoom: 19,
//             minZoom: 2,

//             attribution:
//                 'Tiles &copy; Esri'
//         }
//     );

//     /* Start with street map */
//     streetLayer.addTo(callMap);

//     /* Layer switcher */
//     const baseMaps = {

//         '<i class="mdi mdi-map-outline"></i> Street':
//             streetLayer,

//         '<i class="mdi mdi-satellite-variant"></i> Satellite':
//             satelliteLayer

//     };

//     L.control.layers(
//         baseMaps,
//         null,
//         {
//             position: 'topright',
//             collapsed: true
//         }
//     ).addTo(callMap);

//     // callMap = L.map('callMap', {
//     //     zoomControl: true,
//     //     attributionControl: true,
//     //     preferCanvas: true

//     // });


//     L.tileLayer(
//         'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
//         {
//             maxZoom: 19,
//             minZoom: 2,
//             attribution: '&copy; OpenStreetMap contributors'
//         }
//     ).addTo(callMap);

//     const validLocations =
//         locations.filter(function(location) {

//             const lat =Number(location.latitude);
//             const lng = Number(location.longitude);

//             return (
//                 Number.isFinite(lat) &&
//                 Number.isFinite(lng) &&
//                 lat >= -90 &&
//                 lat <= 90 &&
//                 lng >= -180 &&
//                 lng <= 180
//             );

//         });


//     console.log('Valid map locations:', validLocations.length );

//     if (!validLocations.length) {

//         callMap.setView(
//             LOCATION_TRACKER.defaultCenter,
//             LOCATION_TRACKER.defaultZoom
//         );

//         setTimeout(function() {
//             callMap.invalidateSize();
//         }, 300);

//         renderEmptyLocationList();
//         return;

//     }

//     const groupedLocations = {};

//     validLocations.forEach(function(call) {
//         const lat = Number(call.latitude).toFixed(7);
//         const lng = Number(call.longitude).toFixed(7);

//         const key = lat + ',' + lng;

//         if (!groupedLocations[key]) {
//             groupedLocations[key] = {
//                 latitude: Number(lat),
//                 longitude: Number(lng),
//                 calls: []
//             };
//         }
//         groupedLocations[key].calls.push(call);
//     });


//     const bounds =
//         L.latLngBounds([]);


//     Object.keys(groupedLocations)
//         .forEach(function(key, index) {

//             const location =
//                 groupedLocations[key];


//             const latestCall =
//                 location.calls[0];


//             const marker =
//                 createCallMarker(
//                     location,
//                     latestCall,
//                     index + 1
//                 );


//             marker.addTo(callMap);


//             marker.bindPopup(
//                 buildLocationPopup(
//                     location
//                 ),
//                 {

//                     maxWidth: 380,

//                     minWidth: 285,

//                     closeButton: true,

//                     autoPan: true

//                 }
//             );


//             callMarkers.push({

//                 marker: marker,

//                 latitude:
//                     location.latitude,

//                 longitude:
//                     location.longitude,

//                 calls:
//                     location.calls

//             });


//             bounds.extend([

//                 location.latitude,

//                 location.longitude

//             ]);

//         });


//     if (bounds.isValid()) {

//         callMap.fitBounds(
//             bounds,
//             {

//                 padding: [50, 50],
//                 maxZoom: 16

//             }
//         );

//     }


//     setTimeout(function() {

//         if (!callMap) {
//             return;
//         }

//         callMap.invalidateSize();

//         if (bounds.isValid()) {
//             callMap.fitBounds(
//                 bounds,
//                 {
//                     padding: [50, 50],
//                     maxZoom: 16
//                 }
//             );
//         }

//     }, 350);

// }

function initializeCallMap(locations) {

    const mapElement = document.getElementById('callMap');

    if (!mapElement) {
        console.error('callMap container not found.');
        return;
    }

    /*
    |--------------------------------------------------------------------------
    | Remove previous map
    |--------------------------------------------------------------------------
    */
    if (callMap) {
        try {
            callMap.off();
            callMap.remove();
        } catch (e) {
            console.warn('Previous call map cleanup failed:', e);
        }

        callMap = null;
    }

    callMarkers = [];

    /*
    |--------------------------------------------------------------------------
    | CREATE MAP FIRST
    |--------------------------------------------------------------------------
    */
    callMap = L.map('callMap', {
        zoomControl: true,
        attributionControl: true,
        preferCanvas: true,
        minZoom: 2,
        maxZoom: 19
    });

    /*
    |--------------------------------------------------------------------------
    | STREET MAP
    |--------------------------------------------------------------------------
    */
    const streetLayer = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
            maxZoom: 19,
            minZoom: 2,
            attribution:
                '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors'
        }
    );

    /*
    |--------------------------------------------------------------------------
    | SATELLITE MAP
    |--------------------------------------------------------------------------
    */
    const satelliteLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
            maxZoom: 19,
            minZoom: 2,
            attribution: 'Tiles &copy; Esri'
        }
    );

    /*
    |--------------------------------------------------------------------------
    | DEFAULT = STREET
    |--------------------------------------------------------------------------
    */
    streetLayer.addTo(callMap);

    /*
    |--------------------------------------------------------------------------
    | MAP TYPE SWITCHER
    |--------------------------------------------------------------------------
    */
    const baseMaps = {
        '<i class="mdi mdi-map-outline"></i> Street': streetLayer,
        '<i class="mdi mdi-satellite-variant"></i> Satellite': satelliteLayer
    };

    L.control.layers(
        baseMaps,
        null,
        {
            position: 'topright',
            collapsed: true
        }
    ).addTo(callMap);

    /*
    |--------------------------------------------------------------------------
    | VALID LOCATIONS
    |--------------------------------------------------------------------------
    */
    const validLocations = (locations || []).filter(function(location) {

        const lat = Number(location.latitude);
        const lng = Number(location.longitude);

        return (
            Number.isFinite(lat) &&
            Number.isFinite(lng) &&
            lat >= -90 &&
            lat <= 90 &&
            lng >= -180 &&
            lng <= 180
        );

    });

    console.log(
        'Valid map locations:',
        validLocations.length
    );

    /*
    |--------------------------------------------------------------------------
    | NO VALID LOCATION
    |--------------------------------------------------------------------------
    */
    if (!validLocations.length) {

        callMap.setView(
            LOCATION_TRACKER.defaultCenter,
            LOCATION_TRACKER.defaultZoom
        );

        setTimeout(function() {

            if (callMap) {
                callMap.invalidateSize();
            }

        }, 300);

        renderEmptyLocationList();

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | GROUP SAME COORDINATES
    |--------------------------------------------------------------------------
    */
    const groupedLocations = {};

    validLocations.forEach(function(call) {

        const lat = Number(call.latitude).toFixed(7);
        const lng = Number(call.longitude).toFixed(7);

        const key = lat + ',' + lng;

        if (!groupedLocations[key]) {

            groupedLocations[key] = {
                latitude: Number(lat),
                longitude: Number(lng),
                calls: []
            };

        }

        groupedLocations[key].calls.push(call);

    });

    /*
    |--------------------------------------------------------------------------
    | CREATE BOUNDS
    |--------------------------------------------------------------------------
    */
    const bounds = L.latLngBounds([]);

    /*
    |--------------------------------------------------------------------------
    | CREATE MARKERS
    |--------------------------------------------------------------------------
    */
    Object.keys(groupedLocations).forEach(function(key, index) {

        const location = groupedLocations[key];

        /*
        | Latest call for this location
        */
        const latestCall = location.calls[0];

        /*
        | Create marker
        */
        const marker = createCallMarker(
            location,
            latestCall,
            index + 1
        );

        marker.addTo(callMap);

        /*
        | Popup
        */
        marker.bindPopup(
            buildLocationPopup(location),
            {
                maxWidth: 380,
                minWidth: 285,
                closeButton: true,
                autoPan: true
            }
        );

        /*
        | Store marker
        */
        callMarkers.push({

            marker: marker,

            latitude: location.latitude,

            longitude: location.longitude,

            calls: location.calls

        });

        /*
        | Add location to bounds
        */
        bounds.extend([
            location.latitude,
            location.longitude
        ]);

    });

    /*
    |--------------------------------------------------------------------------
    | AUTO CENTER + AUTO ZOOM
    |--------------------------------------------------------------------------
    */
    if (bounds.isValid()) {

        callMap.fitBounds(
            bounds,
            {
                padding: [50, 50],
                maxZoom: 16
            }
        );

    }

    /*
    |--------------------------------------------------------------------------
    | MODAL / HIDDEN CONTAINER FIX
    |--------------------------------------------------------------------------
    */
    setTimeout(function() {

        if (!callMap) {
            return;
        }

        callMap.invalidateSize();

        if (bounds.isValid()) {

            callMap.fitBounds(
                bounds,
                {
                    padding: [50, 50],
                    maxZoom: 16
                }
            );

        }

    }, 350);

}


function createCallMarker(
    location,
    latestCall,
    number
) {

    const status = latestCall.status_class || getStatusClass(latestCall.status );

    let markerClass = 'marker-blue';
    let icon ='mdi-map-marker';

    if (status === 'incoming') {
        markerClass ='marker-green';
        icon ='mdi-phone-incoming';
    }
    else if (status === 'missed') {
        markerClass ='marker-red';
        icon ='mdi-phone-missed';
    }
    else if (status === 'rejected') {
        markerClass ='marker-orange';
        icon ='mdi-phone-cancel';
    }
    else {
        markerClass = 'marker-blue';
        icon =  'mdi-phone-outgoing';
    }


    const markerHtml = `

        <div
            class="call-map-marker ${markerClass}"
            title="${escapeHtml(
                latestCall.contact || 'Call'
            )}"
        >

            <i class="mdi ${icon}"></i>

        </div>

    `;


    const markerIcon =
        L.divIcon({
            html: markerHtml,
            className: '',
            iconSize: [38, 38],
            iconAnchor: [19, 38],
            popupAnchor: [0, -34]
        });


    return L.marker(
        [
            location.latitude,
            location.longitude
        ],
        {
            icon: markerIcon
        }
    );

}

function buildLocationPopup(location) {

    const calls =location.calls || [];
    const firstCall = calls[0] || {};

    const staffImage =
        currentLocationResponse &&
        currentLocationResponse.staff &&
        currentLocationResponse.staff.image
            ? currentLocationResponse.staff.image
            : '';

    let html = `

        <div class="call-location-popup">
            <div class="popup-header">
                <img
                    class="popup-staff-image"
                    src="${escapeHtml(staffImage)}"
                    onerror="this.style.display='none'"
                >

                <div>
                    <div class="popup-header-name">
                        ${escapeHtml(
                            firstCall.user ||
                            'Staff'
                        )}
                    </div>
                    <div class="popup-header-sub">
                        ${escapeHtml(
                            firstCall.job_position_name ||
                            ''
                        )}
                    </div>
                </div>
            </div>
            <div class="popup-location-summary">
                <i class="mdi mdi-map-marker"></i>
                <div>
                    <div class="popup-location-title">
                        ${calls.length}
                        call${calls.length !== 1 ? 's' : ''}
                        at this location
                    </div>
                    <div class="popup-location-coordinates">
                        ${location.latitude.toFixed(7)},
                        ${location.longitude.toFixed(7)}
                    </div>
                </div>
            </div>
            <div class="popup-call-list">

    `;


    calls.forEach(function(call) {

        const status = call.status_class || getStatusClass(call.status);
        const statusText = call.status_text || getStatusText(call.status);

        html += `

            <div class="popup-call-row">
                <div class="popup-contact">
                    ${escapeHtml( call.contact || 'Unknown Contact' )}
                </div>
                <div class="popup-phone">
                    ${escapeHtml(call.phone || '-')}
                </div>
                <div class="popup-call-meta">
                    <span class="call-status ${escapeHtml(status)}" >

                        <i class="mdi ${
                            escapeHtml(
                                call.status_icon ||
                                getStatusIcon(call.status)
                            )
                        }"></i>
                        ${escapeHtml(statusText)}
                    </span>
                    <span class="call-duration">
                        ${escapeHtml(call.duration || '00:00:00' )}
                        &nbsp; • &nbsp;
                        ${escapeHtml( call.time || '' )}
                    </span>
                </div>
            </div>
        `;

    });


    html += `
            </div>
        </div>

    `;

    return html;

}

function renderLocationList(locations) {

    const container = $('#locationCallList');

    container.empty();

    if (!locations.length) {
        renderEmptyLocationList();
        return;
    }


    locations.forEach(function(call, index) {
        const status = call.status_class || getStatusClass(call.status);
        const statusText = call.status_text || getStatusText(call.status);
        const statusIcon = call.status_icon || getStatusIcon(call.status);

        const hasLocation =
                call.latitude !== null &&
                call.latitude !== undefined &&
                call.longitude !== null &&
                call.longitude !== undefined &&
                call.latitude !== '' &&
                call.longitude !== '' &&
                !isNaN(parseFloat(call.latitude)) &&
                !isNaN(parseFloat(call.longitude));

        const locationBadge = hasLocation
            ? `
                <span class="call-location-status available fs-9 ms-1"
                    title="Location coordinates available">
                    <i class="mdi mdi-map-marker-check-outline fs-9"></i>
                </span>
            `
            : `
                <span class="call-location-status unavailable fs-9 ms-1"
                    title="Location coordinates not available">
                    <i class="mdi mdi-map-marker-off-outline fs-9"></i>
                </span>
            `;

        const html = `
            <div class="location-call-item" data-call-index="${index}" onclick="focusCallLocation(${index})">
                <div class="location-call-top">
                    <div class="location-contact">
                        ${escapeHtml( call.contact ||'Unknown Contact')}
                    </div>
                    <div class="location-time">
                        ${escapeHtml(call.time || '')}
                        ${locationBadge}
                    </div>
                </div>
                <div class="location-call-phone">
                    <i class="mdi mdi-phone-outline"></i>
                    ${escapeHtml(
                        call.phone || '-'
                    )}
                </div>
                <div class="location-call-bottom">
                    <span class="call-status ${escapeHtml(status)}">
                        <i class="mdi ${escapeHtml(statusIcon)}"></i>
                        ${escapeHtml(statusText)}
                    </span>
                    <span class="call-duration">
                        <i class="mdi mdi-timer-outline"></i>
                        ${escapeHtml(
                            call.duration ||
                            '00:00:00'
                        )}
                    </span>
                    
                </div>
            </div>
        `;

        container.append(html);

    });

}

function renderEmptyLocationList() {

    $('#locationCallList').html(`

        <div class="location-empty">

            <i class="mdi mdi-map-marker-off-outline"></i>

            <div class="location-empty-title">
                No call locations found
            </div>

            <div class="mt-1" style="font-size:10px;">
                No valid GPS coordinates are available.
            </div>

        </div>

    `);

}

function focusCallLocation(index) {

    const call = locationTrackerData[index];

    if (!call) {
        return;
    }
    const lat = Number(call.latitude);

    const lng = Number(call.longitude);


    if (
        !Number.isFinite(lat) ||
        !Number.isFinite(lng)
    ) {

        return;
    }

    $('.location-call-item').removeClass('active');
    $( `.location-call-item[data-call-index="${index}"]`).addClass('active');

    if (!callMap) {
        return;
    }
    const markerData =
        callMarkers.find(function(item) {
            return (
                Math.abs(item.latitude - lat ) < 0.0000001 &&
                Math.abs( item.longitude - lng ) < 0.0000001
            );
        });


    callMap.flyTo(
        [lat, lng],
        Math.max(
            callMap.getZoom(),
            16
        ),
        {
            duration: .7
        }
    );


    if (markerData) {
        setTimeout(function() {
            markerData.marker.openPopup();
        }, 500);
    }

}

function fitAllCallLocations() {

    if (!callMap || !callMarkers.length) {
        return;
    }
    const bounds = L.latLngBounds([]);


    callMarkers.forEach(function(item) {
        bounds.extend([
            item.latitude,
            item.longitude
        ]);
    });

    if (bounds.isValid()) {
        callMap.fitBounds(
            bounds,
            {
                padding: [50, 50],
                maxZoom: 16
            }
        );
    }

}

function refreshLocationTracker() {

    if (!currentEncryptedStaffId) {
        return;
    }

    fetchLocationsAndShowMap(currentEncryptedStaffId);

}

function getStatusClass(status) {

    switch (Number(status)) {

        case 0:
            return 'outgoing';

        case 1:
            return 'incoming';

        case 2:
            return 'missed';

        case 3:
            return 'rejected';

        case 4:
            return 'dialed';

        default:
            return 'dialed';

    }

}

function getStatusText(status) {

    switch (Number(status)) {

        case 0:
            return 'Outgoing';

        case 1:
            return 'Incoming';

        case 2:
            return 'Missed';

        case 3:
            return 'Rejected';

        case 4:
            return 'Dialed';

        default:
            return 'Unknown';

    }

}

function getStatusIcon(status) {
    switch (Number(status)) {
        case 0:
            return 'mdi-phone-outgoing';

        case 1:
            return 'mdi-phone-incoming';

        case 2:
            return 'mdi-phone-missed';

        case 3:
            return 'mdi-phone-cancel';

        case 4:
            return 'mdi-phone-dial';

        default:
            return 'mdi-phone-outline';

    }
}

function formatDateOnly(dateString) {

    if (!dateString) {
        return '-';
    }

    const date = new Date(dateString + 'T00:00:00');


    if (Number.isNaN(date.getTime())) {
        return dateString;
    }


    return date.toLocaleDateString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }
    );

}

function formatDateTime(dateTimeString) {

    if (!dateTimeString) {
        return '-';
    }
    const date = new Date( dateTimeString.replace(' ', 'T'));

    if (Number.isNaN(date.getTime())) {
        return dateTimeString;
    }
    return date.toLocaleString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        }
    );

}

$('#kt_modal_mapCallModal').on('shown.bs.modal',
    function() {
        setTimeout(function() {
            if (callMap) {
                callMap.invalidateSize();
                fitAllCallLocations();
            }
        }, 250);
    }
);


$('#kt_modal_mapCallModal').on('hidden.bs.modal',
    function() {
        if (callMap) {
            callMap.remove();
            callMap = null;

        }
        callMarkers = [];
        locationTrackerData = [];
        currentLocationResponse = null;
        currentLocationStaffId = null;
        currentEncryptedStaffId = null;

    }
);

</script>

<script>
    $(document).ready(function() {
        $('.month_filter_common_class').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        })
    });
</script>
@endsection
