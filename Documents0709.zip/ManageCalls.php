<?php
namespace App\Http\Controllers\sales\manage_calls;

use App\Http\Controllers\Controller;
use App\Models\ManageTeamModel;
use App\Models\LeadModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Models\SpamReasonModel;
use App\Models\CallTrackerModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappApiConfigureModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\WhatsappTemplateLogModel;
use Illuminate\Support\Facades\Log;

class ManageCalls extends Controller
{
 
  
    protected $client;
    protected $accessToken;
    protected $businessId;
    protected $baseUrl;
    protected $phoneNumberId;
    
    public function __construct()
    {
        
      
        $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
        $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
        $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
        $this->baseUrl = 'https://graph.facebook.com/v17.0';
        $this->businessId = $whatsappConfig->waba_id;
    }
    public function manage_calls(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        // $date_filter

        

        // Filters
        $department_fill  = $request->input('department_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $date_filter      = $request->input('dt_fill_issue_rpt')== "" ?"today" : $request->input('dt_fill_issue_rpt');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

       


        $calls = DB::table('za_cug_management')
            ->select('za_cug_management.staff_id', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_department.department_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
            ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->distinct('za_cug_management.staff_id')
            ->where('za_staff.status', '!=', 2)
            ->where('za_department.sno',1);

        $staff_list = $calls->get();

        // Other Filters
        if ($department_fill) {
            $calls->where('za_staff.department_id', $department_fill);
        }

        if ($staff_fill) {
            $calls->where('za_cug_management.staff_id', $staff_fill);
        }

        $calls = $calls->orderBy('za_cug_management.staff_id', 'desc')->paginate($perpage);

        $callData = DB::table('za_call_tracker')
        ->select(
            'branch_staff_id',
            DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
            DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
            DB::raw("SUM(CASE WHEN customer_status = 0 THEN 1 ELSE 0 END) AS unknown_count")
        ) 
        ->whereIn('branch_staff_id', $calls->pluck('staff_id')->toArray()); // Fetch only relevant staff

         // Date Filtering
         if ($date_filter === "today") {
            $callData->whereDate('za_call_tracker.call_start_date', now()->toDateString());
        } elseif ($date_filter === "week") {
            $callData->whereBetween('za_call_tracker.call_start_date', [now()->startOfWeek(), now()->endOfWeek()]);
        } elseif ($date_filter === "monthly") {
            $callData->whereMonth('za_call_tracker.call_start_date', now()->month)
                ->whereYear('za_call_tracker.call_start_date', now()->year);
        } elseif ($date_filter === "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $callData->whereBetween('za_call_tracker.call_start_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
            } elseif ($from_date_filter) {
                $callData->where('za_call_tracker.call_start_date', '>=', Carbon::parse($from_date_filter));
            } elseif ($to_date_filter) {
                $callData->where('za_call_tracker.call_start_date', '<=', Carbon::parse($to_date_filter));
            }
        }

        $callData=$callData->groupBy('branch_staff_id')
        ->get()
        ->keyBy('branch_staff_id'); // Index by staff ID for fast lookup

        // Initialize total counts
        $total_incoming_call_count = 0;
        $total_outgoingcall_count = 0;
        $total_missedcall_count = 0;
        $total_rejected_call_count = 0;
        $total_unknown_count = 0;

        // Assign call data to staff
        foreach ($calls as $staff) {
            $data = $callData[$staff->staff_id] ?? (object) [
                'incoming_call_count' => 0,
                'outgoingcall_count' => 0,
                'missedcall_count' => 0,
                'rejected_call_count' => 0,
                'unknown_count' => 0
            ];

            $incoming_call_count= $data->incoming_call_count ;
            $outcoming_call_count= $data->outgoingcall_count ;
            $missed_call_count= $data->missedcall_count;
            $rejected_call_count= $data->rejected_call_count;

            $staff->incoming_call_count = $data->incoming_call_count;
            $staff->outgoingcall_count = $data->outgoingcall_count;
            $staff->missedcall_count = $data->missedcall_count;
            $staff->rejected_call_count = $data->rejected_call_count;
            $staff->unknown_count = $data->unknown_count;

             // outgoing call ratio
             $total_calls = $incoming_call_count + $missed_call_count + $rejected_call_count+$outcoming_call_count;
             $staff->outgoing_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

            // Missed call ratio
            $total_calls = $incoming_call_count + $missed_call_count + $rejected_call_count;
            $staff->missed_call_ratio = $total_calls > 0 ? ($data->missedcall_count / $total_calls) * 100 : 0;

            // Update total counters
            $total_incoming_call_count += $data->incoming_call_count;
            $total_outgoingcall_count += $data->outgoingcall_count;
            $total_missedcall_count += $data->missedcall_count;
            $total_rejected_call_count += $data->rejected_call_count;
            $total_unknown_count += $data->unknown_count;
        }

        // return $calls;



        $department_list = DB::table('za_department')->where('status', 0)->get();

        // return $calls;
        return view('content.sales.manage_calls.call_list', [
            'calls'            => $calls,
            'perpage'          => $perpage,
            'department_list'  => $department_list,
            'staff_list'       => $staff_list,
            'department_fill'  => $department_fill,
            'staff_fill'       => $staff_fill,
            'date_filter'         => $date_filter,
            'from_date_filter'    => $from_date_filter,
            'to_date_filter'      => $to_date_filter,
          
        ]);
    }
    
    
    public function index170826(Request $request)
    {
        $month_filter = $request->get('month_filter', date('M-Y'));
        $parsedDate   = Carbon::createFromFormat('M-Y', $month_filter);
        $startTime = microtime(true);
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $branch_id = $request->user()->branch_id;
        $user_id   = $request->user()->user_id;
    
        $month = $parsedDate->month;
        $year  = $parsedDate->year;
    
        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
    
        // Staff list cache
        $staff_list = Cache::remember("staff_list_branch_{$branch_id}", 300, function () use ($branch_id) {
            return DB::table('za_cug_management')
                ->select(
                    'za_cug_management.staff_id',
                    'za_staff.staff_name',
                    'za_staff.nick_name',
                    'za_staff.staff_image',
                    'za_staff.gender',
                    'za_staff.mobile_no',
                    'za_department.department_name',
                    'za_department.sno as dept_id',
                    'za_job_position.job_position_name'
                )
                ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
                ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
                ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
                ->where('za_staff.status', '!=', 2)
                ->distinct()
                ->get();
        });
    
        // Filters
        $call_fill        = $request->input('call_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');
    
        /**
         * Step 1: Query only IDs for pagination
         */
        $callIdQuery = DB::table('za_call_tracker')
            ->where('za_call_tracker.branch_id', $branch_id);
    
        // Month filter
        if (!$from_date_filter && !$to_date_filter) {
            $callIdQuery->whereYear('za_call_tracker.call_start_date', $year)
                ->whereMonth('za_call_tracker.call_start_date', $month);
        }
    
        // Date range filter
        if ($from_date_filter && $to_date_filter) {
            $callIdQuery->whereBetween('za_call_tracker.call_start_date', [$from_date_filter, $to_date_filter]);
        }
    
        // Permission check
        // if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
        //     $callIdQuery->where('za_call_tracker.branch_staff_id', $user_id);
        // }
    
        // if ($status_fill !== '') {
        //     $callIdQuery->where('za_call_tracker.call_status', $status_fill);
        // }
        
        if ($status_fill) {
                $callIdQuery->where('za_call_tracker.call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $callIdQuery->where('za_call_tracker.call_status', $status_fill);
            }
            
        if ($staff_fill) {
            $callIdQuery->where('za_call_tracker.branch_staff_id', $staff_fill);
        }
        if ($call_fill != '') {
            $callIdQuery->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
                ->where(function ($query) use ($call_fill) {
                    $query->where('za_call_tracker.customer_phone_no', 'LIKE', "%{$call_fill}%")
                        ->orWhere('za_call_tracker.staff_phone_no', 'LIKE', "%{$call_fill}%")
                        ->orWhere('za_staff.staff_name', 'LIKE', "%{$call_fill}%")
                        ->orWhere('za_staff.nick_name', 'LIKE', "%{$call_fill}%")
                        ->orWhere('za_call_tracker.customer_name', 'LIKE', "%{$call_fill}%");
                });
        }
    
        // Get paginated IDs
        $paginatedIds = $callIdQuery
            ->orderBy('za_call_tracker.call_start_date', 'desc')
            ->orderBy('za_call_tracker.call_start_time', 'desc')
            ->distinct()
            ->paginate($perpage, ['za_call_tracker.sno']);
    
        $callIds = $paginatedIds->pluck('sno')->toArray();
    
        /**
         * Step 2: Fetch full data with same filters + department & job_position
         */
        $calls = DB::table('za_call_tracker')
            ->select(
                'za_call_tracker.call_status',
                'za_call_tracker.sno',
                'za_call_tracker.staff_phone_no',
                'za_call_tracker.customer_name',
                'za_call_tracker.customer_phone_no',
                'za_call_tracker.call_start_date',
                'za_call_tracker.call_start_time',
                'za_call_tracker.call_end_time',
                'za_call_tracker.call_duration',
                'za_call_tracker.latitude',
                'za_call_tracker.longitude',
                'za_lead.lead_name',
                'za_lead.drop_verified',
                'za_lead.drop_tl_verified',
                'za_lead.spam_verified',
                'za_lead.spam_tl_verified',
                'za_lead.status AS lead_status',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_department.department_name',
                'za_department.sno as dept_id',
                'za_job_position.job_position_name',
                'sb.staff_name AS lead_staff',
                'za_Internal_cugs.user_name as internal_user_name',
                'za_lead.created_by'
            )
            ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->leftJoin('za_lead', function ($join) {
                $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_call_tracker.customer_phone_no, 10)"));
            })
            ->leftJoin('za_Internal_cugs', function ($join) {
                $join->on('za_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(za_call_tracker.customer_phone_no, 10)"));
            })
            ->leftJoin('za_staff as sb', 'sb.sno', '=', 'za_lead.created_by')
            ->whereIn('za_call_tracker.sno', $callIds)
            ->orderBy('za_call_tracker.call_start_date', 'desc')
            ->orderBy('za_call_tracker.call_start_time', 'desc')
            ->get();
    
        /**
         * Step 3: Aggregate counts
         */
        $call_counts = DB::table('za_call_tracker')
            ->selectRaw('
                COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming_call_count,
                COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing_call_count,
                COUNT(CASE WHEN call_status = 2 THEN 1 END) as missedcall_count,
                COUNT(CASE WHEN call_status = 3 THEN 1 END) as rejected_call_count,
                COUNT(CASE WHEN call_status = 4 THEN 1 END) as dialedcall_count
            ')
            ->where('branch_id', $branch_id)
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month);
    
        // if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
        //     $call_counts->where('branch_staff_id', $user_id);
        // }
        if ($staff_fill) {
            $call_counts->where('branch_staff_id', $staff_fill);
        }
        // if ($status_fill !== '') {
        //     $call_counts->where('call_status', $status_fill);
        // }
    
        if ($status_fill) {
                $call_counts->where('call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $call_counts->where('call_status', $status_fill);
            }
            
        $call_counts = $call_counts->first();
    
        $incoming_call_count = $call_counts->incoming_call_count ?? 0;
        $outgoingcall_count  = $call_counts->outgoing_call_count ?? 0;
        $missedcall_count    = $call_counts->missedcall_count ?? 0;
        $rejected_call_count = $call_counts->rejected_call_count ?? 0;
        $dialedcall_count    = $call_counts->dialedcall_count ?? 0;
    
        $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
            ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
            : 0;
    
        $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
            ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
            : 0;
    
        $reasonList = SpamReasonModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
    
        /**
         * Step 4: Fetch loginData (mysql_secondary)
         */
        $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();
    
        $loginData = DB::connection('mysql_secondary')
            ->table('user as u')
            ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
            ->whereIn('u.phone_no', $staffPhones)
            ->get()
            ->keyBy('phone_no');
    
        $callsPaginator = new LengthAwarePaginator(
            $calls,
            $paginatedIds->total(),
            $paginatedIds->perPage(),
            $paginatedIds->currentPage(),
            ['path' => request()->url(), 'query' => request()->query()]
        );
        
            // $endTime       = microtime(true);
            // $executionTime = $endTime - $startTime;
            // return($executionTime);
    
        return view('content.sales.manage_calls.call_list', [
            'calls'               => $callsPaginator,
            'month_chk'           => $month_chk,
            'month'               => $month,
            'year'                => $year,
            'staff_list'          => $staff_list,
            'staff_fill'          => $staff_fill,
            'month_filter'        => $month_filter,
            'call_fill'           => $call_fill,
            'perpage'             => $perpage,
            'reasonList'          => $reasonList,
            'incoming_call_count' => $incoming_call_count,
            'outgoingcall_count'  => $outgoingcall_count,
            'missedcall_count'    => $missedcall_count,
            'rejected_call_count' => $rejected_call_count,
            'dialedcall_count'    => $dialedcall_count,
            'missed_call_ratio'   => $missed_call_ratio,
            'outgoing_call_ratio' => $outgoing_call_ratio,
            'status_fill'         => $status_fill,
            'lastLoginDataMap'    => $loginData,
        ]);
    }

   
    public function indexOld(Request $request, $month = null, $year = null)
    {
        
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id;
        $year = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));
        $startTime = microtime(true);
        
        // Monthly check
        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        
        
        

        // Query to get staff list
        $staff_list = DB::table('za_cug_management')
            ->select('za_cug_management.staff_id', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_department.department_name','za_department.sno as dept_id','za_job_position.job_position_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
            ->join('za_department','za_staff.department_id', '=', 'za_department.sno')
            ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->distinct()
            ->where('za_staff.status', '!=', 2)
            // ->where('za_department.sno', 1)
            ->get();

        // Filters
        $call_fill = $request->input('call_fill', '');
        $staff_fill = $request->input('staff_fill', '');
        $status_fill = $request->input('status_fill', '');
        $date_filter = $request->input('dt_fill_issue_rpt');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter = $request->input('to_date_fillter_textbox');
        
        
        
         $calls = DB::table('za_call_tracker')
            ->select('za_call_tracker.call_status',
            'za_call_tracker.sno',
            'za_call_tracker.staff_phone_no',
            'za_call_tracker.customer_name',
            'za_call_tracker.customer_phone_no',
            'za_call_tracker.call_start_date',
            'za_call_tracker.call_start_time',
            'za_call_tracker.call_end_time',
            'za_call_tracker.call_duration',
            'za_call_tracker.latitude',
            'za_call_tracker.longitude',
            'za_lead.lead_name',
            'za_lead.drop_verified', 'za_lead.drop_tl_verified',
            'za_lead.spam_verified', 'za_lead.spam_tl_verified',
            'za_lead.status AS lead_status',
            'za_staff.staff_name',
            'sb.staff_name AS lead_staff',
            'za_Internal_cugs.user_name as internal_user_name', 'za_department.department_name','za_department.sno as dept_id','za_job_position.job_position_name',
            'za_lead.created_by')
            ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
            ->join('za_department','za_staff.department_id', '=', 'za_department.sno')
            ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->leftJoin('za_lead', function ($join) {
                            $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_call_tracker.customer_phone_no, 10)"));
                        })
        ->leftJoin('za_Internal_cugs', function ($join) {
            $join->on('za_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(za_call_tracker.customer_phone_no, 10)"));
        })
        ->leftJoin('za_staff as sb', 'sb.sno', '=', 'za_lead.created_by') // Replace 'created_by' with actual column
        ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)
        ->where('za_call_tracker.branch_id', $branch_id);
        
        // $endTime       = microtime(true);
        // $executionTime = $endTime - $startTime;
        // return($executionTime);

        if ($status_fill) {
            $calls->where('za_call_tracker.call_status', $status_fill);
        } elseif ($status_fill === '0') {
            $calls->where('za_call_tracker.call_status', $status_fill);
        }

        if ($staff_fill) {
            $calls->where('za_call_tracker.branch_staff_id', $staff_fill);
        }

        if ($call_fill != '') {
            $calls->where(function ($query) use ($call_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$call_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$call_fill}%")
                    ->orWhere('za_call_tracker.staff_phone_no', 'LIKE', "%{$call_fill}%")
                    ->orWhere('za_call_tracker.customer_phone_no', 'LIKE', "%{$call_fill}%")
                    ->orWhere('za_call_tracker.customer_name', 'LIKE', "%{$call_fill}%")
                    ->orWhere('za_lead.lead_name', 'LIKE', "%{$call_fill}%");
            });
        }

        // Paginate Calls
        $calls = $calls ->orderBy('za_call_tracker.call_start_date', 'desc')->orderBy('za_call_tracker.call_start_time', 'desc')
        ->groupBy('za_call_tracker.call_status',
        'za_call_tracker.sno',
            'za_call_tracker.staff_phone_no',
            'za_call_tracker.customer_name',
            'za_call_tracker.customer_phone_no',
            'za_call_tracker.call_start_date',
            'za_call_tracker.call_start_time',
            'za_call_tracker.call_end_time',
            'za_call_tracker.call_duration',
            'za_call_tracker.latitude',
            'za_call_tracker.longitude',
            'za_lead.lead_name',
            'za_lead.drop_verified', 'za_lead.drop_tl_verified',
            'za_lead.spam_verified', 'za_lead.spam_tl_verified',
            'za_lead.status',
            'za_staff.staff_name',
            'za_Internal_cugs.user_name','za_department.department_name','za_department.sno','za_job_position.job_position_name',
            'sb.staff_name',
            'za_lead.created_by')
        ->paginate($perpage);
        
        //  $endTime       = microtime(true);
        // $executionTime = $endTime - $startTime;
        // return($calls);

        // Aggregated Query for Calls (Incoming, Outgoing, Missed, Rejected)
        $call_counts = DB::table('za_call_tracker')
            ->selectRaw('
                COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming_call_count,
                COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing_call_count,
                COUNT(CASE WHEN call_status = 2 THEN 1 END) as missedcall_count,
                COUNT(CASE WHEN call_status = 3 THEN 1 END) as rejected_call_count,
                COUNT(CASE WHEN call_status = 4 THEN 1 END) as dialedcall_count
            ')
            ->whereYear('call_start_date', $year)
            ->where('za_call_tracker.branch_id', $branch_id)
            ->whereMonth('call_start_date', $month);

        if ($staff_fill) {
            $call_counts->where('branch_staff_id', $staff_fill);
        }

        // Execute the counts
        $call_counts = $call_counts->first();

        // Assign counts
        $incoming_call_count = $call_counts->incoming_call_count ?? 0;
        $outgoingcall_count = $call_counts->outgoing_call_count ?? 0;
        $missedcall_count = $call_counts->missedcall_count ?? 0;
        $rejected_call_count = $call_counts->rejected_call_count ?? 0;
        $dialedcall_count = $call_counts->dialedcall_count ?? 0;

        // Calculate Ratios
        $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
            ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
            : 0;

        $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
            ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
            : 0;
            
            // $endTime       = microtime(true);
            // $executionTime = $endTime - $startTime;
            // return($executionTime);
        // Query for Calls (Paginated)
        //  $startTime = microtime(true);
       
         $reasonList = SpamReasonModel::select('*')
        ->where('status', 0)
        ->orderBy('sno', 'desc')->get();    
       

        //   return $calls;
    
            $loginData=[];
        return view('content.sales.manage_calls.call_list', [
            'calls' => $calls,
            'month_chk' => $month_chk,
            'month' => $month,
            'year' => $year,
            'staff_list' => $staff_list,
            'staff_fill' => $staff_fill,
            'call_fill' => $call_fill,
            'perpage' => $perpage,
            'reasonList' => $reasonList,
            'incoming_call_count' => $incoming_call_count,
            'outgoingcall_count' => $outgoingcall_count,
            'missedcall_count' => $missedcall_count,
            'rejected_call_count' => $rejected_call_count,
            'dialedcall_count' => $dialedcall_count,
            'missed_call_ratio' => $missed_call_ratio,
            'outgoing_call_ratio' => $outgoing_call_ratio,
            'status_fill' => $status_fill,
             'lastLoginDataMap' => $loginData,
        ]);
    }

    public function lead_call_history($id, $status, Request $request)
    {
        // return $status;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id;

        $helper          = new \App\Helpers\Helpers();
        $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
        $lead_id     = $decryptedValue;
        $call_start_date = date('Y-m-01'); // Start date (first day of the month)
        $call_end_date   = date('Y-m-t');

        // Filters
        $status_fill      = $request->input('status_fill', '');
        $date_filter      = $request->input('dt_fill_issue_rpt');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');
        $fin_yr_fill      = $request->input('fin_yr_fill', '');



        // $lead = DB::table('za_call_tracker')->where('customer_phone_no', $lead_mobile)
        //     ->orWhere('customer_phone_no', $phoneWithCountryCode)->orderBy('sno', 'desc')->first();

        $caller = DB::table('za_lead')->select('za_lead.*')
            ->where('za_lead.sno', $lead_id)
            ->first();

            $lead_mobile =$caller->lead_mobile;
            $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
            $phoneWithCountryCode = '+91' . $normalizedPhoneNo; // Add the country code

            // return  $caller ;


        $incoming_call_count = DB::table('za_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)       
              ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)// End date filter 
            ->where('za_call_tracker.call_status', 1)                             // Status is 1
            ->count();

        $incoming_call_count = $incoming_call_count ?? 0;

        // Get the outgoing call count excluding the phone numbers in company_cug_detail
        $outgoingcall_count = DB::table('za_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)                // Filter by user ID
            ->whereDate('za_call_tracker.call_start_date', '>=', $call_start_date) // Start date filter
            ->whereDate('za_call_tracker.call_start_date', '<=', $call_end_date)
            ->where('za_call_tracker.call_status', 0)                             // Status is 0
            // ->where('za_call_tracker.call_duration', '!=', '00:00:00')            // Duration is not '00:00:00'
            ->count();

        // Assign the result to a variable
        $outgoingcall_count = $outgoingcall_count ?? 0;

        // missed call
        $missedcall_count = DB::table('za_call_tracker')
        ->where('customer_phone_no', $lead_mobile)        
        ->orWhere('customer_phone_no', $phoneWithCountryCode)                 // Filter by user ID
              ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)// End date filter  
            ->where('za_call_tracker.call_status', 2)                             // Status is 2 for missed calls
            ->count();

        $rejected_call_count = DB::table('za_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)                   // Filter by user ID
              ->whereYear('za_call_tracker.call_start_date', $year)
        ->whereMonth('za_call_tracker.call_start_date', $month)// End date filter
            
            ->where('za_call_tracker.call_status', 3)                             // Status is 3 for rejected calls
            ->count();

        // Assign the result to a variable
        $rejected_call_count = $rejected_call_count ?? 0;

        // Assign the result to a variable
        $missedcall_count = $missedcall_count ?? 0;

        $missed_call_ratio = 0;

        if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
            $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
            if ($total_calls > 0) {
                $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
                $missed_call_ratio = $missed_call_ratio;
            } else {
                $missed_call_ratio = 0;
            }
        }

        $outgoing_call_ratio = 0;

        if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
            $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
            if ($total_calls > 0) {
                $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
                $outgoing_call_ratio = $outgoing_call_ratio;
            } else {
                $outgoing_call_ratio = 0;
            }
        }

        $calls = DB::table('za_call_tracker')->select('za_call_tracker.*','za_staff.staff_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)    ;            // Filter by user ID
         

            
        // Date Filtering
        if ($date_filter === "today") {
            $calls->whereDate('za_call_tracker.call_start_date', now()->toDateString());
        } elseif ($date_filter === "week") {
            $calls->whereBetween('za_call_tracker.call_start_date', [now()->startOfWeek(), now()->endOfWeek()]);
        } elseif ($date_filter === "monthly") {
            $calls->whereMonth('za_call_tracker.call_start_date', now()->month)
                ->whereYear('za_call_tracker.call_start_date', now()->year);
        } elseif ($date_filter === "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $calls->whereBetween('za_call_tracker.call_start_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
            } elseif ($from_date_filter) {
                $calls->where('za_call_tracker.call_start_date', '>=', Carbon::parse($from_date_filter));
            } elseif ($to_date_filter) {
                $calls->where('za_call_tracker.call_start_date', '<=', Carbon::parse($to_date_filter));
            }
        }else{
            $calls->where('za_call_tracker.call_start_date', '>=', $call_start_date) // Start date filter
            ->where('za_call_tracker.call_start_date', '<=', $call_end_date);
        }

        // return $status;
        if (isset($status) && $status !='0') {
            if ($status == '2') {
                $calls->whereIn('za_call_tracker.call_status', [2, 3]);
            } elseif ($status == '1') {
                $calls->where('za_call_tracker.call_status', $status);
            }
        } else {
            $calls->where('za_call_tracker.call_status', 0);
        }

        $calls = $calls->orderBy('za_call_tracker.sno', 'desc')->paginate($perpage);

        $filter = false;
       
        return view('content.sales.manage_calls.lead_call_history', [
            'calls'               => $calls,
            'status'               => $status,
            'perpage'             => $perpage,
            'caller'              => $caller,
            'incoming_call_count' => $incoming_call_count,
            'outgoingcall_count'  => $outgoingcall_count,
            'missedcall_count'    => $missedcall_count,
            'rejected_call_count' => $rejected_call_count,
            'missed_call_ratio'   => $missed_call_ratio,
            'outgoing_call_ratio' => $outgoing_call_ratio,
            'date_filter'         => $date_filter,
            'status_fill'         => $status_fill,
            'fin_yr_fill'         => $fin_yr_fill,
            'from_date_filter'    => $from_date_filter,
            'to_date_filter'      => $to_date_filter,
            'filter'              => $filter,
        ]);
    }
    //manage team
    public function Add(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'head_staff_add' => 'required|max:255',
            'memb_staff_add' => 'required|array', // Ensure this is an array for proper handling
        ]);
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            $team_head_id   = $request->head_staff_add;
            $team_staff_ids = $request->memb_staff_add;
            $user_id        = $request->user()->user_id;

            $team_staff_ids = json_encode($team_staff_ids);

            $team_chk = ManageTeamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (! $team_chk) {

                $year    = substr(date('y'), -2);
                $team_id = 'TMCL-0001/' . $year;
            } else {

                $data   = $team_chk->team_id;
                $slice  = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);

                $next_number = (int) $result + 1;
                $request     = sprintf('TMCL-%04d', $next_number);

                $year    = substr(date('y'), -2);
                $team_id = $request . '/' . $year;
            }

            $add_team                = new ManageTeamModel();
            $add_team->team_id       = $team_id;
            $add_team->team_head_id  = $team_head_id;
            $add_team->team_staff_id = $team_staff_ids;
            $add_team->branch_id     = $branch_id;
            $add_team->created_by    = $user_id;
            $add_team->updated_by    = $user_id;

            $add_team->save();

            if ($add_team) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type'    => 'success',
                    'message' => 'Team added Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Could not add the Team!',
                ]);
            }

            return redirect('sales/manage_calls');

        }
    }
    public function Update(Request $request, $teamId)
    {
        $branchId = $request->user()->branch_id;

        $validator = Validator::make($request->all(), [
            'head_staff_edit' => 'required|max:255',
            'memb_staff_edit' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $teamHeadId   = $request->head_staff_edit;
        $teamStaffIds = json_encode($request->memb_staff_edit);
        $userId       = $request->user()->user_id;

        // Find the team by ID
        $team = ManageTeamModel::where('team_id', $teamId)->where('branch_id', $branchId)->first();

        if (! $team) {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Team not found!',
            ]);
            return redirect('sales/manage_calls');
        }

        // Update team details
        $team->team_head_id  = $teamHeadId;
        $team->team_staff_id = $teamStaffIds;
        $team->updated_by    = $userId;

        if ($team->update()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Team updated successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not update the team!',
            ]);
        }

        return redirect('sales/manage_calls');
    }
    //staff_list
    public function StaffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $dept_id   = $request->input('dept_id');
        $staff     = StaffModel::where('za_staff.status', '!=', 2)->join('za_team', 'za_staff.sno', '=', 'za_team.', 'left');
        // ->where('branch_id', $branch_id)
        if ($branch_id != 0) {
            $staff->where('za_staff.branch_id', $branch_id);
        }
        $staff = $staff->orderBy('za_staff.staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff,
        ], 200);
    }

    public function getCallHistory(Request $request)
    {
        $leadId = $request->lead_id;
        $status = $request->status;


        $caller = DB::table('za_lead')->select('za_lead.*')
        ->where('za_lead.sno', $leadId)
        ->first();

        $lead_mobile =$caller->lead_mobile;
        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo; 

       $calls = DB::table('za_call_tracker')
                ->select('za_call_tracker.*', 'za_staff.staff_name')
                ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
                ->where(function($query) use ($lead_mobile, $phoneWithCountryCode) {
                    $query->where('customer_phone_no', $lead_mobile)
                          ->orWhere('customer_phone_no', $phoneWithCountryCode);
                })
                ->where('count_status', 1);

                if ($status == "Incoming") {
                    $calls->where('za_call_tracker.call_status', 1);
                } elseif ($status == "Outgoing") {
                    $calls->where('za_call_tracker.call_status', 0);
                } elseif ($status == "Dialed") {
                    $calls->where('za_call_tracker.call_status', 4);
                } elseif ($status == "Missed & Rejected") {
                    $calls->whereIn('za_call_tracker.call_status', [2, 3]);
                }
                
                $calls = $calls->orderBy('za_call_tracker.sno', 'desc')->get();
          

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
        ]);
    }

    public function staffCallHistory(Request $request)
    {
        $staff_id = $request->staff_id;
        $year = $request->year;
        $month = $request->month;
    

        $caller = DB::table('za_staff')->select('za_staff.*')
        ->where('za_staff.sno', $staff_id)
        ->first();

        $calls = DB::table('za_call_tracker')->select('za_call_tracker.*')
            ->where('za_call_tracker.branch_staff_id', $staff_id)
            ->whereYear('za_call_tracker.call_start_date', $year)
            ->whereMonth('za_call_tracker.call_start_date', $month)
            ->orderBy('za_call_tracker.sno', 'desc')->get();  

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
        ]);
    }
    
    public function spamLeadConvertCalls(Request $request)
    {
        $converted_to = $request->lead_convert_to;
        $call_tracker_id = $request->cloud_call_id;
        $created_by = $request->sales_staff_add;
        $lead_name = $request->lead_name;
        $spam_reason = $request->spam_reason;
        $reason_text = $request->reason_text;
        $spam_comments = $request->spam_comments;
        // return $request;

        $cloud_call = CallTrackerModel::select('customer_phone_no', 'call_start_date')->where('sno', $call_tracker_id)->first();
        // return $cloud_call;

        if (strpos($cloud_call->customer_phone_no, '+91') === 0) {
            $country_code = '+91';
            $lead_mobile = substr($cloud_call->customer_phone_no, 3); // Remove the '+91' part
        } else {
            $country_code = '';
            $lead_mobile = $cloud_call->customer_phone_no; // No country code
        }

        $registered_date    = date('Y-m-d', strtotime($cloud_call->call_start_date));
        $user_id            = $request->user()->user_id;
        $branch_id          = $request->user()->branch_id;
    
        // return $lead_mobile;

            $chk = LeadModel::where('lead_mobile', $lead_mobile)->where('za_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();
            // return $chk;
            
            if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Mobile Number already created!'
            ]);
            } else {
                $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
                $branch_code = $branch_check->city_short_code;
        
                $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $year = date("Y");
                if (!$category_check) {
                    $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
                } else {
                    $data = $category_check->lead_id;
                    $slice = explode("/", $data);
                    $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number = (int)$resultcus + 1;
                    $request_pay = sprintf("LED%04d", $next_number);
                    $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
                }
    
                if($converted_to == 1){

                    $add_category = new LeadModel();
                    $add_category->lead_id                 = $lead_id;
                    $add_category->lead_name               = Ucfirst($lead_name);
                    $add_category->lead_mobile             = $lead_mobile;
                    $add_category->inter_calls             = $country_code;
                    $add_category->registered_date         = $registered_date;
                    $add_category->branch_id               = $branch_id;
                    $add_category->lead_source_id          = 4;
                    $add_category->call_tracker_id         = $call_tracker_id;
                    $add_category->created_by              = $created_by;
                    $add_category->updated_by              = $user_id;
                    $add_category->lead_status_id          = 1; 
                    $add_category->lead_condition          = 2; 

                    // return $add_category;
                    $add_category->save();
                    
                    if ($add_category) {
                        // return $add_category;
                        $add_history = new LeadTransferLogModel();
                        $add_history->lead_id = $add_category->sno;
                        $add_history->branch_id = $add_category->branch_id;
                        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                        $add_history->current_staff_id = $add_category->created_by;
                        $add_history->change_staff_id = 0;
                        $add_history->end_date = null;
                        $add_history->transferred_from = 10; // from Cloud Call
                        $add_history->created_by = $user_id;
                        $add_history->updated_by = $user_id;
                        // return $add_history;
                        $add_history->save();
                        
                    }
                    
                    
                    $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
                $branch_name = " ";
                if ($branch_data->branch_type == 1) {
                  $branch_name = $branch_data->branch_name;
                } elseif ($branch_data->branch_type == 2) {
                  $branch_name = $branch_data->franchise_name;
                }
                 // sms thank you lead
                if ($add_category) {
        
                  $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
                  $authkey = $result_sms ? $result_sms->authkey : '';
                  $sender_id = $result_sms ? $result_sms->sender_id : '';
                  $template_id = $result_sms ? $result_sms->template_id : '';
                  $country_code = $result_sms ? $result_sms->country_code : '';
                  $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                  $mobile_number = $country_code . $lead_mobile;
        
                  $cre_mobile = $branch_data->cre_mobile ?? '9677781155';
        
                  // Replace placeholders with actual values
                  $replacement_values = [$lead_name, $cre_mobile];
                  $message_content = preg_replace_callback(
                    '/\{#var#\}/',
                    function () use (&$replacement_values) {
                      return array_shift($replacement_values);
                    },
                    $message_content
                  );
        
                  $route = "default";
                  $postData = array(
                    'authkey' => $authkey,
                    'mobiles' => $mobile_number,
                    'message' => $message_content,
                    'sender' => $sender_id,
                    'route' => $route,
                  );
        
                  // API URL
                  $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
        
                  // Initialize the resource
                  $ch = curl_init();
                  curl_setopt_array($ch, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $postData,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSL_VERIFYPEER => 0,
                  ));
        
                  // Get response
                  $response = curl_exec($ch);
                  // return $response;
                  $err = curl_error($ch);
                  curl_close($ch);
                }
               
                // Thank whatsapp message
                if ($add_category) {
                  $templateName = "elysium_academy_welcome_message";
                $templateHeaderMediaId = '2694538814216613';  
                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";
                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                  // $currentHour = date('H'); // Get current hour in 24-hour format
                  if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                  } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                  } else {
                    $greeting = 'Good Evening';
                  }
        
                  if ($templateName == 'elysium_academy_welcome_message') {
        
                    $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
                    $couponCode  = 'NOOFFER';
                    $buttonIndex = 0;
                    $bodyText    = [
                      [
                        'type'           => 'text',
                        'text'           => $greeting,
                        'parameter_name' => 'greet_msg',
                      ],
                      [
                        'type'           => 'text',
                        'text'           => $lead_name,
                        'parameter_name' => 'customer_name',
                      ],
                      [
                        'type'           => 'text',
                        'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                        'parameter_name' => 'web_link',
                      ],
                      [
                        'type'           => 'text',
                        'text'           => $branch_name,
                        'parameter_name' => 'branch_name',
                      ],
                      [
                        'type'           => 'text',
                        'text'           => $branch_data->cre_mobile ?? '9677781155',
                        'parameter_name' => 'contact_no',
                      ],
                      [
                        'type'           => 'text',
                        'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                        'parameter_name' => 'contact_email',
                      ],
                    ];
                    $hasHeader = true;
                    $hasBody   = true;
                    $hasButton = true;
                  }
        
                  // Add Header if required
                  if ($hasHeader) {
                    $components[] = [
                      'type'       => 'header',
                      'parameters' => [
                        [
                          'type'  => 'image',
                          'image' => [
                                      'id' => $templateHeaderMediaId
                                    ],
                        //   'image' => [
                        //     'link' => $headerImage, // Dynamically set header image
                        //   ],
                        ],
                      ],
                    ];
                  }
        
                  // Add Body if required
                  if ($hasBody) {
                    $components[] = [
                      'type'       => 'body',
                      'parameters' => $bodyText,
                    ];
                  }
        
                  // Add Footer if required
                  if ($hasFooter) {
                    $components[] = [
                      'type'       => 'footer',
                      'parameters' => [
                        [
                          'type'           => 'text',
                          'text'           => 'This is the footer text.',
                          'parameter_name' => 'footer_text',
                        ],
                      ],
                    ];
                  }
        
                  // Add Button if required
                  if ($hasButton) {
                    $components[] = [
                      'type'       => 'button',
                      'sub_type'   => 'copy_code',
                      'index'      => $buttonIndex,
                      'parameters' => [
                        [
                          'type'        => 'coupon_code',
                          'coupon_code' => $couponCode,
                        ],
                      ],
                    ];
                  }
        
                  $dynamicParameters         = $templateParameters[$templateName] ?? [];
                  $WhatsAppBusinessAccountId = $this->businessId;
                  $accessToken               = $this->accessToken;
                  $fromPhoneNumberId         = $this->phoneNumberId;
        
                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
        
                  $to           = $lead_mobile;
                  $languageCode = 'en_US';
        
                  if (strpos($to, '+91') !== 0) {
                    $to = '+91' . $to;
                  }
        
                  $message = 'test~message';
                  if (empty($components)) {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'     => $templateName,
                        'language' => [
                          'code' => $languageCode,
                        ],
                      ],
                    ];
                  } else {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                          'code' => $languageCode,
                        ],
                        'components' => $components,
                      ],
                    ];
                  }
        
                    $response = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                    
                    if ($response['status'] == 200) {
                            // 1. Lead Add 
                            $log_branch_id = $branch_id;
                            $unique_id = $add_category->sno;
                            $source ='Lead';
                            $log_phone_no =$to;
                            $log_template_name =$templateName;

                            $save_log = $this->WhatsappSendLog(
                                $response,
                                $payload,
                                $log_phone_no,
                                $log_template_name,
                                $user_id,
                                $log_branch_id,
                                $unique_id,
                                $source
                            );
                    }

                }
                    if ($add_category) {
                        session()->flash('toastr', [
                          'type' => 'success',
                          'message' => 'Lead added Successfully!'
                        ]);
                      } else {
                        session()->flash('toastr', [
                          'type' => 'error',
                          'message' => 'Could not add the Lead!'
                        ]);
                      }
                } else if($converted_to == 2){
                    $add_category = new LeadModel();
                    $add_category->lead_id                 = $lead_id;
                    $add_category->lead_name               = Ucfirst($lead_name);
                    $add_category->lead_mobile             = $lead_mobile;
                    $add_category->inter_calls             = $country_code;
                    $add_category->registered_date         = $registered_date;
                    $add_category->branch_id               = $branch_id;
                    $add_category->lead_source_id          = 4;
                    $add_category->call_tracker_id         = $call_tracker_id;
                    $add_category->created_by              = $created_by;
                    $add_category->updated_by              = $user_id;
                    $add_category->status                  = 7;
                    $add_category->lead_status_id          = 6;
                    $add_category->spam_verified           = 0;
                    $add_category->spam_tl_verified        = 0;
                    $add_category->lead_condition          = 2; 
                    if ($spam_reason == 1) {
                        $add_category->spam_reason = $request->reason_text;  // Set drop_reason from drop_reason_text
                     } else {
                       $spam = SpamReasonModel::where('reason_name', $spam_reason)->first();
                      // return $spam;
                       if ($spam->comments_check == 1) {
                         $add_category->spam_comments = $request->spam_comments;
                       }
                       $add_category->spam_reason = $spam_reason;
                    }
                    // return $add_category;
                    $add_category->save();
                    
                    if ($add_category) {
                        // return $add_category;
                        $add_history = new LeadTransferLogModel();
                        $add_history->lead_id = $add_category->sno;
                        $add_history->branch_id = $add_category->branch_id;
                        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                        $add_history->current_staff_id = $add_category->created_by;
                        $add_history->change_staff_id = 0;
                        $add_history->end_date = null;
                        $add_history->transferred_from = 11; // from Cloud Call Spam
                        $add_history->created_by = $user_id;
                        $add_history->updated_by = $user_id;
                        // return $add_history;
                        $add_history->save();
                    }
                    if ($add_category) {
                        session()->flash('toastr', [
                          'type' => 'success',
                          'message' => 'Spam Lead added Successfully!'
                        ]);
                      } else {
                        session()->flash('toastr', [
                          'type' => 'error',
                          'message' => 'Could not add the Lead!'
                        ]);
                      }
                }
        }

        return redirect('sales/manage_calls');
    }

private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
    private function WhatsappSendLog(
        array $response,
        array $payload,
        string $phone_no,
        string $template_name,
        int $user_id,
        int $branch_id = 0,
        int $unique_id = 0,
        ?string $source = null
    ) {
        $messageId = $response['data']['messages'][0]['id'] ?? null;

        return WhatsappTemplateLogModel::create([
            'phone_no' => $phone_no,
            'branch_id' => $branch_id,
            'unique_id' => $unique_id,
            'id_source' => $source,
            'template_name' => $template_name,
            'message_date_time' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            'type' => 'template',
            'from' => 1,
            'wama_id' => $messageId,
            'payload' => json_encode($payload),
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'message_status' => 'sent',
        ]);
    }

    // new changes 17-08-26
    public function index(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
            $user_id = $request->user()->user_id;

        $call_fill        = $request->input('search_filter', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        $helper = new \App\Helpers\Helpers();
    
        if ($request->ajax()) {

            $idQuery = DB::table('za_call_tracker as ct')
                    ->select('ct.sno')
                    ->where('ct.branch_id', $branch_id)
                    ->whereIn('ct.call_status',[0,1,2,3,4]);

            if (!$from_date_filter && !$to_date_filter) {
                $start = Carbon::create($year,$month,1)->startOfMonth();
                $end = Carbon::create($year,$month,1)->endOfMonth();
                $idQuery->whereBetween('ct.call_start_date',[$start,$end]);
            }else{
                $idQuery->whereBetween('ct.call_start_date', [$from_date_filter,$to_date_filter]);
            }

            if(auth()->user()->hasPermissionradio('Lead Management','Manage Calls','view_self_lead')){
                $idQuery->where('ct.branch_staff_id',$user_id);
            }

            if($staff_fill!=''){
                $idQuery->where('ct.branch_staff_id', $staff_fill );
            }

            if ($status_fill) {
                $idQuery->where('ct.call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $idQuery->where('ct.call_status', $status_fill);
            }

            if($call_fill!=''){
                $idQuery->where(function($q)use($call_fill){
                    $q->where('ct.customer_phone_no','like',"%{$call_fill}%")
                    ->orWhere('ct.staff_phone_no','like', "%{$call_fill}%")
                    ->orWhere('ct.customer_name','like',"%{$call_fill}%");
                });
            }

            $ids=$idQuery
                ->orderByDesc('ct.call_start_date')
                ->orderByDesc('ct.call_start_time')
                ->paginate($perpage,['ct.sno']);

           

            $callIds=$ids->pluck('sno')->toArray();

            //  return $callIds;


            $calls = DB::table('za_call_tracker as ct')
                    ->select(
                        'ct.sno',
                        'ct.call_status',
                        'ct.staff_phone_no',
                        'ct.customer_name',
                        'ct.customer_phone_no',
                        'ct.call_start_date',
                        'ct.call_start_time',
                        'ct.call_end_time',
                        'ct.call_duration',
                        'ct.latitude',
                        'ct.longitude',
                        'ct.audio_file',

                        'l.lead_name',
                        'l.drop_verified',
                        'l.drop_tl_verified',
                        'l.spam_verified',
                        'l.spam_tl_verified',
                        'l.status as lead_status',

                        's.staff_name',

                        'sb.staff_name as lead_staff',

                        'l.created_by',

                        'ic.user_name as internal_user_name'
                    )
                    ->join('za_staff as s','s.sno','=','ct.branch_staff_id')
                    ->leftJoin('za_lead as l',function($join){
                            $join->on('l.lead_mobile', '=', DB::raw('RIGHT(ct.customer_phone_no,10)'));
                        })
                    ->leftJoin('za_Internal_cugs as ic',function($join){
                            $join->on('ic.cug_mobile_no', '=', DB::raw('RIGHT(ct.customer_phone_no,10)'));
                        }
                    )
                    ->leftJoin('za_staff as sb','sb.sno','=','l.created_by')
                    ->whereIn('ct.sno',$callIds )
                    ->where('s.branch_id',$branch_id)
                    ->orderByDesc('ct.call_start_date')
                    ->orderByDesc('ct.call_start_time')
                    ->get();

                $calls = new LengthAwarePaginator(
                            $calls,
                            $ids->total(),
                            $ids->perPage(),
                            $ids->currentPage(),
                            [
                                'path'=>request()->url(),
                                'query'=>request()->query()
                            ]
                        );

            
                
        
            $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();

             $monthStart = Carbon::create($year, $month, 1)->startOfMonth();
            $monthEnd   = Carbon::create($year, $month, 1)->endOfMonth();

            $cacheKey = 'manage_calls_dashboard_' .
            $branch_id . '_' .
            $user_id . '_' .
            $month . '_' .
            $year . '_' .
            $staff_fill . '_' .
            $status_fill;

        $call_counts = Cache::remember(
        $cacheKey,
        now()->addMinutes(2),
        function () use (
            $branch_id,
            $user_id,
            $staff_fill,
            $status_fill,
            $from_date_filter,
            $to_date_filter,
            $monthStart,
            $monthEnd
        ) {

            $query = DB::table('za_call_tracker')
                ->selectRaw("
                    COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                    COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                    COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                    COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                    COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                ")
                ->where('branch_id', $branch_id);

            if (!$from_date_filter && !$to_date_filter) {

                $query->whereBetween(
                    'call_start_date',
                    [$monthStart, $monthEnd]
                );

            } else {

                $query->whereBetween(
                    'call_start_date',
                    [$from_date_filter, $to_date_filter]
                );

            }

            if (auth()->user()->hasPermissionradio('Lead Management','Manage Calls','view_self_lead')) {
                $query->where('branch_staff_id',$user_id);
            }

            if ($staff_fill != '') {
                $query->where('branch_staff_id',$staff_fill);
            }

            if ($status_fill) {
                $query->where('call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $query->where('call_status', $status_fill);
            }

            

            return $query->first();
        }
        );
        
            $incoming_call_count = (int) ($call_counts->incoming_call_count ?? 0);
            $outgoingcall_count  = (int) ($call_counts->outgoing_call_count ?? 0);
            $missedcall_count    = (int) ($call_counts->missedcall_count ?? 0);
            $rejected_call_count = (int) ($call_counts->rejected_call_count ?? 0);
            $dialedcall_count    = (int) ($call_counts->dialedcall_count ?? 0);
        
            $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
                ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
                : 0;
        
            $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
                ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
                : 0;
        
                //  $loginData = DB::connection('mysql_secondary')
                //     ->table('user as u')
                //     ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
                //     ->whereIn('u.phone_no', $staffPhones)
                //     ->get()
                //     ->keyBy('phone_no');
            $lastLoginDataMap = [];

            if (!empty($staffPhones)) {

                $lastLoginDataMap = DB::table('mobile_user_login_logs as l')
                    ->select(
                        'l.mobile_no',
                        'l.login_at'
                    )
                    ->join(
                        DB::raw("
                            (
                                SELECT
                                    mobile_no,
                                    MAX(login_at) AS last_login
                                FROM mobile_user_login_logs
                                WHERE type = 0
                                GROUP BY mobile_no
                            ) latest
                        "),
                        function ($join) {
                            $join->on('latest.mobile_no', '=', 'l.mobile_no')
                                ->on('latest.last_login', '=', 'l.login_at');
                        }
                    )
                    ->whereIn('l.mobile_no', $staffPhones)
                    ->get()
                    ->keyBy('mobile_no');
            }

            $data = $calls->map(function ($item) use ($helper) {

            

                // Call icon
                switch ($item->call_status) {
                    case 0:
                        $bgColor = "";
                        $img = "outgoing.png";
                        break;
                    case 1:
                        $bgColor = "";
                        $img = "incoming.png";
                        break;
                    case 2:
                         $bgColor="#ffcf9f !important;";
                        $img = "missed.png";
                        break;

                    case 3:
                        $bgColor="#FF7979 !important;";
                        $img = "rejected.png";
                        break;
                    default:
                        $bgColor = "";
                        $img = "outgoing.png";
                }

               $lastLogin = $lastLoginDataMap[$item->staff_phone_no] ?? null;

                $lastLoginDate = null;
                $lastLoginTime = null;
                $duration = '';

                if ($lastLogin && $lastLogin->login_at) {

                    $loginAt = Carbon::parse($lastLogin->login_at);

                    $lastLoginDate = $loginAt->format('Y-m-d');

                    $lastLoginTime = $loginAt->format('H:i:s');

                    $duration = $loginAt->diffForHumans([
                        'parts' => 2,
                        'short' => true,
                    ]);
                }

                $audioSize = '';

                if (!empty($item->audio_file)) {
                    $path = public_path('call_audios/'.$item->audio_file);
                    if (file_exists($path)) {
                        $bytes = filesize($path);
                        if ($bytes >= 1048576) {
                            $audioSize = round($bytes / 1048576, 2).' MB';
                        } else {
                            $audioSize = round($bytes / 1024, 2).' KB';
                        }
                    }
                }

                return [
                    'sno' => $item->sno,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),

                    'bgColor' => $bgColor,
                    'img' => $img,
                    'audio_size' => $audioSize,
                    'last_login_date' => optional($lastLogin)->last_sync_date,
                    'last_login_time' => optional($lastLogin)->last_sync_time,
                    // 'duration' => $this->getDuration(optional($lastLogin)->last_sync_date, optional($lastLogin)->last_sync_time),
                    'duration' => '',

                    'data' => $item,
                ];
            });

            $month_name=Carbon::createFromFormat('m', $month)->format('F');

            return response()->json([
                'data' => $data,
                'current_page' => $calls->currentPage(),
                'last_page' => $calls->lastPage(),
                'total' => $calls->total(),
                'incoming_call_count' => $incoming_call_count,
                'outgoingcall_count'  => $outgoingcall_count,
                'missedcall_count'    => $missedcall_count,
                'rejected_call_count' => $rejected_call_count,
                'dialedcall_count'    => $dialedcall_count,
                'missed_call_ratio'   => $missed_call_ratio,
                'outgoing_call_ratio' => $outgoing_call_ratio,
                'month_name' => $month_name,
                'month_chk'           => $month_chk,
                'month_filter'           => $monthFilter,
            ]);
        }

    
            $staff_list = Cache::remember("staff_list_branch_{$branch_id}", 300, function () use ($branch_id) {
                return DB::table('za_cug_management')
                    ->select(
                        'za_cug_management.staff_id',
                        'za_staff.staff_name',
                        'za_staff.nick_name',
                        'za_staff.staff_image',
                        'za_staff.gender',
                        'za_staff.mobile_no',
                        'za_department.department_name'
                    )
                    ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
                    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
                    ->where('za_staff.status', '!=', 2)
                     ->where('za_staff.branch_id',$branch_id)
                    // ->where('za_department.sno', 1)
                    ->distinct()
                    ->get();
            });
        
            $reasonList = SpamReasonModel::where('status', 0)
                ->orderBy('sno', 'desc')
                ->get();

        return view('content.sales.manage_calls.call_list',[
            'perpage' => $perpage,
            'staff_list' => $staff_list,
            'reasonList'          => $reasonList,
            'month_chk'           => $month_chk,
        ]);
    }

    public function getCallHistoryCustomer(Request $request)
    {
        $customerId = $request->lead_id;
        $status = $request->status;

             $branch_id = $request->user()->branch_id;           

        $caller = DB::table('za_customer')->select('za_customer.*')
        ->where('za_customer.sno', $customerId)
        ->first();
        $cus_mobile =$caller->cus_mobile;
        $normalizedPhoneNo    = ltrim($cus_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;
        // return $phoneWithCountryCode ;
          $cug_numbers = DB::table('za_cug_management')
        ->select('za_cug_management.*')
        ->join('za_staff', 'za_staff.sno', '=', 'za_cug_management.staff_id')
        ->where('za_staff.department_id', 2)
        ->where('za_staff.branch_id',$branch_id)
        ->orderBy('za_cug_management.sno', 'desc')
        ->get();
    
            // Get only mobile numbers as array
         $cugMobiles = $cug_numbers->pluck('staff_mobile')->toArray();
        // return $cugMobiles;
        $calls = DB::table('za_call_tracker')
            ->where('za_staff.branch_id',$branch_id)
            ->select('za_call_tracker.*', 'za_staff.staff_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
            ->where(function ($query) use ($cus_mobile, $phoneWithCountryCode) {
                $query->where('customer_phone_no', $cus_mobile)
                    ->orWhere('customer_phone_no', $phoneWithCountryCode);
            })
            ->where('count_status', 1)
            ->whereIn('za_call_tracker.staff_phone_no', $cugMobiles);

            if ($status == "Incoming") {
                $calls->where('za_call_tracker.call_status', 1);
            } elseif ($status == "Outgoing") {
                $calls->where('za_call_tracker.call_status', 0);
            } elseif ($status == "Dialed") {
                $calls->where('za_call_tracker.call_status', 4);
            } elseif ($status == "Missed & Rejected") {
                $calls->whereIn('za_call_tracker.call_status', [2, 3]);
            }

            $calls = $calls->orderBy('za_call_tracker.sno', 'desc')->get();
          

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
        ]);
    }


    public function cugDepartments(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $departments = Cache::remember(
            'cug_departments_v2',
            now()->addMinutes(10),
            function () use ($branch_id) {

                return DB::table('za_staff as s')
                    ->where('s.branch_id',$branch_id)
                    ->join('za_cug_management as cug', function ($join) {
                        $join->on('cug.staff_id', '=', 's.sno')
                            ->where('cug.status', 0);
                    })
                    ->join('za_department as d', 'd.sno', '=', 's.department_id')
                    ->where('s.status', 0)
                    ->select(
                        'd.sno as department_id',
                        'd.department_name',
                        DB::raw('COUNT(s.sno) as staff_count'),
                        DB::raw('SUM(CASE WHEN cug.online_status = 1 THEN 1 ELSE 0 END) as online_count')
                    )
                    ->groupBy(
                        'd.sno',
                        'd.department_name'
                    )
                    ->orderBy('d.sno','asc')
                    ->get();

            }
        );

        return response()->json([
            'status' => true,
            'data'   => $departments
        ]);
    }

     public function cugStaffList(Request $request)
    {
        /* Month / Year */

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y',$monthFilter );
        } catch (\Throwable $e) {
            $parsedDate = now()->startOfMonth();
        }

        $month = $parsedDate->month;
        $year  = $parsedDate->year;
        $branch_id = $request->user()->branch_id;

        /* Pagination */

        $limit = min( max((int) $request->get('limit', 50), 10), 100 );
        $page = max((int) $request->get('page', 1),1);

        /* Call Summary */

        $callSummary = DB::table('za_call_tracker')
            ->select(
                'staff_phone_no',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoing"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missed"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialed"),
                 DB::raw("MAX(CONCAT( call_start_date, ' ', call_start_time)) AS last_call_at")
            )
            ->whereYear('call_start_date',$year)
            ->whereMonth('call_start_date',$month)
            ->groupBy('staff_phone_no');

        /* Staff Query */

        $query = DB::table('za_staff as s')
            ->where('s.branch_id',$branch_id)
            ->join('za_cug_management as cug', function ($join) {
                $join->on('cug.staff_id','=','s.sno')
                ->where( 'cug.status', 0);
            })
            ->leftJoin('za_job_position as jp','jp.sno', '=','s.position_role')
            ->join('users', 'users.user_id', '=','s.sno')
            ->leftJoinSub($callSummary,'calls',
                function ($join) {
                    $join->on('calls.staff_phone_no','=', 'cug.staff_mobile');
                }
            )
            ->where('s.status', 0);

        /* Department */

        $query->when(
            $request->filled('department_id'),
            function ($q) use ($request) {
                $q->where('s.department_id', $request->department_id);
            }
        );

        /* Online / Offline */
        $query->when(
            $request->filled('online'),
            function ($q) use ($request) {
                $q->where('cug.online_status', $request->online);
            }
        );

        /* Search */
        $query->when(
            $request->filled('search'),
            function ($q) use ($request) {
                $search = trim($request->search);
                $q->where(
                    function ($sub) use ($search) {
                        $sub->where( 's.staff_name', 'LIKE',"%{$search}%")
                        ->orWhere('cug.staff_mobile','LIKE',"%{$search}%" );
                    }
                );
            }
        );

        /* Summary */
        $summary = (clone $query)
            ->selectRaw(
                "COUNT(*) AS total_staff,
                SUM(
                    CASE
                        WHEN cug.online_status = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS online,
                SUM(
                    CASE
                        WHEN cug.online_status = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS offline,
                COALESCE(
                    SUM(
                        COALESCE(calls.incoming, 0) +
                        COALESCE(calls.outgoing, 0) +
                        COALESCE(calls.missed, 0) +
                        COALESCE(calls.rejected, 0) +
                        COALESCE(calls.dialed, 0)
                    ),
                    0
                ) AS total_calls,

                COALESCE(
                    SUM(
                        COALESCE(calls.missed, 0)
                    ),
                    0
                ) AS missed,

                COALESCE(
                    SUM(
                        COALESCE(calls.incoming, 0)
                    ),
                    0
                ) AS incoming,
                COALESCE(
                    SUM(
                        COALESCE(calls.outgoing, 0)
                    ),
                    0
                ) AS outgoing,

                COALESCE(
                    SUM(
                        COALESCE(calls.rejected, 0)
                    ),
                    0
                ) AS rejected,

                COALESCE(
                    SUM(
                        COALESCE(calls.dialed, 0)
                    ),
                    0
                ) AS dialed
            ")
            ->first();


        /* Staff List */

        $staff = $query
            ->select(
                's.sno as staff_id',
                's.staff_name',
                'users.id as user_id',
                's.staff_image',
                's.gender',
                's.status as staff_status',
                'cug.staff_mobile as cug_mobile',
                'cug.online_status',
                'cug.last_online_at',
                'cug.last_terminate_at',
                'cug.last_checking',
                'cug.live_status',
                'jp.job_position_name',
                DB::raw("COALESCE(calls.incoming, 0) AS incoming"),
                DB::raw("COALESCE(calls.outgoing, 0) AS outgoing"),
                DB::raw("COALESCE(calls.missed, 0) AS missed"),
                DB::raw("
                    COALESCE(
                        calls.rejected,
                        0
                    ) AS rejected
                "),

                DB::raw("
                    COALESCE(
                        calls.dialed,
                        0
                    ) AS dialed
                "),
                DB::raw("
                    calls.last_call_at AS last_call_at
                "),
                DB::raw("
                    CASE
                        WHEN cug.live_status = 1
                            AND cug.last_checking IS NOT NULL
                            AND cug.last_checking >= DATE_SUB(NOW(), INTERVAL 20 MINUTE)
                        THEN 1
                        ELSE 0
                    END AS last_checking_status
                "),

            )

            ->orderByDesc(
                'cug.online_status'
            )

            ->orderBy(
                's.staff_name'
            )

            ->paginate(
                $limit,
                ['*'],
                'page',
                $page
            );


        /*
        |--------------------------------------------------------------------------
        | Last Login - ONE QUERY
        |
        | Avoid N+1 query inside transform()
        |--------------------------------------------------------------------------
        */

        $userIds = $staff
            ->getCollection()
            ->pluck('user_id')
            ->filter()
            ->values()
            ->toArray();


        $lastLogins = collect();


        if (!empty($userIds)) {

            $lastLogins = DB::table(
                'mobile_user_login_logs'
            )

            ->select(
                'user_id',
                'login_at'
            )

            ->whereIn(
                'user_id',
                $userIds
            )

            ->where(
                'type',
                0
            )

            ->orderByDesc(
                'login_at'
            )

            ->get()

            ->unique(
                'user_id'
            )

            ->keyBy(
                'user_id'
            );

        }


        /*
        |--------------------------------------------------------------------------
        | Transform
        |--------------------------------------------------------------------------
        */

        
                $startDate = Carbon::create($year, $month, 1);
                    $currentDate = Carbon::now();
                    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
                        ? $currentDate
                        : $startDate->copy()->endOfMonth();
                    $dayCount = $startDate->diffInDays($endDate) + 1;

        $staff->getCollection()->transform(
            function ($row) use ($lastLogins,$dayCount) {

                $row->encrypted_id = $row->cug_mobile ? encrypt($row->cug_mobile) : NULL;

                /*
                |--------------------------------------------------------------------------
                | Last Login
                |--------------------------------------------------------------------------
                */

                $login = $lastLogins->get(
                    $row->user_id
                );

                if ($login && $login->login_at) {

                    $loginAt = Carbon::parse(
                        $login->login_at
                    );

                    $row->last_login_date =
                        $loginAt->format('Y-m-d');

                    $row->last_login_time =
                        $loginAt->format('h:i:s A');

                } else {

                    $row->last_login_date = null;

                    $row->last_login_time = null;

                }

                $lastOnlineDate =NULL;
                $lastOnlineTime =NULL;
                $lastOnlineDuration =NULL;
                
                $lastOfflineDate = null;
                $lastOfflineTime = null;
                $lastOfflineDuration = null;

                $lastLiveDate = null;
                $lastLiveTime = null;
                $lastLiveDuration = null;

                if ($row->last_online_at) {
                    $lastOnlineAt = Carbon::parse($row->last_online_at);
                    $lastOnlineDate = $lastOnlineAt->format('Y-m-d');
                    $lastOnlineTime = $lastOnlineAt->format('H:i:s');
                    $lastOnlineDuration = $lastOnlineAt->diffForHumans([
                        'parts' => 2,
                        'short' => true,
                    ]);
                }
                
                if ($row->last_terminate_at) {
                    $lastOfflineAt = Carbon::parse($row->last_terminate_at);
                    $lastOfflineDate = $lastOfflineAt->format('Y-m-d');
                    $lastOfflineTime = $lastOfflineAt->format('H:i:s');
                    $lastOfflineDuration = $lastOfflineAt->diffForHumans([
                        'parts' => 2,
                        'short' => true,
                    ]);
                }

                $row->last_checking_status =0;

                if ($row->last_checking) {
                    $lastLiveAt = Carbon::parse($row->last_checking);
                    $row->last_checking_status = (
                        (int) $row->live_status === 1
                        && $row->last_checking
                        && Carbon::parse($row->last_checking)->gte(
                            Carbon::now()->subMinutes(20)
                        )
                    ) ? 1 : 0;
                    $lastLiveDate = $lastLiveAt->format('Y-m-d');
                    $lastLiveTime = $lastLiveAt->format('H:i:s');
                    $lastLiveDuration = $lastLiveAt->diffForHumans([
                        'parts' => 2,
                        'short' => true,
                    ]);
 
                }

                

                    $row->last_live_date = $lastLiveDate;
                    $row->last_live_time = $lastLiveTime;
                    $row->last_live_duration = $lastLiveDuration;


                  $row->last_online_date = $lastOnlineDate;
                  $row->last_online_time = $lastOnlineTime;
                  $row->last_online_duration = $lastOnlineDuration;

                    $row->last_offline_date = $lastOfflineDate;
                    $row->last_offline_time = $lastOfflineTime;
                    $row->last_offline_duration = $lastOfflineDuration;

                /*
                |--------------------------------------------------------------------------
                | Last Call
                |--------------------------------------------------------------------------
                */

                if ($row->last_call_at) {

                    $lastCallAt = Carbon::parse( $row->last_call_at);
                    $row->last_call_date = $lastCallAt->format('Y-m-d');
                    $row->last_call_time =  $lastCallAt->format('h:i:s A');
                    $row->last_call_duration =
                        $lastCallAt->diffForHumans([
                            'parts' => 2,
                            'short' => true,
                        ]);

                } else {
                    $row->last_call_date = null;
                    $row->last_call_time = null;
                    $row->last_call_duration = null;

                }

               

                /*
                |--------------------------------------------------------------------------
                | Call Counts
                |--------------------------------------------------------------------------
                */

                $row->incoming = (int) $row->incoming;

                $row->outgoing = (int) $row->outgoing;

                $row->missed = (int) $row->missed;

                $row->rejected = (int) $row->rejected;

                $row->dialed = (int) $row->dialed;


                /*
                |--------------------------------------------------------------------------
                | Total Calls
                |--------------------------------------------------------------------------
                */

                $totalCalls =
                    $row->incoming +
                    $row->outgoing +
                    $row->missed +
                    $row->rejected +
                    $row->dialed;


                $row->total_calls =
                    $totalCalls;


                /*
                |--------------------------------------------------------------------------
                | Call Percentage
                |--------------------------------------------------------------------------
                |
                | Same concept used by your CUG table.
                |--------------------------------------------------------------------------
                */


                    $row->ocr = $dayCount > 0 ? round($row->outgoing / $dayCount) : 0;

                    $row->rcr= $dayCount > 0 ? round($row->incoming / $dayCount) : 0;
                    
                    $row->mcr = $dayCount > 0 ? round($row->missed / $dayCount) : 0;

                
                /*
                |--------------------------------------------------------------------------
                | Missed Call Ratio
                |
                | Match your TeamCall() calculation:
                | incoming + missed + rejected
                |--------------------------------------------------------------------------
                */

                $missedRatioTotal =
                    $row->incoming +
                    $row->missed +
                    $row->rejected;


                $row->missed_call_ratio =
                    $missedRatioTotal > 0
                        ? round(
                            ($row->missed / $missedRatioTotal) * 100,
                            1
                        )
                        : 0;


                return $row;

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'status' => true,

            'summary' => [
                'total_staff' => (int) ($summary->total_staff ?? 0),
                'online' => (int) ($summary->online ?? 0),
                'offline' =>  (int) ($summary->offline ?? 0),
                'total_calls' => (int) ($summary->total_calls ?? 0),
                'incoming' =>  (int) ($summary->incoming ?? 0),
                'outgoing' => (int) ($summary->outgoing ?? 0),
                'missed' => (int) ($summary->missed ?? 0),
                'rejected' => (int) ($summary->rejected ?? 0),
                'dialed' => (int) ($summary->dialed ?? 0),
            ],

            'data' => $staff->items(),
            'pagination' => [
                'current_page' =>  $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'per_page' => $staff->perPage(),
                'total' => $staff->total(),
                'has_more' => $staff->hasMorePages(),
            ],

        ]);
    }

    public function cugIndex(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
        $user_id = $request->user()->user_id;

        $call_fill        = $request->input('call_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }


        $helper = new \App\Helpers\Helpers();
    
       

        return view('content.team_management.cug_management.cug_list',[
        ]);
    }
    
     public function getMonthStaffLocations($id, Request $request)
    {
        
        $staffCug = $id ? decrypt($id) : NULL;
        // return $staffCug;
        $branch_id = $request->user()->branch_id;

        if (!$staffCug) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid staff Mobile.',
                'data'    => [],
            ], 422);
        }

            $monthFilter = $request->get('month_filter', now()->format('M-Y'));

            try {

                $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);

                $month = $parsedDate->month;
                $year  = $parsedDate->year;

                $startDate = $parsedDate->copy()->startOfMonth()->startOfDay();
                $endDate   = $parsedDate->copy()->endOfMonth()->endOfDay();

            } catch (\Throwable $e) {

                return response()->json([
                    'status'  => false,
                    'message' => 'Invalid month format. Use M-Y.',
                    'data'    => [],
                ], 422);
            }

        if ($startDate->gt($endDate)) {

            return response()->json([
                'status'  => false,
                'message' => 'Start date cannot be greater than end date.',
                'data'    => [],
            ], 422);

        }

        if ($startDate->diffInDays($endDate) > 31) {

            return response()->json([
                'status'  => false,
                'message' => 'Maximum location date range is 31 days.',
                'data'    => [],
            ], 422);

        }

        $staff = DB::table('za_staff as s')
            ->where('s.branch_id',$branch_id)
            ->leftJoin('za_department as d','d.sno','=','s.department_id')
            ->leftJoin('za_job_position as jp','jp.sno','=','s.position_role')
            ->join('za_cug_management as cug',
                function ($join) {
                    $join->on('cug.staff_id', '=','s.sno' )
                    ->where('cug.status', 0);
                }
            )
            ->where('cug.staff_mobile', $staffCug)
            ->select(
                's.sno as staff_id',
                's.staff_name',
                's.staff_image',
                's.gender',
                's.mobile_no',
                'd.department_name',
                'jp.job_position_name',
                'cug.staff_mobile as cug_mobile',
                'cug.online_status'

            )
            ->first();


        if (!$staff) {
            return response()->json([
                'status'  => false,
                'message' => 'Staff not found.',
                'data'    => [],
            ], 404);

        }

        $rawMobile = preg_replace(
            '/\D+/',
            '',
            (string) $staff->cug_mobile
        );

        $phoneNumbers = collect([
            $rawMobile,
            '+91' . $rawMobile,
            '91' . $rawMobile,
        ])
            ->filter()
            ->unique()
            ->values()
            ->toArray();

        $callsQuery = DB::table('za_call_tracker')
            ->whereBetween( 'call_start_date',[ $startDate, $endDate])
            ->where(function ($query) use ($phoneNumbers) {
                foreach ($phoneNumbers as $phone) {
                    $query->orWhere('staff_phone_no', $phone );
                }
            });

        $totalCalls = (clone $callsQuery)->count();

        $maxLocations = min( max((int) $request->input('limit', 2000 ), 100 ), 5000 );

        $calls = $callsQuery
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->whereNot('latitude',0)
            ->whereNot('longitude',0)
            ->orderBy('call_start_date','desc' )
            ->orderBy('call_start_time', 'desc')
            ->limit($maxLocations)
            ->get();


        $locations = [];

        foreach ($calls as $call) {

            /* Coordinates */
            $latitude = filter_var( $call->latitude, FILTER_VALIDATE_FLOAT );
            $longitude = filter_var( $call->longitude, FILTER_VALIDATE_FLOAT );

            /* Validate Coordinates */
            if ($latitude === false || $longitude === false ) {
                continue;
            }

            if ($latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
                continue;
            }

            /* Call Status */

            $status = (int) ($call->status ?? $call->call_status ?? 3);

            switch ($status) {
                case 0:
                    $statusText  = 'Outgoing';
                    $statusClass = 'outgoing';
                    $statusIcon  = 'mdi-phone-outgoing';
                    break;
                case 1:
                    $statusText  = 'Incoming';
                    $statusClass = 'incoming';
                    $statusIcon  = 'mdi-phone-incoming';
                    break;
                case 2:
                    $statusText  = 'Missed';
                    $statusClass = 'missed';
                    $statusIcon  = 'mdi-phone-missed';
                    break;
                case 3:
                    $statusText  = 'Rejected';
                    $statusClass = 'rejected';
                    $statusIcon  = 'mdi-phone-cancel';
                    break;
                case 4:
                    $statusText  = 'Dialed';
                    $statusClass = 'dialed';
                    $statusIcon  = 'mdi-phone-dial';
                    break;
                default:
                    $statusText  = 'Unknown';
                    $statusClass = 'unknown';
                    $statusIcon  = 'mdi-phone-outline';
                    break;

            }

            $callDate = null;
            $callTime = null;
            $callDateTime = null;

            if ($call->call_start_date) {
                try {
                    $callDateTimeObject = Carbon::parse($call->call_start_date);

                    if ($call->call_start_time && !str_contains((string) $call->call_start_date,':') ) {

                        $callDateTimeObject = Carbon::parse( $call->call_start_date . ' ' . $call->call_start_time);

                    }
                    $callDate = $callDateTimeObject->format('Y-m-d');
                    $callTime = $callDateTimeObject->format('h:i:s A');
                    $callDateTime = $callDateTimeObject->format('Y-m-d H:i:s' );
                } catch (\Throwable $e) {
                    $callDate = (string) $call->call_start_date;
                    $callTime = $call->call_start_time ? (string) $call->call_start_time  : null;
                }
            }

            $duration = $call->call_duration ?? null;
            if (!$duration && isset($call->duration) ) {
                $duration = $call->duration;
            }

            $customerName =  $call->customer_name ?? $call->user ?? null;
            $customerPhone = $call->customer_phone_no ?? $call->contact ?? null;

            $customerName = $customerName ? trim((string) $customerName)  : 'Unknown Contact';
            $customerPhone = $customerPhone ? trim((string) $customerPhone)  : '';
            /*Location Key */
            $locationKey = number_format($latitude, 7,'.','') . ',' . number_format($longitude, 7, '.', '' );

            $locations[] = [
                'id' => $call->sno ?? null,

                'latitude' => (float) $latitude,
                'longitude' => (float) $longitude,

                'location_key' => $locationKey,

                'user' => $staff->staff_name ?? 'Unknown Staff',

                'staff_id' => $staff->staff_id ?? null,

                'cug_mobile' => $call->staff_phone_no,
                'cug_key' => preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                ),

                'staff_image' => $staff->staff_image ?? null,
                'department_name' => $staff->department_name ?? null,
                'job_position_name' => $staff->job_position_name ?? null,

                'contact' => $call->contact_name ?? 'Unknown Contact',
                'phone' => $call->phone_no ?? '',

                'date' => $callDate,
                'time' => $callTime,
                'datetime' => $callDateTime,

                'duration' => $duration ?: '00:00:00',

                'status' => $status,
                'status_text' => $statusText,
                'status_class' => $statusClass,
                'status_icon' => $statusIcon,

                'audio_file' => $call->audio_file ?? null,
                'audio_url' => $call->audio_url ?? null,
                'audio_size' => $call->audio_size ?? null,
            ];
        }

        $statusCounts = [
            'incoming' => 0,
            'outgoing' => 0,
            'missed'   => 0,
            'rejected' => 0,
            'dialed'   => 0,
        ];

        foreach ($locations as $location) {
            switch ($location['status']) {
                case 0:
                    $statusCounts['outgoing']++;
                    break;
                case 1:
                    $statusCounts['incoming']++;
                    break;
                case 2:
                    $statusCounts['missed']++;
                    break;
                case 3:
                    $statusCounts['rejected']++;
                    break;
                case 4:
                    $statusCounts['dialed']++;
                    break;
            }
        }

        $uniqueLocations = collect($locations)
            ->pluck('location_key')
            ->unique()
            ->count();

        $staffImage = null;
        if (!empty($staff->staff_image)) {
            $staffImage = asset( 'staff_images/' . $staff->staff_image);
        }
        return response()->json([
            'status' => true,
            'message' => 'Call locations loaded successfully.',
            'staff' => [
                'staff_id' =>(int) $staff->staff_id,
                'name' => $staff->staff_name,
                'image' => $staffImage,
                'gender' => $staff->gender,
                'mobile' => $staff->cug_mobile,
                'department' =>  $staff->department_name,
                'position' => $staff->job_position_name,
                'online' => (int) $staff->online_status,
            ],
            'filter' => [
                'start_date' => $startDate->format('Y-m-d'),
                'end_date' => $endDate->format('Y-m-d'),
            ],
            'summary' => [
                'total_calls' => (int) $totalCalls,
                'mapped_calls' => count($locations),
                'unique_locations' => (int) $uniqueLocations,
                'incoming' => $statusCounts['incoming'],
                'outgoing' => $statusCounts['outgoing'],
                'missed' => $statusCounts['missed'],
                'rejected' => $statusCounts['rejected'],
                'dialed' => $statusCounts['dialed'],
            ],
            'data' => $locations,

        ]);
    }
    
     // Tracker Location
    public function locationTrackerIndex(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
            $user_id = $request->user()->user_id;

        $call_fill        = $request->input('call_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }


        $helper = new \App\Helpers\Helpers();
    
       

        return view('content.team_management.cug_management.cug_location',[
        ]);
    }

    public function locationTrackerStaff(Request $request)
    {
        try {

            $branch_id = $request->user()->branch_id;

            $staff = DB::table('za_staff as s')
                ->where('s.branch_id', $branch_id)
                ->where('s.status', 0)

                ->join('za_cug_management as cug', function ($join) {
                    $join->on('cug.staff_id', '=', 's.sno')
                        ->where('cug.status', 0);
                })

                ->leftJoin(
                    'za_job_position as jp',
                    'jp.sno',
                    '=',
                    's.position_role'
                )

                ->select([
                    's.sno as staff_id',
                    's.staff_name',
                    's.staff_image',
                    'jp.job_position_name',
                    'cug.staff_mobile as cug_mobile',
                    'cug.online_status',
                ])

                ->orderBy('s.staff_name')
                ->orderBy('cug.staff_mobile')
                ->get();

            $staff->transform(function ($row) {

                $row->encrypted_id = $row->cug_mobile
                    ? encrypt($row->cug_mobile)
                    : null;

                return $row;
            });

            return response()->json([
                'status'  => true,
                'message' => 'Staff loaded successfully.',
                'data'    => $staff,
            ]);

        } catch (\Throwable $e) {

            Log::error(
                'Location Tracker Staff Error',
                [
                    'message' => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'    => $e->getLine(),
                ]
            );

            return response()->json([
                'status'  => false,
                'message' => 'Unable to load staff.',
                'data'    => [],
            ], 500);
        }
    }

    public function locationTrackerData(Request $request)
    {
        try {

            $branch_id = $request->user()->branch_id;
            $filterType = $request->input( 'filter_type', 'month' );


            if ($filterType === 'today') {
                $startDate = now()->startOfDay();
                $endDate   = now()->endOfDay();
            }else if ($filterType === 'custom') {
                $startDate = $request->filled('start_date') ? Carbon::parse($request->input('start_date'))->startOfDay() : now()->startOfMonth();
                $endDate = $request->filled('end_date') ? Carbon::parse($request->input('end_date'))->endOfDay()  : now()->endOfDay();
            } else {
            $monthFilter = $request->get('month_filter', now()->format('M-Y'));
            try {
                $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
                $month = $parsedDate->month;
                $year  = $parsedDate->year;
            } catch (\Exception $e) {
                $parsedDate = now()->startOfMonth();
                $month = $parsedDate->month;
                $year  = $parsedDate->year;
            }

                $startDate = $parsedDate->copy()->startOfMonth();
                $endDate   = $parsedDate->copy()->endOfMonth();
            }


            if ($startDate->greaterThan($endDate)) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Start date cannot be greater than end date.',
                ], 422);
            }

           $decrypted_cug = null;

            if ($request->filled('staff_id')) {
                try {
                    $decrypted_cug = decrypt($request->input('staff_id'));
                } catch (\Throwable $e) {

                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid CUG mobile.',
                        'data'   => [],
                    ], 422);
                }
            }

            $query = DB::table('za_call_tracker as ct');

            $query->whereBetween('ct.call_start_date',
                    [$startDate->toDateString(),$endDate->toDateString()]);

            if ($decrypted_cug) {
                $query->where('ct.staff_phone_no',$decrypted_cug);
            }

            if ($request->filled('status') && $request->input('status') !== 'all') {

                $statuses = $request->input('status');

                if (!is_array($statuses)) {
                    $statuses = explode(
                        ',',
                        $statuses
                    );
                }

                $statuses = collect($statuses)
                    ->filter(function ($status) {
                        return $status !== ''
                            && $status !== null;
                    })
                    ->map(function ($status) {
                        return (int) $status;
                    })
                    ->unique()
                    ->values()
                    ->toArray();


                if (!empty($statuses)) {
                    $query->whereIn('ct.call_status',$statuses);
                }
            }

            

            

            $calls = $query
                ->select([
                    'ct.sno',
                    'ct.branch_staff_id',
                    'ct.contact_id',

                    'ct.customer_phone_no as phone_no',
                    'ct.staff_phone_no',

                    'ct.call_start_date',
                    'ct.call_start_time',
                    'ct.call_end_time',
                    'ct.call_duration',
                    'ct.call_status',

                    'ct.latitude',
                    'ct.longitude',

                    'ct.audio_file',
                ])
                ->orderByDesc('ct.call_start_date' )
                ->orderByDesc('ct.call_start_time' )
                ->get();

            $contactNameMap = $this->resolveLocationContactNames($calls);

            $calls = $calls->map(function ($call) use ($contactNameMap) {

                $call->contact_name =
                    $contactNameMap[$call->sno]
                    ?? 'Unknown Contact';

                $rawPhone = preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                );

                /*
                * Canonical phone key.
                * This is the identifier used by frontend grouping/routes.
                */
                if (strlen($rawPhone) > 10) {
                    $rawPhone = substr($rawPhone, -10);
                }

                $call->cug_mobile = $call->staff_phone_no;
                $call->cug_key = $rawPhone ?: null;

                /*
                * Audio
                */
                $call->audio_url = null;
                $call->audio_size = null;

                if (!empty($call->audio_file)) {

                    $audioName = basename($call->audio_file);

                    $audioPath = public_path(
                        'call_audios/' . $audioName
                    );

                    if (is_file($audioPath)) {

                        $call->audio_url = asset(
                            'call_audios/' . rawurlencode($audioName)
                        );

                        $bytes = filesize($audioPath);

                        if ($bytes >= 1048576) {
                            $call->audio_size =
                                round($bytes / 1048576, 2) . ' MB';
                        } else {
                            $call->audio_size =
                                round($bytes / 1024, 2) . ' KB';
                        }
                    }
                }

                return $call;
            });


            if ($request->filled('search')) {

                $search =
                    trim(
                        $request->input('search')
                    );

                if ($search !== '') {

                    $calls = $calls
                        ->filter(function ($call) use (
                            $search,
                            $contactNameMap
                        ) {

                            $contactName =
                                $contactNameMap[
                                    $call->sno
                                ] ?? 'Unknown Contact';


                            return
                                stripos(
                                    (string) $contactName,
                                    $search
                                ) !== false

                                ||

                                stripos(
                                    (string) $call->phone_no,
                                    $search
                                ) !== false

                                ||

                                stripos(
                                    (string) $call->staff_phone_no,
                                    $search
                                ) !== false;
                        })
                        ->values();
                }
            }


            $totalCalls = $calls->count();


                $mappedCalls =
                    $calls->filter(function ($call) {

                        return $call->latitude !== null
                            && $call->longitude !== null;

                    })->count();


                $uniqueLocations =
                    $calls
                        ->filter(function ($call) {

                            return $call->latitude !== null
                                && $call->longitude !== null;

                        })
                        ->map(function ($call) {

                            return number_format(
                                (float) $call->latitude,
                                7,
                                '.',
                                ''
                            )
                            . ','
                            .
                            number_format(
                                (float) $call->longitude,
                                7,
                                '.',
                                ''
                            );

                        })
                        ->unique()
                        ->count();


                $incoming =
                    $calls
                        ->where('call_status', 1)
                        ->count();


                $outgoing =
                    $calls
                        ->filter(function ($call) {

                            return (int) $call->call_status === 0
                                && $call->call_duration !== '00:00:00';

                        })
                        ->count();


                $missed =
                    $calls
                        ->where('call_status', 2)
                        ->count();


                $rejected =
                    $calls
                        ->where('call_status', 3)
                        ->count();


                $dialed =
                    $calls
                        ->where('call_status', 4)
                        ->count();

            $staffPhones = $calls
                ->pluck('staff_phone_no')
                ->filter()
                ->map(function ($phone) {
                    return preg_replace('/\D+/', '', (string) $phone);
                })
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $staffCollection = collect();

            


            if (!empty($staffPhones)) {

                $staffCollection = DB::table('za_staff as s')
                    ->where('s.branch_id', $branch_id)
                    ->where('s.status', 0)

                    ->join('za_cug_management as cug', function ($join) {
                        $join->on('cug.staff_id', '=', 's.sno')
                            ->where('cug.status', 0);
                    })

                    ->leftJoin(
                        'za_job_position as jp',
                        'jp.sno',
                        '=',
                        's.position_role'
                    )

                    ->where(function ($query) use ($staffPhones) {

                        foreach ($staffPhones as $phone) {

                            $query->orWhere(
                                DB::raw("REPLACE(REPLACE(REPLACE(cug.staff_mobile, '+', ''), ' ', ''), '-', '')"),
                                $phone
                            );
                        }
                    })

                    ->select([
                        's.sno as staff_id',
                        's.staff_name',
                        's.staff_image',
                        's.gender',
                        's.department_id',
                        'jp.job_position_name',
                        'cug.staff_mobile as cug_mobile',
                    ])

                    ->get()
                    ->mapWithKeys(function ($staff) {

                        $phone = preg_replace(
                            '/\D+/',
                            '',
                            (string) $staff->cug_mobile
                        );

                        return [$phone => $staff];
                    });
            }

            // if ($decrypted_cug) {

            //     $staff = DB::table('za_staff as s')
            //         ->where('s.branch_id', $branch_id)
            //         ->where('s.status', 0)

            //         ->join('za_cug_management as cug', function ($join) {
            //             $join->on('cug.staff_id', '=', 's.sno')
            //                 ->where('cug.status', 0);
            //         })

            //         ->leftJoin(
            //             'za_job_position as jp',
            //             'jp.sno',
            //             '=',
            //             's.position_role'
            //         )

            //         ->where('cug.staff_mobile', $decrypted_cug)

            //         ->select([
            //             's.sno as staff_id',
            //             's.staff_name',
            //             's.staff_image',
            //             's.gender',
            //             's.department_id',
            //             'jp.job_position_name',
            //             'cug.staff_mobile as cug_mobile',
            //         ])

            //         ->first();

            //     if ($staff) {
            //         $staffCollection->put(
            //             preg_replace('/\D+/', '', $decrypted_cug),
            //             $staff
            //         );
            //     }
            // }

            $data = $calls->map(function ($call) use ( $staffCollection ) {

                $callPhone = preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                );

                $staff = $staffCollection->get($callPhone);

                $latitude = is_numeric($call->latitude ) ? (float) $call->latitude : null;
                $longitude = is_numeric($call->longitude ) ? (float) $call->longitude : null;

                if ($latitude !== null && ($latitude < -90 || $latitude > 90 )) {
                    $latitude = null;
                }
                if ( $longitude !== null && ( $longitude < -180 || $longitude > 180)) {
                    $longitude = null;
                }

                $locationKey = null;

                if ( $latitude !== null && $longitude !== null ) {
                    $locationKey =
                        number_format(
                            $latitude,
                            7,
                            '.',
                            ''
                        )
                        . ',' .
                        number_format(
                            $longitude,
                            7,
                            '.',
                            ''
                        );
                }

                $status = (int) $call->call_status;


                $statusData = $this->getCallLocationStatus( $status );

                $datetime = null;

                if (!empty($call->call_start_date) && !empty($call->call_start_time) ) {
                    try {
                        $datetime = Carbon::parse(
                            $call->call_start_date
                            . ' '
                            . $call->call_start_time
                        );

                    } catch (\Throwable $e) {
                        $datetime = null;
                    }
                }

                return [
                    'id' => $call->sno,
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'location_key' => $locationKey,
                    'user' =>  $staff->staff_name ?? 'Unknown Staff',
                    'cug_mobile' => $call->staff_phone_no,
                    'staff_id' => $staff->staff_id ?? null,
                    'staff_image' => $staff->staff_image ?? null,
                    'department_id' => $staff->department_id ?? null,
                    'job_position_name' => $staff->job_position_name ?? null,
                    'contact' => $call->contact_name ?? 'Unknown Contact',
                    'phone' => $call->phone_no ?? '',
                    'date' => $call->call_start_date,
                    'time' => $call->call_start_time,
                    'end_time' => $call->call_end_time,
                    'datetime' => $datetime ? $datetime->format('Y-m-d H:i:s') : null,
                    'duration' => $call->call_duration ?? '00:00:00',
                    'status' => $status,
                    'status_text' => $statusData['text'],
                    'status_class' => $statusData['class'],
                    'status_icon' => $statusData['icon'],
                    'has_location' => $latitude !== null && $longitude !== null,
                     
                    'audio_file' => $call->audio_file ?? null,
                    'audio_url' => $call->audio_url ?? null,
                    'audio_size' => $call->audio_size ?? null,
                ];

            })->values();

            $latestCall = $data->first();

            // $groupedLocations = $data
            //     ->filter(function ($call) {
            //         return $call['has_location'];
            //     })
            //     ->groupBy('location_key')
            //     ->map(function ($locationCalls,$locationKey ) {

            //         $first = $locationCalls->first();

            //         return [
            //             'location_key' =>$locationKey,
            //             'latitude' => $first['latitude'],
            //             'longitude' => $first['longitude'],
            //             'call_count' => $locationCalls->count(),
            //             'latest_call' => $first,
            //             'calls' => $locationCalls->values(),
            //         ];

            //     })
            //     ->values();

            // $groupedLocations = $data
            //         ->filter(function ($call) {
            //             return $call['has_location'];
            //         })
            //         ->sortBy(function ($call) {
            //             return ($call['call_start_date'] ?? '') . ' ' .
            //                 ($call['call_start_time'] ?? '');
            //         })
            //         ->groupBy('location_key')
            //         ->map(function ($locationCalls, $locationKey) {

            //             $locationCalls = $locationCalls->values();

            //             $first = $locationCalls->first();

            //             return [
            //                 'location_key' => $locationKey,
            //                 'latitude' => $first['latitude'],
            //                 'longitude' => $first['longitude'],
            //                 'call_count' => $locationCalls->count(),
            //                 'latest_call' => $locationCalls->last(),
            //                 'calls' => $locationCalls,
            //             ];
            //         })
            //         ->values();

            $groupedLocations = $data
                ->filter(function ($call) {
                    return $call['has_location'];
                })
                ->sortBy(function ($call) {
                    return $call['datetime'] ?? (
                        ($call['date'] ?? '') . ' ' . ($call['time'] ?? '')
                    );
                })
                ->groupBy('location_key')
                ->map(function ($locationCalls, $locationKey) {

                    // Make sure calls inside each location are oldest -> newest
                    $locationCalls = $locationCalls
                        ->sortBy(function ($call) {
                            return $call['datetime'] ?? (
                                ($call['date'] ?? '') . ' ' . ($call['time'] ?? '')
                            );
                        })
                        ->values();

                    // First = oldest call
                    $firstCall = $locationCalls->first();

                    // Last = latest call
                    $latestCall = $locationCalls->last();

                    return [
                        'location_key' => $locationKey,

                        'latitude' => $firstCall['latitude'],
                        'longitude' => $firstCall['longitude'],

                        'call_count' => $locationCalls->count(),

                        // IMPORTANT:
                        // latest_call really means latest call
                        'latest_call' => $latestCall,

                        // Oldest -> newest
                        'calls' => $locationCalls,
                    ];
                })
                ->sortBy(function ($location) {

                    // Sort LOCATION markers by their first/oldest call
                    return $location['calls']->first()['datetime'] ?? '';
                })
                ->values();

            return response()->json([
                'status' => true,
                'message' => 'Call locations loaded successfully.',

                'filter' => [
                    'type' =>  $filterType,
                    'start_date' =>  $startDate->toDateString(),
                    'end_date' => $endDate->toDateString(),
                    'month' => $filterType === 'month' ? $startDate->format('M-Y') : null,
                    'staff_id' => $request->input('staff_id'),
                    'status' => $request->input('status', 'all' ),
                    'search' => $request->input('search'),
                ],

                'summary' => [
                    'total_calls' => $totalCalls,
                    'mapped_calls' => $mappedCalls,
                    'unmapped_calls' => $totalCalls -  $mappedCalls,
                    'unique_locations' => $uniqueLocations,
                    'incoming' => $incoming,
                    'outgoing' => $outgoing,
                    'missed' => $missed,
                    'rejected' => $rejected,
                    'dialed' => $dialed,
                ],

                'latest_call' => $latestCall,
                'data' => $data,
                'locations' => $groupedLocations,
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {

            return response()->json([
                'status' => false,
                'message' => 'Invalid filter parameters.',
                'errors' => $e->errors(),
                'data' => [],
            ], 422);

        } catch (\Throwable $e) {
            return response()->json([
                'status' => false,
                'message' =>'Unable to load location tracker data.',
                'error' =>$e->getMessage(),
                'data' => [],
            ], 500);
        }
    }

    private function getCallLocationStatus(int $status): array
    {
        return match ($status) {

            0 => [
                'text'  => 'Outgoing',
                'class' => 'outgoing',
                'icon'  => 'mdi-phone-outgoing',
            ],

            1 => [
                'text'  => 'Incoming',
                'class' => 'incoming',
                'icon'  => 'mdi-phone-incoming',
            ],

            2 => [
                'text'  => 'Rejected',
                'class' => 'rejected',
                'icon'  => 'mdi-phone-cancel',
            ],

            3 => [
                'text'  => 'Missed',
                'class' => 'missed',
                'icon'  => 'mdi-phone-missed',
            ],

            4 => [
                'text'  => 'Dialed',
                'class' => 'dialed',
                'icon' => 'mdi-phone-dial',
            ],

            default => [
                'text'  => 'Unknown',
                'class' => 'dialed',
                'icon'  => 'mdi-phone-outline',
            ],
        };
    }


    private function resolveLocationContactNames($calls)
    {
        if ($calls->isEmpty()) {
            return collect();
        }


        $phones = $calls
            ->pluck('phone_no')
            ->filter(function ($phone) {
                return $phone !== null
                    && $phone !== '';
            })
            ->map(function ($phone) {
                return substr(
                    (string) $phone,
                    -10
                );
            })
            ->filter()
            ->unique()
            ->values()
            ->toArray();


        if (empty($phones)) {
            return collect();
        }


        $internalMap =
            $this->getLatestContactSource(
                'za_Internal_cugs',
                'cug_mobile_no',
                'user_name',
                $phones
            );

        $customerMap =
            $this->getLatestContactSource(
                'za_customer',
                'cus_mobile',
                'cus_name',
                $phones
            );

        $leadMap =
            $this->getLatestContactSource(
                'za_lead',
                'lead_mobile',
                'lead_name',
                $phones
            );

        $contactIds = $calls
            ->pluck('contact_id')
            ->filter()
            ->unique()
            ->values()
            ->toArray();


        $contactMap = collect();


        if (!empty($contactIds)) {

            $contactMap = DB::table(
                    'za_call_contacts'
                )
                ->whereIn(
                    'sno',
                    $contactIds
                )
                ->select([
                    'sno',
                    'name'
                ])
                ->get()
                ->keyBy('sno');
        }

        return $calls->mapWithKeys(
            function ($call) use (
                $internalMap,
                $customerMap,
                $leadMap,
                $contactMap
            ) {

                $phone = substr(
                    (string) $call->phone_no,
                    -10
                );

                $name = null;

                if (
                    isset($internalMap[$phone]) &&
                    trim((string) $internalMap[$phone]) !== ''
                ) {
                    $name =
                        $internalMap[$phone];
                }

                if (
                    $name === null &&
                    isset($customerMap[$phone]) &&
                    trim((string) $customerMap[$phone]) !== ''
                ) {
                    $name =
                        $customerMap[$phone];
                }

                if (
                    $name === null &&
                    isset($leadMap[$phone]) &&
                    trim((string) $leadMap[$phone]) !== ''
                ) {
                    $name =
                        $leadMap[$phone];
                }

                if (
                    $name === null &&
                    $call->contact_id &&
                    isset($contactMap[$call->contact_id])
                ) {
                    $contactName =
                        $contactMap[
                            $call->contact_id
                        ]->name ?? null;

                    if (
                        trim((string) $contactName) !== ''
                    ) {
                        $name =
                            $contactName;
                    }
                }


                return [
                    $call->sno =>
                        $name ?: 'Unknown Contact'
                ];
            }
        );
    }

    private function getLatestContactSource( string $table, string $mobileColumn, string $nameColumn,  array $phones ) {
        $result = collect();

        

        foreach (array_chunk($phones, 1000) as $phoneChunk) {

            $rows = DB::table($table)
                ->whereIn(
                    $mobileColumn,
                    $phoneChunk
                )
                ->select([
                    'sno',
                    $mobileColumn,
                    $nameColumn,
                ])
                ->orderByDesc('sno')
                ->get();

            /*
            |--------------------------------------------------------------------------
            | First row = latest sno for that mobile
            |--------------------------------------------------------------------------
            */

            foreach ($rows as $row) {

                $mobile =
                    (string) $row->{$mobileColumn};

                if (
                    $mobile === '' ||
                    $result->has($mobile)
                ) {
                    continue;
                }

                $result->put(
                    $mobile,
                    $row->{$nameColumn}
                );
            }
        }

        return $result->all();
    }

}
