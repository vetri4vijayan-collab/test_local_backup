@extends('layouts/layoutMaster')

<title>CUG Call Location</title>

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
      $module_name = 'Sales Management';
     $menu_name = 'Manage Calls';

    if(auth()->user()->hasPermission($module_name, 'Location', $menu_name)){
        $location_check = 1;
    }else{
            $location_check = 0;
    }
@endphp



<style>
    .location-tracker-page {
        background: #f6f8fb;
        min-height: calc(100vh - 70px);
        padding: 14px;
    }

    .location-tracker-wrapper {
        width: 100%;
        max-width: 100%;
        margin: 0 auto;
    }

    .location-filter-card {
        background: #ffffff;
        border: 1px solid #e5eaf0;
        border-radius: 14px;
        padding: 14px;
        margin-bottom: 12px;
        box-shadow: 0 3px 15px rgba(15, 23, 42, .05);
    }

    .location-filter-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 12px;
    }

    .location-filter-title {
        display: flex;
        align-items: center;
        gap: 9px;
    }

    .location-filter-title-icon {
        width: 36px;
        height: 36px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #eff6ff;
        color: #2563eb;
        font-size: 19px;
    }

    .location-filter-title h4 {
        margin: 0;
        color: #172033;
        font-size: 15px;
        font-weight: 750;
    }

    .location-filter-title small {
        display: block;
        margin-top: 2px;
        color: #94a3b8;
        font-size: 10px;
    }

    .location-filter-actions {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .location-filter-btn {
        /* height: 34px;
        padding: 0 11px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        background: #ffffff;
        color: #64748b;
        font-size: 11px;
        font-weight: 650;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        transition: .2s ease; */
    }

    .location-filter-btn:hover {
        /* color: #2563eb;
        background: #eff6ff;
        border-color: #bfdbfe; */
    }

    .location-filter-btn.primary {
        /* color: #ffffff;
        background: #2563eb;
        border-color: #2563eb; */
    }

    .location-filter-btn.primary:hover {
        /* color: #ffffff;
        background: #1d4ed8;
        border-color: #1d4ed8; */
    }

    .location-filter-grid {
        display: grid;
        grid-template-columns:
            150px
            minmax(150px, 1fr)
            minmax(180px, 1.2fr)
            minmax(180px, 1.2fr)
            minmax(180px, 1.2fr)
            180px
            auto;

        gap: 8px;
        align-items: end;
    }

    .location-filter-field {
        min-width: 0;
    }

    .location-filter-field label {
        display: block;
        margin-bottom: 5px;
        color: #64748b;
        font-size: 10px;
        font-weight: 700;
    }

    .location-filter-control {
        width: 100%;
        height: 37px;
        border: 1px solid #dfe5ec;
        border-radius: 8px;
        background: #ffffff;
        color: #334155;
        padding: 0 10px;
        font-size: 11px;
        outline: none;
        transition: .2s ease;
    }

    .location-filter-control:focus {
        border-color: #93c5fd;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, .08);
    }

    .location-filter-control:disabled {
        background: #f8fafc;
        color: #94a3b8;
        cursor: not-allowed;
    }

    .location-search-wrapper {
        position: relative;
    }

    .location-search-wrapper i {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 15px;
        pointer-events: none;
    }

    .location-search-wrapper input {
        padding-left: 31px;
        padding-right: 30px;
    }

    .location-search-clear {
        position: absolute;
        right: 7px;
        top: 50%;
        transform: translateY(-50%);
        width: 23px;
        height: 23px;
        border: 0;
        border-radius: 50%;
        background: transparent;
        color: #94a3b8;
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .location-search-clear:hover {
        background: #f1f5f9;
        color: #475569;
    }

    .location-custom-date-fields {
        display: none;
    }

    .location-custom-date-fields.disabled {
        opacity: .55;
    }

    #locationEndDateField{
         display: none;
    }
    #locationStartDateField{
         display: none;
    }

    .location-summary-grid {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        gap: 8px;
        margin-bottom: 12px;
    }

    .location-stat-card {
        min-height: 72px;
        background: #ffffff;
        border: 1px solid #e5eaf0;
        border-radius: 11px;
        padding: 10px;
        display: flex;
        align-items: center;
        min-width: 0;
        transition: .2s ease;
    }

    .location-stat-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgba(15, 23, 42, .06);
    }

    .location-stat-icon {
        width: 37px;
        height: 37px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 19px;
    }

    .stat-blue {
        background: #eff6ff;
        color: #2563eb;
    }

    .stat-green {
        background: #ecfdf5;
        color: #059669;
    }

    .stat-purple {
        background: #f5f3ff;
        color: #7c3aed;
    }

    .stat-orange {
        background: #fff7ed;
        color: #ea580c;
    }

    .stat-red {
        background: #fef2f2;
        color: #dc2626;
    }

    .stat-yellow {
        background: #fffbeb;
        color: #d97706;
    }

    .stat-gray {
        background: #f8fafc;
        color: #64748b;
    }

    .location-stat-content {
        margin-left: 8px;
        min-width: 0;
    }

    .location-stat-label {
        color: #94a3b8;
        font-size: 9px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .location-stat-value {
        margin-top: 2px;
        color: #172033;
        font-size: 17px;
        line-height: 1.1;
        font-weight: 750;
    }

    .location-stat-value.small {
        font-size: 11px;
    }

    .location-tracker-shell {
        height: calc(100vh - 300px);
        min-height: 520px;
        background: #ffffff;
        border: 1px solid #e5eaf0;
        border-radius: 13px;
        overflow: hidden;
        display: grid;
        grid-template-columns: minmax(0, 1fr) 370px;
        box-shadow: 0 4px 20px rgba(15, 23, 42, .06);
    }

    .location-map-container {
        position: relative;
        min-width: 0;
        min-height: 0;
        background: #e2e8f0;
    }

    #callLocationMap {
        width: 100%;
        height: 100%;
        min-height: 520px;
    }

    .map-overlay {
        position: absolute;
        top: 12px;
        left: 12px;
        right: 12px;
        z-index: 500;
        display: flex;
        justify-content: space-between;
        pointer-events: none;
    }

    .map-overlay-box {
        background: rgba(255,255,255,.95);
        border: 1px solid rgba(226,232,240,.95);
        border-radius: 8px;
        padding: 7px 10px;
        box-shadow: 0 4px 14px rgba(15,23,42,.12);
        color: #475569;
        font-size: 10px;
        font-weight: 650;
    }

    .map-live {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .map-live-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #22c55e;
        box-shadow: 0 0 0 3px rgba(34,197,94,.15);
    }

    .map-live-dot.loading {
        background: #f59e0b;
        box-shadow: 0 0 0 3px rgba(245,158,11,.15);
    }

    .map-live-dot.error {
        background: #ef4444;
        box-shadow: 0 0 0 3px rgba(239,68,68,.15);
    }

    .location-call-panel {
        min-width: 0;
        min-height: 0;
        height: 100%;
        border-left: 1px solid #e5eaf0;
        background: #ffffff;
        display: flex;
        flex-direction: column;
    }

    .location-call-panel-header {
        flex-shrink: 0;
        min-height: 65px;
        padding: 11px 13px;
        border-bottom: 1px solid #edf0f4;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .call-panel-title {
        color: #172033;
        font-size: 13px;
        font-weight: 750;
    }

    .call-panel-subtitle {
        margin-top: 2px;
        color: #94a3b8;
        font-size: 9px;
    }

    .call-panel-count {
        min-width: 29px;
        height: 25px;
        padding: 0 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #eff6ff;
        color: #2563eb;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 750;
    }

    .location-call-list {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        overflow-x: hidden;
        padding: 6px;
    }

    .location-call-list::-webkit-scrollbar {
        width: 6px;
    }

    .location-call-list::-webkit-scrollbar-track {
        background: transparent;
    }

    .location-call-list::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }

    .location-call-list::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
    }

    .staff-call-group {
        margin-bottom: 8px;
        border: 1px solid #edf0f4;
        border-radius: 10px;
        overflow: hidden;
    }

    .staff-call-group-header {
        padding: 8px 9px;
        background: #f8fafc;
        border-bottom: 1px solid #edf0f4;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .staff-call-group-header {
        padding: 8px 9px;
        background: #f8fafc;
        border-bottom: 1px solid #edf0f4;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        user-select: none;
        transition: background .15s ease;
    }

    .staff-call-group-header:hover {
        background: #f1f5f9;
    }

    .staff-call-group.open .staff-call-group-header {
        background: #f8fafc;
    }

    .staff-group-toggle {
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        color: #64748b;
        font-size: 14px;
        transition: transform .18s ease;
    }

    .staff-call-group.open .staff-group-toggle {
        transform: rotate(180deg);
    }

    .staff-call-group-body {
        display: none;
        background: #ffffff;
    }

    .staff-call-group.open .staff-call-group-body {
        display: block;
    }

    .staff-group-avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        object-fit: fill;
        border: 1px solid #e2e8f0;
        flex-shrink: 0;
    }

    .staff-group-info {
        min-width: 0;
        flex: 1;
    }

    .staff-group-name {
        color: #334155;
        font-size: 10px;
        font-weight: 750;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .staff-group-meta {
        color: #94a3b8;
        font-size: 8px;
        margin-top: 1px;
    }

    .staff-group-count {
        min-width: 24px;
        height: 21px;
        padding: 0 5px;
        border-radius: 20px;
        background: #ffffff;
        border: 1px solid #e2e8f0;
        color: #64748b;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 8px;
        font-weight: 750;
    }

    .location-call-item {
        padding: 9px;
        border-bottom: 1px solid #f1f5f9;
        cursor: pointer;
        transition: .15s ease;
    }

    .location-call-item:last-child {
        border-bottom: 0;
    }

    .location-call-item:hover {
        background: #f8fafc;
    }

    .location-call-item.active {
        background: #eff6ff;
        box-shadow: inset 3px 0 0 #2563eb;
    }

    .location-call-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 8px;
    }

    .location-call-contact {
        color: #334155;
        font-size: 10px;
        font-weight: 750;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        min-width: 0;
    }

    .location-call-time {
        color: #94a3b8;
        font-size: 8px;
        white-space: nowrap;
        flex-shrink: 0;
    }

    .location-call-phone {
        color: #64748b;
        font-size: 9px;
        margin-top: 2px;
    }

    .location-call-footer {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 5px;
        margin-top: 6px;
    }

    .location-status {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        padding: 3px 6px;
        border-radius: 20px;
        font-size: 8px;
        font-weight: 750;
    }

    .location-status.outgoing {
        background: #eff6ff;
        color: #2563eb;
    }

    .location-status.incoming {
        background: #ecfdf5;
        color: #059669;
    }

    .location-status.missed {
        background: #fef2f2;
        color: #dc2626;
    }

    .location-status.rejected {
        background: #fff7ed;
        color: #ea580c;
    }

    .location-status.dialed {
        background: #f1f5f9;
        color: #64748b;
    }

    .location-duration {
        color: #94a3b8;
        font-size: 8px;
    }

    .location-available-badge {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        padding: 3px 6px;
        border-radius: 20px;
        font-size: 8px;
        font-weight: 700;
    }

    .location-available {
        background: #ecfdf5;
        color: #059669;
    }

    .location-unavailable {
        background: #f8fafc;
        color: #94a3b8;
    }

    .location-marker {
        width: 38px;
        height: 38px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid #ffffff;
        /* box-shadow: 0 5px 15px rgba(15,23,42,.28); */
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .location-marker i {
        color: #ffffff;
        font-size: 17px;
        transform: rotate(45deg);
    }

    .location-marker.blue {
        background: #2563eb;
    }

    .location-marker.green {
        background: #059669;
    }

    .location-marker.red {
        background: #dc2626;
    }

    .location-marker.orange {
        background: #ea580c;
    }

    .location-marker.gray {
        background: #64748b;
    }

    .staff-route-arrow {
        width: 18px;
        height: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        border: 0;
        pointer-events: none;
    }

    .staff-route-arrow span {
        display: block;
        font-size: 17px;
        font-weight: 900;
        line-height: 1;
        text-shadow:
            0 1px 2px rgba(0, 0, 0, .35),
            0 0 2px #ffffff;
    }

    .staff-route-line {
        pointer-events: auto;
    }

    .marker-cluster-small,
    .marker-cluster-medium,
    .marker-cluster-large {
        background: rgba(37, 99, 235, .18);
    }

    .marker-cluster-small div,
    .marker-cluster-medium div,
    .marker-cluster-large div {
        background: #2563eb;
        color: #ffffff;
        font-weight: 750;
        box-shadow: 0 4px 12px rgba(37,99,235,.3);
    }

    .location-popup {
        min-width: 290px;
        max-width: 390px;
    }

    .location-popup-header {
        display: flex;
        align-items: center;
        gap: 9px;
        padding-bottom: 9px;
        border-bottom: 1px solid #edf0f4;
    }

    .location-popup-avatar {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        object-fit: fill;
        border: 1px solid #e2e8f0;
    }

    .location-popup-staff-name {
        color: #172033;
        font-size: 12px;
        font-weight: 750;
    }

    .location-popup-staff-meta {
        margin-top: 2px;
        color: #94a3b8;
        font-size: 8px;
    }

    .location-popup-location {
        margin-top: 9px;
        padding: 8px;
        border-radius: 8px;
        background: #f8fafc;
        display: flex;
        gap: 8px;
    }

    .location-popup-location i {
        color: #2563eb;
        font-size: 17px;
    }

    .location-popup-coordinates {
        color: #64748b;
        font-size: 9px;
        margin-top: 2px;
    }

    .location-popup-calls {
        max-height: 240px;
        overflow-y: auto;
        margin-top: 7px;
    }

    .location-popup-call {
        padding: 7px 0;
        border-bottom: 1px solid #f1f5f9;
    }

    .location-popup-call:last-child {
        border-bottom: 0;
    }

    .location-popup-contact {
        color: #334155;
        font-size: 10px;
        font-weight: 750;
    }

    .location-popup-phone {
        color: #94a3b8;
        font-size: 8px;
        margin-top: 1px;
    }

    .location-popup-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 4px;
    }

    .location-page-loading {
        position: fixed;
        inset: 0;
        z-index: 99999;
        background: rgba(248,250,252,.72);
        backdrop-filter: blur(2px);
        display: none;
        align-items: center;
        justify-content: center;
    }

    .location-page-loading.show {
        display: flex;
    }

    .location-page-loader-box {
        background: #ffffff;
        border: 1px solid #e5eaf0;
        border-radius: 13px;
        padding: 22px 28px;
        text-align: center;
        box-shadow: 0 15px 50px rgba(15,23,42,.15);
    }

    .location-spinner {
        width: 34px;
        height: 34px;
        margin: auto;
        border: 3px solid #e2e8f0;
        border-top-color: #2563eb;
        border-radius: 50%;
        animation: locationTrackerSpin .75s linear infinite;
    }

    @keyframes locationTrackerSpin {
        to {
            transform: rotate(360deg);
        }
    }

    .location-loading-title {
        margin-top: 11px;
        color: #334155;
        font-size: 12px;
        font-weight: 750;
    }

    .location-loading-text {
        margin-top: 3px;
        color: #94a3b8;
        font-size: 9px;
    }

    .location-empty-state {
        padding: 45px 15px;
        text-align: center;
        color: #94a3b8;
    }

    .location-empty-state i {
        display: block;
        font-size: 38px;
        color: #cbd5e1;
        margin-bottom: 8px;
    }

    .location-empty-title {
        color: #64748b;
        font-size: 12px;
        font-weight: 750;
    }

    .location-empty-text {
        margin-top: 3px;
        font-size: 9px;
    }

    @media (max-width: 1300px) {

        .location-filter-grid {
            grid-template-columns:
                repeat(4, minmax(0, 1fr));
        }

        .location-summary-grid {
            grid-template-columns:
                repeat(4, minmax(0, 1fr));
        }

        .location-tracker-shell {
            grid-template-columns:
                minmax(0, 1fr) 330px;
        }
    }

    @media (max-width: 991px) {

        .location-filter-grid {
            grid-template-columns:
                repeat(2, minmax(0, 1fr));
        }

        .location-summary-grid {
            grid-template-columns:
                repeat(3, minmax(0, 1fr));
        }

        .location-tracker-shell {
            grid-template-columns: 1fr;
            height: auto;
        }

        .location-map-container {
            height: 550px;
        }

        .location-call-panel {
            height: 400px;
            border-left: 0;
            border-top: 1px solid #e5eaf0;
        }
    }

    @media (max-width: 600px) {

        .location-tracker-page {
            padding: 7px;
        }

        .location-filter-grid {
            grid-template-columns: 1fr;
        }

        .location-summary-grid {
            grid-template-columns:
                repeat(2, minmax(0, 1fr));
        }

        .location-filter-header {
            align-items: flex-start;
        }

        .location-filter-actions span {
            display: none;
        }

        .location-map-container {
            height: 450px;
        }

        .location-call-panel {
            height: 350px;
        }
    }

    .staff-group-count {
        transition: all .2s ease;
    }

    .staff-group-count.count-low {
        background: #eff6ff !important;
        color: #2563eb !important;
    }

    .staff-group-count.count-medium {
        background: #fef3c7 !important;
        color: #b45309 !important;
    }

    .staff-group-count.count-high {
        background: #fed7aa !important;
        color: #c2410c !important;
    }

    .staff-group-count.count-critical {
        background: #fee2e2 !important;
        color: #dc2626 !important;
    }

    .staff-route-color {
        width: 7px;
        height: 34px;
        border-radius: 5px;
        flex-shrink: 0;
        margin-right: 7px;
        box-shadow: 0 2px 6px rgba(15, 23, 42, .15);
    }

    .staff-call-group-header {
        position: relative;
        transition: background .2s ease,
                    box-shadow .2s ease;
    }

    .staff-call-group-header:hover {
        background: #f8fafc;
    }

    .staff-call-group-header[aria-expanded="true"] {
        background: color-mix(
            in srgb,
            var(--staff-route-color) 7%,
            #ffffff
        );

        box-shadow:
            inset 3px 0 0
            var(--staff-route-color);
    }

    .staff-group-cug {
        margin-top: 2px;
        color: #64748b;
        font-size: 8px;
        font-weight: 650;
        display: flex;
        align-items: center;
        gap: 2px;
    }

    .staff-group-cug i {
        font-size: 10px;
    }

    .location-call-cug {
        color: #64748b;
        font-size: 8px;
        margin-top: 3px;
    }

    .location-call-cug i {
        font-size: 10px;
    }

    .location-call-audio {
        margin-top: 7px;
    }

    .location-call-audio audio {
        display: block;
        width: 100%;
    }

    .location-audio-size {
        display: block;
        margin-top: 2px;
        color: #94a3b8;
        font-size: 7px;
    }
</style>



<div class="location-tracker-page">
    <div class="location-tracker-wrapper">
        <div class="location-filter-card">
            <div class="location-filter-header">
                <div class="location-filter-title">
                    <div class="location-filter-title-icon">
                        <i class="mdi mdi-map-marker-radius"></i>
                    </div>
                    <div>
                        <h4>
                            Call Location Tracker
                        </h4>
                        <small>
                            Monitor staff call activity and locations
                        </small>
                    </div>
                </div>
                <div class="location-filter-actions">
                    <button type="button" class="location-filter-btn btn btn-sm shadow-none border border-gray"  id="locationResetBtn" >
                        <i class="mdi mdi-filter-remove-outline"></i>
                        <span>Reset</span>
                    </button>
                    <button  type="button" class="location-filter-btn btn btn-sm shadow-none border border-gray" id="locationRefreshBtn" >
                        <i class="mdi mdi-refresh"></i>
                        <span>Refresh</span>
                    </button>
                    <button type="button" class="location-filter-btn btn btn-primary btn-sm" id="locationApplyBtn">
                        <i class="mdi mdi-filter-check-outline"></i>
                        <span>Apply</span>
                    </button>
                </div>
            </div>

            <div class="location-filter-grid">
                {{-- Filter Type --}}
                <div class="location-filter-field">
                    <label> Date Filter</label>
                    <select id="locationFilterType" class="location-filter-control select3" onchange="location_Filter_change()">
                        <option value="today"> Today </option>
                        <option value="month"> Month </option>
                        <option value="custom"> Custom Date</option>
                    </select>

                </div>
                <div class="location-filter-field location-today-date-field" id="locationTodayField" >
                    <label>
                        Today
                    </label>
                    <input type="text" id="locationTodayDate" class="location-filter-control" value="{{date('d-M-Y')}}" Disabled>
                </div>
                {{-- Month --}}
                <div class="location-filter-field" id="locationMonthField">
                    <label>Month</label>
                    @php 
                    $currentMonth = date('M-Y');
                    @endphp
                    <input type="text" id="locationMonth" class="location-filter-control month_filter_common_class" value="{{ $currentMonth }}" readonly>
                </div>
                {{-- Start Date --}}
                <div class="location-filter-field location-custom-date-field" id="locationStartDateField"  >
                    <label>
                        Start Date
                    </label>
                    <input type="text" id="locationStartDate" class="location-filter-control common_date_class" placeholder="select start Date" value="{{date('d-M-Y')}}" readonly>
                </div>
                {{-- End Date --}}
                <div class="location-filter-field location-custom-date-field"  id="locationEndDateField" >
                    <label>
                        End Date
                    </label>
                    <input type="text" id="locationEndDate" class="location-filter-control common_date_class" placeholder="select End Date" value="{{date('d-M-Y')}}" readonly>
                </div>
                {{-- Staff --}}
                <div class="location-filter-field">
                    <label>
                        Staff
                    </label>
                    <select id="locationStaff" class="location-filter-control select3">
                        <option value="">All Staff</option>
                    </select>
                </div>
                {{-- Status --}}
                <div class="location-filter-field">
                    <label> Call Status</label>
                    <select id="locationStatus" class="location-filter-control select3" >
                        <option value="all"> All Status</option>
                        <option value="0"> Outgoing</option>
                        <option value="1">Incoming</option>
                        <option value="2"> Rejected </option>
                        <option value="3">Missed</option>
                        <option value="4">Dialed</option>
                    </select>
                </div>
                {{-- Search --}}
                <div class="location-filter-field">
                    <label>Search</label>
                    <div class="location-search-wrapper">
                        <i class="mdi mdi-magnify"></i>
                        <input type="text" id="locationSearch" class="location-filter-control" placeholder="Contact or phone..." autocomplete="off">
                        <button type="button" id="locationSearchClear" class="location-search-clear">
                            <i class="mdi mdi-close"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="location-summary-grid">
            <div class="location-stat-card">
                <div class="location-stat-icon stat-blue">
                    <i class="mdi mdi-map-marker-radius"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Unique Locations
                    </div>
                    <div id="locationSummaryLocations" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-green">
                    <i class="mdi mdi-phone-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Total Calls
                    </div>
                    <div id="locationSummaryTotal" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-purple">
                    <i class="mdi mdi-phone-incoming-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Incoming
                    </div>
                    <div id="locationSummaryIncoming" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-orange">
                    <i class="mdi mdi-phone-outgoing-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Outgoing
                    </div>
                    <div id="locationSummaryOutgoing" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-red">
                    <i class="mdi mdi-phone-missed-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Missed
                    </div>
                    <div id="locationSummaryMissed" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-gray">
                    <i class="mdi mdi-map-marker-check-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Mapped Calls
                    </div>
                    <div id="locationSummaryMapped" class="location-stat-value">
                        0
                    </div>
                </div>
            </div>
            <div class="location-stat-card">
                <div class="location-stat-icon stat-yellow">
                    <i class="mdi mdi-clock-outline"></i>
                </div>
                <div class="location-stat-content">
                    <div class="location-stat-label">
                        Last Call
                    </div>
                    <div id="locationSummaryLastCall" class="location-stat-value small">
                        -
                    </div>
                </div>
            </div>
        </div>
        <div class="location-tracker-shell">
            <div class="location-map-container">
                <div id="callLocationMap"></div>
                <div class="map-overlay">
                    <div class="map-overlay-box map-live">
                        <span id="locationMapLiveDot" class="map-live-dot"></span>
                        <span id="locationMapLiveText">
                            Location Tracking
                        </span>
                    </div>
                    <div id="locationMapCoordinateCount" class="map-overlay-box">
                        0 coordinates
                    </div>
                </div>
            </div>
            {{-- CALL LIST --}}
            <div class="location-call-panel">
                <div class="location-call-panel-header">
                    <div>
                        <div class="call-panel-title">
                            Staff Call Activity
                        </div>
                        <div class="call-panel-subtitle">
                            Latest calls first
                        </div>
                    </div>
                    <span id="locationCallCount" class="call-panel-count">
                        0
                    </span>
                </div>
                <div id="locationCallList" class="location-call-list">
                    <div class="location-empty-state">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <div class="location-empty-title">
                            Loading locations
                        </div>
                        <div class="location-empty-text">
                            Please wait...
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="locationTrackerLoading" class="location-page-loading" >
    <div class="location-page-loader-box">
        <div class="location-spinner"></div>
        <div class="location-loading-title">
            Loading call locations
        </div>
        <div class="location-loading-text">
            Preparing map and call activity...
        </div>
    </div>
</div>


<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>


<script>

(function () {

    'use strict';

    const LOCATION_TRACKER = {
        dataUrl: @json(route('call.location.tracker.data')),
        staffUrl: @json(route('call.location.tracker.staff')),
        defaultMonth: @json($currentMonth),
        defaultCenter: [
            20.5937,
            78.9629
        ],
        defaultZoom: 5,
        searchDelay: 450
    };

    let locationMap = null;
    let streetLayer = null;
    let satelliteLayer = null;
    let markerCluster = null;
    let routeLayerGroup = null;
    let staffRouteColors = new Map();
    let callMarkers = [];
    let markerLookup = new Map();
    let currentData = [];
    let currentLocations = [];
    let searchTimer = null;
    let currentRequest = null;
    let lastRequestSignature = '';

    let activeStaffMapFilter = null;
    let staffRouteLayers = new Map();
    let staffMarkerGroups = new Map();

    const $ = function (id) {
        return document.getElementById(id);
    };


    document.addEventListener( 'DOMContentLoaded',
        function () {
            initializeLocationTracker();
        }
    );

    async function initializeLocationTracker()
    {
        bindEvents();
        updateDateFilterUI();
        setMapLoadingState();
        await loadStaff();
        await loadLocationData();
    }

    // function change_location_filter_type(){
    //     updateDateFilterUI();
    // }

    function change_filter_staff(){
        loadLocationData();
    }

    function change_filter_status(){
        loadLocationData();
    }

    function bindEvents()
    {
        const locationFilterType = $('#locationFilterType');

        if (locationFilterType) {
            locationFilterType.addEventListener('change', function () {
                updateDateFilterUI();
            });
        }

        const locationStaff = $('#locationStaff');

        if (locationStaff) {
            locationStaff.addEventListener('change', function () {
                loadLocationData();
            });
        }

        const locationStatus = $('#locationStatus');

        if (locationStatus) {
            locationStatus.addEventListener('change', function () {
                loadLocationData();
            });
        }

        $('locationApplyBtn').addEventListener('click', function () {
            loadLocationData();
        });

        $('locationRefreshBtn').addEventListener('click',
                function () {
                    loadLocationData(true);
                    loadStaff()
                }
        );

        $('locationResetBtn').addEventListener('click',resetLocationFilters);

        $('locationSearch').addEventListener('input',handleSearchInput);

        $('locationSearchClear').addEventListener('click',
                function () {
                    $('locationSearch').value = '';
                    updateSearchClearButton();
                    loadLocationData();
                }
        );

        $('locationMonth').addEventListener('change',
                function () {
                    if ( $('locationFilterType').value === 'month') {
                        loadLocationData();
                    }
                }
        );

        $('locationStartDate').addEventListener('change',validateCustomDateRange );
        $('locationEndDate').addEventListener('change',validateCustomDateRange );
    }

    function updateDateFilterUI()
    {
        const type = $('locationFilterType').value;
        const todayField = $('locationTodayField');
        const monthField = $('locationMonthField');
        const startField = $('locationStartDateField');
        const endField =$('locationEndDateField');

        if (type === 'today') {
            todayField.style.display = '';
            monthField.style.display ='none';
            startField.style.display ='none';
            endField.style.display = 'none';
        } else if (type === 'month') {
            monthField.style.display = '';
            todayField.style.display = 'none';
            startField.style.display = 'none';
            endField.style.display = 'none';
        } else {
            monthField.style.display = 'none';
            todayField.style.display = 'none';
            startField.style.display = '';
            endField.style.display = '';
        }

    }


    function validateCustomDateRange()
    {
        const start = $('locationStartDate').value;
        const end = $('locationEndDate').value;
        if (start && end && start > end) {
            $('locationEndDate').value = start;
        }

    }

    // function resetLocationFilters()
    // {
    //     $('locationFilterType').value ='month';
    //     $('locationMonth').value = LOCATION_TRACKER.defaultMonth;
    //     $('locationStartDate').value = '';
    //     $('locationEndDate').value = '';
    //     $('locationStaff').value = '';
    //     $('locationStatus').value = 'all';
    //     $('locationSearch').value = '';
    //     updateDateFilterUI();
    //     updateSearchClearButton();
    //     loadLocationData();

    // }
    function resetLocationFilters()
    {
        $('locationFilterType').value = 'month';
        $('locationMonth').value = LOCATION_TRACKER.defaultMonth;
        $('locationStartDate').value = '';
        $('locationEndDate').value = '';
        $('locationStaff').value = '';
        $('locationStatus').value = 'all';
        $('locationSearch').value = '';

        // Force request after reset
        lastRequestSignature = '';

        updateDateFilterUI();
        updateSearchClearButton();
        loadLocationData(true);
    }

    function handleSearchInput()
    {

        updateSearchClearButton();
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function () {
                                loadLocationData();
                            },
                            LOCATION_TRACKER.searchDelay
                    );
    }

    function updateSearchClearButton()
    {
        const value = $('locationSearch').value.trim();
        $('locationSearchClear').style.display = value ? 'flex' : 'none';
    }

    async function loadStaff()
    {

        try {

             const response =  await fetch( LOCATION_TRACKER.staffUrl,
                                    {
                                        method: 'GET',
                                        headers: {
                                            'Accept':'application/json'
                                        },
                                        credentials:'same-origin'
                                    }
                                );

            if (!response.ok) {
                throw new Error('Unable to load staff.');
            }

            const result = await response.json();

            if (!result.status) {
                throw new Error( result.message || 'Unable to load staff.');
            }

            const staffSelect = $('locationStaff');

            staffSelect.innerHTML = '<option value="">All Staff</option>';

            (result.data || [])
                .forEach(function (staff) {
                    const option = document.createElement('option');
                    option.value = staff.encrypted_id;
                    option.textContent = staff.staff_name ? staff.staff_name + ' - '+ staff.cug_mobile :  'Unknown Staff - ' + staff.staff_mobile;
                    staffSelect.appendChild(option );
                });
        } catch (error) {
            console.error('Staff loading error:',error);
        }

    }

    async function loadLocationData(forceRefresh = false )
    {

        const params = buildRequestParams();
        const signature = params.toString();
        if ( !forceRefresh && signature === lastRequestSignature ) {
            return;
        }

        lastRequestSignature = signature;

        if (currentRequest) {
            currentRequest.abort();
        }

        currentRequest = new AbortController();

        setGlobalLoading(true);
        setMapLiveState('loading','Loading locations');

        try {

            const response =
                await fetch(
                    LOCATION_TRACKER.dataUrl +
                    '?' +
                    params.toString(),
                    {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        credentials: 'same-origin',
                        signal: currentRequest.signal
                    }
                );

            if (!response.ok) {
                throw new Error('Server returned HTTP ' + response.status);

            }

            const result = await response.json();

            if (!result.status) {
                throw new Error( result.message || 'Unable to load location data.');
            }
            currentData = Array.isArray(result.data) ? result.data : [];
            currentLocations = Array.isArray(result.locations) ? result.locations : [];

            renderSummary(result.summary || {});
            renderCallList(currentData );
            initializeMap( currentLocations);

            setMapLiveState('success', 'Location Tracking');

        } catch (error) {
            if (error.name ==='AbortError' ) {
                return;
            }

            console.error('Location tracker error:',error );
            renderErrorState( error.message);
            setMapLiveState('error','Unable to load' );

        } finally {
            setGlobalLoading(false);
            currentRequest =null;
        }

    }

    function buildRequestParams()
    {

        const params = new URLSearchParams();
        const type = $('locationFilterType').value;

        params.set(
            'filter_type',
            type
        );

        if (type === 'month') {
            params.set( 'month_filter', $('locationMonth').value || LOCATION_TRACKER.defaultMonth );
        } else {
            const start = $('locationStartDate').value;
            const end = $('locationEndDate').value;
            if (start) {
                params.set('start_date',start);
            }
            if (end) {
                params.set('end_date',end);
            }
        }

        const staff = $('locationStaff').value;

        if (staff) {
            params.set('staff_id', staff );
        }

        const status =  $('locationStatus').value;

        if ( status && status !== 'all') {
            params.set('status', status );
        }

        const search = $('locationSearch').value.trim();
        if (search) {
            params.set('search', search);
        }
        return params;
    }

    function renderSummary(summary)
    {
        setText('locationSummaryLocations',formatNumber(summary.unique_locations ) );
        setText( 'locationSummaryTotal',formatNumber(summary.total_calls));
        setText('locationSummaryIncoming',formatNumber(summary.incoming) );
        setText('locationSummaryOutgoing', formatNumber(summary.outgoing));
        setText( 'locationSummaryMissed',formatNumber(summary.missed));
        setText('locationSummaryMapped',formatNumber(summary.mapped_calls) );
        const latest = currentData.length ? currentData[0] : null;
        setText('locationSummaryLastCall', latest ? (latest.date + ' ' + latest.time ) : '-' );
    }

    function initializeMap(locations)
    {

        destroyMap();

        const mapElement = document.getElementById('callLocationMap' );

        if (!mapElement) {
            console.error('callLocationMap not found.');
            return;
        }

        locationMap =
            L.map(
                mapElement,
                {
                    zoomControl: true,
                    attributionControl: true,
                    preferCanvas: true
                }
            );

        streetLayer =
            L.tileLayer(
                'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                {
                    maxZoom: 19,
                    minZoom: 2,
                    attribution:
                        '&copy; OpenStreetMap contributors'
                }
            );

        satelliteLayer =
            L.tileLayer(
                'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
                {
                    maxZoom: 19,
                    minZoom: 2,
                    attribution:
                        'Tiles &copy; Esri'
                }
            );


        streetLayer.addTo(
            locationMap
        );

        L.control.layers(
            {
                'Street':
                    streetLayer,

                'Satellite':
                    satelliteLayer

            },
            null,
            {
                position: 'topright',
                collapsed: true
            }
        ).addTo(
            locationMap
        );

        markerCluster =
            L.markerClusterGroup(
                {
                    chunkedLoading: true,

                    showCoverageOnHover:
                        false,

                    spiderfyOnMaxZoom:
                        true,

                    removeOutsideVisibleBounds:
                        true,

                    maxClusterRadius:
                        45,

                    disableClusteringAtZoom:
                        17,

                    animate:
                        true
                }
            );


        const validLocations =
            locations.filter(
                function (location) {

                    const lat =
                        Number(
                            location.latitude
                        );

                    const lng =
                        Number(
                            location.longitude
                        );


                    return (
                        Number.isFinite(lat) &&
                        Number.isFinite(lng) &&
                        lat >= -90 &&
                        lat <= 90 &&
                        lng >= -180 &&
                        lng <= 180
                    );

                }
            );


        setText(
            'locationMapCoordinateCount',
            formatNumber(
                validLocations.length
            ) +
            ' coordinates'
        );


        if (!validLocations.length) {

            locationMap.setView(
                LOCATION_TRACKER.defaultCenter,
                LOCATION_TRACKER.defaultZoom
            );

            setTimeout(
                function () {

                    if (locationMap) {

                        locationMap.invalidateSize();

                    }

                },
                250
            );

            return;

        }


        const bounds =
            L.latLngBounds([]);


        validLocations.forEach(
            function (location, index) {

                const marker =
                    createLocationMarker(
                        location,
                        index
                    );


                markerCluster.addLayer(
                    marker
                );


                const key =
                    location.location_key ||
                    (
                        Number(
                            location.latitude
                        ).toFixed(7) +
                        ',' +
                        Number(
                            location.longitude
                        ).toFixed(7)
                    );


                markerLookup.set(
                    key,
                    marker
                );


                callMarkers.push({
                    marker:
                        marker,

                    location:
                        location
                });


                bounds.extend([
                    Number(
                        location.latitude
                    ),

                    Number(
                        location.longitude
                    )
                ]);

            }
        );

        drawStaffRoutes(
            currentData
        );


        locationMap.addLayer(
            markerCluster
        );
       

        if (bounds.isValid()) {

            locationMap.fitBounds(
                bounds,
                {
                    padding:
                        [50, 50],

                    maxZoom:
                        16
                }
            );

        }


        setTimeout(
            function () {
                if (!locationMap) {
                    return;
                }

                locationMap.invalidateSize();

                if (bounds.isValid()) {
                    locationMap.fitBounds(
                        bounds,
                        {
                            padding:
                                [50, 50],

                            maxZoom:
                                16
                        }
                    );

                }

            },
            350
        );

    }

    function getStaffRouteColor(staffId)
{
    const key = String(staffId || 'unknown');

    if (staffRouteColors.has(key)) {
        return staffRouteColors.get(key);
    }

    /*
     * Golden-angle distribution gives visually separated
     * colors without maintaining a fixed staff-color table.
     */
    let numericId = 0;

    if (key !== 'unknown') {
        numericId = Number(key);

        if (!Number.isFinite(numericId)) {
            numericId = Array.from(key).reduce(
                function (hash, char) {
                    return (
                        ((hash << 5) - hash) +
                        char.charCodeAt(0)
                    ) | 0;
                },
                0
            );
        }
    }

    const hue =
        Math.abs(numericId * 137.508) % 360;

    const color =
        'hsl(' +
        hue.toFixed(1) +
        ', 72%, 45%)';

    staffRouteColors.set(
        key,
        color
    );

    return color;
}


function getRouteBearing(from, to)
{
    const lat1 =
        Number(from[0]) * Math.PI / 180;

    const lat2 =
        Number(to[0]) * Math.PI / 180;

    const deltaLng =
        (
            Number(to[1]) -
            Number(from[1])
        ) * Math.PI / 180;

    const y =
        Math.sin(deltaLng) *
        Math.cos(lat2);

    const x =
        Math.cos(lat1) *
        Math.sin(lat2) -
        Math.sin(lat1) *
        Math.cos(lat2) *
        Math.cos(deltaLng);

    return (
        Math.atan2(y, x) *
        180 /
        Math.PI +
        360
    ) % 360;
}


function createRouteArrow(
    from,
    to,
    color
)
{
    const lat1 = Number(from[0]);
    const lng1 = Number(from[1]);
    const lat2 = Number(to[0]);
    const lng2 = Number(to[1]);

    const midpoint = [
        (lat1 + lat2) / 2,
        (lng1 + lng2) / 2
    ];

    const bearing =
        getRouteBearing(
            from,
            to
        );

    const icon =
        L.divIcon({
            className: '',
            html:
                '<div class="staff-route-arrow" ' +
                'style="transform:rotate(' +
                (bearing - 90) +
                'deg);">' +
                    '<span style="color:' +
                    color +
                    ';">➤</span>' +
                '</div>',
            iconSize: [18, 18],
            iconAnchor: [9, 9]
        });

    return L.marker(
        midpoint,
        {
            icon: icon,
            interactive: false,
            keyboard: false,
            zIndexOffset: 200
        }
    );
}


function drawStaffRoutes(calls)
{
    if (!locationMap) {
        return;
    }

    if (routeLayerGroup) {
        routeLayerGroup.clearLayers();

        if (locationMap.hasLayer(routeLayerGroup)) {
            locationMap.removeLayer(routeLayerGroup);
        }
    }

    routeLayerGroup = L.layerGroup().addTo(locationMap);

    staffRouteColors.clear();
    staffRouteLayers.clear();

    const staffGroups = new Map();

    (Array.isArray(calls) ? calls : []).forEach(function(call) {

        if (!call || !call.has_location) {
            return;
        }

        const lat = Number(call.latitude);
        const lng = Number(call.longitude);

        if (
            !Number.isFinite(lat) ||
            !Number.isFinite(lng)
        ) {
            return;
        }

        const cugKey = String(
            call.cug_key ||
            normalizePhone(
                call.cug_mobile ||
                call.staff_phone_no
            ) ||
            'unknown'
        );

        if (!staffGroups.has(cugKey)) {
            staffGroups.set(cugKey, []);
        }

        staffGroups.get(cugKey).push(call);

       
    });


    staffGroups.forEach(function(staffCalls, cugKey) {

        staffCalls.sort(function(a, b) {

            const aTime = a.datetime
                ? new Date(a.datetime).getTime()
                : 0;

            const bTime = b.datetime
                ? new Date(b.datetime).getTime()
                : 0;

            if (aTime !== bTime) {
                return aTime - bTime;
            }

            return (
                Number(a.id || 0) -
                Number(b.id || 0)
            );
        });

        const points = [];

        staffCalls.forEach(function(call) {

            const point = [
                Number(call.latitude),
                Number(call.longitude)
            ];

            const previous =
                points[points.length - 1];

            if (
                !previous ||
                previous[0] !== point[0] ||
                previous[1] !== point[1]
            ) {
                points.push(point);
            }
        });

        if (points.length < 2) {
            return;
        }

        const color =
            getStaffRouteColor(cugKey);

        const staffName =
            staffCalls[0].user ||
            'Unknown Staff';

        const staffLayer =
            L.layerGroup();

        staffRouteLayers.set(
            cugKey,
            staffLayer
        );

        const polyline =
            L.polyline(
                points,
                {
                    color: color,
                    weight: 5,
                    opacity: 0.82,
                    lineCap: 'round',
                    lineJoin: 'round',
                    className:
                        'staff-route-line'
                }
            );

        polyline.bindTooltip(
            escapeHtml(
                staffName +
                ' · ' +
                (
                    staffCalls[0].cug_mobile ||
                    staffCalls[0].staff_phone_no ||
                    ''
                )
            ),
            {
                sticky: true,
                direction: 'top'
            }
        );

        staffLayer.addLayer(
            polyline
        );

        const segmentCount =
            points.length - 1;

        const arrowStep =
            Math.max(
                1,
                Math.ceil(
                    segmentCount / 20
                )
            );

        for (
            let i = 0;
            i < segmentCount;
            i += arrowStep
        ) {
            const arrow =
                createRouteArrow(
                    points[i],
                    points[i + 1],
                    color
                );

            staffLayer.addLayer(
                arrow
            );
        }

        staffLayer.addTo(
            routeLayerGroup
        );
    });

    if (activeStaffMapFilter) {

        applyStaffMapFilter(
            activeStaffMapFilter,
            false
        );
    }
}

function applyStaffMapFilter(cugKey, zoomToStaff = true){
    if (!locationMap) {
        return;
    }

    cugKey = String(cugKey || 'unknown');

    activeStaffMapFilter = cugKey;

    /*
    |--------------------------------------------------------------------------
    | Route visibility
    |--------------------------------------------------------------------------
    */
    staffRouteLayers.forEach(function(layer, key) {

        if (String(key) === cugKey) {

            if (!locationMap.hasLayer(layer)) {
                routeLayerGroup.addLayer(layer);
            }

        } else {

            if (routeLayerGroup.hasLayer(layer)) {
                routeLayerGroup.removeLayer(layer);
            }
        }
    });


    /*
    |--------------------------------------------------------------------------
    | Marker visibility + STAFF-SPECIFIC numbering
    |--------------------------------------------------------------------------
    */
    if (markerCluster) {

        markerCluster.clearLayers();

        let markerNumber = 1;

        callMarkers.forEach(function(item) {

            if (!item.marker || !item.location) {
                return;
            }

            const latest =
                item.location.latest_call;

            if (!latest) {
                return;
            }

            const itemCugKey =
                String(
                    latest.cug_key ||
                    normalizePhone(
                        latest.cug_mobile ||
                        latest.staff_phone_no
                    ) ||
                    'unknown'
                );

            /*
             * Only selected CUG markers
             */
            if (itemCugKey !== cugKey) {
                return;
            }

            /*
             * IMPORTANT:
             * Number starts again from 1 for this staff
             */
            updateMarkerLabel(
                item.marker,
                markerNumber
            );

            markerCluster.addLayer(
                item.marker
            );

            markerNumber++;
        });
    }


    /*
    |--------------------------------------------------------------------------
    | Zoom to selected CUG
    |--------------------------------------------------------------------------
    */
    if (!zoomToStaff) {
        return;
    }

    const staffCalls =
        currentData.filter(function(call) {

            const callCugKey =
                String(
                    call.cug_key ||
                    normalizePhone(
                        call.cug_mobile ||
                        call.staff_phone_no
                    ) ||
                    'unknown'
                );

            return (
                callCugKey === cugKey &&
                call.has_location
            );
        });

    if (!staffCalls.length) {
        return;
    }

    const bounds = L.latLngBounds([]);

    staffCalls.forEach(function(call) {

        const lat = Number(call.latitude);
        const lng = Number(call.longitude);

        if (
            Number.isFinite(lat) &&
            Number.isFinite(lng)
        ) {
            bounds.extend([
                lat,
                lng
            ]);
        }
    });

    if (bounds.isValid()) {

        locationMap.fitBounds(
            bounds,
            {
                padding: [70, 70],
                maxZoom: 17,
                animate: true
            }
        );
    }
}

function buildAudioButton(call)
{
    if (!call.audio_url) {
        return '';
    }

    return `
        <div class="location-call-audio">
            <audio
                controls
                preload="none"
                src="${escapeAttribute(call.audio_url)}"
                style="width:100%;height:30px;">
            </audio>

            ${
                call.audio_size
                    ? `<span class="location-audio-size">
                        ${escapeHtml(call.audio_size)}
                       </span>`
                    : ''
            }
        </div>
    `;
}

function showAllStaffRoutes()
{
    if (!locationMap) {
        return;
    }

    activeStaffMapFilter =
        null;


    /*
    |--------------------------------------------------------------------------
    | Show all routes
    |--------------------------------------------------------------------------
    */

    staffRouteLayers.forEach(
        function(layer) {

            if (
                routeLayerGroup &&
                !routeLayerGroup.hasLayer(layer)
            ) {

                routeLayerGroup.addLayer(
                    layer
                );

            }

        }
    );


    /*
    |--------------------------------------------------------------------------
    | Show all markers
    |--------------------------------------------------------------------------
    */

    if (markerCluster) {

        markerCluster.clearLayers();

        callMarkers.forEach(function(item, index) {

            if (!item.marker) {
                return;
            }

            // Restore normal 1,2,3,4... numbering
            updateMarkerLabel(
                item.marker,
                index + 1
            );

            markerCluster.addLayer(
                item.marker
            );
        });
    }


    /*
    |--------------------------------------------------------------------------
    | Fit all locations
    |--------------------------------------------------------------------------
    */

    const bounds =
        L.latLngBounds([]);


    currentLocations.forEach(
        function(location) {

            const lat =
                Number(location.latitude);

            const lng =
                Number(location.longitude);

            if (
                Number.isFinite(lat) &&
                Number.isFinite(lng)
            ) {

                bounds.extend([
                    lat,
                    lng
                ]);

            }

        }
    );


    if (bounds.isValid()) {

        locationMap.fitBounds(
            bounds,
            {
                padding: [50, 50],
                maxZoom: 16,
                animate: true
            }
        );

    }

}

function drawStaffRoutesOld(calls)
{
    if (!locationMap) {
        return;
    }

    if (routeLayerGroup) {
        routeLayerGroup.clearLayers();
        locationMap.removeLayer(
            routeLayerGroup
        );
    }

    routeLayerGroup =
        L.layerGroup().addTo(
            locationMap
        );

    staffRouteColors.clear();

    const staffGroups =
        new Map();

    /*
     * Individual calls are used here instead of grouped
     * locations because route direction must follow time.
     */
    (Array.isArray(calls) ? calls : [])
        .forEach(function (call) {

            if (
                !call ||
                !call.has_location
            ) {
                return;
            }

            const lat =
                Number(call.latitude);

            const lng =
                Number(call.longitude);

            if (
                !Number.isFinite(lat) ||
                !Number.isFinite(lng)
            ) {
                return;
            }

            const staffId =
                String(
                    call.staff_id ||
                    'unknown'
                );

            if (!staffGroups.has(staffId)) {
                staffGroups.set(
                    staffId,
                    []
                );
            }

            staffGroups
                .get(staffId)
                .push(call);
        });


    staffGroups.forEach(
        function (staffCalls, staffId) {

            /*
             * Backend returns latest first.
             * Route must be oldest -> newest.
             */
            staffCalls.sort(
                function (a, b) {

                    const aTime =
                        a.datetime
                            ? new Date(a.datetime).getTime()
                            : 0;

                    const bTime =
                        b.datetime
                            ? new Date(b.datetime).getTime()
                            : 0;

                    if (aTime !== bTime) {
                        return aTime - bTime;
                    }

                    return (
                        Number(a.id || 0) -
                        Number(b.id || 0)
                    );
                }
            );


            const points = [];

            staffCalls.forEach(
                function (call) {

                    const point = [
                        Number(call.latitude),
                        Number(call.longitude)
                    ];

                    const previous =
                        points[points.length - 1];

                    /*
                     * Don't create zero-length segments
                     * when two calls have exactly the same GPS.
                     */
                    if (
                        !previous ||
                        previous[0] !== point[0] ||
                        previous[1] !== point[1]
                    ) {
                        points.push(point);
                    }
                }
            );


            if (points.length < 2) {
                return;
            }


            const color =
                getStaffRouteColor(
                    staffId
                );

            const staffName =
                staffCalls[0].user ||
                'Unknown Staff';


            const polyline =
                L.polyline(
                    points,
                    {
                        color: color,
                        weight: 4,
                        opacity: 0.82,
                        lineCap: 'round',
                        lineJoin: 'round',
                        className:
                            'staff-route-line'
                    }
                );

            polyline.bindTooltip(
                escapeHtml(staffName),
                {
                    sticky: true,
                    direction: 'top'
                }
            );

            polyline.addTo(
                routeLayerGroup
            );


            /*
             * Maximum 20 arrows per staff so a large
             * call history does not visually overload
             * the production map.
             */
            const segmentCount =
                points.length - 1;

            const arrowStep =
                Math.max(
                    1,
                    Math.ceil(
                        segmentCount / 20
                    )
                );


            for (
                let i = 0;
                i < segmentCount;
                i += arrowStep
            ) {

                const arrow =
                    createRouteArrow(
                        points[i],
                        points[i + 1],
                        color
                    );

                arrow.addTo(
                    routeLayerGroup
                );
            }
        }
    );
}

    function destroyMap()
    {
        markerLookup.clear();
        callMarkers = [];

        if (routeLayerGroup) {
            routeLayerGroup.clearLayers();

            if (locationMap) {
                locationMap.removeLayer(
                    routeLayerGroup
                );
            }

            routeLayerGroup = null;
        }

        staffRouteColors.clear();

        if (markerCluster) {
            markerCluster.clearLayers();
            markerCluster = null;
        }

        if (locationMap) {
            locationMap.remove();
            locationMap = null;
        }

        streetLayer = null;
        satelliteLayer = null;
    }

    // function destroyMap()
    // {

    //     markerLookup.clear();
    //     callMarkers = [];

    //     if (markerCluster) {
    //         markerCluster.clearLayers();
    //         markerCluster = null;
    //     }


    //     if (locationMap) {
    //         locationMap.remove();
    //         locationMap = null;
    //     }

    //     streetLayer = null;
    //     satelliteLayer = null;

    // }

    function createLocationMarker(location, index)
    {

        const latestCall =
            location.latest_call ||
            (
                Array.isArray(location.calls) &&
                location.calls.length
                    ? location.calls[location.calls.length - 1]
                    : null
            );
        const color = getMarkerColor(latestCall );

        const num = (index !== undefined && index !== null) ? index + 1 : 1;
        const suffix = ['th', 'st', 'nd', 'rd'][(num % 10 > 3) ? 0 : (num % 100 - 20) % 10] || 'th';
        const label = num ;


        const icon =
            L.divIcon(
                {
                    className:
                        '',

                    html:
                        '<div class="location-marker ' +
                        color +
                        '">' +
                         '<span class="text-white fw-bold" >' +   label +'</span>'+
                        '</div>',

                    iconSize:
                        [38, 38],

                    iconAnchor:
                        [19, 38],

                    popupAnchor:
                        [0, -35]
                }
            );


        const marker =
            L.marker(
                [
                    Number(
                        location.latitude
                    ),

                    Number(
                        location.longitude
                    )
                ],
                {
                    icon:
                        icon,

                    title:
                        (
                            latestCall &&
                            latestCall.contact
                        )
                            ? latestCall.contact
                            : 'Call Location'
                }
            );


        marker.bindPopup(
            buildLocationPopup(
                location
            ),
            {
                maxWidth:
                    390,

                minWidth:
                    290,

                closeButton:
                    true,

                autoPan:
                    true
            }
        );


        marker.on(
            'popupopen',
            function () {

                highlightLocationCalls(
                    location.location_key
                );

            }
        );


        return marker;

    }

    function updateMarkerLabel(marker, number)
    {
        if (!marker) {
            return;
        }

        const element = marker.getElement();

        if (!element) {
            return;
        }

        const labelElement =
            element.querySelector('.location-marker span');

        if (labelElement) {
            labelElement.textContent = String(number);
        }
    }

    function getMarkerColor(call)
    {

        if (!call) {

            return 'gray';

        }


        switch (
            Number(
                call.status
            )
        ) {

            case 0:
                return 'blue';

            case 1:
                return 'green';

            case 2:
                return 'orange';

            case 3:
                return 'red';

            case 4:
                return 'gray';

            default:
                return 'gray';

        }

    }


    /* ============================================================
       POPUP
    ============================================================ */

    function buildLocationPopup(
        location
    )
    {

        const calls =
            Array.isArray(
                location.calls
            )
                ? location.calls
                : [];


        const latest =
            calls[0] ||
            location.latest_call ||
            {};


        const image =
            latest.staff_image
                ? (
                    '/staff_images/' +
                    encodeURIComponent(
                        latest.staff_image
                    )
                )
                : '';


        let html =
            '<div class="location-popup">';


        html +=
            '<div class="location-popup-header">';


        if (image) {

            html +=
                '<img ' +
                'src="' +
                escapeAttribute(image) +
                '" ' +
                'class="location-popup-avatar" ' +
                'alt="Staff">';

        } else {

            html +=
                '<div class="location-popup-avatar" ' +
                'style="display:flex;align-items:center;justify-content:center;background:#eff6ff;color:#2563eb;">' +
                    '<i class="mdi mdi-account"></i>' +
                '</div>';

        }


        html +=
            '<div>' +

                '<div class="location-popup-staff-name">' +
                    escapeHtml(
                        latest.user ||
                        'Unknown Staff'
                    ) +
                '</div>' +

                '<div class="location-popup-staff-meta">' +
                    escapeHtml(
                        latest.job_position_name ||
                        latest.department_name ||
                        ''
                    ) +
                '</div>' +

            '</div>' +

            '</div>';


        html +=
            '<div class="location-popup-location">' +

                '<i class="mdi mdi-map-marker"></i>' +

                '<div>' +

                    '<div style="font-size:10px;font-weight:750;color:#334155;">' +
                        'Call Location' +
                    '</div>' +

                    '<div class="location-popup-coordinates">' +
                        escapeHtml(
                            Number(
                                location.latitude
                            ).toFixed(7)
                        ) +
                        ', ' +
                        escapeHtml(
                            Number(
                                location.longitude
                            ).toFixed(7)
                        ) +
                        ' · ' +
                        calls.length +
                        ' call(s)' +
                    '</div>' +

                '</div>' +

            '</div>';


        html +=
            '<div class="location-popup-calls">';


        calls.forEach(
            function (call) {

            const audioHtml = call.audio_url
                ? `
                    <div style="margin-top:6px;">
                        <audio
                            controls
                            preload="none"
                            src="${escapeAttribute(call.audio_url)}"
                            style="width:100%;height:28px;">
                        </audio>
                        ${
                            call.audio_size
                                ? `<div style="font-size:7px;color:#94a3b8;margin-top:2px;">
                                    ${escapeHtml(call.audio_size)}
                                </div>`
                                : ''
                        }
                    </div>
                `
                : '';

                html +=
                    '<div class="location-popup-call">' +

                        '<div class="location-popup-contact">' +
                            escapeHtml(
                                call.contact ||
                                'Unknown Contact'
                            ) +
                        '</div>' +

                        '<div class="location-popup-phone">' +
                            escapeHtml(
                                call.phone ||
                                ''
                            ) +
                        '</div>' +

                        '<div class="location-popup-meta">' +

                            buildStatusBadge(
                                call
                            ) +

                            '<span style="font-size:8px;color:#94a3b8;">' +
                                escapeHtml(
                                    call.date ||
                                    ''
                                ) +
                                ' ' +
                                escapeHtml(
                                    call.time ||
                                    ''
                                ) +
                            '</span>' +

                        '</div>' +

                         audioHtml +

                    '</div>';

            }
        );


        html +=
            '</div>' +
            '</div>';


        return html;

    }


    /* ============================================================
       STATUS BADGE
    ============================================================ */

    function buildStatusBadge(
        call
    )
    {

        const className =
            call.status_class ||
            'dialed';


        const icon =
            call.status_icon ||
            'mdi-phone-outline';


        const text =
            call.status_text ||
            'Unknown';


        return (
            '<span class="location-status ' +
            escapeAttribute(className) +
            '">' +

                '<i class="mdi ' +
                    escapeAttribute(icon) +
                '"></i>' +

                escapeHtml(text) +

            '</span>'
        );

    }


    /* ============================================================
       CALL LIST
    ============================================================ */

    function renderCallList(
        calls
    )
    {

        const container =
            $('locationCallList');


        container.innerHTML =
            '';


        setText(
            'locationCallCount',
            formatNumber(
                calls.length
            )
        );


        if (!calls.length) {

            container.innerHTML =
                buildEmptyState(
                    'mdi-phone-off-outline',
                    'No calls found',
                    'No calls match the selected filters.'
                );

            return;

        }

        const groups = new Map();

        calls.forEach(function (call) {

            const cugKey =
                String(
                    call.cug_key ||
                    normalizePhone(call.cug_mobile || call.staff_phone_no)
                    || 'unknown'
                );

            if (!groups.has(cugKey)) {
                groups.set(cugKey, []);
            }

            groups.get(cugKey).push(call);
        });


        groups.forEach(
            function (
                staffCalls,
                staffId
            ) {

                container.appendChild(
                    buildStaffGroup(
                        staffId,
                        staffCalls
                    )
                );

            }
        );

    }

    function normalizePhone(phone)
    {
        let value = String(phone || '')
            .replace(/\D/g, '');

        if (value.length > 10) {
            value = value.slice(-10);
        }

        return value;
    }

    function buildStaffGroup(
        cugKey,
        calls
    )
    {
        const wrapper =
            document.createElement('div');

        wrapper.className =
            'staff-call-group';

        const first =
            calls[0] || {};

        const staffColor =
            getStaffRouteColor(cugKey);

        const header =
            document.createElement('div');

        header.className =
            'staff-call-group-header';

        header.style.setProperty(
            '--staff-route-color',
            staffColor
        );

        header.setAttribute(
            'role',
            'button'
        );

        header.setAttribute(
            'tabindex',
            '0'
        );

        header.setAttribute(
            'aria-expanded',
            'false'
        );

        const routeColor =
            document.createElement('span');

        routeColor.className =
            'staff-route-color';

        routeColor.style.background =
            staffColor;

        header.appendChild(
            routeColor
        );

        const avatar =
            document.createElement('img');

        avatar.className =
            'staff-group-avatar';

        avatar.alt =
            'Staff';

        if (first.staff_image) {

            avatar.src =
                '/staff_images/' +
                encodeURIComponent(
                    first.staff_image
                );

        } else {

            avatar.src =
                'data:image/svg+xml;charset=UTF-8,' +
                encodeURIComponent(
                    '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40">' +
                    '<rect width="40" height="40" rx="20" fill="#eff6ff"/>' +
                    '<text x="20" y="25" text-anchor="middle" fill="#2563eb" font-size="16">S</text>' +
                    '</svg>'
                );
        }

        const info =
            document.createElement('div');

        info.className =
            'staff-group-info';

        const staffName =
            first.user ||
            'Unknown Staff';

        const cugMobile =
            first.cug_mobile ||
            first.staff_phone_no ||
            '';

        info.innerHTML =
            '<div class="staff-group-name">' +
                escapeHtml(staffName) +
            '</div>' +

            '<div class="staff-group-meta">' +
                escapeHtml(
                    first.job_position_name ||
                    first.department_name ||
                    ''
                ) +
            '</div>' +

            '<div class="staff-group-cug">' +
                '<i class="mdi mdi-sim"></i> ' +
                escapeHtml(cugMobile) +
            '</div>';

        const count =
            document.createElement('span');

        count.className =
            'staff-group-count';

        count.textContent =
            calls.length;

        count.style.background =
            staffColor;

        count.style.borderColor =
            staffColor;

        count.style.color =
            '#ffffff';

        const toggle =
            document.createElement('span');

        toggle.className =
            'staff-group-toggle';

        toggle.innerHTML =
            '<i class="mdi mdi-chevron-down"></i>';

        header.appendChild(avatar);
        header.appendChild(info);
        header.appendChild(count);
        header.appendChild(toggle);

        const body =
            document.createElement('div');

        body.className =
            'staff-call-group-body';

        calls.forEach(function (call) {

            body.appendChild(
                buildCallItem(call)
            );
        });

        wrapper.appendChild(header);
        wrapper.appendChild(body);

        header.addEventListener(
            'click',
            function () {

                const isExpanded =
                    header.getAttribute(
                        'aria-expanded'
                    ) === 'true';

                const newState =
                    !isExpanded;

                header.setAttribute(
                    'aria-expanded',
                    newState
                        ? 'true'
                        : 'false'
                );

                wrapper.classList.toggle(
                    'open',
                    newState
                );

                if (newState) {

                    applyStaffMapFilter(
                        cugKey,
                        true
                    );

                } else {

                    activeStaffMapFilter = null;

                    showAllStaffRoutes();
                }
            }
        );

        header.addEventListener(
            'keydown',
            function (event) {

                if (
                    event.key === 'Enter' ||
                    event.key === ' '
                ) {

                    event.preventDefault();

                    header.click();
                }
            }
        );

        return wrapper;
    }

    // function buildStaffGroup(
    //     staffId,
    //     calls
    // )
    // {

    //     const wrapper =
    //         document.createElement(
    //             'div'
    //         );


    //     wrapper.className =
    //         'staff-call-group';


    //     const first =
    //         calls[0] ||
    //         {};


    //     const header =
    //         document.createElement(
    //             'div'
    //         );


    //     header.className =
    //         'staff-call-group-header';


    //     const avatar =
    //         document.createElement(
    //             'img'
    //         );


    //     avatar.className =
    //         'staff-group-avatar';


    //     avatar.alt =
    //         'Staff';


    //     if (first.staff_image) {

    //         avatar.src =
    //             '/staff_images/' +
    //             first.staff_image;

    //     } else {

    //         avatar.src =
    //             'data:image/svg+xml;charset=UTF-8,' +
    //             encodeURIComponent(
    //                 '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40">' +
    //                 '<rect width="40" height="40" rx="20" fill="#eff6ff"/>' +
    //                 '<text x="20" y="25" text-anchor="middle" fill="#2563eb" font-size="16">S</text>' +
    //                 '</svg>'
    //             );

    //     }


    //     const info =
    //         document.createElement(
    //             'div'
    //         );


    //     info.className =
    //         'staff-group-info';


    //     info.innerHTML =
    //         '<div class="staff-group-name">' +
    //             escapeHtml(
    //                 first.user ||
    //                 'Unknown Staff'
    //             ) +
    //         '</div>' +

    //         '<div class="staff-group-meta">' +
    //             escapeHtml(
    //                 first.job_position_name ||
    //                 first.department_name ||
    //                 ''
    //             ) +
    //         '</div>';


    //     const count =
    //         document.createElement(
    //             'span'
    //         );


    //     count.className =
    //         'staff-group-count';


    //     count.textContent =
    //         calls.length;


    //     header.appendChild(
    //         avatar
    //     );

    //     header.appendChild(
    //         info
    //     );

    //     header.appendChild(
    //         count
    //     );


    //     wrapper.appendChild(
    //         header
    //     );


    //     calls.forEach(
    //         function (call) {

    //             wrapper.appendChild(
    //                 buildCallItem(
    //                     call
    //                 )
    //             );

    //         }
    //     );


    //     return wrapper;

    // }


    /* ============================================================
       CALL ITEM
    ============================================================ */

    function buildCallItem(
        call
    )
    {

        const item =
            document.createElement(
                'div'
            );


        item.className =
            'location-call-item';


        item.dataset.callId =
            call.id ||
            '';


        item.dataset.locationKey =
            call.location_key ||
            '';


        const hasLocation =
            Boolean(
                call.has_location ||
                (
                    Number.isFinite(
                        Number(
                            call.latitude
                        )
                    ) &&
                    Number.isFinite(
                        Number(
                            call.longitude
                        )
                    )
                )
            );


        item.innerHTML =

            '<div class="location-call-top">' +

                '<div class="location-call-contact">' +
                    escapeHtml(
                        call.contact ||
                        'Unknown Contact'
                    ) +
                '</div>' +

                '<div class="location-call-time">' +
                    escapeHtml(
                        call.time ||
                        ''
                    ) +
                '</div>' +

            '</div>' +


            '<div class="location-call-phone">' +
                escapeHtml(
                    call.phone ||
                    ''
                ) +
            '</div>' +


            '<div class="location-call-footer">' +

                buildStatusBadge(
                    call
                ) +

                '<span class="location-duration">' +
                    escapeHtml(
                        call.duration ||
                        '00:00:00'
                    ) +
                '</span>' +


                (
                    hasLocation

                        ?

                    '<span class="location-available-badge location-available">' +
                        '<i class="mdi mdi-map-marker-check-outline"></i>' +
                        'Location' +
                    '</span>'

                        :

                    '<span class="location-available-badge location-unavailable">' +
                        '<i class="mdi mdi-map-marker-off-outline"></i>' +
                        'No Location' +
                    '</span>'
                ) +

            '</div>';

            buildAudioButton(call);


        item.addEventListener(
            'click',
            function () {

                selectCallOnMap(
                    call,
                    item
                );

            }
        );


        return item;

    }


    /* ============================================================
       SELECT CALL ON MAP
    ============================================================ */

    function selectCallOnMap(
        call,
        element
    )
    {

        document
            .querySelectorAll(
                '.location-call-item.active'
            )
            .forEach(
                function (item) {

                    item.classList.remove(
                        'active'
                    );

                }
            );


        if (element) {

            element.classList.add(
                'active'
            );

        }


        if (!call.has_location) {

            return;

        }


        const key =
            call.location_key;


        const marker =
            markerLookup.get(
                key
            );


        if (!marker || !locationMap) {

            return;

        }


        const latLng =
            marker.getLatLng();


        /*
         * If marker is inside cluster,
         * zoom cluster to marker.
         */

        if (
            markerCluster &&
            markerCluster.getBounds &&
            !locationMap.hasLayer(marker)
        ) {

            markerCluster.zoomToShowLayer(
                marker,
                function () {

                    locationMap.setView(
                        latLng,
                        Math.max(
                            locationMap.getZoom(),
                            16
                        ),
                        {
                            animate:
                                true
                        }
                    );

                    marker.openPopup();

                }
            );

            return;

        }


        locationMap.setView(
            latLng,
            Math.max(
                locationMap.getZoom(),
                16
            ),
            {
                animate:
                    true
            }
        );


        marker.openPopup();

    }


    /* ============================================================
       HIGHLIGHT LOCATION CALLS
    ============================================================ */

    function highlightLocationCalls(
        locationKey
    )
    {

        document
            .querySelectorAll(
                '.location-call-item'
            )
            .forEach(
                function (item) {

                    item.classList.toggle(
                        'active',
                        item.dataset.locationKey ===
                        locationKey
                    );

                }
            );

    }


    /* ============================================================
       FIT ALL
    ============================================================ */

    window.fitAllCallLocations =
        function ()
        {

            if (
                !locationMap ||
                !markerCluster
            ) {

                return;

            }


            const bounds =
                markerCluster.getBounds();


            if (!bounds.isValid()) {

                locationMap.setView(
                    LOCATION_TRACKER.defaultCenter,
                    LOCATION_TRACKER.defaultZoom
                );

                return;

            }


            locationMap.fitBounds(
                bounds,
                {
                    padding:
                        [50, 50],

                    maxZoom:
                        16,

                    animate:
                        true
                }
            );

        };


    /* ============================================================
       GLOBAL REFRESH
    ============================================================ */

    window.refreshLocationTracker =
        function ()
        {

            lastRequestSignature =
                '';

            loadLocationData(
                true
            );

        };


    /* ============================================================
       LOADING STATE
    ============================================================ */

    function setGlobalLoading(
        loading
    )
    {

        $('locationTrackerLoading')
            .classList.toggle(
                'show',
                loading
            );

    }


    function setMapLoadingState()
    {

        setMapLiveState(
            'loading',
            'Loading locations'
        );

    }


    function setMapLiveState(
        state,
        text
    )
    {

        const dot =
            $('locationMapLiveDot');


        const label =
            $('locationMapLiveText');


        dot.classList.remove(
            'loading',
            'error'
        );


        if (state === 'loading') {

            dot.classList.add(
                'loading'
            );

        }

        if (state === 'error') {

            dot.classList.add(
                'error'
            );

        }


        label.textContent =
            text;

    }


    /* ============================================================
       ERROR
    ============================================================ */

    function renderErrorState(
        message
    )
    {

        $('locationCallList').innerHTML =
            buildEmptyState(
                'mdi-alert-circle-outline',
                'Unable to load calls',
                message ||
                'Something went wrong while loading data.'
            );

        setText(
            'locationCallCount',
            '0'
        );

        renderSummary({});

    }


    /* ============================================================
       EMPTY
    ============================================================ */

    function renderEmptyLocationList()
    {

        $('locationCallList').innerHTML =
            buildEmptyState(
                'mdi-map-marker-off-outline',
                'No locations available',
                'No valid GPS coordinates were found.'
            );

    }


    function buildEmptyState(
        icon,
        title,
        text
    )
    {

        return (
            '<div class="location-empty-state">' +

                '<i class="mdi ' +
                    escapeAttribute(icon) +
                '"></i>' +

                '<div class="location-empty-title">' +
                    escapeHtml(title) +
                '</div>' +

                '<div class="location-empty-text">' +
                    escapeHtml(text) +
                '</div>' +

            '</div>'
        );

    }


    /* ============================================================
       HELPERS
    ============================================================ */

    function setText(
        id,
        value
    )
    {

        const element =
            $(id);


        if (element) {

            element.textContent =
                value;

        }

    }


    function formatNumber(
        value
    )
    {

        const number =
            Number(value || 0);


        return number.toLocaleString(
            'en-IN'
        );

    }


    function escapeHtml(
        value
    )
    {

        const div =
            document.createElement(
                'div'
            );


        div.textContent =
            value === null ||
            value === undefined
                ? ''
                : String(value);


        return div.innerHTML;

    }


    function escapeAttribute(
        value
    )
    {

        return escapeHtml(
            value
        )
        .replace(
            /"/g,
            '&quot;'
        )
        .replace(
            /'/g,
            '&#039;'
        );

    }

})();

</script>


<script>
    function location_Filter_change(){
        updateDateFilterUIGlobal();      
    }
     function updateDateFilterUIGlobal()
    {
        const type = $('#locationFilterType').val();
        const todayField = document.getElementById('locationTodayField');
        const monthField = document.getElementById('locationMonthField');
        const startField = document.getElementById('locationStartDateField');
        const endField =document.getElementById('locationEndDateField');

        if (type === 'today') {
            todayField.style.display = 'block';
            monthField.style.display ='none';
            startField.style.display ='none';
            endField.style.display = 'none';
        } else if (type === 'month') {
            monthField.style.display = 'block';
            todayField.style.display = 'none';
            startField.style.display = 'none';
            endField.style.display = 'none';
        } else {
            monthField.style.display = 'none';
            todayField.style.display = 'none';
            startField.style.display = 'block';
            endField.style.display = 'block';
        }
    }
</script>

<script>
    $(document).ready(function() {
        $('.month_filter_common_class').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        })
    });
</script>

@endsection
