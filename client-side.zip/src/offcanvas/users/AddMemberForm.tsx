import { useEffect, useState } from "react";
import Select from "react-select";
import { ALL_ROLES, TeamMember, UserRole } from "../../types/user";
import Field from "../../components/Field";
import Button from "../../components/Button";
import { getSelectStyles } from "../../utils/selectStyles";
import { EyeIcon, EyeSlashIcon } from "@phosphor-icons/react";

interface AddMemberFormProps {
  member?: TeamMember | null;
  onSubmit: (member: TeamMember) => void;
  onCancel: () => void;
}

export default function AddMemberForm({
  member,
  onSubmit,
  onCancel,
}: AddMemberFormProps) {
  const isEditMode = !!member;

  const [name, setName] = useState("");
  const [hourlyrate, sethourlyrate] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("Project Manager");
  const [status, setStatus] =
    useState<"Active" | "Inactive">("Active");

  const roleOptions = ALL_ROLES.map((r) => ({
    value: r,
    label: r,
  }));

  const selectedRole = roleOptions.find(
    (option) => option.value === role
  );

  /*
   * Populate form when editing
   */
  useEffect(() => {
    if (member) {
      setName(member.name);
      setEmail(member.email);
      setPassword(member.password ?? "");
      setRole(member.role);
      setStatus(member.status);
    } else {
      // Reset form for Add mode
      setName("");
      setEmail("");
      setPassword("");
      setRole("Project Manager");
      setStatus("Active");
    }
  }, [member]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!name.trim() || !email.trim()) return;

    // Password is required only when adding
    if (!isEditMode && !password.trim()) return;

    const updatedMember: TeamMember = {
        id: member?.id ?? `u-${Date.now()}`,
        name: name.trim(),
        email: email.trim(),
        password: password.trim(),
        role,
        status,
        hourlyrate,
        department: "",
        location: "",
        privileges: []
    };

    onSubmit(updatedMember);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex h-full flex-col"
    >
      <div className="flex-1 space-y-5">

        {/* Full Name */}
        <Field
          label="Full Name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Priya Nair"
        />

        {/* Email */}
        <Field
          label="Email Address"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="name@projectflow.com"
        />

        {/* Password */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            {isEditMode ? "Password" : "Default Password"}
          </label>

          <div className="relative">
            <Field
              label=""
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={
                isEditMode
                  ? "Enter new password"
                  : "Enter default password"
              }
            />

            <button
              type="button"
              onClick={() => setShowPassword((prev) => !prev)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors hover:text-slate-600"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeSlashIcon size={18} />
              ) : (
                <EyeIcon size={18} />
              )}
            </button>
          </div>
        </div>

          <Field
          label="Hourly Rate"
          type="text"
          value={hourlyrate}
          onChange={(e) => sethourlyrate(e.target.value)}
          placeholder="e.g. $ 25"
        />
        {/* Role */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Role
          </label>

          <Select
            options={roleOptions}
            value={selectedRole}
            onChange={(option: any) => {
              if (option) {
                setRole(option.value as UserRole);
              }
            }}
            isSearchable={false}
            className="text-sm"
            styles={getSelectStyles()}
          />
        </div>

        {/* Status */}
        <div>
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Status
          </label>

          <div className="flex gap-2 rounded-lg border border-slate-200 bg-slate-50 p-1">
            {(["Active", "Inactive"] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                className={`flex-1 rounded-md py-1.5 text-xs font-bold uppercase transition-colors ${status === s
                  ? "bg-white text-red-600 shadow-sm"
                  : "text-slate-400"
                  }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-6 flex gap-3 border-t border-slate-100 pt-5">

        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="flex-1"
        >
          Cancel
        </Button>

        <Button
          type="submit"
          variant="primary"
          className="flex-1"
        >
          {isEditMode ? "Update Member" : "Add Member"}
        </Button>

      </div>
    </form>
  );
}
