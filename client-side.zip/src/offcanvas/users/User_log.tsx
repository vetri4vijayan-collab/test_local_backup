import { X } from '@phosphor-icons/react';
import React from 'react';


interface UserLogProps {
    open: boolean;
    user: any;
    onClose: () => void;
}

const UserLog: React.FC<UserLogProps> = ({
    open,
    user,
    onClose,
}) => {
    if (!open || !user) return null;

    return (
        <div className="fixed inset-0 z-[999]">
            <div
                className="absolute inset-0 bg-black/40"
                onClick={onClose}
            />

            <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
                <div className="flex h-full flex-col">

                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                        <div>
                            <h2 className="text-base font-semibold text-slate-800">
                                Activity Logs
                            </h2>

                            <p className="mt-0.5 text-xs text-slate-500">
                                {user.name}
                            </p>
                        </div>

                        <button
                            type="button"
                            onClick={onClose}
                            className="rounded-md p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                        >
                            <X size={18} />
                        </button>
                    </div>

                    {/* User Information */}
                    <div className="border-b border-slate-200 px-5 py-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-semibold text-slate-600">
                                {user.name
                                    ?.split(' ')
                                    .map((name: string) => name[0])
                                    .join('')
                                    .slice(0, 2)
                                    .toUpperCase()}
                            </div>

                            <div className="min-w-0">
                                <p className="truncate text-sm font-semibold text-slate-800">
                                    {user.name}
                                </p>

                                <p className="truncate text-xs text-slate-500">
                                    {user.role}
                                </p>

                                <p className="truncate text-xs text-slate-500">
                                    {user.email}
                                </p>
                            </div>

                            <span
                                className={`ml-auto shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ${
                                    user.status === 'Active'
                                        ? 'bg-green-50 text-green-600'
                                        : 'bg-red-50 text-red-600'
                                }`}
                            >
                                {user.status}
                            </span>
                        </div>
                    </div>

                    {/* Activity Logs */}
                    <div className="flex-1 overflow-y-auto px-5 py-5">
                        <div className="relative">

                            {/* Timeline line */}
                            <div className="absolute bottom-2 left-[7px] top-2 w-px bg-slate-200" />

                            <div className="space-y-6">

                                {/* Profile Updated */}
                                <div className="relative flex gap-4">
                                    <div className="relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white bg-blue-500 ring-1 ring-blue-200" />

                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-start justify-between gap-3">
                                            <p className="text-sm font-semibold text-slate-700">
                                                Profile Updated
                                            </p>

                                            <span className="shrink-0 text-[11px] text-slate-400">
                                                Today, 10:32 AM
                                            </span>
                                        </div>

                                        <p className="mt-1 text-xs leading-5 text-slate-500">
                                            User profile information was updated.
                                        </p>
                                    </div>
                                </div>

                                {/* Login */}
                                <div className="relative flex gap-4">
                                    <div className="relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white bg-green-500 ring-1 ring-green-200" />

                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-start justify-between gap-3">
                                            <p className="text-sm font-semibold text-slate-700">
                                                Login Successful
                                            </p>

                                            <span className="shrink-0 text-[11px] text-slate-400">
                                                Yesterday, 09:15 AM
                                            </span>
                                        </div>

                                        <p className="mt-1 text-xs leading-5 text-slate-500">
                                            User logged into the system successfully.
                                        </p>
                                    </div>
                                </div>

                                {/* Password Changed */}
                                <div className="relative flex gap-4">
                                    <div className="relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white bg-orange-500 ring-1 ring-orange-200" />

                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-start justify-between gap-3">
                                            <p className="text-sm font-semibold text-slate-700">
                                                Password Changed
                                            </p>

                                            <span className="shrink-0 text-[11px] text-slate-400">
                                                02 Sep, 04:45 PM
                                            </span>
                                        </div>

                                        <p className="mt-1 text-xs leading-5 text-slate-500">
                                            User changed their account password.
                                        </p>
                                    </div>
                                </div>

                                {/* Role Updated */}
                                <div className="relative flex gap-4">
                                    <div className="relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white bg-purple-500 ring-1 ring-purple-200" />

                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-start justify-between gap-3">
                                            <p className="text-sm font-semibold text-slate-700">
                                                Role Updated
                                            </p>

                                            <span className="shrink-0 text-[11px] text-slate-400">
                                                01 Sep, 11:20 AM
                                            </span>
                                        </div>

                                        <p className="mt-1 text-xs leading-5 text-slate-500">
                                            User role was changed by an administrator.
                                        </p>
                                    </div>
                                </div>

                                {/* Account Created */}
                                <div className="relative flex gap-4">
                                    <div className="relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white bg-slate-400 ring-1 ring-slate-200" />

                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-start justify-between gap-3">
                                            <p className="text-sm font-semibold text-slate-700">
                                                Account Created
                                            </p>

                                            <span className="shrink-0 text-[11px] text-slate-400">
                                                28 Aug, 02:10 PM
                                            </span>
                                        </div>

                                        <p className="mt-1 text-xs leading-5 text-slate-500">
                                            User account was created in the system.
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserLog;