import OffCanvas from "../../components/OffCanvas";
import Field from "../../components/Field";
import Select from 'react-select';
import ToggleSwitch from "../../components/ToggleSwitch";
import Button from "../../components/Button";
import { RateFormValues } from "../../types/rateSchedule";
import { CAT_TYPES, CATEGORIES, UNITS } from "../../data/seedRateSchedule";
import { getSelectStyles } from "../../utils/selectStyles";

interface RateFormOffCanvasProps {
    isOpen: boolean;
    isEditing: boolean;
    form: RateFormValues;
    onChange: (form: RateFormValues) => void;
    onClose: () => void;
    onSave: () => void;
}
interface SelectOption {
    value: string;
    label: string;
}
// const categoryOptions: SelectOption[] = [
//     { value: "all", label: "All Categories" },
//     ...CATEGORIES.map((c) => ({ value: c, label: c })),
// ];
const unitOptions: SelectOption[] = [
    { value: "all", label: "All Units" },
    ...UNITS.map((u) => ({ value: u, label: u }))
];

const categoryTypeOptions = CATEGORIES.map((type) => ({
    value: type,
    label: type,
}));


export default function RateFormOffCanvas({
    isOpen,
    isEditing,
    form,
    onChange,
    onClose,
    onSave,
}: RateFormOffCanvasProps) {
    return (
        <OffCanvas
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? "Edit Rate" : "Add New Rate"}
            subtitle={isEditing ? "Update this line item" : "Add a line item to the master rate schedule"}
            footer={
                <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button onClick={onSave}>{isEditing ? "Save Changes" : "Add Rate"}</Button>
                </div>
            }
        >
            <div className="space-y-5">
                {/* <Field
                    label="Code"
                    value={form.code}
                    onChange={(e) => onChange({ ...form, code: e.target.value })}
                    placeholder="e.g. C-006"
                /> */}

                {/* <Field
                    label="Category"
                    value={form.category}
                    onChange={(e) => onChange({ ...form, category: e.target.value })}
                    placeholder="e.g. Civil Works"
                /> */}


                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Category
                    </label>

                    <Select
                        options={categoryTypeOptions}
                        value={
                            categoryTypeOptions.find(
                                (option) => option.value === form.categorytype
                            ) ?? null
                        }
                        onChange={(option: any) =>
                            onChange({
                                ...form,
                                categorytype: option?.value ?? "",
                            })
                        }
                        placeholder="Select Category"
                        styles={getSelectStyles()}
                        isSearchable={false}
                    />
                </div>

                <Field
                        label="Module"
                        type="text"
                        value={form.subcategory}
                        onChange={(e) =>
                            onChange({
                                ...form,
                                subcategory: e.target.value,
                            })
                        }
                        placeholder="e.g. Trenching"
                    />



                <Field
                    label="Description"
                    type="textarea"
                    rows={3}
                    value={form.description}
                    onChange={(e) => onChange({ ...form, description: e.target.value })}
                    placeholder="e.g. Trenching in Soft Soil (450mm depth)"
                />
                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Unit of Measure
                    </label>

                    <Select
                        options={unitOptions}
                        value={
                            unitOptions.find((option) => option.value === form.unit) ?? null
                        }
                        onChange={(option: any) =>
                            onChange({
                                ...form,
                                unit: option?.value ?? "",
                            })
                        }
                        placeholder="Select Unit"
                        styles={getSelectStyles()}
                        isSearchable={false}
                    />
                </div>
                <Field
                    label="Standard Rate (JMD)"
                    type="number"
                    value={form.standardRate}
                    onChange={(e) => onChange({ ...form, standardRate: e.target.value })}
                    placeholder="e.g. 1200"
                />

                <Field
                    label="Effective Date"
                    value={form.effectiveDate}
                    onChange={(e) => onChange({ ...form, effectiveDate: e.target.value })}
                    placeholder="YYYY-MM-DD"
                />

                <div>
                    <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Status
                    </span>
                    <div className="flex items-center gap-3 rounded-lg border border-slate-200 px-3.5 py-3">
                        <ToggleSwitch
                            checked={form.status === "active"}
                            onChange={(v) => onChange({ ...form, status: v ? "active" : "inactive" })}
                            srLabel="Toggle rate status"
                        />
                        <span className="text-sm font-semibold text-slate-700">
                            {form.status === "active" ? "Active" : "Inactive"}
                        </span>
                    </div>
                </div>
            </div>
        </OffCanvas>
    );
}
