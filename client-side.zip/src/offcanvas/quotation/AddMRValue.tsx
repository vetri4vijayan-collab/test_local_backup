import { XIcon } from "@phosphor-icons/react";

interface AddMrValueRow {
    id: number;
    category: string;
    description: string;
    uom: string;
    mrValue?: number | null;
}

interface AddMrValueProps {
    isOpen: boolean;
    onClose: () => void;
    row: AddMrValueRow | null;
    value: string;
    onValueChange: (value: string) => void;
    onConfirm: () => void;
}

const AddMrValue = ({
    isOpen,
    onClose,
    row,
    value,
    onValueChange,
    onConfirm,
}: AddMrValueProps) => {
    if (!isOpen || !row) {
        return null;
    }

    const numericValue = Number(value);

    const isValid =
        value.trim() !== "" &&
        Number.isFinite(numericValue) &&
        numericValue >= 0;

    return (
        <div
            className="fixed inset-0 z-50 flex justify-end bg-slate-950/30"
            onMouseDown={(event) => {
                if (
                    event.target ===
                    event.currentTarget
                ) {
                    onClose();
                }
            }}
        >
            <div className="flex h-full w-full max-w-md flex-col bg-white shadow-2xl">
                {/* Header */}
                <div className="flex items-start justify-between border-b border-slate-200 px-5 py-4">
                    <div>
                        <h2 className="text-sm font-bold text-slate-900">
                            Add to Master Rates
                        </h2>

                        <p className="mt-1 text-[10px] text-slate-500">
                            Standardize rate schedule
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={onClose}
                        aria-label="Close"
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                    >
                        <XIcon
                            size={16}
                            weight="bold"
                        />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-5">
                    <div className="space-y-5">
                        {/* Description */}
                        <div>
                            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                Description
                            </label>

                            <div className="mt-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                                <p className="text-xs font-medium leading-relaxed text-slate-800">
                                    {row.description}
                                </p>
                            </div>
                        </div>

                        {/* Category */}
                        <div>
                            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                Category
                            </label>

                            <div className="mt-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                                <p className="text-xs font-medium text-slate-800">
                                    {row.category}
                                </p>
                            </div>
                        </div>

                        {/* UOM */}
                        <div>
                            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                Unit (UOM)
                            </label>

                            <div className="mt-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                                <p className="text-xs font-medium text-slate-800">
                                    {row.uom}
                                </p>
                            </div>
                        </div>

                        {/* MR Value */}
                        <div>
                            <label
                                htmlFor="master-rate-value"
                                className="text-[10px] font-bold uppercase tracking-wider text-slate-500"
                            >
                                Proposed Master Rate (USD)
                            </label>

                            <div className="mt-1.5 flex items-center overflow-hidden rounded-lg border border-slate-200 bg-white transition focus-within:border-red-500 focus-within:ring-2 focus-within:ring-red-100">
                                <span className="flex h-10 items-center border-r border-slate-200 px-3 text-sm font-semibold text-slate-500">
                                    $
                                </span>

                                <input
                                    id="master-rate-value"
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={value}
                                    onChange={(event) =>
                                        onValueChange(
                                            event.target.value
                                        )
                                    }
                                    className="h-10 w-full bg-transparent px-3 text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
                                    placeholder="0.00"
                                />
                            </div>
                        </div>

                        {/* Information */}
                        <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-3">
                            <p className="text-[10px] leading-relaxed text-amber-700">
                                * This rate will be added to the
                                corporate Master Rate Schedule
                                and used as a benchmark for
                                future quotations.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="border-t border-slate-200 bg-white px-5 py-4">
                    <div className="flex items-center justify-end gap-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={onConfirm}
                            disabled={!isValid}
                            className={`rounded-lg px-4 py-2.5 text-xs font-bold text-white transition ${
                                isValid
                                    ? "bg-red-600 hover:bg-red-700"
                                    : "cursor-not-allowed bg-slate-300"
                            }`}
                        >
                            Confirm &amp; Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddMrValue;
