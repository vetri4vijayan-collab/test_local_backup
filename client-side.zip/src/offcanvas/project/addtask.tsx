import React from "react";
import { createPortal } from "react-dom";
import {
    CheckIcon,
    XIcon,
} from "@phosphor-icons/react";

export type TaskPriority =
    | "Low"
    | "Medium"
    | "High"
    | "Urgent";

export interface AddTaskForm {
    name: string;
    description: string;
    estimatedHours: string;
    actualHours: string;
    hourlyRate: string;
    materialCost: string;
    otherExpenses: string;
    project: string;
    phase: string;
    assignStaff: string[];
    startDate: string;
    dueDate: string;
    priority: TaskPriority;
}

export interface AddTaskProject {
    id: string;
    projectName: string;
}

export interface AddTaskPhase {
    id: string;
    name: string;
}

export interface AddTaskProps {
    showModal: boolean;

    form: AddTaskForm;

    projects: AddTaskProject[];

    phases: AddTaskPhase[];

    teamMembers: string[];
    editingTaskId: string | null;

    onClose: () => void;

    onSave: () => void;

    setForm: React.Dispatch<
        React.SetStateAction<AddTaskForm>
    >;
}

const ADDTASK: React.FC<AddTaskProps> = ({
    showModal,
    form,
    projects,
    phases,
    teamMembers,
    editingTaskId,
    onClose,
    onSave,
    setForm,
}) => {

    if (!showModal) {
        return null;
    }
    const [showStaffMenu, setShowStaffMenu] = React.useState(false);

const isFormValid =
    form.name.trim() !== "" &&
    form.project !== "" &&
    form.phase !== "" &&
    form.assignStaff.length > 0 &&
    form.startDate !== "" &&
    form.dueDate !== "" &&
    form.description.trim() !== "";


    return createPortal(
        <div
            className="fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm"

            onMouseDown={(e) => {
                if (e.target === e.currentTarget) {
                    onClose();
                }
            }}
        >
            <div
                className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white shadow-2xl"
                onMouseDown={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white px-6 py-5">
                    <div>
                       <h2 className="text-xl font-bold text-slate-800">
                            {editingTaskId ? 'Edit Task' : 'Add Task'}
                        </h2>

                        <p className="mt-1 text-sm text-slate-500">
                            {editingTaskId
                                ? 'Update task details and assigned staff.'
                                : 'Add task details and track its progress.'}
                        </p>

                    </div>

                    <button
                        type="button"
                        onClick={onClose}
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                    >
                        <XIcon size={20} />
                    </button>
                </div>

                {/* Form */}
                <div className="grid grid-cols-1 gap-5 p-6 md:grid-cols-2">

                    {/* Task Title */}
                    <div className="md:col-span-2">
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Task Title *
                        </label>

                        <input
                            type="text"
                            value={form.name}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    name: e.target.value,
                                }))
                            }
                            placeholder="Enter task title"
                            autoFocus
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Project */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Project *
                        </label>

                        <select
                            value={form.project}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    project: e.target.value,
                                }))
                            }
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        >
                            <option value="">
                                Select Project
                            </option>

                            {projects.map((item) => (
                                <option
                                    key={item.id}
                                    value={item.id}
                                >
                                    {item.projectName}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Phase */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Phase *
                        </label>

                        <select
                            value={form.phase}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    phase: e.target.value,
                                }))
                            }
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        >
                            <option value="">
                                Select Phase
                            </option>

                            {phases.map((phase) => (
                                <option
                                    key={phase.id}
                                    value={phase.id}
                                >
                                    {phase.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Assign Staff */}
                    <div className="relative">
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Assign Staff *
                        </label>

                        <button
                            type="button"
                            onClick={() => setShowStaffMenu((prev) => !prev)}
                            className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-left text-sm outline-none transition hover:border-slate-300 focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        >
                            <span
                                className={
                                    form.assignStaff.length > 0
                                        ? "text-slate-700"
                                        : "text-slate-400"
                                }
                            >
                                {form.assignStaff.length > 0
                                    ? form.assignStaff.join(", ")
                                    : "Select Staff"}
                            </span>

                            <span className="text-slate-400">
                                {showStaffMenu ? "▲" : "▼"}
                            </span>
                        </button>

                        {showStaffMenu && (
                            <div className="absolute left-0 right-0 z-50 mt-2 max-h-60 overflow-y-auto rounded-lg border border-slate-200 bg-white p-2 shadow-lg">
                                {teamMembers.map((member) => {
                                    const isSelected =
                                        form.assignStaff.includes(member);

                                    return (
                                        <label
                                            key={member}
                                            className="flex cursor-pointer items-center gap-3 rounded-md px-3 py-2.5 transition hover:bg-slate-50"
                                        >
                                            <input
                                                type="checkbox"
                                                checked={isSelected}
                                                onChange={() => {
                                                    setForm((prev) => ({
                                                        ...prev,
                                                        assignStaff: isSelected
                                                            ? prev.assignStaff.filter(
                                                                (staff) =>
                                                                    staff !== member
                                                            )
                                                            : [
                                                                ...prev.assignStaff,
                                                                member,
                                                            ],
                                                    }));
                                                }}
                                                className="h-4 w-4 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                            />

                                            <span className="text-sm font-medium text-slate-700">
                                                {member}
                                            </span>
                                        </label>
                                    );
                                })}
                            </div>
                        )}

                        {form.assignStaff.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1.5">
                                {form.assignStaff.map((staff) => (
                                    <span
                                        key={staff}
                                        className="rounded-md bg-red-50 px-2 py-1 text-xs font-semibold text-red-600"
                                    >
                                        {staff}
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>


                    {/* Start Date */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Start Date *
                        </label>

                        <input
                            type="date"
                            value={form.startDate}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    startDate:
                                        e.target.value,
                                }))
                            }
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Due Date */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Due Date *
                        </label>

                        <input
                            type="date"
                            min={form.startDate || undefined}
                            value={form.dueDate}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    dueDate:
                                        e.target.value,
                                }))
                            }
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Priority */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Priority *
                        </label>

                        <select
                            value={form.priority}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    priority:
                                        e.target
                                            .value as TaskPriority,
                                }))
                            }
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        >
                            <option value="Low">
                                Low
                            </option>

                            <option value="Medium">
                                Medium
                            </option>

                            <option value="High">
                                High
                            </option>

                            <option value="Urgent">
                                Urgent
                            </option>
                        </select>
                    </div>

                    {/* Estimated Hours */}
                    <div>
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Estimated Hours
                        </label>

                        <input
                            type="number"
                            min="0"
                            value={form.estimatedHours}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    estimatedHours:
                                        e.target.value,
                                }))
                            }
                            placeholder="0"
                            className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Description */}
                    <div className="md:col-span-2">
                        <label className="mb-2 block text-sm font-medium text-slate-700">
                            Description *
                        </label>

                        <textarea
                            rows={4}
                            value={form.description}
                            onChange={(e) =>
                                setForm((prev) => ({
                                    ...prev,
                                    description:
                                        e.target.value,
                                }))
                            }
                            placeholder="Enter task description"
                            className="w-full resize-none rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none transition focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>
                </div>

                {/* Footer */}
                <div className="flex justify-end gap-3 border-t border-slate-200 bg-white px-6 py-4">
                    <button
                        type="button"
                        onClick={onClose}
                        className="rounded-lg border border-slate-200 px-5 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                   <button
                        type="button"
                        onClick={onSave}
                        disabled={!isFormValid}
                        className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <CheckIcon size={16} weight="bold" />

                        {editingTaskId ? "Update Task" : "Add Task"}
                    </button>

                </div>
            </div>
        </div>,
        document.body
    );
};

export default ADDTASK;
