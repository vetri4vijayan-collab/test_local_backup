import { StylesConfig } from "react-select";

export const getSelectStyles = <T,>(): StylesConfig<T, false> => ({
    control: (base, state) => ({
        ...base,
        minHeight: "42px",
        height: "42px",
        borderRadius: "8px",
        borderColor: state.isFocused ? "#ef4444" : "#cbd5e1",
        boxShadow: state.isFocused
            ? "0 0 0 2px rgba(239, 68, 68, 0.2)"
            : "none",
        backgroundColor: "#ffffff",
        cursor: "pointer",

        "&:hover": {
            borderColor: state.isFocused ? "#ef4444" : "#cbd5e1",
        },
    }),

    valueContainer: (base) => ({
        ...base,
        padding: "0 14px",
    }),

    input: (base) => ({
        ...base,
        margin: 0,
        padding: 0,
        fontSize: "14px",
    }),

    singleValue: (base) => ({
        ...base,
        color: "#1e293b",
        fontSize: "14px",
    }),

    placeholder: (base) => ({
        ...base,
        color: "#94a3b8",
        fontSize: "14px",
    }),

    indicatorSeparator: () => ({
        display: "none",
    }),

    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#94a3b8",
        padding: "0 10px",

        "&:hover": {
            color: "#ef4444",
        },
    }),

    menu: (base) => ({
        ...base,
        zIndex: 9999,
        borderRadius: "8px",
        overflow: "hidden",
        marginTop: "4px",
        boxShadow:
            "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)",
    }),

    menuList: (base) => ({
        ...base,
        padding: "4px",
    }),

    option: (base, state) => ({
        ...base,
        fontSize: "14px",
        padding: "9px 12px",
        borderRadius: "6px",
        cursor: "pointer",

        backgroundColor: state.isSelected
            ? "#ef4444"
            : state.isFocused
                ? "#fef2f2"
                : "#ffffff",

        color: state.isSelected ? "#ffffff" : "#1e293b",

        "&:active": {
            backgroundColor: "#ef4444",
            color: "#ffffff",
        },
    }),

    noOptionsMessage: (base) => ({
        ...base,
        fontSize: "14px",
        color: "#94a3b8",
    }),

    loadingMessage: (base) => ({
        ...base,
        fontSize: "14px",
        color: "#94a3b8",
    }),
});