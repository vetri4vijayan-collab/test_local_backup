import logo from './img/logo.png';
import favIcon from './img/favicon.png';

export { logo, favIcon };