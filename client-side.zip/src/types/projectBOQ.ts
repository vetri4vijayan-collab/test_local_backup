export interface BOQItemm {
    categoryType: string;
    id: number;
    module: string;
    category: string;
    description: string;
    unit: string;
    quantity: number;
    rate: number;
}

export interface SelectOption {
    value: string;
    label: string;
}

export interface BOQSection {
    id: number;
    title: string;
    color: string;
    categoryType: string;
    category: string;
}


