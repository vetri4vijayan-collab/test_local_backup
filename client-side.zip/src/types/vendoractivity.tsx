import React from "react";

/**
 * Main activity categories
 */
export type VendorActivityCategory =
    | "Profile"
    | "Project"
    | "Quotation"
    | "Invoice"
    | "Document"
    | "Status";

/**
 * Specific actions that can happen
 */
export type VendorActivityAction =
    | "Created"
    | "Updated"
    | "Modified"
    | "Deleted"
    | "Uploaded"
    | "Downloaded"
    | "Status Changed";

/**
 * Entity affected by the activity
 */
export type VendorActivityEntity =
    | "Vendor Profile"
    | "Project"
    | "Quotation"
    | "Invoice"
    | "Document"
    | "Vendor Status";

/**
 * Activity status / visual type
 */
export type VendorActivityStatus =
    | "success"
    | "info"
    | "warning"
    | "danger";

/**
 * Individual field change
 *
 * Example:
 * {
 *     field: "Payment Terms",
 *     oldValue: "30 Days",
 *     newValue: "60 Days"
 * }
 */
export interface VendorActivityChange {
    field: string;
    oldValue?: string | number | null;
    newValue?: string | number | null;
}

/**
 * Main vendor activity log interface
 */
export interface VendorActivity {
    id: string;
    vendorId: string;
    vendorName: string;
    category: VendorActivityCategory;
    action: VendorActivityAction;
    entity: VendorActivityEntity;
    /**
     * Human-readable activity message
     *
     * Example:
     * "Vendor profile was updated"
     */
    title: string;

    description?: string;

    /**
     * User who performed the action
     */
    performedBy: string;

    /**
     * Optional user role
     */
    performedByRole?: string;

    /**
     * Date/time of activity
     */
    timestamp: string;

    /**
     * Optional entity reference
     *
     * Example:
     * quotation ID, project ID, invoice ID, document ID
     */
    referenceId?: string;

    /**
     * Optional reference name
     *
     * Example:
     * "QT-2026-001"
     * "MSA Agreement.pdf"
     */
    referenceName?: string;

    /**
     * Fields that were changed
     */
    changes?: VendorActivityChange[];

    /**
     * UI status
     */
    status: VendorActivityStatus;
}

/**
 * Props for Activity Log component
 */
export interface VendorActivityLogProps {
    vendorId: string;

    vendorName: string;

    activities: VendorActivity[];
}

/**
 * Props for a single timeline item
 */
export interface VendorActivityItemProps {
    activity: VendorActivity;
}
