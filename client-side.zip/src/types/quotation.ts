export type QuotationViewMode = "grid" | "list";

export type QuotationStatus =
    | "Form Issued"
    | "Form Submitted"
    | "Form Approved"
    | "Form Rejected"
    | "Issued"
    | "Draft"
    | "Not Responded"
    | "Submitted"
    | "Awarded"
    | "Not Responded"
    | "Rejected";


export type QuotationCategory =
    | "Construction"
    | "Electrical"
    | "Mechanical"
    | "Civil"
    | "Interior";

export type WorkflowStage =
| "Technical Review"
| "Financial Review"
| "Executive Sign-off"
| "Rejected"
| "Draft"
| "Submitted for Approval"
| "Fully Approved";

export interface Quotation {

    id: string;
    quotationNo: string;
    vendor: string;
    vendorName: string;
    projectTitle: string;
    date: string;
    grandTotal: number;
    currency: string;
    margin: number;
    status: QuotationStatus;
    category: string;
    items: number;
    progress: number;
    validUntil: string;
    createdDate: string;
    clientName: string;
    formTemplate: string;
}


export interface QuotationStats {
    total: number;
    pending: number;
    approved: number;
    totalValue: number;
}

/* Rename this */
export interface QuotationFilterState {
    query: string;
    category: string;
    status: string;
    currency: string;
}
