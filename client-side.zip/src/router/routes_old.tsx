import { lazy } from 'react';
import Login from '../pages/Login';
import UnderDevelopment from '../pages/UnderDevelopment';
import CompanyInformation from '../pages/Settings/CompanyInformation';
import SettingsLayout from '../components/Layouts/SettingsLayout';
import RolesPermissions from '../pages/Settings/RolesPermissions';
import ApiConfigurations from '../pages/Settings/ApiConfigurations';
import Users from '../pages/Users';
import MasterRateSchedule from '../pages/MasterRateSchedule';
import Vendors from '../pages/Vendors';
import Quotation from '../pages/Quotation';
import NewQuotation from '../components/quotations/NewQuotation';
import VendorProfile from '../components/vendor/VendorProfile';
import VendorCategorySetting from '../components/vendor/vendor_category_setting';
import VendorSettings from '../components/Layouts/VendorSetting';
import VendorCurrencySetting from '../components/vendor/vendor_currency_setting';
import { CurrencyDollarIcon } from '@phosphor-icons/react';
import VendorPaymentSetting from '../components/vendor/vendor_payment_setting';
import VendorIndustrySectorSetting from '../components/vendor/vendor_infra_setting';
import CommonSetting from '../components/Layouts/CommonSetting';
import UnitSetting from '../pages/Common_setting/unit_setting';
import ValidityPeriodSetting from '../pages/Common_setting/validityperiod_setting';
import VendorStatusSetting from '../components/vendor/vendor_status_setting';
import QuotationDetails from '../components/quotations/QuotationDetails';
import MasterRateSetting from '../components/Layouts/Master_rate_setting';
import CategorySetting from '../pages/MasterRate_setting/Category_setting';
import ProjectBOQList from '../components/quotations/ProjectBOQ_list';
import ProjectBOQ from '../components/quotations/ProjectBOQ';
import TermsCondition from '../pages/Common_setting/terms_condition';
import Dashboard from '../pages/Admin_Dashboard';
import ProjectList from '../components/projects/project_list';
import ProjectOverview from '../components/projects/project_overview';
import Projects from '../components/projects/project';
import List from '../components/myTask/List';
import TimelineTask from '../components/projects/TimelineTask';
import InvoiceList from '../components/invoices/invoice_list';
import InvoiceGenerate from '../components/invoices/invoice_generate';
import SurveyReport from '../components/SurveyReport/SurveyReport';
import Admin_Dashboard from '../pages/Admin_Dashboard';
import SurveyList from '../components/SurveyReport/SurveyList';
import SurveyPack from '../components/SurveyReport/SurveyPack';
import SurveyTemplate from '../pages/SurveyTemplate';
import VendorSummary from '../components/vendor_dashboard/vendor_summary';

const routes = [
    // dashboard
    {
        path: '/',
        element: <Login />,
        layout: 'blank',
    },
    {
        path: '/admin_dashboard',
        element: <  Admin_Dashboard />,
        layout: 'default',
    },
    {
        path: '/vendor_dashboard',
        element: <  VendorSummary />,
        layout: 'default',
    },
   {
    path: "/projects",
    element: <Projects />,
    layout: "default",
    children: [
        {
            index: true,
            element: <ProjectList />,
        },
        {
            path: "project_details/:projectId",
            element: <ProjectOverview />,
        },
    ],
},

    {
        path: '/vendor',
        element: <Vendors />,
        layout: 'default',
    },
    {
        path: "/vendor/vendorprofile",
        element: <VendorProfile/>,
        layout: 'default',
    },
    {
        path: '/quotation',
        element: <Quotation />,
        layout: 'default',
    },

    {
        path: '/quotation/edit_quotation',
        element : <NewQuotation onBack={function (): void {
            throw new Error('Function not implemented.');
        } } onOpenMasterRate={function (): void {
            throw new Error('Function not implemented.');
        } } />,
        layout : 'default',
    },
    {
    path: "/quotation/project_boq/edit-boq",
    element: <ProjectBOQ  />,
    layout: "default",
    },
    {
        path: '/quotation/project_boq',
        element: <ProjectBOQList onAddBOQ={() => {setShowProjectBOQ(true);}}/>,
        layout: 'default',
    },
    {
        path: '/quotation/project_boq/add-boq',
        element: <ProjectBOQ/>,
        layout: 'default',
    },
    {
    path: '/quotation/quotationdetails',
    element: <QuotationDetails/>,
    layout: 'default',
    },


    {
    path: "/invoices",
    element: <InvoiceList />,
    layout: "default",
    },
    {
        path: "/invoices/new_invoice",
        element: <InvoiceGenerate />,
        layout: "default",
    },


    {
    path: '/tasks',
    element: <List/>,
    layout: 'default',
    },

    {
    path: '/survey_report',
    element: <SurveyTemplate/>,
    layout: 'default',
    },
    {
    path: '/survey_report/create_template',
    element: <SurveyReport/>,
    layout: 'default',
    },
    {
    path: '/quotation/survey-form',
    element: <SurveyPack/>,
    layout: 'default',
    },
    {
    path: '/survey_report/view_form/:id',
    element: <SurveyPack/>,
    layout: 'default',
    },


    {
    path: '/timline',
    element: <TimelineTask/>,
    layout: 'default',
    },


    {
        path: '/user_management',
        element: <Users />,
        layout: 'default',
    },
    {
        path: '/master_rate_schedule',
        element: <MasterRateSchedule />,
        layout: 'default',
    },
    {
        path: '/settings',
        element: <SettingsLayout />,
        layout: 'default',
        children: [
            {
                path: 'general_settings',
                element: <CompanyInformation />,
                layout: 'default',
            },
            {
                path: 'roles_permissions',
                element: <RolesPermissions />,
                layout: 'default',
            },
            {
                path: 'api_configuration',
                element: <ApiConfigurations />,
                layout: 'default',
            },
            {
                path: "vendors",
                element: <VendorSettings />,
                children: [
                    {
                        path: "vendor_category",
                        element: <VendorCategorySetting />,
                        layout: 'default',
                    },
                    {
                        path: "currency_format",
                        element: <VendorCurrencySetting />,
                        layout: 'default',
                    },
                    {
                        path: "payment_terms",
                        element: <VendorPaymentSetting />,
                        layout: 'default',
                    },
                    {
                        path: "status",
                        element: <VendorStatusSetting />,
                    },
                    {
                        path: "industry_sector",
                        element: <VendorIndustrySectorSetting />,
                        layout: 'default',
                    },
                ],
            },
            {
                path: 'common_setting',
                element: <CommonSetting />,
                children: [
                    {
                        path:"Unit",
                        element: <UnitSetting/>,
                        layout: 'default',
                    },
                    {
                        path:"Validity_Period",
                        element: <ValidityPeriodSetting/>,
                        layout: 'default',
                    },
                    {
                        path:"Terms_Condition",
                        element: <TermsCondition/>,
                        layout: 'default',
                    },


                ]
            },
           {
                path: "master_rate",
                element: <MasterRateSetting />,
                layout: "default",
                children: [
                    {
                        path: "category",
                        element: <CategorySetting />,
                    },
                ],
            },




        ],
    },
];

export { routes };
    function setShowProjectBOQ(arg0: boolean) {
        throw new Error('Function not implemented.');
    }

