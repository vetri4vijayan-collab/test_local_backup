import { useMemo, useRef, useState } from "react";
import {
    CaretLeftIcon,
    ClockCounterClockwiseIcon,
    DownloadSimpleIcon,
    PencilSimpleIcon,
    PenNibIcon,
    PlusIcon,
    TrashIcon,
    UploadSimpleIcon,
} from "@phosphor-icons/react";
import Button from "../components/Button";
import DataTable, { DataTableAction, DataTableColumn } from "../components/DataTable";
import ToggleSwitch from "../components/ToggleSwitch";
import ConfirmDialog from "../components/ConfirmModal";

import RateFilters from "../features/master_rate_schedule/RateFilters";
import RateFormOffCanvas from "../offcanvas/master_rate_schedule/RateFormOffcanvas";
import RateHistoryOffCanvas from "../offcanvas/master_rate_schedule/RateHistoryOffcanvas";
import { exportRatesToCsv, parseRatesCsvFile } from "../features/master_rate_schedule/csvUtils";

import { RateItem, RateFormValues, emptyRateForm } from "../types/rateSchedule";
import { fmtJmd, initialRateData, todayIso } from "../data/seedRateSchedule";

export default function MasterRateSchedule() {
    const [data, setData] = useState<RateItem[]>(initialRateData);
    const [search, setSearch] = useState("");
    const [categoryFilter, setCategoryFilter] = useState("all");

    const [formOpen, setFormOpen] = useState(false);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [form, setForm] = useState<RateFormValues>(emptyRateForm(todayIso()));

    const [historyRow, setHistoryRow] = useState<RateItem | null>(null);
    const [deleteTarget, setDeleteTarget] = useState<RateItem | null>(null);

    const importInputRef = useRef<HTMLInputElement>(null);

    const filtered = useMemo(() => {
        const q = search.trim().toLowerCase();
        return data.filter((row) => {
            const matchesCategory = categoryFilter === "all" || row.category === categoryFilter;
            const matchesSearch =
                q === "" || row.code.toLowerCase().includes(q) || row.description.toLowerCase().includes(q);
            return matchesCategory && matchesSearch;
        });
    }, [data, search, categoryFilter]);

    /* ---- Add / Edit ---- */
    function openAdd() {
        setEditingId(null);
        setForm(emptyRateForm(todayIso()));
        setFormOpen(true);
    }

    function openEdit(row: RateItem) {
        setEditingId(row.id);
        setForm({
            code: row.code,
            category: row.category,
            categorytype:row.categoryType,
            description: row.description,
            unit: row.unit,
            standardRate: String(row.standardRate),
            effectiveDate: row.effectiveDate,
            status: row.status,
            subcategory:row.subcategory,
        });
        setFormOpen(true);
    }

  function saveForm() {
    if (
        !form.code ||
        !form.categorytype ||
        !form.category ||
        !form.subcategory ||
        !form.description ||
        !form.unit ||
        !form.standardRate ||
        !form.effectiveDate
    ) {
        return;
    }

    if (editingId) {
        setData((prev) =>
            prev.map((row) => {
                if (row.id !== editingId) {
                    return row;
                }

                const rateChanged =
                    String(row.standardRate) !==
                        String(form.standardRate) ||
                    row.effectiveDate !==
                        form.effectiveDate;

                const history = rateChanged
                    ? [
                          {
                              rate: Number(
                                  form.standardRate
                              ),
                              effectiveDate:
                                  form.effectiveDate,
                              updatedAt: todayIso(),
                              updatedBy:
                                  "Ajith Kumar",
                          },
                          ...row.history,
                      ]
                    : row.history;

                return {
                    ...row,

                    code: form.code,

                    categoryType:
                        form.categorytype,

                    category:
                        form.category,

                    subcategory:
                        form.subcategory,

                    description:
                        form.description,

                    unit: form.unit,

                    standardRate:
                        Number(form.standardRate),

                    effectiveDate:
                        form.effectiveDate,

                    status: form.status,

                    history,
                };
            })
        );
    } else {
        const newRow: RateItem = {
            id: `${form.code}-${Date.now()}`,

            code: form.code,

            categoryType: form.categorytype,

            category: form.category,

            subcategory: form.subcategory,

            description: form.description,

            unit: form.unit,

            standardRate: Number(form.standardRate),

            effectiveDate: form.effectiveDate,

            status: form.status,

            history: [
                {
                    rate: Number(
                        form.standardRate
                    ),

                    effectiveDate: form.effectiveDate,

                    updatedAt: todayIso(),

                    updatedBy: "Ajith Kumar",
                },
            ],
            rate: 0,
            module: ""
        };

        setData((prev) => [
            newRow,
            ...prev,
        ]);
    }

    setFormOpen(false);
}


    /* ---- Status toggle ---- */
    function toggleStatus(row: RateItem) {
        setData((prev) =>
            prev.map((r) => (r.id === row.id ? { ...r, status: r.status === "active" ? "inactive" : "active" } : r))
        );
    }

    /* ---- Delete ---- */
    function confirmDelete() {
        if (!deleteTarget) return;
        setData((prev) => prev.filter((r) => r.id !== deleteTarget.id));
        setDeleteTarget(null);
    }

    /* ---- Bulk import ---- */
    async function handleImportFile(e: React.ChangeEvent<HTMLInputElement>) {
        const file = e.target.files?.[0];
        if (!file) return;
        const imported = await parseRatesCsvFile(file);
        if (imported.length) setData((prev) => [...imported, ...prev]);
        e.target.value = "";
    }

    /* ---- Table config ---- */
const columns: DataTableColumn<RateItem>[] = [
   {
    key: "subcategory",
    label: "Module",
    sortable: true,
    render: (r) => (
        <div className="flex flex-col gap-1">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-900 group-hover:text-red-600">
                {r.subcategory}
            </span>


        </div>
    ),
},

    {
        key: "category",
        label: "Category",
        sortable: true,
        render: (r) => (
            <div className="flex flex-col gap-1">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-900">
                {r.category}
            </span>
            <span className="w-fit rounded bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-bold text-slate-500">
                {r.code}
            </span>
            </div>
        ),
    },
    {
        key: "categoryType",
        label: "Category Type",
        sortable: true,
        render: (r) => (
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-900">
                {r.categoryType}
            </span>
        ),
    },
    {
        key: "description",
        label: "Description",
        sortable: true,
        render: (r) => (
            <span className="text-xs leading-5 text-slate-500">
                {r.description}
            </span>
        ),
    },
    {
        key: "unit",
        label: "Unit",
        width: "3%",
        sortable: true,
        render: (r) => (
            <span className="text-xs font-semibold text-slate-700">
                {r.unit}
            </span>
        ),
    },
    {
        key: "standardRate",
        label: "Standard Rate",
        align: "center",
        sortable: true,
        render: (r) => (
            <span className="font-bold text-slate-900">
                {fmtJmd(r.standardRate)}
            </span>
        ),
    },
    {
        key: "effectiveDate",
        label: "Effective Date",
        sortable: true,
        width:"9%",
        render: (r) => (
            <span className="text-xs text-slate-600">
                {r.effectiveDate}
            </span>
        ),
    },
    {
        key: "status",
        label: "Status",
        align: "center",
        render: (r) => (
            <div className="flex justify-center">
                <ToggleSwitch
                    checked={r.status === "active"}
                    onChange={() => toggleStatus(r)}
                    srLabel={`Toggle status for ${r.code}`}
                />
            </div>
        ),
    },
    {
        key: "action",
        label: "Actions",
        align: "center",
        render: (row) => (
            <div className="flex items-center justify-center gap-2">
                <Button
                    type="button"
                    variant="outline"
                    onClick={() => setHistoryRow(row)}
                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                    title="View rate history"
                >
                    <ClockCounterClockwiseIcon size={16} />
                </Button>

                <Button
                    type="button"
                    variant="outline"
                    onClick={() => openEdit(row)}
                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                    title="Edit rate"
                >
                    <PenNibIcon size={16} />
                </Button>

                <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDeleteTarget(row)}
                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                    title="Delete rate"
                >
                    <TrashIcon size={16} />
                </Button>
            </div>
        ),
    },
];



    return (
        <>
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Master Rate Schedule</h1>
                </div>

                <div className="flex items-center gap-3">
                    <input ref={importInputRef} type="file" accept=".csv" className="hidden" onChange={handleImportFile} />
                    <Button variant="outline" onClick={() => importInputRef.current?.click()}>
                        <UploadSimpleIcon size={16} /> Bulk Import
                    </Button>
                    <Button variant="outline" onClick={() => exportRatesToCsv(filtered)}>
                        <DownloadSimpleIcon size={16} /> Export CSV
                    </Button>
                    <Button onClick={openAdd}>
                        <PlusIcon size={16} /> Add New Rate
                    </Button>
                </div>
            </div>

            <RateFilters
                search={search}
                onSearchChange={setSearch}
                category={categoryFilter}
                onCategoryChange={setCategoryFilter}
                resultCount={filtered.length}
            />

            <DataTable
                columns={columns}
                data={filtered}
                rowKey={(r) => r.id}
                emptyMessage="No rates match your filters."
            />

            <RateFormOffCanvas
                isOpen={formOpen}
                isEditing={!!editingId}
                form={form}
                onChange={setForm}
                onClose={() => setFormOpen(false)}
                onSave={saveForm}
            />

            <RateHistoryOffCanvas row={historyRow} onClose={() => setHistoryRow(null)} />

            <ConfirmDialog
                open={!!deleteTarget}
                title="Delete rate?"
                message={
                    deleteTarget
                        ? `"${deleteTarget.description}" (${deleteTarget.code}) will be removed from the schedule. This can't be undone.`
                        : ""
                }
                onCancel={() => setDeleteTarget(null)}
                onConfirm={confirmDelete}
            />
        </>
    );
}
