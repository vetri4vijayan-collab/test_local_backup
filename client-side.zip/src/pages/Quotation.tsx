import { useMemo, useState } from "react";

import { quotations as initialQuotations } from "../data/quotations";

import type { Quotation } from "../types/quotation";

import QuotationTabs, {
    QuotationTab,
} from "../components/quotations/QuotationTabs";

import QuotationDashboard from "../components/quotations/QuotationDashboard";
import BidsAndProposals from "../components/quotations/Bids&Proposal";
import ProjectBOQEstimator from "../components/quotations/ProjectBOQ";
import QuotationHeader from "../components/quotations/QuotationHeader";
import NewQuotation from "../components/quotations/NewQuotation";
import QuotationDetails from "../components/quotations/QuotationDetails";
import ProjectBOQList from "../components/quotations/ProjectBOQ_list";

type QuotationView =
    | "list"
    | "new-quotation"
    | "project-boq"
    | "quotation-details";

const Quotations = () => {
    const [activeTab, setActiveTab] =
        useState<QuotationTab>("bids");

    const [showProjectBOQ, setShowProjectBOQ] =
        useState(false);

    const [currentView, setCurrentView] =
        useState<QuotationView>("list");

    const [quotationList, setQuotationList] =
        useState<Quotation[]>(initialQuotations);

    const [selectedQuotation, setSelectedQuotation] =
        useState<Quotation | null>(null);

    const handleViewQuotation = (
        quotation: Quotation
    ) => {
        setSelectedQuotation(quotation);
        setCurrentView("quotation-details");
    };

    const handleStatusChange = (
        quotationId: Quotation["id"],
        status: Quotation["status"],
        
    ) => {
        setQuotationList((previous) =>
            previous.map((quotation) =>
                quotation.id === quotationId
                    ? {
                          ...quotation,
                          status,
                          
                      }
                    : quotation
            )
        );

        setSelectedQuotation((previous) =>
            previous?.id === quotationId
                ? {
                      ...previous,
                      status,
                     
                  }
                : previous
        );
    };

    const stats = useMemo(() => {
        const issued = quotationList.filter(
            (quotation) =>
                quotation.status === "Issued"
        ).length;

        const draft = quotationList.filter(
            (quotation) =>
                quotation.status === "Draft"
        ).length;

        const submitted = quotationList.filter(
            (quotation) =>
                quotation.status === "Submitted"
        ).length;

        const awarded = quotationList.filter(
            (quotation) =>
                quotation.status === "Awarded"
        ).length;

        const notAwarded = quotationList.filter(
            (quotation) =>
                quotation.status === "Not Responded"
        ).length;

        const notResponded = quotationList.filter(
            (quotation) =>
                quotation.status === "Not Responded"
        ).length;

        const awardedValue = quotationList
            .filter(
                (quotation) =>
                    quotation.status === "Awarded"
            )
            .reduce(
                (total, quotation) =>
                    total + Number(quotation.grandTotal),
                0
            );

        return {
            total: quotationList.length,
            issued,
            draft,
            submitted,
            awarded,
            notAwarded,
            notResponded,
            awardedValue,
        };
    }, [quotationList]);

    if (
        currentView === "quotation-details" &&
        selectedQuotation
    ) {
        return (
            <div className="min-h-screen">
                <QuotationDetails
                    quotation={selectedQuotation}
                    onBack={() => {
                        setSelectedQuotation(null);
                        setCurrentView("list");
                    }}
                    onStatusChange={handleStatusChange}
                />
            </div>
        );
    }

    if (currentView === "new-quotation") {
        return (
            <div className="min-h-screen">
                <NewQuotation
                    onBack={() => {
                        setCurrentView("list");
                    }}
                    onOpenMasterRate={() => {
                        setCurrentView("project-boq");
                    }}
                />
            </div>
        );
    }

    if (currentView === "project-boq") {
        return (
            <div className="min-h-screen">
                <ProjectBOQEstimator
                    onBack={() => {
                        setCurrentView("new-quotation");
                    }}
                />
            </div>
        );
    }

    return (
        <div className="min-h-screen">
            <QuotationHeader
                showNewQuotation={
                    activeTab === "bids"
                }
                showBoqActions={
                    activeTab === "boq" &&
                    showProjectBOQ
                }
                showAddBOQ={
                    activeTab === "boq" &&
                    showProjectBOQ
                }
                onExportEstimate={() => {
                    console.log("Export Estimate");
                }}
                onGenerateQuotation={() => {
                    setCurrentView(
                        "new-quotation"
                    );
                }}
            />

            <div className="mb-6">
                <QuotationTabs
                    activeTab={activeTab}
                    onChange={setActiveTab}
                />
            </div>

            {activeTab === "bids" && (
                <>
                    <QuotationDashboard
                        total={stats.total}
                        pending={stats.submitted}
                        approved={stats.awarded}
                        approvedValue={
                            stats.awardedValue
                        }
                    />

                    <BidsAndProposals
                        quotations={quotationList}
                        onView={handleViewQuotation}
                    />
                </>
            )}

            {activeTab === "boq" && (
                <>
                    {!showProjectBOQ ? (
                        <ProjectBOQList
                            onAddBOQ={() => {
                                setShowProjectBOQ(true);
                            }}
                        />
                    ) : (
                        <ProjectBOQEstimator
                            showBackButton
                            onBack={() => {
                                setShowProjectBOQ(false);
                            }}
                        />
                    )}
                </>
            )}
        </div>
    );
};

export default Quotations;
