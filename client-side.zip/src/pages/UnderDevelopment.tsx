import React from 'react';
import { NavLink } from 'react-router-dom';
import { GearSixIcon, WrenchIcon, ArrowLineLeftIcon } from '@phosphor-icons/react';
import { logo } from '../assets/image';

/**
 * UnderDevelopment
 * ----------------------------------------------------------------
 * Drop-in placeholder for any Argus route that isn't built yet.
 * Usage:
 *   <UnderDevelopment />
 *   <UnderDevelopment title="Vendor Management" progress={40} />
 *
 * Keeps the same brand language as Sidebar/Login: navy/blue primary
 * (#123A8F), red accent, white logo chip.
 * ---------------------------------------------------------------- */

interface UnderDevelopmentProps {
    /** Name of the module being built, e.g. "Vendor Management" */
    title?: string;
    /** Short supporting line under the heading */
    description?: string;
    /** 0–100, purely illustrative progress indicator */
    progress?: number;
    /** Where "Back to Dashboard" should go */
    backTo?: string;
}

const UnderDevelopment: React.FC<UnderDevelopmentProps> = ({
    title = 'This page',
    description = "We're still building this part of Argus. Check back soon — it won't be long.",
    progress = 55,
    backTo = '/',
}) => {
    return (
        <div className="flex w-full items-center justify-center py-6">
            <div className="w-full max-w-md rounded-2xl bg-white p-8 text-center shadow-[0_10px_40px_-15px_rgba(18,58,143,0.25)] sm:p-10">
                {/* logo chip */}
                <div className="mb-6 inline-flex items-center gap-2 rounded-xl border border-slate-100 bg-white px-3.5 py-2 shadow-sm">
                    <img src={logo} alt="Argus" className="h-16 w-auto" />
                    {/* <span className="text-sm font-semibold text-[#123A8F]">Argus</span> */}
                </div>

                {/* icon badge */}
                <div className="relative mx-auto mb-6 flex h-20 w-20 items-center justify-center">
                    <span className="absolute inset-0 animate-[spin_9s_linear_infinite] rounded-full border-2 border-dashed border-blue-200 motion-reduce:animate-none" />
                    <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-[#123A8F]/10 text-[#123A8F]">
                        <GearSixIcon className="h-7 w-7 animate-[spin_6s_linear_infinite] motion-reduce:animate-none" weight="bold" />
                    </div>
                    <div className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full border-2 border-white bg-red-500 text-white shadow-sm">
                        <WrenchIcon className="h-3.5 w-3.5" weight="bold" />
                    </div>
                </div>

                {/* copy */}
                <div className="inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-slate-400">
                    <span className="h-px w-5 bg-red-500" />
                    Under development
                    <span className="h-px w-5 bg-blue-700" />
                </div>
                <h1 className="mt-3 text-xl font-bold text-[#0F1E3D] sm:text-2xl">
                    {title === 'This page' ? 'This page is under development' : `${title} is under development`}
                </h1>
                <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-slate-500">{description}</p>

                {/* actions */}
                <NavLink
                    to={backTo}
                    className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#123A8F] py-3 text-sm font-semibold text-white transition hover:bg-[#0F2F73]"
                >
                    <ArrowLineLeftIcon className="h-4 w-4" />
                    Back to Dashboard
                </NavLink>
            </div>
        </div>
    );
};

export default UnderDevelopment;