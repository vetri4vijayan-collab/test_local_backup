import { useState } from "react";
import {
    ArrowsOutIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
} from "@phosphor-icons/react";


import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, { DataTableColumn } from "../../components/DataTable";


export interface Unit {
    id: string;
    name: string;
    description: string;
    status: boolean;
}

const INITIAL_UNITS: Unit[] = [
    {
        id: "UNIT-001",
        name: "Meter",
        description:
            "Unit of measurement used for length, distance, and linear quantities.",
        status: true,
    },
    {
        id: "UNIT-002",
        name: "SqM",
        description:
            "Square meter used for measuring area and surface quantities.",
        status: true,
    },
    {
        id: "UNIT-003",
        name: "Each",
        description:
            "Unit used for individual items, products, equipment, or components.",
        status: true,
    },
    {
        id: "UNIT-004",
        name: "Hour",
        description:
            "Unit used for measuring labor, service, or equipment usage by the hour.",
        status: true,
    },
    {
        id: "UNIT-005",
        name: "Day",
        description:
            "Unit used for measuring labor, service, equipment rental, or activities by the day.",
        status: true,
    },
    {
        id: "UNIT-006",
        name: "Km",
        description:
            "Unit of measurement used for longer distances and transportation-related quantities.",
        status: true,
    },
    {
        id: "UNIT-007",
        name: "Site",
        description:
            "Unit used for measuring work, services, or activities performed at a specific site.",
        status: true,
    },
];

interface UnitFormData {
    name: string;
    description: string;
}

const emptyForm: UnitFormData = {
    name: "",
    description: "",
};

export default function UnitSetting() {
    const [units, setUnits] =
        useState<Unit[]>(INITIAL_UNITS);

    const [showForm, setShowForm] =
        useState(false);

    const [editingUnit, setEditingUnit] =
        useState<Unit | null>(null);

    const [formData, setFormData] =
        useState<UnitFormData>(emptyForm);

    const [deleteUnit, setDeleteUnit] =
        useState<Unit | null>(null);

    const [errors, setErrors] = useState<{
        name?: string;
        description?: string;
    }>({});

    const openAddForm = () => {
        setEditingUnit(null);
        setFormData(emptyForm);
        setErrors({});
        setShowForm(true);
    };

    const openEditForm = (unit: Unit) => {
        setEditingUnit(unit);

        setFormData({
            name: unit.name,
            description: unit.description,
        });

        setErrors({});
        setShowForm(true);
    };

    const closeForm = () => {
        setShowForm(false);
        setEditingUnit(null);
        setFormData(emptyForm);
        setErrors({});
    };

    const validateForm = () => {
        const nextErrors: {
            name?: string;
            description?: string;
        } = {};

        if (!formData.name.trim()) {
            nextErrors.name = "Unit name is required.";
        }

        if (!formData.description.trim()) {
            nextErrors.description =
                "Description is required.";
        }

        const duplicateUnit = units.some(
            (unit) =>
                unit.name.trim().toLowerCase() ===
                    formData.name.trim().toLowerCase() &&
                unit.id !== editingUnit?.id
        );

        if (duplicateUnit) {
            nextErrors.name =
                "A unit with this name already exists.";
        }

        setErrors(nextErrors);

        return Object.keys(nextErrors).length === 0;
    };

    const generateUnitId = () => {
        const highestNumber = units.reduce(
            (highest, unit) => {
                const match = unit.id.match(
                    /UNIT-(\d+)/
                );

                if (!match) {
                    return highest;
                }

                return Math.max(
                    highest,
                    Number(match[1])
                );
            },
            0
        );

        return `UNIT-${String(
            highestNumber + 1
        ).padStart(3, "0")}`;
    };

    const handleSave = () => {
        if (!validateForm()) {
            return;
        }

        if (editingUnit) {
            setUnits((previous) =>
                previous.map((unit) =>
                    unit.id === editingUnit.id
                        ? {
                              ...unit,
                              name: formData.name.trim(),
                              description:
                                  formData.description.trim(),
                          }
                        : unit
                )
            );
        } else {
            const newUnit: Unit = {
                id: generateUnitId(),
                name: formData.name.trim(),
                description:
                    formData.description.trim(),
                status: true,
            };

            setUnits((previous) => [
                ...previous,
                newUnit,
            ]);
        }

        closeForm();
    };

    const handleToggle = (
        unit: Unit,
        checked: boolean
    ) => {
        setUnits((previous) =>
            previous.map((item) =>
                item.id === unit.id
                    ? {
                          ...item,
                          status: checked,
                      }
                    : item
            )
        );
    };

    const handleDelete = () => {
        if (!deleteUnit) {
            return;
        }

        setUnits((previous) =>
            previous.filter(
                (unit) =>
                    unit.id !== deleteUnit.id
            )
        );

        setDeleteUnit(null);
    };

    const columns: DataTableColumn<Unit>[] = [
        {
            key: "name",
            label: "Unit",
            sortable: true,
            width: "30%",
            render: (row) => (
                <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                        <ArrowsOutIcon
                            size={17}
                            weight="duotone"
                        />
                    </div>

                    <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-slate-800">
                            {row.name}
                        </p>

                        <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                            {row.id}
                        </p>
                    </div>
                </div>
            ),
        },
        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "45%",
            render: (row) => (
                <span className="text-xs leading-5 text-slate-500">
                    {row.description}
                </span>
            ),
        },
        {
            key: "status",
            label: "Status",
            sortable: true,
            align: "center",
            width: "15%",
            render: (row) => (
                <div className="flex items-center justify-center">
                    <ToggleSwitch
                        checked={row.status}
                        onChange={(checked) =>
                            handleToggle(
                                row,
                                checked
                            )
                        }
                        srLabel={`Toggle ${row.name} status`}
                    />
                </div>
            ),
        },
        {
            key: "actions",
            label: "Actions",
            align: "center",
            width: "10%",
            render: (row) => (
                <div className="flex items-center justify-center gap-1">
                    <button
                        type="button"
                        onClick={() =>
                            openEditForm(row)
                        }
                        title={`Edit ${row.name}`}
                        aria-label={`Edit ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                    >
                        <PencilSimpleIcon
                            size={16}
                            weight="duotone"
                        />
                    </button>

                    <button
                        type="button"
                        onClick={() =>
                            setDeleteUnit(row)
                        }
                        title={`Delete ${row.name}`}
                        aria-label={`Delete ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                    >
                        <TrashIcon
                            size={16}
                            weight="duotone"
                        />
                    </button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Units
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage the units of measurement
                        available across your enterprise
                        system.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={openAddForm}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                >
                    <PlusIcon
                        size={16}
                        weight="bold"
                    />

                    Add Unit
                </button>
            </div>

            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingUnit
                                ? "Edit Unit"
                                : "Add Unit"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingUnit
                                ? "Update the unit information."
                                : "Create a new unit of measurement."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {editingUnit && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Unit ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingUnit.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Unit Name
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={formData.name}
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            name: event
                                                .target
                                                .value,
                                        })
                                    );

                                    if (errors.name) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                name: undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="e.g. Meter"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.name
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.name && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={
                                    formData.description
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            description:
                                                event.target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="Enter a description for this unit..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.description
                                    }
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={closeForm}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                        >
                            {editingUnit
                                ? "Save Changes"
                                : "Add Unit"}
                        </button>
                    </div>
                </div>
            )}

            <DataTable<Unit>
                columns={columns}
                data={units}
                rowKey={(row) => row.id}
                minWidth="760px"
                emptyMessage="No units found. Click Add Unit to create one."
            />

            {deleteUnit && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={19}
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete Unit
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are you sure you
                                        want to delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteUnit.name
                                            }
                                        </span>
                                        ? This action
                                        cannot be undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={() =>
                                    setDeleteUnit(null)
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleDelete}
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                            >
                                Delete Unit
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
