interface Config {
    apiUrl: string;
    storageUrl: string;
    appTitle: string;
    appVersion: string;
    isDevelopment: boolean;
    isProduction: boolean;
}

const config: Config = {
    apiUrl: import.meta.env.VITE_API_URL || 'http://192.168.3.122:3000/api/v1',
    storageUrl: import.meta.env.VITE_STORAGE_URL || 'http://192.168.3.122:3000/api/v1',
    appTitle: import.meta.env.VITE_APP_TITLE || 'ARGUS',
    appVersion: import.meta.env.VITE_APP_VERSION || '1.0.0',
    isDevelopment: import.meta.env.DEV,
    isProduction: import.meta.env.PROD,
};

export default config;
