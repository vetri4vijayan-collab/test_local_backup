import { useState } from "react";
import {
    Plus,
    PencilSimple,
    Trash,
    Eye,
} from "@phosphor-icons/react";

import DataTable, {
    DataTableColumn,
} from "../DataTable";
import { useNavigate } from "react-router-dom";

export type SurveyTemplate = {
    id: number;
    name: string;
    description: string;
    status: "Active" | "Draft" | "Archived";
    modules: string[];
};

export const INITIAL_TEMPLATES: SurveyTemplate[] = [
    {
        id: 1,
        name: "Full FTTH Field Survey",
        description:
            "Complete FTTH field survey covering CO, OSP poles, NAP, drop, defects, and PPE verification.",
        status: "Active",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
            "MOD-04",
            "MOD-05",
            "MOD-06",
        ],
    },
    {
        id: 2,
        name: "FTTH OSP Network Survey",
        description:
            "Survey template for central office, pole/structure, and NAP network inspection.",
        status: "Draft",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
        ],
    },
    {
        id: 3,
        name: "FTTH Network & Drop Survey",
        description:
            "Covers CO, OSP structures, NAP stations, and customer drop route verification.",
        status: "Active",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
            "MOD-04",
        ],
    },
    {
        id: 4,
        name: "Pole Structure Survey",
        description:
            "Dedicated OSP pole and structure inspection including location, condition, measurements, and observations.",
        status: "Active",
        modules: [
            "MOD-02",
        ],
    },
];

export default function SurveyList() {
    const [templates, setTemplates] =
        useState<SurveyTemplate[]>(INITIAL_TEMPLATES);

    const navigate = useNavigate();

    const handleDelete = (template: SurveyTemplate) => {
        const confirmed = window.confirm(
            `Are you sure you want to delete "${template.name}"?`
        );

        if (!confirmed) {
            return;
        }

        setTemplates((current) =>
            current.filter(
                (item) => item.id !== template.id
            )
        );
    };

    const handleEditTemplate = (
        template: SurveyTemplate
    ) => {
        navigate(
            `/survey_report/create_template?editId=${template.id}`
        );
    };

    const handleAddTemplate = () => {
        navigate("/survey_report/create_template");
    };

    const columns: DataTableColumn<SurveyTemplate>[] = [
        {
            key: "name",
            label: "Template Name",
            sortable: true,
            width: "20%",
            render: (row) => (
                <div>
                    <div className="font-medium text-slate-900">
                        {row.name}
                    </div>

                    <div className="mt-0.5 font-mono text-[10px] text-slate-400">
                        TMP-{String(row.id).padStart(3, "0")}
                    </div>
                </div>
            ),
        },

        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "42%",
            render: (row) => (
                <div className="max-w-xl truncate text-xs text-slate-500">
                    {row.description}
                </div>
            ),
        },

        {
            key: "status",
            label: "Status",
            sortable: true,
            width: "18%",
            render: (row) => {
                const statusStyles = {
                    Active:
                        "bg-emerald-50 text-emerald-700 border-emerald-200",
                    Draft:
                        "bg-amber-50 text-amber-700 border-amber-200",
                    Archived:
                        "bg-slate-100 text-slate-500 border-slate-200",
                };

                return (
                    <span
                        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold ${
                            statusStyles[row.status]
                        }`}
                    >
                        <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />

                        {row.status}
                    </span>
                );
            },
        },

        {
            key: "actions",
            label: "Actions",
            width: "12%",
            render: (row) => (
                <div className="flex items-center justify-content-center gap-2 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();

                            navigate(
                                `/survey_report/view_form/${row.id}?from=survey_report`
                            );
                        }}
                        title="View Survey"
                        aria-label="View Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-sky-600 transition hover:bg-sky-50 hover:text-sky-700"
                    >
                        <Eye size={13} />
                    </button>

                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();
                            handleEditTemplate(row);
                        }}
                        title="Edit Survey"
                        aria-label="Edit Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
                    >
                        <PencilSimple size={13} />
                    </button>

                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();
                            handleDelete(row);
                        }}
                        title="Delete Survey"
                        aria-label="Delete Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-red-600 transition hover:bg-red-50"
                    >
                        <Trash size={13} />
                    </button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-base font-semibold text-slate-900">
                        Survey Templates
                    </h1>

                    <p className="mt-1 text-xs leading-relaxed text-slate-500">
                        Create and manage survey
                        templates for field
                        inspections.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={handleAddTemplate}
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
                >
                    <Plus
                        size={15}
                        weight="bold"
                    />

                    Add Template
                </button>
            </div>

            <DataTable<SurveyTemplate>
                columns={columns}
                data={templates}
                rowKey={(row) => row.id}
                emptyMessage="No survey templates found."
                minWidth="850px"
            />
        </div>
    );
}