import {
    CaretLeftIcon,
    CaretRightIcon,
    ClockCounterClockwiseIcon,
    FileTextIcon,
    InfoIcon,
    PlusCircleIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import DataTable, {
    DataTableColumn,
} from "../DataTable";
import { useRef, useState } from "react";
import { BOQRow } from "../quotations/NewQuotation";

type QuotationStatus =
    | "Draft"
    | "Submitted"
    | "Approved"
    | "Rejected"
    | "Resubmit"
    | "Paid";
import InvoiceApproval from "./InvoiceApproval";



interface ApprovedQuotation {
    id: string;
    quotationNo: string;
    projectTitle: string;
    vendor: string;
    contractValue: number;
    currency: string;
    status: QuotationStatus;
    totalInstallments: number;
    pendingInstallments: number;
    invoicesGenerated: number;
    invoicesPaid: number;
    balanceAmount: number;
    remarks: string;
}

const approvedQuotations: ApprovedQuotation[] = [
    {
        id: "QT-001",
        quotationNo: "QT-2026-001",
        projectTitle: "Kingston Municipal Office Complex",
        vendor: "Caribbean Construction & Engineering Ltd",
        contractValue: 285000,
        currency: "USD",
        status: "Approved",
        totalInstallments: 6,
        pendingInstallments: 2,
        invoicesGenerated: 4,
        invoicesPaid: 3,
        balanceAmount: 95000,
        remarks: ""
    },
    {
        id: "QT-002",
        quotationNo: "QT-2026-002",
        projectTitle: "Montego Bay Coastal Road Improvement",
        vendor: "Island Infrastructure Contractors Ltd",
        contractValue: 1250000,
        currency: "USD",
        status: "Approved",
        totalInstallments: 8,
        pendingInstallments: 3,
        invoicesGenerated: 5,
        invoicesPaid: 4,
        balanceAmount: 375000,
        remarks: ""
    },
    {
        id: "QT-003",
        quotationNo: "QT-2026-003",
        projectTitle: "Downtown Office Renovation",
        vendor: "City Council - Kingston & St. Andrew Corporation",
        contractValue: 178500,
        currency: "USD",
        status: "Approved",
        totalInstallments: 4,
        pendingInstallments: 2,
        invoicesGenerated: 2,
        invoicesPaid: 1,
        balanceAmount: 89000,
        remarks: ""
    },
    {
        id: "QT-004",
        quotationNo: "QT-2026-004",
        projectTitle: "Spalding Fiber FTTx Network Deployment",
        vendor: "Seiretsu JA Ltd",
        contractValue: 425000,
        currency: "USD",
        status: "Submitted",
        totalInstallments: 6,
        pendingInstallments: 4,
        invoicesGenerated: 2,
        invoicesPaid: 1,
        balanceAmount: 285000,
        remarks: ""
    },
    {
        id: "QT-005",
        quotationNo: "QT-2026-005",
        projectTitle: "Smart City Infrastructure",
        vendor: "Kingston Infrastructure Solutions",
        contractValue: 14500000,
        currency: "JMD",
        status: "Draft",
        totalInstallments: 5,
        pendingInstallments: 3,
        invoicesGenerated: 2,
        invoicesPaid: 1,
        balanceAmount: 8700000,
        remarks: ""
    },
    {
        id: "QT-006",
        quotationNo: "QT-2026-006",
        projectTitle: "Commercial Building Electrical Upgrade",
        vendor: "Jamaica Power & Engineering Ltd",
        contractValue: 265750,
        currency: "USD",
        status: "Rejected",
        totalInstallments: 3,
        pendingInstallments: 2,
        invoicesGenerated: 1,
        invoicesPaid: 0,
        balanceAmount: 265750,
        remarks: "Quotation rejected due to pricing exceeding the approved project budget."
    },
    {
        id: "QT-007",
        quotationNo: "QT-2026-007",
        projectTitle: "Rural Broadband Expansion Phase II",
        vendor: "Caribbean Telecom Builders",
        contractValue: 980000,
        currency: "USD",
        status: "Resubmit",
        totalInstallments: 4,
        pendingInstallments: 3,
        invoicesGenerated: 1,
        invoicesPaid: 0,
        balanceAmount: 735000,
        remarks: "Please review the installment schedule and update the payment timeline before resubmitting."
    },
    {
        id: "QT-008",
        quotationNo: "QT-2026-008",
        projectTitle: "Spanish Town Water Supply Upgrade",
        vendor: "Jamaica Water Infrastructure Ltd",
        contractValue: 685000,
        currency: "USD",
        status: "Approved",
        totalInstallments: 5,
        pendingInstallments: 1,
        invoicesGenerated: 4,
        invoicesPaid: 4,
        balanceAmount: 0,
        remarks: ""
    },
    {
        id: "QT-009",
        quotationNo: "QT-2026-009",
        projectTitle: "Portmore Residential Development",
        vendor: "Kingston Building Solutions Ltd",
        contractValue: 8750000,
        currency: "JMD",
        status: "Submitted",
        totalInstallments: 7,
        pendingInstallments: 5,
        invoicesGenerated: 2,
        invoicesPaid: 1,
        balanceAmount: 6250000,
        remarks: "Quotation submitted for commercial and technical review."
    },
    {
        id: "QT-010",
        quotationNo: "QT-2026-010",
        projectTitle: "Negril Tourism Facility Upgrade",
        vendor: "Caribbean Projects & Development Ltd",
        contractValue: 520000,
        currency: "USD",
        status: "Draft",
        totalInstallments: 4,
        pendingInstallments: 4,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 520000,
        remarks: "Draft quotation awaiting final commercial review."
    },
    {
        id: "QT-011",
        quotationNo: "QT-2026-011",
        projectTitle: "May Pen Industrial Park Development",
        vendor: "Jamaica Industrial Contractors Ltd",
        contractValue: 11800000,
        currency: "JMD",
        status: "Approved",
        totalInstallments: 6,
        pendingInstallments: 2,
        invoicesGenerated: 4,
        invoicesPaid: 3,
        balanceAmount: 2950000,
        remarks: ""
    },
    {
        id: "QT-012",
        quotationNo: "QT-2026-012",
        projectTitle: "Mandeville Highway Drainage Improvement",
        vendor: "National Roadworks & Civil Ltd",
        contractValue: 395000,
        currency: "USD",
        status: "Rejected",
        totalInstallments: 3,
        pendingInstallments: 3,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 395000,
        remarks: "Quotation rejected after technical evaluation."
    }
];



const InvoiceList = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<"invoices" | "approvedQuotes">(
        "invoices"
    );

    const handleGenerateInvoice = (quotation: ApprovedQuotation) => {
        navigate("/invoices/new_invoice", {
            state: {
                quotation,
            },
        });
    };

    const formatCurrency = (value: number): string => {
        return value.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
    };

    const handleViewHistory = () => {
        console.log("View history");
    };

    const quotationColumns: DataTableColumn<ApprovedQuotation>[] = [
        {
            key: "projectTitle",
            label: "Project",
            width: "8%",
            sortable: true,
            align: "left",
            render: (row) => (
                <div className="min-w-0">
                    <p
                        title={row.projectTitle}
                        className="truncate text-xs font-bold text-slate-800"
                    >
                        {row.projectTitle}
                    </p>

                    <p
                        title={row.quotationNo}
                        className="mt-1 truncate text-[10px] font-medium text-slate-400"
                    >
                        {row.quotationNo}
                    </p>
                </div>
            ),
        },

        {
            key: "vendor",
            label: "Vendor",
            width: "5%",
            sortable: true,
            align: "left",
            render: (row) => (
                <span
                    title={row.vendor}
                    className="block truncate text-xs font-medium text-slate-700"
                >
                    {row.vendor}
                </span>
            ),
        },

        {
            key: "contractValue",
            label: "Quotation Amount",
            width: "2%",
            sortable: true,
            align: "right",
            render: (row) => (
                <span className="whitespace-nowrap text-[11px] font-bold text-slate-800">
                    {row.currency} {formatCurrency(row.contractValue)}
                </span>
            ),
        },

        {
            key: "balanceAmount",
            label: "Balance Amount",
            width: "5%",
            sortable: true,
            align: "right",
            render: (row) => (
                <span
                    className={`whitespace-nowrap text-[11px] font-bold ${row.balanceAmount > 0
                        ? "text-red-600"
                        : "text-emerald-600"
                        }`}
                >
                    {row.currency} {formatCurrency(row.balanceAmount)}
                </span>
            ),
        },

        {
            key: "totalInstallments",
            label: "Installments",
            width: "3%",
            sortable: true,
            align: "center",
            render: (row) => (
                <div className="flex flex-col items-center justify-center">
                    <div className="flex items-center gap-1">
                        <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-700">
                            {row.totalInstallments}
                        </span>

                        <span className="text-[10px] text-slate-400">
                            /
                        </span>

                        <span className="rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-bold text-amber-600">
                            {row.pendingInstallments}
                        </span>
                    </div>

                    <span className="mt-0.5 whitespace-nowrap text-[8px] font-medium text-slate-400">
                        Total / Pending
                    </span>
                </div>
            ),
        },

        {
            key: "invoicesGenerated",
            label: "Invoices Generated",
            width: "3%",
            sortable: true,
            align: "center",
            render: (row) => (
                <span className="inline-flex min-w-[26px] items-center justify-center rounded-full bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-700">
                    {row.invoicesGenerated}
                </span>
            ),
        },

        {
            key: "invoicesPaid",
            label: "Invoices Paid",
            width: "3%",
            sortable: true,
            align: "center",
            render: (row) => (
                <span className="inline-flex min-w-[26px] items-center justify-center rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700">
                    {row.invoicesPaid}
                </span>
            ),
        },

        {
            key: "status",
            label: "Status",
            width: "3%",
            sortable: true,
            align: "center",
            render: (row) => {
                const statusStyles: Record<string, string> = {
                    Approved: "bg-emerald-50 text-emerald-700",
                    Draft: "bg-slate-100 text-slate-600",
                    Submitted: "bg-blue-50 text-blue-700",
                    Rejected: "bg-red-50 text-red-700",
                    Paid: "bg-purple-50 text-purple-700",
                    Resubmit: "bg-orange-50 text-orange-700",
                };

                return (
                    <div className="flex items-center justify-center gap-1">
                        <span
                            className={`inline-flex whitespace-nowrap rounded-full px-2 py-1 text-[9px] font-bold ${statusStyles[row.status] ??
                                "bg-slate-100 text-slate-600"
                                }`}
                        >
                            {row.status}
                        </span>

                        {row.status === "Resubmit" && (
                            <div className="group relative">
                                <button
                                    type="button"
                                    aria-label="View remarks"
                                    className="inline-flex h-6 w-6 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                                >
                                    <InfoIcon
                                        size={14}
                                        weight="bold"
                                    />
                                </button>

                                <div className="pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 hidden w-60 -translate-x-1/2 group-hover:block">
                                    <div className="rounded-lg bg-slate-900 px-3 py-2 text-left text-xs text-white shadow-lg">
                                        <p className="mb-1 font-semibold text-white">
                                            Remarks
                                        </p>

                                        <p className="leading-relaxed text-slate-300">
                                            {row.remarks ||
                                                "No remarks available."}
                                        </p>
                                    </div>

                                    <div className="absolute left-1/2 top-full -translate-x-1/2 border-4 border-transparent border-t-slate-900" />
                                </div>
                            </div>
                        )}
                    </div>
                );
            },
        },

        {
            key: "action",
            label: "Action",
            width: "3%",
            align: "center",
            render: (row) => (
                <div className="flex items-center justify-center">
                    <button
                        type="button"
                        onClick={() => handleGenerateInvoice(row)}
                        aria-label="Generate Invoice"
                        title="Generate Invoice"
                        className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-red-600 transition-colors hover:bg-red-50"
                    >
                        <FileTextIcon
                            size={15}
                            weight="duotone"
                        />
                    </button>
                </div>
            ),
        },
    ];

    const quotationTableRef = useRef<HTMLDivElement>(null);

const scrollQuotationTable = (
    direction: "left" | "right"
) => {
    const container = quotationTableRef.current;

    if (!container) {
        return;
    }

    const scrollAmount = container.clientWidth * 0.7;

    container.scrollBy({
        left:
            direction === "left"
                ? -scrollAmount
                : scrollAmount,
        behavior: "smooth",
    });
};

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <h1 className="mt-1 text-lg font-bold text-slate-800">
                        Vendor Invoices &amp; Billing Center
                    </h1>
                    <p className="mt-1 max-w-3xl text-xs leading-5 text-slate-500">
                        Review, verify itemized materials, resources, and approve
                        milestone invoices submitted by network contractors.
                    </p>
                </div>
                {/* Tabs - Top Right */}
                <div className="shrink-0">
                    <div className="flex items-center gap-6">
                        {/* Invoices List */}
                        <button
                            type="button"
                            onClick={() => setActiveTab('invoices')}
                            className={`relative pb-3 text-sm font-semibold transition ${activeTab === 'invoices'
                                ? 'text-primary'
                                : 'text-slate-500 hover:text-slate-700'
                                }`}
                        >
                            Invoices List (3)

                            {activeTab === 'invoices' && (
                                <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-primary" />
                            )}
                        </button>

                        {/* Invoice Approved Quote */}
                        <button
                            type="button"
                            onClick={() => setActiveTab('approvedQuotes')}
                            className={`relative pb-3 text-sm font-semibold transition ${activeTab === 'approvedQuotes'
                                ? 'text-primary'
                                : 'text-slate-500 hover:text-slate-700'
                                }`}
                        >
                            Invoice Approved Quote

                            {activeTab === 'approvedQuotes' && (
                                <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-primary" />
                            )}
                        </button>
                    </div>

                </div>
            </div>
            {activeTab === 'invoices' && (
                <InvoiceApproval />
            )}

           {activeTab === "approvedQuotes" && (
    <div className="mt-5 w-full min-w-0">
        {/* Mobile-friendly table wrapper */}
        <div className="relative w-full min-w-0">
            <div
                className="
                    w-full overflow-x-auto overflow-y-hidden
                    rounded-lg border border-slate-200
                    bg-white
                    [-webkit-overflow-scrolling:touch]
                "
            >
                <DataTable<ApprovedQuotation>
                    columns={quotationColumns}
                    data={approvedQuotations}
                    rowKey={(quotation) => quotation.id}
                    emptyMessage="No approved quotations are ready to invoice."
                    minWidth="1100px"
                    className="w-full rounded-lg"
                />
            </div>
        </div>
    </div>
)}
    



        </div >


    );
};

export default InvoiceList;