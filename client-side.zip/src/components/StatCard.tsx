import { Icon } from "@phosphor-icons/react";

export interface StatCardProps {
    label: string;
    value: string | number;
    icon: Icon;
    tone?: "red" | "green" | "blue" | "amber";
    className?: string;
}

export interface StatCardProps {
    label: string;
    value: string | number;
    icon: Icon;
    tone?: "red" | "green" | "blue" | "amber";
    className?: string;
    description?: string;
    delta?: string; 
    deltaLabel?: string;
}

const TONE_STYLES: Record<NonNullable<StatCardProps["tone"]>, string> = {
    red: "bg-red-50 text-red-600",
    green: "bg-emerald-50 text-emerald-600",
    blue: "bg-blue-50 text-blue-600",
    amber: "bg-amber-50 text-amber-600",
};

export default function StatCard({
    label,
    value,
    icon: Icon,
    delta, deltaLabel,
    tone = "red",
    className = "",
}: StatCardProps) {
    return (
        <div
            className={`flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ${className}`}
        >
            <div className="min-w-0">
                <div className="text-[10px] font-black uppercase tracking-wider text-slate-400">{label}</div>
                <div className="mt-1 truncate text-2xl font-black text-slate-900">{value}</div>
                {delta && ( 
                    <div className="mt-2 flex items-center gap-2 text-[12px]">
                        <span className="font-semibold text-emerald-600"> {delta} </span> 
                        {deltaLabel && ( 
                            <span className="text-slate-500"> {deltaLabel} </span> 
                        )} 
                    </div> 
                )}
            </div>
            <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${TONE_STYLES[tone]}`}>
                <Icon size={20} strokeWidth={2.25} />
            </div>
        </div>
    );
}
