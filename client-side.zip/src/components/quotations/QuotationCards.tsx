import {
    ArrowRightIcon,
    CalendarBlankIcon,
    CurrencyDollarSimpleIcon,
    FileTextIcon,
    UserIcon,
} from "@phosphor-icons/react";

import type { Quotation } from "../../types/quotation";

interface QuotationCardProps {
    quotation: Quotation;
    onView: (quotation: Quotation) => void;
}

const QuotationCard = ({
    quotation,
    onView,
}: QuotationCardProps) => {
    const statusClasses: Record<Quotation["status"], string> = {
    "Form Issued": "bg-blue-50 text-blue-700",
    "Form Submitted": "bg-amber-50 text-amber-700",
    "Form Approved": "bg-emerald-50 text-emerald-700",
    "Form Rejected": "bg-red-50 text-red-700",

    Issued: "bg-blue-50 text-blue-700",
    Draft: "bg-slate-100 text-slate-600",
    Submitted: "bg-amber-50 text-amber-700",
    Awarded: "bg-emerald-50 text-emerald-700",
    "Not Responded": "bg-red-100 text-red-600",
    Rejected: "bg-red-50 text-red-700",
};

    const marginClass =
        quotation.margin >= 20
            ? "bg-emerald-50 text-emerald-700"
            : quotation.margin >= 10
                ? "bg-amber-50 text-amber-700"
                : "bg-red-50 text-red-700";

    return (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:border-red-200 hover:shadow-md">
            <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                        <FileTextIcon
                            size={21}
                            weight="duotone"
                        />
                    </div>

                    <div className="min-w-0">
                        <p className="truncate text-sm font-bold text-slate-900">
                            {quotation.quotationNo}
                        </p>

                        <div className="mt-1 flex items-center gap-1 text-xs text-slate-400">
                            <CalendarBlankIcon size={12} />

                            <span>
                                {quotation.date}
                            </span>
                        </div>
                    </div>
                </div>

                <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                        statusClasses[quotation.status]
                    }`}
                >
                    {quotation.status}
                </span>
            </div>

            <div className="mt-5">
                <p className="mb-1 text-[11px] font-medium uppercase tracking-wide text-slate-400">
                    Project Title
                </p>

                <h3 className="truncate text-base font-bold text-slate-900">
                    {quotation.projectTitle}
                </h3>
            </div>

            <div className="mt-3 flex items-center gap-2">
                <UserIcon
                    size={15}
                    className="shrink-0 text-slate-400"
                />

                <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-700">
                        {quotation.vendor}
                    </p>
                </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
                <span className="rounded-md bg-slate-100 px-2 py-1 text-xs font-medium text-slate-600">
                    {quotation.category}
                </span>

                <span className="rounded-md bg-slate-50 px-2 py-1 text-xs text-slate-500">
                    {quotation.items} BOQ Items
                </span>

                <span className="rounded-md bg-slate-50 px-2 py-1 text-xs text-slate-500">
                    {quotation.currency}
                </span>
            </div>

            <div className="mt-5 rounded-xl bg-slate-50 p-4">
                <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">
                        Grand Total
                    </span>

                    <CurrencyDollarSimpleIcon
                        size={17}
                        className="text-slate-400"
                    />
                </div>

                <p className="mt-1 text-xl font-bold text-slate-900">
                    {quotation.currency}{" "}
                    {quotation.grandTotal.toLocaleString()}
                </p>
            </div>

            <div className="mt-4">
                <div className="rounded-xl border border-slate-100 bg-white p-3">
                    <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                        Margin
                    </p>

                    <div className="mt-2">
                        <span
                            className={`inline-flex rounded-md px-2 py-1 text-xs font-semibold ${marginClass}`}
                        >
                            {quotation.margin.toFixed(1)}%
                        </span>
                    </div>
                </div>
            </div>

            <div className="mt-5">
                <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                        Completion
                    </span>

                    <span className="text-xs font-semibold text-slate-700">
                        {quotation.progress}%
                    </span>
                </div>

                <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                    <div
                        className="h-full rounded-full bg-red-500 transition-all"
                        style={{
                            width: `${quotation.progress}%`,
                        }}
                    />
                </div>
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4">
                <div>
                    <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                        Valid Until
                    </p>

                    <p className="mt-0.5 text-xs font-semibold text-slate-600">
                        {quotation.validUntil}
                    </p>
                </div>

                <button
                    type="button"
                    onClick={() => onView(quotation)}
                    className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-red-600 transition-colors hover:bg-red-50 hover:text-red-700"
                >
                    View Quotation

                    <ArrowRightIcon
                        size={14}
                        weight="bold"
                    />
                </button>
            </div>
        </div>
    );
};

export default QuotationCard;