import { NavLink, Outlet } from "react-router-dom";
import {
    RulerIcon,
    BuildingsIcon,
    CalendarBlankIcon,
} from "@phosphor-icons/react";

interface CommonSettingNavItem {
    label: string;
    path: string;
    icon: React.ElementType;
}

const COMMON_SETTING_NAV_ITEMS: CommonSettingNavItem[] = [
    {
        label: "Unit",
        path: "/settings/common_setting/unit",
        icon: RulerIcon,
    },
    {
        label: "Validity Period",
        path: "/settings/common_setting/validity_period",
        icon: CalendarBlankIcon,
    },
    {
        label: "Terms and Condition",
        path: "/settings/common_setting/terms_condition",
        icon: CalendarBlankIcon,
    },
];

export default function CommonSetting() {
    return (
        <div className="min-w-0 p-0">
            <div className="mb-5">
                <h1 className="text-2xl font-bold text-slate-900">
                    Common Settings
                </h1>

                <p className="mt-1 text-sm text-slate-500">
                    Configure common system settings such as units and validity period.
                </p>
            </div>

            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="border-b border-slate-200">
                    <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-transparent">
                        <nav
                            className="flex min-w-max items-center gap-1 px-4 py-3"
                            aria-label="Common settings navigation"
                        >
                            {COMMON_SETTING_NAV_ITEMS.map(
                                ({ label, path, icon: Icon }) => (
                                    <NavLink
                                        key={path}
                                        to={path}
                                        className={({ isActive }) =>
                                            [
                                                "group flex shrink-0 items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all",
                                                isActive
                                                    ? "bg-red-600 text-white shadow-sm shadow-red-600/20"
                                                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
                                            ].join(" ")}>
                                        {({ isActive }) => (
                                            <>
                                                <Icon
                                                    size={17}
                                                    weight={isActive? "fill": "duotone"}
                                                />
                                                <span>{label}</span>
                                            </>
                                        )}
                                    </NavLink>
                                )
                            )}
                        </nav>
                    </div>
                </div>

                <main className="min-w-0 p-6 md:p-5">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
