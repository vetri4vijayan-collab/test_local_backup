import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
    BuildingOfficeIcon,
    BuildingsIcon,
    CurrencyDollarIcon,
    GearIcon,
    GlobeIcon,
    ShieldIcon,
} from "@phosphor-icons/react";

interface NavItem {
    label: string;
    path: string[];
    icon: React.ElementType;
}

const NAV_ITEMS: NavItem[] = [
    {label: "Company Information",path: ["/settings/general_settings"],icon: BuildingsIcon,},
    {label: "Roles & Permissions",path: ["/settings/roles_permissions"],icon: ShieldIcon,},
    {label: "API Configuration",path: ["/settings/api_configuration"],icon: GlobeIcon,},
    {label: "Vendor",
        path: [
            "/settings/vendors/vendor_category",
            "/settings/vendors/currency_format",
            "/settings/vendors/payment_terms",
            "/settings/vendors/validity_period",
            "/settings/vendors/industry_sector",
            "/settings/vendors/status",
        ],
        icon: BuildingOfficeIcon,
    },
    {label: "Common Setting",
        path: ["/settings/common_setting/unit",
            "/settings/common_setting/validity_period",
            "/settings/common_setting/terms_condition",
        ],
        icon: GearIcon,},
    {
    label: "Master Rate",
    path: [

        "/settings/master_rate/category",
    ],
    icon: CurrencyDollarIcon,
},

];

export default function SettingsLayout() {
    const location = useLocation();

    return (
        <div className="grid grid-cols-[205px_1fr] gap-8">
            {/* Left column */}
            <div>
                {/* Page Header */}
                <div className="mb-4">
                    <h1 className="text-2xl font-bold text-slate-900">
                        Settings
                    </h1>
                </div>

                {/* Sidebar */}
                <nav>
                    <ul className="space-y-1.5">
                        {NAV_ITEMS.map(({ label, path, icon: Icon }) => {
                            const isActive = path.includes(location.pathname);

                            return (
                                <li key={label}>
                                    <NavLink
                                        to={path[0]}
                                        className={() =>
                                            [
                                                "flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition-colors",
                                                isActive
                                                    ? "bg-red-600 text-white shadow-sm shadow-red-600/20"
                                                    : "text-slate-600 hover:bg-slate-100",
                                            ].join(" ")
                                        }
                                    >
                                        <Icon
                                            size={18}
                                            weight={isActive ? "fill" : "regular"}
                                        />

                                        <span>{label}</span>
                                    </NavLink>
                                </li>
                            );
                        })}
                    </ul>
                </nav>
            </div>

            {/* Right column */}
            <main className="min-w-0">
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <Outlet />
                </div>
            </main>
        </div>


    );
}
