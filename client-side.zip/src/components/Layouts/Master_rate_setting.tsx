import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { PackageIcon } from "@phosphor-icons/react";

interface MasterRateSettingNavItem {
    label: string;
    path: string;
    icon: React.ElementType;
}

const MASTER_RATE_SETTING_NAV_ITEMS: MasterRateSettingNavItem[] = [
    {
        label: "Category",
        path: "/settings/master_rate/category",
        icon: PackageIcon,
    },
];

export default function MasterRateSetting() {
    return (
        <div className="min-w-0 ">
            {/* Page Header */}
            <div className="mb-5 p-0">
                <h1 className="text-2xl font-bold text-slate-900">
                    Master Rate Settings
                </h1>

                <p className="mt-1 text-sm text-slate-500">
                    Configure and manage master rate settings.
                </p>
            </div>

            {/* Master Rate Settings Panel */}
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

                {/* Navigation */}
                <div className="border-b border-slate-200">
                    <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-transparent">
                        <nav
                            className="flex min-w-max items-center gap-1 px-4 py-3"
                            aria-label="Master rate settings navigation"
                        >
                            {MASTER_RATE_SETTING_NAV_ITEMS.map(
                                ({ label, path, icon: Icon }) => (
                                    <NavLink
                                        key={path}
                                        to={path}
                                        className={({ isActive }) =>
                                            [
                                                "group flex shrink-0 items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all",
                                                isActive
                                                    ? "bg-red-600 text-white shadow-sm shadow-red-600/20"
                                                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
                                            ].join(" ")
                                        }
                                    >
                                        {({ isActive }) => (
                                            <>
                                                <Icon
                                                    size={17}
                                                    weight={
                                                        isActive
                                                            ? "fill"
                                                            : "duotone"
                                                    }
                                                />

                                                <span>{label}</span>
                                            </>
                                        )}
                                    </NavLink>
                                )
                            )}
                        </nav>
                    </div>
                </div>

                {/* Child Route Content */}
                <main className="min-w-0 p-6 md:p-5">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
