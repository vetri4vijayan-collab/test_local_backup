import { Outlet } from "react-router-dom";
import { useState } from "react";

export interface Project {
    id: string;
    projectName: string;
    location: string;
    vendorName: string;
    managerName: string;
    managerEmail: string;
    startDate: string;
    endDate: string;
    projectValue: number;
    budget: number;
    surveyRef: string;
    version: string;
    status:
    | "Planned"
    | "In Progress"
    | "On Hold"
    | "Completed"
    | "Closed";
    progress: number;
}

export interface Deliverable {
    id: string;
    projectId: string;
    name: string;
    dueDate: string;
    completed: boolean;
}
export interface ActivityLog {
    id: string;
    projectId: string;
    entity: "DELIVERABLE";
    entityId: string;
    action: "ADD" | "MODIFY" | "DELETE";
    description: string;
    createdAt: string;
}
export const PROJECT_DATA: Project[] = [
    {
        id: "PRJ-001",
        projectName: "Al Noor Commercial Tower",
        location: "Dubai, UAE",
        vendorName: "Seiretsu JA Ltd",
        managerName: "Sarah Johnson",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 485000,
        budget: 520000,
        status: "Planned",
        progress: 75,
        surveyRef: "Seiretsu FTTx 5.31.26",
        version: "v1.0 — July 19, 2026"
    },
    {
        id: "PRJ-002",
        projectName: "Kingston Office Renovation",
        location: "Kingston, Jamaica",
        vendorName: "Flow Jamaica",
        managerName: "Michael Brown",
        managerEmail: "michael_brown@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 275000,
        budget: 300000,
        status: "In Progress",
        progress: 52,
        surveyRef: "Flow Jamaica FTTx 5.31.26",
        version: "v1.0 — July 25, 2026"
    },
    {
        id: "PRJ-003",
        projectName: "Metro Network Expansion",
        location: "Montego Bay, Jamaica",
        vendorName: "Digicel Metro Networks",
        managerName: "David Wilson",
        managerEmail: "david_wilson@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 350000,
        budget: 375000,
        status: "On Hold",
        progress: 35,
        surveyRef: "Digicel Metro FTTx 5.26.26",
        version: "v1.0 — July 29, 2026"
    },
    {
        id: "PRJ-004",
        projectName: "Regional Operations Center",
        location: "Miami, USA",
        vendorName: "Global Tech Solutions",
        managerName: "Emily Davis",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 620000,
        budget: 650000,
        status: "Completed",
        progress: 100,
        surveyRef: "Global Tech FTTx 3.26.26",
        version: "v1.0 — July 03, 2026"
    },
    {
        id: "PRJ-005",
        projectName: "Regional Operations Center",
        location: "Miami, USA",
        vendorName: "City Council - Kingston & St. Andrew Corporation",
        managerName: "Emily Davis",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 620000,
        budget: 650000,
        status: "Closed",
        progress: 100,
        surveyRef: "Digicel Metro FTTx 3.24.26",
        version: "v1.0 — July 19, 2026"
    },
];


export interface ProjectsContextType {
    projects: Project[];

    updateProject: (
        projectId: string,
        updates: Partial<Project>
    ) => void;

    activityLogs: ActivityLog[];

    addActivityLog: (activity: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => void;
}

export default function Projects() {
    const [projects, setProjects] =
        useState<Project[]>(PROJECT_DATA);

    const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

    const updateProject = (
        projectId: string,
        updates: Partial<Project>
    ) => {
        setProjects((currentProjects) =>
            currentProjects.map((project) =>
                project.id === projectId
                    ? {
                        ...project,
                        ...updates,
                    }
                    : project
            )
        );
    };

    const addActivityLog = ({
        projectId,
        entity,
        entityId,
        action,
        description,
    }: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => {
        const newActivity: ActivityLog = {
            id: `ACT-${Date.now()}`,
            projectId,
            entity,
            entityId,
            action,
            description,
            createdAt: new Date().toISOString(),
        };

        setActivityLogs((currentLogs) => [
            newActivity,
            ...currentLogs,
        ]);
    };


    return (
        <Outlet
            context={{
                projects, updateProject, activityLogs,
                addActivityLog,
            }}
        />

    );
}