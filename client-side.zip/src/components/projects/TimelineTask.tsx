import { Fragment, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  House,
  Table,
  Kanban,
  CalendarBlank,
  ChartLine,
  Users,
  Plus,
  FolderSimple,
  CheckSquare,
  Lightning,
  HourglassMedium,
} from "@phosphor-icons/react";

import { setPageTitle } from "../../store/themeConfigSlice";





interface Task {
  title: string;
  description: string;
  assignedTo: string;
  endDate: string;
  duration: string;
  priority: string;
  status: StatusType;
}

interface User {
  id: string;
  project: string;
  company: string;
  status: string;
  date: string;
  tasks: Task[];
}

type StatusType = "active" | "inprogress" | "completed" | "onhold";

const statusColors: Record<StatusType, string> = {
  active: "bg-blue-500",
  inprogress: "bg-yellow-500",
  completed: "bg-green-500",
  onhold: "bg-gray-400",
};

const TOTAL_WEEKS = 52;
const WEEK_COL_WIDTH = "w-[200px]";

const TimelineTask = () => {
  const dispatch = useDispatch();

  const [showModal, setShowModal] = useState(false);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);

  const [users, setUsers] = useState<User[]>([
    {
      id: "1",
      project: "Enterprise Software License Setup",
      company: "Tech Corp",
      status: "active",
      date: "01-Jan-2026",
      tasks: [
        {
          title: "Infrastructure Setup",
          description: "Setup servers and networking",
          assignedTo: "Mike Chen",
          endDate: "2026-01-07",
          duration: "50",
          priority: "high",
          status: "inprogress",
        },
        {
          title: "License Configuration",
          description: "Configure licenses",
          assignedTo: "John Smith",
          endDate: "2026-01-14",
          duration: "40",
          priority: "low",
          status: "active",
        },
      ],
    },
  ]);

  useEffect(() => {
    dispatch(setPageTitle("Manage Task"));
  }, [dispatch]);

  /**
   * Get week number of the year
   */
  const getWeekOfYear = (dateStr: string): number => {
    const date = new Date(dateStr);

    const startOfYear = new Date(date.getFullYear(), 0, 1);

    const days = Math.floor(
      (date.getTime() - startOfYear.getTime()) /
        (24 * 60 * 60 * 1000)
    );

    return Math.ceil(
      (days + startOfYear.getDay() + 1) / 7
    );
  };

  /**
   * Calculate total tasks
   */
  const totalTasks = users.reduce(
    (total, user) => total + user.tasks.length,
    0
  );

  /**
   * Calculate active tasks
   */
  const activeTasks = users.reduce(
    (total, user) =>
      total +
      user.tasks.filter((task) =>
        ["active", "inprogress"].includes(task.status)
      ).length,
    0
  );

  /**
   * Calculate total hours
   */
  const totalHours = users.reduce(
    (total, user) =>
      total +
      user.tasks.reduce((sum, task) => {
        const hours = parseInt(task.duration || "0", 10);

        return sum + (Number.isNaN(hours) ? 0 : hours);
      }, 0),
    0
  );

  return (
    <div className="p-4">
      {/* =========================================================
          HEADER
      ========================================================== */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold mb-1">
            Task Timeline
          </h2>

          {/* <Breadcrumb
            items={[
              {
                icon: <House size={20} weight="regular" />,
                to: "/dashboard",
              },
              {
                label: "Task Tracker",
                to: "/task/manage_task",
              },
              {
                label: "Timeline",
                isActive: true,
              },
            ]}
          /> */}
        </div>

        <div className="flex gap-2 items-center">
          {/* View Toggle */}
          {/* <ToggleButton
            tabs={[
              {
                label: "Table",
                icon: (
                  <Table
                    size={20}
                    weight="regular"
                  />
                ),
                value: "table",
                route: "/task/manage_task",
              },
              {
                label: "Kanban",
                icon: (
                  <Kanban
                    size={20}
                    weight="regular"
                  />
                ),
                value: "kanban",
                route: "/task/task_kanban_view",
              },
              {
                label: "Calendar",
                icon: (
                  <CalendarBlank
                    size={20}
                    weight="regular"
                  />
                ),
                value: "calendar",
                route: "/task/task_calendar_view",
              },
              {
                label: "Timeline",
                icon: (
                  <ChartLine
                    size={20}
                    weight="regular"
                  />
                ),
                value: "timeline",
                route: "/task/task_timeline_view",
              },
              {
                label: "Workload",
                icon: (
                  <Users
                    size={20}
                    weight="regular"
                  />
                ),
                value: "work_order",
                route: "/task/task_workorder_view",
              },
            ]}
            initialView="timeline"
          /> */}

          {/* Add Project */}
          {/* <Button
            text="Add Projects"
            icon={
              <Plus
                size={20}
                weight="bold"
              />
            }
            onClick={() =>
              setShowAddProjectModal(true)
            }
          /> */}

          {/* Add Task */}
          {/* <Button
            text="Add Task"
            icon={
              <Plus
                size={20}
                weight="bold"
              />
            }
            onClick={() => setShowModal(true)}
          /> */}
        </div>
      </div>

      {/* =========================================================
          DASHBOARD CARDS
      ========================================================== */}
      <div className="flex gap-3 items-center justify-start py-3">
        {/* Total Projects */}
        {/* <MiniDashboardCard
          label="Total Projects"
          count={users.length}
          iconBg="#e8f8f5"
          iconColor="#00695c"
          Icon={FolderSimple}
        /> */}

        {/* Total Tasks */}
        {/* <MiniDashboardCard
          label="Total Tasks"
          count={totalTasks}
          iconBg="#fff8e1"
          iconColor="#ff6f00"
          Icon={CheckSquare}
        /> */}

        {/* Active Tasks */}
        {/* <MiniDashboardCard
          label="Active Tasks"
          count={activeTasks}
          iconBg="#fbe9e7"
          iconColor="#d84315"
          Icon={Lightning}
        /> */}

        {/* Total Hours */}
        {/* <MiniDashboardCard
          label="Total Hours"
          count={totalHours}
          iconBg="#e1f5fe"
          iconColor="#0277bd"
          Icon={HourglassMedium}
        /> */}
      </div>

      {/* =========================================================
          TIMELINE / GANTT TABLE
      ========================================================== */}
      <div className="overflow-x-auto">
        <table className="border-collapse w-full rounded table-fixed">
          {/* =====================================================
              TABLE HEADER
          ====================================================== */}
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2 text-left w-[350px]">
                Task / Project
              </th>

              {Array.from(
                { length: TOTAL_WEEKS },
                (_, index) => (
                  <th
                    key={index}
                    className={`border p-1 text-center text-xs ${WEEK_COL_WIDTH}`}
                  >
                    Week {index + 1}
                  </th>
                )
              )}
            </tr>
          </thead>

          {/* =====================================================
              TABLE BODY
          ====================================================== */}
          <tbody>
            {users.map((project) => (
              <Fragment key={project.id}>
                {/* =================================================
                    PROJECT ROW
                ================================================== */}
                <tr className="bg-gray-50">
                  <td className="border p-2 font-bold">
                    {project.project}
                  </td>

                  <td
                    colSpan={TOTAL_WEEKS}
                    className="border"
                  ></td>
                </tr>

                {/* =================================================
                    TASK ROWS
                ================================================== */}
                {project.tasks.map((task, index) => {
                  const endWeek = Math.min(
                    TOTAL_WEEKS,
                    Math.max(
                      1,
                      getWeekOfYear(task.endDate)
                    )
                  );

                  /**
                   * 40 hours = 1 working week
                   */
                  const durationWeeks = Math.max(
                    1,
                    Math.ceil(
                      Number(task.duration) / 40
                    )
                  );

                  const startWeek = Math.max(
                    1,
                    endWeek - durationWeeks + 1
                  );

                  const span =
                    endWeek - startWeek + 1;

                  return (
                    <tr key={index}>
                      {/* Task Name */}
                      <td className="border p-2 pl-6">
                        {task.title}
                      </td>

                      {/* =================================================
                          EMPTY WEEKS BEFORE TASK
                      ================================================== */}
                      {Array.from({
                        length: startWeek - 1,
                      }).map((_, weekIndex) => (
                        <td
                          key={`pre-${weekIndex}`}
                          className="border"
                        ></td>
                      ))}

                      {/* =================================================
                          TASK BAR
                      ================================================== */}
                      <td
                        colSpan={span}
                        className="border p-1"
                      >
                        <div
                          className={`
                            ${statusColors[task.status]}
                            text-white
                            text-xs
                            rounded
                            px-2
                            py-1
                            text-center
                            font-medium
                          `}
                        >
                          {task.duration} hrs
                        </div>
                      </td>

                      {/* =================================================
                          EMPTY WEEKS AFTER TASK
                      ================================================== */}
                      {Array.from({
                        length:
                          TOTAL_WEEKS - endWeek,
                      }).map((_, weekIndex) => (
                        <td
                          key={`post-${weekIndex}`}
                          className="border"
                        ></td>
                      ))}
                    </tr>
                  );
                })}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* =========================================================
          ADD TASK MODAL
      ========================================================== */}
      {/* <AddTask
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onAddTask={(newTask) => {
          const normalizedTask: Task = {
            ...newTask,
            status:
              newTask.status === "upcoming"
                ? "active"
                : newTask.status,
          };

          setUsers((prev) =>
            prev.map((user) =>
              user.id === "1"
                ? {
                    ...user,
                    tasks: [
                      ...user.tasks,
                      normalizedTask,
                    ],
                  }
                : user
            )
          );

          setShowModal(false);
        }}
        dateStr={new Date()
          .toISOString()
          .slice(0, 10)}
      /> */}

      {/* =========================================================
          ADD PROJECT MODAL
      ========================================================== */}
      {/* <AddProject
        isOpen={showAddProjectModal}
        onClose={() =>
          setShowAddProjectModal(false)
        }
        dateStr={new Date().toLocaleDateString(
          "en-GB"
        )}
      /> */}
    </div>
  );
};

export default TimelineTask;
