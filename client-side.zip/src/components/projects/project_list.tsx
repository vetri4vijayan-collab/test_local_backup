import {
    EyeIcon,
    MapPinIcon,
    PencilSimpleIcon,
} from "@phosphor-icons/react";
import { useState } from "react";
import {
    useNavigate,
    useOutletContext,
} from "react-router-dom";
import DataTable, {
    DataTableColumn,
} from "../DataTable";
import ProjectEdit from "../../offcanvas/project/project_edit";
import {
    Project,
    ProjectsContextType,
} from "./project";

export default function ProjectList() {
    const [showEditDrawer, setShowEditDrawer] =
        useState(false);

    const [selectedProject, setSelectedProject] =
        useState<Project | null>(null);

    const navigate = useNavigate();

    const {projects,updateProject,} = useOutletContext<ProjectsContextType>();

    const handleViewProject = (project: Project) => {
        navigate(
            `/projects/project_details/${project.id}`
        );
    };

    const handleEditProject = (project: Project) => {
        setSelectedProject(project);
        setShowEditDrawer(true);
    };

    const columns: DataTableColumn<Project>[] = [
        {
            key: "projectName",
            label: "Project",
            sortable: true,
            width: "230px",
            render: (row) => (
                <div className="min-w-0">
                    <p className="font-bold text-slate-900 transition-colors group-hover:text-red-600">
                        {row.projectName}
                    </p>

                    <div className="mt-0.5 flex items-center gap-1 text-xs text-slate-400">
                        <MapPinIcon
                            size={12}
                            weight="regular"
                            className="shrink-0"
                        />
                        <span>{row.location}</span>
                    </div>
                </div>
            ),
        },
        {
            key: "vendorName",
            label: "Vendor",
            sortable: true,
            width: "170px",
            render: (row) => (
                <p className="truncate font-medium text-slate-700">
                    {row.vendorName}
                </p>
            ),
        },
        {
            key: "managerName",
            label: "Manager",
            sortable: true,
            width: "150px",
            render: (row) => (
                <p className="truncate font-medium text-slate-700">
                    {row.managerName}
                </p>
            ),
        },
        {
            key: "startDate",
            label: "Project Dates",
            sortable: true,
            align: "center",
            width: "160px",
            render: (row) => (
                <div className="space-y-1">
                    <div className="flex items-center gap-1">
                        <span className="w-10 text-[9px] font-semibold uppercase text-slate-400">
                            Start
                        </span>
                        <span className="whitespace-nowrap text-xs font-medium text-slate-700">
                            {row.startDate}
                        </span>
                    </div>

                    <div className="flex items-center gap-1">
                        <span className="w-10 text-[9px] font-semibold uppercase text-slate-400">
                            End
                        </span>
                        <span className="whitespace-nowrap text-xs font-medium text-slate-700">
                            {row.endDate}
                        </span>
                    </div>
                </div>
            ),
        },
        {
            key: "projectValue",
            label: "Project Value",
            sortable: true,
            align: "center",
            width: "140px",
            render: (row) => (
                <span className="whitespace-nowrap font-semibold text-slate-800">
                    ${row.projectValue.toLocaleString()}
                </span>
            ),
        },
        {
            key: "budget",
            label: "Budget",
            sortable: true,
            align: "center",
            width: "130px",
            render: (row) => (
                <span className="whitespace-nowrap font-semibold text-slate-800">
                    ${row.budget.toLocaleString()}
                </span>
            ),
        },
        {
            key: "status",
            label: "Status & Progress",
            sortable: true,
            align: "center",
            width: "190px",
            render: (row) => {
                const statusStyles: Record<
                    Project["status"],
                    string
                > = {
                        Planned: "bg-emerald-50 text-emerald-700",
                        Completed: "bg-blue-50 text-blue-700",
                        "On Hold": "bg-amber-50 text-amber-700",
                        "In Progress": "bg-slate-100 text-slate-600",
                        Closed: "bg-red-50 text-red-700",
                    };

                return (
                    <div className="flex flex-col items-center gap-2">
                        <span
                            className={`inline-flex rounded-full px-2.5 py-1 text-[10px] font-bold ${statusStyles[row.status]}`}
                        >
                            {row.status}
                        </span>

                        <div className="flex items-center gap-2">
                            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-200">
                                <div
                                    className="h-full rounded-full bg-red-600 transition-all"
                                    style={{
                                        width: `${row.progress}%`,
                                    }}
                                />
                            </div>

                            <span className="text-xs font-semibold text-slate-600">
                                {row.progress}%
                            </span>
                        </div>
                    </div>
                );
            },
        },
        {
            key: "actions",
            label: "Actions",
            align: "center",
            width: "100px",
            render: (row) => (
                <div className="flex items-center justify-center">
                    <div className="hidden items-center gap-1.5 group-hover:flex">
                        <button
                            type="button"
                            onClick={() =>
                                handleViewProject(row)
                            }
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-600 transition hover:text-red-600"
                            title="View Project"
                        >
                            <EyeIcon size={16} />
                        </button>

                        {(row.status === "Planned" ||
                            row.status === "On Hold") && (
                            <button
                                type="button"
                                onClick={() =>
                                    handleEditProject(row)
                                }
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-red-600"
                                title="Edit Project"
                            >
                                <PencilSimpleIcon
                                    size={16}
                                />
                            </button>
                        )}
                    </div>
                </div>
            ),
        },
    ];

    return (
        <div className="w-full">
            <div className="mb-6">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                    Projects
                </h1>

                <p className="mt-1 text-sm text-slate-500">
                    Manage and track all organizational projects
                </p>
            </div>

            <DataTable<Project>
                columns={columns}
                data={projects}
                rowKey={(row) => row.id}
                minWidth="1200px"
                emptyMessage="No projects found."
            />

            <ProjectEdit
                isOpen={showEditDrawer}
                project={selectedProject}
                onClose={() => {
                    setShowEditDrawer(false);
                    setSelectedProject(null);
                }}
                onSave={(updatedProject) => {
                    updateProject(
                        updatedProject.id,
                        updatedProject
                    );

                    setShowEditDrawer(false);
                    setSelectedProject(null);
                }}
            />
        </div>
    );
}
