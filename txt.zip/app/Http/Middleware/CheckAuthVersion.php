<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckAuthVersion
{
  public function handle(Request $request, Closure $next)
  {
    if (Auth::check()) {

      $user = Auth::user();

      $sessionVersion = session('auth_version');

      if (
        $sessionVersion === null ||
        (int) $sessionVersion !== (int) $user->auth_version
      ) {

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if ($request->expectsJson()) {
          return response()->json([
            'status' => 401,
            'message' => 'Your session has expired. Please login again.',
            'data' => null
          ], 401);
        }

        return redirect()->route('login')
          ->with('error', 'Your session has expired. Please login again.');
      }
    }

    return $next($request);
  }
}
