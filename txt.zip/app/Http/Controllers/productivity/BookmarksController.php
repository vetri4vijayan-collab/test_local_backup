<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Board;
use App\Models\Productivity\BoardCategory;
use App\Models\Productivity\Bookmark;
use App\Models\GeneralSettingsModel;
use App\Services\FavIcon\BookmarkFaviconService;
use App\Services\Productivity\ProductivityAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class BookmarksController extends ProductivityBaseController
{
    public function __construct(
        ProductivityAccessService $access,
        protected BookmarkFaviconService $faviconService,
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.bookmarks.index');
    }

    public function lookups(Request $request): JsonResponse
    {
        $user = $this->authUser($request);
        $userId = $this->access->userId($request);
        $companyId = $this->access->companyId($request);

        // abort_unless($userId > 0, 403, 'Your ERP login identity is not available for BookMarks.');

        $companyRows = DB::table('egc_company')
            ->where('status', 0)
            ->where('sno', '>', 0)
            ->orderBy('sno')
            ->get([
                'sno',
                'company_name',
                'company_short_name',
                'company_base_color',
                'company_logo',
            ])
            ->map(fn ($row) => [
                'sno' => (int) $row->sno,
                'company_name' => trim((string) $row->company_name),
                'company_short_name' => trim((string) ($row->company_short_name ?: $row->company_name)),
                'company_base_color' => $row->company_base_color,
                'company_logo' => $row->company_logo,
                'is_main' => false,
            ]);

        // Company 0 is the ERP's main organisation. Its display name is always
        // sourced from General Settings instead of a duplicated company row.
        $companies = collect([[
            'sno' => 0,
            'company_name' => $this->mainCompanyName(),
            'company_short_name' => $this->mainCompanyName(),
            'company_base_color' => null,
            'company_logo' => null,
            'is_main' => true,
        ]])->concat($companyRows)->values();

        // Visibility Group is a people selector, so use active staff rather than
        // role-1-only records. The role-1 rule is no longer exposed as a board
        // owner selector; the creator is taken from the authenticated staff id.
        $staff = DB::table('egc_staff as s')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->where('s.status', '!=', 2)
            ->where('s.sno', '>', 0)
            ->orderBy('s.staff_name')
            ->orderBy('s.sno')
            ->limit(5000)
            ->get([
                's.sno',
                's.staff_name',
                's.email_id',
                's.company_id',
                's.role_id',
                'c.company_name',
                'c.company_short_name',
            ]);

        $currentUser = DB::table('egc_staff as s')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->where('s.sno', $userId)
            ->where('s.status', '!=', 2)
            ->first([
                's.sno',
                's.staff_name',
                's.email_id',
                's.company_id',
                's.role_id',
                'c.company_name',
                'c.company_short_name',
            ]);

        return $this->ok([
            'companies' => $companies,
            'staff' => $staff,
            // Kept as a compatibility field for older frontend fragments. The
            // BookMarks UI does not expose an owner selector.
            'owners' => [],
            'current_user' => [
                'user_id' => $userId,
                'role_id' => $this->access->roleId($request),
                'role_name' => $this->access->role($request),
                'is_super_admin' => $this->access->isSuper($request),
                'company_id' => $companyId,
                'staff_name' => $currentUser?->staff_name ?? $user->name ?? null,
                'email_id' => $currentUser?->email_id ?? $user->email ?? null,
                'company_name' => $currentUser?->company_name,
                'company_short_name' => $currentUser?->company_short_name,
            ],
        ]);
    }

    public function boards(Request $request)
    {
        $query = DB::table('egc_tool_boards as b')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'b.company_id')
            ->where('b.status', 0)
            ->where('b.is_archived', 0)
            ->select([
                'b.sno', 'b.company_id', 'b.board_name', 'b.icon',
                'b.description', 'b.visibility', 'b.is_locked', 'b.is_archived', 'b.sort_order',
                'b.created_by', 'b.owner_user_id',
                'c.company_name', 'c.company_short_name', 'c.company_base_color',
            ])
            ->selectSub(function ($q) {
                $q->from('egc_tool_bookmarks as bm')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('bm.board_id', 'b.sno')
                    ->where('bm.status', 0);
            }, 'bookmark_count')
            ->orderBy('b.sort_order')
            ->orderBy('b.board_name');

        $this->applyBookmarkBoardReadScope($query, $request, 'b');

        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            if ($search !== '') {
                $escaped = addcslashes($search, '%_\\\\');
                $query->where(function ($q) use ($escaped) {
                    $q->where('b.board_name', 'like', '%' . $escaped . '%')
                        ->orWhere('b.description', 'like', '%' . $escaped . '%');
                });
            }
        }

        if ($request->filled('company_id') && $request->input('company_id') !== 'all') {
            $selectedCompanyId = (int) $request->input('company_id');

            // BookMarks boards are stored in the common company_id=0 bucket.
            // A company filter therefore includes common boards plus legacy
            // company-owned boards; the read-scope below still decides which
            // common boards the current staff member is actually allowed to see.
            $query->where(function ($scope) use ($selectedCompanyId) {
                $scope->where('b.company_id', 0)
                    ->orWhere('b.company_id', $selectedCompanyId);
            });
        }

        $boards = $query->get();
       
        
        $boards->each(function ($board) {
            
            $creatorId =  $this->boardCreatorId($board) ;
            $board->can_manage = $this->access->canManageResource(
                'board', (int) $board->sno, $creatorId
            );
            $board->company_short_name = $board->company_short_name ?: $board->company_name;
            $board->visibility_company_ids = $this->visibilityGrantIds((int) $board->sno, 'company');
            $board->visibility_user_ids = $this->visibilityGrantIds((int) $board->sno, 'user');
        });

        return $this->ok($boards);
    }

    public function board(Request $request, int $id): JsonResponse
    {
        $board = Board::query()
            ->where('status', 0)
            ->where('is_archived', 0)
            ->findOrFail($id);

        abort_unless($this->canReadBoard($request, $board), 403);

        $visibilityCompanyIds = $this->visibilityGrantIds($board->sno, 'company');
        $visibilityUserIds = $this->visibilityGrantIds($board->sno, 'user');

        $categories = BoardCategory::query()
            ->where('board_id', $board->sno)
            ->orderBy('sort_order')
            ->orderBy('category_name')
            ->get();

        $bookmarkQuery = Bookmark::query()
            ->where('board_id', $board->sno)
            ->where('status', 0)
            ->orderBy('sort_order')
            ->orderBy('bookmark_name');

        $search = trim((string) $request->input('search', ''));
        if ($search !== '') {
            $escaped = addcslashes($search, '%_\\\\');
            $bookmarkQuery->where(function ($q) use ($escaped) {
                $q->where('bookmark_name', 'like', '%' . $escaped . '%')
                    ->orWhere('url', 'like', '%' . $escaped . '%')
                    ->orWhere('description', 'like', '%' . $escaped . '%');
            });
        }

        $totalBookmarks = (clone $bookmarkQuery)->count();
        $bookmarks = $bookmarkQuery->limit(500)->get();

        $topLinks = Bookmark::query()
            ->where('board_id', $board->sno)
            ->where('status', 0)
            ->where('is_pinned', 1)
            ->orderBy('sort_order')
            ->orderBy('bookmark_name')
            ->limit(6)
            ->get();

        $counts = Bookmark::query()
            ->where('board_id', $board->sno)
            ->where('status', 0)
            ->select('category_id', DB::raw('COUNT(*) as total'))
            ->groupBy('category_id')
            ->pluck('total', 'category_id');

        foreach ($categories as $category) {
            $category->setAttribute('bookmark_count', (int) ($counts[$category->sno] ?? 0));
        }

        // Legacy Google S2 values are suppressed in the response. Users see
        // the cached ERP favicon or the neutral bookmark icon instead.
        $this->hydrateLegacyFavicons($bookmarks);
        $this->hydrateLegacyFavicons($topLinks);

        $company = $this->companyDetails((int) ($board->company_id ?? 0));
        $board->setAttribute('company_name', $company['company_name']);
        $board->setAttribute('company_short_name', $company['company_short_name']);
        $board->setAttribute('company_base_color', $company['company_base_color']);
        $board->setAttribute('can_manage', $this->access->canManageResource(
            'board', $board->sno, $this->boardCreatorId($board)
        ));

        return $this->ok([
            'board' => $board,
            'categories' => $categories,
            'bookmarks' => $bookmarks->groupBy('category_id'),
            'top_links' => $topLinks,
            'total_bookmarks' => $totalBookmarks,
            'returned_bookmarks' => $bookmarks->count(),
            'truncated' => $totalBookmarks > $bookmarks->count(),
            'visibility_company_ids' => $visibilityCompanyIds,
            'visibility_user_ids' => $visibilityUserIds,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()
            ->where('status', 0)
            ->with(['board', 'category'])
            ->findOrFail($id);

        $board = $bookmark->board;

        abort_unless(
            $board
                && $board->status === 0
                && !$board->is_archived
                && $this->canReadBoard($request, $board),
            403
        );

        return $this->ok($bookmark);
    }

    public function data(Request $request): JsonResponse
    {
        $query = Bookmark::query()
            ->where('status', 0)
            ->with(['board', 'category'])
            ->whereHas('board', function ($boardQuery) use ($request) {
                $boardQuery
                    ->where('status', 0)
                    ->where('is_archived', 0);

                $this->applyBookmarkBoardReadScope($boardQuery, $request);
            });

        if ($request->filled('board_id')) {
            $query->where('board_id', (int) $request->input('board_id'));
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', (int) $request->input('category_id'));
        }

        if ($request->filled('health_status')) {
            $query->where('health_status', trim((string) $request->input('health_status')));
        }

        $search = trim((string) $request->input('search', ''));
        if ($search !== '') {
            $escaped = addcslashes($search, '%_\\');
            $query->where(function ($row) use ($escaped) {
                $row->where('bookmark_name', 'like', '%' . $escaped . '%')
                    ->orWhere('url', 'like', '%' . $escaped . '%')
                    ->orWhere('description', 'like', '%' . $escaped . '%');
            });
        }

        $perPage = min(max((int) $request->input('per_page', 25), 10), 100);

        return $this->ok([
            'rows' => $query
                ->orderByDesc('click_count')
                ->orderBy('sort_order')
                ->orderBy('bookmark_name')
                ->paginate($perPage),
        ]);
    }

    public function favicon(Request $request): JsonResponse
    {
        $inputUrl = trim((string) $request->input('url', ''));
        if ($inputUrl !== '') {
            $request->merge(['url' => $this->addDefaultHttpScheme($inputUrl)]);
        }

        $data = $request->validate([
            'url' => ['required', 'url', 'max:2000'],
            'refresh' => ['nullable', 'boolean'],
        ]);

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs can be resolved.', 422);
        }

        $forceRefresh = (bool) ($data['refresh'] ?? false);
        $faviconUrl = $this->faviconService->getFavicon($url, $forceRefresh);

        // Legacy generated icons are never authoritative. If a real icon is
        // resolved, repair old NULL/generated records. If no real icon exists,
        // remove the generated fallback from active records instead of showing
        // the wrong branding.
        if ($faviconUrl) {
            Bookmark::query()
                ->where('status', 0)
                ->where('url', $url)
                ->where(function ($q) {
                    $q->whereNull('favicon_url')
                        ->orWhere('favicon_url', 'like', '%_fallback.%')
                        ->orWhere('favicon_url', 'like', '%google.com/s2/favicons%');
                })
                ->update([
                    'favicon_url' => $faviconUrl,
                    'updated_at' => now(),
                ]);
        } elseif ($forceRefresh) {
            Bookmark::query()
                ->where('status', 0)
                ->where('url', $url)
                ->where(function ($q) {
                    $q->where('favicon_url', 'like', '%_fallback.%')
                        ->orWhere('favicon_url', 'like', '%google.com/s2/favicons%');
                })
                ->update([
                    'favicon_url' => null,
                    'updated_at' => now(),
                ]);
        }

        return $this->ok([
            'favicon_url' => $faviconUrl,
            'resolved' => (bool) $faviconUrl,
            'refreshed' => $forceRefresh,
        ]);
    }

    public function faviconImage(Request $request)
    {
        $url = trim((string) $request->query('url', ''));

        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return response()->noContent(204);
        }

        // A new bookmark resolves its current official favicon immediately.
        // No generated visual fallback is persisted.
        $faviconUrl = $this->faviconService->getFavicon($url, true);

        if (!$faviconUrl) {
            return response()->noContent(204);
        }

        $filename = basename((string) parse_url($faviconUrl, PHP_URL_PATH));
        $relative = 'favicons/' . $filename;
        $disk = \Illuminate\Support\Facades\Storage::disk('public');

        if (!$filename) {
            return response()->noContent(204);
        }

        $path = null;
        $mime = 'image/x-icon';

        if ($disk->exists($relative)) {
            try {
                $candidate = $disk->path($relative);
                if (is_file($candidate)) {
                    $path = $candidate;
                    $mime = $disk->mimeType($relative) ?: $mime;
                }
            } catch (\Throwable $exception) {
                report($exception);
            }
        }

        // Production fallback for deployments where public/storage is linked but
        // the web server cannot serve the generated /storage URL reliably.
        if (!$path) {
            $publicPath = public_path($relative);
            if (is_file($publicPath)) {
                $path = $publicPath;
                $mime = function_exists('mime_content_type')
                    ? (mime_content_type($publicPath) ?: $mime)
                    : $mime;
            }
        }

        if (!$path) {
            return response()->noContent(204);
        }

        return response()->file($path, [
            'Content-Type' => $mime,
            'Cache-Control' => 'public, max-age=604800, immutable',
        ]);
    }

    public function storeBoard(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);

        $user = $this->authUser($request);
        $userId = $this->access->userId($request);
        $authCompanyId = $user->company_id !== null && $user->company_id !== ''
            ? (int) $user->company_id
            : null;

        // abort_unless($userId > 0, 403, 'Your ERP login identity is not available for BookMarks.');

        $data = $request->validate([
            'board_name' => ['required', 'string', 'max:160'],
            'icon' => ['nullable', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:5000'],
            'visibility' => ['nullable', 'in:Private,Company,Group'],
            'visibility_company_ids' => ['nullable', 'array'],
            'visibility_company_ids.*' => ['integer', 'min:0'],
            'visibility_user_ids' => ['nullable', 'array'],
            'visibility_user_ids.*' => ['integer', 'min:1'],
            'is_locked' => ['nullable', 'boolean'],
        ]);

        // BookMarks boards are common resources, not company-owned boards.
        // Company/group visibility is an access rule, while company_id=0 is the
        // stable common bucket used by the legacy schema.
        $companyId = 0;

        $visibility = $data['visibility'] ?? 'Private';
        $companyTargets = $this->normalizeVisibilityIds($data['visibility_company_ids'] ?? []);
        $userTargets = $this->normalizeVisibilityIds($data['visibility_user_ids'] ?? []);

        $this->validateVisibilityTargets($visibility, $companyTargets, $userTargets);

        DB::beginTransaction();
        try {
            $board = Board::create([
                'company_id' => $companyId,
                // Legacy schema requires owner_user_id. The feature does not
                // expose an owner field; it always follows the creator.
                'owner_user_id' => $userId,
                'board_name' => trim($data['board_name']),
                'icon' => trim((string) ($data['icon'] ?? '')) ?: 'mdi-bookmark-outline',
                'description' => $this->nullableString($data['description'] ?? null),
                'visibility' => $visibility,
                'is_locked' => (bool) ($data['is_locked'] ?? false),
                'is_archived' => false,
                'sort_order' => (int) Board::query()->where('company_id', $companyId)->max('sort_order') + 1,
                'status' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            $this->syncBoardVisibility($request, $board, $visibility, $companyTargets, $userTargets);

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            throw $e;
        }

        $this->audit(
            $request,
            'BookMarks',
            'board_created',
            'board',
            $board->sno,
            null,
            $board->toArray(),
            [
                'visibility' => $visibility,
                'visibility_company_ids' => $companyTargets,
                'visibility_user_ids' => $userTargets,
                'created_by' => $userId,
                'auth_role_id' => (int) ($user->role_id ?? 0),
                'auth_company_id' => $authCompanyId,
            ]
        );

        return $this->ok($board, 'Board created successfully.');
    }

    public function updateBoard(Request $request, int $id): JsonResponse
    {
        $board = Board::findOrFail($id);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $user = $this->authUser($request);
        $authCompanyId = $user->company_id !== null && $user->company_id !== ''
            ? (int) $user->company_id
            : null;

        $data = $request->validate([
            'board_name' => ['required', 'string', 'max:160'],
            'icon' => ['nullable', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:5000'],
            'visibility' => ['nullable', 'in:Private,Company,Group'],
            'visibility_company_ids' => ['nullable', 'array'],
            'visibility_company_ids.*' => ['integer', 'min:0'],
            'visibility_user_ids' => ['nullable', 'array'],
            'visibility_user_ids.*' => ['integer', 'min:1'],
            'is_locked' => ['nullable', 'boolean'],
            'is_archived' => ['nullable', 'boolean'],
        ]);

        // The UI no longer exposes company ownership for boards. Preserve the
        // existing storage value for legacy records; new boards are created in
        // the common company_id=0 bucket. Access is controlled by visibility.
        $companyId = (int) ($board->company_id ?? 0);

        $visibility = $data['visibility'] ?? ($board->visibility ?: 'Private');
        $hasCompanyTargets = array_key_exists('visibility_company_ids', $data);
        $hasUserTargets = array_key_exists('visibility_user_ids', $data);

        $companyTargets = $hasCompanyTargets
            ? $this->normalizeVisibilityIds($data['visibility_company_ids'] ?? [])
            : $this->visibilityGrantIds($board->sno, 'company');
        $userTargets = $hasUserTargets
            ? $this->normalizeVisibilityIds($data['visibility_user_ids'] ?? [])
            : $this->visibilityGrantIds($board->sno, 'user');

        // Legacy boards may not yet have visibility grants. Keep a Company
        // board readable from its board.company_id while it remains untouched.
        if ($visibility === 'Company' && !$companyTargets && !$hasCompanyTargets && $board->company_id !== null) {
            $companyTargets = [(int) $board->company_id];
        }

        $this->validateVisibilityTargets($visibility, $companyTargets, $userTargets);

        $before = $board->toArray();

        DB::beginTransaction();
        try {
            $board->update([
                'company_id' => $companyId,
                'board_name' => trim($data['board_name']),
                'icon' => trim((string) ($data['icon'] ?? '')) ?: 'mdi-bookmark-outline',
                'description' => $this->nullableString($data['description'] ?? null),
                'visibility' => $visibility,
                'is_locked' => (bool) ($data['is_locked'] ?? false),
                'is_archived' => (bool) ($data['is_archived'] ?? false),
                'updated_by' => (int) ($user->user_id ?? $this->uid()),
            ]);

            $this->syncBoardVisibility($request, $board, $visibility, $companyTargets, $userTargets);
            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            throw $e;
        }

        $this->audit(
            $request,
            'BookMarks',
            'board_updated',
            'board',
            $board->sno,
            $before,
            $board->fresh()->toArray(),
            [
                'visibility' => $visibility,
                'visibility_company_ids' => $companyTargets,
                'visibility_user_ids' => $userTargets,
            ]
        );

        return $this->ok($board->fresh(), 'Board updated successfully.');
    }

    public function deleteBoard(Request $request, int $id): JsonResponse
    {
        $board = Board::findOrFail($id);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $before = $board->toArray();
        $board->update([
            'status' => 2,
            'is_archived' => 1,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'board_archived',
            'board',
            $board->sno,
            $before,
            $board->fresh()->toArray()
        );

        return $this->ok(null, 'Board archived successfully.');
    }

    public function storeCategory(Request $request, int $boardId): JsonResponse
    {
        $board = $this->activeBoard($boardId);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'is_collapsed' => ['nullable', 'boolean'],
        ]);

        $data['board_id'] = $board->sno;
        $data['created_by'] = $this->uid();
        $data['updated_by'] = $this->uid();
        // Category position is server-owned. New categories are always appended;
        // drag/drop is the only supported way to reorder them in the UI.
        $data['sort_order'] = ((int) BoardCategory::query()->where('board_id', $board->sno)->max('sort_order') + 1);
        $data['is_collapsed'] = (bool) ($data['is_collapsed'] ?? false);

        $category = BoardCategory::create($data);

        $this->audit(
            $request,
            'BookMarks',
            'category_created',
            'bookmark_category',
            $category->sno,
            null,
            $category->toArray()
        );

        return $this->ok($category, 'Category created successfully.');
    }

    public function updateCategory(Request $request, int $id): JsonResponse
    {
        $category = BoardCategory::findOrFail($id);
        $board = $this->activeBoard($category->board_id);

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'is_collapsed' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $before = $category->toArray();
        $category->update(array_merge($data, [
            'updated_by' => $this->uid(),
            'is_collapsed' => (bool) ($data['is_collapsed'] ?? false),
        ]));

        $this->audit(
            $request,
            'BookMarks',
            'category_updated',
            'bookmark_category',
            $category->sno,
            $before,
            $category->fresh()->toArray()
        );

        return $this->ok($category->fresh(), 'Category updated successfully.');
    }

    public function reorderCategories(Request $request, int $boardId): JsonResponse
    {
        $board = $this->activeBoard($boardId);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );
        abort_unless(!$board->is_locked, 423, 'This board is locked. Unlock it before reordering categories.');

        $data = $request->validate([
            'category_ids' => ['required', 'array', 'min:1'],
            'category_ids.*' => ['integer', 'distinct', 'min:1'],
        ]);

        $ids = array_values(array_map('intval', $data['category_ids']));
        $existing = BoardCategory::query()
            ->where('board_id', $board->sno)
            ->get(['sno', 'sort_order'])
            ->keyBy('sno');

        abort_unless($existing->count() === count($ids) && !array_diff(array_keys($existing->all()), $ids), 422, 'The complete category order is required.');

        DB::transaction(function () use ($ids, $board) {
            foreach ($ids as $position => $categoryId) {
                BoardCategory::query()
                    ->where('board_id', $board->sno)
                    ->where('sno', $categoryId)
                    ->update([
                        'sort_order' => $position + 1,
                        'updated_by' => $this->uid(),
                        'updated_at' => now(),
                    ]);
            }
        });

        $this->audit(
            $request,
            'BookMarks',
            'category_reordered',
            'bookmark_category',
            $board->sno,
            ['category_ids_before' => $existing->sortBy('sort_order')->keys()->map(fn ($id) => (int) $id)->values()->all()],
            ['category_ids_after' => $ids]
        );

        return $this->ok(['category_ids' => $ids], 'Category order saved.');
    }

    public function deleteCategory(Request $request, int $id): JsonResponse
    {
        $category = BoardCategory::findOrFail($id);
        $board = $this->activeBoard($category->board_id);

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        if (Bookmark::query()->where('category_id', $category->sno)->where('status', 0)->exists()) {
            return $this->fail('Move or remove the active bookmarks in this category before deleting it.', 422);
        }

        $before = $category->toArray();
        $category->delete();

        $this->audit(
            $request,
            'BookMarks',
            'category_deleted',
            'bookmark_category',
            $id,
            $before,
            null
        );

        return $this->ok(null, 'Category deleted successfully.');
    }

    public function storeBookmark(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);

        $data = $this->validateBookmarkPayload($request);
        [$board, $category] = $this->validateBookmarkPlacement(
            (int) $data['board_id'],
            (int) $data['category_id']
        );

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs are allowed.', 422);
        }

        $duplicate = $this->findDuplicate($board->sno, $url);
        if ($duplicate) {
            return $this->fail(
                'This URL already exists on the selected board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $bookmarkName = trim((string) ($data['bookmark_name'] ?? ''));
        if ($bookmarkName === '') {
            $bookmarkName = $this->faviconService->getOfficialTitle($url)
                ?: (string) (parse_url($url, PHP_URL_HOST) ?: 'Bookmark');
        }

        $faviconUrl = $this->faviconService->getFavicon($url);
        $bookmark = Bookmark::create([
            'board_id' => $board->sno,
            'category_id' => $category->sno,
            'owner_user_id' => $this->uid(),
            'bookmark_name' => $bookmarkName,
            'url' => $url,
            'description' => $this->nullableString($data['description'] ?? null),
            'favicon_url' => $faviconUrl,
            // Manual third-party icon URLs are intentionally not persisted.
            'manual_icon' => null,
            'tags_json' => $this->normalizeTags($data['tags'] ?? []),
            'sort_order' => (int) Bookmark::query()->where('board_id', $board->sno)->where('category_id', $category->sno)->max('sort_order') + 1,
            'is_pinned' => 0,
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_created',
            'bookmark',
            $bookmark->sno,
            null,
            $bookmark->toArray(),
            ['favicon_resolved' => (bool) $faviconUrl]
        );

        return $this->ok(
            $bookmark->load(['board', 'category']),
            'Bookmark added successfully.'
        );
    }

    public function togglePin(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->with('board')->findOrFail($id);
        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id, $request),
            403
        );
        $board = $bookmark->board;
        abort_unless($board && (int) $board->status === 0 && !(bool) $board->is_archived, 404);
        abort_unless($this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request), 403);
        abort_if((bool) $board->is_locked, 403, 'Unlock this board before changing pinned links.');

        $before = $bookmark->toArray();
        $bookmark->is_pinned = !(bool) $bookmark->is_pinned;
        $bookmark->updated_by = $this->uid();
        $bookmark->save();

        $this->audit(
            $request,
            'BookMarks',
            $bookmark->is_pinned ? 'bookmark_pinned' : 'bookmark_unpinned',
            'bookmark',
            $bookmark->sno,
            $before,
            $bookmark->fresh()->toArray()
        );

        return $this->ok(
            ['bookmark_id' => (int) $bookmark->sno, 'is_pinned' => (bool) $bookmark->is_pinned],
            $bookmark->is_pinned ? 'Bookmark pinned to Top Links.' : 'Bookmark removed from Top Links.'
        );
    }

    public function reorderBookmarks(Request $request, int $categoryId): JsonResponse
    {
        $data = $request->validate([
            'bookmark_ids' => ['required', 'array', 'min:1', 'max:500'],
            'bookmark_ids.*' => ['required', 'integer', 'distinct'],
        ]);

        $category = BoardCategory::query()->findOrFail($categoryId);
        $board = Board::query()->where('status', 0)->where('is_archived', 0)->findOrFail($category->board_id);
        abort_unless($this->canReadBoard($request, $board), 403);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );
        abort_if((bool) $board->is_locked, 403, 'Unlock this board before reordering bookmarks.');

        $ids = array_values(array_map('intval', $data['bookmark_ids']));
        $existing = Bookmark::query()
            ->where('board_id', $board->sno)
            ->where('category_id', $categoryId)
            ->where('status', 0)
            ->whereIn('sno', $ids)
            ->pluck('sno')
            ->map(fn ($value) => (int) $value)
            ->all();
        abort_unless(count($existing) === count($ids), 422, 'The bookmark order contains items outside this category. Refresh and try again.');

        DB::transaction(function () use ($ids) {
            foreach ($ids as $position => $bookmarkId) {
                Bookmark::query()->where('sno', $bookmarkId)->update([
                    'sort_order' => $position + 1,
                    'updated_by' => $this->uid(),
                    'updated_at' => now(),
                ]);
            }
        });

        $this->audit($request, 'BookMarks', 'bookmarks_reordered', 'bookmark_category', $categoryId, null, null, [
            'bookmark_ids' => $ids,
        ]);

        return $this->ok(['bookmark_ids' => $ids], 'Bookmark order updated.');
    }

    public function quickAdd(Request $request): JsonResponse
    {
        $name = trim((string) $request->input('bookmark_name', ''));
        $url = trim((string) $request->input('url', ''));
        if ($url !== '') {
            $url = $this->addDefaultHttpScheme($url);
            $request->merge(['url' => $url]);
        }

        if ($name === '' && filter_var($url, FILTER_VALIDATE_URL)) {
            $name = $this->faviconService->getOfficialTitle($url)
                ?: (string) (parse_url($url, PHP_URL_HOST) ?: 'Bookmark');
        }

        $request->merge(['bookmark_name' => $name]);

        return $this->storeBookmark($request);
    }

    public function updateBookmark(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id, $request),
            403
        );

        $data = $this->validateBookmarkPayload($request);
        [$board, $category] = $this->validateBookmarkPlacement(
            (int) $data['board_id'],
            (int) $data['category_id']
        );

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs are allowed.', 422);
        }

        $duplicate = $this->findDuplicate($board->sno, $url, $bookmark->sno);
        if ($duplicate) {
            return $this->fail(
                'This URL already exists on the selected board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $before = $bookmark->toArray();
        $urlChanged = $bookmark->url !== $url;
        $legacyProxyFavicon = is_string($bookmark->favicon_url)
            && stripos($bookmark->favicon_url, 'google.com/s2/favicons') !== false;
        $legacyFallbackFavicon = is_string($bookmark->favicon_url)
            && stripos($bookmark->favicon_url, '_fallback.') !== false;
        $bookmarkName = trim((string) ($data['bookmark_name'] ?? ''));
        if ($bookmarkName === '') {
            $bookmarkName = $this->faviconService->getOfficialTitle($url)
                ?: (string) (parse_url($url, PHP_URL_HOST) ?: 'Bookmark');
        }
        $missingFavicon = !is_string($bookmark->favicon_url) || trim($bookmark->favicon_url) === '';
        $faviconUrl = ($urlChanged || $legacyProxyFavicon || $legacyFallbackFavicon || $missingFavicon)
            ? $this->faviconService->getFavicon($url, true)
            : $bookmark->favicon_url;

        $placementChanged = (int) $bookmark->board_id !== (int) $board->sno
            || (int) $bookmark->category_id !== (int) $category->sno;
        $bookmark->update([
            'board_id' => $board->sno,
            'category_id' => $category->sno,
            'sort_order' => $placementChanged
                ? ((int) Bookmark::query()->where('board_id', $board->sno)->where('category_id', $category->sno)->max('sort_order') + 1)
                : (int) $bookmark->sort_order,
            'bookmark_name' => $bookmarkName,
            'url' => $url,
            'description' => $this->nullableString($data['description'] ?? null),
            'favicon_url' => $faviconUrl,
            'manual_icon' => null,
            'tags_json' => $this->normalizeTags($data['tags'] ?? []),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_updated',
            'bookmark',
            $bookmark->sno,
            $before,
            $bookmark->fresh()->toArray(),
            ['favicon_refreshed' => $urlChanged]
        );

        return $this->ok(
            $bookmark->fresh()->load(['board', 'category']),
            'Bookmark updated successfully.'
        );
    }

    public function deleteBookmark(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id, $request),
            403
        );

        $before = $bookmark->toArray();
        $bookmark->update([
            'status' => 2,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_archived',
            'bookmark',
            $bookmark->sno,
            $before,
            $bookmark->fresh()->toArray()
        );

        return $this->ok(null, 'Bookmark removed successfully.');
    }

    public function open(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);
        $board = $bookmark->board;

        abort_unless(
            $board
                && $board->status === 0
                && !$board->is_archived
                && $this->canReadBoard($request, $board),
            403
        );

        $bookmark->increment('click_count');

        DB::table('egc_tool_bookmark_clicks')->insert([
            'bookmark_id' => $bookmark->sno,
            'user_id' => $this->uid(),
            'clicked_at' => now(),
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 1000),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_opened',
            'bookmark',
            $bookmark->sno,
            null,
            null,
            ['url' => $bookmark->url]
        );

        return $this->ok(['url' => $bookmark->url]);
    }

    public function health(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id, $request),
            403
        );

        if (!$this->faviconService->isSafePublicUrl($bookmark->url)) {
            return $this->fail('The bookmark URL is not eligible for server-side health checks.', 422);
        }

        $bookmark->update([
            'health_status' => 'checking',
            'last_checked_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $status = null;
        $health = 'broken';

        try {
            $response = Http::timeout(8)
                ->connectTimeout(4)
                ->retry(1, 150)
                ->withOptions(['allow_redirects' => false])
                ->head($bookmark->url);

            $status = $response->status();

            // Some sites reject HEAD; retry with a small GET in that case.
            if (in_array($status, [405, 501], true)) {
                $response = Http::timeout(8)
                    ->connectTimeout(4)
                    ->retry(1, 150)
                    ->withOptions(['allow_redirects' => false])
                    ->get($bookmark->url);
                $status = $response->status();
            }

            if ($response->successful() || in_array($status, [301, 302, 303, 307, 308, 401, 403, 429], true)) {
                $health = 'healthy';
            }
        } catch (\Throwable $exception) {
            report($exception);
        }

        $bookmark->update([
            'health_status' => $health,
            'last_checked_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_health_checked',
            'bookmark',
            $bookmark->sno,
            null,
            ['health_status' => $health, 'http_status' => $status]
        );

        return $this->ok([
            'health_status' => $health,
            'http_status' => $status,
        ]);
    }

    public function moveCopy(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id, $request),
            403
        );

        $data = $request->validate([
            'target_board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'target_category_id' => ['required', 'integer', 'exists:egc_tool_board_categories,sno'],
            'mode' => ['required', 'in:move,copy'],
        ]);

        $targetBoard = $this->activeBoard((int) $data['target_board_id']);
        abort_unless(
            $this->access->canManageResource('board', $targetBoard->sno, $targetBoard->owner_user_id, $request),
            403
        );

        $targetCategory = BoardCategory::query()
            ->where('sno', (int) $data['target_category_id'])
            ->where('board_id', $targetBoard->sno)
            ->first();

        if (!$targetCategory) {
            return $this->fail('The selected category does not belong to the selected board.', 422);
        }

        $duplicate = $this->findDuplicate(
            $targetBoard->sno,
            $bookmark->url,
            $data['mode'] === 'move' ? $bookmark->sno : null
        );

        if ($duplicate) {
            return $this->fail(
                'The bookmark URL already exists on the target board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $before = $bookmark->toArray();

        if ($data['mode'] === 'move') {
            $bookmark->update([
                'board_id' => $targetBoard->sno,
                'category_id' => $targetCategory->sno,
                'updated_by' => $this->uid(),
            ]);
            $result = $bookmark->fresh();
        } else {
            $result = $bookmark->replicate();
            $result->board_id = $targetBoard->sno;
            $result->category_id = $targetCategory->sno;
            $result->owner_user_id = $this->uid();
            $result->created_by = $this->uid();
            $result->updated_by = $this->uid();
            $result->click_count = 0;
            $result->status = 0;
            $result->deleted_at = null;
            $result->save();
        }

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_' . $data['mode'] . 'd',
            'bookmark',
            $result->sno,
            $before,
            $result->fresh()->toArray(),
            ['target_board_id' => $targetBoard->sno, 'target_category_id' => $targetCategory->sno]
        );

        return $this->ok($result->fresh()->load(['board', 'category']), 'Bookmark ' . $data['mode'] . 'd successfully.');
    }

    public function importPreview(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);

        $data = $request->validate([
            'board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'file' => ['required', 'file', 'max:10240', 'mimes:html,htm'],
        ]);

        $board = $this->activeBoard((int) $data['board_id']);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $links = $this->parseBookmarkHtml((string) file_get_contents($request->file('file')->getRealPath()));
        $folders = [];

        foreach ($links as $link) {
            $folder = $link['folder'] ?: 'Unsorted';
            if (!isset($folders[$folder])) {
                $folders[$folder] = ['folder' => $folder, 'count' => 0, 'sample' => []];
            }
            $folders[$folder]['count']++;
            if (count($folders[$folder]['sample']) < 3) {
                $folders[$folder]['sample'][] = ['name' => $link['name'], 'url' => $link['url']];
            }
        }

        return $this->ok([
            'board_id' => $board->sno,
            'total' => count($links),
            'folders' => array_values($folders),
            'categories' => BoardCategory::query()
                ->where('board_id', $board->sno)
                ->orderBy('sort_order')
                ->orderBy('category_name')
                ->get(['sno', 'category_name', 'color', 'sort_order']),
        ]);
    }

    public function importHtml(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);

        $data = $request->validate([
            'board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'file' => ['required', 'file', 'max:10240', 'mimes:html,htm'],
            'mapping' => ['nullable', 'json'],
        ]);

        $board = $this->activeBoard((int) $data['board_id']);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $this->boardCreatorId($board), $request),
            403
        );

        $links = $this->parseBookmarkHtml((string) file_get_contents($request->file('file')->getRealPath()));
        $mapping = json_decode((string) ($data['mapping'] ?? '{}'), true) ?: [];

        $existingCategories = BoardCategory::query()->where('board_id', $board->sno)->get()->keyBy('sno');
        $categoryMap = [];
        $newCategories = 0;

        foreach ($mapping as $folder => $target) {
            $folder = trim((string) $folder);
            $target = trim((string) $target);
            if ($folder === '' || $target === '') continue;

            if (str_starts_with($target, 'new:')) {
                $name = trim(substr($target, 4));
                if ($name === '') continue;

                $created = BoardCategory::create([
                    'board_id' => $board->sno,
                    'category_name' => mb_substr($name, 0, 160),
                    'color' => '#4A3E8E',
                    'sort_order' => (int) BoardCategory::where('board_id', $board->sno)->max('sort_order') + 1,
                    'is_collapsed' => false,
                    'created_by' => $this->uid(),
                    'updated_by' => $this->uid(),
                ]);
                $categoryMap[$folder] = $created->sno;
                $newCategories++;
                continue;
            }

            $categoryId = (int) $target;
            if ($existingCategories->has($categoryId)) {
                $categoryMap[$folder] = $categoryId;
            }
        }

        $fallback = $existingCategories->first();
        if (!$fallback && $links) {
            $fallback = BoardCategory::create([
                'board_id' => $board->sno,
                'category_name' => 'Imported',
                'color' => '#4A3E8E',
                'sort_order' => 0,
                'is_collapsed' => false,
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);
            $newCategories++;
        }

        $imported = $duplicates = $skipped = $faviconResolved = 0;

        foreach ($links as $link) {
            $categoryId = $categoryMap[$link['folder']] ?? $fallback?->sno;
            if (!$categoryId) { $skipped++; continue; }

            if ($this->findDuplicate($board->sno, $link['url'])) {
                $duplicates++;
                continue;
            }

            // Bulk imports stay fast: favicons are resolved lazily by the
            // ERP favicon endpoint when a bookmark is rendered.
            $faviconUrl = null;

            Bookmark::create([
                'board_id' => $board->sno,
                'category_id' => $categoryId,
                'owner_user_id' => $this->uid(),
                'bookmark_name' => mb_substr($link['name'], 0, 180),
                'url' => $link['url'],
                'description' => null,
                'favicon_url' => $faviconUrl,
                'manual_icon' => null,
                'tags_json' => [],
                'click_count' => 0,
                'sort_order' => (int) Bookmark::query()->where('board_id', $board->sno)->where('category_id', $categoryId)->max('sort_order') + 1,
                'health_status' => 'unknown',
                'status' => 0,
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);

            $imported++;
        }

        $result = compact('imported', 'duplicates', 'skipped', 'newCategories', 'faviconResolved');
        $result['total'] = count($links);

        $this->audit($request, 'BookMarks', 'bookmark_import_html', 'board', $board->sno, null, $result);

        return $this->ok($result, 'Browser bookmark import completed.');
    }

    private function parseBookmarkHtml(string $html): array
    {
        if ($html === '' || strlen($html) > 10 * 1024 * 1024 || !class_exists(\DOMDocument::class)) {
            return [];
        }

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        @$dom->loadHTML($html, LIBXML_NOWARNING | LIBXML_NOERROR);

        $links = [];
        $seen = [];

        $walk = function (\DOMNode $node, array $folders = []) use (&$walk, &$links, &$seen) {
            foreach ($node->childNodes as $child) {
                if ($child->nodeType !== XML_ELEMENT_NODE) continue;

                $tag = strtoupper($child->nodeName);
                if ($tag === 'H3') {
                    $name = trim((string) $child->textContent);
                    $next = $folders;
                    if ($name !== '') $next[] = mb_substr($name, 0, 120);
                    $walk($child, $next);
                    continue;
                }

                if ($tag === 'A') {
                    $url = trim((string) $child->getAttribute('href'));
                    if (filter_var($url, FILTER_VALIDATE_URL)) {
                        $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
                        if (in_array($scheme, ['http', 'https'], true)) {
                            $normalized = $this->normalizeUrl($url);
                            if ($normalized && !isset($seen[$normalized])) {
                                $seen[$normalized] = true;
                                $links[] = [
                                    'name' => trim((string) $child->textContent) ?: ((string) parse_url($normalized, PHP_URL_HOST) ?: 'Bookmark'),
                                    'url' => $normalized,
                                    'folder' => $folders ? implode(' / ', $folders) : 'Unsorted',
                                ];
                            }
                        }
                    }
                    if (count($links) >= 500) return;
                    continue;
                }

                $walk($child, $folders);
                if (count($links) >= 500) return;
            }
        };

        if ($dom->documentElement) $walk($dom->documentElement, []);
        libxml_clear_errors();
        return array_slice($links, 0, 500);
    }

    private function validateBookmarkPayload(Request $request): array
    {
        $inputUrl = trim((string) $request->input('url', ''));
        if ($inputUrl !== '') {
            $request->merge(['url' => $this->addDefaultHttpScheme($inputUrl)]);
        }

        return $request->validate([
            'board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'category_id' => ['required', 'integer', 'exists:egc_tool_board_categories,sno'],
            'bookmark_name' => ['nullable', 'string', 'max:180'],
            'url' => ['required', 'url', 'max:2000'],
            'description' => ['nullable', 'string', 'max:5000'],
            'favicon_url' => ['nullable', 'url', 'max:1000'],
            'manual_icon' => ['nullable', 'string', 'max:500'],
            'tags' => ['nullable'],
        ]);
    }

    private function validateBookmarkPlacement(int $boardId, int $categoryId): array
    {
        $board = $this->activeBoard($boardId);
        $category = BoardCategory::query()
            ->where('sno', $categoryId)
            ->where('board_id', $boardId)
            ->first();

        if (!$category) {
            abort(422, 'The selected category does not belong to the selected board.');
        }

        return [$board, $category];
    }

    private function authUser(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 401, 'Authentication is required for BookMarks.');
        return $user;
    }

    private function mainCompanyName(): string
    {
        $title = trim((string) GeneralSettingsModel::query()->value('title'));
        return $title !== '' ? $title : 'Main Company';
    }

    private function companyExists(int $companyId): bool
    {
        if ($companyId === 0) {
            return $this->mainCompanyName() !== 'Main Company'
                || GeneralSettingsModel::query()->exists();
        }

        return $companyId > 0 && DB::table('egc_company')
            ->where('sno', $companyId)
            ->where('status', 0)
            ->exists();
    }

    private function companyDetails(int $companyId): array
    {
        if ($companyId === 0) {
            $name = $this->mainCompanyName();
            return [
                'company_name' => $name,
                'company_short_name' => $name,
                'company_base_color' => null,
            ];
        }

        $row = DB::table('egc_company')
            ->where('sno', $companyId)
            ->first(['company_name', 'company_short_name', 'company_base_color']);

        return [
            'company_name' => $row?->company_name,
            'company_short_name' => $row?->company_short_name ?: $row?->company_name,
            'company_base_color' => $row?->company_base_color,
        ];
    }

    private function boardCreatorId($board)
    {
        
        return (int) ($board->created_by ?: $board->owner_user_id ?: 0);
    }

    private function normalizeVisibilityIds($value): array
    {
        if (!is_array($value)) {
            return $this->ids($value);
        }

        return array_values(array_unique(array_filter(
            array_map('intval', $value),
            fn ($id) => $id >= 0
        )));
    }

    private function validateVisibilityTargets(string $visibility, array $companyIds, array $userIds): void
    {
        if ($visibility === 'Private') {
            return;
        }

        if ($visibility === 'Company') {
            if (!$companyIds) {
                abort(422, 'Select at least one company for Company visibility.');
            }

            $valid = 0;
            foreach ($companyIds as $companyId) {
                if ($this->companyExists((int) $companyId)) {
                    $valid++;
                }
            }

            abort_unless(
                $valid === count($companyIds),
                422,
                'One or more selected companies are not active.'
            );
            return;
        }

        if ($visibility === 'Group') {
            if (!$userIds) {
                abort(422, 'Select at least one staff member for Group visibility.');
            }

            $valid = DB::table('egc_staff')
                ->whereIn('sno', $userIds)
                ->where('status', '!=', 2)
                ->count();

            abort_unless(
                (int) $valid === count($userIds),
                422,
                'One or more selected staff members are not active.'
            );
        }
    }

    /**
     * Board-specific read scope. This intentionally does not call the shared
     * ProductivityAccessService visibility shortcut because BookMarks supports
     * multiple explicit Company and Group targets.
     */
    private function applyBookmarkBoardReadScope($query, Request $request, string $alias = 'egc_tool_boards')
    {
        $user = $this->authUser($request);
        $uid = (int) ($user->user_id ?? 0);
        $companyId = $user->company_id !== null && $user->company_id !== ''
            ? (int) $user->company_id
            : null;
        $uid = $this->access->userId($request);
        $companyId = $this->access->companyId($request);
        $roleName = $this->access->role($request);

        if ($this->access->isGroupAdmin($request) || $this->access->isAuditor($request)) {
            // Admin/auditor access still respects an explicitly selected
            // company filter supplied by the BookMarks page.
            return;
        }
     

        $prefix = $alias ? $alias . '.' : '';
        $boardTable = $alias ?: 'egc_tool_boards';

        $query->where(function ($scope) use ($uid, $companyId, $roleName, $prefix, $boardTable) {
            // The creator always retains access to their own board.
            $scope->where($prefix . 'created_by', $uid)
                ->orWhere($prefix . 'owner_user_id', $uid);

            // Explicit Share feature grants remain valid for BookMarks.
            $scope->orWhereExists(function ($share) use ($uid, $companyId, $roleName, $prefix, $boardTable) {
                $share->selectRaw('1')
                    ->from('egc_tool_share_grants as sg')
                    ->where('sg.resource_type', 'board')
                    ->whereColumn('sg.resource_id', $prefix . 'sno')
                    ->where('sg.status', 'active')
                    ->where(function ($g) use ($uid, $companyId, $roleName) {
                        $g->where(function ($x) use ($uid) {
                            $x->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid);
                        })
                        ->orWhere(function ($x) use ($roleName) {
                            $x->where('sg.grantee_type', 'role')->where('sg.grantee_id', $roleName);
                        })
                        ->orWhere(function ($x) {
                            $x->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0');
                        });

                        if ($companyId !== null) {
                            $g->orWhere(function ($x) use ($companyId) {
                                $x->where('sg.grantee_type', 'company')
                                    ->where('sg.grantee_id', (string) $companyId);
                            });
                        }
                    })
                    ->where(function ($expiry) {
                        $expiry->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now());
                    });
            });

            if ($companyId !== null) {
                // New Company visibility is represented by BookMarks-owned
                // active visibility grants. Older Company boards without such
                // grants continue to work through board.company_id.
                $scope->orWhere(function ($company) use ($companyId, $prefix) {
                    $company->where($prefix . 'visibility', 'Company')
                        ->where(function ($target) use ($companyId, $prefix) {
                            $target->whereExists(function ($grant) use ($companyId, $prefix) {
                                $grant->selectRaw('1')
                                    ->from('egc_tool_share_grants as vg')
                                    ->where('vg.resource_type', 'board')
                                    ->whereColumn('vg.resource_id', $prefix . 'sno')
                                    ->where('vg.grantee_type', 'company')
                                    ->where('vg.grantee_id', (string) $companyId)
                                    ->where('vg.status', 'active')
                                    ->where('vg.metadata_json', 'like', '%"source":"bookmarks_visibility"%');
                            });
                            $target->orWhere(function ($legacy) use ($companyId, $prefix) {
                                $legacy->where($prefix . 'company_id', $companyId)
                                    ->whereNotExists(function ($grant) use ($prefix) {
                                        $grant->selectRaw('1')
                                            ->from('egc_tool_share_grants as vg2')
                                            ->where('vg2.resource_type', 'board')
                                            ->whereColumn('vg2.resource_id', $prefix . 'sno')
                                            ->where('vg2.metadata_json', 'like', '%"source":"bookmarks_visibility"%');
                                    });
                            });
                        });
                });
            }

            // Group boards created before multi-select visibility existed remain
            // group-wide only when they have no BookMarks visibility targets.
            $scope->orWhere(function ($group) use ($uid, $prefix) {
                $group->where($prefix . 'visibility', 'Group')
                    ->where(function ($target) use ($uid, $prefix) {
                        $target->whereExists(function ($grant) use ($uid, $prefix) {
                            $grant->selectRaw('1')
                                ->from('egc_tool_share_grants as gv')
                                ->where('gv.resource_type', 'board')
                                ->whereColumn('gv.resource_id', $prefix . 'sno')
                                ->where('gv.grantee_type', 'user')
                                ->where('gv.grantee_id', (string) $uid)
                                ->where('gv.status', 'active')
                                ->where('gv.metadata_json', 'like', '%"source":"bookmarks_visibility"%');
                        })
                        ->orWhereNotExists(function ($grant) use ($prefix) {
                            $grant->selectRaw('1')
                                ->from('egc_tool_share_grants as vg3')
                                ->where('vg3.resource_type', 'board')
                                ->whereColumn('vg3.resource_id', $prefix . 'sno')
                                ->where('vg3.metadata_json', 'like', '%"source":"bookmarks_visibility"%');
                        });
                    });
            });
        });
            
    }

    private function canReadBoard(Request $request, Board $board): bool
    {
        $query = Board::query()->where('sno', $board->sno);
        $this->applyBookmarkBoardReadScope($query, $request);
        return $query->exists();
    }

    private function visibilityGrantIds(int $boardId, string $type): array
    {
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', 'board')
            ->where('resource_id', $boardId)
            ->where('grantee_type', $type)
            ->where('metadata_json', 'like', '%"source":"bookmarks_visibility"%')
            ->whereIn('status', ['active', 'pending'])
            ->pluck('grantee_id')
            ->map(fn ($id) => (int) $id)
            ->values()
            ->all();
    }

    private function syncBoardVisibility(Request $request, Board $board, string $visibility, array $companyIds, array $userIds): void
    {
        $actorId = (int) ($this->authUser($request)->user_id ?? $this->uid());

        // Remove only BookMarks-managed visibility rows. Explicit Share-modal
        // grants remain untouched.
        $oldVisibility = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'board')
            ->where('resource_id', $board->sno)
            ->where('metadata_json', 'like', '%"source":"bookmarks_visibility"%')
            ->get(['sno', 'grantee_type', 'grantee_id']);

        if ($oldVisibility->isNotEmpty()) {
            DB::table('egc_tool_share_grants')
                ->whereIn('sno', $oldVisibility->pluck('sno')->all())
                ->delete();
        }

        $targets = [];
        if ($visibility === 'Company') {
            foreach ($companyIds as $companyId) {
                $targets[] = ['type' => 'company', 'id' => (string) $companyId];
            }
        } elseif ($visibility === 'Group') {
            foreach ($userIds as $userId) {
                $targets[] = ['type' => 'user', 'id' => (string) $userId];
            }
        }

        foreach ($targets as $target) {
            $alreadyExplicitlyShared = DB::table('egc_tool_share_grants')
                ->where('resource_type', 'board')
                ->where('resource_id', $board->sno)
                ->where('grantee_type', $target['type'])
                ->where('grantee_id', $target['id'])
                ->where('status', 'active')
                ->exists();

            if ($alreadyExplicitlyShared) {
                continue;
            }

            DB::table('egc_tool_share_grants')->insert([
                'resource_type' => 'board',
                'resource_id' => $board->sno,
                'owner_user_id' => $actorId,
                'grantee_type' => $target['type'],
                'grantee_id' => $target['id'],
                'permission' => 'View',
                'status' => 'active',
                'expires_at' => null,
                'requested_by' => $actorId,
                'approved_by' => $actorId,
                'approval_required' => 0,
                'approved_at' => now(),
                'metadata_json' => json_encode([
                    'source' => 'bookmarks_visibility',
                    'visibility' => $visibility,
                ], JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    private function activeBoard(int $id): Board
    {
        return Board::query()
            ->where('status', 0)
            ->where('is_archived', 0)
            ->findOrFail($id);
    }

    private function findDuplicate(int $boardId, string $url, ?int $exceptId = null): ?Bookmark
    {
        $query = Bookmark::query()
            ->where('board_id', $boardId)
            ->where('status', 0)
            ->where('url', $url);

        if ($exceptId) {
            $query->where('sno', '<>', $exceptId);
        }

        return $query->first();
    }

    /**
     * Accept domain-style input from users while preserving explicit schemes.
     * Examples: instagram.com -> https://instagram.com, //instagram.com -> https://instagram.com.
     */
    private function addDefaultHttpScheme(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        if (str_starts_with($url, '//')) {
            return 'https:' . $url;
        }

        if (preg_match('/^[a-z][a-z0-9+.-]*:/i', $url)) {
            return $url;
        }

        return 'https://' . $url;
    }

    private function normalizeUrl(string $url): ?string
    {
        $url = $this->addDefaultHttpScheme($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = $parts['host'] ?? '';

        if (!in_array($scheme, ['http', 'https'], true) || !$host) {
            return null;
        }

        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $path = $parts['path'] ?? '/';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';

        return $scheme . '://' . $host . $port . $path . $query;
    }

    private function normalizeTags($tags): array
    {
        if (is_string($tags)) {
            $tags = preg_split('/[,\n]+/', $tags) ?: [];
        }

        if (!is_array($tags)) {
            return [];
        }

        $normalized = [];
        foreach ($tags as $tag) {
            $tag = trim((string) $tag);
            if ($tag !== '') {
                $normalized[] = mb_substr($tag, 0, 50);
            }
        }

        return array_values(array_unique(array_slice($normalized, 0, 30)));
    }

    private function hydrateLegacyFavicons($collection): void
    {
        foreach ($collection as $bookmark) {
            $faviconUrl = trim((string) ($bookmark->favicon_url ?? ''));

            // Legacy Google S2 proxy icons are not official ERP-owned favicon
            // assets. Keep them null instead of returning a third-party URL.
            if ($faviconUrl !== '' && (
                stripos($faviconUrl, 'google.com/s2/favicons') !== false
                || stripos($faviconUrl, '_fallback.') !== false
            )) {
                // Never send a generated/third-party favicon to the browser.
                // The frontend will request a fresh official favicon instead.
                $bookmark->setAttribute('favicon_url', null);
                continue;
            }

            if ($faviconUrl === '') {
                continue;
            }

            $path = (string) parse_url($faviconUrl, PHP_URL_PATH);
            $filename = basename($path);

            // Normalize old ERP /favicon URLs and new /storage URLs to the
            // currently available public-serving path. Missing cache files are
            // represented as null so the UI can use its neutral bookmark icon.
            if (preg_match('/^bookmark_[a-f0-9]{40}\.(ico|png|jpg|jpeg|webp|svg|gif|bmp)$/i', $filename)) {
                $resolved = $this->faviconService->getCachedFaviconUrl($filename);
                $bookmark->setAttribute('favicon_url', $resolved);
            }
        }
    }

    private function initials(?string $name): string
    {
        $name = trim((string) $name);
        if ($name === '') return 'SN';

        $parts = preg_split('/\s+/', $name) ?: [];
        if (count($parts) === 1) return strtoupper(mb_substr($parts[0], 0, 2));
        return strtoupper(mb_substr($parts[0], 0, 1) . mb_substr(end($parts), 0, 1));
    }

    private function nullableString($value): ?string
    {
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}