<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\SourceModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use thiagoalessio\TesseractOCR\TesseractOCR;
use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser;
use Smalot\PdfParser\Parser as PdfParser;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Services\GoogleDriveService;

use App\Services\Recruitment\ResumeAutomation\ResumeTextExtractionService;
use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\CandidateMobileService;
use App\Services\Recruitment\ResumeAutomation\CandidateEmailService;
use App\Services\Recruitment\ResumeAutomation\CandidateJobRoleMatchingService;
use App\Services\Recruitment\ResumeAutomation\CandidateQualificationMajorService;
use App\Services\Recruitment\ResumeAutomation\CandidateExperienceService;



class ManageCandidate extends Controller
{

    protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
        date_default_timezone_set('Asia/Kolkata');
    }

    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $major_filt = $request->major_filt ?? '';
        $source_name_filt = $request->source_name_filt ?? '';
        $qualification_filt = $request->qualification_filt ?? '';
        $closing_date_filt = $request->closing_date_filt ?? '';
        $exp_type_filt = $request->exp_type_filt ?? '';
        $source_type_filt = $request->source_type_filt ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->from_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_dt_iss_rpt ?? '';
        $old_resume_fill = $request->old_resume_fill ?? '';
        $vip_check = $request->vip_check ?? '';
        $walkin_check = $request->walkin_check ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';

        $resume_keywords_filt = $request->input('resume_keywords_filt', []);

        $applicant_status_filt = $request->applicant_status_filt ?? '';

        

        if (is_string($resume_keywords_filt)) {
            $resume_keywords_filt = json_decode($resume_keywords_filt, true);
        }

        if (!is_array($resume_keywords_filt)) {
            $resume_keywords_filt = [];
        }

        $resume_keywords_filt = collect($resume_keywords_filt)
            ->map(function ($keyword) {
                return trim((string) $keyword);
            })
            ->filter()
            ->unique()
            ->values()
            ->all();



        $jobRequest = ApplicantModel::where('egc_applicant.status', '!=', 2)
            ->leftJoin('egc_job_request', 'egc_applicant.job_request_id', 'egc_job_request.sno')
            ->leftJoin('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_source', 'egc_applicant.source_id', 'egc_source.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->leftJoin('egc_major', 'egc_applicant.major', 'egc_major.sno')
            ->leftJoin('egc_job_fair', 'egc_applicant.job_fair_id', 'egc_job_fair.sno')
            ->leftJoin('egc_applicant_history_logs', 'egc_applicant.candidate_id', 'egc_applicant_history_logs.candidate_id')
            ->distinct('egc_applicant.sno')
            ->select(
                'egc_applicant.*',
                'egc_job_request.status as job_request_status',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_company.company_name',
                'egc_major.major_name',
                'egc_job_fair.job_fair_name',
                'egc_source.source_name as applicant_source_name',
                'egc_company.company_base_color',
            );
        if ($search_filter != '') {
            $jobRequest->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.applicant_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.old_data', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.resume_text', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.description', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant.email', 'LIKE', "%{$search_filter}%");
            });
        }

        if (!empty($resume_keywords_filt)) {
            foreach ($resume_keywords_filt as $keyword) {
                $jobRequest->where(
                    'egc_applicant.resume_text',
                    'LIKE',
                    '%' . $keyword . '%'
                );
            }
        }

        switch ($dashboard_filter) {
            case 'today':
                $jobRequest->whereDate(
                    'egc_applicant.created_at',
                    now()->toDateString()
                );
                break;

            case 'month':
                $jobRequest->whereMonth(
                    'egc_applicant.created_at',
                    now()->month
                )->whereYear(
                    'egc_applicant.created_at',
                    now()->year
                );
                break;

            case 'fresher':
                $jobRequest->where(
                    'egc_applicant.experience_id',
                    1
                );
                break;

            case 'experienced':
                $jobRequest->where(
                    'egc_applicant.experience_id',
                    2
                );
                break;

            case 'jobfair':
                $jobRequest->where(
                    'egc_applicant.job_fair_id',
                    '>',
                    0
                );
                break;

            case 'walkin':
                $jobRequest->where(
                    'egc_applicant.source_id',
                    6
                );
                break;

            case 'vip':
                $jobRequest->where(
                    'egc_applicant.vip_check',
                    1
                );
                break;
            case 'career':
                $jobRequest->where(
                    'egc_applicant.career_portal',
                    1
                );
                break;
        }

        if ($source_type_filt !== '') {
            if ($source_type_filt == 'resource') {
                $jobRequest->where('egc_applicant.job_request_id', '>', 0);
            } elseif ($source_type_filt == 'old_data') {
                $jobRequest->where('egc_applicant.recruitment_id', '>', 0);
            } elseif ($source_type_filt == 'job_fair') {
                $jobRequest->where('egc_applicant.job_fair_id', '>', 0);
            }
        }

        if ($source_name_filt) {
            $jobRequest->where('egc_applicant.source_id', $source_name_filt);
        }

        if ($vip_check) {
            $jobRequest->where('egc_applicant.vip_check', 1);
        }

        if ($walkin_check) {
            $jobRequest->where('egc_applicant.source_id', 6);
        }


        if (!empty($exp_type_filt)) {
            $jobRequest->where(function ($query) use ($exp_type_filt) {
                $query->where(function ($q) use ($exp_type_filt) {
                    $q->where('egc_applicant.recruitment_id', 0)
                        ->where('egc_applicant.experience_id', $exp_type_filt);
                });
                $query->orWhere(function ($q) use ($exp_type_filt) {
                    $q->where('egc_applicant.recruitment_id', '>', 0);

                    if ($exp_type_filt == 1) {
                        // Fresher
                        $q->where('egc_applicant.experience_id', 2);
                    } elseif ($exp_type_filt == 2) {
                        // Experience
                        $q->where('egc_applicant.experience_id', '>=', 3);
                    }
                });
            });
        }
        if (!empty($qualification_filt)) {

            $jobRequest->where(function ($query) use ($qualification_filt) {

                $query->where(function ($q) use ($qualification_filt) {
                    $q->where('egc_applicant.recruitment_id', 0)
                        ->where('egc_applicant.qualification_id', $qualification_filt);
                });


                $query->orWhere(function ($q) use ($qualification_filt) {

                    $q->where('egc_applicant.recruitment_id', '>', 0);

                    if ($qualification_filt == 1) {
                        // UG → old_data qualification_id = 5
                        $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 5");
                    } elseif ($qualification_filt == 2) {
                        // PG → 3,4
                        $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (3,4)");
                    } elseif ($qualification_filt == 3) {
                        // Doctorate → 2
                        $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 2");
                    } elseif ($qualification_filt == 'Others' || $qualification_filt == '4' || $qualification_filt == '5' || $qualification_filt == '6') {
                        // Others → 6,7
                        $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (6,7)");
                    }
                });
            });
        }

        if ($major_filt) {
            $jobRequest->where('egc_applicant.major', $major_filt);
        }
        
        if ($applicant_status_filt !='') {
            $jobRequest->where('egc_applicant_history_logs.applicant_status', $applicant_status_filt);
        }

        if ($old_resume_fill !== '') {
            $jobRequest->where('egc_applicant.recruitment_id', '>', 0)->where('egc_applicant.recruitment_file', $old_resume_fill);
        }

        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('egc_applicant.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('egc_applicant.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('egc_applicant.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $jobRequest->whereBetween('egc_applicant.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $jobRequest->where('egc_applicant.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $jobRequest->where('egc_applicant.created_at', '<=', $toDate);
            }
        } else {
            if ($closing_date_filt) {
                $jobRequest->whereDate('egc_applicant.created_at', date('Y-m-d', strtotime($closing_date_filt)));
            }
        }



        $jobRequest = $jobRequest->orderBy('egc_applicant.created_at', 'desc')
            ->paginate($perpage);

        $aiRoleIds = $jobRequest
            ->pluck('job_role_id')
            ->filter()
            ->map(function ($id) {

                $decoded = json_decode($id, true);

                return is_array($decoded) ? $decoded : [];

            })
            ->flatten()
            ->unique()
            ->values()
            ->toArray();

        $aiRoleNames = DB::table('egc_recruitment_roles')
            ->whereIn('sno', $aiRoleIds)
            ->pluck('role_name', 'sno')
            ->toArray();



        $today_candidates = ApplicantModel::whereDate('egc_applicant.created_at', date('Y-m-d'))->where('egc_applicant.status', '!=', 2)->count();
        $month_candidates = ApplicantModel::whereBetween('egc_applicant.created_at', [date('Y-m-01'), date('Y-m-t')])->where('egc_applicant.status', '!=', 2)->count();
        $fresher_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where(function ($query) {
            $query->where(function ($q) {
                $q->where('egc_applicant.recruitment_id', 0)
                    ->where('egc_applicant.experience_id', 1);
            });
            $query->orWhere(function ($q) {
                $q->where('egc_applicant.recruitment_id', '>', 0)
                    ->where('egc_applicant.experience_id', 2);
            });
        })->count();
        $experience_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where(function ($query) {
            $query->where(function ($q) {
                $q->where('egc_applicant.recruitment_id', 0)
                    ->where('egc_applicant.experience_id', 2);
            });
            $query->orWhere(function ($q) {
                $q->where('egc_applicant.recruitment_id', '>', 0)
                    ->where('egc_applicant.experience_id', '>=', 3);
            });
        })->count();
        $job_fair_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.job_fair_id', '>', 0)->count();
        $walkin_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.source_id', 6)->count();
        $vip_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.vip_check', 1)->count();
        $career_candidates = ApplicantModel::where('egc_applicant.status', '!=', 2)->where('egc_applicant.career_portal', 1)->count();

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $jobRequest->map(function ($item) use ($helper, $aiRoleNames) {

                $roleIds = json_decode(
                    $item->job_role_id,
                    true
                );


                if(is_array($roleIds)) {

                    $item->display_job_role_name = collect($roleIds)
                        ->map(function($id) use ($aiRoleNames){

                            return $aiRoleNames[$id] ?? null;

                        })
                        ->filter()
                        ->implode(', ');

                } else {

                    $item->display_job_role_name =
                        $item->job_role_name;

                }


                return [
                    'sno' => $item->sno,
                    'vip_check' => $item->vip_check,
                    'status' => $item->status,
                    'data' => $item,
                    'old_data' => $item->old_data,
                    'drive_data' => $item->drive_data,
                    
                    'resume_view_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/open?disposition=inline'),
                    'resume_download_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/open?disposition=attachment'),
                    'resume_urls_url' => url('/hr-recruiter/applicants/' . (int) $item->sno . '/resume/urls'),

                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    'short_encrypt_id' => base64_encode($item->sno),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $jobRequest->currentPage(),
                'last_page' => $jobRequest->lastPage(),
                'total' => $jobRequest->total(),
                'today_candidates' => $today_candidates,
                'month_candidates' => $month_candidates,
                'fresher_candidates' => $fresher_candidates,
                'experience_candidates' => $experience_candidates,
                'job_fair_candidates' => $job_fair_candidates,
                'walkin_candidates' => $walkin_candidates,
                'vip_candidates' => $vip_candidates,
            ]);
        }
        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = DB::table('egc_company')->where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list = DB::table('egc_entity')->where('status', 0)->orderBy('sno', 'ASC')->get();
        $recruitment_roles = DB::table('egc_recruitment_roles')
            ->where('status', 0)
            ->orderBy('role_name', 'ASC')
            ->get(['sno', 'role_name']);

        return view('content.hr_management.hr_recruiter.manage_candidate.candidate_list', [
            'jobRequest' => $jobRequest,
            'source_list' => $source_list,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'company_list' => $company_list,
            'entity_list' => $entity_list,
            'recruitment_roles' => $recruitment_roles,
        ]);
    }


    


    private function parseWithAI($text)
    {


        try {
            $primaryApiKey = $this->HuggingFaceCretential();
            $prompt = "
                Extract ONLY valid JSON. No explanation.

                STRICT RULES:
                    1. Return ONLY valid JSON. No explanation, no extra text.
                    2. NEVER infer or guess ANY field unless explicitly present in resume text.
                    3. NAME RULE (VERY IMPORTANT):
                    - Extract candidate name ONLY from the top section of the resume.
                    - DO NOT infer name from email address.
                    - DO NOT convert email username into a name.
                    - If name is written in ALL CAPS (e.g., AKMAX), return it EXACTLY as is.
                    - If no clear name is found, return empty string ''.

                    4. GENDER RULE:
                    - Infer gender ONLY from name if clearly identifiable.
                    - Otherwise return ''.

                    5. DEGREE RULE:
                    - Extract FULL degree with specialization.
                    - Example: MBA Human Resources, B.Tech Computer Science
                    - If degree is in short form (BE, B.Tech, MBA), expand it if possible.
                    - If expansion is unclear, return original text exactly as found.
                    Examples:
                        BE (EEE) → Bachelor of Engineering in Electrical and Electronics Engineering
                        B.Tech CSE → Bachelor of Technology in Computer Science Engineering
                        MBA HR → Master of Business Administration in Human Resources

                    6. STRICT DATA EXTRACTION:
                    - Extract ONLY what exists in text.
                    - DO NOT assume missing values.
                7. OUTPUT FORMAT:
                {
                \"name\": \"\",
                \"email\": \"\",
                \"phone\": \"\",
                \"gender\": \"\",
                \"qualification\": \"\",
                \"degree\": \"\",
                \"degree_full\": \"\",
                \"experience_years\": \"\",
                \"marital_status\": \"\"
                }

                Resume:
                " . substr($text, 0, 4000); // limit tokens

            $response = Http::timeout(45)
                ->withHeaders([
                    'Authorization' => 'Bearer ' . $primaryApiKey,
                    'Content-Type' => 'application/json'
                ])
                ->post('https://router.huggingface.co/v1/chat/completions', [
                    'model' => "meta-llama/Llama-3.1-8B-Instruct:novita",
                    'messages' => [['role' => 'user', 'content' => $prompt]],
                    'stream' =>  false
                ]);


            if ($response->failed()) {
                return null;
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('AI Error: ' . $e->getMessage());
            return null;
        }
    }
    private function mapAIResponse($aiResponse)
    {
        $default = [
            'candidate_name' => null,
            'candidate_email' => null,
            'candidate_mobile' => null,
            'candidate_gender' => null,
            'candidate_exper_count' => null,
            'candidate_marital_status' => null,
        ];

        if (!$aiResponse || !isset($aiResponse['choices'][0]['message']['content'])) {
            return $default;
        }

        // 🔥 Get content
        $generated = $aiResponse['choices'][0]['message']['content'];

        // 🔥 Clean it
        $generated = trim($generated);
        $generated = str_replace(["\r", "\n"], '', $generated);

        // 🔥 Decode directly (NO REGEX)
        // $json = json_decode($generated, true);
        $generated = preg_replace('/```json|```/', '', $generated);
        $generated = trim($generated);
        $json = json_decode($generated, true);

        if (!$json) {
            \Log::error('AI JSON decode failed: ' . $generated);
            return $default;
        }

        return [
            'candidate_name' => $json['name'] ?? null,
            'candidate_email' => $json['email'] ?? null,
            'candidate_mobile' => $json['phone'] ?? null,
            'candidate_gender' => $this->mapGender($json['gender'] ?? ''),
            'candidate_exper_count' => (int)($json['experience_years'] ?? 0),
            'candidate_marital_status' => $this->mapMarital($json['marital_status'] ?? ''),
            'degree_full' => $json['degree_full'] ?? null,
        ];
    }
    private function rankDegree($degree)
    {
        $degree = strtoupper($degree);

        if (str_contains($degree, 'PHD')) return 5;
        if (str_contains($degree, 'MASTER') || str_contains($degree, 'MBA')) return 4;
        if (str_contains($degree, 'BACHELOR') || str_contains($degree, 'BCOM')) return 3;
        if (str_contains($degree, 'DIPLOMA')) return 2;

        return 1;
    }
    private function findClosestMajor($text, $majors)
    {
        $bestMatch = null;
        $bestScore = 0;

        foreach ($majors as $major) {

            if (!$major->major_name) continue;

            $dbMajor = $this->normalizeText($major->major_name);

            similar_text($text, $dbMajor, $percent);

            if ($percent > $bestScore && $percent > 70) { // threshold
                $bestScore = $percent;
                $bestMatch = $major;
            }
        }

        return $bestMatch;
    }

    public function detectQualification($text, $aiData = [])
    {
        $levels = DB::table('egc_qualification_level')->get();
        $majors = Cache::remember('majors', 3600, function () {
            return DB::table('egc_major')->where('status', 0)->get();
        });

        $aiDegree = $aiData['degree_full'] ?? '';
        // if (is_array($aiDegree)) {
        //     $aiDegree = implode(' ', $aiDegree);
        // }

        // $aiDegree = (string) $aiDegree;

        if ($aiDegree) {
            $degrees = preg_split('/,|\n|\/|;/', $aiDegree);
            $degrees = array_filter(array_map('trim', $degrees));

            usort($degrees, function ($a, $b) {
                return $this->rankDegree($b) <=> $this->rankDegree($a);
            });

            $aiDegree = $degrees[0] ?? $aiDegree;
            $aiDegree = $this->cleanDegree($aiDegree); //  ADD THIS
        }

        // if (empty($aiDegree)) {
        //     $aiDegree = $this->extractDegreeFromText($text);
        // }

        // 🔥 1. AI FIRST
        if ($aiDegree) {

            $aiDegree = $this->cleanDegree($aiDegree);
            $normalizedAI = $this->normalizeDegreeKey($aiDegree);
            $bestMatch = null;
            $bestScore = 0;

            // ✅ STEP 4: DIRECT NORMALIZED MATCH (VERY IMPORTANT)
            // foreach ($majors as $major) {

            //     $dbText = ($major->major_name ?? '') . ' ' . ($major->description ?? '');
            //     $dbText = $this->cleanDegree($dbText);
            //     $normalizedDB = $this->normalizeDegreeKey($dbText);

            //     if (
            //             $normalizedAI === $normalizedDB ||
            //             str_contains($normalizedAI, $normalizedDB) ||
            //             str_contains($normalizedDB, $normalizedAI)
            //         ) {

            //         // 🔥 EXTRA: check specialization words
            //         $aiText = $this->canonicalize($aiDegree);
            //         $dbText = $this->canonicalize($major->major_name);

            //         if (str_contains($aiText, $dbText) || str_contains($dbText, $aiText)) {
            //             return [
            //                 'qualification_sno' => $major->qualification_id,
            //                 'major_sno' => $major->sno
            //             ];
            //         }
            //     }
            // }

            foreach ($majors as $major) {

                $dbText = $this->cleanDegree(($major->major_name ?? '') . ' ' . ($major->description ?? ''));
                $normalizedDB = $this->normalizeDegreeKey($dbText);

                if (
                    $normalizedAI === $normalizedDB ||
                    str_contains($normalizedAI, $normalizedDB) ||
                    str_contains($normalizedDB, $normalizedAI)
                ) {
                    // 🔥 SCORE BASED ON WORD MATCH
                    $aiWords = explode(' ', $this->canonicalize($aiDegree));
                    $dbWords = explode(' ', $this->canonicalize($major->major_name));

                    $common = array_intersect($aiWords, $dbWords);

                    $score = count($common);

                    // 🔥 Prefer more specific (longer) match
                    if (
                        $score > $bestScore ||
                        ($score == $bestScore && count($dbWords) > count(explode(' ', $this->canonicalize($bestMatch->major_name ?? ''))))
                    ) {
                        $bestScore = $score;
                        $bestMatch = $major;
                    }
                }
            }

            if ($bestMatch) {
                return [
                    'qualification_sno' => $bestMatch->qualification_id,
                    'major_sno' => $bestMatch->sno
                ];
            }

            // ✅ SMART MATCH
            $matched = $this->matchMajor($aiDegree, $majors);

            if ($matched) {
                return [
                    'qualification_sno' => $matched->qualification_id,
                    'major_sno' => $matched->sno
                ];
            }

            $existing = DB::table('egc_major')
                ->get()
                ->first(function ($row) use ($normalizedAI) {
                    $dbNorm = $this->normalizeDegreeKey($row->major_name);
                    return (
                        $dbNorm === $normalizedAI ||
                        str_contains($dbNorm, $normalizedAI) ||
                        str_contains($normalizedAI, $dbNorm)
                    );
                });

            if ($existing) {
                return [
                    'qualification_sno' => $existing->qualification_id,
                    'major_sno' => $existing->sno
                ];
            }

            // ✅ INSERT ONLY IF TRULY NEW
            $qualificationId = $this->mapDegreeToQualification($aiDegree, $levels);

            $newId = DB::table('egc_major')->insertGetId([
                'qualification_id' => $qualificationId,
                'major_name' => ucwords(strtolower($aiDegree)),
                'description' => $aiDegree,
                'created_by' => auth()->id() ?? 0,
                'created_at' => now(),
                'status' => 0
            ]);

            return [
                'qualification_sno' => $qualificationId,
                'major_sno' => $newId
            ];
        }

        // 🔽 fallback (rare)
        $text = $this->canonicalize($text);

        $matched = $this->matchMajor($text, $majors);

        if ($matched) {
            return [
                'qualification_sno' => $matched->qualification_id,
                'major_sno' => $matched->sno
            ];
        }

        return [
            'qualification_sno' => null,
            'major_sno' => null
        ];
    }
    private function mapDegreeToQualification($degree, $levels)
    {
        // if (!is_string($degree)) {
        //     $degree = '';
        // }

        $degree = strtoupper($degree);

        if (preg_match('/BACHELOR|BTECH|BE|BSC|BCOM/', $degree)) {
            return $levels->firstWhere('qualification_level_name', 'UG')->sno ?? 1;
        }

        if (preg_match('/MASTER|MBA|MSC|MTECH/', $degree)) {
            return $levels->firstWhere('qualification_level_name', 'PG')->sno ?? 2;
        }

        if (str_contains($degree, 'PHD')) {
            return $levels->firstWhere('qualification_level_name', 'Doctorate')->sno ?? 3;
        }

        if (str_contains($degree, 'DIPLOMA')) {
            return $levels->firstWhere('qualification_level_name', 'Diploma')->sno ?? 7;
        }

        return null;
    }
    private function canonicalize($text)
    {
        // if (!is_string($text)) {
        //     return '';
        // }

        $text = strtoupper($text);

        // Expand degrees
        $map = [
            'B.E' => 'BACHELOR ENGINEERING',
            'BE' => 'BACHELOR ENGINEERING',
            'BTECH' => 'BACHELOR TECHNOLOGY',
            'MTECH' => 'MASTER TECHNOLOGY',
            'MBA' => 'MASTER BUSINESS ADMINISTRATION',
            'MSC' => 'MASTER SCIENCE',
            'BSC' => 'BACHELOR SCIENCE',
            'M.E' => 'MASTER ENGINEERING'
        ];

        foreach ($map as $k => $v) {
            $text = str_replace($k, $v, $text);
        }

        // 🔥 Branch aliases (VERY IMPORTANT)
        $aliases = [
            'EEE' => 'ELECTRICAL ELECTRONICS ENGINEERING',
            'ELECTRICAL AND ELECTRONICS ENGINEERING' => 'ELECTRICAL ELECTRONICS ENGINEERING',

            'ECE' => 'ELECTRONICS COMMUNICATION ENGINEERING',
            'ELECTRONICS AND COMMUNICATION ENGINEERING' => 'ELECTRONICS COMMUNICATION ENGINEERING',

            'CSE' => 'COMPUTER SCIENCE ENGINEERING',
            'COMPUTER SCIENCE AND ENGINEERING' => 'COMPUTER SCIENCE ENGINEERING',
            'E I' => 'ELECTRONICS INSTRUMENTATION ENGINEERING',
            'E&I' => 'ELECTRONICS INSTRUMENTATION ENGINEERING',

            'CS' => 'COMPUTER SCIENCE',
            'AI' => 'ARTIFICIAL INTELLIGENCE',
            'DS' => 'DATA SCIENCE',

            'COMPUTER APPLICATIONS' => 'COMPUTER APPLICATION',

            'IT' => 'INFORMATION TECHNOLOGY',

            'MECH' => 'MECHANICAL ENGINEERING',
            'CIVIL' => 'CIVIL ENGINEERING',

            'AI ML' => 'ARTIFICIAL INTELLIGENCE MACHINE LEARNING',
            'AI DS' => 'ARTIFICIAL INTELLIGENCE DATA SCIENCE',

            'AGRICULTURAL' => 'AGRICULTURE'
        ];

        foreach ($aliases as $k => $v) {
            if (str_contains($text, $k)) {
                $text = str_replace($k, $v, $text);
            }
        }

        // Remove noise
        // $text = str_replace(['IN', 'OF', 'AND', '&'], ' ', $text);

        // Remove symbols
        $text = preg_replace('/[^A-Z0-9\s]/', ' ', $text);

        // Normalize spaces
        $text = preg_replace('/\s+/', ' ', $text);

        return trim($text);
    }

    private function matchMajor($aiDegree, $majors)
    {
        $ai = $this->canonicalize($aiDegree);

        $best = null;
        $bestScore = 0;

        foreach ($majors as $major) {

            $db = $this->canonicalize($major->major_name);

            $aWords = array_unique(explode(' ', $ai));
            $bWords = array_unique(explode(' ', $db));

            $common = array_intersect($aWords, $bWords);

            $score = (2 * count($common)) / (count($aWords) + count($bWords));

            // 🔥 NEW: prefer longer (more specific) majors
            $specificity = count($bWords);

            if ($score > $bestScore || ($score == $bestScore && $specificity > count(explode(' ', $this->canonicalize($best->major_name ?? ''))))) {
                $bestScore = $score;
                $best = $major;
            }
        }

        return $bestScore >= 0.5 ? $best : null;
    }
    private function fallbackParser($text)
    {
        // Email
        preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $text, $email);

        // Phone
        preg_match('/\+?\d{10,15}/', $text, $phone);

        // Name (top section only)
        $lines = explode("\n", $text);
        $firstLines = implode(" ", array_slice($lines, 0, 5));

        preg_match('/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $firstLines, $name);

        // Gender
        $gender = 3;
        if (preg_match('/\b(male|mr)\b/i', $text)) $gender = 1;
        elseif (preg_match('/\b(female|ms|mrs)\b/i', $text)) $gender = 2;

        // Experience
        preg_match_all('/(\d+)\+?\s*(years|yrs)/i', $text, $exp);
        $experience = !empty($exp[1]) ? max($exp[1]) : 0;

        // Marital
        $marital = null;
        if (stripos($text, 'married') !== false) $marital = 1;
        elseif (stripos($text, 'single') !== false) $marital = 2;
        else $marital = 2;

        return [
            'candidate_name' => $name[0] ?? null,
            'candidate_email' => $email[0] ?? null,
            'candidate_mobile' => $phone[0] ?? null,
            'candidate_gender' => $gender,
            'candidate_exper_count' => $experience,
            'candidate_marital_status' => $marital,
        ];
    }

    private function mergeData($ai, $fallback, $text)
    {
        return [
            // ✅ Name → AI + fallback
            'candidate_name' => $ai['candidate_name'] ?: $this->extractName($text) ?: $fallback['candidate_name'],

            // ✅ Email → ALWAYS from TEXT (critical fix)

            'candidate_email' => $ai['candidate_email'] ?? $this->extractEmail($text),

            // ✅ Phone → ALWAYS from TEXT
            //   'candidate_mobile' =>  $ai['candidate_mobile'] ?? $this->extractPhone($text) ,
            'candidate_mobile' => $this->cleanPhone(
                $ai['candidate_mobile'] ?: $this->extractPhone($text)
            ),

            // ✅ Gender → AI or fallback
            'candidate_gender' => $ai['candidate_gender'] ?? $fallback['candidate_gender'] ?? 3,

            // ✅ Experience → max of both
            'candidate_exper_count' => max(
                (int)$ai['candidate_exper_count'],
                (int)$fallback['candidate_exper_count']
            ),

            // ✅ Marital
            'candidate_marital_status' => $ai['candidate_marital_status'] ?? $fallback['candidate_marital_status'],
        ];
    }

    private function cleanFinalData($data, $text)
    {
        // ✅ Clean Email
        if (!empty($data['candidate_email'])) {
            preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $data['candidate_email'], $email);
            $data['candidate_email'] = $email[0] ?? null;
        }

        // ✅ Clean Name (remove garbage words)
        if (!empty($data['candidate_name'])) {
            $name = trim($data['candidate_name']);

            // Remove unwanted words
            $name = preg_replace('/(country|india|city|resume)/i', '', $name);

            // Keep only 2 words max
            // preg_match('/[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $name, $match);
            // preg_match('/^([A-Z]\.\s*)*[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $name, $match);

            // $data['candidate_name'] = $match[0] ?? null;
            $name = trim($data['candidate_name']);

            // Remove unwanted words
            $name = preg_replace('/(country|india|city|resume)/i', '', $name);

            $name = trim($name);

            // Remove unwanted words
            $name = preg_replace('/(country|india|city|resume)/i', '', $name);

            // Normalize dots → spaces
            $name = str_replace('.', ' ', $name);
            $name = preg_replace('/\s+/', ' ', $name);

            // normalize dots
            $name = preg_replace('/\.([A-Z])/', ' $1', $name);

            // remove extra spaces
            $name = preg_replace('/\s+/', ' ', $name);

            // 🔥 REMOVE DUPLICATE FULL NAME
            $words = explode(' ', $name);
            $half = intdiv(count($words), 2);

            if ($half > 0) {
                $firstHalf = implode(' ', array_slice($words, 0, $half));
                $secondHalf = implode(' ', array_slice($words, $half));

                if ($firstHalf === $secondHalf) {
                    $name = $firstHalf;
                }
            }

            $data['candidate_name'] = $name;

            // ✅ CASE 1: ALL CAPS (P EASAN)
            if (preg_match('/^[A-Z\s]{3,}$/', $name)) {
                $data['candidate_name'] = trim($name);
                return $data;
            }

            // ✅ CASE 2: Normal (Vetri Vijayan)
            if (preg_match('/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)+$/', $name, $match)) {
                $data['candidate_name'] = $match[0];
                return $data;
            }

            // ✅ CASE 3: Initials (P Easan)
            if (preg_match('/^([A-Z]\s*)+[A-Z][a-z]+$/', $name, $match)) {
                $data['candidate_name'] = $match[0];
                return $data;
            }

            if (preg_match('/^[A-Z][a-z]+\s[A-Z]$/', $name, $match)) {
                $data['candidate_name'] = $match[0];
                return $data;
            }


            // ❌ Otherwise reject
            $data['candidate_name'] = null;
        }

        // ✅ Clean Phone
        // if (!empty($data['candidate_mobile'])) {
        //     preg_match('/\+?\d{10,15}/', $data['candidate_mobile'], $phone);
        //     $data['candidate_mobile'] = $phone[0] ?? null;
        // }
        if (!empty($data['candidate_mobile'])) {
            $data['candidate_mobile'] = $this->cleanPhone($data['candidate_mobile']);
        }

        return $data;
    }


    private function mapGender($gender)
    {
        $gender = strtolower(trim($gender));

        if (in_array($gender, ['male', 'm'])) return 1;
        if (in_array($gender, ['female', 'f'])) return 2;

        return 3;
    }
    private function mapMarital($status)
    {
        $status = strtolower(trim($status));

        return match (true) {
            str_contains($status, 'unmarried'),
            str_contains($status, 'single'),
            str_contains($status, 'not married') => 2,

            str_contains($status, 'married') => 1,

            default => null,
        };
    }

    private function extractDegreeFromText($text)
    {
        $text = strtolower($text);

        $degrees = [
            'phd' => 'PhD',
            'doctorate' => 'PhD',
            'mba' => 'MBA',
            'm.tech' => 'M.Tech',
            'mtech' => 'M.Tech',
            'm.e' => 'M.E',
            'msc' => 'MSc',
            'm.sc' => 'MSc',
            'b.tech' => 'B.Tech',
            'btech' => 'B.Tech',
            'b.e' => 'B.E',
            'be' => 'B.E',
            'bsc' => 'BSc',
            'b.sc' => 'BSc',
            'bcom' => 'BCom',
            'b.com' => 'BCom',
            'ba' => 'BA',
            'diploma' => 'Diploma',
        ];

        foreach ($degrees as $key => $value) {
            if (strpos($text, $key) !== false) {
                return $value;
            }
        }

        return null;
    }
    private function mapQualification($degree)
    {
        if (!$degree) return null;

        $degree = strtolower($degree);

        if (in_array($degree, ['phd'])) return 4;        // Doctorate
        if (str_contains($degree, 'm')) return 2;        // PG
        if (str_contains($degree, 'b')) return 1;        // UG
        if (str_contains($degree, 'diploma')) return 3;  // Diploma

        return null;
    }

    public function extractCandidateData(
        Request $request,
        ResumeTextExtractionService $resumeTextExtractionService,
        CandidateNameExtractionService $candidateNameExtractionService,
        CandidateMobileService $candidateMobileService,
        CandidateEmailService $candidateEmailService,
        CandidateJobRoleMatchingService $candidateJobRoleMatchingService,
        CandidateQualificationMajorService $candidateQualificationMajorService,
        CandidateExperienceService $candidateExperienceService
    ) {
        $request->validate([
            'upload_resume' => [
                'required',
                'file',
                'max:10240',
                function ($attribute, $file, $fail) {
                    if (!$file instanceof \Illuminate\Http\UploadedFile) {
                        $fail('Please select a valid resume file.');
                        return;
                    }

                    $extension = strtolower($file->getClientOriginalExtension());
                    if (!ResumeTextExtractionService::supportsExtension($extension)) {
                        $fail('Unsupported resume format. Please upload PDF, Word, ODT, RTF, text/HTML, PowerPoint, Excel, or an image file.');
                    }
                },
            ],
        ]);

        $file = $request->file('upload_resume');
        $traceId = (string) Str::uuid();

        try {
            $fileHash = hash_file('sha256', $file->getRealPath());
            if (!is_string($fileHash) || strlen($fileHash) !== 64) {
                throw new \RuntimeException('The uploaded file could not be fingerprinted.');
            }

            $textResult = $resumeTextExtractionService->extract($file);
            $resumeText = trim((string) ($textResult['text'] ?? ''));
            $nameEvidenceEngine = 'resume_text';
            $isPdf = strtolower((string) $file->getClientOriginalExtension()) === 'pdf';
            $ocrFallbackAttempted = false;
            $earlyOcrText = '';
            $ocrText = '';
            // Mobile extraction is local-only so candidate phone PII is not sent to AI.
            $mobileResult = $candidateMobileService->extractFromResume($resumeText);

            // AI-first policy: for readable resume text, call the configured model
            // before local candidate-name parsing. CandidateNameExtractionService
            // validates model output and automatically uses local parsing if AI fails.
            // If a PDF has no readable text at all, OCR is required to create model
            // input; the AI still runs before local parsing of that OCR text.
            $nameInputForAi = $resumeText;
            if ($resumeText === '' && $isPdf) {
                $earlyOcr = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $earlyOcrText = trim((string) ($earlyOcr['text'] ?? ''));
                if ($earlyOcrText !== '') {
                    $nameInputForAi = $earlyOcrText;
                    $nameEvidenceEngine = (string) ($earlyOcr['engine'] ?? 'pdf_ocr_name_fallback');
                }
            }

            $nameResult = $candidateNameExtractionService->extract($nameInputForAi);
            if (!empty($nameResult['candidate_name']) && $earlyOcrText !== ''
                && ($nameResult['source'] ?? '') === 'local_parser') {
                $nameEvidenceEngine = (string) ($earlyOcr['engine'] ?? 'pdf_ocr_name_fallback');
            }

            // After the AI-first pass and local fallback fail, OCR page one and retry
            // local parsing only. Do not invoke Hugging Face a second time for the same
            // upload: that would spend another credit without improving the source text
            // already given to the model.
            if (empty($nameResult['candidate_name']) && $isPdf && !$ocrFallbackAttempted) {
                $ocrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $ocrText = trim((string) ($ocrFallback['text'] ?? ''));
                if ($ocrText !== '') {
                    $ocrNameResult = $candidateNameExtractionService->extractLocallyOnly($ocrText);
                    if (empty($ocrNameResult['candidate_name'])) {
                        $combinedText = trim($ocrText . "\n\n" . $resumeText);
                        $ocrNameResult = $candidateNameExtractionService->extractLocallyOnly($combinedText);
                        if (!empty($ocrNameResult['candidate_name'])) {
                            $nameEvidenceEngine = 'resume_text+pdf_ocr_name_fallback';
                        }
                    } else {
                        $nameEvidenceEngine = (string) ($ocrFallback['engine'] ?? 'pdf_ocr_name_fallback');
                    }

                    if (!empty($ocrNameResult['candidate_name'])) {
                        $ocrNameResult['ai_attempted'] = (bool) ($nameResult['ai_attempted'] ?? false);
                        $nameResult = $ocrNameResult;
                    } else {
                        $nameEvidenceEngine = (string) ($ocrFallback['engine'] ?? 'pdf_ocr_name_fallback');
                    }
                }
            }

            // Email extraction is deterministic/local; do not spend inference credits
            // on a field that can be validated from its syntax. Reuse OCR text when
            // already available. If a PDF has no email in its text layer, perform one
            // bounded first-page OCR retry (only if OCR has not already been attempted).
            $contactEvidenceText = trim($resumeText . "\n" . $earlyOcrText . "\n" . $ocrText);
            $emailContactEvidenceText = $contactEvidenceText;
            $emailResult = $candidateEmailService->extractFromResume($emailContactEvidenceText);
            if (empty($emailResult['candidate_email']) && $isPdf && !$ocrFallbackAttempted) {
                $emailOcrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                $ocrFallbackAttempted = true;
                $emailOcrText = trim((string) ($emailOcrFallback['text'] ?? ''));
                if ($emailOcrText !== '') {
                    // Keep email-only OCR isolated from name/mobile selection, but make
                    // the same recovered page text available to role matching later.
                    $emailContactEvidenceText = trim($contactEvidenceText . "\n" . $emailOcrText);
                    $emailResult = $candidateEmailService->extractFromResume($emailContactEvidenceText);
                    $ocrText = trim($ocrText . "\n" . $emailOcrText);
                }
            }
            $mobileEvidenceText = $contactEvidenceText;
            $mobileResult = $candidateMobileService->extractFromResume($mobileEvidenceText);

            // Local, explainable ATS role matching. This step never calls an LLM and
            // never changes name/mobile/email decisions. The active role catalogue
            // and optional per-role profile table control which roles are eligible.
            $roleEvidenceText = trim($resumeText . "\n" . $earlyOcrText . "\n" . $ocrText);
            $roleEvidenceEngine = trim($ocrText . $earlyOcrText) !== '' ? 'resume_text+pdf_ocr' : 'resume_text';
            $roleMatchResult = $candidateJobRoleMatchingService->matchResume($roleEvidenceText, 8);
            if (empty($roleMatchResult['matches']) && $isPdf && !$ocrFallbackAttempted) {
                try {
                    $roleOcrFallback = $resumeTextExtractionService->extractPdfNameFallback((string) $file->getRealPath());
                    $roleOcrText = trim((string) ($roleOcrFallback['text'] ?? ''));
                    if ($roleOcrText !== '') {
                        $roleEvidenceText = trim($roleEvidenceText . "\n" . $roleOcrText);
                        $roleEvidenceEngine = 'resume_text+' . (string) ($roleOcrFallback['engine'] ?? 'pdf_ocr_role_fallback');
                        $roleMatchResult = $candidateJobRoleMatchingService->matchResume($roleEvidenceText, 8);
                    }
                } catch (Throwable $roleOcrError) {
                    // Role suggestions are optional; OCR failure must not break resume upload.
                    Log::debug('Candidate role matching OCR fallback skipped.', [
                        'trace_id' => $traceId,
                        'exception' => get_class($roleOcrError),
                    ]);
                }
            }

            // Qualification/major suggestions use the existing database master tables;
            // no schema mutation and no additional AI inference.
            try {
                $qualificationMajorResult = $candidateQualificationMajorService->suggest($roleEvidenceText);
            } catch (Throwable $qualificationMajorError) {
                Log::warning('Candidate qualification/major suggestion unavailable.', ['trace_id' => $traceId, 'exception' => get_class($qualificationMajorError)]);
                $qualificationMajorResult = [];
            }

            // Experience classification and date-range union are local-only. It does
            // not invoke Hugging Face and cannot interrupt the name/contact/role flows.
            try {
                $experienceResult = $candidateExperienceService->suggest($roleEvidenceText);
            } catch (Throwable $experienceError) {
                Log::warning('Candidate experience suggestion unavailable.', [
                    'trace_id' => $traceId,
                    'exception' => get_class($experienceError),
                ]);
                $experienceResult = [];
            }

            Log::info('Resume candidate-name extraction completed', [
                'trace_id' => $traceId,
                'parser_version' => CandidateNameExtractionService::VERSION,
                'text_engine' => $textResult['engine'] ?? 'none',
                'name_evidence_engine' => $nameEvidenceEngine,
                'text_chars' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                'candidate_name_found' => !empty($nameResult['candidate_name']),
                'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                'ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                'candidate_mobile_found' => !empty($mobileResult['candidate_mobile']),
                'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                'candidate_email_found' => !empty($emailResult['candidate_email']),
                'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                'candidate_email_parser_version' => CandidateEmailService::VERSION,
                'candidate_role_match_version' => CandidateJobRoleMatchingService::VERSION,
                'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                'candidate_role_catalog_count' => (int) ($roleMatchResult['catalog_role_count'] ?? 0),
                'candidate_experience_type_found' => isset($experienceResult['candidate_experience_type']),
                'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                'local_parser_diagnostics' => $candidateNameExtractionService->getLastDiagnostics(),
            ]);

            $token = bin2hex(random_bytes(24));
            $sessionHash = hash('sha256', (string) $request->session()->getId());
            $cacheTtl = max(1, (int) config('recruitment_resume_ai.cache_ttl_minutes', 20));

            // Text remains server-side in the short-lived cache; never return the CV text
            // to the browser. Bind the cache entry to this session and exact file hash.
            Cache::put('hr_recruitment_resume_parse:' . $token, [
                'sha256' => $fileHash,
                'session_hash' => $sessionHash,
                'resume_text' => $resumeText,
                'data' => [
                    'candidate_name' => $nameResult['candidate_name'] ?? null,
                    'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                    'candidate_name_model' => $nameResult['model'] ?? null,
                    'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                    'candidate_name_ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                    'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                    'candidate_name_evidence_engine' => $nameEvidenceEngine,
                    'candidate_mobile' => $mobileResult['candidate_mobile'] ?? null,
                    'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                    'candidate_mobile_parser_version' => CandidateMobileService::VERSION,
                    'candidate_email' => $emailResult['candidate_email'] ?? null,
                    'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                    'candidate_email_parser_version' => CandidateEmailService::VERSION,
                    'candidate_role_matches' => $roleMatchResult['matches'] ?? [],
                    'suggested_job_role_ids' => $roleMatchResult['role_ids'] ?? [],
                    'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                    'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                    'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                    'candidate_role_match_parser_version' => CandidateJobRoleMatchingService::VERSION,
                    'candidate_qualification' => $qualificationMajorResult['candidate_qualification'] ?? null,
                    'candidate_qualification_name' => $qualificationMajorResult['candidate_qualification_name'] ?? null,
                    'candidate_major' => $qualificationMajorResult['candidate_major'] ?? null,
                    'candidate_major_name' => $qualificationMajorResult['candidate_major_name'] ?? null,
                    'candidate_other_qualify' => $qualificationMajorResult['candidate_other_qualify'] ?? null,
                    'candidate_qualification_major_source' => $qualificationMajorResult['candidate_qualification_major_source'] ?? 'not_found',
                    'candidate_qualification_major_confidence' => $qualificationMajorResult['candidate_qualification_major_confidence'] ?? 'low',
                    'candidate_qualification_major_parser_version' => CandidateQualificationMajorService::VERSION,
                    'candidate_experience_type' => $experienceResult['candidate_experience_type'] ?? null,
                    'candidate_experience_type_name' => $experienceResult['candidate_experience_type_name'] ?? null,
                    'candidate_exper_count' => $experienceResult['candidate_exper_count'] ?? null,
                    'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                    'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                    'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                    'candidate_experience_confidence' => $experienceResult['candidate_experience_confidence'] ?? 'low',
                    'candidate_experience_date_range_count' => (int) ($experienceResult['candidate_experience_date_range_count'] ?? 0),
                    'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                ],
                'text_extraction' => [
                    'engine' => $textResult['engine'] ?? 'none',
                    'extension' => $textResult['extension'] ?? strtolower($file->getClientOriginalExtension()),
                    'warning' => $textResult['warning'] ?? null,
                ],
                'created_at' => now()->toIso8601String(),
            ], now()->addMinutes($cacheTtl));

            $readable = $resumeText !== '';
            return response()->json([
                'status' => 200,
                'message' => $readable
                    ? (!empty($nameResult['candidate_name'])
                        ? 'Resume text read. Please verify the suggested candidate fields.'
                        : (!empty($emailResult['candidate_email']) || !empty($mobileResult['candidate_mobile'])
                            ? 'Resume text read. Contact suggestions are available; verify them and enter the candidate name manually if needed.'
                            : 'Resume text read, but no reliable candidate name was found. Enter it manually.'))
                    : 'The file was selected, but text could not be read. You can still attach the resume and enter the candidate name manually.',
                'data' => [
                    'candidate_name' => $nameResult['candidate_name'] ?? null,
                    'candidate_name_source' => $nameResult['source'] ?? 'not_found',
                    'candidate_name_model' => $nameResult['model'] ?? null,
                    'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                    'candidate_name_ai_attempted' => (bool) ($nameResult['ai_attempted'] ?? false),
                    'candidate_name_ai_result_status' => $nameResult['ai_result_status'] ?? $candidateNameExtractionService->getLastAiResultStatus(),
                    'candidate_name_evidence_engine' => $nameEvidenceEngine,
                    'candidate_mobile' => $mobileResult['candidate_mobile'] ?? null,
                    'candidate_mobile_source' => $mobileResult['source'] ?? 'not_found',
                    'candidate_mobile_parser_version' => CandidateMobileService::VERSION,
                    'candidate_email' => $emailResult['candidate_email'] ?? null,
                    'candidate_email_source' => $emailResult['source'] ?? 'not_found',
                    'candidate_email_parser_version' => CandidateEmailService::VERSION,
                    'candidate_role_matches' => $roleMatchResult['matches'] ?? [],
                    'suggested_job_role_ids' => $roleMatchResult['role_ids'] ?? [],
                    'candidate_role_match_count' => (int) ($roleMatchResult['match_count'] ?? 0),
                    'candidate_role_match_status' => (string) ($roleMatchResult['status'] ?? 'unavailable'),
                    'candidate_role_match_evidence_engine' => $roleEvidenceEngine,
                    'candidate_role_match_parser_version' => CandidateJobRoleMatchingService::VERSION,
                    'candidate_qualification' => $qualificationMajorResult['candidate_qualification'] ?? null,
                    'candidate_qualification_name' => $qualificationMajorResult['candidate_qualification_name'] ?? null,
                    'candidate_major' => $qualificationMajorResult['candidate_major'] ?? null,
                    'candidate_major_name' => $qualificationMajorResult['candidate_major_name'] ?? null,
                    'candidate_other_qualify' => $qualificationMajorResult['candidate_other_qualify'] ?? null,
                    'candidate_qualification_major_source' => $qualificationMajorResult['candidate_qualification_major_source'] ?? 'not_found',
                    'candidate_qualification_major_confidence' => $qualificationMajorResult['candidate_qualification_major_confidence'] ?? 'low',
                    'candidate_qualification_major_parser_version' => CandidateQualificationMajorService::VERSION,
                    'candidate_experience_type' => $experienceResult['candidate_experience_type'] ?? null,
                    'candidate_experience_type_name' => $experienceResult['candidate_experience_type_name'] ?? null,
                    'candidate_exper_count' => $experienceResult['candidate_exper_count'] ?? null,
                    'candidate_experience_years' => $experienceResult['candidate_experience_years'] ?? null,
                    'candidate_experience_months' => $experienceResult['candidate_experience_months'] ?? null,
                    'candidate_experience_source' => $experienceResult['candidate_experience_source'] ?? 'insufficient_evidence',
                    'candidate_experience_confidence' => $experienceResult['candidate_experience_confidence'] ?? 'low',
                    'candidate_experience_date_range_count' => (int) ($experienceResult['candidate_experience_date_range_count'] ?? 0),
                    'candidate_experience_parser_version' => CandidateExperienceService::VERSION,
                    'resume_extraction_token' => $token,
                    'resume_source_sha256' => $fileHash,
                    'text_extraction_engine' => $textResult['engine'] ?? 'none',
                    'text_extraction_status' => $readable ? 'readable' : 'unreadable',
                    'text_extraction_warning' => $textResult['warning'] ?? null,
                    'resume_text_chars' => function_exists('mb_strlen') ? mb_strlen($resumeText, 'UTF-8') : strlen($resumeText),
                    'review_required' => true,
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Recruitment resume extraction endpoint failed', [
                'trace_id' => $traceId,
                'extension' => strtolower((string) $file->getClientOriginalExtension()),
                'size_bytes' => (int) ($file->getSize() ?: 0),
                'exception' => get_class($e),
            ]);

            return response()->json([
                'status' => 422,
                'trace_id' => $traceId,
                'candidate_name_parser_version' => CandidateNameExtractionService::VERSION,
                'message' => 'This resume could not be processed automatically. The file can still be attached; please enter the candidate name manually and try saving again.',
            ], 422);
        }
    }

    /** Real-time duplicate check used by the Add/Edit Candidate mobile fields. */
    public function checkCandidateMobile(Request $request, CandidateMobileService $candidateMobileService)
    {
        $validated = $request->validate([
            'mobile' => ['required', 'string', 'max:24'],
            'exclude_applicant_id' => ['nullable', 'integer', 'min:1'],
        ]);

        $mobile = $candidateMobileService->normalizeIndianMobile((string) $validated['mobile']);
        if ($mobile === null) {
            return response()->json([
                'status' => 422,
                'message' => 'Enter a valid Indian 10-digit mobile number.',
                'data' => ['exists' => false, 'valid' => false],
            ], 422);
        }

        $excludeId = isset($validated['exclude_applicant_id']) ? (int) $validated['exclude_applicant_id'] : null;
        $exists = $candidateMobileService->existsForApplicant($mobile, $excludeId);

        return response()->json([
            'status' => 200,
            'message' => $exists ? 'This mobile number already exists for another candidate.' : 'Mobile number is available.',
            'data' => [
                'valid' => true,
                'exists' => $exists,
                'normalized_mobile' => $mobile,
            ],
        ]);
    }

    private function extractName($text)
    {
        $lines = explode("\n", $text);

        foreach (array_slice($lines, 0, 10) as $line) {

            $line = trim($line);

            //  if (preg_match('/^[A-Z]{3,}$/', $line)) {
            //     return $line; // keep as is (AKMAX)
            // }

            // Skip noise
            if (preg_match('/(email|phone|linkedin|contact|profile)/i', $line)) {
                continue;
            }

            // ✅ ALL CAPS NAME SUPPORT
            // if (preg_match('/^[A-Z\s]{3,}$/', $line)) {
            //     return ucwords(strtolower($line));
            // }

            if (preg_match('/^[A-Z\s]{3,}$/', $line)) {
                return trim($line); // KEEP ORIGINAL
            }

            // ✅ Normal Name
            if (preg_match('/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)+$/', $line)) {
                return $line;
            }
        }

        return null;
    }

    private function extractEmail($text)
    {
        preg_match_all('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $text, $matches);

        if (!empty($matches[0])) {

            foreach ($matches[0] as $email) {

                // Skip fake/system emails
                if (str_contains($email, 'example')) continue;

                return strtolower(trim($email));
            }
        }

        return null;
    }

    private function extractPhone($text)
    {
        preg_match_all('/\+?\d[\d\s\-\/]{8,}\d/', $text, $matches);

        if (!empty($matches[0])) {
            return $matches[0][0]; // ✅ return RAW (don't clean here)
        }

        return null;
    }

    // public function detectQualification($text)
    // {
    //     $text = strtoupper($text);
    //     $text = preg_replace('/[^A-Z0-9\s]/', ' ', $text);

    //     $levels = DB::table('egc_qualification_level')->get();
    //     $majors = DB::table('egc_major')->where('status', 0)->get();

    //     // 🔥 DEGREE KEYWORDS → MAP TO DB
    //     $degreeMap = [
    //         'BTECH' => 'UG',
    //         'BE' => 'UG',
    //         'BSC' => 'UG',
    //         'BCOM' => 'UG',
    //         'BCA' => 'UG',

    //         'MBA' => 'PG',
    //         'MTECH' => 'PG',
    //         'MSC' => 'PG',

    //         'PHD' => 'Doctorate',
    //         'DIPLOMA' => 'Diploma'
    //     ];

    //     foreach ($degreeMap as $key => $levelName) {

    //         if (strpos($text, $key) !== false) {

    //             $level = $levels->firstWhere('qualification_level_name', $levelName);

    //             return [
    //                 'qualification_sno' => $level->sno ?? null,
    //                 'major_sno' => $this->detectMajor($text, $majors)
    //             ];
    //         }
    //     }

    //     // 🔥 MAJOR MATCH (BEST CASE)
    //     foreach ($majors as $major) {

    //         if (!$major->major_name) continue;

    //         if (strpos($text, strtoupper($major->major_name)) !== false) {

    //             return [
    //                 'qualification_sno' => $major->qualification_id,
    //                 'major_sno' => $major->sno
    //             ];
    //         }
    //     }

    //     return [
    //         'qualification_sno' => null,
    //         'major_sno' => null
    //     ];
    // }

    private function detectMajor($text, $majors)
    {
        $text = strtolower($text);

        foreach ($majors as $m) {

            $name = strtolower($m->major_name ?? '');

            if (!$name) continue;

            if (str_contains($text, $name)) {
                return $m->sno;
            }
        }

        return null;
    }

    private function fallbackQualification($text)
    {
        $map = [
            'BTECH' => 'UG',
            'B E' => 'UG',
            'BE' => 'UG',
            'BSC' => 'UG',
            'BCA' => 'UG',
            'BCOM' => 'UG',
            'BA' => 'UG',

            'MTECH' => 'PG',
            'ME' => 'PG',
            'MSC' => 'PG',
            'MCA' => 'PG',
            'MBA' => 'PG',

            'PHD' => 'Doctorate',

            'DIPLOMA' => 'Diploma'
        ];

        foreach ($map as $key => $level) {
            if (strpos($text, $key) !== false) {
                return [
                    'major_sno' => null,
                    'major_name' => $key,
                    'qualification_level' => $level
                ];
            }
        }

        return [
            'major_sno' => null,
            'major_name' => null,
            'qualification_level' => null
        ];
    }

    private function extractResumeText(string $filePath): string
    {

        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        $text = '';
        // return $extension;
        try {

            /* ===== PDF ===== */
            if ($extension === 'pdf') {
                $parser = new PdfParser();
                $pdf = $parser->parseFile($filePath);
                $text = $pdf->getText();

                // 🔥 If empty → OCR fallback
                if (strlen(trim($text)) < 50) {
                    $text = $this->extractPdfWithOCR($filePath);
                }
            }

            /* ===== DOC / DOCX ===== */
            if (in_array($extension, ['doc', 'docx'])) {

                $phpWord = IOFactory::load($filePath);

                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {

                        if (method_exists($element, 'getText')) {
                            $text .= $element->getText() . ' ';
                        }

                        if (method_exists($element, 'getElements')) {
                            foreach ($element->getElements() as $child) {
                                if (method_exists($child, 'getText')) {
                                    $text .= $child->getText() . ' ';
                                }
                            }
                        }
                    }
                }
            }
            if (in_array($extension, ['jpg', 'jpeg', 'png',])) {
                $text = $this->extractTextWithOCR($path);
            }
        } catch (\Exception $e) {
            \Log::error('Resume extraction failed: ' . $e->getMessage());
        }

        // Cleanup text
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    private function extractDocFallback($path)
    {
        $text = '';

        try {
            // Linux server (best)
            if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
                $text = shell_exec("antiword " . escapeshellarg($path));
            } else {
                // Windows fallback
                $text = file_get_contents($path);
            }
        } catch (\Exception $e) {
            \Log::error('DOC Extract Error: ' . $e->getMessage());
        }

        return $text;
    }
    private function cleanText($text)
    {
        // Keep line breaks!
        $text = preg_replace('/[^\x20-\x7E\n]/', ' ', $text);

        // Normalize spaces but KEEP new lines
        $text = preg_replace('/[ \t]+/', ' ', $text);

        return trim(substr($text, 0, 8000));
    }
    private function extractTextWithOCR($filePath)
    {
        try {
            return (new TesseractOCR($filePath))
                ->lang('eng')
                ->psm(6) // 🔥 Better layout detection
                ->run();
        } catch (\Exception $e) {
            \Log::error('OCR Error: ' . $e->getMessage());
            return '';
        }
    }

    private function cleanPhone($phone)
    {
        if (!$phone) return null;

        // 🔥 Split multiple numbers (/, comma, semicolon)
        $numbers = preg_split('/[\/,;]+/', $phone);
        $validNumbers = [];
        foreach ($numbers as $num) {

            // Remove all non-digits
            $num = preg_replace('/\D/', '', $num);

            if (!$num) continue;

            // Remove leading 91 (India country code)
            if (strlen($num) > 10 && str_starts_with($num, '91')) {
                $num = substr($num, 2);
            }

            // Keep last 10 digits
            if (strlen($num) > 10) {
                $num = substr($num, -10);
            }


            // ✅ Validate Indian mobile (starts 6-9)
            if (preg_match('/^[6-9]\d{9}$/', $num)) {
                return $num; // ✅ return FIRST valid number
            }
        }

        return null;
    }

    private function pdfToImages($path)
    {
        $images = [];
        $outputDir = storage_path('app/ocr/');

        if (!file_exists($outputDir)) {
            mkdir($outputDir, 0777, true);
        }

        $output = $outputDir . uniqid();

        // Convert PDF to PNG images
        shell_exec("pdftoppm -png " . escapeshellarg($path) . " $output");

        foreach (glob($output . "*.png") as $img) {
            $images[] = $img;
        }

        return $images;
    }
    private function extractPdfWithOCR($path)
    {
        $text = '';

        $images = $this->pdfToImages($path);

        foreach ($images as $img) {
            $text .= ' ' . $this->extractTextWithOCR($img);
            unlink($img);
        }

        return $text;
    }
    
    private function addConfidence($data)
    {
        $score = 0;

        if ($data['candidate_email']) $score += 20;
        if ($data['candidate_mobile']) $score += 20;
        if ($data['candidate_name']) $score += 15;
        if ($data['candidate_exper_count']) $score += 15;
        if ($data['candidate_qualification']) $score += 15;
        if ($data['candidate_major']) $score += 15;

        $data['confidence'] = $score; // out of 100

        return $data;
    }

    private function cleanDegree($degree)
    {
        $degree = strtoupper($degree);

        // ❌ Remove noise words
        $degree = str_replace([
            'DEGREE',
            'COURSE',
            'PROGRAM',
            'STUDIES'
        ], '', $degree);

        // ❌ Remove "OF"
        $degree = str_replace([' OF ', ' IN ', ' AND '], ' ', $degree);

        // ❌ Remove university / etc
        $degree = preg_replace('/(UNIVERSITY|COLLEGE|INSTITUTE|SCHOOL).*/', '', $degree);

        // ❌ Remove commas / suffix
        $degree = preg_replace('/,.*$/', '', $degree);

        // Normalize spaces
        $degree = preg_replace('/\s+/', ' ', $degree);

        return trim($degree);
    }


    private function normalizeDegreeKey($degree)
    {

        $degree = $this->cleanDegree($degree);

        // 🔥 DIRECT HARD MATCHES (MOST IMPORTANT)
        if (str_contains($degree, 'BACHELOR COMMERCE')) return 'BCOM';
        if (str_contains($degree, 'MASTER COMMERCE')) return 'MCOM';

        if (str_contains($degree, 'BACHELOR TECHNOLOGY')) return 'BTECH';
        if (str_contains($degree, 'MASTER TECHNOLOGY')) return 'MTECH';

        if (str_contains($degree, 'BACHELOR ENGINEERING')) return 'BE';
        if (str_contains($degree, 'MASTER ENGINEERING')) return 'ME';

        if (str_contains($degree, 'BACHELOR SCIENCE')) return 'BSC';
        if (str_contains($degree, 'MASTER SCIENCE')) return 'MSC';

        if (str_contains($degree, 'BACHELOR ARTS')) return 'BA';
        if (str_contains($degree, 'MASTER ARTS')) return 'MA';

        if (str_contains($degree, 'BUSINESS ADMINISTRATION')) return 'MBA';

        if (str_contains($degree, 'MASTER') && str_contains($degree, 'COMPUTER APPLICATION')) return 'MCA';
        if (str_contains($degree, 'BACHELOR') && str_contains($degree, 'COMPUTER APPLICATION')) return 'BCA';

        $degree = strtoupper($degree);

        // ✅ Normalize text first
        $degree = preg_replace('/[^A-Z0-9\s]/', ' ', $degree);
        $degree = preg_replace('/\s+/', ' ', $degree);

        /*
    |--------------------------------------------------------------------------
    | 🎯 DEGREE DICTIONARY (EXPANDABLE)
    |--------------------------------------------------------------------------
    */
        $map = [

            // 🎓 PG - IT / CS
            'MCA' => ['MCA', 'MASTER COMPUTER APPLICATION', 'COMPUTER APPLICATION'],

            // 🎓 PG - Management
            'MBA' => ['MBA', 'MASTER BUSINESS ADMINISTRATION', 'BUSINESS ADMINISTRATION'],

            // 🎓 UG - Engineering
            'BE' => ['BE', 'B E', 'BACHELOR ENGINEERING'],
            'BTECH' => ['BTECH', 'B TECH', 'BACHELOR TECHNOLOGY'],

            // 🎓 PG - Engineering
            'ME' => ['ME', 'M E', 'MASTER ENGINEERING'],
            'MTECH' => ['MTECH', 'M TECH', 'MASTER TECHNOLOGY'],

            // 🎓 UG - Science
            'BSC' => ['BSC', 'B SC', 'BACHELOR SCIENCE'],

            // 🎓 PG - Science
            'MSC' => ['MSC', 'M SC', 'MASTER SCIENCE'],

            // 🎓 UG - Commerce
            'BCOM' => ['BCOM', 'B COM', 'BACHELOR COMMERCE'],

            // 🎓 PG - Commerce
            'MCOM' => ['MCOM', 'M COM', 'MASTER COMMERCE'],

            // 🎓 UG - Arts
            'BA' => ['BA', 'B A', 'BACHELOR ARTS'],

            // 🎓 PG - Arts
            'MA' => ['MA', 'M A', 'MASTER ARTS'],

            // 🎓 Education
            'BED' => ['BED', 'B ED', 'BACHELOR EDUCATION'],
            'MED' => ['MED', 'M ED', 'MASTER EDUCATION'],

            // 🎓 Computer / IT Diplomas
            'DIPLOMA_CS' => ['DIPLOMA COMPUTER', 'DIPLOMA IT', 'DIPLOMA SOFTWARE'],

            // 🎓 General Diploma
            'DIPLOMA' => ['DIPLOMA'],

            // 🎓 PhD
            'PHD' => ['PHD', 'DOCTORATE', 'DOCTOR OF PHILOSOPHY'],

            // 🎓 12th / 10th
            'HSC' => ['HSC', '12TH', 'HIGHER SECONDARY'],
            'SSLC' => ['SSLC', '10TH', 'SECONDARY SCHOOL'],
        ];

        /*
    |--------------------------------------------------------------------------
    | 🔍 MATCH AGAINST DICTIONARY
    |--------------------------------------------------------------------------
    */
        foreach ($map as $key => $patterns) {
            foreach ($patterns as $pattern) {
                if (str_contains($degree, $pattern)) {
                    return $key;
                }
            }
        }

        /*
    |--------------------------------------------------------------------------
    | 🧠 FALLBACK (GENERIC DETECTION)
    |--------------------------------------------------------------------------
    */

        // Engineering fallback
        if (str_contains($degree, 'ENGINEERING') || str_contains($degree, 'TECHNOLOGY')) {
            return 'ENGINEERING';
        }

        // Science fallback
        if (str_contains($degree, 'SCIENCE')) {
            return 'SCIENCE';
        }

        // Commerce fallback
        if (str_contains($degree, 'COMMERCE')) {
            return 'COMMERCE';
        }

        // Arts fallback
        if (str_contains($degree, 'ARTS')) {
            return 'ARTS';
        }

        return trim($degree); // last fallback
    }

    private function HuggingFaceCretential()
    {
        $huggingApi = DB::table('egc_api_integration')->where('api_key', 'egc_huggingface_api_1')->where('status', 0)->orderBy('sno', 'desc')->first();
        if ($huggingApi) {
            $apiFields = json_decode($huggingApi->api_fields, true);
            $accessToken = '';
            foreach ($apiFields as $field) {
                if ($field['key'] === 'api_key') {
                    $accessToken = $field['value'];
                } else {
                    $accessToken = null;
                }
            }
        } else {
            $accessToken = null;
        }
        return $accessToken;
    }

    // edit
    public function ApplicantDetails(Request $request)
    {
        $applicant_id = $request->applicant_id;
        $applicant = ApplicantModel::where('sno', $applicant_id)->first();
        if ($applicant) {
            return response()->json([
                'status' => 200,
                'message' => 'Applicant Updated successfully',
                'error_msg' => null,
                'data' => $applicant,
            ], 200);
        } else {
            return response()->json([
                'status' => 401,
                'message' => 'Applicant Not Found',
                'error_msg' => 'Applicant Not Found',
                'data' => null,
            ], 401);
        }
    }
    public function UpdateApplicant(Request $request, CandidateMobileService $candidateMobileService)
    {
        $normalizedMobile = $candidateMobileService->normalizeIndianMobile((string) $request->input('candidate_mobile', ''));
        if ($normalizedMobile !== null) {
            $request->merge(['candidate_mobile' => $normalizedMobile]);
        }

        // Validate mobile in the same canonical Indian 10-digit format used by Add Candidate.
        $validator = Validator::make($request->all(), [
            'edit_candidate_id' => ['required', 'integer', 'min:1'],
            'candidate_mobile' => ['required', 'string', 'digits:10', 'regex:/^[6-9][0-9]{9}$/'],
            'recruitment_role_ids_present' => ['sometimes', 'boolean'],
            'recruitment_role_ids' => ['sometimes', 'nullable', 'array', 'max:100'],
            'recruitment_role_ids.*' => ['integer', 'distinct', 'exists:egc_recruitment_roles,sno,status,0'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->errors()->all(),
                'data' => null,
            ], 401);
        }

        $user_id = $request->user()->user_id;
        $edit_id = $request->edit_candidate_id;
        $update_applicant = ApplicantModel::where('sno', $edit_id)->first();
        if ($update_applicant) {
            $normalizedMobile = $candidateMobileService->normalizeIndianMobile((string) $request->input('candidate_mobile', ''));
            if ($normalizedMobile === null) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Enter a valid Indian 10-digit mobile number.',
                    'error_msg' => 'Enter a valid Indian 10-digit mobile number.',
                    'data' => null,
                ], 422);
            }
            if ($candidateMobileService->existsForApplicant($normalizedMobile, (int) $edit_id)) {
                return response()->json([
                    'status' => 409,
                    'message' => 'This mobile number already exists for another candidate.',
                    'error_msg' => 'This mobile number already exists for another candidate.',
                    'data' => null,
                ], 409);
            }

            $candidate_name = $request->candidate_name;
            $candidate_mobile = $request->candidate_mobile;
            $candidate_email = $request->candidate_email;
            $candidate_gender = $request->candidate_gender;
            $candidate_marital_status = $request->candidate_marital_status;
            $qualification_id = $request->candidate_qualification;
            $major = $request->candidate_major;
            $source_id = $request->source_name;
            $exper_type = $request->candidate_exper_type;
            $exper_count = $request->candidate_exper_count;

            $update_applicant->applicant_name = $candidate_name;
            $update_applicant->mobile  = $candidate_mobile;
            $update_applicant->email  = $candidate_email;
            $update_applicant->gender  = $candidate_gender;
            $update_applicant->marital_status_id  = $candidate_marital_status;
            $update_applicant->marital_status_id  = $candidate_marital_status;
            $update_applicant->experience_id = $exper_type;
            $update_applicant->experience_count = $exper_count ?? 0;
            $update_applicant->qualification_id = $qualification_id;
            $update_applicant->major = $major;
            $update_applicant->source_id = $source_id;

            if ($request->boolean('recruitment_role_ids_present') || $request->exists('recruitment_role_ids')) {
                $selectedRecruitmentRoleIds = collect($request->input('recruitment_role_ids', []))
                    ->map(static fn ($roleId) => (int) $roleId)
                    ->unique()
                    ->values()
                    ->all();

                $update_applicant->job_role_id = $selectedRecruitmentRoleIds
                    ? json_encode($selectedRecruitmentRoleIds, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    : null;
            }

            $update_applicant->update();

            if ($update_applicant) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Applicant Updated successfully',
                    'error_msg' => null,
                ], 200);
            }
        } else {
            return response()->json([
                'status' => 401,
                'message' => 'Applicant Not Found',
                'error_msg' => 'Applicant Not Found',
                'data' => null,
            ], 401);
        }
    }


    public function generateAiAnalyse(Request $request)
    {
        $job_role_name = $request->input('job_role_name');
        $applicant_id = $request->input('applicant_id');
        // First try the fallback API
        $applicant = ApplicantModel::where('status', '!=', 2)
            ->where('sno', $applicant_id)->first();

        $drive_old = $applicant->drive_data;
        $drive_data = $drive_old ? json_decode($drive_old) : null;
        if ($drive_data && !isset($drive_data->errors) && isset($drive_data->webViewLink)) {
            $attachment_link = $drive_data->webViewLink;
        } else {
            $attachment_link = null;
        }
        $resumeText = '';
        // return $resumeText;
        if ($applicant->resume_text) {
            $resumeText = $applicant->resume_text;
        } else {
            if ($drive_data && isset($drive_data->file_id)) {
                $resumeText = $this->extractResumeTextFromDrive($drive_data->file_id);
            } else if ($applicant->attachment) {
                $resumeText = $this->extractResumeText(public_path('job_applications/resume_files/' . $applicant->attachment));
            }
        }

        $promptTemplate = "
                    Act as an ATS + hiring manager.

                    I will provide a Job Role Name and a Resume.

                    Analyze the resume against the job role and generate a structured evaluation using metrics.

                    Your output MUST include:

                    1. Overall Match Score (0–100%)
                    2. ATS Keyword Match Score (0–100%)
                    3. Skills Alignment Score (0–100%)
                    4. Experience Relevance Score (0–100%)
                    5. Impact & Metrics Score (0–100%)
                    (Check if the resume includes measurable achievements like %, $, time saved, growth, efficiency gains)
                    6. Role Responsibility Match Score (0–100%)

                    7. Missing Keywords / Skills (list them)
                    8. Strengths (what fits the role well)
                    9. Weaknesses / Gaps (what may block selection)
                    10. Top 5 Resume Improvements (specific edits)
                    11. Rewrite 2–3 strongest bullet points in an achievement-focused format tailored to the role
                    12. Suggest an optimized Professional Summary (3–4 lines) aligned with the job description.

                    Important Rules:
                    - Be strict and realistic like a recruiter.
                    - Highlight weak sections clearly.
                    - Suggest improvements using job-specific keywords.
                    - Do NOT add unnecessary explanations.

                    VERY IMPORTANT:
                    Return the response ONLY in valid JSON format using this structure:

                    {
                    \"overall_match_score\": 0,
                    \"ats_keyword_match_score\": 0,
                    \"skills_alignment_score\": 0,
                    \"experience_relevance_score\": 0,
                    \"impact_metrics_score\": 0,
                    \"role_responsibility_match_score\": 0,
                    \"missing_keywords\": [],
                    \"strengths\": [],
                    \"weaknesses\": [],
                    \"resume_improvements\": [],
                    \"rewritten_bullets\": [],
                    \"optimized_summary\": \"\"
                    }

                    Job Description is provided below:
                    {{JOB_DESCRIPTION}}
                    

                    Resume is provided below:
                    {{RESUME_TEXT}}
                    ";

        $prompt = str_replace(
            [
                '{{JOB_DESCRIPTION}}',
                '{{RESUME_TEXT}}',
            ],
            [
                $job_role_name,
                $resumeText ?? 'Resume not available',
            ],
            $promptTemplate
        );


        $aidata = $this->getAIFromHuggingFaceAIPreview($prompt);




        return response()->json([
            'status' => 200,
            'data' => $aidata,
        ]);
    }
    private function getAIFromHuggingFaceAIPreview($prompt)
    {
        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions';
        $primaryApiKey = $this->HuggingFaceCretential();
        $maxTokens = 1000;
        $aiTimeout = 60; // Consistent timeout
        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobDescriptionGenerator",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            // 'model' => "meta-llama/Meta-Llama-3-70B-Instruct",
            'model' => "meta-llama/Meta-Llama-3-8B-Instruct",
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens,
            'response_format' => ['type' => 'json_object'],
        ]);

        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobDescriptionGenerator",
            ])->post($primaryApiUrl, [
                'model' => "mistralai/Mixtral-8x7B-Instruct",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens,
                'response_format' => ['type' => 'json_object'],
            ]);

            if ($response->failed()) {
                $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                    'Authorization' => "Bearer $primaryApiKey",
                    'Content-Type' => 'application/json',
                    "X-Title" => "JobDescriptionGenerator",
                ])->post($primaryApiUrl, [
                    'model' => "google/gemma-3-12b-it",
                    'messages' => [['role' => 'user', 'content' => $prompt]],
                    'max_tokens' => $maxTokens,
                    'response_format' => ['type' => 'json_object'],
                ]);

                \Log::error('AI API FAILED', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
            }
        }

        // Parse Response
        if ($response->successful()) {
            $responseData = $response->json();

            // 🔍 Debug log (VERY IMPORTANT for production)
            \Log::info('AI RAW RESPONSE', $responseData);

            if (!isset($responseData['choices'][0]['message']['content'])) {
                return [
                    'error' => 'Invalid AI response',
                    'raw' => $responseData
                ];
            }

            $content = $responseData['choices'][0]['message']['content'];

            // 🔥 Clean markdown if exists
            $content = preg_replace('/```json|```/', '', $content);
            $content = trim($content);

            // 🔥 Decode JSON safely
            $decoded = json_decode($content, true);

            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded; // ✅ FINAL CLEAN DATA
            }

            // ❌ If JSON fails
            return [
                'error' => 'JSON parse failed',
                'raw' => $content
            ];
        }

        return '';
    }
    public function extractResumeTextFromDrive(string $fileId): string
    {

        try {
            $filePath = $this->googleDriveService->downloadFile($fileId);

            $mime = mime_content_type($filePath);

            $extension = match ($mime) {
                'application/pdf' => 'pdf',
                'application/msword' => 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                default => throw new Exception("Unsupported MIME type: {$mime}")
            };

            $finalPath = $filePath . '.' . $extension;
            rename($filePath, $finalPath);

            $text = $this->extractResumeText($finalPath);

            unlink($finalPath);

            return $text;
        } catch (Exception $e) {
            Log::error('Resume extraction failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            return '';
        }
    }

    public function vipDetails(Request $request)
    {
        $candidate = DB::table('egc_applicant')
            ->leftJoin(
                'egc_source as s',
                's.sno',
                '=',
                'egc_applicant.source_id'
            )
            ->leftJoin(
                'egc_major',
                'egc_major.sno',
                '=',
                'egc_applicant.major'
            )
            ->where(
                'egc_applicant.sno',
                $request->sno
            )
            ->select(
                'egc_applicant.*',
                's.source_name',
                'egc_major.major_name'
            )
            ->first();

        return response()->json([
            'status' => true,
            'data' => $candidate
        ]);
    }

    public function markVip(Request $request)
    {
        DB::table('egc_applicant')
            ->where(
                'sno',
                $request->applicant_id
            )
            ->update([

                'vip_check' => 1,

                'vip_remarks' => $request->remarks,

                'updated_by' => auth()->id(),

                'updated_at' => now()

            ]);

        return response()->json([

            'status' => true,

            'message' =>
                'Candidate marked as VIP successfully'

        ]);
    }


     public function getCandidateHistoryDetails(Request $request)
    {
        $candidate = DB::table('egc_applicant')
                    ->leftJoin('egc_major','egc_major.sno','=','egc_applicant.major')
                     ->leftJoin('egc_source','egc_source.sno','=','egc_applicant.source_id')
                    ->where('egc_applicant.sno',$request->applicant_id)
                    ->select('egc_applicant.*','egc_major.major_name' ,'egc_source.source_name',)
                    ->first();

        $history =DB::table('egc_applicant_history_logs' )
                    ->leftJoin('egc_company','egc_company.sno','=','egc_applicant_history_logs.company_id')
                    ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_applicant_history_logs.job_role_id')
                    ->where('egc_applicant_history_logs.applicant_id', $request->applicant_id)
                    ->orderBy('egc_applicant_history_logs.sno','asc')
                    ->get();

        return response()->json([
            'status'=>true,
            'candidate'=>$candidate,
            'companies'=>[],
            'history'=>$history
        ]);
    }

    public function storeCandidateHistory(Request $request)
    {
        DB::transaction(function() use($request){

            $entity_id = $request->entity_id == 'egc' ? 0 : $request->entity_id;

            $applicant = ApplicantModel::where('sno', $request->applicant_id)->first();

            DB::table('egc_applicant_history_logs')->insert([

                'candidate_id' =>$applicant->candidate_id ?? 0,
                'applicant_id' =>$request->applicant_id,
                'interview_date' =>$request->interview_date ? date('Y-m-d',strtotime($request->interview_date )) : NULL,
                'applicant_status' =>$request->applicant_status,
                'remarks' =>$request->remarks,
                'selected_date' =>$request->selected_date ? date('Y-m-d',strtotime($request->selected_date )) : NULL,
                'joining_date' =>$request->joining_date ? date('Y-m-d',strtotime($request->joining_date )) : NULL,
                'entity_id' =>$entity_id,
                'job_role_id' =>$request->job_role_id,
                'expected_salary' =>$request->expected_salary,
                'offered_salary' =>$request->offered_salary,
                'followup_date' =>$request->followup_date ? date('Y-m-d',strtotime($request->followup_date )) : NULL,
                'created_by' =>auth()->id()
            ]);

            DB::table('egc_applicant')
                ->where('sno',$request->applicant_id)
                ->update([
                    'interview_status' =>$request->applicant_status,
                    'updated_at' => now()
                ]);

        });

        return response()->json([
            'status'=>true,
            'message'=>
            'Candidate updated successfully'
        ]);
    }

    public function companyRoles(Request $request)
    {
        $roles = DB::table('egc_job_role')
            ->where('company_id', $request->company_id)
            ->where('status', 0)
            ->get();

        return response()->json([
            'status' => true,
            'roles'  => $roles
        ]);
    }


    public function aiView($id)
    {
        $applicant = ApplicantModel::findOrFail($id);

        $ai = [];

        if (!empty($applicant->ai_response)) {
            $ai = json_decode($applicant->ai_response, true);
        }

        return response()->json([
            'status' => true,
            'data' => $applicant,
            'ai' => $ai
        ]);
    }
}
