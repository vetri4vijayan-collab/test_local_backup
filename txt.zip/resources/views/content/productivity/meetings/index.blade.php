@extends('layouts/layoutMaster')
@section('title', 'Meetings')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/sortablejs/sortable.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')

@endsection
@section('content')
@php
    $meetingCanManage = (bool) ($canManageMeetingSettings ?? false);
    $meetingRoutes = [
        'csrf' => csrf_token(),
        'base' => url('/productivity/meetings'),
        'lookups' => route('productivity.meetings.lookups'),
        'dashboard' => route('productivity.meetings.dashboard'),
        'data' => route('productivity.meetings.data'),
        'calendar' => route('productivity.meetings.calendar'),
        'externalEvents' => route('productivity.meetings.external-events'),
        'categories' => route('productivity.meetings.categories'),
        'teams' => route('productivity.meetings.teams'),
        'store' => route('productivity.meetings.store'),
    ];
@endphp
<style>
#egmtApp{
    --egmt-navy:#203a66;
    --egmt-purple:#ab2b22;
    --egmt-bg:#f4f6fb;
    --egmt-line:#dce3ef;
    --egmt-muted:#7b879e;
    --egmt-text:#172b4d;
    --egmt-green:#2c7d3c;
    --egmt-danger:#b42318;
    color:var(--egmt-text);
    font-family:inherit;
}
#egmtApp *{
    box-sizing:border-box;
}
#egmtApp{
    background:var(--egmt-bg);
    padding:18px;
    border-radius:14px;
    min-height:calc(100vh - 130px);
}
.egmt-header{
    margin-bottom:14px;
}
.egmt-header-main{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:14px;
    flex-wrap:wrap;
}
.egmt-title-group{
    display:flex;
    align-items:center;
    gap:12px;
}
.egmt-title-icon{
    width:44px;
    height:44px;
    border-radius:13px;
    background:#e9edf8;
    color:#AB2B22;
    display:grid;
    place-items:center;
    font-size:24px;
}
.egmt-eyebrow{
    font-size:10px;
    letter-spacing:.08em;
    font-weight:800;
    color:#8994a9;
}
.egmt-title-group h1{
    font-size:25px;
    line-height:1.2;
    font-weight:800;
    color:#AB2B22;
    margin:1px 0 0;
}
.egmt-header-actions{
    display:flex;
    gap:8px;
    align-items:center;
    flex-wrap:wrap;
}
.egmt-btn-primary{
    background:#AB2B22!important;
    border:1px solid #AB2B22!important;
    color:#fff!important;
    border-radius:9px!important;
    font-weight:700!important;
    padding:9px 14px!important;
    box-shadow:0 3px 8px rgba(32,58,102,.12);
}
.egmt-btn-primary:hover{
    background:#172d51!important;
}
.egmt-btn-light{
    background:#fff!important;
    border:1px solid var(--egmt-line)!important;
    color:#344766!important;
    border-radius:9px!important;
    font-weight:650!important;
    padding:8px 12px!important;
}

.egmt-btn-light:hover{
    background:#f7f8fc!important;
    border-color:#bdc8dc!important;
}
.egmt-header-actions .mdi{
    font-size:17px;
    vertical-align:-2px;
    margin-right:4px;
}

.egmt-toolbar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    flex-wrap:wrap;
    padding:11px 12px;
    background:#fff;
    /* border:1px solid var(--egmt-line); */
    border-radius:12px;
}
.egmt-toolbar-left,.egmt-toolbar-right{
    display:flex;
    align-items:center;
    gap:11px;
    flex-wrap:wrap;
}
.egmt-view-switch{
    display:flex;
    align-items:center;
    border:1px solid var(--egmt-line);
    border-radius:9px;
    overflow:hidden;
    background:#fff;
}
.egmt-view-switch button{
    height:37px;
    min-width:56px;
    padding:0 14px;
    border:0;
    border-right:1px solid var(--egmt-line);
    background:#fff;
    color:#344766;
    font-size:13px;
    font-weight:650;
}
.egmt-view-switch button:last-child{
    border-right:0;
}
.egmt-view-switch button.active{
    background:#AB2B22;
    color:#fff;
}
.egmt-date-nav{
    display:flex;
    align-items:center;
    gap:4px;
}
.egmt-icon-btn{
    width:32px;
    height:34px;
    border:0;
    border-radius:8px;
    background:#fff;
    color:#425a7c;
    font-size:20px;
}
.egmt-icon-btn:hover{
    background:#eef1f8;
}
.egmt-today-btn{
    border:0;
    background:transparent;
    color:var(--egmt-purple);
    font-weight:800;
    font-size:13px;
    padding:6px 9px;
}
.egmt-calendar-select-wrap{
    min-width:145px;
}
.egmt-calendar-select-wrap .select2-container{
    min-width:145px!important;
}
.egmt-toolbar .select2-container--default .select2-selection--single{
    height:38px;
    border:1px solid var(--egmt-line);
    border-radius:9px;
}
.egmt-toolbar .select2-container--default .select2-selection--single .select2-selection__rendered{
    line-height:36px;
    color:#263b5f;
    font-size:13px;
    padding-left:12px;
}
.egmt-toolbar .select2-container--default .select2-selection--single .select2-selection__arrow{
    height:36px;
}
.egmt-search-wrap{
    position:relative;
    display:flex;
    align-items:center;
    width:270px;
    height:38px;
    border:1px solid var(--egmt-line);
    border-radius:9px;
    background:#fff;
    padding:0 9px;
    color:#8190a8;
}

.egmt-search-wrap>i{
    font-size:18px;
}
.egmt-search-wrap input{
    border:0!important;
    outline:0!important;
    box-shadow:none!important;
    min-width:0;
    width:100%;
    font-size:12px;
    padding:5px 7px;
    background:transparent;
}
.egmt-search-wrap button{
    border:0;
    background:transparent;
    color:#98a3b5;
    padding:0 2px;
}

.egmt-refresh-btn{
    width:38px;
    height:38px;
    padding:0!important;
}

.egmt-filter-row{
    display:flex;
    align-items:center;
    gap:8px;
    flex-wrap:wrap;
    margin:13px 0 15px;
}
.egmt-filter-pill{
    display:inline-flex;
    align-items:center;
    gap:7px;
    background:#fff;
    border:1px solid var(--egmt-line);
    border-radius:30px;
    padding:7px 14px;
    color:#344766;
    font-size:12px;
    font-weight:700;
    transition:.15s;
}
.egmt-filter-pill.active{
    background:#ab2b22;
    /* border-color:var(--egmt-purple); */
    color:#fff;
}
.egmt-filter-dot{
    height:9px;
    width:9px;
    border-radius:50%;
    background:#ab2b22;
    display:inline-block;
}
.egmt-filter-pill.active .egmt-filter-dot{
    background:white;
}

.egmt-main-grid{
    display:grid;
    grid-template-columns:minmax(0,1fr) 312px;
    gap:16px;
    align-items:start;
}
.egmt-calendar-card,.egmt-side-card{
    background:#fff;
    border:1px solid var(--egmt-line);
    border-radius:14px;
    overflow:hidden;
}
.egmt-calendar-heading{
    height:48px;
    display:flex;
    align-items:center;
    padding:0 17px;
    border-bottom:1px solid var(--egmt-line);
    font-size:15px;
    font-weight:800;
    color:#AB2B22;
}
.egmt-calendar-content{min-height:515px}.egmt-sidebar{display:flex;flex-direction:column;gap:15px}.egmt-side-title{height:49px;display:flex;align-items:center;justify-content:space-between;padding:0 15px;border-bottom:1px solid var(--egmt-line);font-size:14px;font-weight:800;color:#172b4d}.egmt-side-title .mdi{font-size:18px;margin-right:8px;color:var(--egmt-purple)}.egmt-rsvp-title{border-bottom:2px solid #d5a100}.egmt-rsvp-title>span:nth-child(2){margin-right:auto}.egmt-count{background:#f0eef9;color:var(--egmt-purple);border-radius:20px;padding:3px 8px;font-size:11px}.egmt-side-list{max-height:360px;overflow:auto}.egmt-side-item{padding:12px 15px;border-bottom:1px solid #edf0f6}.egmt-side-item:last-child{border-bottom:0}.egmt-side-item-title{font-size:13px;font-weight:750;color:#172b4d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.egmt-side-item-meta{font-size:11px;color:#7f8ba2;margin-top:4px}.egmt-side-actions{display:flex;gap:7px;margin-top:9px}.egmt-side-actions button{font-size:11px;padding:5px 12px;border-radius:7px;font-weight:750}.egmt-accept{border:1px solid #2f8240;background:#2f8240;color:#fff}.egmt-decline{border:1px solid #e4aaa6;background:#fff;color:#b42318}.egmt-upcoming-item{display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid #edf0f6;cursor:pointer}.egmt-upcoming-item:last-child{border-bottom:0}.egmt-upcoming-dot{width:9px;height:9px;border-radius:50%;flex:0 0 9px}.egmt-upcoming-name{font-size:12px;font-weight:750;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}.egmt-upcoming-time{font-size:11px;color:#76839b;white-space:nowrap}.egmt-side-empty{padding:22px 14px;text-align:center;color:#8793a8;font-size:12px}.egmt-text-btn{border:0;background:transparent;color:var(--egmt-purple);font-size:11px;font-weight:750}.egmt-side-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}.egmt-stat{border:1px solid var(--egmt-line);background:#fff;border-radius:11px;padding:12px}.egmt-stat strong{display:block;font-size:19px;color:#AB2B22}.egmt-stat span{font-size:10px;color:#7e8aa1;font-weight:700}
.egmt-week-grid{display:grid;grid-template-columns:64px repeat(7,minmax(0,1fr));overflow:auto}.egmt-week-day-head{height:45px;border-bottom:1px solid var(--egmt-line);border-right:1px solid #eef1f7;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#405678;background:#fff;position:sticky;top:0;z-index:3}.egmt-week-day-head.today span{background:var(--egmt-purple);color:#fff;border-radius:20px;padding:4px 11px}.egmt-time-head{height:45px;border-bottom:1px solid var(--egmt-line);background:#fff;position:sticky;top:0;z-index:3}.egmt-time-label{height:55px;border-right:1px solid #eef1f7;border-bottom:1px solid #edf0f6;text-align:right;padding:5px 8px 0 0;color:#8b97ad;font-size:10px;white-space:nowrap}.egmt-day-column{height:550px;position:relative;border-right:1px solid #eef1f7;background-image:repeating-linear-gradient(to bottom,transparent 0,transparent 54px,#edf0f6 54px,#edf0f6 55px);min-width:0}.egmt-day-column.today{background-color:#fafaff}.egmt-event-card{position:absolute;left:4px;right:4px;border-radius:8px;padding:6px 8px;color:#fff;overflow:hidden;cursor:pointer;z-index:1;box-shadow:0 1px 2px rgba(16,24,40,.09);font-size:11px;line-height:1.22}.egmt-event-card:hover{filter:brightness(.95);z-index:2}.egmt-event-card strong{display:block;font-size:11px;line-height:1.2;overflow:hidden}.egmt-event-card span{display:block;margin-top:2px;opacity:.9;font-size:10px}.egmt-event-card .egmt-event-people{position:absolute;right:5px;top:5px;font-size:9px;background:rgba(255,255,255,.22);border:1px solid rgba(255,255,255,.3);border-radius:10px;padding:2px 4px}.egmt-day-layout{display:grid;grid-template-columns:64px minmax(0,1fr);min-width:500px}.egmt-day-main{height:550px;position:relative;background-image:repeating-linear-gradient(to bottom,transparent 0,transparent 54px,#edf0f6 54px,#edf0f6 55px)}.egmt-day-main .egmt-event-card{left:12px;right:12px}.egmt-month-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border-left:1px solid #edf0f6}.egmt-month-day-head{background:#AB2B22;color:#fff;font-size:11px;font-weight:800;padding:11px 12px}.egmt-month-cell{min-height:116px;border-right:1px solid #edf0f6;border-bottom:1px solid #edf0f6;padding:7px 7px;background:#fff;overflow:hidden}.egmt-month-cell.muted{background:#fbfcfe;color:#a6b0c1}.egmt-month-date{font-size:12px;font-weight:800;color:#405678;margin-bottom:6px}.egmt-month-date.today{display:inline-flex;background:var(--egmt-purple);color:#fff;border-radius:20px;padding:2px 7px}.egmt-month-event{font-size:10px;color:#fff;padding:4px 6px;border-radius:5px;margin:3px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer;font-weight:700}.egmt-month-more{font-size:10px;color:var(--egmt-purple);font-weight:800;padding:3px 2px;cursor:pointer}.egmt-list-wrap{overflow:auto}.egmt-list-table{width:100%;border-collapse:collapse;min-width:850px}.egmt-list-table thead th{background:#AB2B22;color:#fff;font-size:11px;text-transform:uppercase;letter-spacing:.02em;padding:12px 13px;text-align:left;white-space:nowrap}.egmt-list-table tbody td{border-bottom:1px solid #edf0f6;padding:11px 13px;font-size:12px;color:#4f617e;vertical-align:middle}.egmt-list-table tbody tr:hover{background:#fafbfe}.egmt-list-title{font-size:12px;font-weight:800;color:#172b4d;cursor:pointer}.egmt-list-title-line{display:flex;align-items:center;gap:9px}.egmt-list-dot{width:9px;height:9px;border-radius:50%;flex:0 0 9px}.egmt-status{display:inline-flex;align-items:center;gap:5px;border-radius:20px;padding:4px 9px;background:#eaf1fb;color:#1465b8;font-size:10px;font-weight:800;white-space:nowrap}.egmt-status.completed{background:#edf5ef;color:#2b7b40}.egmt-status.cancelled{background:#faeceb;color:#b42318}.egmt-status.in-progress{background:#eff5ed;color:#23813b}.egmt-status.postponed{background:#f8f3e8;color:#aa7300}.egmt-rsvp-text{color:#bc7d00;font-size:11px;font-weight:750}.egmt-table-actions{display:flex;gap:5px}.egmt-table-actions button{border:1px solid var(--egmt-line);background:#fff;border-radius:6px;color:#5b6d89;font-size:12px;width:28px;height:27px}
.egmt-loading{display:flex;justify-content:center;align-items:center;gap:6px;padding:75px}.egmt-loading span{height:8px;width:8px;background:#8c83be;border-radius:50%;animation:egmtPulse .9s infinite alternate}.egmt-loading span:nth-child(2){animation-delay:.15s}.egmt-loading span:nth-child(3){animation-delay:.3s}@keyframes egmtPulse{to{opacity:.25;transform:translateY(-4px)}}
.egmt-modal .modal-content{border:0;border-radius:16px;overflow:visible;box-shadow:0 18px 55px rgba(22,36,64,.2)}.egmt-modal .modal-header{padding:16px 20px;border-bottom:1px solid var(--egmt-line)}.egmt-modal .modal-title{font-size:18px;font-weight:800;color:#AB2B22}.egmt-modal .modal-body{padding:18px 20px}.egmt-modal .modal-footer{padding:13px 20px;border-top:1px solid var(--egmt-line)}.egmt-modal .form-label{font-size:12px;font-weight:750;color:#353535;margin-bottom:6px}.egmt-modal .form-control,.egmt-modal .form-select{min-height:41px;border:1px solid #dce3ef;border-radius:9px;color:#263b5f;font-size:13px;box-shadow:none}.egmt-modal textarea.form-control{min-height:unset}.egmt-modal .form-control:focus,.egmt-modal .form-select:focus{border-color:#909bd0;box-shadow:0 0 0 3px rgba(81,67,154,.08)}.egmt-modal .select2-container{width:100%!important}.egmt-modal .select2-container--default .select2-selection--single,.egmt-modal .select2-container--default .select2-selection--multiple{min-height:41px;border:1px solid #dce3ef;border-radius:9px}.egmt-modal .select2-container--default .select2-selection--single .select2-selection__rendered{line-height:39px;padding-left:12px;color:#263b5f;font-size:13px}.egmt-modal .select2-container--default .select2-selection--single .select2-selection__arrow{height:39px}.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__rendered{padding:3px 6px}.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__choice{background:#efedfa;border:1px solid #d6d1f1;color:#423882;border-radius:6px;padding:3px 7px;font-size:11px}.egmt-segment{display:flex;border:1px solid #ab2b22;border-radius:9px;overflow:hidden}.egmt-segment button{flex:1;border:0;background:#fff;color:#3d3d3d;padding:8px;font-size:12px;font-weight:750}.egmt-segment button+button{border-left:1px solid #ab2b22}.egmt-segment button.active{background:#ab2b22;color:#fff}.egmt-file-drop{border:1px dashed #b9c5d8;border-radius:9px;padding:9px 12px;display:flex;align-items:center;gap:8px;color:#7887a1;font-size:11px;cursor:pointer;min-height:41px}.egmt-file-drop:hover{background:#fafaff;border-color:#948ac4}.egmt-file-drop .mdi{font-size:17px;color:var(--egmt-purple)}.egmt-invite-section{margin-top:20px;padding-top:18px;border-top:1px solid var(--egmt-line)}.egmt-invite-section h6{font-size:14px;font-weight:800;margin:0 0 3px;color:#AB2B22}.egmt-invite-section p{font-size:11px;color:#7c89a1;margin:0}.egmt-inline-manage{border:0;background:transparent;color:var(--egmt-purple);font-size:11px;font-weight:800}.egmt-invite-tabs{display:flex;align-items:center;gap:7px;border-bottom:1px solid var(--egmt-line);margin:15px 0 12px}.egmt-invite-tabs button{border:0;border-bottom:3px solid transparent;background:transparent;color:#8390a7;font-weight:800;font-size:12px;padding:9px 12px;margin-bottom:-1px}.egmt-invite-tabs button.active{border-color:var(--egmt-purple);color:var(--egmt-purple)}.egmt-invite-tabs button .mdi{font-size:15px;margin-right:4px;vertical-align:-2px}.egmt-selected-count{margin-left:auto;color:var(--egmt-purple);font-size:11px;font-weight:800;padding-bottom:8px}.egmt-invite-panel{padding:2px 0 5px}.egmt-form-hint{font-size:10px;color:#8490a7;margin-top:7px}.egmt-conflict{display:flex;align-items:flex-start;gap:10px;border:1px solid #e8c98c;background:#fff9ea;color:#745414;border-radius:10px;padding:11px 13px;margin-bottom:15px}.egmt-conflict>i{font-size:20px;color:#be8500}.egmt-conflict strong,.egmt-conflict span{display:block;font-size:12px}.egmt-conflict span{margin-top:3px;line-height:1.45}.egmt-info-note{display:flex;align-items:flex-start;gap:8px;background:#f7f6fc;border:1px solid #ded9f2;color:#ab2b22;border-radius:9px;padding:10px 12px;font-size:11px}.egmt-info-note .mdi{font-size:16px}
.egmt-manager-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;color:#344766;font-size:13px;font-weight:800}.egmt-manager-list{border:1px solid var(--egmt-line);border-radius:10px;overflow:hidden}.egmt-manager-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 13px;border-bottom:1px solid #edf0f6}.egmt-manager-row:last-child{border-bottom:0}.egmt-manager-row-main{display:flex;align-items:center;gap:10px;min-width:0}.egmt-manager-color{width:11px;height:11px;border-radius:50%;flex:0 0 11px}.egmt-manager-name{font-size:12px;font-weight:800;color:#263b5f}.egmt-manager-sub{font-size:10px;color:#8894a8;margin-top:2px}.egmt-manager-actions{display:flex;gap:5px;flex:0 0 auto}.egmt-manager-actions button{border:1px solid var(--egmt-line);background:#fff;color:#526783;border-radius:7px;padding:5px 8px;font-size:11px}.egmt-manager-actions .danger{color:#b42318}.egmt-manager-actions button:disabled{opacity:.45;cursor:not-allowed}
.egmt-drawer{width:min(560px,96vw)!important;border:0;box-shadow:-10px 0 40px rgba(24,38,66,.12)}.egmt-drawer-header{background:#AB2B22;color:#fff;padding:18px 20px}.egmt-drawer-header .offcanvas-title{font-size:18px;font-weight:850;max-width:430px;white-space:normal}.egmt-detail-badges{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.egmt-detail-badge{display:inline-flex;align-items:center;gap:5px;border-radius:20px;padding:4px 9px;background:rgba(255,255,255,.14);color:#fff;font-size:10px;font-weight:800}.egmt-drawer .offcanvas-body{padding:18px 20px}.egmt-detail-line{display:flex;align-items:flex-start;gap:12px;padding:10px 2px;color:#435673;font-size:13px}.egmt-detail-line .mdi{font-size:18px;color:#8794ad;min-width:20px}.egmt-detail-line strong{color:#263b5f}.egmt-detail-description{background:#f6f7fb;border-radius:10px;padding:12px 14px;color:#63718b;font-size:12px;line-height:1.5;margin:12px 0}.egmt-detail-section{margin-top:18px}.egmt-detail-section h6{color:#7c88a0;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;margin-bottom:10px}.egmt-rsvp-summary{display:flex;gap:13px;flex-wrap:wrap;font-size:12px;font-weight:800}.egmt-rsvp-summary .accepted{color:#2e883f}.egmt-rsvp-summary .declined{color:#c0392b}.egmt-rsvp-summary .tentative{color:#bc8200}.egmt-participant-list{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}.egmt-participant{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--egmt-line);border-radius:22px;padding:5px 9px 5px 5px;font-size:11px;color:#415573}.egmt-avatar{width:25px;height:25px;border-radius:50%;background:var(--egmt-purple);color:#fff;display:grid;place-items:center;font-size:9px;font-weight:800}.egmt-rsvp-tag{border-radius:20px;padding:3px 7px;font-size:9px;font-weight:800;background:#f0f2f6;color:#64738d}.egmt-history-row{border:1px solid var(--egmt-line);border-radius:9px;padding:11px 12px;margin-bottom:8px}.egmt-history-row strong{font-size:11px;color:#354c6e}.egmt-history-row span{display:block;font-size:10px;color:#808da4;margin-top:4px}.egmt-detail-actions{display:flex;flex-wrap:wrap;gap:7px;margin-top:18px}.egmt-detail-actions button{font-size:11px;font-weight:750;border-radius:8px;padding:7px 10px;border:1px solid var(--egmt-line);background:#fff;color:#405675}.egmt-detail-actions .cancel{color:#b42318;border-color:#e5aaa7}.egmt-detail-actions .complete{color:#2c7d3c;border-color:#b6d9bf}.egmt-attachment-row{display:flex;align-items:center;gap:9px;border-bottom:1px solid #edf0f6;padding:8px 0;font-size:11px}.egmt-attachment-row a{color:var(--egmt-purple);font-weight:750;text-decoration:none}
@media(max-width:1200px){.egmt-main-grid{grid-template-columns:minmax(0,1fr) 285px}.egmt-search-wrap{width:220px}}
@media(max-width:992px){.egmt-main-grid{grid-template-columns:1fr}.egmt-sidebar{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));align-items:start}.egmt-side-stats{grid-column:1/-1}}
@media(max-width:767px){#egmtApp{padding:10px}.egmt-title-group h1{font-size:21px}.egmt-header-actions{width:100%}.egmt-toolbar-left,.egmt-toolbar-right{width:100%}.egmt-search-wrap{flex:1;width:auto}.egmt-toolbar .egmt-calendar-select-wrap{flex:1}.egmt-sidebar{grid-template-columns:1fr}.egmt-filter-row{flex-wrap:nowrap;overflow:auto;padding-bottom:3px}.egmt-filter-pill{white-space:nowrap}.egmt-modal .modal-dialog{margin:8px}.egmt-modal .modal-body{padding:14px}.egmt-invite-tabs{gap:0}.egmt-invite-tabs button{padding:9px 8px}.egmt-selected-count{font-size:10px}.egmt-month-cell{min-height:78px;padding:5px}.egmt-month-event{font-size:9px}.egmt-week-grid{grid-template-columns:52px repeat(7,minmax(100px,1fr))}.egmt-time-label{padding-right:5px}.egmt-day-layout{grid-template-columns:52px minmax(0,1fr)}}


/* -------------------------------------------------------------
   EGC application theme - Meetings page Select3 / Select2 only
   Brand colours sampled from the supplied application screenshots:
   red #AB2B22 and amber #FBA919.
   ------------------------------------------------------------- */
#egmtApp select.select3:focus,
.egmt-modal select.select3:focus {
    border-color: #AB2B22 !important;
    box-shadow: 0 0 0 3px rgba(171, 43, 34, .12) !important;
    outline: 0;
}

#egmtApp .select2-container--default .select2-selection--single,
#egmtApp .select2-container--default .select2-selection--multiple,
.egmt-modal .select2-container--default .select2-selection--single,
.egmt-modal .select2-container--default .select2-selection--multiple {
    background-color: #fff !important;
    border: 1px solid #D8DEE8 !important;
    border-radius: 9px !important;
    transition: border-color .15s ease, box-shadow .15s ease;
}

#egmtApp .select2-container--default.select2-container--focus .select2-selection--single,
#egmtApp .select2-container--default.select2-container--focus .select2-selection--multiple,
#egmtApp .select2-container--default.select2-container--open .select2-selection--single,
#egmtApp .select2-container--default.select2-container--open .select2-selection--multiple,
.egmt-modal .select2-container--default.select2-container--focus .select2-selection--single,
.egmt-modal .select2-container--default.select2-container--focus .select2-selection--multiple,
.egmt-modal .select2-container--default.select2-container--open .select2-selection--single,
.egmt-modal .select2-container--default.select2-container--open .select2-selection--multiple {
    border-color: #AB2B22 !important;
    box-shadow: 0 0 0 3px rgba(171, 43, 34, .11) !important;
}

#egmtApp .select2-container--default .select2-selection--single .select2-selection__rendered,
.egmt-modal .select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #29364A !important;
}

#egmtApp .select2-container--default .select2-selection--placeholder,
.egmt-modal .select2-container--default .select2-selection--placeholder {
    color: #8A94A5 !important;
}

#egmtApp .select2-container--default .select2-selection--single .select2-selection__arrow b,
.egmt-modal .select2-container--default .select2-selection--single .select2-selection__arrow b {
    border-color: #AB2B22 transparent transparent transparent !important;
}

#egmtApp .select2-container--default .select2-selection__clear,
.egmt-modal .select2-container--default .select2-selection__clear {
    color: #AB2B22 !important;
    font-weight: 800;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-selection__rendered,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__rendered {
    padding: 3px 6px;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-selection__choice,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background: #FFF2D8 !important;
    border: 1px solid #F2C66D !important;
    border-radius: 6px !important;
    color: #7F2B20 !important;
    padding: 3px 8px !important;
    font-size: 11px;
    font-weight: 650;
    margin-top: 4px;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-selection__choice__remove,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
    color: #AB2B22 !important;
    border-right: 1px solid rgba(171, 43, 34, .18) !important;
    margin-right: 6px;
    padding-right: 5px;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover {
    background: #AB2B22 !important;
    color: #fff !important;
}

#egmtApp .select2-dropdown,
.egmt-modal .select2-dropdown {
    background: #fff !important;
    border: 1px solid #AB2B22 !important;
    border-radius: 10px !important;
    box-shadow: 0 12px 28px rgba(43, 28, 25, .16) !important;
    overflow: hidden;
    z-index: 1065;
}

#egmtApp .select2-results__option,
.egmt-modal .select2-results__option {
    color: #29364A;
    font-size: 12px;
    line-height: 1.4;
    padding: 9px 12px;
    transition: background-color .12s ease, color .12s ease;
}

#egmtApp .select2-results__option[aria-selected="true"],
.egmt-modal .select2-results__option[aria-selected="true"] {
    background: #FFF2D8 !important;
    color: #7F2B20 !important;
    font-weight: 700;
}

#egmtApp .select2-results__option--highlighted[aria-selected],
.egmt-modal .select2-results__option--highlighted[aria-selected] {
    background: #AB2B22 !important;
    color: #fff !important;
}

#egmtApp .select2-results__option[aria-disabled="true"],
.egmt-modal .select2-results__option[aria-disabled="true"] {
    color: #A0A8B5 !important;
    background: #F7F8FA !important;
}

#egmtApp .select2-search--dropdown .select2-search__field,
.egmt-modal .select2-search--dropdown .select2-search__field {
    min-height: 36px;
    border: 1px solid #D8DEE8 !important;
    border-radius: 7px !important;
    color: #29364A;
    font-size: 12px;
    padding: 6px 9px;
    outline: 0;
}

#egmtApp .select2-search--dropdown .select2-search__field:focus,
.egmt-modal .select2-search--dropdown .select2-search__field:focus {
    border-color: #AB2B22 !important;
    box-shadow: 0 0 0 2px rgba(171, 43, 34, .10) !important;
}

#egmtApp .select2-results__group,
.egmt-modal .select2-results__group {
    background: #FFF8EA;
    color: #AB2B22;
    font-size: 11px;
    font-weight: 800;
    padding: 8px 12px;
}

#egmtApp .select2-results > .select2-results__options,
.egmt-modal .select2-results > .select2-results__options {
    max-height: 230px;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-search__field,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-search__field {
    color: #29364A;
    font-size: 12px;
    min-height: 25px;
    margin-top: 5px;
}

#egmtApp .select2-container--default .select2-selection--multiple .select2-search__field::placeholder,
.egmt-modal .select2-container--default .select2-selection--multiple .select2-search__field::placeholder {
    color: #8A94A5;
}

</style>

<div id="egmtApp" class="eg-knowledge-page" data-can-manage-settings="{{ $meetingCanManage ? '1' : '0' }}">

    <div class="card card-action">
        <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Meetings </h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> Tool Mangement
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                            Meetings
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-2">
                
                @if($meetingCanManage)
                    <button type="button" class="btn btn-label-primary shadow-none" id="egmtManageCategories"><i class="mdi mdi-tag-multiple-outline"></i><span>Manage categories</span></button>
                    <button type="button" class="btn btn-label-primary shadow-none" id="egmtManageTeams"><i class="mdi mdi-account-group-outline"></i><span>Manage teams</span></button>
                @endif
                <button type="button" class="btn btn-primary shadow-none" id="egmtScheduleMeeting"><i class="mdi mdi-plus"></i> Schedule meeting</button>
                
            </div>
        </div>
        <div class="card-body">
            <div class="egmt-toolbar">
                <div class="egmt-toolbar-left">
                    <div class="egmt-view-switch" role="group" aria-label="Meeting calendar view">
                        <button type="button" data-view="day">Day</button>
                        <button type="button" data-view="week" class="active">Week</button>
                        <button type="button" data-view="month">Month</button>
                        <button type="button" data-view="list">List</button>
                    </div>
                    <div class="egmt-date-nav">
                        <button type="button" class="egmt-icon-btn" id="egmtPrev"><i class="mdi mdi-chevron-left"></i></button>
                        <button type="button" class="egmt-today-btn text-primary" id="egmtToday">Today</button>
                        <button type="button" class="egmt-icon-btn" id="egmtNext"><i class="mdi mdi-chevron-right"></i></button>
                    </div>
                    <div class="egmt-calendar-select-wrap">
                        <select class="form-select select3" id="egmtCalendarScope" aria-label="Calendar scope">
                            <option value="my">My Calendar</option>
                            <option value="team">My Team</option>
                            <option value="department">Department</option>
                            <option value="company">Company</option>
                        </select>
                    </div>
                    <button type="button" class="btn btn-warning text-black shadow-none egmt-external-btn " id="egmtExternalEvents"><i class="mdi mdi-calendar-arrow-right"></i> External events</button>
                </div>
                <div class="egmt-toolbar-right">
                    <div class="egmt-search-wrap"><i class="mdi mdi-magnify"></i><input type="search" id="egmtSearch" placeholder="Search meetings, people or venue"><button type="button" id="egmtSearchClear" aria-label="Clear search"><i class="mdi mdi-close"></i></button></div>
                    <button type="button" class="btn btn-warning text-black shadow-none egmt-refresh-btn" id="egmtRefresh" title="Refresh"><i class="mdi mdi-refresh"></i></button>
                </div>
            </div>
            <div class="egmt-filter-row" id="egmtCategoryFilters">
                <button type="button" class="egmt-filter-pill active" data-category="all"><span class="egmt-filter-dot"></span>All</button>
            </div>
        
            <div class="row">
                <div class="col-lg-12">
                    <div class="egmt-main-grid">
                        <main class="egmt-calendar-card">
                            <div class="egmt-calendar-heading" id="egmtCalendarHeading">Loading calendar…</div>
                            <div id="egmtCalendarContent" class="egmt-calendar-content">
                                <div class="egmt-loading"><span></span><span></span><span></span></div>
                            </div>
                        </main>
                        <aside class="egmt-sidebar">
                            <section class="egmt-side-card">
                                <div class="egmt-side-title egmt-rsvp-title"><i class="mdi mdi-email-outline"></i><span>Awaiting my RSVP</span><span class="egmt-count" id="egmtRsvpCount">0</span></div>
                                <div id="egmtRsvpList" class="egmt-side-list"><div class="egmt-side-empty">Loading invitations…</div></div>
                            </section>
                            <section class="egmt-side-card">
                                <div class="egmt-side-title"><span>Upcoming today</span><button type="button" class="egmt-text-btn" id="egmtViewToday">View all</button></div>
                                <div id="egmtUpcomingList" class="egmt-side-list"><div class="egmt-side-empty">Loading meetings…</div></div>
                            </section>
                            <section class="egmt-side-stats" id="egmtStats"></section>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>



{{-- Schedule / edit meeting --}}
<div class="modal fade egmt-modal" id="egmtScheduleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <div><h5 class="modal-title" id="egmtScheduleTitle">Schedule meeting</h5><div class="small text-muted" id="egmtScheduleSubtitle">Invite people, teams or departments and manage responses.</div></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="egmtScheduleForm" enctype="multipart/form-data">
                <input type="hidden" name="meeting_id" id="egmtMeetingId">
                <div class="modal-body">
                    <div id="egmtConflictNotice" class="egmt-conflict d-none"><i class="mdi mdi-alert-outline"></i><div><strong>Scheduling conflict detected</strong><span id="egmtConflictText"></span></div></div>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label" for="egmtTitle">Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="egmtTitle" name="title" maxlength="240" placeholder="e.g. Client kickoff — SVN College" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="egmtAgenda">Agenda</label>
                            <textarea class="form-control" id="egmtAgenda" name="agenda" rows="3" maxlength="10000" placeholder="Add the meeting agenda, goals and preparation notes…"></textarea>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label" for="egmtDate">Date <span class="text-danger">*</span></label>
                            <input type="text" class="form-control common_datepicker_cust" id="egmtDate" readonly required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="egmtStart">Start <span class="text-danger">*</span></label>
                            <input type="text" class="form-control custom_time_picker" id="egmtStart" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="egmtEnd">End <span class="text-danger">*</span></label>
                            <input type="text" class="form-control custom_time_picker" id="egmtEnd" required>
                        </div>
                        <div class="col-lg-6">
                            <label class="form-label">Where</label>
                            <div class="egmt-segment" id="egmtWhereSwitch"><button type="button" class="active" data-where="venue">Venue</button><button type="button" data-where="online">Online link</button></div>
                            <input type="text" class="form-control mt-2" id="egmtVenue" name="venue" maxlength="500" placeholder="e.g. Conference Room A">
                            <input type="url" class="form-control mt-2 d-none" id="egmtMeetingUrl" name="meeting_url" maxlength="2000" placeholder="https://meet.google.com/…">
                        </div>
                        <div class="col-lg-6">
                            <div class="row g-2">
                                <div class="col-sm-6">
                                    <label class="form-label" for="egmtReminder">Reminder</label>
                                    <select class="form-select select3" id="egmtReminder" name="reminder_minutes">
                                        <option value="0">No reminder</option><option value="10">10 minutes</option><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="60">1 hour</option><option value="120">2 hours</option><option value="1440">1 day</option>
                                    </select>
                                </div>
                                <div class="col-sm-6">
                                    <label class="form-label" for="egmtVisibility">Visibility</label>
                                    <select class="form-select select3" id="egmtVisibility" name="visibility">
                                        <option value="Private">Private</option><option value="Company" selected>Company</option><option value="Group">Group</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label" for="egmtAttachments">Attachments</label>
                                    <label class="egmt-file-drop" for="egmtAttachments"><i class="mdi mdi-paperclip"></i><span id="egmtAttachmentLabel">Add attachments (PDF, Office files, images or ZIP; max 20 MB each)</span></label>
                                    <input type="file" class="d-none" id="egmtAttachments" name="attachments[]" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.png,.jpg,.jpeg,.txt,.csv,.zip">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                <label class="form-label mb-0" for="egmtCategory">Category</label>
                                @if($meetingCanManage)<button type="button" class="egmt-inline-manage" id="egmtManageCategoriesInline"><i class="mdi mdi-cog-outline"></i> Manage categories</button>@endif
                            </div>
                            <select class="form-select select3" id="egmtCategory" name="category_id" data-placeholder="Select meeting category"><option value="">Select category</option></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="egmtStatus">Meeting status</label>
                            <select class="form-select select3" id="egmtStatus" name="status"><option value="Scheduled">Scheduled</option><option value="In Progress">In Progress</option><option value="Completed">Completed</option></select>
                        </div>
                    </div>

                    <div class="egmt-invite-section">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div><h6>Invite participants</h6><p>Select individual people, a saved team or a department. Team and department members are expanded into meeting invitees.</p></div>
                            @if($meetingCanManage)<button type="button" class="egmt-inline-manage" id="egmtManageTeamsInline"><i class="mdi mdi-account-cog-outline"></i> Manage teams</button>@endif
                        </div>
                        <div class="egmt-invite-tabs" role="tablist">
                            <button type="button" class="active" data-invite-tab="people"><i class="mdi mdi-account-outline"></i> People</button>
                            <button type="button" data-invite-tab="teams"><i class="mdi mdi-account-group-outline"></i> Teams</button>
                            <button type="button" data-invite-tab="departments"><i class="mdi mdi-domain"></i> Departments</button>
                            <span class="egmt-selected-count" id="egmtSelectedCount">1 participant selected</span>
                        </div>
                        <div class="egmt-invite-panel" data-invite-panel="people">
                            <label class="form-label" for="egmtPeople">Select people</label>
                            <select class="form-select select3" id="egmtPeople" multiple data-placeholder="Search staff by name, ID or email"></select>
                            <div class="egmt-form-hint">You are automatically added as the meeting organiser.</div>
                        </div>
                        <div class="egmt-invite-panel d-none" data-invite-panel="teams">
                            <label class="form-label" for="egmtTeams">Select saved teams</label>
                            <select class="form-select select3" id="egmtTeams" multiple data-placeholder="Choose one or more teams"></select>
                            <div class="egmt-form-hint">All active members of the selected teams receive an invitation. Team membership is managed separately.</div>
                        </div>
                        <div class="egmt-invite-panel d-none" data-invite-panel="departments">
                            <label class="form-label" for="egmtDepartments">Select departments</label>
                            <select class="form-select select3" id="egmtDepartments" multiple data-placeholder="Choose one or more departments"></select>
                            <div class="egmt-form-hint">All active staff in the selected departments are included.</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn egmt-btn-primary" id="egmtSaveMeeting"><i class="mdi mdi-calendar-check-outline"></i> Schedule &amp; send invites</button></div>
            </form>
        </div>
    </div>
</div>

{{-- Category manager --}}
<div class="modal fade egmt-modal" id="egmtCategoryManageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><div><h5 class="modal-title">Manage meeting categories</h5><div class="small text-muted">Create and maintain category names and calendar colours.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="egmt-manager-toolbar"><span>Categories</span><button type="button" class="btn egmt-btn-primary btn-sm" id="egmtAddCategory"><i class="mdi mdi-plus"></i> Add category</button></div><div id="egmtCategoryManagerList" class="egmt-manager-list"><div class="egmt-side-empty">Loading categories…</div></div></div>
        <div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Close</button></div>
    </div></div>
</div>
<div class="modal fade egmt-modal" id="egmtCategoryFormModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="egmtCategoryFormTitle">Add category</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <form id="egmtCategoryForm"><input type="hidden" id="egmtCategoryId"><div class="modal-body">
            <div class="mb-3"><label class="form-label" for="egmtCategoryName">Category name <span class="text-danger">*</span></label><input type="text" class="form-control" id="egmtCategoryName" maxlength="160" required placeholder="e.g. Review"></div>
            <div class="mb-3"><label class="form-label" for="egmtCategoryColor">Calendar colour</label><div class="d-flex align-items-center gap-2"><input type="color" class="form-control form-control-color" id="egmtCategoryColor" value="#ab2b22"><span class="small text-muted">Choose a colour used for meeting cards and filters.</span></div></div>
            <div><label class="form-label" for="egmtCategoryDescription">Description</label><textarea class="form-control" id="egmtCategoryDescription" rows="2" maxlength="500" placeholder="Optional description"></textarea></div>
        </div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn egmt-btn-primary" id="egmtSaveCategory">Save category</button></div></form>
    </div></div>
</div>

{{-- Team manager --}}
<div class="modal fade egmt-modal" id="egmtTeamManageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><div><h5 class="modal-title">Manage meeting teams</h5><div class="small text-muted">Create reusable groups of staff for meeting invitations.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="egmt-manager-toolbar"><span>Saved teams</span><button type="button" class="btn egmt-btn-primary btn-sm" id="egmtAddTeam"><i class="mdi mdi-plus"></i> Add team</button></div><div id="egmtTeamManagerList" class="egmt-manager-list"><div class="egmt-side-empty">Loading teams…</div></div></div>
        <div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Close</button></div>
    </div></div>
</div>
<div class="modal fade egmt-modal" id="egmtTeamFormModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="egmtTeamFormTitle">Add team</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <form id="egmtTeamForm"><input type="hidden" id="egmtTeamId"><div class="modal-body">
            <div class="row g-3"><div class="col-md-6"><label class="form-label" for="egmtTeamName">Team name <span class="text-danger">*</span></label><input type="text" class="form-control" id="egmtTeamName" maxlength="160" required placeholder="e.g. Marketing Dept"></div><div class="col-md-6"><label class="form-label" for="egmtTeamDescription">Description</label><input type="text" class="form-control" id="egmtTeamDescription" maxlength="500" placeholder="Optional team purpose"></div><div class="col-12"><label class="form-label" for="egmtTeamMembers">Team members <span class="text-danger">*</span></label><select class="form-select select3" id="egmtTeamMembers" multiple data-placeholder="Search and select active staff"></select><div class="egmt-form-hint">Only active staff in the selected company can be added to a team.</div></div></div>
        </div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn egmt-btn-primary" id="egmtSaveTeam">Save team</button></div></form>
    </div></div>
</div>

{{-- Meeting detail drawer --}}
<div class="offcanvas offcanvas-end egmt-drawer" tabindex="-1" id="egmtDetailDrawer" aria-labelledby="egmtDetailTitle">
    <div class="offcanvas-header egmt-drawer-header"><div><h5 class="offcanvas-title" id="egmtDetailTitle">Meeting details</h5><div id="egmtDetailBadges" class="egmt-detail-badges"></div></div><button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div>
    <div class="offcanvas-body" id="egmtDetailBody"><div class="egmt-side-empty">Select a meeting to view its details.</div></div>
</div>

{{-- Cancel meeting --}}
<div class="modal fade egmt-modal" id="egmtCancelModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-md modal-dialog-centered"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title">Cancel meeting</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <form id="egmtCancelForm"><div class="modal-body"><input type="hidden" id="egmtCancelId"><label class="form-label" for="egmtCancelReason">Reason (required) <span class="text-danger">*</span></label><textarea class="form-control" id="egmtCancelReason" rows="4" maxlength="500" required placeholder="Participants will see this reason"></textarea><div class="egmt-info-note mt-3"><i class="mdi mdi-information-outline"></i> Participants will be notified that the meeting is cancelled.</div></div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Back</button><button type="submit" class="btn btn-danger" id="egmtCancelSubmit">Cancel meeting</button></div></form>
</div></div></div>

{{-- Reschedule meeting --}}
<div class="modal fade egmt-modal" id="egmtRescheduleModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-md modal-dialog-centered"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title">Reschedule meeting</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <form id="egmtRescheduleForm"><div class="modal-body"><input type="hidden" id="egmtRescheduleId"><div class="row g-3"><div class="col-md-6"><label class="form-label" for="egmtRescheduleDate">New date <span class="text-danger">*</span></label><input type="date" class="form-control" id="egmtRescheduleDate" required></div><div class="col-md-3"><label class="form-label" for="egmtRescheduleStart">Start <span class="text-danger">*</span></label><input type="time" class="form-control" id="egmtRescheduleStart" required></div><div class="col-md-3"><label class="form-label" for="egmtRescheduleEnd">End <span class="text-danger">*</span></label><input type="time" class="form-control" id="egmtRescheduleEnd" required></div><div class="col-12"><label class="form-label" for="egmtRescheduleReason">Reason (required) <span class="text-danger">*</span></label><textarea class="form-control" id="egmtRescheduleReason" rows="3" maxlength="500" required placeholder="Participants will see this reason"></textarea></div></div><div class="egmt-info-note mt-3"><i class="mdi mdi-information-outline"></i> Participants will be notified and their previous RSVPs will reset.</div></div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Back</button><button type="submit" class="btn egmt-btn-primary" id="egmtRescheduleSubmit">Reschedule meeting</button></div></form>
</div></div></div>

{{-- External events --}}
<div class="modal fade egmt-modal" id="egmtExternalModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
    <div class="modal-header"><div><h5 class="modal-title">External events</h5><div class="small text-muted">Events from the ERP Events module that overlap this calendar period.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body" id="egmtExternalList"><div class="egmt-side-empty">Loading events…</div></div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Close</button></div>
</div></div></div>

<div class="modal fade egmt-modal" id="egmtConfirmModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="egmtConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="egmtConfirmText"></div><div class="modal-footer"><button type="button" class="btn egmt-btn-light" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger" id="egmtConfirmYes">Confirm</button></div></div></div></div>

<script type="application/json" id="egmtRouteConfig">{!! json_encode($meetingRoutes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>

<script>
var egmtRoutes = {};
var egmtState = {
    view: 'week', date: new Date(), scope: 'my', category: 'all', search: '',
    lookups: {categories: [], teams: [], departments: [], staff: [], companies: []},
    meetings: [], dashboard: {}, currentMeeting: null, activeWhere: 'venue',
    editingCategoryId: null, editingTeamId: null, editMeetingId: null,
    pendingConfirm: null, currentRange: null, returnToSchedule: false,
    settingsTransition: false, keepSettingsOpen: false
};
var egmtModals = {};

function egmtEscape(value) {
    return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, function (ch) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch];
    });
}
function egmtSafeColor(value) {
    return /^#[0-9a-f]{6}$/i.test(String(value || '')) ? value : '#ab2b22';
}
function egmtInitials(name) {
    return String(name || 'User').trim().split(/\s+/).slice(0,2).map(function (part) { return part.charAt(0); }).join('').toUpperCase();
}
function egmtNotify(message, type) {
    var text = String(message || 'Completed');
    if (window.toastr && typeof toastr[type || 'success'] === 'function') toastr[type || 'success'](text);
    else if (window.Swal && typeof Swal.fire === 'function') Swal.fire({toast:true,position:'top-end',icon:type === 'error' ? 'error' : 'success',title:text,showConfirmButton:false,timer:2800});
    else window.alert(text);
}
function egmtAjax(method, url, data, options) {
    var config = options || {};
    return $.ajax({
        url: url, method: method, data: data || {},
        processData: config.processData !== undefined ? config.processData : true,
        contentType: config.contentType !== undefined ? config.contentType : 'application/x-www-form-urlencoded; charset=UTF-8',
        headers: {'X-CSRF-TOKEN': egmtRoutes.csrf, 'X-Requested-With': 'XMLHttpRequest'},
        dataType: 'json'
    });
}
function egmtErrorMessage(xhr, fallback) {
    var response = xhr && xhr.responseJSON ? xhr.responseJSON : {};
    var errors = response.errors || {};
    var key = Object.keys(errors)[0];
    if (key && Array.isArray(errors[key]) && errors[key][0]) return errors[key][0];
    return response.message || fallback || 'Unable to complete this request.';
}
function egmtUrl(id, suffix) {
    var url = egmtRoutes.base + '/' + encodeURIComponent(id);
    return suffix ? url + '/' + suffix : url;
}
function egmtDateKey(date) {
    var d = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return d.toISOString().slice(0,10);
}
function egmtParseDate(value) {
    if (!value) return null;
    var raw = String(value).replace(' ', 'T');
    return new Date(raw);
}
function egmtTime(value) {
    var date = egmtParseDate(value);
    if (!date || isNaN(date.getTime())) return '—';
    return date.toLocaleTimeString([], {hour:'numeric', minute:'2-digit'});
}
function egmtDateLabel(date, options) {
    return date.toLocaleDateString([], options || {weekday:'short', day:'numeric', month:'short'});
}
function egmtWeekStart(date) {
    var result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    var day = (result.getDay() + 6) % 7;
    result.setDate(result.getDate() - day);
    result.setHours(0,0,0,0);
    return result;
}
function egmtGetRange() {
    var start, end, label;
    if (egmtState.view === 'day') {
        start = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth(), egmtState.date.getDate());
        end = new Date(start); end.setDate(end.getDate() + 1);
        label = egmtState.date.toLocaleDateString([], {weekday:'long', day:'numeric', month:'long', year:'numeric'});
    } else if (egmtState.view === 'week') {
        start = egmtWeekStart(egmtState.date); end = new Date(start); end.setDate(end.getDate() + 7);
        var last = new Date(end); last.setDate(last.getDate() - 1);
        label = start.toLocaleDateString([], {day:'numeric', month:'short'}) + ' – ' + last.toLocaleDateString([], {day:'numeric', month:'short', year:'numeric'});
    } else if (egmtState.view === 'month') {
        start = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth(), 1);
        end = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth() + 1, 0);
        label = egmtState.date.toLocaleDateString([], {month:'long', year:'numeric'});
        start = egmtWeekStart(start);
        end = new Date(end.getFullYear(), end.getMonth(), end.getDate());
        while (end.getDay() !== 0) end.setDate(end.getDate() + 1);
        end.setDate(end.getDate() + 1);
    } else {
        start = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth(), 1);
        end = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth() + 1, 0); end.setHours(23,59,59,999);
        label = egmtState.date.toLocaleDateString([], {month:'long', year:'numeric'});
    }
    return {start:start, end:end, label:label, startKey:egmtDateKey(start), endKey:egmtDateKey(new Date(end.getTime() - 1))};
}
function egmtBootstrapModal(id) {
    if (!egmtModals[id]) egmtModals[id] = bootstrap.Modal.getOrCreateInstance(document.getElementById(id));
    return egmtModals[id];
}
function egmtOffcanvas(id) {
    if (!egmtModals[id]) egmtModals[id] = bootstrap.Offcanvas.getOrCreateInstance(document.getElementById(id));
    return egmtModals[id];
}
function egmtInitSelect3(scope) {
    var $scope = scope ? $(scope) : $(document);
    if (typeof $.fn.select2 !== 'function') return;

    $scope.find('select.select3').addBack('select.select3').each(function () {
        var $select = $(this);

        if ($select.hasClass('select2-hidden-accessible')) {
            $select.select2('destroy');
        }

        var modal = $select.closest('.egmt-modal');
        var meetingsApp = $select.closest('#egmtApp');
        var config = {
            width: '100%',
            allowClear: true,
            placeholder: $select.data('placeholder') || 'Select'
        };

        // Keep the popup inside this Meetings page so its theme remains local.
        // Modal dropdowns stay inside their modal to preserve Bootstrap layering.
        if (modal.length) {
            config.dropdownParent = modal;
        } else if (meetingsApp.length) {
            config.dropdownParent = meetingsApp;
        }

        if ($select.prop('multiple')) {
            config.closeOnSelect = false;
        }

        $select.select2(config);
    });
}
function egmtSetSelect(selector, items, selected, placeholder, multiple) {
    var $select = $(selector);
    var values = (Array.isArray(selected) ? selected : (selected === null || selected === undefined || selected === '' ? [] : [selected])).filter(function (value) { return value !== null && value !== undefined && value !== ''; }).map(String);
    $select.empty();
    if (!multiple) $select.append(new Option(placeholder || 'Select', '', false, false));
    (items || []).forEach(function (item) {
        var value = String(item.value !== undefined ? item.value : item.sno);
        var label = item.label !== undefined ? item.label : (item.category_name || item.team_name || item.department_name || item.staff_name || item.name || '');
        $select.append(new Option(label, value, false, values.indexOf(value) >= 0));
    });
    if (multiple) $select.val(values.filter(Boolean)); else $select.val(values[0] || '');
    if ($select.hasClass('select2-hidden-accessible')) $select.trigger('change.select2');
    else $select.trigger('change');
}
function egmtReloadSelects() {
    egmtSetSelect('#egmtCategory', egmtState.lookups.categories.map(function (item) { return {sno:item.sno, category_name:item.category_name}; }), egmtState.currentMeeting && egmtState.currentMeeting.category_id ? [egmtState.currentMeeting.category_id] : [], 'Select category', false);
    egmtSetSelect('#egmtPeople', egmtState.lookups.staff.map(function (item) { return {sno:item.sno, staff_name:item.staff_name + (item.department_name ? ' · ' + item.department_name : '')}; }), egmtState.currentMeeting ? (egmtState.currentMeeting.people_ids || []) : [], '', true);
    egmtSetSelect('#egmtTeams', egmtState.lookups.teams.map(function (item) { return {sno:item.sno, team_name:item.team_name + ' (' + (item.member_count || 0) + ')'}; }), egmtState.currentMeeting ? (egmtState.currentMeeting.team_ids || []) : [], '', true);
    egmtSetSelect('#egmtDepartments', egmtState.lookups.departments, egmtState.currentMeeting ? (egmtState.currentMeeting.department_ids || []) : [], '', true);
    egmtSetSelect('#egmtTeamMembers', egmtState.lookups.staff, egmtState.editingTeamMembers || [], '', true);
    egmtInitSelect3('#egmtScheduleModal'); egmtInitSelect3('#egmtTeamFormModal');
}
function egmtLoadLookups() {
    return egmtAjax('GET', egmtRoutes.lookups, {}).done(function (response) {
        egmtState.lookups = response.data || egmtState.lookups;
        egmtRenderCategoryFilters();
        egmtReloadSelects();
    }).fail(function (xhr) { egmtNotify(egmtErrorMessage(xhr, 'Unable to load meeting settings.'), 'error'); });
}
function egmtRenderCategoryFilters() {
    var html = '<button type="button" class="egmt-filter-pill ' + (egmtState.category === 'all' ? 'active' : '') + '" data-category="all"><span class="egmt-filter-dot"></span>All</button>';
    (egmtState.lookups.categories || []).forEach(function (category) {
        var color = egmtSafeColor(category.color);
        html += '<button type="button" class="egmt-filter-pill ' + (String(egmtState.category) === String(category.sno) ? 'active' : '') + '" data-category="' + egmtEscape(category.sno) + '"><span class="egmt-filter-dot" style="background:' + color + '"></span>' + egmtEscape(category.category_name) + '</button>';
    });
    $('#egmtCategoryFilters').html(html);
}
function egmtLoadDashboard() {
    return egmtAjax('GET', egmtRoutes.dashboard, {scope:egmtState.scope}).done(function (response) {
        egmtState.dashboard = response.data || {};
        egmtRenderDashboard();
    }).fail(function () {
        $('#egmtRsvpList,#egmtUpcomingList').html('<div class="egmt-side-empty">Unable to load meeting summary.</div>');
    });
}
function egmtRenderDashboard() {
    var data = egmtState.dashboard || {};
    var pending = data.pending_rsvp || [];
    var upcoming = data.upcoming_today || [];
    $('#egmtRsvpCount').text(pending.length);
    $('#egmtRsvpList').html(pending.length ? pending.map(function (item) {
        return '<div class="egmt-side-item"><div class="egmt-side-item-title" data-meeting-open="' + item.sno + '">' + egmtEscape(item.title) + '</div><div class="egmt-side-item-meta">' + egmtEscape(egmtRelativeMeetingTime(item.start_at)) + ' · ' + egmtEscape(egmtTime(item.start_at)) + '</div><div class="egmt-side-actions"><button type="button" class="egmt-accept" data-meeting-rsvp="accepted" data-id="' + item.sno + '">Accept</button><button type="button" class="egmt-decline" data-meeting-rsvp="declined" data-id="' + item.sno + '">Decline</button></div></div>';
    }).join('') : '<div class="egmt-side-empty">You have no pending meeting responses.</div>');
    $('#egmtUpcomingList').html(upcoming.length ? upcoming.map(function (item) {
        return '<div class="egmt-upcoming-item" data-meeting-open="' + item.sno + '"><span class="egmt-upcoming-dot" style="background:' + egmtSafeColor(item.category_color) + '"></span><span class="egmt-upcoming-name">' + egmtEscape(item.title) + '</span><span class="egmt-upcoming-time">' + egmtEscape(egmtTime(item.start_at)) + '</span></div>';
    }).join('') : '<div class="egmt-side-empty">No meetings scheduled for today.</div>');
    var stats = data.stats || {};
    $('#egmtStats').html('<div class="egmt-stat"><strong>' + egmtEscape(stats.today || 0) + '</strong><span>Meetings today</span></div><div class="egmt-stat"><strong>' + egmtEscape(stats.upcoming || 0) + '</strong><span>Upcoming</span></div><div class="egmt-stat"><strong>' + egmtEscape(stats.pending_rsvp || 0) + '</strong><span>RSVP pending</span></div><div class="egmt-stat"><strong>' + egmtEscape(stats.in_progress || 0) + '</strong><span>In progress</span></div>');
}
function egmtRelativeMeetingTime(value) {
    var date = egmtParseDate(value);
    if (!date) return '';
    var today = new Date();
    if (date.toDateString() === today.toDateString()) return 'Today';
    var tomorrow = new Date(today); tomorrow.setDate(today.getDate()+1);
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    return date.toLocaleDateString([], {weekday:'short', day:'numeric', month:'short'});
}
function egmtLoadMeetings() {
    var range = egmtGetRange();
    egmtState.currentRange = range;
    $('#egmtCalendarHeading').text(range.label);
    $('#egmtCalendarContent').html('<div class="egmt-loading"><span></span><span></span><span></span></div>');
    var params = {start:range.startKey, end:range.endKey, scope:egmtState.scope, category_id:egmtState.category, search:egmtState.search, per_page:100};
    if (egmtState.category === 'all') delete params.category_id;
    var endpoint = egmtState.view === 'list' ? egmtRoutes.data : egmtRoutes.calendar;
    return egmtAjax('GET', endpoint, params).done(function (response) {
        var data = response.data || [];
        if (egmtState.view === 'list') data = data.rows && data.rows.data ? data.rows.data : [];
        egmtState.meetings = data || [];
        if (egmtState.view === 'day') egmtRenderDay(egmtState.meetings, range);
        else if (egmtState.view === 'week') egmtRenderWeek(egmtState.meetings, range);
        else if (egmtState.view === 'month') egmtRenderMonth(egmtState.meetings, range);
        else egmtRenderList(egmtState.meetings, range);
    }).fail(function (xhr) {
        $('#egmtCalendarContent').html('<div class="egmt-side-empty">' + egmtEscape(egmtErrorMessage(xhr, 'Unable to load meetings.')) + '</div>');
    });
}
function egmtRenderDay(items, range) {
    var current = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth(), egmtState.date.getDate());
    var dayEvents = items.filter(function (item) { var start = egmtParseDate(item.start_at); var end = egmtParseDate(item.end_at); return start && end && start < new Date(current.getTime()+86400000) && end >= current; });
    var html = '<div class="egmt-day-layout"><div><div class="egmt-time-head"></div>';
    for (var hour=8;hour<=17;hour++) html += '<div class="egmt-time-label">' + (hour < 12 ? hour + ' AM' : (hour === 12 ? '12 PM' : (hour-12) + ' PM')) + '</div>';
    html += '</div><div class="egmt-day-main">';
    dayEvents.forEach(function (item) {
        var start = egmtParseDate(item.start_at), end = egmtParseDate(item.end_at);
        var minutes = Math.max(0, (start.getHours()-8)*60 + start.getMinutes());
        var duration = Math.max(30, Math.round((end-start)/60000));
        var top = Math.max(0, minutes * (55/60)); var height = Math.max(34, duration * (55/60));
        var color = egmtSafeColor(item.category_color);
        html += '<div class="egmt-event-card" style="top:' + top + 'px;height:' + height + 'px;background:' + color + '" data-meeting-open="' + item.sno + '"><strong>' + egmtEscape(item.title) + '</strong><span>' + egmtEscape(egmtTime(item.start_at) + ' – ' + egmtTime(item.end_at)) + '</span></div>';
    });
    html += '</div></div>';
    $('#egmtCalendarContent').html(html);
}
function egmtRenderWeek(items, range) {
    var days = [];
    for (var index=0;index<7;index++) { var date = new Date(range.start); date.setDate(date.getDate()+index); days.push(date); }
    var html = '<div class="egmt-week-grid"><div class="egmt-time-head"></div>';
    days.forEach(function (date) {
        var today = date.toDateString() === new Date().toDateString();
        html += '<div class="egmt-week-day-head ' + (today?'today':'') + '"><span>' + egmtEscape(date.toLocaleDateString([], {weekday:'short',day:'numeric'})) + '</span></div>';
    });
    for (var hour=8;hour<=17;hour++) html += '<div class="egmt-time-label">' + (hour < 12 ? hour + ' AM' : (hour === 12 ? '12 PM' : (hour-12) + ' PM')) + '</div>' + days.map(function () { return '<div class="egmt-day-column"></div>'; }).join('');
    // Replace time-slot grid cells by one continuous positioned surface per day.
    html = '<div class="egmt-week-grid"><div class="egmt-time-head"></div>';
    days.forEach(function (date) { var today = date.toDateString() === new Date().toDateString(); html += '<div class="egmt-week-day-head ' + (today?'today':'') + '"><span>' + egmtEscape(date.toLocaleDateString([], {weekday:'short',day:'numeric'})) + '</span></div>'; });
    html += '<div><div class="egmt-time-head"></div>';
    for (var h=8;h<=17;h++) html += '<div class="egmt-time-label">' + (h < 12 ? h + ' AM' : (h === 12 ? '12 PM' : (h-12) + ' PM')) + '</div>';
    html += '</div>';
    days.forEach(function (date) {
        var events = items.filter(function (item) { var start=egmtParseDate(item.start_at), end=egmtParseDate(item.end_at); var next=new Date(date);next.setDate(next.getDate()+1);return start && end && start < next && end >= date; });
        html += '<div class="egmt-day-column ' + (date.toDateString()===new Date().toDateString()?'today':'') + '">';
        events.forEach(function (item) {
            var start=egmtParseDate(item.start_at),end=egmtParseDate(item.end_at);
            var minutes = Math.max(0, (start.getHours()-8)*60 + start.getMinutes());
            var duration = Math.max(30, Math.round((end-start)/60000));
            var top=Math.max(0,minutes*(55/60)); var height=Math.max(30,duration*(55/60));
            var overlapIndex = 0; var overlapTotal = 1;
            var colliding = events.filter(function (other) { if (other.sno===item.sno) return false; var os=egmtParseDate(other.start_at), oe=egmtParseDate(other.end_at); return os < end && oe > start; });
            overlapTotal = Math.min(3, colliding.length + 1);
            overlapIndex = colliding.filter(function (other) { return Number(other.sno) < Number(item.sno); }).length % overlapTotal;
            var color=egmtSafeColor(item.category_color);
            html += '<div class="egmt-event-card" style="top:' + top + 'px;height:' + height + 'px;left:calc(3px + ' + (overlapIndex*(100/overlapTotal)) + '%);right:auto;width:calc(' + (100/overlapTotal) + '% - 6px);background:' + color + '" data-meeting-open="' + item.sno + '"><strong>' + egmtEscape(item.title) + '</strong><span>' + egmtEscape(egmtTime(item.start_at)) + '</span></div>';
        });
        html += '</div>';
    });
    html += '</div>';
    $('#egmtCalendarContent').html(html);
}
function egmtRenderMonth(items, range) {
    var first = new Date(egmtState.date.getFullYear(), egmtState.date.getMonth(), 1);
    var start = egmtWeekStart(first);
    var html = '<div class="egmt-month-grid">' + ['MON','TUE','WED','THU','FRI','SAT','SUN'].map(function (d) { return '<div class="egmt-month-day-head">' + d + '</div>'; }).join('');
    for (var i=0;i<42;i++) {
        var date = new Date(start); date.setDate(start.getDate()+i);
        if (date.getTime() >= range.end.getTime()) break;
        var key=egmtDateKey(date);
        var daily=items.filter(function (item) { var dt=egmtParseDate(item.start_at); return dt && egmtDateKey(dt)===key; });
        html += '<div class="egmt-month-cell ' + (date.getMonth()!==egmtState.date.getMonth()?'muted':'') + '"><div class="egmt-month-date ' + (date.toDateString()===new Date().toDateString()?'today':'') + '">' + date.getDate() + '</div>';
        daily.slice(0,3).forEach(function (item) { html += '<div class="egmt-month-event" style="background:' + egmtSafeColor(item.category_color) + '" data-meeting-open="' + item.sno + '">' + egmtEscape(egmtTime(item.start_at) + ' ' + item.title) + '</div>'; });
        if (daily.length>3) html += '<div class="egmt-month-more" data-month-date="' + key + '">+' + (daily.length-3) + ' more</div>';
        html += '</div>';
    }
    html += '</div>';
    $('#egmtCalendarContent').html(html);
}
function egmtRenderList(items, range) {
    if (!items.length) { $('#egmtCalendarContent').html('<div class="egmt-side-empty">No meetings match the selected filters.</div>'); return; }
    var html = '<div class="egmt-list-wrap"><table class="egmt-list-table"><thead><tr><th>Meeting</th><th>Category</th><th>When</th><th>Venue / Link</th><th>Organiser</th><th>Status</th><th>My RSVP</th><th></th></tr></thead><tbody>';
    items.forEach(function (item) {
        var color=egmtSafeColor(item.category_color); var status=String(item.status||'Scheduled').toLowerCase().replace(/\s+/g,'-');
        var where = item.meeting_url ? '<a href="' + egmtEscape(item.meeting_url) + '" target="_blank" rel="noopener noreferrer">Online meeting</a>' : egmtEscape(item.venue||'—');
        html += '<tr><td><div class="egmt-list-title-line"><span class="egmt-list-dot" style="background:' + color + '"></span><span class="egmt-list-title" data-meeting-open="' + item.sno + '">' + egmtEscape(item.title) + '</span></div></td><td>' + egmtEscape(item.category_name || item.category || '—') + '</td><td>' + egmtEscape(egmtDateLabel(egmtParseDate(item.start_at),{weekday:'short',day:'numeric',month:'short'}) + ' · ' + egmtTime(item.start_at) + ' – ' + egmtTime(item.end_at)) + '</td><td>' + where + '</td><td>' + egmtEscape(item.organiser_name || '—') + '</td><td><span class="egmt-status ' + status + '">' + egmtEscape(item.status || 'Scheduled') + '</span></td><td>' + (item.my_rsvp === 'pending' ? '<span class="egmt-rsvp-text">RSVP pending</span>' : egmtEscape(item.my_rsvp || '—')) + '</td><td><div class="egmt-table-actions"><button type="button" title="View" data-meeting-open="' + item.sno + '"><i class="mdi mdi-eye-outline"></i></button></div></td></tr>';
    });
    html += '</tbody></table></div>';
    $('#egmtCalendarContent').html(html);
}
function egmtRefreshAll() {
    egmtRenderCategoryFilters();
    egmtLoadMeetings();
    egmtLoadDashboard();
}
function egmtSetView(view) {
    egmtState.view = view;
    $('.egmt-view-switch button').removeClass('active').filter('[data-view="' + view + '"]').addClass('active');
    egmtRefreshAll();
}
function egmtOpenSchedule(item) {
    egmtState.currentMeeting = item || null;
    egmtState.editMeetingId = item ? item.sno : null;
    $('#egmtScheduleForm')[0].reset();
    $('#egmtMeetingId').val(item ? item.sno : '');
    $('#egmtScheduleTitle').text(item ? 'Edit meeting' : 'Schedule meeting');
    $('#egmtScheduleSubtitle').text(item ? 'Update the details and participants for this meeting.' : 'Invite people, teams or departments and manage responses.');
    $('#egmtSaveMeeting').html(item ? '<i class="mdi mdi-content-save-outline"></i> Save changes' : '<i class="mdi mdi-calendar-check-outline"></i> Schedule &amp; send invites');
    $('#egmtConflictNotice').addClass('d-none');
    $('#egmtDate').val(item ? egmtDateKey(egmtParseDate(item.start_at)) : egmtDateKey(egmtState.date));
    $('#egmtStart').val(item ? egmtParseDate(item.start_at).toTimeString().slice(0,5) : '10:00');
    $('#egmtEnd').val(item ? egmtParseDate(item.end_at).toTimeString().slice(0,5) : '11:00');
    $('#egmtTitle').val(item ? item.title : '');
    $('#egmtAgenda').val(item ? item.agenda : '');
    $('#egmtVenue').val(item ? item.venue : '');
    $('#egmtMeetingUrl').val(item ? item.meeting_url : '');
    $('#egmtReminder').val(item ? String(item.reminder_minutes || 30) : '30');
    $('#egmtVisibility').val(item ? item.visibility : 'Company');
    $('#egmtStatus').val(item ? (String(item.status||'Scheduled').toLowerCase()==='in progress'?'In Progress':(String(item.status||'').toLowerCase()==='completed'?'Completed':'Scheduled')) : 'Scheduled');
    egmtSetWhere(item && item.meeting_url ? 'online' : 'venue');
    egmtState.currentMeeting = item || null;
    egmtReloadSelects();
    var selectedPeople = item ? (item.people_ids || []) : [];
    var selectedTeams = item ? (item.team_ids || []) : [];
    var selectedDepartments = item ? (item.department_ids || []) : [];
    $('#egmtPeople').val(selectedPeople.map(String)).trigger('change');
    $('#egmtTeams').val(selectedTeams.map(String)).trigger('change');
    $('#egmtDepartments').val(selectedDepartments.map(String)).trigger('change');
    $('#egmtAttachmentLabel').text('Add attachments (PDF, Office files, images or ZIP; max 20 MB each)');
    egmtUpdateSelectedCount();
    egmtInitSelect3('#egmtScheduleModal');
    egmtBootstrapModal('egmtScheduleModal').show();
}
function egmtOpenScheduleForEdit(id) {
    egmtAjax('GET', egmtUrl(id)).done(function (response) {
        var data=response.data||{}; var meeting=data.meeting||{};
        meeting.people_ids=(data.participants||[]).filter(function (x) { return Number(x.user_id)>0 && Number(x.user_id)!==Number(meeting.owner_user_id); }).map(function (x) { return Number(x.user_id); });
        meeting.team_ids=(data.teams||[]).map(function (x) { return Number(x.sno); });
        meeting.department_ids=(data.departments||[]).map(function (x) { return Number(x.sno); });
        egmtOpenSchedule(meeting);
    }).fail(function (xhr) { egmtNotify(egmtErrorMessage(xhr,'Unable to load this meeting.'),'error'); });
}
function egmtSetWhere(where) {
    egmtState.activeWhere=where;
    $('#egmtWhereSwitch button').removeClass('active').filter('[data-where="'+where+'"]').addClass('active');
    $('#egmtVenue').toggleClass('d-none',where!=='venue');
    $('#egmtMeetingUrl').toggleClass('d-none',where!=='online');
    $('#egmtVenue').prop('required',where==='venue');
    $('#egmtMeetingUrl').prop('required',where==='online');
}
function egmtUpdateSelectedCount() {
    var people=($('#egmtPeople').val()||[]).length;
    var teams=($('#egmtTeams').val()||[]).length;
    var departments=($('#egmtDepartments').val()||[]).length;
    var total=people+teams+departments+1;
    $('#egmtSelectedCount').text(total + ' participant' + (total===1?'':'s') + ' selected');
}
function egmtSubmitMeeting(event) {
    event.preventDefault();
    var form=document.getElementById('egmtScheduleForm');
    if (!form.reportValidity()) return;
    var date=$('#egmtDate').val(), start=$('#egmtStart').val(), end=$('#egmtEnd').val();
    if (!date || !start || !end || end<=start) { egmtNotify('Please select a valid start and end time.','error'); return; }
    if (egmtState.activeWhere==='venue' && !$('#egmtVenue').val().trim()) { egmtNotify('Please enter a meeting venue.','error'); return; }
    if (egmtState.activeWhere==='online' && !$('#egmtMeetingUrl').val().trim()) { egmtNotify('Please enter the online meeting link.','error'); return; }
    var data=new FormData();
    data.append('title',$('#egmtTitle').val().trim());
    data.append('agenda',$('#egmtAgenda').val());
    data.append('start_at',date+' '+start+':00'); data.append('end_at',date+' '+end+':00');
    data.append('venue',egmtState.activeWhere==='venue'?$('#egmtVenue').val().trim():'');
    data.append('meeting_url',egmtState.activeWhere==='online'?$('#egmtMeetingUrl').val().trim():'');
    data.append('reminder_minutes',$('#egmtReminder').val());
    data.append('visibility',$('#egmtVisibility').val());
    data.append('status',$('#egmtStatus').val());
    data.append('category_id',$('#egmtCategory').val()||'');
    ($('#egmtPeople').val()||[]).forEach(function(id){data.append('participant_ids[]',id);});
    ($('#egmtTeams').val()||[]).forEach(function(id){data.append('team_ids[]',id);});
    ($('#egmtDepartments').val()||[]).forEach(function(id){data.append('department_ids[]',id);});
    Array.from($('#egmtAttachments')[0].files||[]).forEach(function(file){data.append('attachments[]',file);});
    var id=egmtState.editMeetingId;
    if (id) data.append('_method','PUT');
    var button=$('#egmtSaveMeeting').prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-1"></span> Saving…');
    egmtAjax('POST',id?egmtUrl(id):egmtRoutes.store,data,{processData:false,contentType:false}).done(function(response){
        egmtBootstrapModal('egmtScheduleModal').hide(); egmtNotify(response.message||'Meeting saved.'); egmtState.currentMeeting=null; egmtState.editMeetingId=null; egmtRefreshAll();
    }).fail(function(xhr){
        var msg=egmtErrorMessage(xhr,'Unable to save the meeting.');
        if (xhr.responseJSON && xhr.responseJSON.errors && xhr.responseJSON.errors.schedule_conflicts) { $('#egmtConflictText').text(xhr.responseJSON.errors.schedule_conflicts.join(' ')); $('#egmtConflictNotice').removeClass('d-none'); }
        egmtNotify(msg,'error');
    }).always(function(){button.prop('disabled',false).html(id?'<i class="mdi mdi-content-save-outline"></i> Save changes':'<i class="mdi mdi-calendar-check-outline"></i> Schedule &amp; send invites');});
}
function egmtOpenMeeting(id) {
    egmtAjax('GET',egmtUrl(id)).done(function(response){ egmtState.currentMeeting=response.data||{}; egmtRenderMeetingDetail(egmtState.currentMeeting); egmtOffcanvas('egmtDetailDrawer').show(); }).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to open meeting.'),'error');});
}
function egmtRenderMeetingDetail(data) {
    var meeting=data.meeting||{}; var counts=data.rsvp_counts||{}; var status=String(meeting.status||'Scheduled');
    $('#egmtDetailTitle').text(meeting.title||'Meeting');
    $('#egmtDetailBadges').html('<span class="egmt-detail-badge">' + egmtEscape(meeting.category_name||meeting.category||'Uncategorised') + '</span><span class="egmt-detail-badge">' + egmtEscape(status) + '</span>');
    var date=egmtParseDate(meeting.start_at); var when=date?date.toLocaleDateString([], {weekday:'short',day:'numeric',month:'long',year:'numeric'}):'';
    var html='<div class="egmt-detail-line"><i class="mdi mdi-clock-outline"></i><div><strong>' + egmtEscape(when + ' · ' + egmtTime(meeting.start_at) + ' – ' + egmtTime(meeting.end_at)) + '</strong></div></div>';
    if (meeting.venue) html+='<div class="egmt-detail-line"><i class="mdi mdi-map-marker-outline"></i><div>' + egmtEscape(meeting.venue) + '</div></div>';
    if (meeting.meeting_url) html+='<div class="egmt-detail-line"><i class="mdi mdi-video-outline"></i><div><a href="' + egmtEscape(meeting.meeting_url) + '" target="_blank" rel="noopener noreferrer">' + egmtEscape(meeting.meeting_url) + '</a></div><a class="btn egmt-btn-primary btn-sm ms-auto" href="' + egmtEscape(meeting.meeting_url) + '" target="_blank" rel="noopener noreferrer">Join</a></div>';
    html+='<div class="egmt-detail-line"><i class="mdi mdi-account-outline"></i><div>Organiser · <strong>' + egmtEscape(meeting.organiser_name||'ERP User') + '</strong></div></div>';
    if (meeting.agenda) html+='<div class="egmt-detail-description">' + egmtEscape(meeting.agenda).replace(/\n/g,'<br>') + '</div>';
    html+='<div class="egmt-detail-section"><h6>RSVP</h6><div class="egmt-rsvp-summary"><span class="accepted">✓ ' + (counts.accepted||0) + ' accepted</span><span class="declined">✕ ' + (counts.declined||0) + ' declined</span><span class="tentative">? ' + (counts.tentative||0) + ' tentative</span><span style="color:#7c88a0">' + (counts.pending||0) + ' pending</span></div><div class="egmt-participant-list">' + (data.participants||[]).map(function (person) { return '<span class="egmt-participant"><span class="egmt-avatar">' + egmtEscape(egmtInitials(person.staff_name)) + '</span>' + egmtEscape(person.staff_name||'Participant') + '<span class="egmt-rsvp-tag">' + egmtEscape(person.rsvp||'pending') + '</span></span>'; }).join('') + '</div></div>';
    if ((data.teams||[]).length || (data.departments||[]).length) html+='<div class="egmt-detail-section"><h6>Groups invited</h6><div class="egmt-participant-list">' + (data.teams||[]).map(function(x){return '<span class="egmt-participant"><span class="egmt-avatar"><i class="mdi mdi-account-group"></i></span>'+egmtEscape(x.team_name)+'</span>';}).join('') + (data.departments||[]).map(function(x){return '<span class="egmt-participant"><span class="egmt-avatar"><i class="mdi mdi-domain"></i></span>'+egmtEscape(x.department_name)+'</span>';}).join('') + '</div></div>';
    if ((data.attachments||[]).length) html+='<div class="egmt-detail-section"><h6>Attachments</h6>' + data.attachments.map(function(a){return '<div class="egmt-attachment-row"><i class="mdi mdi-paperclip"></i><a href="'+egmtEscape(a.download_url)+'">'+egmtEscape(a.original_name)+'</a><span class="ms-auto text-muted">'+egmtEscape(egmtFileSize(a.file_size))+'</span></div>';}).join('') + '</div>';
    if ((data.reschedules||[]).length) html+='<div class="egmt-detail-section"><h6>Reschedule history</h6>' + data.reschedules.map(function(row){return '<div class="egmt-history-row"><strong>'+egmtEscape(egmtDateTimeLabel(row.old_start_at))+' → '+egmtEscape(egmtDateTimeLabel(row.new_start_at))+'</strong><span>'+egmtEscape(row.reason||'No reason provided')+' — '+egmtEscape(row.changed_by_name||'ERP User')+'</span></div>';}).join('') + '</div>';
    if (meeting.cancellation_reason) html+='<div class="egmt-detail-description"><strong>Cancellation reason:</strong> '+egmtEscape(meeting.cancellation_reason)+'</div>';
    if (data.can_manage) {
        html+='<div class="egmt-detail-actions"><button type="button" data-meeting-edit="'+meeting.sno+'"><i class="mdi mdi-pencil-outline"></i> Edit</button><button type="button" data-meeting-reschedule="'+meeting.sno+'">Reschedule</button>';
        if (status.toLowerCase()!=='cancelled' && status.toLowerCase()!=='completed') html+='<button type="button" class="cancel" data-meeting-cancel="'+meeting.sno+'">Cancel meeting</button>';
        if (status.toLowerCase()==='scheduled' || status.toLowerCase()==='postponed') html+='<button type="button" class="complete" data-meeting-status="'+meeting.sno+'" data-status="In Progress">Mark In Progress</button>';
        if (status.toLowerCase()==='in progress') html+='<button type="button" class="complete" data-meeting-status="'+meeting.sno+'" data-status="Completed">Mark Completed</button>';
        html+='</div>';
    } else if (data.my_rsvp==='pending' || data.my_rsvp==='tentative') {
        html+='<div class="egmt-detail-actions"><button type="button" class="complete" data-meeting-rsvp="accepted" data-id="'+meeting.sno+'">Accept invitation</button><button type="button" class="cancel" data-meeting-rsvp="declined" data-id="'+meeting.sno+'">Decline</button></div>';
    }
    $('#egmtDetailBody').html(html);
}
function egmtDateTimeLabel(value) {
    var date=egmtParseDate(value); return date?date.toLocaleDateString([], {day:'numeric',month:'short'})+' · '+egmtTime(value):'—';
}
function egmtFileSize(bytes) {
    var size=Number(bytes||0); if (size<1024) return size+' B'; if(size<1048576)return (size/1024).toFixed(1)+' KB';return (size/1048576).toFixed(1)+' MB';
}
function egmtSubmitRsvp(id, value) {
    egmtAjax('POST',egmtUrl(id,'rsvp'),{rsvp:value}).done(function(response){egmtNotify(response.message||'RSVP updated.');egmtLoadDashboard();if(egmtState.currentMeeting && egmtState.currentMeeting.meeting && Number(egmtState.currentMeeting.meeting.sno)===Number(id))egmtOpenMeeting(id);}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to update RSVP.'),'error');});
}
function egmtOpenCancel(id) {
    $('#egmtCancelId').val(id); $('#egmtCancelReason').val('');
    egmtBootstrapModal('egmtCancelModal').show();
}
function egmtSubmitCancel(event) {
    event.preventDefault(); var id=$('#egmtCancelId').val(); var reason=$('#egmtCancelReason').val().trim();
    if(!reason){egmtNotify('Please enter a cancellation reason.','error');return;}
    $('#egmtCancelSubmit').prop('disabled',true);
    egmtAjax('POST',egmtUrl(id,'cancel'),{reason:reason}).done(function(response){egmtBootstrapModal('egmtCancelModal').hide();egmtOffcanvas('egmtDetailDrawer').hide();egmtNotify(response.message||'Meeting cancelled.');egmtRefreshAll();}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to cancel meeting.'),'error');}).always(function(){$('#egmtCancelSubmit').prop('disabled',false);});
}
function egmtOpenReschedule(id) {
    var meeting=egmtState.currentMeeting && egmtState.currentMeeting.meeting ? egmtState.currentMeeting.meeting : null;
    if (!meeting || Number(meeting.sno)!==Number(id)) { egmtAjax('GET',egmtUrl(id)).done(function(r){egmtState.currentMeeting=r.data||{};egmtOpenReschedule(id);}); return; }
    $('#egmtRescheduleId').val(id); $('#egmtRescheduleDate').val(egmtDateKey(egmtParseDate(meeting.start_at)));
    $('#egmtRescheduleStart').val(egmtParseDate(meeting.start_at).toTimeString().slice(0,5)); $('#egmtRescheduleEnd').val(egmtParseDate(meeting.end_at).toTimeString().slice(0,5)); $('#egmtRescheduleReason').val('');
    egmtBootstrapModal('egmtRescheduleModal').show();
}
function egmtSubmitReschedule(event) {
    event.preventDefault(); var id=$('#egmtRescheduleId').val(); var date=$('#egmtRescheduleDate').val(); var start=$('#egmtRescheduleStart').val(); var end=$('#egmtRescheduleEnd').val(); var reason=$('#egmtRescheduleReason').val().trim();
    if(!date||!start||!end||end<=start||!reason){egmtNotify('Enter a valid date, time range and reason.','error');return;}
    $('#egmtRescheduleSubmit').prop('disabled',true);
    egmtAjax('POST',egmtUrl(id,'reschedule'),{start_at:date+' '+start+':00',end_at:date+' '+end+':00',reason:reason}).done(function(response){egmtBootstrapModal('egmtRescheduleModal').hide();egmtOffcanvas('egmtDetailDrawer').hide();egmtNotify(response.message||'Meeting rescheduled.');egmtRefreshAll();}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to reschedule meeting.'),'error');}).always(function(){$('#egmtRescheduleSubmit').prop('disabled',false);});
}
function egmtUpdateStatus(id,status) {
    egmtAjax('POST',egmtUrl(id,'status'),{status:status}).done(function(response){egmtNotify(response.message||'Status updated.');egmtOpenMeeting(id);egmtRefreshAll();}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to update status.'),'error');});
}
function egmtConfirm(title, text, action) {
    $('#egmtConfirmTitle').text(title); $('#egmtConfirmText').text(text); egmtState.pendingConfirm=action; egmtBootstrapModal('egmtConfirmModal').show();
}

function egmtFetchCategoryManager() {
    egmtAjax('GET',egmtRoutes.categories,{}).done(function(response){egmtRenderCategoryManager((response.data||{}).categories||[]);egmtBootstrapModal('egmtCategoryManageModal').show();}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to load categories.'),'error');});
}
function egmtOpenCategoryManager() {
    if ($('#egmtScheduleModal').hasClass('show') && !egmtState.returnToSchedule) {
        egmtState.returnToSchedule = true;
        $('#egmtScheduleModal').one('hidden.bs.modal', egmtFetchCategoryManager);
        egmtBootstrapModal('egmtScheduleModal').hide();
        return;
    }
    egmtFetchCategoryManager();
}
function egmtRenderCategoryManager(rows) {
    var isGroupAdmin = !!(egmtState.lookups && egmtState.lookups.is_group_admin);
    $('#egmtCategoryManagerList').html(rows.length?rows.map(function(row){
        var canEdit = isGroupAdmin || row.company_id !== null;
        var actions = canEdit ? '<div class="egmt-manager-actions"><button type="button" data-category-edit="'+row.sno+'">Edit</button><button type="button" class="danger" data-category-delete="'+row.sno+'">Delete</button></div>' : '<span class="egmt-manager-sub">Global · Read only</span>';
        return '<div class="egmt-manager-row"><div class="egmt-manager-row-main"><span class="egmt-manager-color" style="background:'+egmtSafeColor(row.color)+'"></span><div><div class="egmt-manager-name">'+egmtEscape(row.category_name)+'</div><div class="egmt-manager-sub">'+(Number(row.status)===0?'Active':'Inactive')+(row.description?' · '+egmtEscape(row.description):'')+'</div></div></div>'+actions+'</div>';
    }).join(''):'<div class="egmt-side-empty">No categories added yet. Create a category to organise meetings.</div>');
}
function egmtOpenCategoryForm(row) {
    egmtState.editingCategoryId=row?row.sno:null; $('#egmtCategoryFormTitle').text(row?'Edit category':'Add category'); $('#egmtCategoryId').val(row?row.sno:''); $('#egmtCategoryName').val(row?row.category_name:''); $('#egmtCategoryColor').val(row?egmtSafeColor(row.color):'#ab2b22'); $('#egmtCategoryDescription').val(row?row.description:'');
    egmtState.settingsTransition = true;
    $('#egmtCategoryManageModal').one('hidden.bs.modal', function(){egmtBootstrapModal('egmtCategoryFormModal').show();egmtState.settingsTransition=false;});
    egmtBootstrapModal('egmtCategoryManageModal').hide();
}
function egmtSubmitCategory(event) {
    event.preventDefault(); var id=$('#egmtCategoryId').val(); var payload={category_name:$('#egmtCategoryName').val().trim(),color:$('#egmtCategoryColor').val(),description:$('#egmtCategoryDescription').val()};
    if(!payload.category_name){egmtNotify('Category name is required.','error');return;}
    $('#egmtSaveCategory').prop('disabled',true);
    egmtAjax(id?'PUT':'POST',id?egmtRoutes.categories+'/'+id:egmtRoutes.categories,payload).done(function(response){egmtState.keepSettingsOpen=true;egmtBootstrapModal('egmtCategoryFormModal').hide();egmtNotify(response.message||'Category saved.');egmtLoadLookups().always(function(){egmtState.keepSettingsOpen=false;egmtOpenCategoryManager();});}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to save category.'),'error');}).always(function(){$('#egmtSaveCategory').prop('disabled',false);});
}
function egmtDeleteCategory(id) {
    egmtConfirm('Delete category','This will remove the category from new selection. Existing meetings keep their category label.',function(){egmtAjax('DELETE',egmtRoutes.categories+'/'+id,{}).done(function(response){egmtNotify(response.message||'Category deleted.');egmtLoadLookups().always(egmtOpenCategoryManager);}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to delete category.'),'error');});});
}
function egmtFetchTeamManager() {
    egmtAjax('GET',egmtRoutes.teams,{}).done(function(response){egmtRenderTeamManager((response.data||{}).teams||[]);egmtBootstrapModal('egmtTeamManageModal').show();}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to load teams.'),'error');});
}
function egmtOpenTeamManager() {
    if ($('#egmtScheduleModal').hasClass('show') && !egmtState.returnToSchedule) {
        egmtState.returnToSchedule = true;
        $('#egmtScheduleModal').one('hidden.bs.modal', egmtFetchTeamManager);
        egmtBootstrapModal('egmtScheduleModal').hide();
        return;
    }
    egmtFetchTeamManager();
}
function egmtRenderTeamManager(rows) {
    var isGroupAdmin = !!(egmtState.lookups && egmtState.lookups.is_group_admin);
    $('#egmtTeamManagerList').html(rows.length?rows.map(function(row){
        var canEdit = isGroupAdmin || row.company_id !== null;
        var actions = canEdit ? '<div class="egmt-manager-actions"><button type="button" data-team-edit="'+row.sno+'">Edit</button><button type="button" class="danger" data-team-delete="'+row.sno+'">Deactivate</button></div>' : '<span class="egmt-manager-sub">Global · Read only</span>';
        return '<div class="egmt-manager-row"><div class="egmt-manager-row-main"><span class="egmt-manager-color" style="background:#ab2b22"></span><div><div class="egmt-manager-name">'+egmtEscape(row.team_name)+'</div><div class="egmt-manager-sub">'+Number(row.member_count||0)+' members'+(row.description?' · '+egmtEscape(row.description):'')+'</div></div></div>'+actions+'</div>';
    }).join(''):'<div class="egmt-side-empty">No meeting teams added yet. Create a reusable team.</div>');
}
function egmtOpenTeamForm(row) {
    egmtState.editingTeamId=row?row.sno:null; egmtState.editingTeamMembers=row?(row.members||[]).map(function(x){return Number(x.user_id);}):[];
    $('#egmtTeamFormTitle').text(row?'Edit team':'Add team'); $('#egmtTeamId').val(row?row.sno:''); $('#egmtTeamName').val(row?row.team_name:''); $('#egmtTeamDescription').val(row?row.description:'');
    egmtReloadSelects(); $('#egmtTeamMembers').val(egmtState.editingTeamMembers.map(String)).trigger('change');
    egmtState.settingsTransition = true;
    $('#egmtTeamManageModal').one('hidden.bs.modal', function(){egmtBootstrapModal('egmtTeamFormModal').show();egmtState.settingsTransition=false;});
    egmtBootstrapModal('egmtTeamManageModal').hide();
}
function egmtSubmitTeam(event) {
    event.preventDefault(); var id=$('#egmtTeamId').val(); var payload={team_name:$('#egmtTeamName').val().trim(),description:$('#egmtTeamDescription').val(),member_ids:$('#egmtTeamMembers').val()||[]};
    if(!payload.team_name){egmtNotify('Team name is required.','error');return;} if(!payload.member_ids.length){egmtNotify('Select at least one team member.','error');return;}
    $('#egmtSaveTeam').prop('disabled',true);
    egmtAjax(id?'PUT':'POST',id?egmtRoutes.teams+'/'+id:egmtRoutes.teams,payload).done(function(response){egmtState.keepSettingsOpen=true;egmtBootstrapModal('egmtTeamFormModal').hide();egmtNotify(response.message||'Team saved.');egmtLoadLookups().always(function(){egmtState.keepSettingsOpen=false;egmtOpenTeamManager();});}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to save team.'),'error');}).always(function(){$('#egmtSaveTeam').prop('disabled',false);});
}
function egmtDeleteTeam(id) {
    egmtConfirm('Deactivate team','This team will no longer be available for new invitations. Existing meeting records are retained.',function(){egmtAjax('DELETE',egmtRoutes.teams+'/'+id,{}).done(function(response){egmtNotify(response.message||'Team deactivated.');egmtLoadLookups().always(egmtOpenTeamManager);}).fail(function(xhr){egmtNotify(egmtErrorMessage(xhr,'Unable to deactivate team.'),'error');});});
}
function egmtLoadExternalEvents() {
    var range=egmtGetRange(); $('#egmtExternalList').html('<div class="egmt-loading"><span></span><span></span><span></span></div>');
    egmtAjax('GET',egmtRoutes.externalEvents,{start:range.startKey,end:range.endKey}).done(function(response){var rows=response.data||[];$('#egmtExternalList').html(rows.length?rows.map(function(row){return '<div class="egmt-manager-row"><div class="egmt-manager-row-main"><span class="egmt-manager-color" style="background:#c08b00"></span><div><div class="egmt-manager-name">'+egmtEscape(row.event_name)+'</div><div class="egmt-manager-sub">'+egmtEscape(row.event_type)+' · '+egmtEscape(row.event_date)+' '+egmtEscape(row.event_time||'')+' · '+egmtEscape(row.venue||'Online')+'</div></div></div>'+(row.online_link?'<a href="'+egmtEscape(row.online_link)+'" target="_blank" rel="noopener noreferrer" class="egmt-inline-manage">Open</a>':'')+'</div>';}).join(''):'<div class="egmt-side-empty">No ERP events found for this calendar period.</div>');egmtBootstrapModal('egmtExternalModal').show();}).fail(function(xhr){$('#egmtExternalList').html('<div class="egmt-side-empty">'+egmtEscape(egmtErrorMessage(xhr,'Unable to load external events.'))+'</div>');egmtBootstrapModal('egmtExternalModal').show();});
}
function egmtMoveDate(direction) {
    if(egmtState.view==='day') egmtState.date.setDate(egmtState.date.getDate()+direction);
    else if(egmtState.view==='week') egmtState.date.setDate(egmtState.date.getDate()+(7*direction));
    else egmtState.date.setMonth(egmtState.date.getMonth()+direction);
    egmtRefreshAll();
}
function egmtReturnToScheduleIfNeeded() {
    if (!egmtState.returnToSchedule || egmtState.settingsTransition || egmtState.keepSettingsOpen) return;
    var anySettingsModalOpen = $('#egmtCategoryManageModal,#egmtCategoryFormModal,#egmtTeamManageModal,#egmtTeamFormModal').filter('.show').length > 0;
    if (anySettingsModalOpen) return;
    egmtState.returnToSchedule = false;
    egmtBootstrapModal('egmtScheduleModal').show();
}

function egmtInitMeetings() {
    var config=document.getElementById('egmtRouteConfig');
    try { egmtRoutes=JSON.parse(config?config.textContent:'{}'); } catch(error) { console.error('Meeting route configuration error',error); return; }
    egmtInitSelect3(document);
    $('#egmtCalendarScope').val(egmtState.scope).trigger('change');
    $('#egmtScheduleMeeting').on('click',function(){egmtOpenSchedule(null);});
    $('#egmtManageCategories,#egmtManageCategoriesInline').on('click',egmtOpenCategoryManager);
    $('#egmtManageTeams,#egmtManageTeamsInline').on('click',egmtOpenTeamManager);
    $('.egmt-view-switch').on('click','[data-view]',function(){egmtSetView($(this).data('view'));});
    $('#egmtPrev').on('click',function(){egmtMoveDate(-1);}); $('#egmtNext').on('click',function(){egmtMoveDate(1);});
    $('#egmtToday').on('click',function(){egmtState.date=new Date();egmtRefreshAll();});
    $('#egmtCalendarScope').on('change',function(){egmtState.scope=this.value;egmtRefreshAll();});
    $('#egmtCategoryFilters').on('click','[data-category]',function(){egmtState.category=$(this).data('category');egmtRefreshAll();});
    $('#egmtRefresh').on('click',function(){egmtRefreshAll();});
    $('#egmtSearch').on('input',function(){clearTimeout(window.egmtSearchTimer);var value=this.value;window.egmtSearchTimer=setTimeout(function(){egmtState.search=value.trim();egmtRefreshAll();},350);});
    $('#egmtSearchClear').on('click',function(){$('#egmtSearch').val('');egmtState.search='';egmtRefreshAll();});
    $('#egmtViewToday').on('click',function(){egmtState.view='day';egmtState.date=new Date();egmtSetView('day');});
    $('#egmtExternalEvents').on('click',egmtLoadExternalEvents);
    $('#egmtScheduleForm').on('submit',egmtSubmitMeeting);
    $('#egmtWhereSwitch').on('click','[data-where]',function(){egmtSetWhere($(this).data('where'));});
    $('.egmt-invite-tabs').on('click','[data-invite-tab]',function(){var tab=$(this).data('invite-tab');$('.egmt-invite-tabs button').removeClass('active');$(this).addClass('active');$('.egmt-invite-panel').addClass('d-none').filter('[data-invite-panel="'+tab+'"]').removeClass('d-none');});
    $('#egmtPeople,#egmtTeams,#egmtDepartments').on('change',egmtUpdateSelectedCount);
    $('#egmtAttachments').on('change',function(){var files=Array.from(this.files||[]);$('#egmtAttachmentLabel').text(files.length?files.length+' file(s) selected':'Add attachments (PDF, Office files, images or ZIP; max 20 MB each)');});
    $('#egmtAddCategory').on('click',function(){egmtOpenCategoryForm(null);}); $('#egmtCategoryForm').on('submit',egmtSubmitCategory);
    $('#egmtCategoryManagerList').on('click','[data-category-edit]',function(){var id=Number($(this).data('category-edit'));egmtAjax('GET',egmtRoutes.categories,{}).done(function(r){var row=(r.data.categories||[]).find(function(x){return Number(x.sno)===id;});if(row)egmtOpenCategoryForm(row);});});
    $('#egmtCategoryManagerList').on('click','[data-category-delete]',function(){egmtDeleteCategory(Number($(this).data('category-delete')));});
    $('#egmtCategoryManageModal,#egmtCategoryFormModal,#egmtTeamManageModal,#egmtTeamFormModal').on('hidden.bs.modal',egmtReturnToScheduleIfNeeded);
    $('#egmtAddTeam').on('click',function(){egmtOpenTeamForm(null);}); $('#egmtTeamForm').on('submit',egmtSubmitTeam);
    $('#egmtTeamManagerList').on('click','[data-team-edit]',function(){var id=Number($(this).data('team-edit'));egmtAjax('GET',egmtRoutes.teams,{}).done(function(r){var row=(r.data.teams||[]).find(function(x){return Number(x.sno)===id;});if(row)egmtOpenTeamForm(row);});});
    $('#egmtTeamManagerList').on('click','[data-team-delete]',function(){egmtDeleteTeam(Number($(this).data('team-delete')));});
    $('#egmtCancelForm').on('submit',egmtSubmitCancel); $('#egmtRescheduleForm').on('submit',egmtSubmitReschedule);
    $('#egmtConfirmYes').on('click',function(){var action=egmtState.pendingConfirm;egmtState.pendingConfirm=null;egmtBootstrapModal('egmtConfirmModal').hide();if(typeof action==='function')action();});
    $('#egmtCalendarContent,#egmtRsvpList,#egmtUpcomingList,#egmtDetailBody').on('click','[data-meeting-open]',function(){egmtOpenMeeting(Number($(this).data('meeting-open')));});
    $('#egmtRsvpList,#egmtDetailBody').on('click','[data-meeting-rsvp]',function(event){event.stopPropagation();egmtSubmitRsvp(Number($(this).data('id')),$(this).data('meeting-rsvp'));});
    $('#egmtDetailBody').on('click','[data-meeting-edit]',function(){var id=Number($(this).data('meeting-edit'));egmtOffcanvas('egmtDetailDrawer').hide();egmtOpenScheduleForEdit(id);});
    $('#egmtDetailBody').on('click','[data-meeting-cancel]',function(){egmtOpenCancel(Number($(this).data('meeting-cancel')));});
    $('#egmtDetailBody').on('click','[data-meeting-reschedule]',function(){egmtOpenReschedule(Number($(this).data('meeting-reschedule')));});
    $('#egmtDetailBody').on('click','[data-meeting-status]',function(){egmtUpdateStatus(Number($(this).data('meeting-status')),$(this).data('status'));});
    $('#egmtCalendarContent').on('click','[data-month-date]',function(){var value=String($(this).data('month-date')).split('-');egmtState.date=new Date(Number(value[0]),Number(value[1])-1,Number(value[2]));egmtSetView('day');});
    egmtLoadLookups().always(function(){egmtLoadDashboard();egmtLoadMeetings();});
}

$(document).ready(function(){ egmtInitMeetings(); });

    $('.common_datepicker_cust').datepicker({
        todayHighlight: true,
        autoclose: true,
        format: 'dd-M-yyyy'
    });
    $('.custom_time_picker').flatpickr({
        enableTime: true,
        noCalendar: true,
        dateFormat: 'h:i K',
        defaultHour: 12,
        defaultMinute: 0,
        minuteIncrement: 5
    });
</script>
@endsection
