<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;

class ContractorList extends Controller
{
    public function index()
    {
        return view('content.sitelog.managecontractor');
    }
}
