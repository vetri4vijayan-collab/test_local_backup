<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class VendorController extends Controller
{
  public function vendor_controller ()
  {
    return view('content.sitelog.vendor');
  }
}
