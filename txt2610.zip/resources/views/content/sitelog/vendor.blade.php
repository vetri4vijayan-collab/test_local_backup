@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  /* Hide cursor globally except inside inputs */
  * {
    caret-color: transparent !important;
  }
  input, textarea, select {
    caret-color: auto !important;
  }
</style>

<div id="vendorListView">
    <!-- Header section -->
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            <div
                class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                <div class="d-flex align-items-center gap-3">
                    <i class="mdi mdi-truck-outline fs-1 text-primary"></i>
                    <div>
                        <h4 class="mb-1 fw-bold text-primary">Vendor</h4>
                        <p class="text-muted mb-0 fs-7">Site Operations Management & Logs</p>
                    </div>
                </div>
                <!-- Updated button to call setViewMode('form') -->
                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" onclick="setViewMode('form')">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Vendor
                </button>
            </div>
        </div>
    </div>

    <!-- Filter section -->
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            <div
                class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                <div class="input-group" style="max-width: 350px;">
                    <span class="input-group-text border-end-0 text-muted bg-white">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input type="text" id="hr-search-field" class="form-control border-start-0 ps-0 shadow-none"
                        placeholder="Search by vendor, company type..">
                </div>
                <div class="text-muted fs-7 mb-0">
                    Showing active <span class="fw-semibold text-dark">3</span> records
                </div>
            </div>
        </div>
    </div>

    <!-- List content  -->
    <div class="card  shadow-sm bg-white mb-0 mt-3 rounded-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle  text-dark" style="font-size: 0.85rem;">
                <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                    <tr>
                        <th class="py-3 px-3 esi-th-company min-w-100px text-black">Vendor Code & Company</th>
                        <th class="py-3 px-3 esi-th-type min-w-100px text-black">Vendor Type</th>
                        <th class="py-3 px-3 esi-th-contact min-w-100px text-black">Contact Representative</th>
                        <th class="py-3 px-3 esi-th-location min-w-100px text-black">City / District</th>
                        <th class="py-3 px-3 esi-th-tax min-w-100px text-black">PAN / GST No</th>
                        <th class="py-3 px-3 esi-th-bank min-w-100px text-black ">NEFT / RTGS Bank
                        <th class="py-3 px-3 text-center esi-th-machinery min-w-100px text-black ">Machinery Supply</th>
                        <th class="py-3 px-3 text-center esi-th-actions min-w-100px text-black">Actions</th>
                    </tr>
                </thead>
                <tbody class="">
                    <!-- Empty State Row (Toggle via JS/Backend when array is empty) -->
                    <!--
                <tr>
                    <td colspan="8" class="p-5 text-center text-muted esi-table-empty">
                        No vendor records match your search query. Click "+ Add Vendor" to create one.
                    </td>
                </tr>
                -->

                    <!-- Example Data Row 1 -->
                    <tr class="esi-vendor-row">
                        <!-- Company & Code -->
                        <td class="py-3 px-3">
                            <span class="fw-bold text-dark d-block esi-vendor-company" id="esi_vendor">Apex Steel &
                                Industrial
                                Works</span>
                            <span
                                class="font-monospace text-info bg-info bg-opacity-10 px-2 py-0.5 rounded small d-inline-block mt-1 border border-info border-opacity-25 esi-vendor-code">
                                VEND-001
                            </span>
                        </td>

                        <!-- Vendor Type -->
                        <td class="py-3 px-3">
                            <span class="fw-semibold text-secondary bg-light px-2 py-1 rounded small esi-vendor-type"
                                id="esi_vendor_type">
                                Electrical
                            </span>
                        </td>

                        <!-- Contact Rep -->
                        <td class="py-3 px-3">
                            <div class="fw-bold text-dark esi-contact-name">Rajesh Kumar</div>
                            <div
                                class="text-muted small font-monospace mt-0.5 d-flex align-items-center gap-1 esi-contact-phone">
                                <i class="mdi mdi-phone text-secondary"></i>
                                <span>+91 98765 43210</span>
                            </div>
                            <div class="text-muted text-truncate esi-contact-email"
                                style="max-width: 150px; font-size: 0.75rem;">
                                rajesh@apexindustrial.com
                            </div>
                        </td>

                        <!-- Location -->
                        <td class="py-3 px-3">
                            <div class="fw-medium text-dark esi-vendor-city">Madurai</div>
                            <div class="text-muted small esi-vendor-district" style="font-size: 0.75rem;">Madurai, Tamil
                                Nadu</div>
                        </td>

                        <!-- PAN & GST -->
                        <td class="py-3 px-3 font-monospace" style="font-size: 0.8rem;">
                            <div class="text-dark esi-vendor-pan"><span class="text-muted font-sans text-uppercase"
                                    style="font-size: 0.7rem;">PAN:</span> ABCDE1234F</div>
                            <div class="text-info esi-vendor-gst"><span class="text-muted font-sans text-uppercase"
                                    style="font-size: 0.7rem;">GST:</span> 33AAAAA0000A1Z5</div>
                        </td>

                        <!-- Bank Details -->
                        <td class="py-3 px-3 font-monospace" style="font-size: 0.8rem;">
                            <div class="esi-bank-container">
                                <div class="fw-semibold text-dark font-sans text-truncate esi-bank-name"
                                    style="max-width: 150px;">HDFC Bank Ltd</div>
                                <div class="text-muted" style="font-size: 0.75rem;">A/C: 50200012345678</div>
                                <div class="text-success fw-bold" style="font-size: 0.75rem;">IFSC: HDFC0001234</div>
                            </div>
                        </td>

                        <!-- Machinery Supply -->
                        <td class="py-3 px-3 text-center">
                            <span
                                class="badge bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-2 py-1 esi-badge-machinery">
                                <i class="mdi mdi-tools me-1"></i> Machinery
                            </span>
                        </td>

                        <!-- Actions -->
                        <td class="py-3 px-3 text-end">
                            <div class="d-flex align-items-center justify-content-center gap-1">
                                <!-- Edit Button  -->
                                <button type="button" class="btn p-0 text-decoration-none esi-btn-edit"
                                    onclick="setViewMode('update')" title="Edit Record">
                                    <i class="mdi mdi-pencil-outline fs-4 text-dark"></i>
                                </button>
                                <!-- Trigger Button -->
                                <button type="button" class="btn p-0 text-decoration-none esi-btn-delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal"
                                    title="Delete Record">
                                    <i class="mdi mdi-trash-can-outline fs-4 text-danger"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Example Data Row 2 -->
                    <tr class="esi-vendor-row">
                        <!-- Company & Code -->
                        <td class="py-3 px-3">
                            <span class="fw-bold text-dark d-block esi-vendor-company">UltraTech Cement Depot
                                Corporation</span>
                            <span
                                class="font-monospace text-info bg-info bg-opacity-10 px-2 py-0.5 rounded small d-inline-block mt-1 border border-info border-opacity-25 esi-vendor-code">
                                VEND-002
                            </span>
                        </td>

                        <!-- Vendor Type -->
                        <td class="py-3 px-3 fs-8 text-nowrap text-start ">
                            <span
                                class="fw-semibold text-secondary text-start bg-light px-2 py-1 rounded  esi-vendor-type fs-9">
                                Cement Supplier
                            </span>
                        </td>

                        <!-- Contact Rep -->
                        <td class="py-3 px-3">
                            <div class="fw-bold text-dark esi-contact-name">V. Sundaram (Regional Manager)</div>
                            <div
                                class="text-muted small font-monospace mt-0.5 d-flex align-items-center gap-1 esi-contact-phone">
                                <i class="mdi mdi-phone text-secondary"></i>
                                <span>+91 98765 43210</span>
                            </div>
                            <div class="text-muted text-truncate esi-contact-email"
                                style="max-width: 150px; font-size: 0.75rem;">
                                rajesh@apexindustrial.com
                            </div>
                        </td>

                        <!-- Location -->
                        <td class="py-3 px-3">
                            <div class="fw-medium text-dark esi-vendor-city">Madurai</div>
                            <div class="text-muted small esi-vendor-district" style="font-size: 0.75rem;">Madurai, Tamil
                                Nadu</div>
                        </td>

                        <!-- PAN & GST -->
                        <td class="py-3 px-3 font-monospace" style="font-size: 0.8rem;">
                            <div class="text-dark esi-vendor-pan"><span class="text-muted font-sans text-uppercase"
                                    style="font-size: 0.7rem;">PAN:</span> ABCDE1234F</div>
                            <div class="text-info esi-vendor-gst"><span class="text-muted font-sans text-uppercase"
                                    style="font-size: 0.7rem;">GST:</span> 33AAAAA0000A1Z5</div>
                        </td>

                        <!-- Bank Details -->
                        <td class="py-3 px-3 font-monospace" style="font-size: 0.8rem;">
                            <div class="esi-bank-container">
                                <div class="fw-semibold text-dark font-sans text-truncate esi-bank-name"
                                    style="max-width: 150px;">HDFC Bank Ltd</div>
                                <div class="text-muted" style="font-size: 0.75rem;">A/C: 50200012345678</div>
                                <div class="text-success fw-bold" style="font-size: 0.75rem;">IFSC: HDFC0001234</div>
                            </div>
                        </td>

                        <!-- Machinery Supply -->
                        <td class="py-3 px-3 text-center">
                            <span
                                class="badge bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-2 py-1 esi-badge-machinery">
                                Materials Only
                            </span>
                        </td>

                        <!-- Actions -->
                        <td class="py-3 px-3 text-end">
                            <div class="d-flex align-items-center justify-content-center gap-1">
                                <button type="button" class="btn p-0 text-decoration-none esi-btn-edit"
                                    onclick="setViewMode('update')" title="Edit Record">
                                    <i class="mdi mdi-pencil-outline fs-4 text-dark"></i>
                                </button>
                                <!-- Trigger Button -->
                                <button type="button" class="btn btn-link p-0 text-decoration-none esi-btn-delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal"
                                    title="Delete Record">
                                    <i class="mdi mdi-trash-can-outline fs-4 text-danger"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content    shadow">

            <!-- Modal Header -->
            <div class="modal-header align-items-center pb-2">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-alert-circle-outline text-danger fs-2"></i>
                    <h5 class="modal-title fw-bold text-dark mb-0" id="deleteModalLabel">Confirm Deletion</h5>
                </div>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body text-center py-0">

                <p class="text-muted mb-0">Are you sure you want to delete this vendor record? <br> <strong
                        class="text-dark">This action cannot be undone.</strong></p>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer border-top-0 d-flex justify-content-center pt-0">
                <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger rounded-3 px-4" id="confirmDeleteBtn">Yes,
                    Delete</button>
            </div>

        </div>
    </div>
</div>

<!-- VIEW 2: ADD VENDOR FORM VIEW (Hidden by default) -->
<div id="vendorFormView" style="display: none;">
    <div class="container py-4">
        <div class="card bg-white border border-secondary-subtle rounded-0 shadow-sm text-secondary">

            <!-- Top Bar / Header -->
            <div
                class="card-header px-4 py-3 border-bottom border-secondary-subtle bg-light d-flex align-items-center justify-content-between rounded-0">
                <div class="d-flex align-items-center gap-2">
                    <button type="button" onclick="setViewMode('list')" class="btn p-1" title="Back to Vendor List">
                        <i class="mdi mdi-arrow-left text-dark"></i>
                    </button>
                    <h2 class="fs-6 fw-bold text-dark text-uppercase m-0" id="formHeaderTitle">
                        ADD VENDOR
                    </h2>
                </div>
                <span class="text-muted font-monospace" style="font-size: 11px;">
                    Vendor Code: <span id="vendorCodeDisplay">NEW</span>
                </span>
            </div>

            <!-- Form Body -->
            <form id="vendorForm" class="card-body p-4 p-md-5 fs-7">

                <!-- ROW 1: Vendor Type*, Name Of The Company*, Vendor Name* -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Type<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="vendorType"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            required>
                            <option value="Electrical">Electrical</option>
                            <option value="Cement Supplier">Cement Supplier</option>
                            <option value="Ready Mix Concrete">Ready Mix Concrete</option>
                            <option value="Structural Steel">Structural Steel</option>
                            <option value="Safety Gear & PPE">Safety Gear & PPE</option>
                            <option value="Earthmoving & Machinery">Earthmoving & Machinery</option>
                            <option value="Hardware & Tools">Hardware & Tools</option>
                            <option value="Plumbing & Sanitary">Plumbing & Sanitary</option>
                            <option value="Paints & Coatings">Paints & Coatings</option>
                            <option value="General Material">General Material</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Name Of The Company<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorCompany" required placeholder="e.g. EIBS COMPANY"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Name<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorName" required placeholder="e.g. John Doe"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                </div>

                <!-- ROW 2: Product Purchase Details, Address, Town/City -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Product Purchase Details
                        </label>
                        <input type="text" id="productPurchaseInput" placeholder="eg: cement, steel etc.."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div id="productPurchaseTags" class="mt-2 d-flex flex-wrap gap-1"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Address
                        </label>
                        <textarea id="address" rows="1" placeholder="Street address, industrial estate..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></textarea>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Town/City</label>
                        <input type="text" id="townCity" placeholder="e.g. Bengaluru"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                </div>

                <!-- ROW 3: Taluka/District, State, Pincode -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Taluka/District</label>
                        <input type="text" id="talukaDistrict" placeholder="e.g. Bengaluru Urban"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State</label>
                        <input type="text" id="state" placeholder="e.g. Karnataka"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Pincode</label>
                        <input type="text" id="pincode" placeholder="Pincode"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                    </div>
                </div>

                <!-- ROW 4: PAN No, GST No, (Checkbox under GST) -->
                <div class="row g-3 mb-3 align-items-start">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">PAN No</label>
                        <input type="text" id="panNo" placeholder="PAN No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">GST No</label>
                        <input type="text" id="gstNo" placeholder="GST No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                        
                      
                    </div>
                      <!-- CORRECTED CHECKBOX ALIGNMENT -->
                        <div class="d-flex align-items-center justify-content-start mt-2">
                            <input type="checkbox" id="isSupplyMachinery"
                                class="border-secondary-subtle rounded-1 shadow-none m-0 me-2"
                                style="width: 1rem; height: 1rem; cursor: pointer;" />
                            <label class="fw-semibold text-secondary m-0" style="font-size: 11px; cursor: pointer;" for="isSupplyMachinery">
                                is Supply Machinery
                            </label>
                        </div>
                    
                </div>

                <!-- SECTION: Person Details (Primary & Secondary) -->
                <div id="addPersonContainer">
                    <div class="mb-3">
                        <label class="text-dark fw-bold fs-6">Primary</label>
                    </div>
                    <div class="row g-3 mb-3 person-row">
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Type<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                <option value="Technical">Technical</option>
                                <option value="Commercial">Commercial</option>
                                <option value="Sales">Sales</option>
                                <option value="Management">Management</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Name<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" placeholder="Project Manager EiBS"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Mobile No<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" placeholder="9874561230"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                                Id</label>
                            <input type="email" placeholder="projectmanager@eibsglobal.com"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                                No</label>
                            <input type="text" placeholder="Telephone No"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Person -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="addVendorPerson()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Contact Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- SECTION: Details for Making Payment by NEFT / RTGS (Primary & Secondary) -->
                <div id="addBankContainer">
                    <div class="pt-3 border-top border-secondary-subtle">
                        <div class="mb-3">
                            <label class="text-dark fw-bold fs-6 mb-2">Primary Bank Details</label><br>
                            <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                                Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                                Vendors' Account
                            </h3>
                        </div>

                        <div class="row g-3 mb-3 bank-row">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Name</label>
                                <input type="text" placeholder="Bank Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Branch</label>
                                <input type="text" placeholder="Bank Branch"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Address</label>
                                <textarea rows="1" placeholder="Bank Address"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    style="resize: none;"></textarea>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    City</label>
                                <input type="text" placeholder="Bank City"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    District</label>
                                <input type="text" placeholder="Bank District"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    State</label>
                                <input type="text" placeholder="Bank State"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Name</label>
                                <input type="text" placeholder="Bank Account Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Type</label>
                                <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="Select">Select</option>
                                    <option value="Current">Current Account</option>
                                    <option value="Savings">Savings Account</option>
                                    <option value="Cash Credit">Cash Credit (CC)</option>
                                    <option value="Overdraft">Overdraft (OD)</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Number</label>
                                <input type="text" placeholder="Bank Account Number"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                                    of Bank</label>
                                <input type="text" placeholder="MICR Code of Bank"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                                    RTGS Code No. of the Bank</label>
                                <input type="text" placeholder="IFSC / RTGS Code No."
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Bank -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="addVendorBank()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Bank Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- Bottom Right Action Buttons -->
                <div
                    class="d-flex align-items-center justify-content-end gap-2 pt-4 border-top border-secondary-subtle">
                    <button type="button" onclick="setViewMode('list')"
                        class="btn btn-sm btn-light border border-secondary-subtle text-dark rounded-1 fw-semibold">
                        Cancel
                    </button>
                    <button type="submit" id="submitBtn"
                        class="btn btn-sm text-white bg-primary rounded-1 fw-bold border-0">
                        <span id="submitBtnText">Add Vendor</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<!-- VIEW 3: UPDATE VENDOR FORM VIEW (Hidden by default) -->
<div id="vendorUpdateView" style="display: none;">
    <div class="container py-4">
        <div class="card bg-white border border-secondary-subtle rounded-0 shadow-sm text-secondary">

            <!-- Top Bar / Header -->
            <div
                class="card-header px-4 py-3 border-bottom border-secondary-subtle bg-light d-flex align-items-center justify-content-between rounded-0">
                <div class="d-flex align-items-center gap-2">
                    <button type="button" onclick="setViewMode('list')" class="btn p-1" title="Back to Vendor List">
                        <i class="mdi mdi-arrow-left text-dark"></i>
                    </button>
                    <h2 class="fs-6 fw-bold text-dark text-uppercase m-0" id="formHeaderTitle">
                        UPDATE VENDOR
                    </h2>
                </div>
                <span class="text-muted font-monospace" style="font-size: 11px;">
                    Vendor Code: <span id="vendorCodeDisplay">NEW</span>
                </span>
            </div>

            <!-- Form Body -->
            <form id="vendorForm" onsubmit="handleSubmitForm(event)" class="card-body p-4 p-md-5 fs-7">

                <!-- ROW 1: Vendor Type*, Name Of The Company*, Vendor Name* -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Type<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="vendorType"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            required>
                            <option value="Electrical">Electrical</option>
                            <option value="Cement Supplier">Cement Supplier</option>
                            <option value="Ready Mix Concrete">Ready Mix Concrete</option>
                            <option value="Structural Steel">Structural Steel</option>
                            <option value="Safety Gear & PPE">Safety Gear & PPE</option>
                            <option value="Earthmoving & Machinery">Earthmoving & Machinery</option>
                            <option value="Hardware & Tools">Hardware & Tools</option>
                            <option value="Plumbing & Sanitary">Plumbing & Sanitary</option>
                            <option value="Paints & Coatings">Paints & Coatings</option>
                            <option value="General Material">General Material</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Name Of The Company<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorCompany" required placeholder="e.g. EIBS COMPANY"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Name<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorName" required placeholder="e.g. John Doe"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                </div>

                <!-- ROW 2: Product Purchase Details, Address, Town/City -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Product Purchase Details
                        </label>
                        <input type="text" id="updateProductPurchaseInput" placeholder="Type product & press Enter..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div id="updateProductPurchaseTags" class="mt-2 d-flex flex-wrap gap-1"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Address
                        </label>
                        <textarea id="address" rows="1" placeholder="Street address, industrial estate..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></textarea>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Town/City</label>
                        <input type="text" id="townCity" placeholder="e.g. Bengaluru"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                </div>

                <!-- ROW 3: Taluka/District, State, Pincode -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Taluka/District</label>
                        <input type="text" id="talukaDistrict" placeholder="e.g. Bengaluru Urban"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State</label>
                        <input type="text" id="state" placeholder="e.g. Karnataka"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">Pincode</label>
                        <input type="text" id="pincode" placeholder="Pincode"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                    </div>
                </div>

                <!-- ROW 4: PAN No, GST No (Checkbox under GST) -->
                <div class="row g-3 mb-3 align-items-start">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">PAN
                            No</label>
                        <input type="text" id="panNo" placeholder="PAN No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">GST
                            No</label>
                        <input type="text" id="gstNo" placeholder="GST No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                        
                       
                    </div>
                     <!-- CORRECTED CHECKBOX ALIGNMENT -->
                        <div class="d-flex align-items-center justify-content-start mt-2">
                            <input type="checkbox" id="isSupplyMachinery"
                                class="border-secondary-subtle rounded-1 shadow-none m-0 me-2"
                                style="width: 1rem; height: 1rem; cursor: pointer;" />
                            <label class="fw-semibold text-secondary m-0" style="font-size: 11px; cursor: pointer;" for="isSupplyMachinery">
                                is Supply Machinery
                            </label>
                        </div>
                    
                </div>

                <!-- SECTION: Person Details (Primary & Secondary) -->
                <div id="updatePersonContainer">
                    <div class="mb-3">
                        <label class="text-dark fw-bold fs-6">Primary</label>
                    </div>
                    <div class="row g-3 mb-3 person-row">
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Type<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                <option value="Technical">Technical</option>
                                <option value="Commercial">Commercial</option>
                                <option value="Sales">Sales</option>
                                <option value="Management">Management</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Name<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" placeholder="Project Manager EiBS"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Mobile No<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" placeholder="9874561230"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                                Id</label>
                            <input type="email" placeholder="projectmanager@eibsglobal.com"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                                No</label>
                            <input type="text" placeholder="Telephone No"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Person -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="updateVendorPerson()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Contact Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- SECTION: Details for Making Payment by NEFT / RTGS (Primary & Secondary) -->
                <div id="updateBankContainer">
                    <div class="pt-3 border-top border-secondary-subtle">
                        <div class="mb-3">
                            <label class="text-dark fw-bold fs-6 mb-2">Primary Bank Details</label><br>
                            <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                                Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                                Vendors' Account
                            </h3>
                        </div>

                        <div class="row g-3 mb-3 bank-row">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Name</label>
                                <input type="text" placeholder="Bank Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Branch</label>
                                <input type="text" placeholder="Bank Branch"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Address</label>
                                <textarea rows="1" placeholder="Bank Address"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    style="resize: none;"></textarea>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    City</label>
                                <input type="text" placeholder="Bank City"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    District</label>
                                <input type="text" placeholder="Bank District"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    State</label>
                                <input type="text" placeholder="Bank State"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Name</label>
                                <input type="text" placeholder="Bank Account Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Type</label>
                                <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="Select">Select</option>
                                    <option value="Current">Current Account</option>
                                    <option value="Savings">Savings Account</option>
                                    <option value="Cash Credit">Cash Credit (CC)</option>
                                    <option value="Overdraft">Overdraft (OD)</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Number</label>
                                <input type="text" placeholder="Bank Account Number"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                                    of Bank</label>
                                <input type="text" placeholder="MICR Code of Bank"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                                    RTGS Code No. of the Bank</label>
                                <input type="text" placeholder="IFSC / RTGS Code No."
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Bank -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="updateVendorBank()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Bank Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- Bottom Right Action Buttons -->
                <div
                    class="d-flex align-items-center justify-content-end gap-2 pt-4 border-top border-secondary-subtle">
                    <button type="button" onclick="setViewMode('list')"
                        class="btn btn-sm btn-light border border-secondary-subtle text-dark rounded-1 fw-semibold">
                        Cancel
                    </button>
                    <button type="submit" id="submitBtn"
                        class="btn btn-sm text-white bg-primary rounded-1 fw-bold border-0">
                        <span id="submitBtnText">Update Vendor</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
function setViewMode(mode) {
    const listView = document.getElementById('vendorListView');
    const formView = document.getElementById('vendorFormView');
    const updateView = document.getElementById('vendorUpdateView');

    if (mode === 'form') {
        listView.style.display = 'none';
        updateView.style.display = 'none';
        formView.style.display = 'block';
        // Optional: Reset form or adjust title for "Add" vs "Update" if needed
    } else if (mode === 'list') {
        formView.style.display = 'none';
        updateView.style.display = 'none';
        listView.style.display = 'block';
    } else if (mode === 'update') {
        updateView.style.display = 'block';
        formView.style.display = 'none';
        listView.style.display = 'none';
    }
}

function loadVendorDataForUpdate(companyName, vendorAddress) {
    // 1. Assign the existing values to the input and textarea fields
    document.getElementById('esi_vendor').value = companyName;
    document.getElementById('address').value = vendorAddress;

    // 2. Optional: If your form is inside a Bootstrap Modal, open it like this:
    // var myModal = new bootstrap.Modal(document.getElementById('editVendorModal'));
    // myModal.show();
}

// Function to dynamically add Person (Add Form) - Fax No removed
function addVendorPerson() {
    const container = document.getElementById('addPersonContainer');
    const newRow = document.createElement('div');
    newRow.className = 'mt-4';
    newRow.innerHTML = `
        <div class="mb-3 border-top border-secondary-subtle pt-4">
            <label class="text-dark fw-bold fs-6">Secondary</label>
        </div>
        <div class="row g-3 mb-3 person-row">
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Type<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                    <option value="Technical">Technical</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Sales">Sales</option>
                    <option value="Management">Management</option>
                </select>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Name<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" placeholder="Project Manager EiBS"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Mobile No<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" placeholder="9874561230"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                    Id</label>
                <input type="email" placeholder="projectmanager@eibsglobal.com"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                    No</label>
                <input type="text" placeholder="Telephone No"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}

// Function to dynamically add Bank (Add Form)
function addVendorBank() {
    const container = document.getElementById('addBankContainer');
    const newRow = document.createElement('div');
    newRow.className = 'mt-4';
    newRow.innerHTML = `
        <div class="pt-4 border-top border-secondary-subtle">
            <div class="mb-3">
                <label class="text-dark fw-bold fs-6 mb-2">Secondary Bank Details</label><br>
                <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                    Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                    Vendors' Account
                </h3>
            </div>

            <div class="row g-3 mb-3 bank-row">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Name</label>
                    <input type="text" placeholder="Bank Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Branch</label>
                    <input type="text" placeholder="Bank Branch"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Address</label>
                    <textarea rows="1" placeholder="Bank Address"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                        style="resize: none;"></textarea>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        City</label>
                    <input type="text" placeholder="Bank City"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        District</label>
                    <input type="text" placeholder="Bank District"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        State</label>
                    <input type="text" placeholder="Bank State"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Name</label>
                    <input type="text" placeholder="Bank Account Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Type</label>
                    <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                        <option value="Select">Select</option>
                        <option value="Current">Current Account</option>
                        <option value="Savings">Savings Account</option>
                        <option value="Cash Credit">Cash Credit (CC)</option>
                        <option value="Overdraft">Overdraft (OD)</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Number</label>
                    <input type="text" placeholder="Bank Account Number"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                        of Bank</label>
                    <input type="text" placeholder="MICR Code of Bank"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                        RTGS Code No. of the Bank</label>
                    <input type="text" placeholder="IFSC / RTGS Code No."
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                </div>
            </div>
            <div class="col-12 d-flex justify-content-end pb-3">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}

// Function to dynamically add Person (Update Form) - Fax No removed
function updateVendorPerson() {
    const container = document.getElementById('updatePersonContainer');
    const newRow = document.createElement('div');
    newRow.className = 'mt-4';
    newRow.innerHTML = `
        <div class="mb-3 border-top border-secondary-subtle pt-4">
            <label class="text-dark fw-bold fs-6">Secondary</label>
        </div>
        <div class="row g-3 mb-3 person-row">
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Type<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                    <option value="Technical">Technical</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Sales">Sales</option>
                    <option value="Management">Management</option>
                </select>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Name<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" placeholder="Project Manager EiBS"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Mobile No<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" placeholder="9874561230"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                    Id</label>
                <input type="email" placeholder="projectmanager@eibsglobal.com"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                    No</label>
                <input type="text" placeholder="Telephone No"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}

// Function to dynamically add Bank (Update Form)
function updateVendorBank() {
    const container = document.getElementById('updateBankContainer');
    const newRow = document.createElement('div');
    newRow.className = 'mt-4';
    newRow.innerHTML = `
        <div class="pt-4 border-top border-secondary-subtle">
            <div class="mb-3">
                <label class="text-dark fw-bold fs-6 mb-2">Secondary Bank Details</label><br>
                <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                    Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                    Vendors' Account
                </h3>
            </div>

            <div class="row g-3 mb-3 bank-row">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Name</label>
                    <input type="text" placeholder="Bank Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Branch</label>
                    <input type="text" placeholder="Bank Branch"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Address</label>
                    <textarea rows="1" placeholder="Bank Address"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                        style="resize: none;"></textarea>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        City</label>
                    <input type="text" placeholder="Bank City"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        District</label>
                    <input type="text" placeholder="Bank District"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        State</label>
                    <input type="text" placeholder="Bank State"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Name</label>
                    <input type="text" placeholder="Bank Account Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Type</label>
                    <select class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                        <option value="Select">Select</option>
                        <option value="Current">Current Account</option>
                        <option value="Savings">Savings Account</option>
                        <option value="Cash Credit">Cash Credit (CC)</option>
                        <option value="Overdraft">Overdraft (OD)</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Account Number</label>
                    <input type="text" placeholder="Bank Account Number"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                        of Bank</label>
                    <input type="text" placeholder="MICR Code of Bank"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                        RTGS Code No. of the Bank</label>
                    <input type="text" placeholder="IFSC / RTGS Code No."
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                </div>
            </div>
            <div class="col-12 d-flex justify-content-end pb-3">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}

// Add a small script to handle the Product Purchase Tags dynamically
document.addEventListener('DOMContentLoaded', function() {
    function setupProductTags(inputId, containerId) {
        const input = document.getElementById(inputId);
        const container = document.getElementById(containerId);
        if(!input || !container) return;

        let tags = [];
        
        function renderTags() {
            container.innerHTML = '';
            tags.forEach((tag, index) => {
                const chip = document.createElement('span');
                chip.className = 'badge bg-primary-subtle text-primary border border-primary rounded-pill px-2 py-1 d-inline-flex align-items-center gap-1';
                chip.style.fontSize = '10px';
                chip.innerHTML = `
                    ${tag}
                    <i class="mdi mdi-close cursor-pointer" style="font-size: 12px;" onclick="removeTag_${inputId}(${index})"></i>
                `;
                container.appendChild(chip);
            });
        }

        window[`removeTag_${inputId}`] = function(index) {
            tags.splice(index, 1);
            renderTags();
        };

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                const val = input.value.trim();
                if (val && !tags.includes(val)) {
                    tags.push(val);
                    input.value = '';
                    renderTags();
                }
            }
        });
    }

    setupProductTags('productPurchaseInput', 'productPurchaseTags');
    setupProductTags('updateProductPurchaseInput', 'updateProductPurchaseTags');
});
</script>
@endsection