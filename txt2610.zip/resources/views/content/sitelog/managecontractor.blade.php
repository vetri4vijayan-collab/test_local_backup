@extends('layouts/layoutMaster')

@section('title', 'Contractor')

@section('content')
<style>
  /* Hide cursor globally except inside input fields */
  * {
    caret-color: transparent !important;
  }
  input, textarea, select {
    caret-color: auto !important;
  }
</style>

<div id="contractorlist">
  <div class="card rounded">
      <div class="d-flex justify-content-between p-3">
          <div class="d-flex gap-3 align-items-center">
              <i class="mdi mdi-office-building text-primary fs-4"></i>

              <div class="d-flex flex-column">
                  <label class="text-primary fw-bold mb-1 text-uppercase">Contractor</label>

                  <span class="text-muted fw-semibold">
                      Site Operations Management & Logs
                  </span>
              </div>
          </div>
          <div>
            <button
                type="button"
                class="btn btn-primary d-flex align-items-center gap-2"
                onclick="showAddContractor()"
            >
                <i class="mdi mdi-plus"></i>
                Add Contractor
            </button>
          </div>
      </div>
  </div>

  <div class="card rounded shadow-sm mt-3">
      <div class="card-body p-4">
          <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
              <div class="position-relative" style="max-width: 500px; width: 100%;">
                  <i class="mdi mdi-magnify position-absolute top-50 start-0 translate-middle-y ms-3 text-muted fs-5"></i>
                  <input
                      type="search"
                      class="form-control ps-5 rounded"
                      placeholder="Search by contractor name, contact, GST, PAN, address..."
                  />
              </div>

              <div class="d-flex align-items-center gap-2">
                  <label for="tradeFilter" class="fw-semibold text-nowrap mb-0">
                      Filter by trade:
                  </label>

                  <select id="tradeFilter" class="form-select" style="min-width: 220px;">
                      <option value="">All Trades</option>
                      <option value="plumbing">Plumbing Contractor</option>
                      <option value="civil">Civil & Concreting Contractor</option>
                      <option value="steel">Steel & Rebar Contractor</option>
                  </select>
              </div>
          </div>

          <div class="table-responsive rounded">
              <table class="table border table-hover align-middle mb-0">
                  <thead class="table-light">
                      <tr>
                          <th class="text-dark text-uppercase fs-8">Contractor Name</th>
                          <th class="text-dark text-uppercase fs-8">Type & Trade</th>
                          <th class="text-dark text-uppercase fs-8">Contact Person</th>
                          <th class="text-dark text-uppercase fs-8">City & Statect</th>
                          <th class="text-dark text-uppercase fs-8">PAN / GST No</th>
                          <th class="text-dark text-uppercase fs-8">Bank / Account No</th>
                          <th class="text-dark text-uppercase fs-8">Status</th>
                          <th class="text-dark text-uppercase fs-8 text-center">Action</th>
                      </tr>
                  </thead>

                  <tbody>
                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      AquaLine Plumbing Works
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CON-PLM-01
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column align-items-start">
                                  <span class="fw-semibold text-dark fs-7">
                                      Plumbing Contractor
                                  </span>
                                  <span class="text-muted fs-8">
                                      Internal & External Sanitary Piping
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <span class="text-dark fw-semibold fs-7">Selvam (Supervisor)</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-muted fs-8">9543216789</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold text-dark fs-7">Madurai</span>
                                  <small class="text-muted">Tamil Nadu - 625001</small>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-dark fs-8">ABXFS5510P</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-dark fs-8">33ABXFS5510P1ZG</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="">
                                    <label class="text-black fs-7">IOB</label>
                                  </div>
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">A/C :</label>
                                    <span class="text-dark fs-8">444455556666</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">IFSC :</label>
                                    <span class="text-dark fs-8">IOBA0000789</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewContractorModal"
                                      onclick="showContractor(
                                          'CON-PLM-01',
                                          'civil',
                                          'AquaLine Plumbing Works',
                                          '87/2 G.N Chetty Road',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          '625001',
                                          'ABXFS5510P',
                                          '33ABXFS5510P1ZG',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'Selvam',
                                          '9876543210',
                                          'selvam@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'IOB',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          'AquaLine Plumbing Works',
                                          'current',
                                          '444455556666',
                                          '620005',
                                          'IOBA0000789'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateContractor(
                                          'CON-PLM-01',
                                          'civil',
                                          'AquaLine Plumbing Works',
                                          '87/2 G.N Chetty Road',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          '625001',
                                          'ABXFS5510P',
                                          '33ABXFS5510P1ZG',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'Selvam',
                                          '9876543210',
                                          'selvam@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'IOB',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          'AquaLine Plumbing Works',
                                          'current',
                                          '444455556666',
                                          '620005',
                                          'IOBA0000789'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>

                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteContractorModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>

                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      Apex Structural Sub-Contractors
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CON-CIV-02
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column align-items-start">
                                  <span class="fw-semibold text-dark fs-7">
                                      Civil & Concreting Contractor
                                  </span>
                                  <span class="text-muted fs-8">
                                      Pier Concreting & Pier Cap Assembly
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <span class="text-dark fw-semibold fs-7">Muthu Pandian (Project Lead)</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-muted fs-8">9789011223</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold text-dark fs-7">Chennai</span>
                                  <small class="text-muted">Tamil Nadu - 600032 </small>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-dark fs-8">AAACP1234H</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-dark fs-8">33AAACP1234H1Z8</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="">
                                    <label class="text-black fs-7">State Bank of India</label>
                                  </div>
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">A/C :</label>
                                    <span class="text-dark fs-8">332211445566</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">IFSC :</label>
                                    <span class="text-dark fs-8">SBIN0000833</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewContractorModal"
                                      onclick="showContractor(
                                          'CON-PLM-02',
                                          'civil',
                                          'Apex Structural Sub-Contractors',
                                          '87/2 G.N Chetty Road',
                                          'Chennai',
                                          'Chennai',
                                          'Tamil Nadu',
                                          '625001',
                                          'AAACP1234H',
                                          '33AAACP1234H1Z8',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'Muthu Pandian ',
                                          '9876543210',
                                          'pandian@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'State Bank of India',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          'Apex Structural Sub-Contractors',
                                          'current',
                                          '444455556666',
                                          '620005',
                                          'SBIN0000833'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateContractor(
                                          'CON-PLM-01',
                                          'civil',
                                          'AquaLine Plumbing Works',
                                          '87/2 G.N Chetty Road',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          '625001',
                                          'ABXFS5510P',
                                          '33ABXFS5510P1ZG',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'Selvam',
                                          '9876543210',
                                          'selvam@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'IOB',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          'AquaLine Plumbing Works',
                                          'current',
                                          '444455556666',
                                          '620005',
                                          'IOBA0000789'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>

                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteContractorModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>

                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      Star Bar-Bending & Rebar Works
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CON-STL-03
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column align-items-start">
                                  <span class="fw-semibold text-dark fs-7">
                                      Steel & Rebar Contractor
                                  </span>
                                  <span class="text-muted fs-8">
                                      Fe550D Rebar Caging & Binding
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <span class="text-dark fw-semibold fs-7">R. Velu (Senior Supervisor)</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-muted fs-8">9841233445</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold text-dark fs-8">Chennai</span>
                                  <small class="text-muted">Tamil Nadu - 600032</small>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-dark fs-8">AABCS9876K</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-dark fs-8">33AABCS9876K1Z3</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="">
                                    <label class="text-black fs-7">HDFC Bank</label>
                                  </div>
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">A/C :</label>
                                    <span class="text-dark fs-8">50200011223344</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">IFSC :</label>
                                    <span class="text-dark fs-8">HDFC0000060</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewContractorModal"
                                      onclick="showContractor(
                                          'CON-PLM-03',
                                          'civil',
                                          'Star Bar-Bending & Rebar Works',
                                          '87/2 G.N Chetty Road',
                                          'Chennai',
                                          'Chennai',
                                          'Tamil Nadu',
                                          '625001',
                                          'AABCS9876K',
                                          '33AABCS9876K1Z3',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'R. Velu',
                                          '9876543210',
                                          'velu@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'HDFC Bank',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Chennai',
                                          'Chennai',
                                          'Tamil Nadu',
                                          'Star Bar-Bending & Rebar Works',
                                          'current',
                                          '50200011223344',
                                          '620005',
                                          'HDFC0000060'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateContractor(
                                          'CON-PLM-01',
                                          'civil',
                                          'AquaLine Plumbing Works',
                                          '87/2 G.N Chetty Road',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          '625001',
                                          'ABXFS5510P',
                                          '33ABXFS5510P1ZG',
                                          '4444 5555 6666',
                                          'ESI400500600',
                                          'EPF400500600',
                                          'commercial',
                                          'Selvam',
                                          '9876543210',
                                          'selvam@example.com',
                                          '0452-2698712',
                                          '0452-2698712',
                                          'IOB',
                                          'South Avani Moola Street',
                                          'South Avani Moola Street',
                                          'Madurai',
                                          'Madurai',
                                          'Tamil Nadu',
                                          'AquaLine Plumbing Works',
                                          'current',
                                          '444455556666',
                                          '620005',
                                          'IOBA0000789'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>

                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteContractorModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</div>

<!-- add contractor -->
  <div id="addContractor" class="d-none">
    <div class="card rounded shadow-sm mt-3">
      <div class="card-header bg-white border-bottom py-3">
          <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center gap-2">
                  <button
                      type="button"
                      class="btn"
                      title="Back"
                      onclick="showContractorList()"
                  >
                      <i class="mdi mdi-chevron-double-left"></i>
                  </button>

                  <div>
                      <h6 class="mb-0 text-dark fw-bold text-uppercase">
                          Add Contractor
                      </h6>
                  </div>
              </div>

              <div>
                  <span class="">
                      System Code: CON-0003
                  </span>
              </div>

          </div>
      </div>

      <div class="card-body p-4">
          <div class="row g-4 border-b mb-4">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contractor Type
                      <span class="text-danger">*</span>
                  </label>

                  <select class="form-select">
                      <option value="">Select Contractor Type</option>
                      <option value="civil">Plumbing Contractor</option>
                      <option value="electrical">Civil & Concreting Contractor</option>
                      <option value="plumbing">Steel & Rebar Contractor</option>
                  </select>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Name of the Company
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="e.g. AquaLine Plumbing Works"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contract Name
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="Enter Contract Name"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Address
                  </label>

                  <textarea
                      class="form-control"
                      rows="1"
                      placeholder="Enter contractor address"
                  ></textarea>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Town/City
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="madurai"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Taluka/District
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="madurai"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      value="Tamil nadu"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Pincode
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="625001"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      PAN NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="ABXFS5510P"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      GST NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="33ABXFS5510P1ZG"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Aadhar No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="4444 5555 6666"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      ESI No
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="ESI400500600"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      EPF No
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="EPF400500600"
                  />
              </div>
          </div>

          <div id="personcontainer">
              <div class="mb-3">
                  <label class="text-black fw-bold fs-5">Primary</label>
              </div>
              <div class="row g-4 person-row">
                    <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Type
                          <span class="text-danger">*</span>
                      </label>

                      <select class="form-select">
                          <option value="">Commercial/Technical</option>
                          <option value="civil">Commercial Admin</option>
                          <option value="electrical">Technical lead</option>
                          <option value="plumbing">Site Representative</option>
                      </select>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Name
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="salvam(supervisor)"
                      />
                  </div>

                  <!-- Contact Number -->
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Mobile No
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="tel"
                          class="form-control"
                          placeholder="98765 43210"
                      />
                  </div>

                  <!-- Email -->
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Email
                      </label>

                      <input
                          type="email"
                          class="form-control"
                          placeholder="salvam@example.com"
                      />
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Telephone No
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="0452-2698712"
                      />
                  </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-align-items-end mt-12">
            <button type="button" class="btn" onclick="addperson()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>

          <div class="mt-12 pt-4 border-top" id="bankcontainer">
              <div class="mb-3">
                <label class="text-black fw-bold fs-5 mb-2">Primary Bank Details</label><br>
                <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                  / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
                </label>
              </div>

              <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="IOB"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="South avani moola street"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="South avani moola street"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank city
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Madurai"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank District
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Madurai"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank State
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        value="Tamil nadu"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Aqualine plumbing works"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>

                    <select class="form-select">
                      <option value="">Current account</option>
                      <option value="civil">Saveing Account</option>
                      <option value="electrical">OverDraft</option>
                  </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="444455556666"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="625020005"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="IOBA0000789"
                    />
                </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-align-items-end mt-12">
            <button type="button" class="btn" onclick="addbank()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>
      </div>

      <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
        <button
            type="button"
            class="btn btn-outline-secondary"
            onclick="showContractorList()"
        >
            Cancel
        </button>

        <button
            type="button"
            class="btn btn-primary"
        >
            Save Contractor
        </button>
      </div>
    </div>
  </div>

<!-- update contractor -->
  <div id="updateContractor" class="d-none">
    <div class="card rounded shadow-sm mt-3">
      <div class="card-header bg-white border-bottom py-3">
          <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center gap-2">
                  <button
                      type="button"
                      class="btn"
                      title="Back"
                      onclick="showContractorList()"
                  >
                      <i class="mdi mdi-chevron-double-left"></i>
                  </button>

                  <div>
                      <h6 class="mb-0 text-dark fw-bold text-uppercase">
                          Update Contractor
                      </h6>
                  </div>
              </div>

              <div>
                  <span id="updateSystemCode">
                      System Code: CON-0003
                  </span>
              </div>

          </div>
      </div>

      <div class="card-body p-4">
          <div class="row g-4 border-b mb-4">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contractor Type
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateContractorType" class="form-select">
                      <option value="">Select Contractor Type</option>
                      <option value="plumbing">Plumbing Contractor</option>
                      <option value="civil">Civil & Concreting Contractor</option>
                      <option value="steel">Steel & Rebar Contractor</option>
                  </select>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                  Name of the Company
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateContractorCompany"
                      class="form-control"
                      placeholder="e.g. AquaLine Plumbing Works"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contract Name
                  </label>

                  <input
                      type="text"
                      id="updateContractName"
                      class="form-control"
                      placeholder="Enter Contract Name"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Address
                  </label>

                  <textarea
                      id="updateAddress"
                      class="form-control"
                      rows="1"
                      placeholder="Enter contractor address"
                  ></textarea>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Town/City
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateTown"
                      class="form-control"
                      placeholder="Madurai"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Taluka/District
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateDistrict"
                      class="form-control"
                      placeholder="Madurai"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateState"
                      class="form-control"
                      value="Tamil Nadu"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Pincode
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePincode"
                      class="form-control"
                      placeholder="625001"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      PAN NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePan"
                      class="form-control"
                      placeholder="ABXFS5510P"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      GST NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateGst"
                      class="form-control"
                      placeholder="33ABXFS5510P1ZG"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Aadhar No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateAadhar"
                      class="form-control"
                      placeholder="4444 5555 6666"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      ESI No
                  </label>

                  <input
                      type="text"
                      id="updateEsi"
                      class="form-control"
                      placeholder="ESI400500600"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      EPF No
                  </label>

                  <input
                      type="text"
                      id="updateEpf"
                      class="form-control"
                      placeholder="EPF400500600"
                  />
              </div>
          </div>

          <div id="updatepersoncontainer">
            <div class="mb-3">
                <label class="text-black fw-bold fs-5">Primary</label>
            </div>
            <div class="row g-4 person-row">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Person Type
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updatePersonType" class="form-select">
                    <option value="">Commercial/Technical</option>
                    <option value="commercial">Commercial Admin</option>
                    <option value="technical">Technical Lead</option>
                    <option value="site">Site Representative</option>
                </select>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Person Name
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePersonName"
                      class="form-control"
                      placeholder="Selvam (Supervisor)"
                  />
              </div>

              <!-- Contact Number -->
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Mobile No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="tel"
                      id="updateMobile"
                      class="form-control"
                      placeholder="98765 43210"
                  />
              </div>

              <!-- Email -->
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Email
                  </label>

                  <input
                      type="email"
                      id="updateEmail"
                      class="form-control"
                      placeholder="selvam@example.com"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Telephone No
                  </label>

                  <input
                      type="text"
                      id="updateTelephone"
                      class="form-control"
                      placeholder="0452-2698712"
                  />
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-end align-items-end mt-4">
              <button
                  class="btn"
                  type="button"
                  onclick="updatecontractor()"
              >
                  <i class="mdi mdi-plus border rounded p-1"></i>
              </button>
          </div>

          <div class="mt-12 pt-4 border-top" id="updatebankcontainer">
            <div class="mb-3">
              <label class="text-black fw-bold fs-5 mb-2">Primary Bank Details</label><br>
              <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
              </label>
            </div>
              <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankName" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankBranch" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankAddress" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank city
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankCity" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank District
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankDistrict" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank State
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankState" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateAccountName" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>

                    <select id="updateAccountType" class="form-select">
                        <option value="">Select Account Type</option>
                        <option value="current">Current Account</option>
                        <option value="saving">Saving Account</option>
                        <option value="overdraft">OverDraft</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateAccountNumber" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateMicr" type="text" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateIfsc" type="text" class="form-control">
                </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-items-end mt-4">
            <button type="button" class="btn" onclick="addUpdateBank()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>
      </div>

      <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
        <button
            type="button"
            class="btn btn-outline-secondary"
            onclick="showContractorList()"
        >
            Cancel
        </button>

        <button
            type="button"
            class="btn btn-primary"
        >
            Save Contractor
        </button>
      </div>
    </div>
  </div>

<!-- view Contractor -->
  <div class="modal fade" id="viewContractorModal" tabindex="-1" aria-labelledby="viewContractorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-bottom">
                <h5 class="modal-title mb-4" id="viewContractorModalLabel">
                    Contractor Details
                </h5>

                <button
                    type="button"
                    class="btn-close mb-4"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contractor Code
                        </label>
                        <div class="fw-semibold" id="viewContractorCode">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Type
                        </label>
                        <div class="fw-semibold" id="viewContractorType">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contractor Name
                        </label>
                        <div class="fw-semibold" id="viewContractorName">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contact Person
                        </label>
                        <div class="fw-semibold" id="viewContactPerson">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contact Number
                        </label>
                        <div class="fw-semibold" id="viewContactNo">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Email
                        </label>
                        <div class="fw-semibold" id="viewEmail">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            PAN
                        </label>
                        <div class="fw-semibold" id="viewPan">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            GST
                        </label>
                        <div class="fw-semibold" id="viewGst">-</div>
                    </div>

                    <div class="col-12">
                        <label class="form-label text-muted">
                            Address
                        </label>
                        <div class="fw-semibold" id="viewAddress">-</div>
                    </div>
                </div>

                <div class="border rounded mb-4 mt-4">
                  <div class="d-flex align-items-center mb-3 p-2">
                      <i class="mdi mdi-bank-outline fs-5 text-primary me-2"></i>
                      <h6 class="mb-0 fw-semibold">Bank Details</h6>
                  </div>

                  <div class="table-responsive">
                      <table class="table align-middle mb-0">
                          <tbody>
                              <tr class="border-top">
                                  <td class="text-muted fw-medium py-3" style="width: 40%;">
                                      Bank Name
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankName">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Account Name
                                  </td>
                                  <td class="fw-semibold py-3" id="viewAccountName">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Account Number
                                  </td>
                                  <td class="fw-semibold py-3" id="viewAccountNo">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      IFSC Code
                                  </td>
                                  <td class="fw-semibold py-3" id="viewIfsc">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Branch
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankBranch">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Address
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankAddress">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      City
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankCity">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      District
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankDistrict">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      State
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankState">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Pincode
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankPincode">
                                      -
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
                </div>
            </div>
        </div>
    </div>
  </div>

<!-- delete contractor -->
  <div class="modal fade" id="deleteContractorModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 rounded-4 shadow w-100" style="max-width: 400px">
              <div class="modal-body text-center p-4">
                  <div
                      class="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-3"
                      style="
                          width: 48px;
                          height: 48px;
                          background-color: #fff0f1;
                          color: #ff3e5b;
                      "
                  >
                      <i class="mdi mdi-trash-can-outline fs-4"></i>
                  </div>

                  <h5 class="fw-bold text-dark mb-2">
                      Confirm Deletion
                  </h5>
                  <p class="text-muted small mb-4">
                      Are you sure you want to delete contractor record
                      <strong>"SPK And Co., - VF"</strong>?
                      This action cannot be undone.
                  </p>
                  <div class="row g-2">
                      <div class="col-6">
                          <button
                              type="button"
                              class="btn btn-light w-100"
                              data-bs-dismiss="modal"
                          >
                              Cancel
                          </button>
                      </div>

                      <div class="col-6">
                          <button
                              type="button"
                              class="btn btn-danger w-100"
                          >
                              Delete
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<!-- add contractor -->
  <script>
    function showAddContractor() {
        document.getElementById('contractorlist').classList.add('d-none');
        document.getElementById('addContractor').classList.remove('d-none');
        document.getElementById('updateContractor').classList.add('d-none');
    }

    function showContractorList() {
        document.getElementById('addContractor').classList.add('d-none');
        document.getElementById('updateContractor').classList.add('d-none');
        document.getElementById('contractorlist').classList.remove('d-none');
    }
  </script>

<!-- update contractor -->
  <script>
    function showUpdateContractor(
        code,
        contractorType,
        contractorCompany,
        address,
        town,
        district,
        state,
        pincode,
        pan,
        gst,
        aadhar,
        esi,
        epf,
        personType,
        personName,
        mobile,
        email,
        telephone,
        fax,
        bankName,
        bankBranch,
        bankAddress,
        bankCity,
        bankDistrict,
        bankState,
        accountName,
        accountType,
        accountNumber,
        micr,
        ifsc
    ) {
        document.getElementById('contractorlist').classList.add('d-none');
        document.getElementById('addContractor').classList.add('d-none');
        document.getElementById('updateContractor').classList.remove('d-none');

        document.getElementById('updateSystemCode').innerText = 'System Code: ' + code;
        document.getElementById('updateContractorType').value = contractorType;
        document.getElementById('updateContractorCompany').value = contractorCompany;
        // Note: Contract Name is not passed in the sample JS parameters, but the field exists.
        document.getElementById('updateAddress').value = address;
        document.getElementById('updateTown').value = town;
        document.getElementById('updateDistrict').value = district;
        document.getElementById('updateState').value = state;
        document.getElementById('updatePincode').value = pincode;
        document.getElementById('updatePan').value = pan;
        document.getElementById('updateGst').value = gst;
        document.getElementById('updateAadhar').value = aadhar;
        document.getElementById('updateEsi').value = esi;
        document.getElementById('updateEpf').value = epf;
        document.getElementById('updatePersonType').value = personType;
        document.getElementById('updatePersonName').value = personName;
        document.getElementById('updateMobile').value = mobile;
        document.getElementById('updateEmail').value = email;
        document.getElementById('updateTelephone').value = telephone;

        document.getElementById('updateBankName').value = bankName;
        document.getElementById('updateBankBranch').value = bankBranch;
        document.getElementById('updateBankAddress').value = bankAddress;
        document.getElementById('updateBankCity').value = bankCity;
        document.getElementById('updateBankDistrict').value = bankDistrict;
        document.getElementById('updateBankState').value = bankState;
        document.getElementById('updateAccountName').value = accountName;
        document.getElementById('updateAccountType').value = accountType;
        document.getElementById('updateAccountNumber').value = accountNumber;
        document.getElementById('updateMicr').value = micr;
        document.getElementById('updateIfsc').value = ifsc;
    }
  </script>

<!-- view contractor -->
  <script>
    function showContractor(
        code,
        type,
        name,
        address,
        city,
        district,
        state,
        pincode,
        pan,
        gst,
        aadhaar,
        esi,
        epf,
        category,
        contactPerson,
        contactNo,
        email,
        phone,
        fax,
        bankName,
        bankBranch,
        bankAddress,
        bankCity,
        bankDistrict,
        bankState,
        accountName,
        status,
        accountNo,
        bankPincode,
        ifsc
    ) {
        document.getElementById('viewContractorCode').textContent = code || '-';
        document.getElementById('viewContractorType').textContent = type || '-';
        document.getElementById('viewContractorName').textContent = name || '-';
        document.getElementById('viewContactPerson').textContent = contactPerson || '-';
        document.getElementById('viewContactNo').textContent = contactNo || '-';
        document.getElementById('viewEmail').textContent = email || '-';
        document.getElementById('viewPan').textContent = pan || '-';
        document.getElementById('viewGst').textContent = gst || '-';
        document.getElementById('viewAddress').textContent =
            (address || '-') + ', ' +
            (city || '-') + ', ' +
            (state || '-') + ' - ' +
            (pincode || '-');

        document.getElementById('viewBankName').textContent = bankName || '-';
        document.getElementById('viewAccountName').textContent = accountName || '-';
        document.getElementById('viewAccountNo').textContent = accountNo || '-';
        document.getElementById('viewIfsc').textContent = ifsc || '-';
        document.getElementById('viewBankBranch').textContent = bankBranch || '-';
        document.getElementById('viewBankAddress').textContent = bankAddress || '-';
        document.getElementById('viewBankCity').textContent = bankCity || '-';
        document.getElementById('viewBankDistrict').textContent = bankDistrict || '-';
        document.getElementById('viewBankState').textContent = bankState || '-';
        document.getElementById('viewBankPincode').textContent = bankPincode || '-';
    }
  </script>

  <!-- add modal add person -->
   <script>
      function addperson() {

          const container = document.getElementById('personcontainer');

          const newPerson = document.createElement('div');

          newPerson.className = 'mt-4';

          newPerson.innerHTML = `
              <div class="mb-3">
                  <label class="text-black fw-bold fs-5">Secondary</label>
              </div>
              <div class="row g-4 person-row">
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Type
                          <span class="text-danger">*</span>
                      </label>

                      <select class="form-select">
                          <option value="">Commercial/Technical</option>
                          <option value="commercial">Commercial Admin</option>
                          <option value="technical">Technical Lead</option>
                          <option value="site">Site Representative</option>
                      </select>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Name
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="Salvam (Supervisor)"
                      />
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Mobile No
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="tel"
                          class="form-control"
                          placeholder="98765 43210"
                      />
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Email
                      </label>

                      <input
                          type="email"
                          class="form-control"
                          placeholder="salvam@example.com"
                      />
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Telephone No
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="0452-2698712"
                      />
                  </div>

                  <div class="col-12 d-flex justify-content-end">
                      <button
                          type="button"
                          class="btn btn-outline-danger btn-sm"
                          onclick="removePerson(this)"
                      >
                          <i class="mdi mdi-delete-outline"></i>
                          Remove
                      </button>
                  </div>
              </div>
          `;

          container.appendChild(newPerson);
      }


      function removePerson(button) {

          const personRow = button.closest('.mt-4');

          if (personRow) {
              personRow.remove();
          }

      }
  </script>

<!-- update modal add person -->
  <script>
    function updatecontractor() {

        const container = document.getElementById('updatepersoncontainer');

        const newPerson = document.createElement('div');

        newPerson.className = 'mt-4';

        newPerson.innerHTML = `
            <div class="mb-3">
                <label class="text-black fw-bold fs-5">Secondary</label>
            </div>
            <div class="row g-4 person-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Type
                        <span class="text-danger">*</span>
                    </label>

                    <select class="form-select">
                        <option value="">Commercial/Technical</option>
                        <option value="commercial">Commercial Admin</option>
                        <option value="technical">Technical Lead</option>
                        <option value="site">Site Representative</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Selvam (Supervisor)"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Mobile No
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="tel"
                        class="form-control"
                        placeholder="98765 43210"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Email
                    </label>

                    <input
                        type="email"
                        class="form-control"
                        placeholder="selvam@example.com"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Telephone No
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="0452-2698712"
                    />
                </div>

                <div class="col-12 d-flex justify-content-end">
                    <button
                        type="button"
                        class="btn btn-outline-danger btn-sm"
                        onclick="removePerson(this)"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                        Remove
                    </button>
                </div>
            </div>
        `;

        container.appendChild(newPerson);
    }

    function removePerson(button) {
        const personRow = button.closest('.mt-4');
        if (personRow) {
            personRow.remove();
        }
    }
  </script>

  <!-- add modal add bank -->
  <script>
    function addbank() {
        const container = document.getElementById('bankcontainer');
        const newBank = document.createElement('div');
        newBank.className = 'mt-4 border-top pt-4';
        
        newBank.innerHTML = `
            <div class="mb-3">
              <label class="text-black fw-bold fs-5 mb-2">Secondary Bank Details</label><br>
              <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
              </label>
            </div>
            <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="IOB" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="South avani moola street" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="South avani moola street" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank city
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Madurai" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank District
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Madurai" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank State
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" value="Tamil nadu" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Aqualine plumbing works" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>
                    <select class="form-select">
                      <option value="">Current account</option>
                      <option value="civil">Saveing Account</option>
                      <option value="electrical">OverDraft</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="444455556666" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="625020005" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="IOBA0000789" />
                </div>
                <div class="col-12 d-flex justify-content-end">
                    <button
                        type="button"
                        class="btn btn-outline-danger btn-sm"
                        onclick="removeBank(this)"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                        Remove
                    </button>
                </div>
            </div>
        `;
        container.appendChild(newBank);
    }

    function removeBank(button) {
        const bankRow = button.closest('.mt-4');
        if (bankRow) {
            bankRow.remove();
        }
    }
  </script>

  <!-- update modal add bank -->
  <script>
    function addUpdateBank() {
        const container = document.getElementById('updatebankcontainer');
        const newBank = document.createElement('div');
        newBank.className = 'mt-4 border-top pt-4';
        
        newBank.innerHTML = `
            <div class="mb-3">
              <label class="text-black fw-bold fs-5 mb-2">Secondary Bank Details</label><br>
              <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
              </label>
            </div>
            <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="IOB" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="South avani moola street" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="South avani moola street" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank city
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Madurai" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank District
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Madurai" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank State
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" value="Tamil nadu" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Aqualine plumbing works" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>
                    <select class="form-select">
                      <option value="">Current account</option>
                      <option value="civil">Saveing Account</option>
                      <option value="electrical">OverDraft</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="444455556666" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="625020005" />
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="IOBA0000789" />
                </div>
                <div class="col-12 d-flex justify-content-end">
                    <button
                        type="button"
                        class="btn btn-outline-danger btn-sm"
                        onclick="removeBank(this)"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                        Remove
                    </button>
                </div>
            </div>
        `;
        container.appendChild(newBank);
    }

    function removeBank(button) {
        const bankRow = button.closest('.mt-4');
        if (bankRow) {
            bankRow.remove();
        }
    }
  </script>
@endsection