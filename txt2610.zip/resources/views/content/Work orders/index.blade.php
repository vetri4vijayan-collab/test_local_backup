@extends('layouts/contentNavbarLayout')

@section('title', 'Work Orders')

@section('content')

<div class="container-fluid">

    <div class="card mb-4 shadow-sm rounded-2">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div class="d-flex align-items-center gap-3">

                    <div class="">
                    </div>

                    <div>

                        <h4 class="fw-bold mb-1">
                            Planning & Quantity Surveying (QS) Engine
                        </h4>

                        <p class="text-muted mb-0">
                            Master Schedules, Work Orders, RA Billing & Material Verification
                        </p>

                    </div>

                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <div class="settings-tabs-wrapper">

                        <div class="d-flex align-items-center gap-2">

                            <button
                                type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                                <i class="mdi mdi-chevron-left"></i>

                            </button>

                            <div class="settings-tabs-scroller">

                                <div
                                    class="settings-tabs-track"
                                    id="qsTabsTrack">

                                    <a
                                        href="{{ route('planning-qs.work-orders') }}"
                                        class="settings-tab-pill {{ request()->routeIs('planning-qs.work-orders') ? 'active' : '' }}">

                                        Client Work Order

                                    </a>

                                    <a
                                        href="{{ route('planning-qs.work-orders.sub') }}"
                                        class="settings-tab-pill {{ request()->routeIs('planning-qs.work-orders.sub') ? 'active' : '' }}">

                                        Sub Contractor Work Orders

                                    </a>

                                </div>

                            </div>

                            <button
                                type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                                <i class="mdi mdi-chevron-right"></i>

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


<div class="card border-0 shadow-sm rounded-3 mb-3">

    <div class="card-body p-6">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

            <div>
                <p class="text-muted small mb-0">
                    <strong>All Projects (Unified View)</strong>
                </p>
            </div>

            <!-- Right side: Filters + Button -->
            <div class="d-flex align-items-center gap-2 flex-wrap">

                <select
                    id="projectFilter"
                    class="form-select form-select-sm"
                    style="width:220px;">

                    <option value="all">
                        All Projects (Unified View)
                    </option>

                    <option value="MAA-MET-C4">
                        Chennai Metro Phase 2
                    </option>

                    <option value="ADY-RES">
                        Adyar Prevalent Residences
                    </option>

                    <option value="ECK-BRG">
                        East Coast Road Elevated Bridge
                    </option>

                </select>

                <select
                    id="statusFilter"
                    class="form-select form-select-sm"
                    style="width:160px;">

                    <option value="all">
                        All Status
                    </option>

                    <option value="Active">
                        Active
                    </option>

                    <option value="Completed">
                        Completed
                    </option>

                    <option value="Pending">
                        Pending
                    </option>

                </select>

                <button
                    type="button"
                    class="btn btn-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#issueWorkOrderModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Issue Client WO

                </button>

            </div>

        </div>

    </div>

</div>



    <div
        class="card mb-3 work-order-card shadow-sm"
        data-project="MAA-MET-C4"
        data-status="Active">

        <div class="card-body p-4">

            <div class="row align-items-center">

                <div class="col-lg-9">

                    <div class="work-order-header-line">

                        <span class="badge rounded-pill project-title-text text-white bg-primary">

                            <i class="mdi mdi-file-document-outline me-1"></i>

                            MAA-MET-C4 — Chennai Metro Phase 2 - Corridor 4

                        </span>

                        <span class="header-separator"></span>

                        <span class="badge wo-number-badge">

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">
                                MO/CRL/2025/089
                            </span>

                        </span>

                        <span class="header-separator"></span>

                        <span class="issued-date">

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary">

                                <i class="mdi mdi-calendar-outline"></i>

                                Issued:

                                18 Aug 2025

                            </span>

                        </span>

                        <span class="badge bg-label-success">
                            Active
                        </span>

                    </div>


                    <p class="mb-1 fw-semibold text-dark mt-2">
                        Corridor 4 Piling & Substructure Contract
                    </p>


                    <div class="small text-muted">

                        <i class="mdi mdi-account-outline me-1"></i>

                        Signatory:

                        <span class="text-dark fw-semibold">
                            Er Rajesh Gopal (CMRL)
                        </span>

                    </div>

                </div>


                <div class="col-lg-3 mt-3 mt-lg-0">

                    <div class="d-flex justify-content-end align-items-center gap-3">

                        <div class="boq-value-box text-end">

                            <span class="small text-muted d-block">
                                TOTAL BOQ VALUE
                            </span>

                            <span class="fs-4 fw-bold text-success">
                                ₹7.13 Cr
                            </span>

                        </div>

                        <span
                            class="work-order-action-icon delete-btn"
                            title="Delete"
                            onclick="return confirm('Are you sure you want to delete this work order?')">

                            <i class="mdi mdi-delete-outline"></i>

                        </span>

                        <span
                            class="work-order-action-icon expand-btn"
                            data-bs-toggle="collapse"
                            data-bs-target="#collapseWO0"
                            aria-expanded="false"
                            title="Expand">

                            <i class="mdi mdi-chevron-down"></i>

                        </span>

                    </div>

                </div>

            </div>


            <div
                class="collapse mt-4"
                id="collapseWO0">

                <div class="border-top pt-4">

                    <div class="row g-3 mb-4">

                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">

                                            <i class="mdi mdi-file-tree-outline"></i>

                                        </div>

                                        <small class="text-muted fw-semibold">
                                            TECHNICAL SCOPE
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">

                                        Piling work up to 25m depth, installation of piling caps,
                                        and pier construction.

                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">

                                            <i class="mdi mdi-chart-donut"></i>

                                        </div>

                                        <small class="text-muted fw-semibold">
                                            EXECUTION ANALYTICS
                                        </small>

                                    </div>

                                    <div class="mb-2">

                                        <span class="badge bg-label-success">
                                            100% Validated
                                        </span>

                                    </div>

                                    <small class="text-muted">
                                        12 Structures Linked
                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">

                                            <i class="mdi mdi-clipboard-check-outline"></i>

                                        </div>

                                        <small class="text-muted fw-semibold">
                                            CHECKLIST VERIFICATION
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">

                                        Dynamic BOQ Linked to Structure Checklist

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="card border-0 shadow-sm rounded-3 mb-4">

                        <div class="card-body p-4">

                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                <div class="d-flex align-items-center gap-3">

                                    <div class="table-section-icon">

                                        <i class="mdi mdi-format-list-bulleted"></i>

                                    </div>

                                    <div>

                                        <small class="text-muted d-block mb-1">
                                            CHECKLIST
                                        </small>

                                        <h6 class="fw-bold mb-0 text-dark">
                                            ITEMIZED STRUCTURE CHECKLIST &amp; QUANTITIES
                                        </h6>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm">

                                    <i class="mdi mdi-file-export-outline me-1"></i>

                                    EXPORT SIGNED BOQ

                                </button>

                            </div>

                        </div>

                    </div>


                    <div class="table-responsive border rounded-3 boq-table-v2-wrapper">

                        <table class="table align-middle mb-0 boq-table-v2">

                            <thead>

                                <tr>

                                    <th>SR<br>NO</th>
                                    <th>STRUCTURE / ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th>UNIT</th>

                                    <th class="text-end">
                                        TENTATIVE QTY
                                    </th>

                                    <th class="text-end">
                                        RATE (₹)
                                    </th>

                                    <th class="text-end">
                                        AMOUNT (₹)
                                    </th>

                                    <th>REMARKS</th>

                                </tr>

                            </thead>


                            <tbody>

                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        1
                                    </td>

                                    <td class="fw-bold">
                                        PILING & DEEP FOUNDATIONS
                                    </td>

                                    <td class="boq-spec">
                                        Bored cast-in-situ piling using bentonite slurry
                                    </td>

                                    <td>
                                        CuM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">1,200</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 25,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 3,00,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Complete</span>
                                    </td>

                                </tr>


                                <tr>

                                    <td class="text-muted">&ndash;</td>

                                    <td class="fw-semibold">
                                        Piling Excavation (25m depth)
                                    </td>

                                    <td class="boq-spec">
                                        Bored cast-in-situ piling using bentonite slurry
                                    </td>

                                    <td>
                                        MT
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">180</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 65,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-semibold">
                                        ₹ 1,17,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Completed testing</span>
                                    </td>

                                </tr>


                                <tr>

                                    <td class="text-muted">&ndash;</td>

                                    <td class="fw-semibold">
                                        Reinforcing Steel Cage Fabrication
                                    </td>

                                    <td class="boq-spec">
                                        Fe 550D TMT reinforcement steel bars
                                    </td>

                                    <td>
                                        MT
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">1,200</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 7,500</span>
                                    </td>

                                    <td class="text-end font-monospace fw-semibold">
                                        ₹ 90,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">7-day cube passed</span>
                                    </td>

                                </tr>


                                <tr>

                                    <td class="text-muted">&ndash;</td>

                                    <td class="fw-semibold">
                                        Piling Concrete Pouring
                                    </td>

                                    <td class="boq-spec">
                                        M35 Grade high-slump tremie concrete
                                    </td>

                                    <td>
                                        CuM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">1,200</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 15,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-semibold">
                                        ₹ 1,80,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Passed</span>
                                    </td>

                                </tr>


                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        2
                                    </td>

                                    <td class="fw-bold">
                                        Sonic Integrity Testing
                                    </td>

                                    <td class="boq-spec">
                                        Cross-hole sonic logging tests on piles
                                    </td>

                                    <td>
                                        Nos.
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">12</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 5,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 60,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Curing completed</span>
                                    </td>

                                </tr>


                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        3
                                    </td>

                                    <td class="fw-bold">
                                        SUBSTRUCTURE & PIERS
                                    </td>

                                    <td class="boq-spec">
                                        Structural concrete and reinforcement works
                                    </td>

                                    <td>
                                        CuM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">850</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 8,200</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 69,70,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Alignment verified</span>
                                    </td>

                                </tr>


                                <tr>

                                    <td class="text-muted">&ndash;</td>

                                    <td class="fw-semibold">
                                        Pile Cap Concrete
                                    </td>

                                    <td class="boq-spec">
                                        M40 Grade structural concrete
                                    </td>

                                    <td>
                                        MT
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">95</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 68,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-semibold">
                                        ₹ 64,60,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Formwork stripped</span>
                                    </td>

                                </tr>

                            </tbody>

                            <tfoot>

                                <tr class="boq-total-row">

                                    <td colspan="6" class="fw-bold">
                                        GRAND TOTAL WORK ORDER BOQ VALUE
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 8,21,90,000
                                    </td>

                                    <td></td>

                                </tr>

                            </tfoot>

                        </table>

                    </div>


                    <div class="row mt-4 g-3">

                        <div class="col-lg-8">

                            <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                <i class="mdi mdi-sync fs-5"></i>

                                <div>

                                    <strong>
                                        Live Sync Enabled
                                    </strong>

                                    <div class="small mt-1">
                                        Any edits you perform inside "Tentative Qty", "Rate", or "Remarks" are saved persistently in real-time and mirror automatically across Project Managers modules.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-lg-4">

                            <div class="staff-boq-box">

                                <span class="small text-muted d-block">
                                    STAFF BOQ VALUE
                                </span>

                                <span class="fs-5 fw-bold text-primary">
                                    ₹8,460,000
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div
        class="card mb-3 work-order-card shadow-sm"
        data-project="MAA-MET-C4"
        data-status="Active">

        <div class="card-body p-4">

            <div class="row align-items-center">

                <div class="col-lg-9">

                    <div class="work-order-header-line">

                        <span class="badge rounded-pill project-title-text text-white bg-primary">

                            <i class="mdi mdi-file-document-outline me-1"></i>

                            MAA-MET-C4 — Chennai Metro Phase 2 - Corridor 4

                        </span>

                        <span class="header-separator"></span>

                        <span class="badge wo-number-badge">

                            <i class="mdi mdi-file-document-outline"></i>

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">

                                MO/CRL/2026/041

                            </span>

                        </span>

                        <span class="header-separator"></span>

                        <span class="issued-date">

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary">

                                <i class="mdi mdi-calendar-outline"></i>

                                Issued:

                                10 Feb 2026

                            </span>

                        </span>

                        <span class="badge bg-label-success">
                            Active
                        </span>

                    </div>


                    <p class="mb-1 fw-semibold text-dark mt-2">
                        Station Elevated Box Girders Launching Amendment
                    </p>


                    <div class="small text-muted">

                        <i class="mdi mdi-account-outline me-1"></i>

                        Signatory:

                        <span class="text-dark fw-semibold">
                            Er Rajesh Gopal (CMRL)
                        </span>

                    </div>

                </div>


                <div class="col-lg-3 mt-3 mt-lg-0">

                    <div class="d-flex justify-content-end align-items-center gap-3">

                        <div class="boq-value-box text-end">

                            <span class="small text-muted d-block">
                                TOTAL BOQ VALUE
                            </span>

                            <span class="fs-4 fw-bold text-success">
                                ₹8.46 Cr
                            </span>

                        </div>



                        <span
                            class="work-order-action-icon delete-btn"
                            title="Delete"
                            onclick="return confirm('Are you sure you want to delete this work order?')">

                            <i class="mdi mdi-delete-outline"></i>

                        </span>

                        <span
                            class="work-order-action-icon expand-btn"
                            data-bs-toggle="collapse"
                            data-bs-target="#collapseWO1"
                            aria-expanded="false"
                            title="Expand">

                            <i class="mdi mdi-chevron-down"></i>

                        </span>

                    </div>

                </div>

            </div>


            <div
                class="collapse mt-4"
                id="collapseWO1">

                <div class="border-top pt-4">

                    <div class="row g-3 mb-4">

                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-file-tree-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            TECHNICAL SCOPE
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        Elevated box girder launching, structural alignment and deck preparation.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-chart-donut"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            EXECUTION ANALYTICS
                                        </small>

                                    </div>

                                    <div class="mb-2">

                                        <span class="badge bg-label-success">
                                            78% Validated
                                        </span>

                                    </div>

                                    <small class="text-muted">
                                        8 Structures Linked
                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-clipboard-check-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            CHECKLIST VERIFICATION
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        BOQ Linked to Elevated Structures
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="card border-0 shadow-sm rounded-3 mb-4">

                        <div class="card-body p-4">

                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                <div class="d-flex align-items-center gap-3">

                                    <div class="table-section-icon">
                                        <i class="mdi mdi-format-list-bulleted"></i>
                                    </div>

                                    <div>

                                        <small class="text-muted d-block mb-1">
                                            CHECKLIST
                                        </small>

                                        <h6 class="fw-bold mb-0 text-dark">
                                            ITEMIZED STRUCTURE CHECKLIST &amp; QUANTITIES
                                        </h6>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm">

                                    <i class="mdi mdi-file-export-outline me-1"></i>

                                    EXPORT SIGNED BOQ

                                </button>

                            </div>

                        </div>

                    </div>


                    <div class="table-responsive border rounded-3 boq-table-v2-wrapper">

                        <table class="table align-middle mb-0 boq-table-v2">

                            <thead>

                                <tr>

                                    <th>SR<br>NO</th>
                                    <th>STRUCTURE / ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th>UNIT</th>

                                    <th class="text-end">
                                        TENTATIVE QTY
                                    </th>

                                    <th class="text-end">
                                        RATE (₹)
                                    </th>

                                    <th class="text-end">
                                        AMOUNT (₹)
                                    </th>

                                    <th>REMARKS</th>

                                </tr>

                            </thead>

                            <tbody>

                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        1
                                    </td>

                                    <td class="fw-bold">
                                        ELEVATED GIRDER LAUNCHING
                                    </td>

                                    <td class="boq-spec">
                                        Precast prestressed concrete box girders
                                    </td>

                                    <td>
                                        Nos.
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">48</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 12,50,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 6,00,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Launching in progress</span>
                                    </td>

                                </tr>


                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        2
                                    </td>

                                    <td class="fw-bold">
                                        DECK SLAB WORK
                                    </td>

                                    <td class="boq-spec">
                                        M40 grade reinforced concrete
                                    </td>

                                    <td>
                                        CuM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">420</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 18,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 75,60,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Scheduled</span>
                                    </td>

                                </tr>

                            </tbody>

                            <tfoot>

                                <tr class="boq-total-row">

                                    <td colspan="6" class="fw-bold">
                                        GRAND TOTAL WORK ORDER BOQ VALUE
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 6,75,60,000
                                    </td>

                                    <td></td>

                                </tr>

                            </tfoot>

                        </table>

                    </div>


                    <div class="row mt-4 g-3">

                        <div class="col-lg-8">

                            <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                <i class="mdi mdi-sync fs-5"></i>

                                <div>

                                    <strong>
                                        Live Sync Enabled
                                    </strong>

                                    <div class="small mt-1">
                                        Any edits performed inside Tentative Qty, Rate, or Remarks are saved persistently and mirrored automatically across Project Manager modules.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-lg-4">

                            <div class="staff-boq-box">

                                <span class="small text-muted d-block">
                                    STAFF BOQ VALUE
                                </span>

                                <span class="fs-5 fw-bold text-primary">
                                    ₹5,200,000
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div
        class="card mb-3 work-order-card shadow-sm"
        data-project="ADY-RES"
        data-status="Active">

        <div class="card-body p-4">

            <div class="row align-items-center">

                <div class="col-lg-9">

                    <div class="work-order-header-line">

                        <span class="badge rounded-pill project-title-text text-white bg-primary">

                            <i class="mdi mdi-file-document-outline me-1"></i>

                            ADY-RES — Adyar Prevalent Residences

                        </span>

                        <span class="header-separator"></span>

                        <span class="badge wo-number-badge">

                            <i class="mdi mdi-file-document-outline"></i>

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">

                                MO/EI/Y/2025/112

                            </span>

                        </span>

                        <span class="header-separator"></span>

                        <span class="issued-date">

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary">

                                <i class="mdi mdi-calendar-outline"></i>

                                Issued:

                                05 Nov 2025

                            </span>

                        </span>

                        <span class="badge bg-label-success">
                            Active
                        </span>

                    </div>


                    <p class="mb-1 fw-semibold text-dark mt-2">
                        Adyar Block B Post-Tensioned Structure
                    </p>


                    <div class="small text-muted">

                        <i class="mdi mdi-account-outline me-1"></i>

                        Signatory:

                        <span class="text-dark fw-semibold">
                            Ananya Roy (Eylsum Ready)
                        </span>

                    </div>

                </div>


                <div class="col-lg-3 mt-3 mt-lg-0">

                    <div class="d-flex justify-content-end align-items-center gap-3">

                        <div class="boq-value-box text-end">

                            <span class="small text-muted d-block">
                                TOTAL BOQ VALUE
                            </span>

                            <span class="fs-4 fw-bold text-success">
                                ₹2.25 Cr
                            </span>

                        </div>

                        <span
                            class="work-order-action-icon delete-btn"
                            title="Delete"
                            onclick="return confirm('Are you sure you want to delete this work order?')">

                            <i class="mdi mdi-delete-outline"></i>

                        </span>

                        <span
                            class="work-order-action-icon expand-btn"
                            data-bs-toggle="collapse"
                            data-bs-target="#collapseWO2"
                            aria-expanded="false"
                            title="Expand">

                            <i class="mdi mdi-chevron-down"></i>

                        </span>

                    </div>

                </div>

            </div>


            <div
                class="collapse mt-4"
                id="collapseWO2">

                <div class="border-top pt-4">

                    <div class="row g-3 mb-4">

                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-file-tree-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            TECHNICAL SCOPE
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        Post-tensioned structural works for Block B including slab and beam systems.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-chart-donut"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            EXECUTION ANALYTICS
                                        </small>

                                    </div>

                                    <div class="mb-2">

                                        <span class="badge bg-label-success">
                                            62% Validated
                                        </span>

                                    </div>

                                    <small class="text-muted">
                                        Block B Linked
                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-clipboard-check-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            CHECKLIST VERIFICATION
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        Structural BOQ Verification Checklist
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="card border-0 shadow-sm rounded-3 mb-4">

                        <div class="card-body p-4">

                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                <div class="d-flex align-items-center gap-3">

                                    <div class="table-section-icon">

                                        <i class="mdi mdi-format-list-bulleted"></i>

                                    </div>

                                    <div>

                                        <small class="text-muted d-block mb-1">
                                            CHECKLIST
                                        </small>

                                        <h6 class="fw-bold mb-0 text-dark">
                                            ITEMIZED STRUCTURE CHECKLIST &amp; QUANTITIES
                                        </h6>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm">

                                    <i class="mdi mdi-file-export-outline me-1"></i>

                                    EXPORT SIGNED BOQ

                                </button>

                            </div>

                        </div>

                    </div>


                    <div class="table-responsive border rounded-3 boq-table-v2-wrapper">

                        <table class="table align-middle mb-0 boq-table-v2">

                            <thead>

                                <tr>

                                    <th>SR<br>NO</th>
                                    <th>STRUCTURE / ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th>UNIT</th>

                                    <th class="text-end">
                                        TENTATIVE QTY
                                    </th>

                                    <th class="text-end">
                                        RATE (₹)
                                    </th>

                                    <th class="text-end">
                                        AMOUNT (₹)
                                    </th>

                                    <th>REMARKS</th>

                                </tr>

                            </thead>


                            <tbody>

                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        1
                                    </td>

                                    <td class="fw-bold">
                                        POST-TENSIONED SLAB
                                    </td>

                                    <td class="boq-spec">
                                        PT slab system with high tensile strands
                                    </td>

                                    <td>
                                        SqM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">1,800</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 7,200</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 1,29,60,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Execution ongoing</span>
                                    </td>

                                </tr>


                                <tr class="boq-section-row">

                                    <td class="fw-bold">
                                        2
                                    </td>

                                    <td class="fw-bold">
                                        STRUCTURAL CONCRETE
                                    </td>

                                    <td class="boq-spec">
                                        M40 Grade structural concrete
                                    </td>

                                    <td>
                                        CuM
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">360</span>
                                    </td>

                                    <td class="text-end">
                                        <span class="boq-input-box">₹ 15,000</span>
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 54,00,000
                                    </td>

                                    <td>
                                        <span class="boq-remark-box">Approved</span>
                                    </td>

                                </tr>

                            </tbody>

                            <tfoot>

                                <tr class="boq-total-row">

                                    <td colspan="6" class="fw-bold">
                                        GRAND TOTAL WORK ORDER BOQ VALUE
                                    </td>

                                    <td class="text-end font-monospace fw-bold">
                                        ₹ 1,83,60,000
                                    </td>

                                    <td></td>

                                </tr>

                            </tfoot>

                        </table>

                    </div>


                    <div class="row mt-4 g-3">

                        <div class="col-lg-8">

                            <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                <i class="mdi mdi-sync fs-5"></i>

                                <div>

                                    <strong>
                                        Live Sync Enabled
                                    </strong>

                                    <div class="small mt-1">
                                        Any edits performed inside Tentative Qty, Rate, or Remarks are saved persistently and mirrored automatically across Project Manager modules.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-lg-4">

                            <div class="staff-boq-box">

                                <span class="small text-muted d-block">
                                    STAFF BOQ VALUE
                                </span>

                                <span class="fs-5 fw-bold text-primary">
                                    ₹3,200,000
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div
        class="card mb-3 work-order-card shadow-sm"
        data-project="ECK-BRG"
        data-status="Active">

        <div class="card-body p-4">

            <div class="row align-items-center">

                <div class="col-lg-9">

                    <div class="work-order-header-line">

                        <span class="badge rounded-pill project-title-text text-white bg-primary">

                            <i class="mdi mdi-file-document-outline me-1"></i>

                            ECK-BRG — East Coast Road Elevated Bridge

                        </span>

                        <span class="header-separator"></span>

                        <span class="badge wo-number-badge">

                            <i class="mdi mdi-file-document-outline"></i>

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">

                                MO/SR/2026/085

                            </span>

                        </span>

                        <span class="header-separator"></span>

                        <span class="issued-date">

                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary">

                                <i class="mdi mdi-calendar-outline"></i>

                                Issued:

                                15 Jan 2026

                            </span>

                        </span>

                        <span class="badge bg-label-success">
                            Active
                        </span>

                    </div>


                    <p class="mb-1 fw-semibold text-dark mt-2">
                        Advance Projects
                    </p>


                    <div class="small text-muted">

                        <i class="mdi mdi-account-outline me-1"></i>

                        Signatory:

                        <span class="text-dark fw-semibold">
                            Project Director
                        </span>

                    </div>

                </div>


                <div class="col-lg-3 mt-3 mt-lg-0">

                    <div class="d-flex justify-content-end align-items-center gap-3">

                        <div class="boq-value-box text-end">

                            <span class="small text-muted d-block">
                                TOTAL BOQ VALUE
                            </span>

                            <span class="fs-4 fw-bold text-success">
                                ₹0
                            </span>

                        </div>

                        <span
                            class="work-order-action-icon delete-btn"
                            title="Delete"
                            onclick="return confirm('Are you sure you want to delete this work order?')">

                            <i class="mdi mdi-delete-outline"></i>

                        </span>

                        <span
                            class="work-order-action-icon expand-btn"
                            data-bs-toggle="collapse"
                            data-bs-target="#collapseWO3"
                            aria-expanded="false"
                            title="Expand">

                            <i class="mdi mdi-chevron-down"></i>

                        </span>


                    </div>

                </div>

            </div>


            <div
                class="collapse mt-4"
                id="collapseWO3">

                <div class="border-top pt-4">

                    <div class="row g-3 mb-4">

                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-file-tree-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            TECHNICAL SCOPE
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        Elevated bridge preliminary and structural development works.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-chart-donut"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            EXECUTION ANALYTICS
                                        </small>

                                    </div>

                                    <div class="mb-2">

                                        <span class="badge bg-label-warning">
                                            Pending Validation
                                        </span>

                                    </div>

                                    <small class="text-muted">
                                        Structures Pending
                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="col-12 col-md-4">

                            <div class="card h-100 border-0 shadow-sm rounded-3">

                                <div class="card-body p-4">

                                    <div class="d-flex align-items-center mb-3">

                                        <div class="detail-icon me-3">
                                            <i class="mdi mdi-clipboard-check-outline"></i>
                                        </div>

                                        <small class="text-muted fw-semibold">
                                            CHECKLIST VERIFICATION
                                        </small>

                                    </div>

                                    <div class="fw-semibold text-dark">
                                        BOQ Verification Pending
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="card border-0 shadow-sm rounded-3 mb-4">

                        <div class="card-body p-4">

                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                <div class="d-flex align-items-center gap-3">

                                    <div class="table-section-icon">
                                        <i class="mdi mdi-format-list-bulleted"></i>
                                    </div>

                                    <div>

                                        <small class="text-muted d-block mb-1">
                                            CHECKLIST
                                        </small>

                                        <h6 class="fw-bold mb-0 text-dark">
                                            ITEMIZED STRUCTURE CHECKLIST &amp; QUANTITIES
                                        </h6>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm">

                                    <i class="mdi mdi-file-export-outline me-1"></i>

                                    EXPORT SIGNED BOQ

                                </button>

                            </div>

                        </div>

                    </div>


                    <div class="alert alert-secondary mb-0">

                        No detailed BOQ available for this work order.

                    </div>


                    <div class="row mt-4 g-3">

                        <div class="col-lg-8">

                            <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                <i class="mdi mdi-sync fs-5"></i>

                                <div>

                                    <strong>
                                        Live Sync Enabled
                                    </strong>

                                    <div class="small mt-1">
                                        Any edits performed inside Tentative Qty, Rate, or Remarks are saved persistently and mirrored automatically across Project Manager modules.
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="col-lg-4">

                            <div class="staff-boq-box">

                                <span class="small text-muted d-block">
                                    STAFF BOQ VALUE
                                </span>

                                <span class="fs-5 fw-bold text-primary">
                                    ₹0
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<div
    class="modal fade"
    id="issueWorkOrderModal"
    tabindex="-1"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header bg-primary text-white">

                <div class="d-flex align-items-center gap-2">

                    <h5 class="modal-title text-white mb-0">
                        Issue New Client Work Order
                    </h5>

                </div>

                <button
                    type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>

            </div>


            <div class="modal-body">

                <form>

                    <div class="row g-3">


                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Work Order Number
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                placeholder="MO/CRL/2026/001">

                        </div>

     <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Date of Agreement
                            </label>

                            <input
                                type="date"
                                class="form-control">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Agreement / Work Order Title
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                placeholder="eg:Corridor 4 Piling & Substructure Contract">

                        </div>


                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Authorized Client Signatory / Designee
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                placeholder="eg:Er Rajesh Gopal (CMRL)">

                        </div>




                        <div class="col-md-12">

                            <label class="form-label fw-semibold">
                                Technical Scope Statement
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                placeholder="Provide detailed description of operations, execution standards, etc..">

                        </div>

                    </div>

                </form>

            </div>


            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal">

                    Cancel

                </button>


                <button
                    type="button"
                    class="btn btn-primary">

                    <i class="mdi mdi-check me-1"></i>

                    Issue & Sync Contract

                </button>

            </div>

        </div>

    </div>

</div>





<style>


.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    align-items: center;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 4px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tabs-track .settings-tab-pill,
a.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tabs-track .settings-tab-pill:hover,
a.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tabs-track .settings-tab-pill.active,
a.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


:root {
    --bs-primary: #16659E !important;
    --bs-primary-rgb: 22, 101, 158 !important;
}

.btn-primary {
    --bs-btn-color: #fff !important;
    --bs-btn-bg: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #124f7c !important;
    --bs-btn-hover-border-color: #124f7c !important;
    --bs-btn-active-color: #fff !important;
    --bs-btn-active-bg: #0f4265 !important;
    --bs-btn-active-border-color: #0f4265 !important;
    background-color: #16659E !important;
    border-color: #16659E !important;
    color: #fff !important;
}

.bg-primary {
    background-color: #16659E !important;
}

.text-primary {
    color: #16659E !important;
}

.btn-outline-primary {
    --bs-btn-color: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #16659E !important;
    --bs-btn-hover-border-color: #16659E !important;
    color: #16659E !important;
    border-color: #16659E !important;
}

.bg-primary-subtle {
    background-color: #e8eef5 !important;
}


.wo-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 12px;
    background: rgba(30, 58, 95, 0.10);
    color: #1e3a5f;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    flex-shrink: 0;
}


.work-order-card {
    border: 1px solid #e7e7e9;
    border-radius: 12px;
    transition: all 0.2s ease;
}

.work-order-card:hover {
    box-shadow: 0 5px 18px rgba(0, 0, 0, 0.07) !important;
    transform: translateY(-1px);
}


.work-order-header-line {
    display: flex !important;
    align-items: center !important;
    flex-wrap: nowrap !important;
    gap: 9px !important;
    width: 100% !important;
    max-width: 100% !important;
    white-space: nowrap !important;
    overflow-x: auto !important;
    overflow-y: hidden !important;
    padding: 0 0 2px 0 !important;
}

.project-title-badge {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: flex-start !important;
    gap: 6px !important;
    background: #1e3a5f !important;
    color: #ffffff !important;
    border: 0 !important;
    border-radius: 7px !important;
    padding: 6px 10px !important;
    margin: 0 !important;
    font-size: 12px !important;
    font-weight: 700 !important;
    line-height: 1.3 !important;
    white-space: nowrap !important;
    width: auto !important;
    max-width: none !important;
    min-width: max-content !important;
    flex: 0 0 auto !important;
    overflow: visible !important;
}

.project-title-badge i {
    display: inline-block !important;
    color: #ffffff !important;
    font-size: 15px !important;
    line-height: 1 !important;
    flex: 0 0 auto !important;
}

.project-title-text i {
    font-size: 14px;
    vertical-align: middle;
}

.header-separator {
    display: inline-block !important;
    color: #b7b7bd !important;
    font-weight: 500 !important;
    flex: 0 0 auto !important;
}

.wo-number-badge {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    background: #f1f1f5 !important;
    color: #444444 !important;
    border: 1px solid #e2e2e6 !important;
    border-radius: 7px !important;
    padding: 6px 10px !important;
    margin: 0 !important;
    font-size: 12px !important;
    font-weight: 700 !important;
    line-height: 1.3 !important;
    white-space: nowrap !important;
    width: auto !important;
    max-width: none !important;
    min-width: max-content !important;
    flex: 0 0 auto !important;
}

.issued-date {
    display: inline-flex !important;
    align-items: center !important;
    gap: 4px !important;
    font-size: 13px !important;
    color: #6f7075 !important;
    white-space: nowrap !important;
    flex: 0 0 auto !important;
}

.issued-date i {
    font-size: 16px !important;
    color: #1e3a5f !important;
}

.boq-value-box {
    min-width: 150px;
    padding-right: 12px;
}


.work-order-action-icon {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: auto !important;
    height: auto !important;
    padding: 0 !important;
    margin: 0 !important;
    border: 0 !important;
    border-radius: 0 !important;
    background: transparent !important;
    box-shadow: none !important;
    cursor: pointer;
    line-height: 1;
}

.work-order-action-icon i {
    font-size: 22px !important;
}

.expand-btn {
    color: #1e3a5f !important;
}

.expand-btn:hover,
.expand-btn:focus,
.expand-btn:active {
    color: #1e3a5f !important;
    background: transparent !important;
    box-shadow: none !important;
}

.delete-btn {
    color: #dc3545 !important;
}

.delete-btn:hover,
.delete-btn:focus,
.delete-btn:active {
    color: #dc3545 !important;
    background: transparent !important;
    box-shadow: none !important;
}

.expand-btn i {
    transition: transform 0.2s ease;
}

.expand-btn[aria-expanded="true"] i {
    transform: rotate(180deg);
}


.detail-box {
    height: 100%;
    min-height: 120px;
    border: 1px solid #e7e7e9;
    border-radius: 10px;
    padding: 15px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    background: #fff;
}

.detail-icon {
    width: 36px;
    height: 36px;
    min-width: 36px;
    border-radius: 8px;
    background: #f5f5f9;
    color: #1e3a5f;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}

.detail-content {
    flex: 1;
    min-width: 0;
}

.detail-content small {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.04em;
}

.detail-content .fw-semibold {
    font-size: 13px;
    line-height: 1.5;
}


.table-section-icon {
    width: 34px;
    height: 34px;
    border-radius: 7px;
    background: #e8eef5;
    color: #1e3a5f;
    display: flex;
    align-items: center;
    justify-content: center;
}


.staff-boq-box {
    height: 100%;
    border: 1px solid #e7e7e9;
    border-radius: 10px;
    padding: 15px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-end;
    text-align: right;
}


.work-order-card .table {
    font-size: 12px;
}

.work-order-card .table th {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    white-space: nowrap;
}

.work-order-card .table td {
    vertical-align: middle;
}

.badge {
    font-size: 10px;
}


/* ---------- BOQ Table v2 (image-matched style) ---------- */

.boq-table-v2-wrapper {
    background: #fff;
}

.boq-table-v2 {
    font-size: 12.5px;
    margin-bottom: 0;
}

.boq-table-v2 thead th {
    background: #f8f9fb;
    color: #6c757d;
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    white-space: nowrap;
    border-bottom: 1px solid #e7e7e9;
    padding: 10px 12px;
}

.boq-table-v2 tbody td {
    padding: 10px 12px;
    vertical-align: middle;
    border-bottom: 1px solid #eef0f2;
}

.boq-table-v2 .boq-spec {
    font-style: italic;
    color: #7a7d85;
    font-size: 12px;
}

.boq-table-v2 .boq-section-row td {
    background: #f4f6f8;
}

.boq-table-v2 .boq-input-box {
    display: inline-block;
    min-width: 84px;
    text-align: right;
    background: #fffdf3;
    border: 1px solid #ece1b8;
    border-radius: 5px;
    padding: 4px 10px;
    font-family: var(--bs-font-monospace, monospace);
    font-size: 12px;
    color: #333;
}

.boq-table-v2 .boq-remark-box {
    display: inline-block;
    background: #fff;
    border: 1px solid #dcdde0;
    border-radius: 5px;
    padding: 4px 10px;
    font-size: 12px;
    color: #333;
    white-space: nowrap;
}

.boq-table-v2 tfoot .boq-total-row td {
    background: #eef1f4;
    border-top: 2px solid #d7dade;
    padding: 12px;
    font-size: 13px;
}

.boq-table-v2 tfoot .boq-total-row td:first-child {
    text-transform: uppercase;
    letter-spacing: 0.02em;
    color: #1e3a5f;
}


.work-order-filters {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    flex-wrap: wrap;
}


@media (max-width: 1200px) {

    .wo-header-icon {
        width: 46px;
        height: 46px;
        font-size: 24px;
    }

    .card-body .btn {
        white-space: nowrap;
    }

}


@media (max-width: 992px) {

    .boq-value-box {
        min-width: auto;
    }

    .staff-boq-box {
        align-items: flex-start;
        text-align: left;
    }

    .wo-header-icon {
        width: 44px;
        height: 44px;
        font-size: 22px;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        max-width: 100%;
    }

}


@media (max-width: 768px) {

    .settings-tabs-wrapper {
        width: 100%;
    }

    .settings-tabs-wrapper > .d-flex {
        width: 100%;
    }

    .settings-tabs-scroller {
        flex: 1 1 auto;
        min-width: 0;
    }

    .settings-tabs-track {
        width: 100%;
    }

    .work-order-filters {
        width: 100%;
    }

    .work-order-filters .btn {
        flex: 1 1 auto;
    }

}


@media (max-width: 576px) {

    .container-fluid {
        padding-left: 12px;
        padding-right: 12px;
    }

    .card-body {
        padding: 15px !important;
    }

    .work-order-filters .btn {
        width: 100%;
    }

    .work-order-filters select {
        width: 100% !important;
    }

    .issued-date {
        font-size: 12px;
    }

    .project-title-badge {
        font-size: 11px !important;
    }

    .wo-number-badge {
        font-size: 11px !important;
    }

    .settings-tab-pill {
        padding: .45rem .85rem;
        font-size: .82rem;
    }

}

</style>




<script>

document.addEventListener('DOMContentLoaded', function () {

    const projectFilter =
        document.getElementById('projectFilter');

    const statusFilter =
        document.getElementById('statusFilter');

    const workOrders =
        document.querySelectorAll('.work-order-card');


    function filterWorkOrders() {

        const selectedProject =
            projectFilter.value;

        const selectedStatus =
            statusFilter.value;


        workOrders.forEach(function (card) {

            const project =
                card.getAttribute('data-project');

            const status =
                card.getAttribute('data-status');


            const projectMatch =
                selectedProject === 'all' ||
                project === selectedProject;


            const statusMatch =
                selectedStatus === 'all' ||
                status === selectedStatus;


            card.style.display =
                (projectMatch && statusMatch)
                    ? ''
                    : 'none';

        });

    }


    projectFilter.addEventListener(
        'change',
        filterWorkOrders
    );


    statusFilter.addEventListener(
        'change',
        filterWorkOrders
    );


    const qsTabsTrack =
        document.getElementById('qsTabsTrack');

    const qsTabScrollLeft =
        document.getElementById('qsTabScrollLeft');

    const qsTabScrollRight =
        document.getElementById('qsTabScrollRight');


    if (qsTabsTrack) {

        if (qsTabScrollLeft) {

            qsTabScrollLeft.addEventListener(
                'click',
                function () {

                    qsTabsTrack.scrollBy({
                        left: -220,
                        behavior: 'smooth'
                    });

                }
            );

        }


        if (qsTabScrollRight) {

            qsTabScrollRight.addEventListener(
                'click',
                function () {

                    qsTabsTrack.scrollBy({
                        left: 220,
                        behavior: 'smooth'
                    });

                }
            );

        }

    }
    document
        .querySelectorAll('.expand-btn')
        .forEach(function (icon) {

            const targetId =
                icon.getAttribute('data-bs-target');


            const target =
                document.querySelector(targetId);


            if (target) {

                target.addEventListener(
                    'shown.bs.collapse',
                    function () {

                        icon.setAttribute(
                            'aria-expanded',
                            'true'
                        );

                    }
                );


                target.addEventListener(
                    'hidden.bs.collapse',
                    function () {

                        icon.setAttribute(
                            'aria-expanded',
                            'false'
                        );

                    }
                );

            }

        });

});

</script>

@endsection