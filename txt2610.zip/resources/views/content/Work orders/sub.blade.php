@extends('layouts/contentNavbarLayout')

@section('title', 'Sub-Contractor Work Orders')

@section('content')

    <div class="container-fluid">

      <div class="card mb-4 shadow-sm rounded-2">
    <div class="card-body p-3 p-md-4">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

            <!-- Title Section -->
            <div>
                <h4 class="fw-bold mb-1">
                    Planning & Quantity Surveying (QS) Engine
                </h4>

                <p class="text-muted mb-0">
                    Master Schedules, Work Orders, RA Billing & Material Verification
                </p>
            </div>

            <!-- Work Order Buttons -->

                <div class="d-flex align-items-center gap-2 flex-wrap">
                <div class="settings-tabs-wrapper">


<div class="d-flex align-items-center gap-2">
<button
                                type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                                <i class="mdi mdi-chevron-left"></i>

                            </button>

                            <div class="settings-tabs-scroller">

                                <div
                                    class="settings-tabs-track"
                                    id="qsTabsTrack">

                                    <a
                                        href="{{ route('planning-qs.work-orders') }}"
                                        class="settings-tab-pill {{ request()->routeIs('planning-qs.work-orders') ? 'active' : '' }}">

                                        Client Work Order

                                    </a>

                                    <a
                                        href="{{ route('planning-qs.work-orders.sub') }}"
                                        class="settings-tab-pill {{ request()->routeIs('planning-qs.work-orders.sub') ? 'active' : '' }}">

                                        Sub Contractor Work Orders

                                    </a>

                                </div>

                            </div>

                            <button
                                type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                                <i class="mdi mdi-chevron-right"></i>

                            </button>

                        </div>



            </div>

        </div>

    </div>
</div>

   <div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-2 p-md-3">

        <div class="row g-2 align-items-end sub-filter-row">

            <!-- Project Name -->
            <div class="col-12 col-md">
                <label class="form-label fw-semibold small text-uppercase text-muted mb-1">
                    Project Name
                </label>

                <select id="subProjectFilter"
                        class="form-select form-select-sm">
                    <option value="all" selected>
                        All Projects (Unified View)
                    </option>
                    <option value="MAA-MET-C4">
                        Chennai Metro Phase 2 - Corridor 4
                    </option>
                    <option value="ADY-RES">
                        Adyar Prevalent Residences
                    </option>
                    <option value="ECR-BRG">
                        East Coast Road Elevated Bridge
                    </option>
                </select>
            </div>

            <!-- Client Work Order -->
            <div class="col-12 col-md">
                <label class="form-label fw-semibold small text-uppercase text-muted mb-1">
                    Select Sub Contractor Work Order
                </label>

                <select id="clientWOFilter"
                        class="form-select form-select-sm">
                    <option value="all" selected>
                        All Client Work Orders
                    </option>
                    <option value="WO/CMRL/2025/089">
                        WO/CMRL/2025/089 — Corridor 4 Piling & Substructure Contract
                    </option>
                    <option value="WO/CMRL/2026/041">
                        WO/CMRL/2026/041 — Elevated Box Girders Launching
                    </option>
                    <option value="WO/EI/Y/2025/112">
                        WO/EI/Y/2025/112 — Adyar Block B PT Structure
                    </option>
                </select>
            </div>

            <!-- Contractor WO No -->
            <div class="col-12 col-md">
                <label class="form-label fw-semibold small text-uppercase text-muted mb-1">
                    Choose Contractor WO No
                </label>

                <select id="contractorWOFilter"
                        class="form-select form-select-sm">
                    <option value="all" selected>
                        All Contractor Work Order Nos
                    </option>
                    <option value="SCWO/APEX/088">
                        SCWO/APEX/088
                    </option>
                    <option value="SCWO/APEX/091">
                        SCWO/APEX/091
                    </option>
                    <option value="SCWO/CRL/045">
                        SCWO/CRL/045
                    </option>
                </select>
            </div>

            <!-- Quick Search -->
            <div class="col-12 col-md">
                <label class="form-label fw-semibold small text-uppercase text-muted mb-1">
                    Quick Search
                </label>

                <div class="input-group input-group-sm sub-filter-search">
                    <input type="text"
                           class="form-control"
                           placeholder="Search..."
                           id="subSearchInput">

                    <button class="btn btn-primary"
                            type="button"
                            id="subSearchButton">
                        <i class="mdi mdi-magnify"></i>
                    </button>
                </div>
            </div>

            <!-- Issue Sub-Contractor WO -->
            <div class="col-12 col-md">
                <label class="form-label fw-semibold small text-uppercase text-muted mb-1 d-none d-md-block">
                    &nbsp;
                </label>

                <button type="button"
                        class="btn btn-primary btn-sm w-100 sub-filter-btn"
                        data-bs-toggle="modal"
                        data-bs-target="#issuesSubContractorModal">
                    <i class="mdi mdi-plus me-1"></i>
                    Issue Sub-Contractor WO
                </button>
            </div>

        </div>

    </div>
</div>


        <div class="card mb-3 work-order-card shadow-sm"
             data-project="MAA-MET-C4"
             data-client-wo="WO/CMRL/2025/089"
             data-contractor-wo="SCWO/APEX/088">

            <div class="card-body p-4">

                <div class="row align-items-center">

                    <div class="col-lg-9">

                        <div class="work-order-header-line">

                            <span class="badge rounded-pill project-title-text text-white bg-primary">
                                <i class="mdi mdi-file-document-outline me-1"></i>
                                MAA-MET-C4 — Chennai Metro Phase 2 - Corridor 4
                            </span>

                            <span class="header-separator"></span>

                            <span class="badge wo-number-badge">
                            <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">

                                    SCWO/APEX/088
                                </span>
                            </span>

                            <span class="header-separator"></span>

                           <span class="issued-date">
    <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary bg-primary-subtle"
          style="font-size: 11px; padding: 3px 7px;">
        <i class="mdi mdi-file-document-outline"></i>
        Ref Client No: WO/CMRL/2025/089
    </span>
</span>

                            </span>

                            <span class="badge bg-label-success">
                                Approved
                            </span>

                        </div>

                        <p class="mb-1 fw-semibold text-dark mt-2">
                            Pier Connecting & Substructure Formwork
                        </p>

                        <div class="small text-muted">
                            <i class="mdi mdi-account-hard-hat me-1"></i>
                            Sub-Contractor:
                            <span class="text-dark fw-bold">
                                Apex Structural Sub-Contractors
                            </span>
                        </div>

                    </div>

                    <div class="col-lg-3 mt-3 mt-lg-0">
                        <div class="boq-value-box d-flex align-items-center justify-content-end gap-3">

                            <div class="text-center">
                                <span class="small text-muted d-block text-nowrap">
                                    SUB-CONTRACTOR VALUE
                                </span>

                                <span class="fs-4 fw-bold text-success d-block text-nowrap">
                                    ₹6.11 Cr
                                </span>

                                <span class="small text-muted d-block text-nowrap">
                                    Client BOQ: ₹7.75 Cr
                                </span>
                            </div>



<span class="badge bg-light pdf-work-order-badge text-primary"
      onclick="openPrintPreview(this)"
      title="Generate PDF Work Order"
      style="border-radius: 50px; padding: 3px 8px; cursor: pointer; font-size: 10px;">

    <i class="mdi mdi-printer-outline me-1"></i>
    Generate PDF Work Order
</span>


                            <!-- Expand -->
</span>
 <span class="work-order-action-icon delete-btn"
                                  title="Delete"
                                  onclick="return confirm('Are you sure you want to delete this sub-contractor work order?')">
                                <i class="mdi mdi-delete-outline"></i>
                            </span>

</span>

                            <span class="work-order-action-icon expand-btn"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseSubWO0"
                                  aria-expanded="false"
                                  aria-controls="collapseSubWO0"
                                  title="Expand">
                                <i class="mdi mdi-chevron-down"></i>
                            </span>



                        </div>
                    </div>

                    <div class="collapse mt-4" id="collapseSubWO0">

                        <div class="border-top pt-4">

                            <!-- Project Summary Card -->
                            <div class="card sub-project-summary-card mb-4">
                                <div class="card-body">

                                    <div class="row g-4">

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    PROJECT NAME
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Chennai Metro Phase 2 - Corridor 4
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    CONTRACTOR WORK ORDER NO
                                                </span>

                                                <strong class="d-block mt-1">
                                                    SCWO/APEX/088
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    SUB-CONTRACTOR FIRM
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Apex Structural Sub-Contractors
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    FLOWING CLIENT WO BOQ
                                                </span>

                                                <strong class="d-block mt-1 sub-summary-value-accent">
                                                    WO/CMRL/2025/089 (Corridor 4 Piling &amp; Substructure Contract)
                                                </strong>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>

                            <div class="card mb-3">
                                <div class="card-body">

                                    <div class="sub-boq-section-header d-flex justify-content-between align-items-center">

                                        <div class="d-flex align-items-center gap-2">

                                            <div class="sub-boq-section-icon">
                                                <i class="mdi mdi-layers-outline"></i>
                                            </div>

                                            <h6 class="mb-0 fw-bold">
                                                ITEMIZED BOQ FLOWING FROM CLIENT WORK ORDER
                                            </h6>

                                        </div>

                                        <button type="button"
                                                class="btn btn-primary btn-sm sub-generate-pdf-btn"
                                                onclick="openPrintPreview(this)">

                                            <i class="mdi mdi-printer-outline me-1"></i>
                                            GENERATE PDF WORK ORDER

                                        </button>

                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="table-responsive sub-boq-table-wrapper">

                            <table class="table sub-boq-table align-middle mb-0">

                                <thead>

                                    <tr>

                                        <th class="text-center">SR. NO</th>
                                        <th>BOQ ITEM NAME (FROM CLIENT WO)</th>
                                        <th>SPECIFICATION DESCRIPTION</th>
                                        <th class="text-center">UNIT</th>
                                        <th class="text-end">CLIENT QTY</th>
                                        <th class="text-end">CLIENT RATE</th>
                                        <th class="text-end">SUB QTY</th>
                                        <th class="text-end">SUB RATE (₹)</th>
                                        <th class="text-end">SUB AMOUNT (₹)</th>
                                        <th>ALLOCATION REMARKS</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    <tr class="sub-boq-category-row">

                                        <td class="text-center fw-bold">1</td>

                                        <td class="fw-bold">
                                            PILING & DEEP FOUNDATIONS
                                        </td>

                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Piling Excavation (25m depth)
                                        </td>

                                        <td class="sub-specification">
                                            Bored cast-in-situ piling using bentonite slurry
                                        </td>

                                        <td class="text-center fw-semibold">
                                            CuM
                                        </td>

                                        <td class="text-end font-monospace">
                                            1,200
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹25,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="1,200">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="22,500">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹27,000,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Reinforcing Steel Cage Fabrication
                                        </td>

                                        <td class="sub-specification">
                                            Fe 550D TMT reinforcement steel bars
                                        </td>

                                        <td class="text-center fw-semibold">
                                            MT
                                        </td>

                                        <td class="text-end font-monospace">
                                            180
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹65,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="180">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="58,500">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹10,530,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Piling Concrete Pouring
                                        </td>

                                        <td class="sub-specification">
                                            M35 Grade high-slump tremie concrete
                                        </td>

                                        <td class="text-center fw-semibold">
                                            CuM
                                        </td>

                                        <td class="text-end font-monospace">
                                            1,200
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹15,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="600">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="14,250">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹8,550,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="50% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Sonic Integrity Testing
                                        </td>

                                        <td class="sub-specification">
                                            Cross-hole sonic logging tests on piles
                                        </td>

                                        <td class="text-center fw-semibold">
                                            Nos.
                                        </td>

                                        <td class="text-end font-monospace">
                                            12
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹5,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="6">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="4,800">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹28,800
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="50% allocated">
                                        </td>

                                    </tr>

                                    <tr class="sub-boq-category-row">

                                        <td class="text-center fw-bold">2</td>

                                        <td class="fw-bold">
                                            SUBSTRUCTURE & PIERS
                                        </td>

                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Pile Cap Concrete
                                        </td>

                                        <td class="sub-specification">
                                            M40 Grade structural concrete
                                        </td>

                                        <td class="text-center fw-semibold">
                                            MT
                                        </td>

                                        <td class="text-end font-monospace">
                                            95
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹68,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="95">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="64,000">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹6,080,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Pier Pedestal Fabrication
                                        </td>

                                        <td class="sub-specification">
                                            Reinforcing steel and template alignment
                                        </td>

                                        <td class="text-center fw-semibold">
                                            MT
                                        </td>

                                        <td class="text-end font-monospace">
                                            95
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹68,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="95">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="64,000">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹6,080,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Pier Column Casting
                                        </td>

                                        <td class="sub-specification">
                                            M45 Grade self-compacting concrete
                                        </td>

                                        <td class="text-center fw-semibold">
                                            CuM
                                        </td>

                                        <td class="text-end font-monospace">
                                            600
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹9,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="520">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="9,000">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹4,680,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="86.67% allocated">
                                        </td>

                                    </tr>

                                </tbody>

                                <tfoot>

                                    <tr>

                                        <td colspan="8"
                                            class="text-end fw-bold">
                                            GRAND TOTAL WORK ORDER VALUE
                                        </td>

                                        <td class="text-end fw-bold text-primary font-monospace">
                                            ₹61,100,000
                                        </td>

                                        <td></td>

                                    </tr>

                                </tfoot>

                            </table>

                        </div>

                        <div class="row mt-4 g-3">

                            <div class="col-12">

                                <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                    <i class="mdi mdi-sync fs-5"></i>

                                    <div>

                                        <strong>
                                            Live Sync Enabled
                                        </strong>

                                        <div class="small mt-1">
                                            Any edits performed inside Sub-Qty,
                                            Sub-Rate, or Allocation Remarks are saved
                                            persistently and mirrored automatically
                                            across Project Manager modules.
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4">

                            <button type="button"
                                    class="btn btn-outline-secondary btn-sm">

                                <i class="mdi mdi-pencil-outline me-1"></i>
                                Edit BOQ Allocation

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
        <!-- ============================================================ -->
        <!-- WORK ORDER CARD 2                                              -->
        <!-- ============================================================ -->
        <div class="card mb-3 work-order-card shadow-sm"
             data-project="MAA-MET-C4"
             data-client-wo="WO/CMRL/2026/041"
             data-contractor-wo="SCWO/APEX/091">

            <div class="card-body p-4">

                <div class="row align-items-center">

                    <div class="col-lg-9">

                        <div class="work-order-header-line">

                            <span class="badge rounded-pill project-title-text text-white bg-primary">
                                <i class="mdi mdi-file-document-outline me-1"></i>
                                MAA-MET-C4 — Chennai Metro Phase 2 - Corridor 4
                            </span>

                            <span class="header-separator"></span>

                            <span class="badge wo-number-badge">
                                  <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">
                                    SCWO/APEX/091
                                </span>
                            </span>

                            <span class="header-separator"></span>

                            <span class="issued-date">
    <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary bg-primary-subtle"
          style="font-size: 11px; padding: 3px 7px;">
        <i class="mdi mdi-file-document-outline"></i>
     Ref Client No: WO/CMRL/2026/041
    </span>


                            </span>

                            <span class="badge bg-label-warning">
                                In Progress
                            </span>

                        </div>

                        <p class="mb-1 fw-semibold text-dark mt-2">
                            Girder Erection & Deck Slab Casting
                        </p>

                        <div class="small text-muted">
                            <i class="mdi mdi-account-hard-hat me-1"></i>
                            Sub-Contractor:
                            <span class="text-dark fw-bold">
                                Apex Structural Sub-Contractors
                            </span>
                        </div>

                    </div>


                   <div class="col-lg-3 mt-3 mt-lg-0">
                        <div class="boq-value-box d-flex align-items-center justify-content-end gap-3">

                            <div class="text-center">
                                <span class="small text-muted d-block text-nowrap">
                                    SUB-CONTRACTOR VALUE
                                </span>

                                <span class="fs-4 fw-bold text-success d-block text-nowrap">
                                    ₹6.30 Cr
                                </span>

                                <span class="small text-muted d-block text-nowrap">
                                    Client BOQ: ₹7.75 Cr
                                </span>
                            </div>
<span class="badge bg-light pdf-work-order-badge text-primary"
      onclick="openPrintPreview(this)"
      title="Generate PDF Work Order"
      style="border-radius: 50px; padding: 3px 8px; cursor: pointer; font-size: 10px;">

    <i class="mdi mdi-printer-outline me-1"></i>
    Generate PDF Work Order
</span>

                            <!-- Expand -->

 </span>

                            <span class="work-order-action-icon delete-btn"
                                  title="Delete"
                                  onclick="return confirm('Are you sure you want to delete this sub-contractor work order?')">
                                <i class="mdi mdi-delete-outline"></i>
                            </span>



</span>
                            <span class="work-order-action-icon expand-btn"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseSubWO1"
                                  aria-expanded="false"
                                  aria-controls="collapseSubWO1"
                                  title="Expand">

                                <i class="mdi mdi-chevron-down"></i>
</span>

                        </div>
                    </div>


                </div>

                <div class="collapse mt-4" id="collapseSubWO1">

                        <div class="border-top pt-4">

                            <!-- Project Summary Card -->
                            <div class="card sub-project-summary-card mb-4">
                                <div class="card-body">

                                    <div class="row g-4">

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    PROJECT NAME
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Chennai Metro Phase 2 - Corridor 4
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    CONTRACTOR WORK ORDER NO
                                                </span>

                                                <strong class="d-block mt-1">
                                                      SCWO/APEX/091
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    SUB-CONTRACTOR FIRM
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Apex Structural Sub-Contractors
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    FLOWING CLIENT WO BOQ
                                                </span>

                                                <strong class="d-block mt-1 sub-summary-value-accent">
                                                        WO/CMRL/2026/041 (Elevated Box Girders Launching)
                                                </strong>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>

                        <div class="sub-boq-section-header mb-3">

                            <div class="d-flex align-items-center gap-2">

                                <div class="card-body">

                                    <div class="sub-boq-section-header d-flex justify-content-between align-items-center">

                                        <div class="d-flex align-items-center gap-2">

                                            <div class="sub-boq-section-icon">
                                                <i class="mdi mdi-layers-outline"></i>
                                            </div>

                                            <h6 class="mb-0 fw-bold">
                                                ITEMIZED BOQ FLOWING FROM CLIENT WORK ORDER
                                            </h6>

                                        </div>

                                        <button type="button"
                                                class="btn btn-primary btn-sm sub-generate-pdf-btn"
                                                onclick="openPrintPreview(this)">

                                            <i class="mdi mdi-printer-outline me-1"></i>
                                            GENERATE PDF WORK ORDER

                                        </button>

                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="table-responsive sub-boq-table-wrapper">

                            <table class="table sub-boq-table align-middle mb-0">

                                <thead>
                                    <tr>
                                        <th class="text-center">SR. NO</th>
                                        <th>BOQ ITEM NAME (FROM CLIENT WO)</th>
                                        <th>SPECIFICATION DESCRIPTION</th>
                                        <th class="text-center">UNIT</th>
                                        <th class="text-end">CLIENT QTY</th>
                                        <th class="text-end">CLIENT RATE</th>
                                        <th class="text-end">SUB QTY</th>
                                        <th class="text-end">SUB RATE (₹)</th>
                                        <th class="text-end">SUB AMOUNT (₹)</th>
                                        <th>ALLOCATION REMARKS</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <tr class="sub-boq-category-row">

                                        <td class="text-center fw-bold">
                                            1
                                        </td>

                                        <td class="fw-bold">
                                            ELEVATED GIRDER LAUNCHING
                                        </td>

                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Precast Girder Launching
                                        </td>

                                        <td class="sub-specification">
                                            Precast prestressed concrete box girders
                                        </td>

                                        <td class="text-center fw-semibold">
                                            Nos.
                                        </td>

                                        <td class="text-end font-monospace">
                                            48
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹1,250,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="48">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="1,100,000">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹52,800,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Deck Slab Work
                                        </td>

                                        <td class="sub-specification">
                                            M40 grade reinforced concrete
                                        </td>

                                        <td class="text-center fw-semibold">
                                            CuM
                                        </td>

                                        <td class="text-end font-monospace">
                                            420
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹18,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="300">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="16,500">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹4,950,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="71.43% allocated">
                                        </td>

                                    </tr>

                                </tbody>

                                <tfoot>

                                    <tr>

                                        <td colspan="8"
                                            class="text-end fw-bold">
                                            GRAND TOTAL WORK ORDER VALUE
                                        </td>

                                        <td class="text-end fw-bold text-primary font-monospace">
                                            ₹52,400,000
                                        </td>

                                        <td></td>

                                    </tr>

                                </tfoot>

                            </table>

                        </div>

                        <div class="row mt-4 g-3">

                            <div class="col-12">

                                <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                    <i class="mdi mdi-sync fs-5"></i>

                                    <div>

                                        <strong>
                                            Live Sync Enabled
                                        </strong>

                                        <div class="small mt-1">
                                            Any edits performed inside Sub-Qty,
                                            Sub-Rate, or Allocation Remarks are saved
                                            persistently and mirrored automatically
                                            across Project Manager modules.
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4">

                            <button type="button"
                                    class="btn btn-outline-secondary btn-sm">

                                <i class="mdi mdi-pencil-outline me-1"></i>
                                Edit BOQ Allocation

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="card mb-3 work-order-card shadow-sm"
             data-project="ADY-RES"
             data-client-wo="WO/EI/Y/2025/112"
             data-contractor-wo="SCWO/CRL/045">

            <div class="card-body p-4">

                <div class="row align-items-center">

                    <div class="col-lg-9">

                        <div class="work-order-header-line">

                            <span class="badge rounded-pill project-title-text text-white bg-primary">
                                <i class="mdi mdi-file-document-outline me-1"></i>
                                ADY-RES — Adyar Prevalent Residences
                            </span>

                            <span class="header-separator"></span>

                            <span class="badge wo-number-badge">

                          <span class="badge rounded-pill badge-outline-secondary project-title-text text-primary small bg-primary-subtle small">
                                    SCWO/CRL/045
                                </span>
                            </span>

                            <span class="header-separator"></span>

                            <span class="issued-date">
    <span class="badge rounded-pill badge-outline-secondary project-title-text text-secondary bg-primary-subtle"
          style="font-size: 11px; padding: 3px 7px;">
        <i class="mdi mdi-file-document-outline"></i>
     Ref Client No: WO/EI/Y/2025/112
    </span>

                            </span>

                            <span class="badge bg-label-success">
                                Approved
                            </span>

                        </div>

                        <p class="mb-1 fw-semibold text-dark mt-2">
                            Post-Tensioned Slab & Structural Concrete
                        </p>

                        <div class="small text-muted">
                            <i class="mdi mdi-account-hard-hat me-1"></i>
                            Sub-Contractor:
                            <span class="text-dark fw-bold">
                                Chennai Concrete Works
                            </span>
                        </div>

                    </div>

                     <div class="col-lg-3 mt-3 mt-lg-0">
                        <div class="boq-value-box d-flex align-items-center justify-content-end gap-3">

                            <div class="text-center">
                                <span class="small text-muted d-block text-nowrap">
                                    SUB-CONTRACTOR VALUE
                                </span>

                                <span class="fs-4 fw-bold text-success d-block text-nowrap">
                                    ₹6.11 Cr
                                </span>

                                <span class="small text-muted d-block text-nowrap">
                                    Client BOQ: ₹7.75 Cr
                                </span>
                            </div>




<span class="badge bg-light pdf-work-order-badge text-primary"
      onclick="openPrintPreview(this)"
      title="Generate PDF Work Order"
      style="border-radius: 50px; padding: 3px 8px; cursor: pointer; font-size: 10px;">

    <i class="mdi mdi-printer-outline me-1"></i>
    Generate PDF Work Order
</span>


                            <span class="work-order-action-icon delete-btn"
                                  title="Delete"
                                  onclick="return confirm('Are you sure you want to delete this sub-contractor work order?')">

                                <i class="mdi mdi-delete-outline"></i>

                            </span>

                            </span>

                            <span class="work-order-action-icon expand-btn"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseSubWO2"
                                  aria-expanded="false"
                                  aria-controls="collapseSubWO2"
                                  title="Expand">

                                <i class="mdi mdi-chevron-down"></i>

                            </span>

                        </div>

                    </div>

                </div>

                <div class="collapse mt-4" id="collapseSubWO2">
                        <div class="border-top pt-4">

                            <!-- Project Summary Card -->
                            <div class="card sub-project-summary-card mb-4">
                                <div class="card-body">

                                    <div class="row g-4">

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    PROJECT NAME
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Chennai Metro Phase 2 - Corridor 4
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    CONTRACTOR WORK ORDER NO
                                                </span>

                                                <strong class="d-block mt-1">
                                                 SCWO/CRL/045
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    SUB-CONTRACTOR FIRM
                                                </span>

                                                <strong class="d-block mt-1">
                                                    Chennai Concrete Works
                                                </strong>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="sub-project-summary-item">
                                                <span class="sub-summary-label d-block">
                                                    FLOWING CLIENT WO BOQ
                                                </span>

                                                <strong class="d-block mt-1 sub-summary-value-accent">
                                                     WO/EI/Y/2025/112 (Adyar Block B PT Structure)
                                                </strong>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>

                            <div class="card mb-3">
                                <div class="card-body">

                                    <div class="sub-boq-section-header d-flex justify-content-between align-items-center">

                                        <div class="d-flex align-items-center gap-2">

                                            <div class="sub-boq-section-icon">
                                                <i class="mdi mdi-layers-outline"></i>
                                            </div>

                                            <h6 class="mb-0 fw-bold">
                                                ITEMIZED BOQ FLOWING FROM CLIENT WORK ORDER
                                            </h6>

                                        </div>

                                        <button type="button"
                                                class="btn btn-primary btn-sm sub-generate-pdf-btn"
                                                onclick="openPrintPreview(this)">

                                            <i class="mdi mdi-printer-outline me-1"></i>
                                            GENERATE PDF WORK ORDER

                                        </button>

                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="table-responsive sub-boq-table-wrapper">

                            <table class="table sub-boq-table align-middle mb-0">

                                <thead>

                                    <tr>

                                        <th class="text-center">SR. NO</th>
                                        <th>BOQ ITEM NAME (FROM CLIENT WO)</th>
                                        <th>SPECIFICATION DESCRIPTION</th>
                                        <th class="text-center">UNIT</th>
                                        <th class="text-end">CLIENT QTY</th>
                                        <th class="text-end">CLIENT RATE</th>
                                        <th class="text-end">SUB QTY</th>
                                        <th class="text-end">SUB RATE (₹)</th>
                                        <th class="text-end">SUB AMOUNT (₹)</th>
                                        <th>ALLOCATION REMARKS</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    <tr class="sub-boq-category-row">

                                        <td class="text-center fw-bold">
                                            1
                                        </td>

                                        <td class="fw-bold">
                                            POST-TENSIONED SLAB
                                        </td>

                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            PT Slab System
                                        </td>

                                        <td class="sub-specification">
                                            PT slab system with high tensile strands
                                        </td>

                                        <td class="text-center fw-semibold">
                                            SqM
                                        </td>

                                        <td class="text-end font-monospace">
                                            1,800
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹7,200
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="1,800">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="6,500">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹11,700,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                    <tr class="sub-boq-category-row">

                                        <td class="text-center fw-bold">
                                            2
                                        </td>

                                        <td class="fw-bold">
                                            STRUCTURAL CONCRETE
                                        </td>

                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>

                                    <tr>

                                        <td class="text-center">—</td>

                                        <td class="fw-semibold">
                                            Structural Concrete
                                        </td>

                                        <td class="sub-specification">
                                            M40 Grade structural concrete
                                        </td>

                                        <td class="text-center fw-semibold">
                                            CuM
                                        </td>

                                        <td class="text-end font-monospace">
                                            360
                                        </td>

                                        <td class="text-end font-monospace">
                                            ₹15,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-boq-input text-end"
                                                   value="360">
                                        </td>

                                        <td>
                                            <div class="input-group input-group-sm sub-rate-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text"
                                                       class="form-control text-end sub-boq-input"
                                                       value="13,500">
                                            </div>
                                        </td>

                                        <td class="text-end font-monospace fw-semibold">
                                            ₹4,860,000
                                        </td>

                                        <td>
                                            <input type="text"
                                                   class="form-control form-control-sm sub-remarks-input"
                                                   value="100% allocated">
                                        </td>

                                    </tr>

                                </tbody>

                                <tfoot>

                                    <tr>

                                        <td colspan="8"
                                            class="text-end fw-bold">
                                            GRAND TOTAL WORK ORDER VALUE
                                        </td>

                                        <td class="text-end fw-bold text-primary font-monospace">
                                            ₹19,200,000
                                        </td>

                                        <td></td>

                                    </tr>

                                </tfoot>

                            </table>

                        </div>

                        <div class="row mt-4 g-3">

                            <div class="col-12">

                                <div class="alert alert-info mb-0 d-flex align-items-start gap-2">

                                    <i class="mdi mdi-sync fs-5"></i>

                                    <div>

                                        <strong>
                                            Live Sync Enabled
                                        </strong>

                                        <div class="small mt-1">
                                            Any edits performed inside Sub-Qty,
                                            Sub-Rate, or Allocation Remarks are saved
                                            persistently and mirrored automatically
                                            across Project Manager modules.
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4">

                            <button type="button"
                                    class="btn btn-outline-secondary btn-sm">

                                <i class="mdi mdi-pencil-outline me-1"></i>
                                Edit BOQ Allocation

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="modal fade"
         id="issuesSubContractorModal"
         tabindex="-1"
         aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered modal-lg">

            <div class="modal-content rounded-3 border-0 shadow-lg">

             <div class="modal-header bg-primary text-white">

    <div class="d-flex flex-column gap-1">

        <h5 class="modal-title text-white mb-0">
            Issue New Sub-Contractor Work Order
        </h5>

        <p class="text-white mb-0"
           style="font-size:11px; opacity:.85;">

            Flow items directly from selected Client Work Order BOQ

        </p>

    </div>

    <button type="button"
            class="btn-close btn-close-white"
            data-bs-dismiss="modal">
    </button>

</div>
                <div class="modal-body">

                    <form id="subContractorForm">

                        <div class="row g-3">

                            <div class="col-md-6">

                                <label class="form-label fw-semibold">
                                    Project name
                                </label>

                                <select class="form-select">

                                    <option>
                                        Select Project
                                    </option>

                                    <option>
                                        Chennai Metro Phase 2 - Corridor 4
                                    </option>

                                    <option>
                                        Adyar Prevalent Residences
                                    </option>

                                    <option>
                                        East Coast Road Elevated Bridge
                                    </option>

                                </select>

                            </div>

                            <div class="col-md-6">

                                <label class="form-label fw-semibold">
                                  Linked Client Work Order (BOQ Source)
                                </label>

                                <select class="form-select">

                                    <option>
                                        Select Linked Client Work Order (BOQ Source)

                                    </option>

                                    <option>
                                        WO/CMRL/2025/089 — Corridor 4 Piling & Substructure Contract
                                    </option>

                                    <option>
                                        WO/CMRL/2026/041 — Elevated Box Girders Launching
                                    </option>

                                    <option>
                                        WO/EI/Y/2025/112 — Adyar Block B PT Structure
                                    </option>

                                </select>

                            </div>

                            <div class="col-md-6">

                                <label class="form-label fw-semibold">
                                    Contractor WO Number
                                </label>

                                <input type="text"
                                       class="form-control"
                                       placeholder="SCWO/APEX/XXX"
                                       value="SCWO/APEX/">

                            </div>
 <div class="col-md-6">

                                <label class="form-label fw-semibold">
                                    Sub-Contractor Firm
                                </label>

                                <select class="form-select">

                                    <option>
                                        Select Sub-Contractor Firm
                                    </option>

                                    <option>
                                        Apex Structural Sub-Contractors
                                    </option>

                                    <option>
                                         Chennai Concrete Works
                                    </option>

                                    <option>
                                        Star Bar-Bending Works
                                    </option>

                                    <option>
                                         Vanguard Piling Rigs
                                    </option>


                                </select>
</div>

                            <div class="col-md-12">

                                <label class="form-label fw-semibold">
                                    Trade Package Title
                                </label>

                                <input type="text"
                                       class="form-control"
                                       placeholder="Work order description">

                            </div>

                           <div class="col-md-6">

                                <label class="form-label fw-semibold">
                                    Agreement Rate Basis
                                </label>

                                <select class="form-select">

                                    <option>
                                        Item Rate Boq Flow
                                    </option>

                                    <option>
                                        per cum rate
                                    </option>

                                    <option>
                                         per MT rate
                                    </option>

                                    <option>
                                        per meter depth
                                    </option>

                                    <option>
                                         Lump sum contract
                                    </option>


                                </select>
</div>

                            <div class="col-md-6">

                                <label class="form-label">
                                    Issued Date
                                </label>

                                <input type="date"
                                       class="form-control"
                                       name="issued_date"
                                       value="2026-09-09">

                            </div>

                        </div>

                    </form>

                </div>

                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="button"
                            class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>
                        Issue Sub-Contractor Work Order

                    </button>

                </div>

            </div>

        </div>

    </div>

    <!-- ============================================================ -->
    <!-- MODAL: PDF Print Preview (Work Order Agreement)               -->
    <!-- ============================================================ -->
    <div class="modal fade"
         id="pdfPrintModal"
         tabindex="-1"
         aria-hidden="true"
         data-bs-backdrop="static">

        <div class="modal-dialog modal-dialog-centered modal-xl">

            <div class="modal-content rounded-3 border-0 shadow-lg">

                <div class="modal-header bg-primary text-white py-2">

                    <div class="d-flex align-items-center gap-2">

                        <i class="mdi mdi-file-pdf-box fs-4"></i>

                        <h5 class="modal-title text-white mb-0">
                            Sub-Contractor Work Order Print Preview
                        </h5>

                    </div>

                    <button type="button"
                            class="btn-close btn-close-white"
                            data-bs-dismiss="modal">
                    </button>

                </div>

                <div class="modal-body p-4" id="pdfPrintModalBody">

                    <!-- CONTENT WILL BE INJECTED DYNAMICALLY -->

                </div>

                <div class="modal-footer bg-light">

                    <button type="button"
                            class="btn btn-light"
                            data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>
                        Close
                    </button>

                    <button type="button"
                            class="btn btn-primary"
                            onclick="printPdfPreview()">
                        <i class="mdi mdi-printer me-1"></i>
                        Print / Save as PDF
                    </button>

                </div>

            </div>

        </div>

    </div>

    <!-- ============================================================ -->
    <!-- HIDDEN TEMPLATE: Work Order Agreement HTML                    -->
    <!-- ============================================================ -->
    <template id="pdfAgreementTemplate">

        <div id="pdf-agreement-content" class="pdf-agreement-wrapper">

            <!-- HEADER -->
            <div class="text-center mb-4">
                <h4 class="fw-bold text-uppercase text-primary mb-1">
                    Sub-Contractor WORK ORDER AGREEMENT
                </h4>
                <hr class="hr-primary w-25 mx-auto">
            </div>

            <!-- WO REF NO -->
            <div class="row mb-3">
                <div class="col-12">
                    <div class="bg-light p-2 rounded-2 d-flex align-items-center">
                        <span class="fw-bold text-muted me-2">WO Ref No.:</span>
                        <span class="fw-bold fs-5" id="pdf-wo-ref"></span>
                    </div>
                </div>
            </div>

            <!-- PROJECT DETAILS -->
            <div class="row g-3 mb-4">

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">PROJECT NAME &amp; CODE</span>
                        <strong id="pdf-project-name"></strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">TRADE PACKAGE TITLE</span>
                        <strong id="pdf-trade-package"></strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">AGREEMENT RATE BASIS</span>
                        <strong>Item Rate BOQ</strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">SUB-CONTRACTOR FIRM NAME</span>
                        <strong id="pdf-sub-firm"></strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">FLOWING CLIENT WO BASELINE</span>
                        <strong id="pdf-client-wo"></strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="pdf-detail-box">
                        <span class="pdf-label">CONTRACT STATUS</span>
                        <strong id="pdf-contract-status"></strong>
                    </div>
                </div>

            </div>
<!-- TOTAL APPROVED CONTRACT VALUE -->
<div class="row mb-3">
    <div class="col-12">
        <div class="card border shadow-sm">
            <div class="card-body py-2 px-3">

                <div class="d-flex align-items-center justify-content-between">

                    <!-- LEFT SIDE -->
                    <div>
                        <div class="fw-bold text-uppercase small">
                            TOTAL APPROVED CONTRACT VALUE
                        </div>

                        <div class="text-muted small mt-1" id="pdf-total-words">
                            Rupees Six Crore Ten Lakh Fifty Five Thousand Only
                        </div>
                    </div>

                    <!-- RIGHT SIDE -->
                    <div class="fw-bold text-primary fs-5 ms-3 text-nowrap"
                         id="pdf-total-figure">
                        ₹ 6,10,55,000 /-
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

            <!-- SCHEDULE A - BOQ TABLE -->
            <div class="mb-4">
                <h6 class="fw-bold text-uppercase mb-2">
                    SCHEDULE 'A' — BOQ ITEMS &amp; SUB-CONTRACT RATES
                </h6>
                <div class="table-responsive">
                    <table class="table pdf-boq-table table-bordered table-sm mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="text-center" style="width:50px;">SR.</th>
                                <th>BOQ ITEM DESCRIPTION</th>
                                <th class="text-center" style="width:70px;">UNIT</th>
                                <th class="text-end" style="width:90px;">SUB QTY</th>
                                <th class="text-end" style="width:110px;">SUB RATE (₹)</th>
                                <th class="text-end" style="width:120px;">AMOUNT (₹)</th>
                                <th>REMARKS</th>
                            </tr>
                        </thead>
                        <tbody id="pdf-boq-rows">
                            <!-- injected dynamically -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5" class="text-end fw-bold">GRAND TOTAL WORK ORDER VALUE</td>
                                <td class="text-end fw-bold text-primary" id="pdf-grand-total"></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <!-- GENERAL TERMS & CONDITIONS -->
            <div class="mb-4">
                <h6 class="fw-bold text-uppercase mb-2">
                    GENERAL TERMS &amp; CONDITIONS:
                </h6>
                <ol class="pdf-terms-list ps-3 mb-0">
                    <li>
                        <strong>Technical Specifications:</strong> All execution must strictly comply with IS codes, site engineering drawings, and Project Quality Assurance Plan.
                    </li>
                    <li>
                        <strong>Progress Schedule:</strong> The Sub Contractor agrees to deploy sufficient personnel and equipment to adhere to the baseline project completion schedule.
                    </li>
                    <li>
                        <strong>Measurement &amp; Billing:</strong> RA Bills shall be processed bi-weekly based on jointly verified physical site measurements.
                    </li>
                    <li>
                        <strong>Retention &amp; DLP:</strong> A 5% retention deduction will be made from each running bill and released post completion of the 12 month Defect Liability Period.
                    </li>
                    <li>
                        <strong>Safety &amp; Statutory Compliance:</strong> The sub-contractor is solely responsible for personal protective equipment (PPE), site safety, and statutory ESI/PF labor regulations.
                    </li>
                </ol>
            </div>

            <!-- SIGN-OFF SECTION -->
            <div class="row g-3 pdf-signoff-row">

                <div class="col-md-3">
                    <div class="pdf-signoff-box">
                        <span class="pdf-signoff-label">Prepared By</span>
                        <span class="pdf-signoff-value">Quantity Surveyor / Billing</span>
                        <span class="pdf-signoff-line"></span>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="pdf-signoff-box">
                        <span class="pdf-signoff-label">Verified By</span>
                        <span class="pdf-signoff-value">Project Manager</span>
                        <span class="pdf-signoff-line"></span>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="pdf-signoff-box">
                        <span class="pdf-signoff-label">Accepted By</span>
                        <span class="pdf-signoff-value">Sub-Contractor (Seal &amp; Sign)</span>
                        <span class="pdf-signoff-line"></span>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="pdf-signoff-box">
                        <span class="pdf-signoff-label">Authorized Signatory</span>
                        <span class="pdf-signoff-value">SRIK Executive Management</span>
                        <span class="pdf-signoff-line"></span>
                    </div>
                </div>

            </div>

            <!-- FOOTER -->
            <div class="text-muted small text-center mt-4 pt-2 border-top">
                <i class="mdi mdi-calendar-clock me-1"></i>
                Issue Date: <span id="pdf-issue-date"></span>
            </div>

        </div>

    </template>



    <style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    align-items: center;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 4px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tabs-track .settings-tab-pill,
a.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tabs-track .settings-tab-pill:hover,
a.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tabs-track .settings-tab-pill.active,
a.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


:root {
    --bs-primary: #16659E !important;
    --bs-primary-rgb: 22, 101, 158 !important;
}

.btn-primary {
    --bs-btn-color: #fff !important;
    --bs-btn-bg: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #124f7c !important;
    --bs-btn-hover-border-color: #124f7c !important;
    --bs-btn-active-color: #fff !important;
    --bs-btn-active-bg: #0f4265 !important;
    --bs-btn-active-border-color: #0f4265 !important;
    background-color: #16659E !important;
    border-color: #16659E !important;
    color: #fff !important;
}

.bg-primary {
    background-color: #16659E !important;
}

.text-primary {
    color: #16659E !important;
}

.btn-outline-primary {
    --bs-btn-color: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #16659E !important;
    --bs-btn-hover-border-color: #16659E !important;
    color: #16659E !important;
    border-color: #16659E !important;
}

.bg-primary-subtle {
    background-color: #e8eef5 !important;
}

/* ---------- Sub-Contractor filter row: even 5-column alignment ---------- */
.sub-filter-row {
    row-gap: 12px;
}

.sub-filter-row > [class*="col-"] {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    min-width: 0;
}

.sub-filter-row .form-label {
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 10px;
    letter-spacing: .04em;
}

.sub-filter-row .form-select-sm,
.sub-filter-row .form-control,
.sub-filter-row .input-group-sm .form-control {
    height: 34px;
    font-size: 12.5px;
    padding: 4px 10px;
    border-radius: 6px;
}

.sub-filter-row .input-group-sm .btn {
    height: 34px;
    padding: 0 12px;
}

.sub-filter-row .sub-filter-btn {
    height: 34px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
    padding: 0 12px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.sub-filter-row .form-select-sm {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

@media (max-width: 992px) {
    .sub-filter-row > [class*="col-"] {
        flex: 1 1 calc(50% - 8px);
    }
}

@media (max-width: 576px) {
    .sub-filter-row > [class*="col-"] {
        flex: 1 1 100%;
    }
}

        .wo-header-icon {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            background: rgba(105, 108, 255, 0.10);
            color: #696cff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }

        .work-order-card {
            border: 1px solid #e7e7e9;
            border-radius: 12px;
            transition: all 0.2s ease;
        }

        .work-order-card:hover {
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.07) !important;
            transform: translateY(-1px);
        }

        .work-order-header-line {
            display: flex !important;
            align-items: center !important;
            flex-wrap: nowrap !important;
            gap: 9px !important;
            width: 100% !important;
            max-width: 100% !important;
            white-space: nowrap !important;
            overflow-x: auto !important;
            overflow-y: hidden !important;
            padding: 0 0 2px 0 !important;
            scrollbar-width: thin;
        }

        .project-title-badge {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            gap: 6px !important;
            background: #696cff !important;
            color: #ffffff !important;
            border: 0 !important;
            border-radius: 7px !important;
            padding: 6px 10px !important;
            margin: 0 !important;
            font-size: 12px !important;
            font-weight: 700 !important;
            line-height: 1.3 !important;
            white-space: nowrap !important;
            width: auto !important;
            max-width: none !important;
            min-width: max-content !important;
            flex: 0 0 auto !important;
        }

        .project-title-badge i {
            display: inline-block !important;
            color: #ffffff !important;
            font-size: 15px !important;
            line-height: 1 !important;
            flex: 0 0 auto !important;
        }

        .project-title-text i {
            font-size: 14px;
            vertical-align: middle;
        }

        .header-separator {
            display: inline-block !important;
            color: #b7b7bd !important;
            font-weight: 500 !important;
            flex: 0 0 auto !important;
        }

        .wo-number-badge {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 5px !important;
            background: #f1f1f5 !important;
            color: #444444 !important;
            border: 1px solid #e2e2e6 !important;
            border-radius: 7px !important;
            padding: 6px 10px !important;
            margin: 0 !important;
            font-size: 12px !important;
            font-weight: 700 !important;
            line-height: 1.3 !important;
            white-space: nowrap !important;
            width: auto !important;
            max-width: none !important;
            min-width: max-content !important;
            flex: 0 0 auto !important;
        }

        .issued-date {
            display: inline-flex !important;
            align-items: center !important;
            gap: 4px !important;
            font-size: 13px !important;
            color: #6f7075 !important;
            white-space: nowrap !important;
            flex: 0 0 auto !important;
        }

        .issued-date i {
            font-size: 16px !important;
            color: #696cff !important;
        }

        .boq-value-box {
            min-width: 150px;
            padding-right: 12px;
        }

        .work-order-action-icon {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: auto !important;
            height: auto !important;
            padding: 0 !important;
            margin: 0 !important;
            border: 0 !important;
            border-radius: 0 !important;
            background: transparent !important;
            box-shadow: none !important;
            cursor: pointer;
            line-height: 1;
        }

        .pdf-work-order-badge {
            cursor: pointer;
            padding: 7px 12px;
            font-size: 11px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .pdf-work-order-badge {
            font-size: 10px !important;
            padding: 5px 7px !important;
            white-space: nowrap;
        }


        .work-order-action-icon i {
            font-size: 22px !important;
        }

        .expand-btn {
            color: #696cff !important;
        }

        .expand-btn:hover,
        .expand-btn:focus,
        .expand-btn:active {
            color: #696cff !important;
            background: transparent !important;
            box-shadow: none !important;
        }

        .delete-btn {
            color: #dc3545 !important;
        }

        .delete-btn:hover,
        .delete-btn:focus,
        .delete-btn:active {
            color: #dc3545 !important;
            background: transparent !important;
            box-shadow: none !important;
        }

        .expand-btn i {
            transition: transform 0.2s ease;
        }

        .expand-btn[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        .detail-box {
            height: 100%;
            min-height: 120px;
            border: 1px solid #e7e7e9;
            border-radius: 10px;
            padding: 15px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            background: #fff;
        }

        .detail-icon {
            width: 36px;
            height: 36px;
            min-width: 36px;
            border-radius: 8px;
            background: #f5f5f9;
            color: #696cff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .detail-content {
            flex: 1;
            min-width: 0;
        }

        .detail-content small {
            font-size: 10px;
            font-weight: 600;
            letter-spacing: 0.04em;
        }

        .detail-content .fw-semibold {
            font-size: 13px;
            line-height: 1.5;
        }

        .project-details-card {
            border: 1px solid #e7e7e9;
            overflow: hidden;
        }

        .project-details-card .card-header {
            background: #f8f9fc !important;
        }

        .project-details-icon {
            width: 36px;
            height: 36px;
            min-width: 36px;
            border-radius: 8px;
            background: #eef0ff;
            color: #696cff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .project-detail-card {
            height: 100%;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            border: 1px solid #e7e7e9;
            border-radius: 10px;
            background: #fff;
            transition: all 0.2s ease;
        }

        .project-detail-card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
            transform: translateY(-1px);
        }

        .project-detail-icon {
            width: 36px;
            height: 36px;
            min-width: 36px;
            border-radius: 8px;
            background: #f5f5f9;
            color: #696cff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            flex-shrink: 0;
        }

        .project-detail-content {
            min-width: 0;
            flex: 1;
        }

        .project-detail-content span {
            display: block;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .04em;
            color: #8a8d93;
            margin-bottom: 5px;
        }

        .project-detail-content strong {
            display: block;
            color: #333;
            font-size: 13px;
            line-height: 1.45;
            word-break: break-word;
        }

        .table-section-icon {
            width: 34px;
            height: 34px;
            border-radius: 7px;
            background: #f1f3ff;
            color: #696cff;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .staff-boq-box {
            height: 100%;
            border: 1px solid #e7e7e9;
            border-radius: 10px;
            padding: 15px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-end;
            text-align: right;
        }

        .work-order-card .table {
            font-size: 12px;
        }

        .work-order-card .table th {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            white-space: nowrap;
        }

        .work-order-card .table td {
            vertical-align: middle;
        }

        .badge {
            font-size: 10px;
        }

        /* ===================================================== */
        /* SUB-CONTRACTOR PROJECT SUMMARY CARD (updated UI)        */
        /* ===================================================== */
        .sub-project-summary-card {
            width: 100%;
            border: 1px solid #dce5f0;
            border-radius: 11px;
            background: #ffffff;
            box-shadow: none;
        }

        .sub-project-summary-card > .card-body {
            padding: 14px 20px;
        }

        .sub-project-summary-item {
            min-width: 0;
            padding: 0 14px;
        }

        .sub-project-summary-item:first-child {
            padding-left: 0;
        }

        .sub-project-summary-item:last-child {
            padding-right: 0;
        }

        .sub-summary-label {
            display: block;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            color: #718096;
            margin-bottom: 4px;
        }

        .sub-project-summary-item strong {
            display: block;
            font-size: 11px;
            line-height: 1.35;
            font-weight: 700;
            color: #071d3a;
            word-break: break-word;
        }

        .sub-summary-value-accent {
            color: #0f9d78 !important;
        }

        .sub-boq-section-header {
            min-height: 54px;
            padding: 9px 12px;
            border: 1px solid #dce5f0;
            border-radius: 11px;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .sub-boq-section-icon {
            width: 26px;
            height: 26px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1267a5;
            font-size: 17px;
            flex-shrink: 0;
        }

        .sub-boq-section-header h6 {
            color: #10243e;
            font-size: 11px;
            letter-spacing: .01em;
            text-transform: uppercase;
        }

        .sub-generate-pdf-btn {
            border-radius: 7px;
            font-size: 10px;
            font-weight: 700;
            padding: 7px 13px;
            white-space: nowrap;
            background: #176aa3;
            border-color: #176aa3;
        }

        .sub-boq-table-wrapper {
            border: 1px solid #dce5f0;
            border-radius: 11px;
            overflow-x: auto;
            background: #ffffff;
        }

        .sub-boq-table {
            min-width: 1180px;
            margin: 0;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 10px;
            color: #13233a;
        }

        .sub-boq-table thead th {
            height: 47px;
            padding: 8px 10px;
            background: #f5f8fc;
            color: #31577d;
            border-right: 1px solid #b9c8da;
            border-bottom: 1px solid #b9c8da;
            font-size: 9px;
            line-height: 1.25;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .035em;
            white-space: nowrap;
            vertical-align: middle;
        }

        .sub-boq-table thead th:last-child {
            border-right: 0;
        }

        .sub-boq-table tbody td {
            padding: 7px 10px;
            height: 38px;
            border-right: 1px solid #c6d2df;
            border-bottom: 1px solid #d9e1ea;
            vertical-align: middle;
            white-space: nowrap;
        }

        .sub-boq-table tbody td:last-child {
            border-right: 0;
        }

        .sub-boq-table tbody tr:last-child td {
            border-bottom: 0;
        }

        .sub-boq-category-row td {
            background: #f5f8fc;
            color: #122a47;
            border-bottom: 1px solid #c5d2df !important;
            height: 31px !important;
        }

        .sub-boq-category-row td:first-child {
            color: #122a47;
        }

        .sub-specification {
            color: #43566b;
            font-size: 10px;
            font-style: italic;
            white-space: normal !important;
            line-height: 1.35;
        }

        .sub-boq-input {
            height: 25px;
            min-width: 82px;
            padding: 3px 7px;
            border: 1px solid #f0cf78;
            border-radius: 4px;
            background: #fffdf6;
            color: #111827;
            font-size: 10px;
            font-weight: 600;
            box-shadow: none;
        }

        .sub-boq-input:focus {
            border-color: #f0bd3d;
            background: #ffffff;
            box-shadow: 0 0 0 1px rgba(240, 189, 61, .15);
        }

        .sub-rate-group {
            min-width: 98px;
        }

        .sub-rate-group .input-group-text {
            height: 25px;
            padding: 3px 7px;
            border-color: #f0cf78;
            background: #fffdf6;
            color: #31577d;
            font-size: 10px;
        }

        .sub-rate-group .form-control {
            height: 25px;
            padding: 3px 6px;
            border-color: #f0cf78;
            background: #fffdf6;
            font-size: 10px;
            font-weight: 600;
        }

        .sub-remarks-input {
            min-width: 150px;
            height: 25px;
            padding: 3px 7px;
            border: 1px solid #d9e1ea;
            border-radius: 4px;
            background: #f8fafc;
            color: #31506f;
            font-size: 10px;
            white-space: nowrap;
        }

        .sub-boq-table tfoot td {
            height: 39px;
            padding: 8px 10px;
            background: #f5f8fc;
            border-top: 1px solid #b9c8da;
            color: #10243e;
            font-size: 10px;
        }

        .sub-boq-table tfoot td:last-of-type {
            color: #176aa3;
            font-size: 11px;
        }


        .pdf-agreement-wrapper {
            background: #ffffff;
            padding: 20px 25px;
            font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
            color: #1a2332;
            font-size: 13px;
            line-height: 1.6;
        }

        .pdf-agreement-wrapper .hr-primary {
            border: 0;
            height: 2px;
            background: #696cff;
            opacity: 0.35;
            width: 120px;
            margin: 6px auto 0;
        }

        .pdf-detail-box {
            background: #f8f9fc;
            border: 1px solid #e7e7e9;
            border-radius: 8px;
            padding: 12px 16px;
            min-height: 62px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .pdf-detail-box .pdf-label {
            display: block;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .05em;
            color: #8a8d93;
            margin-bottom: 3px;
        }

        .pdf-detail-box strong {
            font-size: 13px;
            color: #1a2332;
        }

        .pdf-total-box {
            background: #f0f3ff;
            border: 2px solid #696cff;
            border-radius: 10px;
            padding: 16px 20px;
        }

        .pdf-total-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            color: #5a5f7a;
        }

        .pdf-total-amount {
            display: block;
            font-size: 17px;
            font-weight: 700;
            color: #1a2332;
            margin-top: 2px;
        }

        .pdf-total-figure {
            display: block;
            font-size: 26px;
            font-weight: 800;
            color: #696cff;
            margin-top: 2px;
        }

        .pdf-boq-table {
            font-size: 11px;
            border-color: #d0d5dd;
        }

        .pdf-boq-table thead th {
            background: #1a2332;
            color: #ffffff;
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: .04em;
            padding: 8px 10px;
            border-color: #2a3344;
            vertical-align: middle;
        }

        .pdf-boq-table td,
        .pdf-boq-table th {
            padding: 7px 10px;
            border-color: #d0d5dd;
            vertical-align: middle;
        }

        .pdf-boq-table tbody tr:nth-child(even) {
            background: #fafbfc;
        }

        .pdf-boq-table tbody tr.pdf-category-row td {
            background: #eef1f5;
            font-weight: 700;
            color: #1a2332;
        }

        .pdf-boq-table tfoot td {
            background: #f0f3ff;
            font-weight: 700;
            border-top: 2px solid #696cff;
        }

        .pdf-terms-list {
            font-size: 12px;
            color: #1e293b;
            padding-left: 20px;
        }

        .pdf-terms-list li {
            margin-bottom: 6px;
        }

        .pdf-signoff-row {
            margin-top: 20px;
            border-top: 1px solid #e7e7e9;
            padding-top: 20px;
        }

        .pdf-signoff-box {
            text-align: center;
            padding: 6px 4px;
        }

        .pdf-signoff-label {
            display: block;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .05em;
            color: #8a8d93;
            margin-bottom: 4px;
        }

        .pdf-signoff-value {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #1a2332;
        }

        .pdf-signoff-line {
            display: block;
            width: 80%;
            height: 1px;
            border-bottom: 1px dashed #b7b7bd;
            margin: 8px auto 0;
        }


        @media print {

            .modal-header,
            .modal-footer,
            .btn,
            .btn-close {
                display: none !important;
            }

            .modal-content {
                border: 0 !important;
                box-shadow: none !important;
                border-radius: 0 !important;
                background: #ffffff !important;
            }

            .modal-dialog {
                max-width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
            }

            .modal-body {
                padding: 20px !important;
                background: #ffffff !important;
            }

            .pdf-agreement-wrapper {
                padding: 10px 15px !important;
            }

            .pdf-boq-table {
                font-size: 10px !important;
            }

            .pdf-total-figure {
                font-size: 22px !important;
            }

            .pdf-total-amount {
                font-size: 14px !important;
            }

            .pdf-detail-box {
                min-height: 50px !important;
                padding: 8px 12px !important;
            }

            .pdf-detail-box strong {
                font-size: 11px !important;
            }

            .pdf-signoff-box {
                padding: 4px 2px !important;
            }

            .pdf-signoff-value {
                font-size: 10px !important;
            }

            .pdf-terms-list {
                font-size: 10px !important;
            }

            .pdf-terms-list li {
                margin-bottom: 4px !important;
            }

            .work-order-card,
            .card,
            .container-fluid {
                box-shadow: none !important;
                border: 0 !important;
            }

            body {
                background: #ffffff !important;
            }

            .modal-backdrop {
                display: none !important;
            }

        }

        @media (max-width: 992px) {

            .boq-value-box {
                min-width: auto;
            }

            .wo-header-icon {
                width: 44px;
                height: 44px;
                font-size: 22px;
            }

            .sub-project-summary-card .row.g-4 {
                row-gap: 14px;
            }

        }

        @media (max-width: 768px) {

            .d-flex.gap-2.flex-wrap {
                width: 100%;
            }

            .d-flex.gap-2.flex-wrap .btn {
                flex: 1 1 auto;
            }

            .work-order-header-line {
                flex-wrap: wrap !important;
                white-space: normal !important;
                overflow-x: visible !important;
            }

            .header-separator {
                display: none !important;
            }

            .project-details-card .card-header {
                flex-direction: column;
                align-items: flex-start !important;
                gap: 12px;
            }

            .project-details-card .card-header .btn {
                width: 100%;
            }

        }

        @media (max-width: 576px) {

            .container-fluid {
                padding-left: 12px;
                padding-right: 12px;
            }

            .card-body {
                padding: 15px !important;
            }

            .d-flex.gap-2.flex-wrap .btn {
                width: 100%;
            }

            .d-flex.gap-2 select {
                width: 100% !important;
            }

            .issued-date {
                font-size: 12px;
            }

            .project-title-badge {
                font-size: 11px !important;
            }

            .wo-number-badge {
                font-size: 11px !important;
            }

            .sub-project-summary-card > .card-body {
                padding: 15px !important;
            }

            .sub-project-summary-item {
                padding: 0 !important;
            }

            .sub-boq-section-header {
                align-items: flex-start;
                flex-direction: column;
            }

            .sub-generate-pdf-btn {
                width: 100%;
            }

        }
        /* ---------- Ref Client WO badge: softer icon + text tone ---------- */
.issued-date .project-title-text {
    color: #4a5464 !important;          /* muted slate for the whole badge text */
}

.issued-date .project-title-text i {
    color: #6b7280 !important;          /* soft grey icon, matching the screenshot */
    font-size: 13px !important;         /* slightly smaller so it sits neatly */
    vertical-align: middle;
}

.issued-date .project-title-text:hover i {
    color: #4a5464 !important;          /* subtle darken on hover */
}

    </style>

    @stack('page-script')

    <script>

        function openPrintPreview(btn) {

            const card = btn.closest('.work-order-card');
            if (!card) {
                alert('Could not locate the work order card.');
                return;
            }

            const data = extractWorkOrderData(card);
            if (!data) {
                alert('Could not extract work order data.');
                return;
            }

            const html = buildAgreementHtml(data);

            const body = document.getElementById('pdfPrintModalBody');
            if (!body) {
                alert('Modal body not found.');
                return;
            }
            body.innerHTML = html;

            const modal = new bootstrap.Modal(
                document.getElementById('pdfPrintModal'), {
                    backdrop: 'static',
                    keyboard: true
                }
            );
            modal.show();
        }


        function extractWorkOrderData(card) {

            try {

                const projectBadge = card.querySelector(
                    '.project-title-text.bg-primary'
                );
                const projectNameRaw = projectBadge ?
                    projectBadge.textContent.trim() :
                    '';
                const projectName = projectNameRaw
                    .replace(/^[^—]+—\s*/, '')
                    .trim();

                const woBadge = card.querySelector(
                    '.wo-number-badge .project-title-text'
                );
                const woRef = woBadge ?
                    woBadge.textContent.trim().replace(/^[^:]+:\s*/, '') :
                    '';

                const clientBadge = card.querySelector(
                    '.issued-date .project-title-text'
                );
                const clientWoRef = clientBadge ?
                    clientBadge.textContent.trim().replace(/^[^:]+:\s*/, '') :
                    '';

                const statusBadge = card.querySelector(
                    '.badge.bg-label-success, .badge.bg-label-warning, .badge.bg-label-danger'
                );
                const status = statusBadge ?
                    statusBadge.textContent.trim() :
                    '';

                const descEl = card.querySelector('p.mb-1.fw-semibold.text-dark');
                const tradePackage = descEl ?
                    descEl.textContent.trim() :
                    '';

                const firmEl = card.querySelector(
                    '.small.text-muted .text-dark.fw-bold'
                );
                const subFirm = firmEl ?
                    firmEl.textContent.trim() :
                    '';

                const valueEl = card.querySelector(
                    '.boq-value-box .fs-4.fw-bold.text-success'
                );
                const subValueRaw = valueEl ?
                    valueEl.textContent.trim().replace(/[₹,]/g, '').trim() :
                    '0';
                const subValueNum = parseFloat(subValueRaw) || 0;

                const clientBoqEls = card.querySelectorAll(
                    '.boq-value-box .small.text-muted.d-block'
                );
                let clientBoqRaw = '';
                if (clientBoqEls.length >= 2) {
                    clientBoqRaw = clientBoqEls[1].textContent.trim()
                        .replace(/[₹,]/g, '').trim();
                }
                const clientBoqNum = parseFloat(clientBoqRaw) || 0;

                const table = card.querySelector(
                    '.sub-boq-table-wrapper table.sub-boq-table'
                );
                const boqItems = extractBoqItems(table);

                let grandTotal = 0;
                if (boqItems.length > 0) {
                    grandTotal = boqItems.reduce((sum, item) => {
                        const amt = parseFloat(
                            String(item.amount).replace(/[₹,]/g, '').trim()
                        ) || 0;
                        return sum + amt;
                    }, 0);
                } else {
                    const tfoot = table ? table.querySelector('tfoot td.text-primary') : null;
                    if (tfoot) {
                        const raw = tfoot.textContent.trim()
                            .replace(/[₹,]/g, '').trim();
                        grandTotal = parseFloat(raw) || 0;
                    }
                }

                if (grandTotal === 0 && subValueNum > 0) {
                    grandTotal = subValueNum;
                }

                const totalWords = numberToWords(grandTotal);

                return {
                    projectName: projectName || 'N/A',
                    woRef: woRef || 'N/A',
                    clientWoRef: clientWoRef || 'N/A',
                    status: status || 'N/A',
                    tradePackage: tradePackage || 'N/A',
                    subFirm: subFirm || 'N/A',
                    subValue: subValueNum,
                    clientBoqValue: clientBoqNum,
                    boqItems: boqItems,
                    grandTotal: grandTotal,
                    totalWords: totalWords,
                };

            } catch (e) {
                console.error('Error extracting work order data:', e);
                return null;
            }
        }


        function extractBoqItems(table) {

            const items = [];
            if (!table) return items;

            const rows = table.querySelectorAll('tbody tr');
            let srCounter = 0;
            let currentCategory = '';

            rows.forEach(function(row) {

                const cells = row.querySelectorAll('td');
                if (cells.length < 10) return;

                const isCategory = row.classList.contains('sub-boq-category-row');
                const firstText = cells[0] ? cells[0].textContent.trim() : '';

                if (isCategory || firstText === '') {
                    const catName = cells[1] ? cells[1].textContent.trim() : '';
                    if (catName) {
                        currentCategory = catName;
                    }
                    return;
                }

                const sr = cells[0] ? cells[0].textContent.trim() : '';
                const desc = cells[1] ? cells[1].textContent.trim() : '';
                const spec = cells[2] ? cells[2].textContent.trim() : '';
                const unit = cells[3] ? cells[3].textContent.trim() : '';
                const clientQty = cells[4] ? cells[4].textContent.trim() : '';

                const subQtyInput = cells[6] ? cells[6].querySelector('input') : null;
                const subQty = subQtyInput ? subQtyInput.value.trim() : '0';

                const rateGroup = cells[7] ? cells[7].querySelector('.sub-rate-group') : null;
                const rateInput = rateGroup ? rateGroup.querySelector('input') : null;
                let subRate = rateInput ? rateInput.value.trim() : '0';
                if (subRate.startsWith('₹')) subRate = subRate.substring(1).trim();

                const amountEl = cells[8] ? cells[8] : null;
                let amount = amountEl ? amountEl.textContent.trim() : '0';
                if (amount.startsWith('₹')) amount = amount.substring(1).trim();

                const remarksInput = cells[9] ? cells[9].querySelector('input') : null;
                const remarks = remarksInput ? remarksInput.value.trim() : '';

                if (desc) {
                    items.push({
                        sr: sr || '—',
                        category: currentCategory,
                        description: desc,
                        specification: spec,
                        unit: unit,
                        clientQty: clientQty,
                        subQty: subQty,
                        subRate: subRate,
                        amount: amount,
                        remarks: remarks,
                    });
                }

            });

            return items;
        }


        function buildAgreementHtml(data) {

            const template = document.getElementById('pdfAgreementTemplate');
            if (!template) {
                return '<div class="alert alert-danger">Template not found.</div>';
            }

            const clone = template.content.cloneNode(true);
            const wrapper = clone.querySelector('#pdf-agreement-content');
            if (!wrapper) {
                return '<div class="alert alert-danger">Invalid template structure.</div>';
            }

            const setText = (id, value) => {
                const el = wrapper.querySelector('#' + id);
                if (el) el.textContent = value || 'N/A';
            };

            setText('pdf-wo-ref', data.woRef);
            setText('pdf-project-name', data.projectName);
            setText('pdf-trade-package', data.tradePackage);
            setText('pdf-sub-firm', data.subFirm);
            setText('pdf-client-wo', data.clientWoRef);
            setText('pdf-contract-status', data.status);

            const formattedTotal = '₹ ' + formatNumber(data.grandTotal);
            setText('pdf-total-words', data.totalWords || '');
            const totalFigureEl = wrapper.querySelector('#pdf-total-figure');
            if (totalFigureEl) totalFigureEl.textContent = formattedTotal;

            const grandEl = wrapper.querySelector('#pdf-grand-total');
            if (grandEl) grandEl.textContent = formattedTotal;

            const dateEl = wrapper.querySelector('#pdf-issue-date');
            if (dateEl) {
                const now = new Date();
                const y = now.getFullYear();
                const m = String(now.getMonth() + 1).padStart(2, '0');
                const d = String(now.getDate()).padStart(2, '0');
                dateEl.textContent = y + '-' + m + '-' + d;
            }

            const tbody = wrapper.querySelector('#pdf-boq-rows');
            if (tbody) {
                let htmlRows = '';
                let lastCategory = '';

                data.boqItems.forEach(function(item, index) {

                    if (item.category && item.category !== lastCategory) {
                        htmlRows += `
                            <tr class="pdf-category-row">
                                <td colspan="7" class="fw-bold">
                                    ${escapeHtml(item.category)}
                                </td>
                            </tr>
                        `;
                        lastCategory = item.category;
                    }

                    const amountDisplay = '₹ ' + formatNumber(item.amount);
                    const rateDisplay = '₹ ' + formatNumber(item.subRate);

                    htmlRows += `
                        <tr>
                            <td class="text-center">${escapeHtml(item.sr || '—')}</td>
                            <td>
                                ${escapeHtml(item.description)}
                                <br><small class="text-muted">${escapeHtml(item.specification)}</small>
                            </td>
                            <td class="text-center">${escapeHtml(item.unit)}</td>
                            <td class="text-end">${escapeHtml(item.subQty)}</td>
                            <td class="text-end">${rateDisplay}</td>
                            <td class="text-end">${amountDisplay}</td>
                            <td>${escapeHtml(item.remarks)}</td>
                        </tr>
                    `;

                });

                if (!htmlRows) {
                    htmlRows = `
                        <tr>
                            <td colspan="7" class="text-center text-muted py-3">
                                No BOQ items found.
                            </td>
                        </tr>
                    `;
                }

                tbody.innerHTML = htmlRows;
            }

            return wrapper.outerHTML;
        }


        function printPdfPreview() {
            const content = document.getElementById('pdf-agreement-content');
            if (!content) {
                alert('No content to print.');
                return;
            }

            const modalBody = document.getElementById('pdfPrintModalBody');
            const modalDialog = modalBody ? modalBody.closest('.modal-dialog') : null;
            const modalContent = modalDialog ? modalDialog.querySelector('.modal-content') : null;

            const originalOverflow = document.body.style.overflow;
            const originalModalStyles = modalContent ? modalContent.style.cssText : '';

            try {
                document.body.style.overflow = 'visible';

                if (modalContent) {
                    modalContent.style.boxShadow = 'none';
                    modalContent.style.border = '0';
                    modalContent.style.borderRadius = '0';
                    modalContent.style.background = '#ffffff';
                }

                window.print();

            } finally {
                document.body.style.overflow = originalOverflow;
                if (modalContent) {
                    modalContent.style.cssText = originalModalStyles;
                }
            }
        }


        function numberToWords(num) {

            if (!num || num === 0) return 'Zero';

            const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
            const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen',
                'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
            ];
            const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty',
                'Sixty', 'Seventy', 'Eighty', 'Ninety'
            ];

            const convertBelowHundred = (n) => {
                if (n < 10) return ones[n];
                if (n < 20) return teens[n - 10];
                const t = Math.floor(n / 10);
                const o = n % 10;
                return tens[t] + (o ? ' ' + ones[o] : '');
            };

            const convertBelowThousand = (n) => {
                if (n < 100) return convertBelowHundred(n);
                const h = Math.floor(n / 100);
                const r = n % 100;
                return ones[h] + ' Hundred' + (r ? ' ' + convertBelowHundred(r) : '');
            };

            const crore = Math.floor(num / 10000000);
            const lakh = Math.floor((num % 10000000) / 100000);
            const thousand = Math.floor((num % 100000) / 1000);
            const remainder = Math.floor(num % 1000);

            let parts = [];

            if (crore > 0) {
                parts.push(convertBelowThousand(crore) + ' Crore');
            }
            if (lakh > 0) {
                parts.push(convertBelowThousand(lakh) + ' Lakh');
            }
            if (thousand > 0) {
                parts.push(convertBelowThousand(thousand) + ' Thousand');
            }
            if (remainder > 0) {
                parts.push(convertBelowThousand(remainder));
            }

            if (parts.length === 0) return 'Zero';

            let result = parts.join(' ');
            result = result.charAt(0).toUpperCase() + result.slice(1);

            return result + ' Only';
        }


        function formatNumber(n) {
            if (n === undefined || n === null || isNaN(parseFloat(n))) return '0';
            const num = parseFloat(n);
            if (num === 0) return '0';

            const str = String(Math.round(num));
            const len = str.length;

            if (len <= 3) return str;

            const last3 = str.slice(-3);
            const rest = str.slice(0, -3);

            const groups = [];
            let temp = rest;
            while (temp.length > 0) {
                if (temp.length <= 2) {
                    groups.push(temp);
                    break;
                }
                groups.push(temp.slice(-2));
                temp = temp.slice(0, -2);
            }
            groups.reverse();

            let result = groups.join(',') + ',' + last3;
            return result;
        }


        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }



        document.addEventListener('DOMContentLoaded', function() {

            const projectFilter = document.getElementById('subProjectFilter');
            const clientWOFilter = document.getElementById('clientWOFilter');
            const contractorWOFilter = document.getElementById('contractorWOFilter');
            const searchInput = document.getElementById('subSearchInput');
            const searchButton = document.getElementById('subSearchButton');

            function filterWorkOrders() {

                const selectedProject = projectFilter ?
                    projectFilter.value.trim() :
                    'all';

                const selectedClient = clientWOFilter ?
                    clientWOFilter.value.trim() :
                    'all';

                const selectedContractor = contractorWOFilter ?
                    contractorWOFilter.value.trim() :
                    'all';

                const searchTerm = searchInput ?
                    searchInput.value.toLowerCase().trim() :
                    '';

                const cards = document.querySelectorAll('.work-order-card');

                cards.forEach(function(card) {

                    const project = (
                        card.getAttribute('data-project') || ''
                    ).trim();

                    const clientWO = (
                        card.getAttribute('data-client-wo') || ''
                    ).trim();

                    const contractorWO = (
                        card.getAttribute('data-contractor-wo') || ''
                    ).trim();

                    const cardText = (
                        card.textContent || ''
                    ).toLowerCase().replace(/\s+/g, ' ').trim();

                    const projectMatch =
                        selectedProject === 'all' ||
                        project === selectedProject;

                    const clientMatch =
                        selectedClient === 'all' ||
                        clientWO === selectedClient;

                    const contractorMatch =
                        selectedContractor === 'all' ||
                        contractorWO === selectedContractor;

                    const searchMatch =
                        searchTerm === '' ||
                        cardText.includes(searchTerm);

                    if (
                        projectMatch &&
                        clientMatch &&
                        contractorMatch &&
                        searchMatch
                    ) {
                        card.style.removeProperty('display');
                    } else {
                        card.style.setProperty('display', 'none', 'important');
                    }

                });

            }

            if (projectFilter) {
                projectFilter.addEventListener('change', filterWorkOrders);
            }

            if (clientWOFilter) {
                clientWOFilter.addEventListener('change', filterWorkOrders);
            }

            if (contractorWOFilter) {
                contractorWOFilter.addEventListener('change', filterWorkOrders);
            }

            if (searchInput) {

                searchInput.addEventListener('input', filterWorkOrders);

                searchInput.addEventListener('keyup', function(event) {

                    if (event.key === 'Enter') {
                        filterWorkOrders();
                    }

                });

            }

            if (searchButton) {
                searchButton.addEventListener('click', filterWorkOrders);
            }

            document.querySelectorAll('.expand-btn').forEach(function(icon) {

                const targetId = icon.getAttribute('data-bs-target');

                if (!targetId) {
                    return;
                }

                const target = document.querySelector(targetId);

                if (!target) {
                    return;
                }

                target.addEventListener('shown.bs.collapse', function() {

                    icon.setAttribute('aria-expanded', 'true');
                    icon.setAttribute('title', 'Collapse');

                });

                target.addEventListener('hidden.bs.collapse', function() {

                    icon.setAttribute('aria-expanded', 'false');
                    icon.setAttribute('title', 'Expand');

                });

            });

        });
    </script>
  @endsection
