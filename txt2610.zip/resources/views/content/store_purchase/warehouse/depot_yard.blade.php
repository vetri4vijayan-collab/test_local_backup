@extends('layouts/layoutMaster')

@section('title', 'Depot Yard Registry')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  /* --- Hides the cursor globally on the page --- */
  * {
    caret-color: transparent !important;
  }

  /* --- Restores the blinking cursor ONLY inside input fields, textareas, and dropdowns --- */
  input, textarea, select, .form-control, .form-select {
    caret-color: auto !important;
  }

  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }
  .error_msg {
    border: 1px solid red !important;
}

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
@php
  $warehouseTabs = [
    ['key' => 'depot_yard','label' => 'Depot Yard Registry','route' => 'store-purchase.warehouse'],
    ['key' => 'inventory_ledger','label' => 'Inventory Ledger','route' => 'store-purchase.inventory-ledger'],
    ['key' => 'stock_transfer','label' => 'Stock Transfer','route' => 'store-purchase.stock-transfer'],
    [
        'key' => 'allocation_return',
        'label' => 'Allocations & Returns',
        'route' => 'store-purchase.material_allocation',
        'active_keys' => ['material_allocation', 'unused_material_return'], // top pill lights up for both
    ],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_allocation'    => 'material_allocation',
      'store-purchase.unused_material_return' => 'unused_material_return',
      'store-purchase.warehouse'              => 'depot_yard',
      'store-purchase.inventory-ledger'       => 'inventory_ledger',
      'store-purchase.stock-transfer'         => 'stock_transfer',
      default                                 => 'depot_yard',
  };
  // no override line here — let $activeTab stay whatever match() resolved it to
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller">
            @foreach ($warehouseTabs as $tab)
                @if (isset($tab['children']))
                    @php
                        $childActive = collect($tab['children']) ->contains('key', $activeTab);
                    @endphp
                    <div class="settings-tab-dropdown">
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" >
                            {{ $tab['label'] }}
                            <span class="ms-1">
                                <i class="mdi mdi-chevron-down"></i>
                            </span>
                        </button>
                        <div class="settings-tab-dropdown-menu">
                            @foreach ($tab['children'] as $child)
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" >
                                {{ $child['label'] }}
                            </a>
                            @endforeach
                        </div>
                    </div>
                    @else
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" >
                        {{ $tab['label'] }}
                    </a>
                @endif
            @endforeach
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>
<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body p-3">
        @php
            // ---- STATIC DEMO DATA (remove once wired to real controller/model) ----
            $regions = ['South Region', 'West Region', 'North Region', 'East Region'];
        @endphp
        {{-- Toolbar: Search / Region filter / Actions --}}
        <div class="d-flex flex-wrap align-items-center gap-2 mb-4 pb-3 border-bottom">
            <div class="flex-grow-1" style="min-width: 260px;">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="mdi mdi-magnify text-muted"></i>
                    </span>
                    <input type="text"
                           id="warehouseSearch"
                           class="form-control border-start-0 ps-0"
                           placeholder="Search by warehouse, manager, location, or stock items...">
                </div>
            </div>

            <div style="min-width: 160px;">
                <select id="regionFilter" class="form-select">
                    <option value="">All Regions</option>
                    @foreach($regions as $region)
                        <option value="{{ $region }}">{{ $region }}</option>
                    @endforeach
                </select>
            </div>

            <button
                type="button"
                id="toggleNearestSuggestion"
                class="btn btn-outline-secondary d-flex align-items-center gap-1"
            >
                <i class="mdi mdi-navigation-variant-outline"></i>
                <span>Nearest Suggestion Tool</span>
            </button>

            <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#add_warehouse_modal">
                <i class="mdi mdi-plus"></i>
                <span>Add Warehouse Master</span>
            </button>
        </div>

        {{-- Warehouse Cards Grid --}}
        {{-- Skeleton Loader --}}
        <div id="warehouseSkeletonLoader" style="display: none;">
            <div class="row g-3" id="warehouseSkeletonGrid"></div>
        </div>
        <div id="warehouseEmptyState"
          class="text-center text-muted py-5"
          style="display: none;">
          No warehouses found.
      </div>
      {{-- Existing Warehouse Cards Grid - KEEP THIS --}}
      <div class="row g-3" id="warehouseGrid">

          {{-- Keep all your existing code here:
              nearestSuggestionTool
              @forelse($warehouses as $warehouse)
              warehouse cards
              @empty
              @endforelse
          --}}
      </div>
      <div id="warehousePagination" class="mt-4"></div>
    </div>
</div>
<div class="modal fade" id="edit_warehouse_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Update Construction Warehouse Master</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>


            <form id="countryeditSettingForm" action="#" method="POST" novalidate>
                @csrf
                <input type="hidden" name="warehouse_id" id="edit_warehouse_id">
                <div class="modal-body text-start">
                    <div class="row g-2 mb-3">
                        {{-- Project Sites Input Field Only (Tags Removed) --}}
                        <div class="col-lg-12">
                            <label class="form-label">Project Sites</label>
                            <input class="form-control" type="text" id="editProjectSiteInput" name="project_site" placeholder="Enter project site">
                            <div class="text-danger" id="edit_project_site_err"></div>
                        </div>

                        {{-- Head Office & Distance --}}
                        <div class="col-lg-12">
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <label class="form-label">Head Office</label>
                                    <input class="form-control" type="text" name="head_office" placeholder="Enter Head Office Name" value=""/>
                                    <div class="text-danger" id="edit_head_office_err"></div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Distance (km)</label>
                                  <input class="form-control" type="number" id="edit_distance_km" name="distance" step="0.1" min="0">
                                    <div class="text-danger" id="edit_distance_km_err"></div>
                                </div>
                            </div>
                        </div>

                        {{-- Address --}}
                        <div class="col-lg-12">
                            <label class="form-label">Address / Physical Location</label>
                            <textarea class="form-control" name="address" rows="2" placeholder="Enter Address"></textarea>
                            <div class="text-danger" id="edit_address_err"></div>
                        </div>

                        {{-- Country & State --}}
                        <div class="col-lg-6">
                            <label for="country_id_edit" class="form-label fw-semibold">Country <span class="text-danger">*</span></label>
                            <select id="country_id_edit" name="country_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a country</option>
                            </select>
                            <div class="text-danger" id="edit_country_id_edit_err"></div>
                        </div>
                        <div class="col-lg-6">
                            <label for="state_id_edit" class="form-label fw-semibold">State</label>
                            <select id="state_id_edit" name="state_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a State</option>
                            </select>
                            <div class="text-danger" id="edit_state_id_edit_err"></div>
                        </div>

                        {{-- City & Zip Code --}}
                        <div class="col-lg-6">
                          <label for="city_id_edit" class="form-label fw-semibold">
                              City <span class="text-danger">*</span>
                          </label>

                          <select id="city_id_edit"
                                  name="city_id"
                                  class="form-select select3"
                                  required>
                              <option value="">Select a City</option>
                          </select>

                          <div class="text-danger" id="edit_city_id_edit_err"></div>
                      </div>
                        <div class="col-lg-6">
                            <label for="zip_code" class="form-label fw-semibold">Zip Code <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" id="edit_zip_code" name="zip_code" placeholder="Enter Zip Code" required />
                            <div class="text-danger" id="edit_zip_code_err"></div>
                        </div>
                    </div>

                    {{-- Response Officer Details (Mandatory Removed) --}}
                    <div class="row g-2 rounded-3 p-2 bg-label-primary mb-2 mt-4">
                        <label class="form-label">Response Officer/Store Manager Details</label>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Response Officer Name</label>
                            <input class="form-control" type="text" name="response_officer_name" placeholder="Enter Response Officer Name" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Contact Phone</label>
                            <input class="form-control" type="text" name="contact_number" placeholder="Enter Contact Phone" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Designation/Role</label>
                            <input class="form-control" type="text" name="desigination" placeholder="Enter Designation/Role" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Email Id</label>
                            <input class="form-control" type="email" name="mail_id" placeholder="Enter Email Id" value=""/>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Update Warehouse Master</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>
<div class="modal fade" id="inspection_stock_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content border-0 shadow-lg overflow-hidden">
            <div class="modal-header bg-dark text-white border-0 p-4">
                <div class="flex-grow-1">
                    <div class="d-flex align-items-center flex-wrap gap-2 mb-2">
                        <span class="badge bg-secondary font-monospace">
                            WH-VPM-DEP
                        </span>
                        <span class="badge bg-primary rounded-pill text-uppercase">
                            South Region
                        </span>
                        <span class="badge bg-success bg-opacity-10 text-success border border-success">
                            <i class="mdi mdi-check-circle-outline me-1"></i>
                            Active
                        </span>
                    </div>
                    <h4 class="fw-bold text-white mb-1">
                        Villupuram Highway Depot
                    </h4>
                    <div class="small text-white-80 d-flex align-items-start gap-2">
                        <i class="mdi mdi-map-marker-outline text-primary"></i>
                        <span>
                            NH-45 bypass, Near Toll Plaza, Villupuram,
                            Tamil Nadu - 605602
                        </span>
                    </div>
                </div>
                <button
                    type="button"
                    class="btn btn-sm btn-secondary ms-3"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                >
                    <i class="mdi mdi-close fs-5"></i>
                </button>
            </div>
            <div class="bg-light border-bottom px-4 py-2">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <ul class="nav nav-pills gap-1" id="warehouseInspectionTabs">
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link active d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-overview"
                            >
                                <i class="mdi mdi-office-building-outline"></i>
                                Overview & Response Person
                            </button>
                        </li>
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-stock"
                            >
                                <i class="mdi mdi-package-variant-closed"></i>
                                Stocks Present
                                <span class="badge bg-secondary ms-1">5</span>
                            </button>
                        </li>
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-transfer"
                            >
                                <i class="mdi mdi-truck-outline"></i>
                                Stock in Transfer
                                <span class="badge bg-secondary ms-1">1</span>
                            </button>
                        </li>
                    </ul>
                    <button
                        type="button"
                        id="toggleRecordStockInward"
                        class="btn btn-primary btn-sm d-flex align-items-center gap-1"
                    >
                        <i class="mdi mdi-plus"></i>
                        Record Stock Inward
                    </button>
                </div>
            </div>
            <div class="modal-body bg-white p-3">
                <div
                    id="recordStockInward"
                    class="bg-label-primary border border-primary rounded-3 p-4 m-3 d-none"
                >
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div>
                            <h6 class="fw-bold text-primary text-uppercase mb-1 d-flex align-items-center gap-1">
                                <i class="mdi mdi-plus"></i>
                                Record Material Stock Inward For Villupuram Highway Depot
                            </h6>
                        </div>
                        <button
                            type="button"
                            id="closeRecordStock"
                            class="btn btn-sm btn-link text-muted p-0 border border-secondary"
                            style="box-shadow: none;"
                            aria-label="Close"
                        >
                            <i class="mdi mdi-close fs-5"></i>
                        </button>
                    </div>
                    <div class="row g-3">
                        {{-- Project Name --}}
                        <div class="col-md-4">
                            <label for="recordMaterialName" class="form-label fw-semibold small">
                                Material Name
                            </label>
                            <input
                                type="text"
                                id="recordMaterialName"
                                name="material_name"
                                class="form-control"
                                placeholder="Enter Material Name"
                            >
                        </div>
                        {{-- Project Location --}}
                        <div class="col-md-4">
                            <label for="recordMaterialCategory" class="form-label fw-semibold small">
                                Material Category
                            </label>
                            <select
                                id="recordMaterialCategory"
                                name="material_category"
                                class="form-select select3"
                            >
                                <option value="Cement">Cement</option>
                                <option value="Bitumen">Bitumen</option>
                                <option value="Steel & Rebars">Steel & Rebars</option>
                                <option value="Chemicals & Additives">Chemicals & Additives</option>
                                <option value="Aggregates & M-Sand">Aggregates & M-Sand</option>
                                <option value="Pipes & MEP">Pipes & MEP</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="recordStockQuantity" class="form-label fw-semibold small">
                                Stock Quantity
                            </label>
                            <input
                                type="text"
                                id="recordStockQuantity"
                                name="stock_quantity"
                                class="form-control"
                                placeholder="Enter Stock Quantity"
                            >
                        </div>
                        <div class="col-md-4">
                            <label for="recordUnitMeasure" class="form-label fw-semibold small">
                                Unit Of Measure
                            </label>
                            <select
                                id="recordUnitMeasure"
                                name="unit_measure"
                                class="form-select select3"
                            >
                                <option value="Bags">Bags</option>
                                <option value="MT (Metric Tonnes)">MT (Metric Tonnes)</option>
                                <option value="Drums">Drums</option>
                                <option value="PCs">PCs</option>
                                <option value="Kgs">Kgs</option>
                                <option value="Sheets">Sheets</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="recordUnitRate" class="form-label fw-semibold small">
                                Unit Purchase Rate (₹)
                            </label>
                            <input
                                type="text"
                                id="recordUnitRate"
                                name="unit_rate"
                                class="form-control"
                                placeholder="Enter Unit Purchase Rate (₹)"
                            >
                        </div>
                        {{-- Generate --}}
                        <div class="col-md-4 d-flex align-items-end">
                            <button
                                type="button"
                                id="generateRecommendation"
                                class="btn btn-primary w-100"
                            >
                                <i class="mdi mdi-map-marker-distance me-1"></i>
                                Save Stock Inward
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tab-content">
                    <div
                        class="tab-pane fade show active"
                        id="warehouse-overview"
                    >
                        <div class="card border-primary border-opacity-25 bg-label-primary bg-opacity-10 shadow-none mb-4">
                            <div class="card-body p-4">
                                <div class="d-flex justify-content-between align-items-start border-bottom border-primary border-opacity-25 pb-3 mb-3">
                                    <div>
                                        <span class="text-primary fw-bold text-uppercase small">
                                            Primary Response Person & Store Manager
                                        </span>
                                        <h5 class="fw-bold text-dark mb-1 mt-1">
                                            K. Subramaniam
                                        </h5>
                                        <p class="text-dark small fw-semibold mb-0">
                                            Assistant Depot Manager & Site Response Officer
                                        </p>
                                    </div>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill">
                                        <i class="mdi mdi-check-circle me-1"></i>
                                        Active Duty Assigned
                                    </span>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Contact Phone Number
                                            </small>
                                            <a
                                                href="tel:+919842144521"
                                                class="text-primary fw-bold font-monospace text-decoration-none"
                                            >
                                                <i class="mdi mdi-phone-outline me-1"></i>
                                                +91 98421 44521
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Official Email Address
                                            </small>
                                            <span class="text-dark fw-bold font-monospace small">
                                                <i class="mdi mdi-email-outline text-muted me-1"></i>
                                                k.subramaniam@srkinfra.com
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Location Officer ID
                                            </small>
                                            <span class="text-dark fw-bold font-monospace small">
                                                <i class="mdi mdi-shield-check-outline text-primary me-1"></i>
                                                RESP-OFF-VPM-DEP
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card bg-light border shadow-none mb-4">
                            <div class="card-body p-4">
                                <h6 class="fw-bold text-uppercase text-dark mb-3">
                                    <i class="mdi mdi-map-marker-outline text-primary me-1"></i>
                                    Location Address & Regional Network
                                </h6>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="bg-white border rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Physical Address
                                            </small>
                                            <p class="fw-semibold text-dark small mb-0">
                                                NH-45 bypass, Near Toll Plaza,
                                                Villupuram, Tamil Nadu - 605602
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="bg-white border rounded-3 p-3 h-100">
                                            <div class="row">
                                                <div class="col-6">
                                                    <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                        City & District
                                                    </small>
                                                    <span class="fw-bold text-dark small">
                                                        Villupuram, Villupuram
                                                    </span>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                        State & Country
                                                    </small>
                                                    <span class="fw-bold text-dark small">
                                                        Tamil Nadu, India
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="bg-white border rounded-3 p-3">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Mapped Highway / Rail Construction Projects
                                            </small>
                                            <span class="badge bg-label-primary bg-opacity-10 text-primary border border-primary border-opacity-25 px-3 py-2">
                                                East Coast Road Elevated Bridge
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Storage Area Capacity
                                        </small>
                                        <h4 class="fw-bold font-monospace text-dark mt-2 mb-1">
                                            25,000 sq.ft
                                        </h4>
                                        <small class="text-muted">
                                            Covered shed + open storage yard
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Capacity Utilization
                                        </small>
                                        <div class="d-flex align-items-center gap-2 mt-2">
                                            <h4 class="fw-bold font-monospace text-dark mb-0">
                                                58%
                                            </h4>
                                            <div class="progress flex-grow-1" style="height: 8px;">
                                                <div
                                                    class="progress-bar bg-primary"
                                                    role="progressbar"
                                                    style="width: 58%;"
                                                    aria-valuenow="58"
                                                    aria-valuemin="0"
                                                    aria-valuemax="100"
                                                ></div>
                                            </div>
                                        </div>
                                        <small class="text-muted">
                                            Optimal threshold below 85%
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Total Asset Stock Valuation
                                        </small>
                                        <h4 class="fw-bold font-monospace text-success mt-2 mb-1">
                                            ₹2,40,00,072
                                        </h4>
                                        <small class="text-muted">
                                            Verified as per central store ledger
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="tab-pane fade"
                        id="warehouse-stock"
                    >
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="fw-bold mb-1">
                                    Stock Present
                                </h6>
                                <small class="text-muted">
                                    Materials and assets currently available at this warehouse.
                                </small>
                            </div>
                            <span class="badge bg-primary">
                                5 Items
                            </span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Item</th>
                                        <th>Category</th>
                                        <th>Quantity</th>
                                        <th>Unit</th>
                                        <th>Value</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-semibold">
                                            Cement
                                        </td>
                                        <td>Construction Material</td>
                                        <td class="fw-bold">1,250</td>
                                        <td>Bags</td>
                                        <td>₹5,62,500</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            TMT Steel
                                        </td>
                                        <td>Steel Material</td>
                                        <td class="fw-bold">85</td>
                                        <td>MT</td>
                                        <td>₹5,10,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Aggregate
                                        </td>
                                        <td>Construction Material</td>
                                        <td class="fw-bold">320</td>
                                        <td>MT</td>
                                        <td>₹2,88,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Safety Helmets
                                        </td>
                                        <td>Safety Equipment</td>
                                        <td class="fw-bold">145</td>
                                        <td>Nos</td>
                                        <td>₹43,500</td>
                                        <td>
                                            <span class="badge bg-warning text-dark">
                                                Low Stock
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Welding Machines
                                        </td>
                                        <td>Equipment</td>
                                        <td class="fw-bold">12</td>
                                        <td>Nos</td>
                                        <td>₹3,60,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div
                            class="tab-pane fade"
                            id="warehouse-transfer"
                        >
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="fw-bold mb-1">
                                        Stock in Transfer
                                    </h6>
                                    <small class="text-muted">
                                        Materials currently moving to or received by this warehouse.
                                    </small>
                                </div>
                                <span class="badge bg-warning text-dark fs-8">
                                    1 Transfer
                                </span>
                            </div>
                            {{-- Transfer Card --}}
                            <div class="card border shadow-none rounded-3 mb-3">
                                <div class="card-body p-4">
                                    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-2 border-bottom pb-3 mb-3">
                                        <div class="d-flex align-items-center flex-wrap gap-2">
                                            <span class="badge bg-light text-dark border font-monospace px-2 py-1">
                                                TRF-2026-001
                                            </span>
                                            <span class="badge bg-success bg-opacity-10 text-success text-uppercase">
                                                Incoming Shipment
                                            </span>
                                        </div>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2">
                                            Status: Received
                                        </span>
                                    </div>
                                    <div class="row g-4">
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Material Transferred
                                            </small>
                                            <p class="fw-bold text-dark mb-1">
                                                Cement OPC 53 Grade
                                            </p>
                                            <span class="font-monospace fw-bold text-success">
                                                500 Bags
                                            </span>
                                        </div>
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Source / Destination Hub
                                            </small>
                                            <p class="fw-bold text-dark mb-1">
                                                Chennai Central Logistics Yard
                                                <span class="text-muted">
                                                    (WH-001)
                                                </span>
                                            </p>
                                            <small class="text-muted">
                                                Dispatched:
                                                <span class="font-monospace">
                                                    2026-07-22
                                                </span>
                                            </small>
                                        </div>
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Vehicle & Driver Details
                                            </small>
                                            <p class="fw-bold font-monospace text-dark mb-1">
                                                TN-01-AX-9912
                                            </p>
                                            <p class="small text-dark mb-1">
                                                <i class="mdi mdi-account-outline text-muted me-1"></i>
                                                M. Sundaram
                                                <span class="text-muted">
                                                    (+91 97880 11223)
                                                </span>
                                            </p>
                                            <small class="text-warning fw-bold font-monospace">
                                                Expected ETA:
                                                2026-07-23
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <div class="modal-footer bg-light border-top d-flex justify-content-between">
                <div class="text-muted small d-flex align-items-center gap-1">
                    <i class="mdi mdi-clock-outline"></i>
                    <span>
                        Last System Update:
                        <strong>2026-07-25 15:45</strong>
                    </span>
                </div>
                <button
                    type="button"
                    class="btn btn-dark"
                    data-bs-dismiss="modal"
                >
                    Close Inspector
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="add_warehouse_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Add Construction Warehouse Master</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="countrySettingForm" action="#" >
                      @csrf
                      <div class="modal-body text-start">
                          <div class="row g-2 mb-3">
                              {{-- Project Sites Input Field Only (Tags Removed) --}}
                            <div class="col-lg-12">
                                <label for="addProjectSiteInput" class="form-label">
                                    Project Sites <span class="text-danger">*</span>
                                </label>
                                  <input class="form-control"
                                        type="text"
                                        id="addProjectSiteInput"
                                        name="project_site"
                                        placeholder="Enter project site">
                                <div class="text-danger" id="project_site_err"></div>
                            </div>

                              {{-- Head Office & Distance --}}
                            <div class="col-lg-12">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                <label for="head_office" class="form-label">
                                    Head Office <span class="text-danger">*</span>
                                </label>
                                <input class="form-control"
                                      type="text"
                                      id="head_office"
                                      name="head_office"
                                      placeholder="Enter Head Office Name">
                                <div class="text-danger" id="head_office_err"></div>
                            </div>

                              <div class="col-md-6">
                            <label for="distance" class="form-label">
                                Distance (km) <span class="text-danger">*</span>
                            </label>
                            <input class="form-control"
                                  type="number"
                                  id="distance"
                                  name="distance"
                                  step="0.1"
                                  min="0"
                                  placeholder="e.g. 12.5">
                            <div class="text-danger" id="distance_err"></div>
                        </div>
                      </div>
                            {{-- Address --}}
                      <div class="col-lg-12">
                          <label for="address" class="form-label">
                              Address / Physical Location <span class="text-danger">*</span>
                          </label>
                          <textarea class="form-control"
                                    id="address"
                                    name="address"
                                    rows="2"
                                    placeholder="Enter Address"></textarea>
                          <div class="text-danger" id="address_err"></div>
                      </div>
                      <div class="row g-2 mb-3">
                          <div class="col-lg-6">
                            <label for="country_id" class="form-label fw-semibold">
                                Country <span class="text-danger">*</span>
                            </label>
                            <select id="country_id" name="country_id" class="form-select select3">
                                <option value="">Select country</option>
                            </select>
                            <div class="text-danger" id="country_id_err"></div>
                          </div>
                          <div class="col-lg-6">
                            <label for="state_id" class="form-label fw-semibold">
                                State <span class="text-danger">*</span>
                            </label>
                            <select id="state_id" name="state_id" class="form-select select3">
                                <option value="">Select a State</option>
                            </select>
                            <div class="text-danger" id="state_id_err"></div>
                          </div>
                        <div class="col-lg-6">
                          <label for="city_id" class="form-label fw-semibold">
                              City <span class="text-danger">*</span>
                          </label>
                          <select id="city_id" name="city_id" class="form-select select3">
                              <option value="">Select a City</option>
                          </select>
                          <div class="text-danger" id="city_id_err"></div>
                        </div>
                        <div class="col-lg-6">
                          <label for="zip_code" class="form-label fw-semibold">
                              Zip Code <span class="text-danger">*</span>
                          </label>
                          <input class="form-control"
                                type="text"
                                id="zip_code"
                                name="zip_code"
                                placeholder="Enter Zip Code">
                          <div class="text-danger" id="zip_code_err"></div>
                        </div>
                      </div>
                      {{-- Response Officer Details (Mandatory Removed) --}}
                      <div class="row g-2 rounded-3 p-2 bg-label-primary mb-2 mt-4">
                          <label class="form-label">Response Officer/Store Manager Details</label>
                          <div class="col-lg-6 mb-2">
                              <label class="form-label text-black">Response Officer Name</label>
                              <input class="form-control" type="text" name="response_officer_name" placeholder="Enter Response Officer Name" value=""/>
                          </div>
                          <div class="col-lg-6 mb-2">
                              <label class="form-label text-black">Contact Phone</label>
                              <input class="form-control" type="text" name="contact_number" placeholder="Enter Contact Phone" value=""/>
                          </div>
                          <div class="col-lg-6 mb-2">
                              <label class="form-label text-black">Designation/Role</label>
                              <input class="form-control" type="text" name="desigination" placeholder="Enter Designation/Role" value=""/>
                          </div>
                          <div class="col-lg-6 mb-2">
                              <label class="form-label text-black">Email Id</label>
                              <input class="form-control" type="email" name="mail_id" placeholder="Enter Email Id" value=""/>
                          </div>
                      </div>
                  </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Save Warehouse Master</span>
                    </button>
                </div>
        </form>
        </div>
    </div>
</div>
{{-- Client-side search + region filter --}}
<script>
    document.addEventListener('DOMContentLoaded', function () {
    const toggleButton = document.getElementById('toggleNearestSuggestion');
    const closeButton = document.getElementById('closeNearestSuggestion');
    const suggestionTool = document.getElementById('nearestSuggestionTool');
    if (!toggleButton || !suggestionTool) {
        console.warn('Nearest Suggestion Tool elements are missing.');
        return;
    }
    toggleButton.addEventListener('click', function () {
        suggestionTool.classList.toggle('d-none');
    });
    if (closeButton) {
        closeButton.addEventListener('click', function () {
            suggestionTool.classList.add('d-none');
        });
    }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const toggleButton = document.getElementById('toggleRecordStockInward');
    const closeButton = document.getElementById('closeRecordStock');
    const suggestionTool = document.getElementById('recordStockInward');

    toggleButton.addEventListener('click', function () {
        suggestionTool.classList.toggle('d-none');
    });

    closeButton.addEventListener('click', function () {
        suggestionTool.classList.add('d-none');
    });

});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const inspectionModal = document.getElementById('inspection_stock_modal');
    if (!inspectionModal) {
        return;
    }
    inspectionModal.addEventListener('show.bs.modal', function (event) {
        // Button which opened the modal
        const button = event.relatedTarget;
        if (!button) {
            return;
        }
        // Get the target tab
        const targetTab = button.getAttribute('data-inspection-tab');
        if (!targetTab) {
            return;
        }
        // Find the corresponding tab button
        const tabButton = inspectionModal.querySelector(
            `[data-bs-target="${targetTab}"]`
        );
        if (tabButton) {
            // Bootstrap 5 Tab API
            const tab = new bootstrap.Tab(tabButton);
            tab.show();
        }
    });

});
</script>
<script>
  function buildRow(item, index) {
    const escapeHtml = (value) => String(value ?? '-').replace(/[&<>"']/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    })[char]);

    const stocks = Array.isArray(item.stocks) ? item.stocks : [];
    const transfers = Array.isArray(item.transfers) ? item.transfers : [];
    const stockCount = stocks.length;
    const transferCount = transfers.length;
    const status = String(item.status ?? '1').toLowerCase();
    const isActive = status === '0' || status === 'active';
    const stockRows = stocks.slice(0, 3).map((stock, stockIndex) => `
        <div class="d-flex justify-content-between small py-1 ${stockIndex < 2 ? 'border-bottom' : ''}">
            <span class="text-truncate pe-2">
                ${escapeHtml(stock.item_name)}
            </span>
            <span class="fw-semibold text-nowrap">
                ${Number(stock.quantity || 0).toLocaleString('en-IN')}
                ${escapeHtml(stock.unit)}
            </span>
        </div>
    `).join('');
    const transferRows = transfers.length
        ? transfers.map(transfer => `
            <div class="mb-2 p-2 bg-gray-100 rounded d-flex flex-column gap-1">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="badge ${transfer.direction === 'OUTGOING' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info'}"
                          style="font-size:.65rem;">
                        ${escapeHtml(transfer.direction)}
                    </span>
                    <span class="small font-monospace text-muted">
                        ${escapeHtml(transfer.reference_no)}
                    </span>
                </div>
                <div class="d-flex justify-content-between small mt-1">
                    <span>${escapeHtml(transfer.item_name)}</span>
                    <span class="fw-semibold">
                        ${Number(transfer.quantity || 0).toLocaleString('en-IN')}
                        ${escapeHtml(transfer.unit)}
                    </span>
                </div>
                <div class="d-flex justify-content-between small text-muted">
                    <span>Driver: ${escapeHtml(transfer.driver_name)}</span>
                    <span class="text-danger">ETA: ${escapeHtml(transfer.eta)}</span>
                </div>
            </div>
        `).join('')
        : '<div class="text-muted small text-center py-2">No active transfers</div>';

    const moreStocks = stockCount > 3
        ? `<div class="text-end">
               <a href="#" class="small text-decoration-none fs-9">
                   + ${stockCount - 3} more stock items...
               </a>
           </div>`
        : '';

    return `
        <div class="col-12 col-md-6 col-xl-4 warehouse-card-col"
             data-region="${escapeHtml(item.region)}"
             data-search="${escapeHtml([
                 item.project_site,
                 item.code,
                 item.response_officer_name,
                 item.city_name,
                 item.district,
                 item.address,
                 ...stocks.map(stock => stock.item_name)
             ].join(' ').toLowerCase())}">

            <div class="card h-100 border shadow-sm wh-card">

                <div class="card-header border-bottom d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="d-flex gap-1">
                        </div>

                        <div class="d-flex gap-1 align-items-center">
                           <button type="button"
                                class="btn btn-sm btn-link p-0 shadow-none"
                                data-bs-toggle="modal"
                                data-bs-target="#edit_warehouse_modal"
                                data-warehouse-id="${escapeHtml(item.sno ?? '')}"
                               >
                                <i class="mdi mdi-pencil-outline text-secondary"></i>
                            </button>

                            <button type="button"
                                  class="btn btn-sm border-0 rounded-pill px-2 shadow-none
                                      ${isActive
                                          ? 'bg-success-subtle text-success'
                                          : 'bg-secondary-subtle text-secondary'}"
                                  style="font-size: .7rem;"
                                  data-warehouse-status="${escapeHtml(item.sno)}"
                                  data-current-status="${isActive ? '0' : '1'}"
                                  onclick="updateWarehouseStatus(this)">

                                  <i class="mdi mdi-circle-fill me-1"
                                    style="font-size:6px;"></i>

                                  <span class="status-label">
                                      ${isActive ? 'ACTIVE' : 'INACTIVE'}
                                  </span>

                                  <i class="mdi mdi-swap-horizontal ms-1"></i>
                              </button>
                        </div>
                    </div>

                    <h6 class="fw-bold mb-3">${escapeHtml(item.project_site)}</h6>
                </div>

                <div class="card-body d-flex flex-column p-0 pb-2">

                    <div class="p-3 border-bottom bg-light-subtle">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="text-uppercase text-muted small fw-semibold"
                                 style="font-size:.7rem;">
                                <i class="mdi mdi-account-outline me-1"></i>
                                Responsible Officer
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-start">
                            <div class="d-flex flex-column gap-1">
                                <span class="fw-bold small">
                                    ${escapeHtml(item.response_officer_name)}
                                </span>
                                <span class="text-muted fs-9 text-wrap">
                                    ${escapeHtml(item.desigination)}
                                </span>
                                <span class="text-muted fs-9">
                                    <i class="mdi mdi-email-outline me-1"></i>
                                    ${escapeHtml(item.mail_id)}
                                </span>
                            </div>

                            <div class="text-end">
                                <div class="small">
                                    <a href="tel:${escapeHtml(item.contact_number)}"
                                       class="text-decoration-none fs-8 text-primary border p-1 rounded">
                                        <i class="mdi mdi-phone-outline me-1 fs-9"></i>
                                        ${escapeHtml(item.contact_number)}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3 p-3 border-bottom">
                        <div class="text-uppercase text-muted small fw-semibold mb-1"
                             style="font-size:.7rem;letter-spacing:.03em;">
                            Location Address & Proximity
                        </div>

                        <div class="d-flex align-items-start gap-1">
                            <i class="mdi mdi-map-marker-radius-outline text-primary fs-9"></i>
                            <div class="small mb-1">${escapeHtml(item.address)}</div>
                        </div>

                        <div class="d-flex flex-wrap align-items-center gap-1">
                            <span class="badge bg-light text-dark border fs-8">
                                State: ${escapeHtml(item.state_name)}
                            </span>
                            <span class="badge bg-light text-dark border fs-8">
                                City: ${escapeHtml(item.city_name)}
                            </span>
                            <span class="text-primary fs-8">
                                ${Number(item.projects_mapped || 0)} Projects Mapped
                            </span>
                        </div>
                    </div>

                    <div class="p-2">
                        <div class="mt-auto">
                            <button type="button"
                                    class="btn btn-primary w-100 mb-2 d-flex align-items-center justify-content-center gap-2"
                                    data-bs-toggle="modal"
                                    data-bs-target="#inspection_stock_modal"
                                    data-inspection-tab="#warehouse-overview"
                                    data-warehouse-id="${escapeHtml(item.id)}">
                                <i class="mdi mdi-eye"></i>
                                Inspect Stock & Transfer Details
                            </button>

                            <div class="d-flex flex-wrap gap-2 justify-content-evenly">
                                <button type="button"
                                        class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1"
                                        data-bs-toggle="modal"
                                        data-bs-target="#inspection_stock_modal"
                                        data-inspection-tab="#warehouse-stock"
                                        data-warehouse-id="${escapeHtml(item.id)}">
                                    <i class="mdi mdi-package-variant-closed text-success"></i>
                                    Stocks
                                </button>

                                <button type="button"
                                        class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1"
                                        data-bs-toggle="modal"
                                        data-bs-target="#inspection_stock_modal"
                                        data-inspection-tab="#warehouse-transfer"
                                        data-warehouse-id="${escapeHtml(item.id)}">
                                    <i class="mdi mdi-truck-outline text-warning"></i>
                                    Transfers
                                </button>
                                <button type="button"
                                        class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1">
                                    <i class="mdi mdi-printer-outline"></i>
                                    Report
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    `;
}
function skeletenRow() {
    return Array.from({ length: 3 }, () => `
        <div class="col-12 col-md-6 col-xl-4">
            <div class="card h-100 border shadow-sm">
                <div class="card-header">
                    <div class="skeleton mb-3" style="height:20px;width:45%;"></div>
                    <div class="skeleton" style="height:22px;width:75%;"></div>
                </div>
                <div class="card-body">
                    <div class="skeleton mb-2" style="height:14px;width:55%;"></div>
                    <div class="skeleton mb-2" style="height:14px;width:85%;"></div>
                    <div class="skeleton mb-4" style="height:14px;width:65%;"></div>

                    <div class="skeleton mb-2" style="height:18px;width:70%;"></div>
                    <div class="skeleton mb-2" style="height:14px;width:95%;"></div>
                    <div class="skeleton mb-2" style="height:14px;width:80%;"></div>
                    <div class="skeleton mb-4" style="height:14px;width:60%;"></div>

                    <div class="skeleton mb-2" style="height:42px;width:100%;"></div>
                    <div class="skeleton" style="height:32px;width:100%;"></div>
                </div>
            </div>
        </div>
    `).join('');
}
let currentPage = 1;
let isLoading = false;
let abortController = new AbortController();
function loadThemes(page = 1) {
    const search = document.getElementById('warehouseSearch')?.value || '';
    const region = document.getElementById('regionFilter')?.value || '';
    const url = `{{ route('store-purchase.warehouse.list') }}?page=${page}`
    + `&search_filter=${encodeURIComponent(search)}`
    + `&region_filter=${encodeURIComponent(region)}`;
    const grid = document.getElementById('warehouseGrid');
    const skeletonGrid = document.getElementById('warehouseSkeletonGrid');
    const skeletonWrapper = document.getElementById('warehouseSkeletonLoader');
    const emptyState = document.getElementById('warehouseEmptyState');
    isLoading = true;
    grid.querySelectorAll('.warehouse-card-col').forEach(card => card.remove());
    skeletonGrid.innerHTML = skeletenRow();
    skeletonWrapper.style.display = 'block';
    emptyState.style.display = 'none';
    abortController.abort();
    abortController = new AbortController();
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        },
        signal: abortController.signal
    })
    .then(res => {
        if (!res.ok) {
            throw new Error(`Request failed: ${res.status}`);
        }
        return res.json();
    })
    .then(res => {
        const items = Array.isArray(res.data) ? res.data : [];
        items.forEach((item, index) => {
            grid.insertAdjacentHTML('beforeend', buildRow(item, index + 1));
        });
        currentPage = Number(res.current_page || page);
        updatePagination(currentPage,Number(res.last_page || 1),Number(res.total || items.length),Number(res.per_page || 10));
        emptyState.style.display = items.length ? 'none' : 'block';
    })
    .catch(error => {
        if (error.name !== 'AbortError') {
            console.error('Error loading warehouses:', error);
            emptyState.textContent = 'Unable to load warehouses. Please try again.';
            emptyState.style.display = 'block';
        }
    })
    .finally(() => {
        // A cancelled, older request must not hide the latest request's loader.
        if (!abortController.signal.aborted) {
            skeletonWrapper.style.display = 'none';
            isLoading = false;
        }
    });
}
function updatePagination(currentPage, lastPage, total, perpage) {
    const container = document.getElementById('warehousePagination');
    container.innerHTML = '';
    if (lastPage <= 1 && total === 0) {
        return;
    }
    const start = total === 0 ? 0 : (currentPage - 1) * perpage + 1;
    const end = Math.min(currentPage * perpage, total);
    container.style.display = 'flex';
    container.style.justifyContent = 'space-between';
    container.style.alignItems = 'center';
    container.style.flexWrap = 'wrap';
    container.style.gap = '12px';
    container.innerHTML = `
        <span>Showing ${start} to ${end} of ${total} results</span>
        <nav aria-label="Warehouse pagination">
            <ul class="pagination mb-0">
                <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                    <button class="page-link" ${currentPage <= 1 ? 'disabled' : ''}
                        onclick="loadThemes(1)">«</button>
                </li>
                <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                    <button class="page-link" ${currentPage <= 1 ? 'disabled' : ''}
                        onclick="loadThemes(${currentPage - 1})">‹</button>
                </li>
                ${Array.from(
                    { length: Math.max(0, Math.min(lastPage, currentPage + 2) - Math.max(1, currentPage - 2) + 1) },
                    (_, index) => Math.max(1, currentPage - 2) + index
                ).map(page => `
                    <li class="page-item ${page === currentPage ? 'active' : ''}">
                        <button class="page-link" onclick="loadThemes(${page})">${page}</button>
                    </li>
                `).join('')}
                <li class="page-item ${currentPage >= lastPage ? 'disabled' : ''}">
                    <button class="page-link" ${currentPage >= lastPage ? 'disabled' : ''}
                        onclick="loadThemes(${currentPage + 1})">›</button>
                </li>
                <li class="page-item ${currentPage >= lastPage ? 'disabled' : ''}">
                    <button class="page-link" ${currentPage >= lastPage ? 'disabled' : ''}
                        onclick="loadThemes(${lastPage})">»</button>
                </li>
            </ul>
        </nav>
    `;
}
const warehouseSearch = document.getElementById('warehouseSearch');
const regionFilter = document.getElementById('regionFilter');
let warehouseSearchTimeout;
if (warehouseSearch) {
    warehouseSearch.addEventListener('input', function () {
        clearTimeout(warehouseSearchTimeout);
        warehouseSearchTimeout = setTimeout(() => loadThemes(1), 300);
    });
}
if (regionFilter) {
    regionFilter.addEventListener('change', () => loadThemes(1));
}
// Initial load
loadThemes(1);
 $(document).ready(function () {
    function fetchCountries() {
        $.ajax({
            url: '/store/states_by_country',
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                const countryDropdown = $('#country_id');
                countryDropdown.empty().append('<option value="">Select country</option>');
                if (response.status === 200 && response.data) {
                    response.data.forEach(function (country) {
                        countryDropdown.append(
                            $('<option></option>')
                                .val(country.sno)
                                .text(country.country_name)
                        );
                    });
                }
            },
            error: function (xhr) {
                console.error(
                    'Error fetching countries:',
                    xhr.status,
                    xhr.responseText
                );
            }
        });
    }
    function country_function() {
        const countryId = $(this).val();
        const stateDropdown = $('#state_id');
        const cityDropdown = $('#city_id');
        stateDropdown.empty().append('<option value="">Select state</option>');
        cityDropdown.empty().append('<option value="">Select city</option>');
        if (!countryId) return;
        $.ajax({
            url: '/store/states_by_country/' + countryId,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response.status === 200 && response.data) {
                    response.data.forEach(function (state) {
                        stateDropdown.append(
                            $('<option></option>')
                                .val(state.sno)
                                .text(state.state_name)
                        );
                    });
                }
            },
            error: function (xhr) {
                console.error(
                    'Error fetching states:',
                    xhr.status,
                    xhr.responseText
                );
            }
        });
    }
    function state_function() {
        const stateId = $(this).val();
        const cityDropdown = $('#city_id');
        cityDropdown.empty().append('<option value="">Select city</option>');
        if (!stateId) return;
        $.ajax({
            url: '/store/city_by_state/' + stateId,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response.status === 200 && response.data) {
                    response.data.forEach(function (city) {
                        cityDropdown.append(
                            $('<option></option>')
                                .val(city.sno)
                                .text(city.city_name)
                        );
                    });
                }
            },
            error: function (xhr) {
                console.error(
                    'Error fetching cities:',
                    xhr.status,
                    xhr.responseText
                );
            }
        });
    }
    $('#country_id').on('change', country_function);
    $('#state_id').on('change', state_function);
    fetchCountries();
});
$(document).ready(function () {
    $('#countrySettingForm').on('submit', function (e) {
        e.preventDefault();
        addValidateForm();
    });
    function addValidateForm() {
        var err = 0;
        const fields = [
            {
                id: 'addProjectSiteInput',
                errorId: 'project_site_err',
                message: 'Project Site is required...!'
            },
            {
                id: 'head_office',
                errorId: 'head_office_err',
                message: 'Head Office is required...!'
            },
            {
                id: 'distance',
                errorId: 'distance_err',
                message: 'Distance is required...!'
            },
            {
                id: 'address',
                errorId: 'address_err',
                message: 'Address is required...!'
            },
            {
                id: 'country_id',
                errorId: 'country_id_err',
                message: 'Please select a Country...!'
            },
            {
                id: 'state_id',
                errorId: 'state_id_err',
                message: 'Please select a State...!'
            },
            {
                id: 'city_id',
                errorId: 'city_id_err',
                message: 'Please select a City...!'
            },
            {
                id: 'zip_code',
                errorId: 'zip_code_err',
                message: 'Zip Code is required...!'
            }
        ];
        fields.forEach(function (field) {
            const input = document.getElementById(field.id);
            const error = document.getElementById(field.errorId);
            const value = input.value.trim();
            let invalid = value === '';
            if (field.id === 'distance' && value !== '') {
                invalid = !Number.isFinite(Number(value)) ||
                          Number(value) < 0;
            }
            if (invalid) {
                error.innerHTML = field.message;
                input.classList.add('error_msg');
                err++;
            } else {
                error.innerHTML = '';
                input.classList.remove('error_msg');
            }
        });
        const emailInput = document.getElementById('mail_id');
        const emailError = document.getElementById('officer_email_err');
        if (emailInput && emailInput.value.trim() !== '') {
            if (!emailInput.checkValidity()) {
                emailError.innerHTML = 'Please enter a valid Email Id...!';
                emailInput.classList.add('error_msg');
                err++;
            } else {
                emailError.innerHTML = '';
                emailInput.classList.remove('error_msg');
            }
        } else if (emailInput && emailError) {
            emailError.innerHTML = '';
            emailInput.classList.remove('error_msg');
        }
        if (err > 0) {
            return false;
        }
        submit_form();
        return true;
    }
    function submit_form() {
        const form = document.getElementById('countrySettingForm');
        const submitBtn = $(form).find('button[type="submit"]');
        if (!form || !submitBtn.length || submitBtn.prop('disabled')) {
            return;
        }
        submitBtn.prop('disabled', true);
        const formData = new FormData(form);
        $.ajax({
            url: "{{ route('depot-yard.store') }}",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.status === 200) {
                    if (response.message === 'Already Exist') {
                        toastr.warning('Project Site already exists.');
                        submitBtn.prop('disabled', false);
                        return;
                    }
                    toastr.success(response.message);
                    $('#add_warehouse_modal').modal('hide');
                    window.location.reload();
                } else {
                    toastr.error(response.message ||'Unable to save Warehouse Master.');
                    submitBtn.prop('disabled', false);
                }
            },
            error: function (xhr) {
                submitBtn.prop('disabled', false);
                if (xhr.status === 422) {
                    const errors = xhr.responseJSON?.errors;
                    if (errors) {
                        Object.keys(errors).forEach(function (key) {
                            const input = form.querySelector('[name="' + key + '"]');
                            const errorElement = document.getElementById(key + '_err');
                            if (input && errorElement) {
                                errorElement.innerHTML = errors[key][0];
                                input.classList.add('error_msg');
                            }
                        });
                    } else {
                        toastr.error(xhr.responseJSON?.message ||'Please check the required fields.');
                    }
                } else {
                    toastr.error('Something went wrong while saving Warehouse Master.');
                    console.error(xhr.responseJSON || xhr.responseText);
                }
            }
        });
    }
    $('#countrySettingForm').on('input change', 'input, textarea, select', function () {
        const errorId = this.id === 'addProjectSiteInput'? 'project_site_err': this.name + '_err';
        $('#' + errorId).text('');
        $(this).removeClass('error_msg');
    });
});
$(document).ready(function () {
    const editModal = $('#edit_warehouse_modal');
    const editForm = $('#countryeditSettingForm');
    const editFetchUrl = @json(route('depot-yard-editfetch', ['warehouse_id' => '__ID__']));
    const countriesUrl = '/store/states_by_country';
    const statesUrl = '/store/states_by_country/';
    const citiesUrl = '/store/city_by_state/';
    let editRequest = null;
    function resetDropdown(selector, placeholder) {
        $(selector).empty().append(
            $('<option>', {
                value: '',
                text: placeholder
            })
        );
    }
    function populateDropdown(url,selector,placeholder,selectedValue = '') {
        const dropdown = $(selector);
        resetDropdown(selector, placeholder);
        return $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json'
        }).then(function (response) {
            if (response.status !== 200 ||
                !Array.isArray(response.data)) {
                throw new Error(
                    response.message || 'Unable to load dropdown data.'
                );
            }
            response.data.forEach(function (item) {
                const value = item.sno;
                const text = item.country_name || item.state_name || item.city_name;
                dropdown.append($('<option>', {value: String(value),text: text}));
            });
            dropdown.val(selectedValue != null && selectedValue !== ''? String(selectedValue): '');
            return response;
        });
    }
    function loadCountries(selectedCountry = '') {
        return populateDropdown(countriesUrl,'#country_id_edit','Select a country',selectedCountry);
    }
    function loadStates(countryId, selectedState = '') {
        resetDropdown('#state_id_edit', 'Select a state');
        resetDropdown('#city_id_edit', 'Select a city');
        if (!countryId) {
            return $.Deferred().resolve().promise();
        }
        return populateDropdown(statesUrl + encodeURIComponent(countryId),'#state_id_edit','Select a state',selectedState);
    }
    function loadCities(stateId, selectedCity = '') {
        resetDropdown('#city_id_edit', 'Select a city');
        if (!stateId) {
            return $.Deferred().resolve().promise();
        }
        return populateDropdown(citiesUrl + encodeURIComponent(stateId),'#city_id_edit','Select a city',selectedCity);
    }
    editModal.on('show.bs.modal', function (event) {
        const trigger = event.relatedTarget;
        if (!trigger) {
            return;
        }
        const warehouseId = String(
            $(trigger).attr('data-warehouse-id') || ''
        ).trim();
        if (!warehouseId || warehouseId === '-' || warehouseId === 'undefined' || warehouseId === 'null') {
            event.preventDefault();
            toastr.error('Invalid warehouse ID.');
            console.error('Invalid warehouse ID:',warehouseId,trigger);
            return;
        }
        if (editRequest) {
            editRequest.abort();
        }
        editForm[0].reset();
        $('#edit_warehouse_id').val(warehouseId);
        resetDropdown('#country_id_edit', 'Select a country');
        resetDropdown('#state_id_edit', 'Select a state');
        resetDropdown('#city_id_edit', 'Select a city');
        editRequest = $.ajax({
            url: editFetchUrl.replace('__ID__',encodeURIComponent(warehouseId)),
            type: 'GET',
            dataType: 'json'
        });
        editRequest.done(function (response) {
            if (String(response.status) !== '200' || !response.data) {
                toastr.error(response.message || 'Unable to fetch warehouse.');
                return;
            }
            const data = response.data;
            $('#editProjectSiteInput').val(data.project_site ?? '');
            editForm.find('[name="head_office"]').val(data.head_office ?? '');
            editForm.find('[name="distance"]').val(data.distance ?? '');
            editForm.find('[name="address"]').val(data.address ?? '');
            $('#edit_zip_code').val(data.zip_code ?? '');
            editForm.find('[name="response_officer_name"]').val(data.response_officer_name ?? '');
            editForm.find('[name="contact_number"]').val(data.contact_number ?? '');
            editForm.find('[name="desigination"]').val(data.desigination ?? '');
            editForm.find('[name="mail_id"]').val(data.mail_id ?? '');
            loadCountries(data.country_id)
                .then(function () {
                    return loadStates(
                        data.country_id,
                        data.state_id
                    );
                })
                .then(function () {
                    return loadCities(data.state_id,data.city_id);
                })
                .catch(function (error) {
                    console.error('Dropdown loading failed:', error);
                    toastr.error(
                        'Unable to load country, state or city.'
                    );
                });
        });
        editRequest.fail(function (xhr, status) {
            if (status === 'abort') {
                return;
            }
            console.error('Warehouse fetch failed:',xhr.responseJSON || xhr.responseText);
            toastr.error(xhr.responseJSON?.message ||'Unable to fetch Warehouse Master.');
        });
    });
    $('#country_id_edit').on('change', function () {
        loadStates($(this).val());
    });
    $('#state_id_edit').on('change', function () {
        loadCities($(this).val());
    });
});
$(document).ready(function () {

    const form = $('#countryeditSettingForm');
    const fields = [
        {
            selector: '#editProjectSiteInput',
            error: '#edit_project_site_err',
            message: 'Project Site is required...!'
        },
        {
            selector: '#edit_warehouse_modal [name="head_office"]',
            error: '#edit_head_office_err',
            message: 'Head Office is required...!'
        },
        {
            selector: '#edit_warehouse_modal [name="distance"]',
            error: '#edit_distance_km_err',
            message: 'Distance is required...!'
        },
        {
            selector: '#edit_warehouse_modal [name="address"]',
            error: '#edit_address_err',
            message: 'Address is required...!'
        },
        {
            selector: '#country_id_edit',
            error: '#edit_country_id_edit_err',
            message: 'Please select a Country...!'
        },
        {
            selector: '#state_id_edit',
            error: '#edit_state_id_edit_err',
            message: 'Please select a State...!'
        },
        {
            selector: '#city_id_edit',
            error: '#edit_city_id_edit_err',
            message: 'Please select a City...!'
        },
        {
            selector: '#edit_zip_code',
            error: '#edit_zip_code_err',
            message: 'Zip Code is required...!'
        }
    ];

    function validateEditForm() {
        let errors = 0;
        fields.forEach(function (field) {
            const input = $(field.selector);
            const errorElement = $(field.error);
            const value = String(input.val() ?? '').trim();
            let invalid = value === '';
            if (field.selector.includes('distance') && value !== '') {
                invalid = !Number.isFinite(Number(value)) ||
                          Number(value) < 0;
            }
            if (invalid) {
                errorElement.text(field.message);
                input.addClass('error_msg');
                errors++;
            } else {
                errorElement.text('');
                input.removeClass('error_msg');
            }
        });
        const email = form.find('[name="mail_id"]');
        const emailValue = String(email.val() ?? '').trim();
        if (emailValue !== '' && !email[0].checkValidity()) {
            $('#edit_officer_email_err').text('Please enter a valid Email Id...!');
            email.addClass('error_msg');
            errors++;
        } else {
            $('#edit_officer_email_err').text('');
            email.removeClass('error_msg');
        }
        return errors === 0;
    }
    form.on('input change', 'input, textarea, select', function () {
        $(this).removeClass('error_msg');
        const errorMap = {
            editProjectSiteInput: '#edit_project_site_err',
            edit_zip_code: '#edit_zip_code_err'
        };

        if (errorMap[this.id]) {
            $(errorMap[this.id]).text('');
        } else {
            const name = $(this).attr('name');
            const mappedErrors = {
                head_office: '#edit_head_office_err',
                distance: '#edit_distance_km_err',
                address: '#edit_address_err',
                country_id: '#edit_country_id_edit_err',
                state_id: '#edit_state_id_edit_err',
                city_id: '#edit_city_id_edit_err',
                mail_id: '#edit_officer_email_err'
            };
            if (mappedErrors[name]) {
                $(mappedErrors[name]).text('');
            }
        }
    });
    form.on('submit', function (e) {
        e.preventDefault();
        if (!validateEditForm()) {
            return;
        }
        const warehouseId = $('#edit_warehouse_id').val();
        const submitBtn = form.find('button[type="submit"]');
        if (!warehouseId || submitBtn.prop('disabled')) {
            return;
        }
        submitBtn.prop('disabled', true);
        $.ajax({
            url: '/depot-yard/update/' + encodeURIComponent(warehouseId),
            type: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function (response) {
                if (response.status === 200) {
                    if (response.message === 'Already Exist') {
                        toastr.warning('Project Site already exists.');
                        return;
                    }
                    toastr.success(response.message ||'Warehouse Master updated successfully!');
                    const modalElement = document.getElementById('edit_warehouse_modal');
                    bootstrap.Modal.getOrCreateInstance(modalElement).hide();
                    if (typeof loadThemes === 'function') {
                        loadThemes(1);
                    } else {
                        window.location.reload();
                    }
                } else {
                    toastr.error(
                        response.message ||
                        'Unable to update Warehouse Master.'
                    );
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    const errors = xhr.responseJSON?.errors || {};
                    if (Object.keys(errors).length) {
                        Object.keys(errors).forEach(function (key) {
                            const input = form.find(
                                '[name="' + key + '"]'
                            );
                            const errorId = {
                                project_site: '#edit_project_site_err',
                                head_office: '#edit_head_office_err',
                                distance: '#edit_distance_km_err',
                                address: '#edit_address_err',
                                country_id: '#edit_country_id_edit_err',
                                state_id: '#edit_state_id_edit_err',
                                city_id: '#edit_city_id_edit_err',
                                zip_code: '#edit_zip_code_err',
                                mail_id: '#edit_officer_email_err'
                            }[key];
                            if (input.length) {
                                input.addClass('error_msg');
                            }
                            if (errorId) {
                                $(errorId).text(errors[key][0]);
                            }
                        });
                    } else {
                        toastr.error(xhr.responseJSON?.message ||'Please check the required fields.');
                    }
                } else {
                    toastr.error(xhr.responseJSON?.message ||'Something went wrong while updating Warehouse Master.');
                    console.error(xhr.responseJSON || xhr.responseText);
                }
            },
            complete: function () {
                submitBtn.prop('disabled', false);
            }
        });
    });
});
function updateWarehouseStatus(button) {
    const warehouseId = button.dataset.warehouseStatus;
    const currentStatus = String(button.dataset.currentStatus).toLowerCase();
    const isCurrentlyActive =currentStatus === '0' || currentStatus === 'active';
    const newStatus = isCurrentlyActive ? 1 : 0;
    button.disabled = true;
    fetch(`/depot-yard/status/${encodeURIComponent(warehouseId)}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            status: newStatus
        })
    })
    .then(async response => {
        const data = await response.json();
        if (!response.ok || Number(data.status) !== 200) {
            throw new Error(data.message || 'Unable to update status.');
        }
        const savedStatus = String(data.data.status).toLowerCase();
        const isActive =savedStatus === '0' || savedStatus === 'active';
        button.dataset.currentStatus = isActive ? '0' : '1';
        button.classList.toggle('bg-success-subtle', isActive);
        button.classList.toggle('text-success', isActive);
        button.classList.toggle('bg-secondary-subtle', !isActive);
        button.classList.toggle('text-secondary', !isActive);
        button.querySelector('.status-label').textContent =isActive ? 'ACTIVE' : 'INACTIVE';
        toastr.success(
            isActive
                ? 'Warehouse activated successfully!'
                : 'Warehouse deactivated successfully!'
        );
    })
    .catch(error => {
        toastr.error(error.message || 'Failed to update status.');
        console.error('Status update error:', error);
    })
    .finally(() => {
        button.disabled = false;
    });
}
</script>
@endsection
