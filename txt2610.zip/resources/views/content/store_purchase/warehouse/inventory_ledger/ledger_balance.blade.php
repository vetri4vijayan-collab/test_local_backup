@extends('layouts/layoutMaster')

@section('title', 'Inventory Ledger Balance')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>

@php
  $warehouseTabs = [
    ['key' => 'depot_yard','label' => 'Depot Yard Registry','route' => 'store-purchase.warehouse'],
    ['key' => 'inventory_ledger','label' => 'Inventory Ledger','route' => 'store-purchase.inventory-ledger'],
    ['key' => 'stock_transfer','label' => 'Stock Transfer','route' => 'store-purchase.stock-transfer'],
    [
        'key' => 'allocation_return',
        'label' => 'Allocations & Returns',
        'route' => 'store-purchase.material_allocation',
        'active_keys' => ['material_allocation', 'unused_material_return'], // top pill lights up for both
    ],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_allocation'    => 'material_allocation',
      'store-purchase.unused_material_return' => 'unused_material_return',
      'store-purchase.warehouse'              => 'depot_yard',
      'store-purchase.inventory-ledger'       => 'inventory_ledger',
      'store-purchase.stock-transfer'         => 'stock_transfer',
      default                                 => 'inventory_ledger',
  };
  // no override line here — let $activeTab stay whatever match() resolved it to
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller"> 
            @foreach ($warehouseTabs as $tab) 
                @if (isset($tab['children'])) 
                    @php 
                        $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                    @endphp 
                    <div class="settings-tab-dropdown"> 
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                            {{ $tab['label'] }} 
                            <span class="ms-1"> 
                                <i class="mdi mdi-chevron-down"></i> 
                            </span> 
                        </button> 
                        <div class="settings-tab-dropdown-menu"> 
                            @foreach ($tab['children'] as $child) 
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                {{ $child['label'] }} 
                            </a> 
                            @endforeach 
                        </div> 
                    </div> 
                    @else 
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                        {{ $tab['label'] }} 
                    </a> 
                @endif 
            @endforeach 
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>
  <div class="card pt-2 px-2 mb-4">
    {{-- Tabs + Search --}}
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
        <ul class="nav nav-pills gap-2" id="ledgerTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active d-flex align-items-center gap-2 px-3 py-2" id="ledger-tab"
                        data-bs-toggle="pill" data-bs-target="#ledger-pane" type="button" role="tab">
                    <i class="mdi mdi-box-seam"></i> Inventory Ledger Balance
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link d-flex align-items-center gap-2 px-3 py-2" id="batch-tab"
                        data-bs-toggle="pill" data-bs-target="#batch-pane" type="button" role="tab">
                    <i class="mdi mdi-clock-history"></i> Batch Codes &amp; Expiry Tracking
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link d-flex align-items-center gap-2 px-3 py-2" id="audit-tab"
                        data-bs-toggle="pill" data-bs-target="#audit-pane" type="button" role="tab">
                    <i class="mdi mdi-arrow-counterclockwise"></i> Transactions Audit Trail
                </button>
            </li>
        </ul>
        <div style="min-width: 260px;">
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0">
                    <i class="mdi mdi-magnify text-muted"></i>
                </span>
                <input type="text" id="materialSearch" class="form-control border-start-0 ps-0"
                        placeholder="Search items, codes...">
            </div>
        </div>
    </div>
  </div>
  @php
      // ---- STATIC DEMO DATA (remove once wired to real controller/model) ----
      $materials = [
          [
              'code' => 'MAT-CEM-OPC53',
              'name' => 'Cement OPC 53 Grade',
              'supplier' => 'UltraTech Cement',
              'unit' => 'Bags',
              'gross_stock' => 4500,
              'reserved_stock' => 500,
              'available_stock' => 4000,
              'ageing' => ['0-30' => 60, '31-90' => 30, '91+' => 10],
              'alert' => 'Adequate',
          ],
          [
              'code' => 'MAT-STL-TMT16',
              'name' => 'TMT Reinforcement Steel 16mm',
              'supplier' => 'Tata Tiscon',
              'unit' => 'MT',
              'gross_stock' => 120,
              'reserved_stock' => 25,
              'available_stock' => 95,
              'ageing' => ['0-30' => 60, '31-90' => 30, '91+' => 10],
              'alert' => 'Adequate',
          ],
          [
              'code' => 'MAT-AGG-20MM',
              'name' => 'Coarse Aggregates 20mm',
              'supplier' => 'Titan Aggregates',
              'unit' => 'CU.M',
              'gross_stock' => 1500,
              'reserved_stock' => 500,
              'available_stock' => 1000,
              'ageing' => ['0-30' => 60, '31-90' => 30, '91+' => 10],
              'alert' => 'Adequate',
          ],
          [
              'code' => 'MAT biT biT60',
              'name' => 'Paving bitumen 60/70',
              'supplier' => 'IOCL bitumen',
              'unit' => 'Drums',
              'gross_stock' => 35,
              'reserved_stock' => 0,
              'available_stock' => 35,
              'ageing' => ['0-30' => 60, '31-90' => 30, '91+' => 10],
              'alert' => 'Low Stock Outbreak',
          ],
          [
              'code' => 'MAT-PIP-PVC4IN',
              'name' => 'PVC Plumbing Pipe 4" (6m)',
              'supplier' => 'Supreme Pipes',
              'unit' => 'PCS',
              'gross_stock' => 850,
              'reserved_stock' => 25,
              'available_stock' => 825,
              'ageing' => ['0-30' => 60, '31-90' => 30, '91+' => 10],
              'alert' => 'Adequate',
          ],
      ];

      $alertBadgeClass = fn($alert) => $alert === 'Adequate'
          ? 'bg-success-subtle text-success border border-success-subtle'
          : 'bg-danger-subtle text-danger border border-danger-subtle';
  @endphp
  <div class="tab-content p-0" id="ledgerTabsContent">
    {{-- ================= LEDGER TAB ================= --}}
    <div class="tab-pane fade show active" id="ledger-pane" role="tabpanel">
        <div class="card mb-4 settings-card">
            <div class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
                        <i class="mdi mdi-clipboard-list-outline text-primary"></i> Inventory Stock Allocation Ledger
                    </h6>
                    <small class="text-muted">Live stock allocations showing Reserved for active requisitions vs Available balance</small>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                        <tr>
                            <th class="min-w-100px text-black">Material Details</th>
                            <th class="min-w-100px text-black text-end">Gross Stock</th>
                            <th class="min-w-100px text-black text-end">Reserved Stock</th>
                            <th class="min-w-100px text-black text-end">Available Stock</th>
                            <th class="min-w-100px text-black" style="min-width: 220px;">Material Ageing Profile (Days)</th>
                            <th class="min-w-100px text-black text-end">Alert Level Status</th>
                        </tr>
                    </thead>
                    <tbody class="fs-8 fw-semibold">
                        @foreach($materials as $item)
                            <tr class="material-row" data-search="{{ strtolower($item['name'].' '.$item['code'].' '.$item['supplier']) }}">
                                {{-- Material details --}}
                                <td>
                                    <span class="badge bg-light text-secondary border font-monospace mb-1">
                                        {{ $item['code'] }}
                                    </span>
                                    <div class="fw-semibold">{{ $item['name'] }}</div>
                                    <div class="text-muted small">{{ $item['supplier'] }} &middot; {{ $item['unit'] }}</div>
                                </td>

                                {{-- Gross --}}
                                <td class="text-end fw-semibold">{{ number_format($item['gross_stock']) }}</td>

                                {{-- Reserved --}}
                                <td class="text-end fw-semibold text-primary">{{ number_format($item['reserved_stock']) }}</td>

                                {{-- Available --}}
                                <td class="text-end fw-semibold text-success">{{ number_format($item['available_stock']) }}</td>

                                {{-- Ageing profile --}}
                                <td>
                                    <div class="progress" style="height: 8px; border-radius: 6px;">
                                        <div class="progress-bar bg-success" style="width: {{ $item['ageing']['0-30'] }}%"></div>
                                        <div class="progress-bar bg-warning" style="width: {{ $item['ageing']['31-90'] }}%"></div>
                                        <div class="progress-bar bg-danger" style="width: {{ $item['ageing']['91+'] }}%"></div>
                                    </div>
                                    <div class="d-flex justify-content-between text-muted mt-1">
                                        <span>0-30d: {{ $item['ageing']['0-30'] }}%</span>
                                        <span>31-90d: {{ $item['ageing']['31-90'] }}%</span>
                                        <span>91d+: {{ $item['ageing']['91+'] }}%</span>
                                    </div>
                                </td>

                                {{-- Alert badge --}}
                                <td class="text-end">
                                    @if($item['alert'] === 'Adequate')
                                        <span class="badge bg-label-success">{{ $item['alert'] }}</span>
                                    @else
                                        <span class="badge bg-label-danger">{{ $item['alert'] }}</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{-- ================= BATCH CODES TAB ================= --}}
    <div class="tab-pane fade" id="batch-pane" role="tabpanel">
        @php
            // ---- STATIC DEMO DATA ----
            $batches = [
                [
                    'name' => 'Cement OPC 53 Grade',
                    'supplier' => 'UltraTech Cement',
                    'batch_no' => 'BCH-2026-032',
                    'serial_log' => 'SR-0-889',
                    'expiry' => '2026-11-15',
                    'quality' => 'QC Certified Passed',
                ],
                [
                    'name' => 'TMT Reinforcement Steel 16mm',
                    'supplier' => 'Tata Tiscon',
                    'batch_no' => 'BCH-2026-033',
                    'serial_log' => 'SR-22-889',
                    'expiry' => null,
                    'quality' => 'QC Certified Passed',
                ],
                [
                    'name' => 'Coarse Aggregates 20mm',
                    'supplier' => 'Titan Aggregates',
                    'batch_no' => 'BCH-2026-034',
                    'serial_log' => 'SR-44-889',
                    'expiry' => null,
                    'quality' => 'QC Certified Passed',
                ],
                [
                    'name' => 'Paving Bitumen 60/70',
                    'supplier' => 'IOCL Bitumen',
                    'batch_no' => 'BCH-2026-035',
                    'serial_log' => 'SR-66-889',
                    'expiry' => '2026-11-15',
                    'quality' => 'QC Certified Passed',
                ],
                [
                    'name' => 'PVC Plumbing Pipe 4" (6m)',
                    'supplier' => 'Supreme Pipes',
                    'batch_no' => 'BCH-2026-036',
                    'serial_log' => 'SR-88-889',
                    'expiry' => null,
                    'quality' => 'QC Certified Passed',
                ],
            ];

            $qualityBadgeClass = fn($status) => $status === 'QC Certified Passed'
                ? 'bg-label-success'
                : 'bg-label-danger';
        @endphp

        <div class="card mb-4 settings-card">
            <div class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
                        <i class="mdi mdi-clock-history text-primary"></i> Quality Batch &amp; Expiry Tracker
                    </h6>
                    <small class="text-muted">Tracking concrete batches, reinforcement logs, and perishable chemical expirations</small>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                        <tr>
                            <th class="min-w-100px text-black">Material Details</th>
                            <th class="min-w-100px text-black">Batch Number</th>
                            <th class="min-w-100px text-black">Serial / Manufacturer Log</th>
                            <th class="min-w-100px text-black">Expiry Date</th>
                            <th class="min-w-100px text-black text-end">Quality Status</th>
                        </tr>
                    </thead>
                    <tbody class="fs-8 fw-semibold">
                        @foreach($batches as $batch)
                            <tr class="batch-row" data-search="{{ strtolower($batch['name'].' '.$batch['batch_no'].' '.$batch['supplier']) }}">
                                {{-- Material details --}}
                                <td>
                                    <div class="fw-semibold">{{ $batch['name'] }}</div>
                                    <div class="text-muted small">{{ $batch['supplier'] }}</div>
                                </td>

                                {{-- Batch number --}}
                                <td>
                                    <a href="#" class="text-primary fw-semibold text-decoration-none">{{ $batch['batch_no'] }}</a>
                                </td>

                                {{-- Serial / manufacturer log --}}
                                <td class="text-muted">{{ $batch['serial_log'] }}</td>

                                {{-- Expiry date --}}
                                <td>
                                    @if($batch['expiry'])
                                        <span class="text-warning fw-semibold">{{ $batch['expiry'] }}</span>
                                    @else
                                        <span class="text-muted">No Perishable Expiry</span>
                                    @endif
                                </td>

                                {{-- Quality status --}}
                                <td class="text-end">
                                    <span class="badge {{ $qualityBadgeClass($batch['quality']) }}">{{ $batch['quality'] }}</span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- ================= AUDIT TRAIL TAB ================= --}}
    <div class="tab-pane fade" id="audit-pane" role="tabpanel">
        @php
            // ---- STATIC DEMO DATA ----
            $auditLogs = [
                [
                    'datetime' => '2026-07-01',
                    'depot' => 'Chennai Yard',
                    'type' => 'Purchase',
                    'material' => 'Cement OPC 53 Grade',
                    'qty' => '+5,000',
                    'closing_balance' => '5,000',
                    'ref' => 'OB-2026',
                    'user' => 'System',
                ],
                [
                    'datetime' => '2026-07-20',
                    'depot' => 'Chennai Yard',
                    'type' => 'Consumption',
                    'material' => 'Cement OPC 53 Grade',
                    'qty' => '-1,200',
                    'closing_balance' => '3,800',
                    'ref' => 'ALC-001',
                    'user' => 'Vignesh Kumar',
                ],
                [
                    'datetime' => '2026-07-22',
                    'depot' => 'Chennai Yard',
                    'type' => 'Transfer',
                    'material' => 'Cement OPC 53 Grade',
                    'qty' => '-500',
                    'closing_balance' => '3,300',
                    'ref' => 'XFR-001',
                    'user' => 'Vignesh Kumar',
                ],
                [
                    'datetime' => '2026-07-23',
                    'depot' => 'Villupuram Yard',
                    'type' => 'Transfer',
                    'material' => 'Cement OPC 53 Grade',
                    'qty' => '+500',
                    'closing_balance' => '500',
                    'ref' => 'XFR-001',
                    'user' => 'K. Subramaniam',
                ],
                [
                    'datetime' => '2026-07-25',
                    'depot' => 'Villupuram Yard',
                    'type' => 'Purchase',
                    'material' => 'Paving Bitumen 60/70',
                    'qty' => '+48',
                    'closing_balance' => '48',
                    'ref' => 'GRN-2026-001',
                    'user' => 'K. Subramaniam',
                ],
            ];

            $txnTypeBadgeClass = fn($type) => match($type) {
                'Purchase' => 'bg-label-success',
                'Consumption' => 'bg-label-danger',
                'Transfer' => 'bg-label-warning',
                default => 'bg-label-secondary',
            };
        @endphp

        <div class="card mb-4 settings-card">
            <div class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
                        <i class="mdi mdi-arrow-counterclockwise text-primary"></i> Stock Transactions &amp; Audit Logs
                    </h6>
                    <small class="text-muted">Every single stock dispatch, receipt, consumption, or transfer tracked with driver and vehicle indices</small>
                </div>
                <span class="badge bg-label-primary">{{ count($auditLogs) }} Log Entries</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                        <tr>
                            <th class="min-w-100px text-black">Log Date &amp; Time</th>
                            <th class="min-w-100px text-black">Warehouse Depot</th>
                            <th class="min-w-100px text-black">Transaction Type</th>
                            <th class="min-w-100px text-black">Material Details</th>
                            <th class="min-w-100px text-black text-end">Qty Log</th>
                            <th class="min-w-100px text-black text-end">Closing Balance</th>
                            <th class="min-w-100px text-black">Action Source (Ref)</th>
                            <th class="min-w-100px text-black">Authorized User</th>
                        </tr>
                    </thead>
                    <tbody class="fs-8 fw-semibold">
                        @foreach($auditLogs as $log)
                            <tr class="audit-row" data-search="{{ strtolower($log['material'].' '.$log['depot'].' '.$log['ref'].' '.$log['user']) }}">
                                {{-- Log date & time --}}
                                <td class="text-muted">{{ $log['datetime'] }}</td>

                                {{-- Warehouse depot --}}
                                <td class="fw-semibold">{{ $log['depot'] }}</td>

                                {{-- Transaction type --}}
                                <td>
                                    <span class="badge {{ $txnTypeBadgeClass($log['type']) }}">{{ $log['type'] }}</span>
                                </td>

                                {{-- Material details --}}
                                <td class="fw-semibold">{{ $log['material'] }}</td>

                                {{-- Qty log --}}
                                <td class="text-end fw-semibold {{ str_starts_with($log['qty'], '+') ? 'text-success' : 'text-danger' }}">
                                    {{ $log['qty'] }}
                                </td>

                                {{-- Closing balance --}}
                                <td class="text-end fw-semibold">{{ $log['closing_balance'] }}</td>

                                {{-- Action source ref --}}
                                <td>
                                    <a href="#" class="text-primary fw-semibold text-decoration-none">{{ $log['ref'] }}</a>
                                </td>

                                {{-- Authorized user --}}
                                <td>{{ $log['user'] }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

{{-- Client-side search across the ledger rows --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('materialSearch');
    const rows = document.querySelectorAll('.material-row');

    searchInput.addEventListener('input', function () {
        const term = this.value.trim().toLowerCase();
        rows.forEach(function (row) {
            row.style.display = !term || row.dataset.search.includes(term) ? '' : 'none';
        });
    });
});
</script>

<style>
    #ledgerTabs .nav-link {
        background: #fff;
        border: 1px solid #e5e7eb;
        color: #475569;
        font-weight: 600;
        font-size: .75rem;
        border-radius: 10px;
    }
    #ledgerTabs .nav-link.active {
        background: #16659E;
        color: #fff;
        border-color: #16659E;
    }
</style>

@endsection