@extends('layouts/layoutMaster')

@section('title', 'Project Material Allocation')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
<style>
    .alc-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }
    .alc-toolbar-left {
        display: flex;
        gap: 0.6rem;
    }
    .btn-alc-active {
        background-color: #16659E;
        border-color: transparent;
        color: #fff;
        font-size: 0.82rem;
        font-weight: 600;
        border-radius: 8px;
    }
    .btn-alc-active:hover {
        background-color: #10233f;
        border-color: transparent;
        color: #fff;
    }
    .btn-alc-outline {
        background-color: #fff;
        border: 1px solid #e1e4eb;
        color: #4a5163;
        font-size: 0.82rem;
        font-weight: 600;
        border-radius: 8px;
    }
    .btn-alc-outline:hover {
        background-color: #f8f9fc;
        color: #2b3245;
    }
    .btn-alc-primary {
        background-color: #16659E;
        border-color: transparent;
        font-size: 0.82rem;
        font-weight: 600;
        border-radius: 8px;
    }
    .btn-alc-primary:hover {
        background-color: #10233f;
        border-color: transparent;
    }
    .alc-card {
        border-radius: 12px;
        border: 1px solid #eef0f4;
    }
    .alc-code {
        background: #eef2f8;
        color: #3a4a63;
        font-size: 0.72rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 6px;
    }
    .alc-badge {
        font-size: 0.68rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 6px;
    }
    .alc-yard {
        font-size: 0.72rem;
        color: #9096a3;
    }
    .alc-yard span {
        color: #4a5163;
        font-weight: 600;
    }
    .alc-item-title {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1e2432;
    }
    .alc-project {
        font-size: 0.8rem;
        color: #4a5163;
        display: flex;
        align-items: center;
        gap: 6px;
        margin-bottom: 0.75rem;
    }
    .alc-project i {
        color: #9096a3;
    }
    .alc-details-box {
        background: #f8f9fc;
        border: 1px solid #eef0f4;
        border-radius: 10px;
        padding: 0.85rem 1rem;
    }
    .alc-details-box .label {
        font-size: 0.65rem;
        letter-spacing: 0.03em;
        color: #9096a3;
        font-weight: 600;
        text-transform: uppercase;
    }
    .alc-details-box .value {
        font-size: 0.82rem;
        color: #2b3245;
        font-weight: 600;
    }
    .alc-side-receiver {
        font-size: 0.8rem;
        font-weight: 700;
        color: #1e2432;
        white-space: nowrap;
    }
    .alc-side-date {
        font-size: 0.7rem;
        color: #9096a3;
        white-space: nowrap;
    }
</style>

@php
  $warehouseTabs = [
    ['key' => 'depot_yard','label' => 'Depot Yard Registry','route' => 'store-purchase.warehouse'],
    ['key' => 'inventory_ledger','label' => 'Inventory Ledger','route' => 'store-purchase.inventory-ledger'],
    ['key' => 'stock_transfer','label' => 'Stock Transfer','route' => 'store-purchase.stock-transfer'],
    [
        'key' => 'allocation_return',
        'label' => 'Allocations & Returns',
        'route' => 'store-purchase.material_allocation',
        'active_keys' => ['material_allocation', 'unused_material_return'], // top pill lights up for both
    ],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_allocation'    => 'material_allocation',
      'store-purchase.unused_material_return' => 'unused_material_return',
      'store-purchase.warehouse'              => 'depot_yard',
      'store-purchase.inventory-ledger'       => 'inventory_ledger',
      'store-purchase.stock-transfer'         => 'stock_transfer',
      default                                 => 'allocation_return',
  };
  // no override line here — let $activeTab stay whatever match() resolved it to
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
        <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
            <i class="mdi mdi-chevron-left"></i>
        </button>

        <div class="settings-tabs-scroller">
            <div class="settings-tabs-track" id="warehouseTabScroller">
                @foreach ($warehouseTabs as $tab)
                    @php
                        $isActive = isset($tab['active_keys'])
                            ? in_array($activeTab, $tab['active_keys'])
                            : $activeTab === $tab['key'];
                    @endphp
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}"
                    class="settings-tab-pill {{ $isActive ? 'active' : '' }}">
                        {{ $tab['label'] }}
                    </a>
                @endforeach
            </div>
        </div>

        <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
            <i class="mdi mdi-chevron-right"></i>
        </button>
    </div>

  </div>
</div>
@php
    // Static data — in a real app pass this from the controller as $allocations
    $allocations = $allocations ?? [
        [
            'code' => 'ALC-001',
            'status' => 'Allocated', // Allocated | Partially Returned
            'yard_source' => 'Chennai',
            'item' => 'CEMENT OPC 53 GRADE',
            'qty' => '1200',
            'unit' => 'BAGS',
            'project' => 'Chennai Metro Phase 2 - Corridor 4',
            'issued_qty' => '1200 Bags',
            'outstanding' => '1200 Bags',
            'issued_by' => 'Vignesh Kumar',
            'receiver' => 'Sri Sai Concrete Gang',
            'date' => '2026-07-20',
        ],
        [
            'code' => 'ALC-002',
            'status' => 'Partially Returned',
            'yard_source' => 'Villupuram',
            'item' => 'PAVING BITUMEN 60/70',
            'qty' => '40',
            'unit' => 'DRUMS',
            'project' => 'East Coast Road Elevated Bridge',
            'issued_qty' => '40 Drums',
            'outstanding' => '32 Drums',
            'issued_by' => 'K. Subramaniam',
            'receiver' => 'ECR Bituminous Paving Crew',
            'date' => '2026-07-26',
        ],
    ];
@endphp

{{-- Toolbar --}}
<div class="card p-2 d-flex align-items-center justify-content-between flex-row mb-4">
    <div class="alc-toolbar-left">
        <a href="{{ route('store-purchase.material_allocation') }}"
           class="{{ $activeTab === 'material_allocation' ? 'btn-alc-active' : 'btn-alc-outline' }} px-3 py-2">
            <i class="mdi mdi-layers-triple-outline me-1"></i> Project Material Allocations
        </a>
        <a href="{{ route('store-purchase.unused_material_return') }}"
           class="{{ $activeTab === 'unused_material_return' ? 'btn-alc-active' : 'btn-alc-outline' }} px-3 py-2">
            <i class="mdi mdi-arrow-left-bottom me-1"></i> Unused Material Returns
        </a>
    </div>
    <div>
        <button type="button" class="btn-alc-primary text-white px-3 py-2" data-bs-toggle="modal" data-bs-target="#allocate_inventory">
            <i class="mdi mdi-plus me-1"></i> Allocate Inventory
        </button>
    </div>
</div>

{{-- Allocation Cards --}}
@foreach ($allocations as $allocation)
    <div class="card alc-card mb-3 shadow-sm border-0">
        <div class="card-body p-4">
            <div class="row align-items-center">

                {{-- Left / main content --}}
                <div class="col-12 col-md-9">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span class="alc-code">{{ $allocation['code'] }}</span>

                        @if ($allocation['status'] === 'Allocated')
                            <span class="badge bg-label-primary">Allocated</span>
                        @else
                            <span class="badge bg-label-info">Partially Returned</span>
                        @endif

                        <span class="alc-yard">YARD source: <span>{{ $allocation['yard_source'] }}</span></span>
                    </div>

                    <div class="alc-item-title mb-1">
                        {{ $allocation['item'] }} — <span class="text-primary">{{ $allocation['qty'] }} {{ $allocation['unit'] }} ISSUED</span>
                    </div>

                    <div class="alc-project">
                        <i class="mdi mdi-map-marker-radius-outline"></i> Allocated Project: {{ $allocation['project'] }}
                    </div>

                    <div class="alc-details-box">
                        <div class="row">
                            <div class="col-4">
                                <div class="label">Issued Quantity</div>
                                <div class="value">{{ $allocation['issued_qty'] }}</div>
                            </div>
                            <div class="col-4">
                                <div class="label">Outstanding Balance</div>
                                <div class="text-primary">{{ $allocation['outstanding'] }}</div>
                            </div>
                            <div class="col-4">
                                <div class="label">Issued By</div>
                                <div class="value">{{ $allocation['issued_by'] }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Right / status side --}}
                <div class="col-12 col-md-3 text-md-end text-start mt-3 mt-md-0">
                    <div class="alc-side-receiver mb-1">Receiver: {{ $allocation['receiver'] }}</div>
                    <div class="alc-side-date">Date: {{ $allocation['date'] }}</div>
                </div>

            </div>
        </div>
    </div>
@endforeach

{{-- Add / Edit Allocate Inventory Modal --}}
<div class="modal fade" id="allocate_inventory" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Allocate Inventory to Construction Project</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="countrySettingForm" action="#" method="POST">
                @csrf
                <input type="hidden" id="country_id" name="country_id" value="">

                <div class="modal-body text-start">
                    <div class="row g-2 mb-3">
                        <div class="col-lg-6">
                            <label for="warehouse_id" class="form-label fw-semibold">Target Project Site<span
                                    class="text-danger">*</span></label>
                            <select id="warehouse_id" name="warehouse_id" class="form-select select3" required>
                                <option value="" disabled selected>Select Project Site</option>
                                <option value="1">Chennai Metro Phase 2 - Corridor</option>
                                <option value="2">Adiyar Premium Residences</option>
                                <option value="3">East Coast Road</option>
                                <option value="4">SIPCOT Industrial Park</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="destination_warehouse_id" class="form-label fw-semibold">Source Dispatching Warehouse<span
                                    class="text-danger">*</span></label>
                            <select id="destination_warehouse_id" name="destination_warehouse_id" class="form-select select3" required>
                                <option value="" disabled selected>Select Dispatching Warehouse</option>
                                <option value="1">Chennai Central Logistics Yard</option>
                                <option value="2">Villupuram Highway Depot</option>
                                <option value="3">Salem Steel Plant Yard</option>
                                <option value="4">Madurai Southern Storage</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="material_master_id" class="form-label fw-semibold">Select Material Master <span
                                    class="text-danger">*</span></label>
                            <select id="material_master_id" name="material_master_id" class="form-select select3" required>
                                <option value="" disabled selected>Select Material Master</option>
                                <option value="1">Cement OPC 53 Grade Bags</option>
                                <option value="2">Coarse Aggregates 20mm (Cu.m)</option>
                                <option value="3">PVC Plumbing Pipe 4" (6m) (PCs)</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="transfer_qty" class="form-label fw-semibold">Quantity Issued</label>
                             <input type="text" id="transfer_qty" name="transfer_qty" value="" class="form-control" placeholder="Enter Quantity Issued">
                        </div>
                        <div class="col-lg-12">
                            <label for="driver_name" class="form-label fw-semibold">Site Contractor / Receiver Name</label>
                            <select id="driver_name" name="driver_name" class="form-select select3" required>
                                <option value="" disabled selected>Select Site Contractor / Receiver</option>
                                <option value="1">Murugan S</option>
                                <option value="2">Kathiresan</option>
                                <option value="3">Palani</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary">Cancel</button>
                    <button type="" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Authorize Material Allocation</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>
@endsection