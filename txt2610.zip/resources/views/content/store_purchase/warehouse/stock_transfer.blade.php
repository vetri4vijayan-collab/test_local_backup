@extends('layouts/layoutMaster')

@section('title', 'Stock Transfer')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<style>
    .xfr-header-card {
        border-radius: 12px;
        border: 1px solid #eef0f4;
    }
    .xfr-header-card .title {
        font-weight: 700;
        font-size: 0.95rem;
        color: #1e2432;
    }
    .xfr-header-card .subtitle {
        font-size: 0.78rem;
        color: #8a90a0;
    }
    .btn-xfr-primary {
        background-color: #16659E;
        border-color: #16659E;
        font-size: 0.82rem;
        font-weight: 600;
        border-radius: 8px;
    }
    .btn-xfr-primary:hover {
        background-color: #135381;
        border-color: #135381;
    }
    .xfr-card {
        border-radius: 12px;
        border: 1px solid #eef0f4;
    }
    .xfr-code {
        background: #eef2f8;
        color: #3a4a63;
        font-size: 0.72rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 6px;
    }
    .xfr-badge {
        font-size: 0.68rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 6px;
    }
    .xfr-badge-received {
        background-color: #e3f7ea;
        color: #1e9e56;
    }
    .xfr-badge-transit {
        background-color: #fdf2df;
        color: #d99a2b;
    }
    .xfr-approved {
        font-size: 0.72rem;
        color: #9096a3;
    }
    .xfr-approved span {
        color: #4a5163;
        font-weight: 600;
    }
    .xfr-item-title {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1e2432;
    }
    .xfr-route {
        font-size: 0.8rem;
        color: #4a5163;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .xfr-route .pin-to {
        color: #1e9e56;
    }
    .xfr-details-box {
        background: #f8f9fc;
        border: 1px solid #eef0f4;
        border-radius: 10px;
        padding: 0.85rem 1rem;
    }
    .xfr-details-box .label {
        font-size: 0.65rem;
        letter-spacing: 0.03em;
        color: #9096a3;
        font-weight: 600;
        text-transform: uppercase;
    }
    .xfr-details-box .value {
        font-size: 0.82rem;
        color: #2b3245;
        font-weight: 600;
    }
    .xfr-side-status {
        font-size: 0.8rem;
        font-weight: 700;
        color: #1e9e56;
        white-space: nowrap;
    }
    .xfr-side-date {
        font-size: 0.7rem;
        color: #9096a3;
        white-space: nowrap;
    }
    .btn-xfr-receive {
        background-color: #1e9e56;
        border-color: #1e9e56;
        font-size: 0.8rem;
        font-weight: 600;
        border-radius: 8px;
        white-space: nowrap;
    }
    .btn-xfr-receive:hover {
        background-color: #187e44;
        border-color: #187e44;
    }
</style>
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>
@php
  $warehouseTabs = [
    ['key' => 'depot_yard','label' => 'Depot Yard Registry','route' => 'store-purchase.warehouse'],
    ['key' => 'inventory_ledger','label' => 'Inventory Ledger','route' => 'store-purchase.inventory-ledger'],
    ['key' => 'stock_transfer','label' => 'Stock Transfer','route' => 'store-purchase.stock-transfer'],
    [
        'key' => 'allocation_return',
        'label' => 'Allocations & Returns',
        'route' => 'store-purchase.material_allocation',
        'active_keys' => ['material_allocation', 'unused_material_return'], // top pill lights up for both
    ],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_allocation'    => 'material_allocation',
      'store-purchase.unused_material_return' => 'unused_material_return',
      'store-purchase.warehouse'              => 'depot_yard',
      'store-purchase.inventory-ledger'       => 'inventory_ledger',
      'store-purchase.stock-transfer'         => 'stock_transfer',
      default                                 => 'stock_transfer',
  };
  // no override line here — let $activeTab stay whatever match() resolved it to
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>
    <div class="d-flex align-items-center justify-content-end gap-2">
        <button type="button" class="btn btn-xfr-primary text-white px-3 py-2" data-bs-toggle="modal" data-bs-target="#formulate_stock_transfer_modal">
            <i class="mdi mdi-plus"></i> Formulate Stock Transfer
        </button>
        <div class="settings-tabs-wrapper d-flex align-items-center">
        <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
            <i class="mdi mdi-chevron-left"></i>
        </button>

        <div class="settings-tabs-scroller">
            <div class="settings-tabs-track" id="warehouseTabScroller"> 
                @foreach ($warehouseTabs as $tab) 
                    @if (isset($tab['children'])) 
                        @php 
                            $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                        @endphp 
                        <div class="settings-tab-dropdown"> 
                            <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                                {{ $tab['label'] }} 
                                <span class="ms-1"> 
                                    <i class="mdi mdi-chevron-down"></i> 
                                </span> 
                            </button> 
                            <div class="settings-tab-dropdown-menu"> 
                                @foreach ($tab['children'] as $child) 
                                <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                    {{ $child['label'] }} 
                                </a> 
                                @endforeach 
                            </div> 
                        </div> 
                        @else 
                        <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                            {{ $tab['label'] }} 
                        </a> 
                    @endif 
                @endforeach 
            </div>
        </div>

        <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
            <i class="mdi mdi-chevron-right"></i>
        </button>
        </div>
    </div>
  </div>
</div>
@php
    // Static data — in a real app pass this from the controller as $transfers
    $transfers = $transfers ?? [
        [
            'code' => 'XFR-001',
            'status' => 'Received', // Received | In-Transit
            'approved_by' => 'Murugan Thangaraj',
            'item' => 'CEMENT OPC 53 GRADE',
            'qty' => '500',
            'unit' => 'BAGS',
            'from' => 'Chennai',
            'to' => 'Villupuram',
            'vehicle' => 'TN-01-AX-9912',
            'driver' => 'M. Sundaram',
            'dispatched' => '2026-07-22',
            'eta' => '2026-07-23',
            'trans_date' => '2026-07-22',
            'unloaded_at' => '2026-07-23',
        ],
        [
            'code' => 'XFR-002',
            'status' => 'In-Transit',
            'approved_by' => 'Murugan Thangaraj',
            'item' => 'TMT REINFORCEMENT STEEL 16MM',
            'qty' => '15',
            'unit' => 'MT',
            'from' => 'Chennai',
            'to' => 'Madurai',
            'vehicle' => 'TN-09-C-4412',
            'driver' => 'R. Loganathan',
            'dispatched' => '2026-07-26',
            'eta' => '2026-07-28',
            'trans_date' => '2026-07-26',
            'unloaded_at' => null,
        ],
    ];
@endphp

{{-- Transfer Cards --}}
@foreach ($transfers as $transfer)
    <div class="card mb-3 shadow-sm border-0">
        <div class="card-body p-4">
            <div class="row align-items-center">
                {{-- Left / main content --}}
                <div class="col-12 col-md-9">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span class="xfr-code">{{ $transfer['code'] }}</span>

                        @if ($transfer['status'] === 'Received')
                            <span class="xfr-badge xfr-badge-received">Received</span>
                        @else
                            <span class="xfr-badge xfr-badge-transit">In-Transit</span>
                        @endif

                        <span class="xfr-approved">Approved by: <span>{{ $transfer['approved_by'] }}</span></span>
                    </div>

                    <div class="xfr-item-title mb-1">
                        {{ $transfer['item'] }} — <span class="text-primary">{{ $transfer['qty'] }} {{ $transfer['unit'] }}</span>
                    </div>

                    <div class="xfr-route mb-3">
                        <span class="text-primary"><i class="mdi mdi-map-marker-radius-outline"></i></span> {{ $transfer['from'] }}
                        <span class="mx-1">&rarr;</span>
                        <span class="pin-to"><i class="mdi mdi-map-marker-radius-outline"></i></span> {{ $transfer['to'] }}
                    </div>

                    <div class="xfr-details-box">
                        <div class="row">
                            <div class="col-3">
                                <div class="label">Transit Vehicle</div>
                                <div class="value">{{ $transfer['vehicle'] }}</div>
                            </div>
                            <div class="col-3">
                                <div class="label">Driver Operator</div>
                                <div class="value">{{ $transfer['driver'] }}</div>
                            </div>
                            <div class="col-3">
                                <div class="label">Dispatched</div>
                                <div class="value">{{ $transfer['dispatched'] }}</div>
                            </div>
                            <div class="col-3">
                                <div class="label">ETA Arrival</div>
                                <div class="value">{{ $transfer['eta'] }}</div>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- Right / status side --}}
                <div class="col-12 col-md-3 text-md-end text-start mt-3 mt-md-0">
                    @if ($transfer['status'] === 'Received')
                        <div class="xfr-side-status mb-1">
                            <i class="mdi mdi-check-circle-fill me-1"></i> Unloaded at {{ $transfer['unloaded_at'] }}
                        </div>
                        <div class="xfr-side-date">Trans Date: {{ $transfer['trans_date'] }}</div>
                    @else
                        <button type="button" class="btn btn-xfr-receive text-white px-3 py-2 mb-1">
                            Receive Stock Transfer
                        </button>
                        <div class="xfr-side-date">Trans Date: {{ $transfer['trans_date'] }}</div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endforeach

{{-- Add / Edit Formulate Stock Transfer Modal --}}
<div class="modal fade" id="formulate_stock_transfer_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Formulate Stock Transfer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="countrySettingForm" action="#" method="POST">
                @csrf
                <input type="hidden" id="country_id" name="country_id" value="">

                <div class="modal-body text-start">
                    <div class="row g-2 mb-3">
                        <div class="col-lg-6">
                            <label for="warehouse_id" class="form-label fw-semibold">Source Dispatching Warehouse <span
                                    class="text-danger">*</span></label>
                            <select id="warehouse_id" name="warehouse_id" class="form-select select3" required>
                                <option value="" disabled selected>Select warehouse</option>
                                <option value="1">Chennai Central Logistics Yard</option>
                                <option value="2">Villupuram Highway Depot</option>
                                <option value="3">Salem Steel Plant Yard</option>
                                <option value="4">Madurai Southern Storage</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="destination_warehouse_id" class="form-label fw-semibold">Destination Receiving Warehouse <span
                                    class="text-danger">*</span></label>
                            <select id="destination_warehouse_id" name="destination_warehouse_id" class="form-select select3" required>
                                <option value="" disabled selected>Select Destination Warehouse</option>
                                <option value="1">Chennai Central Logistics Yard</option>
                                <option value="2">Villupuram Highway Depot</option>
                                <option value="3">Salem Steel Plant Yard</option>
                                <option value="4">Madurai Southern Storage</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="material_master_id" class="form-label fw-semibold">Select Material Master <span
                                    class="text-danger">*</span></label>
                            <select id="material_master_id" name="material_master_id" class="form-select select3" required>
                                <option value="" disabled selected>Select Material Master</option>
                                <option value="1">Cement OPC 53 Grade Bags</option>
                                <option value="2">Coarse Aggregates 20mm (Cu.m)</option>
                                <option value="3">PVC Plumbing Pipe 4" (6m) (PCs)</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="transfer_qty" class="form-label fw-semibold">Transfer Qty</label>
                             <input type="text" id="transfer_qty" name="transfer_qty" value="" class="form-control" placeholder="Enter Transfer Qty">
                        </div>
                        <div class="col-lg-6">
                            <label for="transit_vehicle" class="form-label fw-semibold">Transit Vehicle coordinates</label>
                             <input type="text" id="transit_vehicle" name="transit_vehicle" value="" class="form-control" placeholder="Enter Transit Vehicle coordinates">
                        </div>
                        <div class="col-lg-6">
                            <label for="driver_name" class="form-label fw-semibold">Driver/Operator Name</label>
                            <select id="driver_name" name="driver_name" class="form-select select3" required>
                                <option value="" disabled selected>Select Driver/Operator</option>
                                <option value="1">Murugan S</option>
                                <option value="2">Kathiresan</option>
                                <option value="3">Palani</option>
                            </select>
                        </div>
                        <div class="col-lg-12">
                            <label for="date_arrival" class="form-label fw-semibold">Expected Arrival Date</label>
                             <input type="text" id="date_arrival" name="date_arrival" value="" class="form-control" placeholder="dd-mm-yyy">
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary">Cancel</button>
                    <button type="" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Submit Stock Transfer</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
@endsection