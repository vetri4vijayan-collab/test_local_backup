@extends('layouts.layoutMaster')

@section('title', 'Planning & Quantity Surveying (QS) Engine - Steel Reconciliation')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 w-100">

                <div>
                    <h5 class="mb-1 fw-semibold text-dark">
                        Planning & Quantity Surveying (QS) Engine
                    </h5>

                    <p class="mb-0 text-muted small">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>
                </div>

                <div class="d-flex align-items-center gap-2 flex-shrink-0">

                    <button
                        type="button"
                        class="btn btn-tab-arrow"
                        id="tabScrollLeft"
                        aria-label="Scroll tabs left">
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

              
                    <div
                        class="d-flex align-items-center gap-2 tab-pill-track"
                        id="tabPillTrack">

                        <!-- Reconciliation Tab -->
                        <a
                            href="{{ route('planning-qs.verification') }}"
                            class="btn btn-tab-pill {{ request()->routeIs('planning-qs.verification') ? 'active' : '' }}">
                            Reconciliation
                        </a>

                        <!-- Bill Passing Check List Tab -->
                        <a
                            href="{{ route('planning-qs.verification.passing') }}"
                            class="btn btn-tab-pill {{ request()->routeIs('planning-qs.verification.passing') ? 'active' : '' }}">
                            Bill Passing Check List
                        </a>

                    </div>

                    <button
                        type="button"
                        class="btn btn-tab-arrow"
                        id="tabScrollRight"
                        aria-label="Scroll tabs right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                </div>

            </div>

        </div>
    </div>


    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4">

            <form
                method="GET"
                id="projectFilterForm"
                class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">

                <div class="flex-grow-1">

                    <div class="row align-items-end g-3">

                        <div class="col-12 col-md-5 col-lg-4">

                            <label
                                for="projectFilter"
                                class="form-label fw-semibold">
                                Project
                            </label>

                            <select
                                id="projectFilter"
                                name="project"
                                class="form-select">

                                <option value="">
                                    All Project
                                </option>

                                <option value="KWRP">
                                    KWRP
                                </option>

                                <option value="Industrial Warehouse Construction">
                                    Industrial Warehouse Construction
                                </option>

                                <option value="Commercial Complex - Block">
                                    Commercial Complex - Block
                                </option>

                            </select>

                        </div>

                        <div class="col-12 col-md-auto">

                        </div>

                    </div>

                </div>

                <div>

                    <button
                        type="button"
                        class="btn btn-primary px-4"
                        data-bs-toggle="modal"
                        data-bs-target="#createSteelReconciliationModal">

                        <i class="mdi mdi-plus me-1"></i>

                        Create Steel Reconciliation

                    </button>

                </div>

            </form>

        </div>

    </div>


    <div class="card shadow-sm border-0 rounded-3">

        <div class="card-body p-3 p-md-4">

            <div class="table-responsive">

                <table
                    id="steelReconciliationTable"
                    class="table table-hover align-middle mb-0">

                    <thead>

                        <tr>

                            <th class="text-nowrap">
                                Date
                                
                            </th>

                            <th class="text-nowrap">
                                Project
                            </th>

                            <th class="text-nowrap">
                                Period
                            </th>

                            <th class="text-nowrap">
                                Receive Qty
                                
                            </th>

                            <th class="text-nowrap">
                                Return Qty
                                
                            </th>

                            <th class="text-center text-nowrap">
                                Actions
                              
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr data-project="KWRP">

                            <td class="text-nowrap">
                                17-03-2026
                            </td>

                            <td>
                                KWRP
                            </td>

                            <td class="text-nowrap">
                                01-03-2026 to 17-03-2026
                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">100</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">86</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">675</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">58</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">55</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">77</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">56</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">1107</span>
                                </div>

                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                            </td>

                            <td class="text-center">

                                <button
                                    type="button"
                                    class="btn text-dark p-1 view-reconciliation-btn"
                                    title="View Reconciliation"
                                    data-project="KWRP"
                                    data-date="17-03-2026"
                                    data-period="01-03-2026 to 17-03-2026"
                                    data-received="100,86,675,58,55,77,56"
                                    data-returned="0,0,0,0,0,0,0">

                                    <i class="mdi mdi-eye-outline fs-5"></i>

                                </button>

                            </td>

                        </tr>


                        <tr data-project="Industrial Warehouse Construction">

                            <td class="text-nowrap">
                                10-04-2026
                            </td>

                            <td>
                                Industrial Warehouse Construction
                            </td>

                            <td class="text-nowrap">
                                30-04-2026 to 30-05-2026
                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">10</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">15</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">25</span>
                                </div>

                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">2</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">4</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">6</span>
                                </div>

                            </td>

                            <td class="text-center">

                                <button
                                    type="button"
                                    class="btn text-dark p-1 view-reconciliation-btn"
                                    title="View Reconciliation"
                                    data-project="Industrial Warehouse Construction"
                                    data-date="10-04-2026"
                                    data-period="30-04-2026 to 30-05-2026"
                                    data-received="10,15,0,0,0,0,0"
                                    data-returned="2,4,0,0,0,0,0">

                                    <i class="mdi mdi-eye-outline fs-5"></i>

                                </button>

                            </td>

                        </tr>


                        <tr data-project="Commercial Complex - Block">

                            <td class="text-nowrap">
                                16-04-2026
                            </td>

                            <td>
                                Commercial Complex - Block
                            </td>

                            <td class="text-nowrap">
                                01-04-2026 to 30-04-2026
                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">20</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">30</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">45</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">25</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">15</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">10</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">5</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">150</span>
                                </div>

                            </td>

                            <td>

                                <div class="fw-semibold mb-2">
                                    DIA&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;QTY
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">8</span>
                                    <span>-</span>
                                    <span class="ms-2">1</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">10</span>
                                    <span>-</span>
                                    <span class="ms-2">2</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">12</span>
                                    <span>-</span>
                                    <span class="ms-2">3</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">16</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">20</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-1">
                                    <span class="d-inline-block" style="width:35px;">25</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="mb-2">
                                    <span class="d-inline-block" style="width:35px;">32</span>
                                    <span>-</span>
                                    <span class="ms-2">0</span>
                                </div>

                                <div class="fw-bold">
                                    <span style="width:35px; display:inline-block;">
                                        TOT
                                    </span>
                                    <span>-</span>
                                    <span class="ms-2">6</span>
                                </div>

                            </td>

                            <td class="text-center">

                                <button
                                    type="button"
                                    class="btn text-dark p-1 view-reconciliation-btn"
                                    title="View Reconciliation"
                                    data-project="Commercial Complex - Block"
                                    data-date="16-04-2026"
                                    data-period="01-04-2026 to 30-04-2026"
                                    data-received="20,30,45,25,15,10,5"
                                    data-returned="1,2,3,0,0,0,0">

                                    <i class="mdi mdi-eye-outline fs-5"></i>

                                </button>

                            </td>

                        </tr>


                        <tr id="noReconciliationResults" style="display:none;">

                            <td
                                colspan="6"
                                class="text-center text-muted py-4">

                                No reconciliation records found for the selected project.

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


<!-- View Reconciliation Modal -->
<div class="modal fade" id="viewReconciliationModal" tabindex="-1" aria-labelledby="viewReconciliationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" style="max-width: 950px;">
        <div class="modal-content border-0 shadow">

            <div class="modal-header bg-white border-bottom">
                <h6 class="modal-title fw-semibold text-secondary text-uppercase" id="viewReconciliationModalLabel" style="letter-spacing: 0.5px;">
                    Steel Reconciliation
                </h6>
                <button type="button" class="btn-close" id="closeViewModalBtn" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">

                <!-- Action Buttons -->
                <div class="d-flex gap-2 mb-4">
                    <button type="button" class="btn btn-primary text-white px-3" onclick="window.print()">
                        <i class="mdi mdi-printer me-1"></i> Print
                    </button>
                    <button type="button" class="btn btn-primary text-white px-3" id="exportReconciliationBtn">
                        <i class="mdi mdi-download me-1"></i> Export
                    </button>
                </div>

               <!-- Statement Table -->
<div class="table-responsive">
    <table class="table table-bordered mb-0 reconciliation-statement-table" id="reconciliationStatementTable">
        <tbody>
            <!-- Title Row -->
            <tr>
                <td colspan="11" class="text-center fw-bold" style="background-color: #e9ecef; font-size: 15px; padding: 8px;">
                    Steel Reconciliation Statement
                </td>
            </tr>

            <!-- Project / Date Row -->
            <tr>
                <td colspan="2" class="fw-semibold" style="background-color: #f8f9fa; font-size: 13px; padding: 8px 10px;">
                    Project : <span id="modalProjectName" class="fw-normal"></span>
                </td>
                <td colspan="9" class="fw-semibold" style="background-color: #f8f9fa; font-size: 13px; padding: 8px 10px;">
                    Date : <span id="modalProjectDate" class="fw-normal"></span>
                </td>
            </tr>

            <!-- Period Row -->
            <tr>
                <td colspan="2" style="background-color: #f8f9fa;"></td>
                <td colspan="9" class="fw-semibold" style="background-color: #f8f9fa; font-size: 13px; padding: 8px 10px;">
                    Period : <span id="modalProjectPeriod" class="fw-normal"></span>
                </td>
            </tr>

            <!-- Header Row 1 -->
            <tr style="background-color: #00b4d8; color: #fff;">
                <th rowspan="2" class="text-center align-middle" style="font-size: 13px; width: 60px;">Sr. No</th>
                <th rowspan="2" class="text-center align-middle" style="font-size: 13px; width: 160px;">Description</th>
                <th colspan="7" class="text-center" style="font-size: 13px;">Dia Wise Steel in MT</th>
                <th rowspan="2" class="text-center align-middle" style="font-size: 13px; width: 100px;">Total in MT</th>
                <th rowspan="2" class="text-center align-middle" style="font-size: 13px; width: 100px;">Remarks</th>
            </tr>

            <!-- Header Row 2 (Dia values) -->
            <tr style="background-color: #00b4d8; color: #fff;">
                <th class="text-center" style="font-size: 13px;">8</th>
                <th class="text-center" style="font-size: 13px;">10</th>
                <th class="text-center" style="font-size: 13px;">12</th>
                <th class="text-center" style="font-size: 13px;">16</th>
                <th class="text-center" style="font-size: 13px;">20</th>
                <th class="text-center" style="font-size: 13px;">25</th>
                <th class="text-center" style="font-size: 13px;">32</th>
            </tr>

            <!-- Row 1: Received Qty -->
            <tr>
                <td class="text-center" style="font-size: 13px;">1</td>
                <td style="font-size: 13px;">Received Qty</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_0">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_1">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_2">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_3">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_4">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_5">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReceivedQty_6">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;" id="totalReceivedQty">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 2: Returned Qty -->
            <tr>
                <td class="text-center" style="font-size: 13px;">2</td>
                <td style="font-size: 13px;">Returned Qty</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_0">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_1">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_2">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_3">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_4">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_5">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowReturnedQty_6">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;" id="totalReturnedQty">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 3: Actual Quantity -->
            <tr>
                <td class="text-center" style="font-size: 13px;">3</td>
                <td style="font-size: 13px;">Actual Quantity (3=1-2)</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_0">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_1">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_2">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_3">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_4">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_5">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowActualQty_6">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;" id="totalActualQty">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 4: Billed Qty -->
            <tr>
                <td class="text-center" style="font-size: 13px;">4</td>
                <td style="font-size: 13px;">Billed Qty</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 5: Lap & Chairs -->
            <tr>
                <td class="text-center" style="font-size: 13px;">5</td>
                <td style="font-size: 13px;">Lap &amp; Chairs</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 6: Total (6=4+5) -->
            <tr>
                <td class="text-center" style="font-size: 13px;">6</td>
                <td style="font-size: 13px;">Total (6=4+5)</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 7: Stock at Site & Camp -->
            <tr>
                <td class="text-center" style="font-size: 13px;">7</td>
                <td style="font-size: 13px;">Stock at Site &amp; Camp</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 8: WIP -->
            <tr>
                <td class="text-center" style="font-size: 13px;">8</td>
                <td style="font-size: 13px;">WIP</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 9: Total (9=7+8) -->
            <tr>
                <td class="text-center" style="font-size: 13px;">9</td>
                <td style="font-size: 13px;">Total (9=7+8)</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 10: Difference -->
            <tr>
                <td class="text-center" style="font-size: 13px;">10</td>
                <td style="font-size: 13px;">Difference (10=3-6-9)</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_0">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_1">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_2">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_3">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_4">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_5">0</td>
                <td class="text-center" style="font-size: 13px;" id="rowDifference_6">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;" id="totalDifference">0</td>
                <td style="font-size: 13px;"></td>
            </tr>

            <!-- Row 11: Scrap -->
            <tr>
                <td class="text-center" style="font-size: 13px;">11</td>
                <td style="font-size: 13px;">Scrap</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center" style="font-size: 13px;">0</td>
                <td class="text-center fw-semibold" style="font-size: 13px;">0</td>
                <td style="font-size: 13px;"></td>
            </tr>
        </tbody>
    </table>
</div>

                <!-- Signature Row -->
                <div class="d-flex justify-content-between mt-5 pt-3" style="font-size: 13px;">
                    <div class="text-center">
                        <div class="fw-semibold mb-4">Prepared By</div>
                        <div style="border-top: 1px solid #333; width: 150px; margin-top: 40px;"></div>
                    </div>
                    <div class="text-center">
                        <div class="fw-semibold mb-4">Checked By</div>
                        <div style="border-top: 1px solid #333; width: 150px; margin-top: 40px;"></div>
                    </div>
                    <div class="text-center">
                        <div class="fw-semibold mb-4">Accepted By</div>
                        <div style="border-top: 1px solid #333; width: 150px; margin-top: 40px;"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="createSteelReconciliationModal" tabindex="-1" aria-labelledby="createSteelReconciliationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" style="max-width: 1200px;">
        <div class="modal-content border-0 shadow" style="border-radius: 4px;">

            <!-- Modal Header -->
            <div class="modal-header bg-light border-bottom" style="border-radius: 4px 4px 0 0;">
                <h6 class="modal-title fw-semibold text-secondary text-uppercase" id="createSteelReconciliationModalLabel" style="letter-spacing: 0.5px;">
                    Create Steel Reconciliation
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body p-0">

                <!-- Top Form Section -->
                <div class="p-4 border-bottom">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small mb-1">
                                Project <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" style="border-radius: 2px; border-color: #ced4da;">
                                <option value="">Select Project</option>
                                <option value="KWRP">KWRP</option>
                                <option value="Industrial Warehouse Construction">Industrial Warehouse Construction</option>
                                <option value="Commercial Complex - Block">Commercial Complex - Block</option>
                                 <option value="MVMM - Block">MVMM</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small mb-1">
                                From Date <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small mb-1">
                                To Date <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;">
                        </div>
                    </div>
                </div>

                <!-- Table Section -->
                <div class="p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered mb-0" style="font-size: 13px; border-color: #dee2e6;">
                            <thead>
                                <!-- Header Row 1 -->
                                <tr style="background-color: #f8fafc;">
                                    <th rowspan="2" class="text-center align-middle fw-semibold" style="width: 50px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">Sr. No</th>
                                    <th rowspan="2" class="align-middle fw-semibold" style="width: 180px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">Description</th>
                                    <th colspan="7" class="text-center fw-semibold" style="color: #4b6380; border-color: #dee2e6; font-size: 12px; padding: 8px;">Dia Wise Steel in MT</th>
                                    <th rowspan="2" class="text-center align-middle fw-semibold" style="width: 100px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">Total In MT</th>
                                    <th rowspan="2" class="align-middle fw-semibold" style="width: 130px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">Remarks</th>
                                </tr>
                                <!-- Header Row 2 -->
                                <tr style="background-color: #f8fafc;">
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">8</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">10</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">12</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">16</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">20</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">25</th>
                                    <th class="text-center fw-semibold" style="width: 65px; color: #4b6380; border-color: #dee2e6; font-size: 12px;">32</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Row 1: Received Qty -->
                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">1</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Received Qty</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>
                                <!-- Row 2: Returned Qty -->
                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">2</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Returned Qty</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">3</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Actual Quantity (3=1-2)</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>


                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">4</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Billed Qty</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>
  
                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">5</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Lap & Chairs</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                 <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">6</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Total (6=4+5)</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">7</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Stock at Site & Camp</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                     <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">8</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">WIP</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                
                                     <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">9</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Total (9=7+8)</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>

                                    <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">10</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Difference (10=3-6-9)</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>
                                        
                                <tr>
                                    <td class="text-center align-middle" style="color: #183b63; border-color: #dee2e6;">11</td>
                                    <td class="align-middle" style="color: #183b63; border-color: #dee2e6; background-color: #f1f4f7;">Scrap</td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="number" class="form-control form-control-sm text-center" value="0" style="border-radius: 2px; border-color: #ced4da;"></td>
                                    <td style="border-color: #dee2e6; padding: 4px;">
                                        <input type="text" class="form-control form-control-sm text-center" value="0" readonly style="background-color: #e9ecef; border-radius: 2px; border-color: #ced4da;">
                                    </td>
                                    <td style="border-color: #dee2e6; padding: 4px;"><input type="text" class="form-control form-control-sm" style="border-radius: 2px; border-color: #ced4da;"></td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

            <!-- Modal Footer -->
            <div class="modal-footer border-top bg-light" style="border-radius: 0 0 4px 4px;">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal" style="border-radius: 2px;">Cancel</button>
                <button type="button" class="btn btn-sm btn-primary" style="border-radius: 2px;">
            </i> Create Steel Reconciliation
                </button>
            </div>

        </div>
    </div>
</div>

<style>

#steelReconciliationTable {
    font-size: 13px;
}

#steelReconciliationTable thead th {
    font-size: 12px;
    font-weight: 600;
    color: #4b6380;
    background-color: #f8fafc;
    border-bottom: 1px solid #dee2e6;
    white-space: nowrap;
    padding: 12px 10px;
}

#steelReconciliationTable tbody td {
    padding: 12px 10px;
    color: #183b63;
    vertical-align: top;
    border-bottom: 1px solid #e5e7eb;
}

#steelReconciliationTable tbody tr:last-child td {
    border-bottom: 0;
}

#steelReconciliationTable tbody td:first-child {
    color: #244e78;
}

#steelReconciliationTable tbody td:nth-child(4),
#steelReconciliationTable tbody td:nth-child(5) {
    min-width: 145px;
}

#steelReconciliationTable tbody td:nth-child(2) {
    min-width: 220px;
}

#steelReconciliationTable tbody td:nth-child(3) {
    min-width: 210px;
}

.card {
    border: 1px solid #e3e8ef !important;
}

.form-label {
    font-size: 13px;
    color: #53677d;
}

.form-select,
.form-control {
    font-size: 13px;
}

.btn-info {
    background-color: #1da9d5;
    border-color: #1da9d5;
}

.btn-info:hover {
    background-color: #168db5;
    border-color: #168db5;
}

.btn-primary {
    background-color: #1769aa;
    border-color: #1769aa;
}

.btn-primary:hover {
    background-color: #12578f;
    border-color: #12578f;
}

.btn-tab-pill {
    border-radius: 50px;
    padding: 8px 20px;
    font-size: 13px;
    font-weight: 600;
    color: #53677d;
    background-color: #eef1f4;
    border: none;
    white-space: nowrap;
    text-decoration: none;
    transition: background-color 0.15s ease, color 0.15s ease;
}

.btn-tab-pill:hover {
    background-color: #e2e6eb;
    color: #1769aa;
    text-decoration: none;
}

.btn-tab-pill.active {
    background-color: #1769aa;
    color: #fff;
}

.btn-tab-pill.active:hover {
    background-color: #12578f;
    color: #fff;
}

.btn-tab-arrow {
    width: 32px;
    height: 32px;
    min-width: 32px;
    border-radius: 50%;
    border: 1px solid #e3e8ef;
    background-color: #fff;
    color: #8a97a8;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    flex-shrink: 0;
}

.btn-tab-arrow:hover {
    background-color: #f1f4f7;
    color: #1769aa;
}

.tab-pill-track {
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    max-width: 60vw;
}

.tab-pill-track::-webkit-scrollbar {
    display: none;
}

/* Reconciliation Statement Table Styles */
.reconciliation-statement-table {
    font-size: 13px;
    border-color: #adb5bd;
}

.reconciliation-statement-table th,
.reconciliation-statement-table td {
    border-color: #adb5bd !important;
    vertical-align: middle;
    padding: 8px 10px;
}

.reconciliation-statement-table thead th {
    background-color: #00b4d8 !important;
    color: #fff;
    border-color: #adb5bd !important;
}

.reconciliation-statement-table tbody td {
    color: #212529;
}

/* 7-column grid for dia-wise values */
.dia-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    width: 100%;
    text-align: center;
}

.dia-grid > span {
    padding: 2px 4px;
    font-size: 13px;
    white-space: nowrap;
}

/* Header row variant (used in the blue header) */
.dia-grid-header > span {
    font-weight: 600;
    color: #fff;
}

/* Custom styling for the Create Modal to match image */
#createSteelReconciliationModal .form-label {
    font-size: 12px;
}
#createSteelReconciliationModal .form-control-sm,
#createSteelReconciliationModal .form-select-sm {
    font-size: 13px;
}
#createSteelReconciliationModal table th {
    font-size: 12px;
    font-weight: 600;
    color: #4b6380;
    background-color: #f8fafc;
    vertical-align: middle;
}
#createSteelReconciliationModal table td {
    vertical-align: middle;
    color: #183b63;
}
#createSteelReconciliationModal table input {
    font-size: 13px;
    color: #183b63;
}
/* ---------- Clean fix for Create Steel Reconciliation modal ---------- */
#createSteelReconciliationModal .modal-dialog {
    max-width: 900px
    margin: 1rem auto;
}

#createSteelReconciliationModal .modal-content {
    max-height: calc(100vh - 2rem);
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

#createSteelReconciliationModal .modal-header {
    padding: 1rem 1.5rem;
    flex-shrink: 0;
}

#createSteelReconciliationModal .modal-body {
    overflow-y: auto;
    overflow-x: hidden;
    flex: 1 1 auto;
    padding: 1.5rem;   /* <-- restores the internal padding */
}

#createSteelReconciliationModal .modal-footer {
    padding: 1rem 1.5rem;
    flex-shrink: 0;
}

/* The form section (top of modal body) keeps its own padding */
#createSteelReconciliationModal .modal-body > .p-4.border-bottom {
    padding: 0 0 1rem 0 !important;
    border-bottom: 1px solid #dee2e6;
    margin-bottom: 1rem;
}

/* The table wrapper gets horizontal padding too */
#createSteelReconciliationModal .table-responsive {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
}

#createSteelReconciliationModal table {
    width: 100%;
    font-size: 13px;
}

#createSteelReconciliationModal table th,
#createSteelReconciliationModal table td {
    padding: 6px 8px !important;
    vertical-align: middle;
}

#createSteelReconciliationModal table input.form-control-sm {
    height: 30px;
    padding: 2px 6px;
    font-size: 12px;
    text-align: center;
}
/* ---------- end FIX ---------- */

@media (max-width: 768px) {

    #steelReconciliationTable {
        min-width: 1050px;
    }

    .card-body {
        padding: 1rem !important;
    }

    .tab-pill-track {
        max-width: 100%;
    }

}

/* Print-specific styles to hide buttons and modal headers */
@media print {
    #viewReconciliationModal .modal-body > .d-flex.gap-2.mb-4 {
        display: none !important;
    }
    
    #viewReconciliationModal .modal-header {
        display: none !important;
    }
    
    #viewReconciliationModal .modal-content {
        border: none !important;
        box-shadow: none !important;
    }
}

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('tabPillTrack');
    const leftBtn = document.getElementById('tabScrollLeft');
    const rightBtn = document.getElementById('tabScrollRight');

    if (track && leftBtn && rightBtn) {

        leftBtn.addEventListener('click', function () {

            track.scrollBy({
                left: -150,
                behavior: 'smooth'
            });

        });

        rightBtn.addEventListener('click', function () {

            track.scrollBy({
                left: 150,
                behavior: 'smooth'
            });

        });

    }


    const filterForm = document.getElementById('projectFilterForm');
    const projectSelect = document.getElementById('projectFilter');
    const table = document.getElementById('steelReconciliationTable');

    if (!filterForm || !projectSelect || !table) {
        return;
    }

    const tbody = table.querySelector('tbody');

    const noResultsRow =
        document.getElementById('noReconciliationResults');


    function applyProjectFilter() {

        const selectedProject =
            projectSelect.value.trim();

        const rows =
            tbody.querySelectorAll('tr[data-project]');

        let visibleCount = 0;


        rows.forEach(function (row) {

            const rowProject =
                row.getAttribute('data-project').trim();

            const matches =
                selectedProject === '' ||
                rowProject === selectedProject;

            row.style.display =
                matches ? '' : 'none';

            if (matches) {
                visibleCount++;
            }

        });


        if (noResultsRow) {

            noResultsRow.style.display =
                visibleCount === 0 ? '' : 'none';

        }

    }


    filterForm.addEventListener('submit', function (event) {

        event.preventDefault();

        applyProjectFilter();

    });


    projectSelect.addEventListener('change', function () {

        applyProjectFilter();

    });


    applyProjectFilter();

    const viewModalEl = document.getElementById('viewReconciliationModal');
    const viewModal = new bootstrap.Modal(viewModalEl);
    const viewButtons = document.querySelectorAll('.view-reconciliation-btn');

    const closeViewModalBtn = document.getElementById('closeViewModalBtn');
    if (closeViewModalBtn) {
        closeViewModalBtn.addEventListener('click', function () {
            viewModal.hide();
        });
    }

    viewButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            const project = this.getAttribute('data-project');
            const date = this.getAttribute('data-date');
            const period = this.getAttribute('data-period');
            const receivedStr = this.getAttribute('data-received');
            const returnedStr = this.getAttribute('data-returned');

            const received = receivedStr.split(',').map(Number);
            const returned = returnedStr.split(',').map(Number);

            document.getElementById('modalProjectName').textContent = project;
            document.getElementById('modalProjectDate').textContent = date;
            document.getElementById('modalProjectPeriod').textContent = period;

            function setRowValues(rowId, values) {
                const container = document.getElementById(rowId);
                if (container) {
                    const spans = container.querySelectorAll('span');
                    spans.forEach(function (span, index) {
                        span.textContent = values[index] !== undefined ? values[index] : 0;
                    });
                }
            }

            setRowValues('rowReceivedQty', received);
            document.getElementById('totalReceivedQty').textContent = received.reduce((a, b) => a + b, 0);

            setRowValues('rowReturnedQty', returned);
            document.getElementById('totalReturnedQty').textContent = returned.reduce((a, b) => a + b, 0);

            const actual = received.map((v, i) => v - (returned[i] || 0));
            setRowValues('rowActualQty', actual);
            document.getElementById('totalActualQty').textContent = actual.reduce((a, b) => a + b, 0);

            setRowValues('rowDifference', actual);
            document.getElementById('totalDifference').textContent = actual.reduce((a, b) => a + b, 0);

            viewModal.show();
        });
    });

    const exportBtn = document.getElementById('exportReconciliationBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', function () {
            alert('Export functionality would download the reconciliation statement.');
        });
    }

});

</script>

@endsection