@extends('layouts.layoutMaster')

@section('title', 'Planning & Quantity Surveying (QS) Engine - Bill Passing Check List')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 w-100">
                <div>
                    <h5 class="mb-1 fw-semibold text-dark">Planning & Quantity Surveying (QS) Engine</h5>
                    <p class="mb-0 text-muted small">Master Schedules, Work Orders, RA Billing & Material Verification</p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-shrink-0">
                    <button type="button" class="btn btn-tab-arrow" id="tabScrollLeft" aria-label="Scroll tabs left"><i class="mdi mdi-chevron-left"></i></button>
                    <div class="d-flex align-items-center gap-2 tab-pill-track" id="tabPillTrack">
                        <a href="{{ route('planning-qs.verification') }}" class="btn btn-tab-pill {{ request()->routeIs('planning-qs.verification') ? 'active' : '' }}">Reconciliation</a>
                        <a href="{{ route('planning-qs.verification.passing') }}" class="btn btn-tab-pill {{ request()->routeIs('planning-qs.verification.passing') ? 'active' : '' }}">Bill Passing Check List</a>
                    </div>
                    <button type="button" class="btn btn-tab-arrow" id="tabScrollRight" aria-label="Scroll tabs right"><i class="mdi mdi-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">
        <div class="card-body p-3">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg-3">
                    <div class="position-relative">
                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted" style="pointer-events:none;"><i class="mdi mdi-magnify"></i></span>
                        <input id="securityBillSearch" type="text" placeholder="Search Bill No, Project, Vendor..." class="form-control form-control-sm ps-4 bg-light border-0 rounded-3" style="height:38px;font-size:11px;" autocomplete="off">
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <select id="securityProjectFilter" class="form-select form-select-sm bg-light border-0 rounded-3">
                        <option value="">All Project</option>
                        <option value="Commercial Complex - Block">Commercial Complex - Block</option>
                        <option value="Solar Power Plant Installation">Solar Power Plant Installation</option>
                        <option value="Smart City Drainage Upgrade">Smart City Drainage Upgrade</option>
                        <option value="Industrial Warehouse Construction">Industrial Warehouse Construction</option>
                        <option value="KWRP">KWRP</option>
                    </select>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <select id="securityVendorFilter" class="form-select form-select-sm bg-light border-0 rounded-3">
                        <option value="">All Vendors</option>
                        <option value="UltraTech Cement Ltd">UltraTech Cement Ltd</option>
                        <option value="PowerLine Electricals">PowerLine Electricals</option>
                        <option value="TechNova Solutions Pvt Ltd">TechNova Solutions Pvt Ltd</option>
                        <option value="ABC Heavy Equipments Pvt Ltd">ABC Heavy Equipments Pvt Ltd</option>
                        <option value="SK Construction">SK Construction</option>
                    </select>
                </div>
                <div class="col-12 col-lg-3">
                    <button type="button" class="btn btn-primary btn-sm rounded-3 d-inline-flex align-items-center justify-content-center px-3 w-100" style="height:38px;white-space:nowrap;" id="newSecurityBillBtn" data-bs-toggle="modal" data-bs-target="#newSecurityBillModal">
                        <i class="mdi mdi-plus me-1"></i>
                        <span>Create Bill Passing Check List</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3" id="securityBillCards"></div>

    <div class="modal fade" id="newSecurityBillModal" tabindex="-1" aria-labelledby="newSecurityBillModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4">
                <div class="modal-header bg-light border-bottom">
                    <h6 class="modal-title fw-semibold text-secondary text-uppercase" id="newSecurityBillModalLabel" style="letter-spacing: 0.5px;">CREATE BILL PASSING CHECK LIST</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-3 p-md-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Project <span class="text-danger">*</span></label>
                            <select class="form-select" id="securityProject">
                                <option value="">Select Project</option>
                                <option value="Metro Central Yard & Corridor 4">Metro Central Yard & Corridor 4</option>
                                <option value="Adyar Residential Yard B">Adyar Residential Yard B</option>
                                <option value="Smart City Drainage Upgrade">Smart City Drainage Upgrade</option>
                                <option value="Highway Road Expansion Phase 2">Highway Road Expansion Phase 2</option>
                                <option value="Water Treatment Plant Setup">Water Treatment Plant Setup</option>
                                <option value="IT Park Infrastructure Development">IT Park Infrastructure Development</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Vendor <span class="text-danger">*</span></label>
                            <select class="form-select" id="securityVendor">
                                <option value="">Select Vendor</option>
                                <option value="Apex Guarding Services Pvt Ltd">Apex Guarding Services Pvt Ltd</option>
                                <option value="Vanguard Site Security Systems">Vanguard Site Security Systems</option>
                                <option value="TechNova Solutions Pvt Ltd">TechNova Solutions Pvt Ltd</option>
                                <option value="FastTrack Logistics">FastTrack Logistics</option>
                                <option value="Sri Sai Facility Services">Sri Sai Facility Services</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Voucher No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="securityVoucherNo" value="">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Work Order No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="securityWorkOrderNo" value="">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Agency Bill No</label>
                            <input type="text" class="form-control" id="securityAgencyBillNo" value="">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">From Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="securityFromDate">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">To Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="securityToDate">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Account Head <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="securityAccountHead" value="">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="securityAmountInput" value="0">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Sub Total <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="subTotal" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">GST % <span class="text-danger">*</span></label>
                            <select class="form-select" id="gstPercent">
                                <option value="">Select GST%</option>
                                <option value="5">5%</option>
                                <option value="12">12%</option>
                                <option value="18">18%</option>
                                <option value="28">28%</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">GST Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="gstAmount" readonly>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Bill Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="billAmount" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">TDS % <span class="text-danger">*</span></label>
                            <input type="number" min="0" max="100" step="0.01" class="form-control" id="tdsPercent" value="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">TDS Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="tdsAmount" readonly>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Security Deposit % <span class="text-danger">*</span></label>
                            <input type="number" min="0" max="100" step="0.01" class="form-control" id="securityDepositPercent" value="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Security Deposit Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="securityDepositAmount" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Net Payment <span class="text-danger">*</span></label>
                            <input type="number" class="form-control calculated-field" id="netPaymentInput" readonly>
                        </div>

                        <div class="col-12">
                            <label class="form-label">Narration</label>
                            <textarea class="form-control" id="securityNarration" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveSecurityBillBtn">
                        <i class="mdi mdi-check me-1"></i>
                        <span id="securitySaveText">Create Material Rental Bill</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewSecurityBillModal" tabindex="-1" aria-labelledby="viewSecurityBillModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" style="max-width: 1000px;">
            <div class="modal-content border-0 shadow-lg rounded-4">
                <div class="modal-header bg-light border-bottom d-flex justify-content-between align-items-center">
                    <h6 class="modal-title fw-semibold text-secondary text-uppercase" id="viewSecurityBillModalLabel" style="letter-spacing: 0.5px;">BILL PASSING CHECK LIST</h6>
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="btn btn-primary text-white btn-sm" onclick="window.print()"><i class="mdi mdi-printer me-1"></i> Print</button>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
                <div class="modal-body p-3 p-md-4">
                    <div class="voucher-container" id="voucherPrintArea">

                        <div class="voucher-header">
                            <div class="voucher-header-left">
                                <div class="voucher-company-name">SRK Infra Developers,</div>
                                <div class="voucher-company-address">Door No. 5/288, Flat No. 14, B. Kalavathy Apartments, Loganathan Nagar, Mannivakkam, Chennai - 600 048.</div>
                            </div>
                            <div class="voucher-header-right">
                                <div class="voucher-logo">
                                    <span class="voucher-logo-text">SRK</span>
                                    <span class="voucher-logo-sub">INFRA DEVELOPERS</span>
                                </div>
                            </div>
                        </div>

                        <div class="voucher-title-row">
                            <div class="voucher-title">BILL PASSING CHECK LIST</div>
                        </div>

                        <div class="voucher-info-row">
                            <div class="voucher-info-item">Project : <strong id="voucherProject"></strong></div>
                            <div class="voucher-info-item">Voucher No : <strong id="voucherVoucherNo"></strong></div>
                            <div class="voucher-info-item voucher-info-right" id="voucherDate"></div>
                        </div>

                        <div class="voucher-subtitle">Capital / Material / Expenses / Purchase Voucher</div>

                        <div class="voucher-body">
                            <div class="voucher-left">
                                <div class="voucher-row"><span class="voucher-label">Agency Name</span><span class="voucher-colon">:</span><strong id="voucherAgencyName"></strong></div>
                                <div class="voucher-row"><span class="voucher-label">TIN / GST No</span><span class="voucher-colon">:</span><span id="voucherGstNo"></span></div>
                                <div class="voucher-row"><span class="voucher-label">PAN No</span><span class="voucher-colon">:</span><span id="voucherPanNo"></span></div>
                                <div class="voucher-row"><span class="voucher-label">P.O./W.O. No</span><span class="voucher-colon">:</span><span id="voucherWorkOrderNo"></span></div>
                                <div class="voucher-row"><span class="voucher-label">Agency Bill No</span><span class="voucher-colon">:</span><span id="voucherAgencyBillNo"></span></div>
                                <div class="voucher-row"><span class="voucher-label">Account Head</span><span class="voucher-colon">:</span><span id="voucherAccountHead"></span></div>

                                <div class="voucher-section-title">VAT Input</div>
                                <div class="voucher-section-line"></div>
                                <div class="voucher-section-line"></div>

                                <div class="voucher-section-title">Discount</div>
                                <div class="voucher-section-line"></div>

                                <div class="voucher-row"><span class="voucher-label">Income Tax TDS</span><span class="voucher-colon">:</span><span id="voucherTdsPercent"></span><span class="voucher-percent">%</span><span class="voucher-on">On Rs.</span><span id="voucherTdsBase"></span></div>
                                <div class="voucher-section-line"></div>

                                <div class="voucher-section-title">Debit Note</div>
                                <div class="voucher-section-line"></div>

                                <div class="voucher-row"><span class="voucher-label">Security Deposit</span><span class="voucher-colon">:</span><span id="voucherSecurityPercent"></span><span class="voucher-percent">%</span><span class="voucher-on">On Rs.</span><span id="voucherSecurityBase"></span></div>
                                <div class="voucher-section-line"></div>

                                <div class="voucher-words-row">
                                    <span class="voucher-label">Rs. in Words</span>
                                    <span class="voucher-colon">:</span>
                                    <span id="voucherAmountInWords" class="voucher-words-text"></span>
                                </div>

                                <div class="voucher-words-row">
                                    <span class="voucher-label">Narration</span>
                                    <span class="voucher-colon">:</span>
                                    <span id="voucherNarration" class="voucher-words-text"></span>
                                </div>
                            </div>

                            <div class="voucher-right">
                                <div class="voucher-right-row"><span class="voucher-right-label">State</span><span class="voucher-right-value">Tamil Nadu</span></div>
                                <div class="voucher-right-row"><span class="voucher-right-label">Service Tax No.</span><span class="voucher-right-value"></span></div>
                                <div class="voucher-right-row"><span class="voucher-right-label">Date</span><span class="voucher-right-value" id="voucherFromDate"></span></div>
                                <div class="voucher-right-row"><span class="voucher-right-label">Date</span><span class="voucher-right-value" id="voucherToDate"></span></div>
                                <div class="voucher-right-row"><span class="voucher-right-label">Dr</span><span class="voucher-right-value" id="voucherDr"></span></div>

                                <div class="voucher-total-row"><span class="voucher-total-label">Sub Total</span><span class="voucher-total-value" id="voucherSubTotal"></span></div>
                                <div class="voucher-total-row"><span class="voucher-total-label">CGST 9%</span><span class="voucher-total-value" id="voucherCgst"></span></div>
                                <div class="voucher-total-row"><span class="voucher-total-label">SGST 9%</span><span class="voucher-total-value" id="voucherSgst"></span></div>
                                <div class="voucher-total-row voucher-total-strong"><span class="voucher-total-label">Bill Amt</span><span class="voucher-total-value" id="voucherBillAmt"></span></div>

                                <div class="voucher-total-row"><span class="voucher-total-label"></span><span class="voucher-total-value" id="voucherTdsAmount"></span></div>
                                <div class="voucher-total-row"><span class="voucher-total-label"></span><span class="voucher-total-value" id="voucherSecurityAmount"></span></div>

                                <div class="voucher-total-row voucher-total-strong"><span class="voucher-total-label">Pass for Payment</span><span class="voucher-total-value" id="voucherPassForPayment"></span></div>
                            </div>
                        </div>

                        <div class="voucher-signature-row">
                            <div class="voucher-signature-box">Prepared By</div>
                            <div class="voucher-signature-box">Checked By</div>
                            <div class="voucher-signature-box">Authorised by</div>
                        </div>

                        <div class="voucher-footer">
                            <div class="voucher-footer-col">
                                <div class="voucher-footer-title">Office Address:</div>
                                <div>M/s. SRK Infra Developers,</div>
                                <div>D. No. 5/288, Flat No. 14, Loganathan Nagar,</div>
                                <div>Mannivakkam, Chennai - 600048.</div>
                                <div>Phone : +91 444843611</div>
                                <div>Email : srkinfrach@gmail.com</div>
                            </div>
                            <div class="voucher-footer-col voucher-footer-center">
                                <div>PAN : ADKFZ8096B</div>
                                <div>GST : 33ADKFZ8096B1ZV</div>
                            </div>
                            <div class="voucher-footer-col voucher-footer-right">
                                <div>Bank Name HDFC Bank</div>
                                <div>A/c No 50200012345678</div>
                                <div>IFSC Code HDFC0000456</div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
.btn-tab-pill {
    border-radius: 50px;
    padding: 8px 20px;
    font-size: 13px;
    font-weight: 600;
    color: #53677d;
    background-color: #eef1f4;
    border: none;
    white-space: nowrap;
    text-decoration: none;
    transition: background-color 0.15s ease, color 0.15s ease;
}
.btn-tab-pill:hover {
    background-color: #e2e6eb;
    color: #1769aa;
    text-decoration: none;
}
.btn-tab-pill.active {
    background-color: #1769aa;
    color: #fff;
}
.btn-tab-pill.active:hover {
    background-color: #12578f;
    color: #fff;
}
.btn-tab-arrow {
    width: 32px;
    height: 32px;
    min-width: 32px;
    border-radius: 50%;
    border: 1px solid #e3e8ef;
    background-color: #fff;
    color: #8a97a8;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    flex-shrink: 0;
}
.btn-tab-arrow:hover {
    background-color: #f1f4f7;
    color: #1769aa;
}
.tab-pill-track {
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    max-width: 60vw;
}
.tab-pill-track::-webkit-scrollbar {
    display: none;
}
.security-bill-card .card {
    border: 1px solid #e3e8ef !important;
    border-radius: 12px !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    transition: box-shadow 0.15s ease;
}
.security-bill-card .card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.security-card-layout {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
}
.security-card-left {
    flex: 1 1 auto;
    min-width: 0;
}
.security-card-right {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 6px;
    margin-left: 20px;
}
.security-card-actions {
    display: flex;
    align-items: center;
    gap: 4px;
}
.security-bill-number {
    font-size: 10px;
    font-weight: 700;
    padding: 4px 7px;
    border-radius: 4px;
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
    font-family: monospace;
    display: inline-block;
}
.security-vendor {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 5px;
}
.security-project {
    font-size: 12px;
    color: #64748b;
    margin-bottom: 0;
}
.security-net-label {
    font-size: 10px;
    color: #64748b;
    display: block;
    text-align: right;
}
.security-net-payment-display {
    font-size: 15px;
    font-weight: 800;
    color: #059669;
    white-space: nowrap;
    text-align: right;
}
.security-edit-btn,
.security-view-btn,
.security-delete-btn {
    width: 26px;
    height: 26px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #64748b;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 5px;
}
.security-edit-btn:hover,
.security-view-btn:hover {
    background: #f1f5f9;
    color: #16659E;
}
.security-delete-btn:hover {
    background: #fef2f2;
    color: #dc2626;
}
.security-edit-btn i,
.security-view-btn i,
.security-delete-btn i {
    font-size: 15px;
}
#securityBillSearch,
#securityProjectFilter,
#securityVendorFilter {
    height: 38px;
    font-size: 12px;
}
#newSecurityBillModal .modal-dialog {
    max-width: 1050px;
}
#newSecurityBillModal .modal-content {
    overflow: hidden;
}
#newSecurityBillModal .modal-header {
    padding: 13px 18px;
}
#newSecurityBillModal .modal-title {
    font-size: 14px;
}
#newSecurityBillModal .modal-body {
    background: #fff;
}
#newSecurityBillModal .form-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 5px;
}
#newSecurityBillModal .form-control,
#newSecurityBillModal .form-select {
    height: 36px;
    border-color: #dbe2ea;
    border-radius: 7px;
    font-size: 11px;
}
#newSecurityBillModal .modal-footer {
    padding: 10px 18px;
}
#newSecurityBillModal .modal-footer .btn {
    height: 34px;
    font-size: 11px;
    font-weight: 600;
}
.calculated-field {
    background: #f8fafc !important;
    font-weight: 700;
}
.net-payment-box {
    margin-top: 5px;
    padding: 14px 16px;
    border-radius: 9px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.net-payment-title {
    font-size: 12px;
    font-weight: 700;
    color: #166534;
}
#netPayment {
    font-size: 19px;
    font-weight: 800;
    color: #059669;
}

/* Voucher Styles */
.voucher-container {
    background: #fff;
    color: #000;
    font-family: Arial, sans-serif;
    font-size: 12px;
    border: 1px solid #000;
    padding: 0;
}
.voucher-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 10px 15px;
    border-bottom: 1px solid #000;
}
.voucher-header-left {
    flex: 1;
}
.voucher-company-name {
    font-size: 13px;
    font-weight: 700;
    margin-bottom: 3px;
}
.voucher-company-address {
    font-size: 11px;
    line-height: 1.4;
}
.voucher-header-right {
    flex-shrink: 0;
    padding-left: 20px;
}
.voucher-logo {
    text-align: center;
    border: 2px solid #1a4d8c;
    padding: 8px 12px;
    border-radius: 4px;
}
.voucher-logo-text {
    display: block;
    font-size: 26px;
    font-weight: 900;
    color: #1a4d8c;
    line-height: 1;
    letter-spacing: 2px;
}
.voucher-logo-sub {
    display: block;
    font-size: 8px;
    font-weight: 700;
    color: #1a4d8c;
    letter-spacing: 1px;
    margin-top: 2px;
}
.voucher-title-row {
    text-align: center;
    padding: 6px 0;
    border-bottom: 1px solid #000;
}
.voucher-title {
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 1px;
}
.voucher-info-row {
    display: flex;
    justify-content: space-between;
    padding: 6px 15px;
    font-size: 11px;
    border-bottom: 1px solid #000;
}
.voucher-info-item {
    flex: 1;
}
.voucher-info-right {
    text-align: right;
    flex: 0 0 auto;
}
.voucher-subtitle {
    text-align: center;
    font-size: 11px;
    font-weight: 700;
    padding: 4px 0;
    border-bottom: 1px solid #000;
}
.voucher-body {
    display: flex;
    border-bottom: 1px solid #000;
}
.voucher-left {
    flex: 1;
    padding: 10px 15px;
    border-right: 1px solid #000;
}
.voucher-right {
    flex: 0 0 320px;
    padding: 10px 15px;
}
.voucher-row {
    display: flex;
    align-items: baseline;
    font-size: 11px;
    margin-bottom: 6px;
}
.voucher-label {
    flex: 0 0 110px;
    font-weight: 400;
}
.voucher-colon {
    flex: 0 0 10px;
    text-align: center;
}
.voucher-row strong,
.voucher-row span:not(.voucher-label):not(.voucher-colon):not(.voucher-percent):not(.voucher-on) {
    flex: 1;
    border-bottom: 1px solid #000;
    padding: 0 4px;
    min-height: 16px;
}
.voucher-percent {
    flex: 0 0 auto;
    padding: 0 3px;
}
.voucher-on {
    flex: 0 0 auto;
    padding: 0 3px;
    font-size: 10px;
}
.voucher-section-title {
    font-size: 11px;
    font-weight: 400;
    margin-top: 10px;
    margin-bottom: 4px;
}
.voucher-section-line {
    border-bottom: 1px solid #000;
    height: 14px;
    margin-bottom: 6px;
}
.voucher-words-row {
    display: flex;
    align-items: flex-start;
    font-size: 11px;
    margin-top: 8px;
}
.voucher-words-text {
    flex: 1;
    border-bottom: 1px solid #000;
    padding: 0 4px;
    min-height: 16px;
}
.voucher-right-row {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    margin-bottom: 6px;
}
.voucher-right-label {
    flex: 0 0 auto;
}
.voucher-right-value {
    flex: 1;
    border-bottom: 1px solid #000;
    text-align: right;
    padding: 0 4px;
    min-height: 16px;
}
.voucher-total-row {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    margin-bottom: 6px;
}
.voucher-total-label {
    flex: 0 0 auto;
}
.voucher-total-value {
    flex: 1;
    border-bottom: 1px solid #000;
    text-align: right;
    padding: 0 4px;
    min-height: 16px;
}
.voucher-total-strong {
    font-weight: 700;
}
.voucher-signature-row {
    display: flex;
    justify-content: space-between;
    padding: 30px 15px 10px 15px;
    border-bottom: 1px solid #000;
}
.voucher-signature-box {
    flex: 1;
    text-align: center;
    font-size: 11px;
    font-weight: 700;
}
.voucher-footer {
    display: flex;
    justify-content: space-between;
    padding: 8px 15px;
    font-size: 10px;
    line-height: 1.5;
}
.voucher-footer-col {
    flex: 1;
}
.voucher-footer-center {
    text-align: center;
}
.voucher-footer-right {
    text-align: right;
}
.voucher-footer-title {
    font-weight: 700;
}

@media print {
    body * {
        visibility: hidden !important;
    }
    #viewSecurityBillModal,
    #viewSecurityBillModal * {
        visibility: visible !important;
    }
    #viewSecurityBillModal {
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 100% !important;
        display: block !important;
        background: #fff !important;
    }
    .modal-backdrop {
        display: none !important;
    }
    .modal-dialog {
        max-width: 100% !important;
        margin: 0 !important;
    }
    .modal-content {
        border: 0 !important;
        box-shadow: none !important;
    }
    .modal-header,
    .modal-footer {
        display: none !important;
    }
    .voucher-container {
        border: 1px solid #000 !important;
    }
}

@media (max-width: 767px) {
    .tab-pill-track {
        max-width: 220px;
    }
    .btn-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }
    .btn-tab-arrow {
        width: 28px;
        height: 28px;
    }
    .security-card-right {
        margin-left: 10px;
    }
    .voucher-body {
        flex-direction: column;
    }
    .voucher-right {
        flex: 1;
        border-top: 1px solid #000;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('tabPillTrack');
    const leftBtn = document.getElementById('tabScrollLeft');
    const rightBtn = document.getElementById('tabScrollRight');

    if (track && leftBtn && rightBtn) {
        leftBtn.addEventListener('click', function () {
            track.scrollBy({ left: -150, behavior: 'smooth' });
        });
        rightBtn.addEventListener('click', function () {
            track.scrollBy({ left: 150, behavior: 'smooth' });
        });
    }

    const modalElement = document.getElementById('newSecurityBillModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
    const newButton = document.getElementById('newSecurityBillBtn');
    const saveButton = document.getElementById('saveSecurityBillBtn');
    const saveText = document.getElementById('securitySaveText');
    const project = document.getElementById('securityProject');
    const vendor = document.getElementById('securityVendor');
    const voucherNo = document.getElementById('securityVoucherNo');
    const workOrderNo = document.getElementById('securityWorkOrderNo');
    const agencyBillNo = document.getElementById('securityAgencyBillNo');
    const fromDate = document.getElementById('securityFromDate');
    const toDate = document.getElementById('securityToDate');
    const accountHead = document.getElementById('securityAccountHead');
    const amountInput = document.getElementById('securityAmountInput');
    const subTotal = document.getElementById('subTotal');
    const gstPercent = document.getElementById('gstPercent');
    const gstAmount = document.getElementById('gstAmount');
    const billAmount = document.getElementById('billAmount');
    const tdsPercent = document.getElementById('tdsPercent');
    const tdsAmount = document.getElementById('tdsAmount');
    const securityDepositPercent = document.getElementById('securityDepositPercent');
    const securityDepositAmount = document.getElementById('securityDepositAmount');
    const netPaymentInput = document.getElementById('netPaymentInput');
    const narration = document.getElementById('securityNarration');

    let editingCard = null;

    function formatAmount(value) {
        const number = Number(value || 0);
        return number.toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function formatDate(value) {
        if (!value) return '';
        const parts = value.split('-');
        if (parts.length !== 3) return value;
        return parts[2] + '-' + parts[1] + '-' + parts[0];
    }

    function numberToWords(num) {
        const a = ['', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ', 'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '];
        const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
        if ((num = num.toString()).length > 9) return 'overflow';
        const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) return '';
        let str = '';
        str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
        str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
        str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
        str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
        str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only ' : 'Only ';
        return str.trim();
    }

    function calculateValues(data) {
        const amount = Number(data.amount || 0);
        const gstValue = Number(data.gst || 0);
        const tdsValue = Number(data.tds || 0);
        const securityDepositValue = Number(data.securityDeposit || 0);

        const gstAmountValue = amount * gstValue / 100;
        const billAmountValue = amount + gstAmountValue;
        const tdsAmountValue = billAmountValue * tdsValue / 100;
        const securityDepositAmountValue = billAmountValue * securityDepositValue / 100;
        const netPaymentValue = billAmountValue - tdsAmountValue - securityDepositAmountValue;

        return {
            amount: amount,
            gstAmount: gstAmountValue,
            billAmount: billAmountValue,
            tdsAmount: tdsAmountValue,
            securityDepositAmount: securityDepositAmountValue,
            netPayment: netPaymentValue
        };
    }

    function calculateBill() {
        const amount = Number(amountInput.value || 0);
        const gstValue = Number(gstPercent.value || 0);
        const tdsValue = Number(tdsPercent.value || 0);
        const securityDepositValue = Number(securityDepositPercent.value || 0);

        const gstAmountValue = amount * gstValue / 100;
        const billAmountValue = amount + gstAmountValue;
        const tdsAmountValue = billAmountValue * tdsValue / 100;
        const securityDepositAmountValue = billAmountValue * securityDepositValue / 100;
        const netPaymentValue = billAmountValue - tdsAmountValue - securityDepositAmountValue;

        subTotal.value = amount.toFixed(2);
        gstAmount.value = gstAmountValue.toFixed(2);
        billAmount.value = billAmountValue.toFixed(2);
        tdsAmount.value = tdsAmountValue.toFixed(2);
        securityDepositAmount.value = securityDepositAmountValue.toFixed(2);
        netPaymentInput.value = netPaymentValue.toFixed(2);
    }

    [amountInput, gstPercent, tdsPercent, securityDepositPercent].forEach(function (element) {
        element.addEventListener('input', calculateBill);
        element.addEventListener('change', calculateBill);
    });

    function resetModal() {
        editingCard = null;
        document.getElementById('newSecurityBillModalLabel').textContent = 'CREATE BILL PASSING CHECK LIST';
        saveText.textContent = 'Create Material Rental Bill';
        saveButton.style.display = '';

        project.value = '';
        vendor.value = '';
        voucherNo.value = '';
        workOrderNo.value = '';
        agencyBillNo.value = '';
        fromDate.value = '';
        toDate.value = '';
        accountHead.value = '';
        amountInput.value = '0';
        gstPercent.value = '';
        tdsPercent.value = '0';
        securityDepositPercent.value = '0';
        narration.value = '';

        calculateBill();
    }

    function openEditModal(card) {
        editingCard = card;
        document.getElementById('newSecurityBillModalLabel').textContent = 'EDIT BILL PASSING CHECK LIST';
        saveText.textContent = 'Save Changes';
        saveButton.style.display = '';

        project.value = card.dataset.project || '';
        vendor.value = card.dataset.vendor || '';
        voucherNo.value = card.dataset.voucherNo || '';
        workOrderNo.value = card.dataset.workOrderNo || '';
        agencyBillNo.value = card.dataset.agencyBillNo || '';
        fromDate.value = card.dataset.fromDate || '';
        toDate.value = card.dataset.toDate || '';
        accountHead.value = card.dataset.accountHead || '';
        amountInput.value = card.dataset.amount || '0';
        gstPercent.value = card.dataset.gst || '';
        tdsPercent.value = card.dataset.tds || '0';
        securityDepositPercent.value = card.dataset.securityDeposit || '0';
        narration.value = card.dataset.narration || '';

        calculateBill();
        modal.show();
    }

    function getFormData() {
        return {
            billNo: voucherNo.value.trim() || workOrderNo.value.trim() || 'BILL-' + Date.now(),
            project: project.value,
            vendor: vendor.value,
            voucherNo: voucherNo.value.trim(),
            workOrderNo: workOrderNo.value.trim(),
            agencyBillNo: agencyBillNo.value.trim(),
            fromDate: fromDate.value,
            toDate: toDate.value,
            accountHead: accountHead.value.trim(),
            amount: Number(amountInput.value || 0),
            gst: Number(gstPercent.value || 0),
            tds: Number(tdsPercent.value || 0),
            securityDeposit: Number(securityDepositPercent.value || 0),
            narration: narration.value.trim()
        };
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function createCard(data) {
        const column = document.createElement('div');
        column.className = 'col-12 security-bill-card';
        column.dataset.billNo = data.billNo || '';
        column.dataset.project = data.project || '';
        column.dataset.vendor = data.vendor || '';
        column.dataset.voucherNo = data.voucherNo || '';
        column.dataset.workOrderNo = data.workOrderNo || '';
        column.dataset.agencyBillNo = data.agencyBillNo || '';
        column.dataset.fromDate = data.fromDate || '';
        column.dataset.toDate = data.toDate || '';
        column.dataset.accountHead = data.accountHead || '';
        column.dataset.amount = data.amount || 0;
        column.dataset.gst = data.gst || 0;
        column.dataset.tds = data.tds || 0;
        column.dataset.securityDeposit = data.securityDeposit || 0;
        column.dataset.narration = data.narration || '';

        const values = calculateValues(data);

        column.innerHTML = `
            <div class="card border rounded-3 shadow-sm bg-white">
                <div class="card-body p-3">
                    <div class="security-card-layout">
                        <div class="security-card-left">
                            <div class="d-flex align-items-center mb-2">
                                <span class="security-bill-number">${escapeHtml(data.billNo)}</span>
                            </div>
                            <h6 class="vendor-title security-vendor">${escapeHtml(data.vendor)}</h6>
                            <div class="security-project">${escapeHtml(data.project)}</div>
                        </div>
                        <div class="security-card-right">
                            <div class="security-card-actions">
                                <button type="button" class="security-view-btn" title="View Bill"><i class="mdi mdi-eye-outline"></i></button>
                                <button type="button" class="security-edit-btn" title="Edit Bill"><i class="mdi mdi-pencil"></i></button>
                                <button type="button" class="security-delete-btn" title="Delete Bill"><i class="mdi mdi-delete-outline"></i></button>
                            </div>
                            <div class="security-payment-box">
                                <span class="security-net-label">Net Payment</span>
                                <div class="security-net-payment-display">$${formatAmount(values.netPayment)}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('securityBillCards').appendChild(column);
        return column;
    }

    function updateCard(card, data) {
        card.dataset.billNo = data.billNo;
        card.dataset.project = data.project;
        card.dataset.vendor = data.vendor;
        card.dataset.voucherNo = data.voucherNo;
        card.dataset.workOrderNo = data.workOrderNo;
        card.dataset.agencyBillNo = data.agencyBillNo;
        card.dataset.fromDate = data.fromDate;
        card.dataset.toDate = data.toDate;
        card.dataset.accountHead = data.accountHead;
        card.dataset.amount = data.amount;
        card.dataset.gst = data.gst;
        card.dataset.tds = data.tds;
        card.dataset.securityDeposit = data.securityDeposit;
        card.dataset.narration = data.narration;

        const values = calculateValues(data);
        card.querySelector('.security-bill-number').textContent = data.billNo;
        card.querySelector('.security-vendor').textContent = data.vendor;
        card.querySelector('.security-project').textContent = data.project;
        card.querySelector('.security-net-payment-display').textContent = '$' + formatAmount(values.netPayment);
    }

    function getDataFromCard(card) {
        return {
            billNo: card.dataset.billNo || '',
            project: card.dataset.project || '',
            vendor: card.dataset.vendor || '',
            voucherNo: card.dataset.voucherNo || '',
            workOrderNo: card.dataset.workOrderNo || '',
            agencyBillNo: card.dataset.agencyBillNo || '',
            fromDate: card.dataset.fromDate || '',
            toDate: card.dataset.toDate || '',
            accountHead: card.dataset.accountHead || '',
            amount: Number(card.dataset.amount || 0),
            gst: Number(card.dataset.gst || 0),
            tds: Number(card.dataset.tds || 0),
            securityDeposit: Number(card.dataset.securityDeposit || 0),
            narration: card.dataset.narration || ''
        };
    }

    function openViewModal(card) {
        const data = getDataFromCard(card);
        const values = calculateValues(data);

        document.getElementById('voucherProject').textContent = data.project;
        document.getElementById('voucherVoucherNo').textContent = data.voucherNo;
        document.getElementById('voucherDate').textContent = formatDate(data.fromDate);
        document.getElementById('voucherAgencyName').textContent = data.vendor;
        document.getElementById('voucherGstNo').textContent = '';
        document.getElementById('voucherPanNo').textContent = '';
        document.getElementById('voucherWorkOrderNo').textContent = data.workOrderNo;
        document.getElementById('voucherAgencyBillNo').textContent = data.agencyBillNo;
        document.getElementById('voucherAccountHead').textContent = data.accountHead;
        document.getElementById('voucherTdsPercent').textContent = data.tds.toFixed(2);
        document.getElementById('voucherTdsBase').textContent = formatAmount(values.billAmount);
        document.getElementById('voucherSecurityPercent').textContent = data.securityDeposit.toFixed(2);
        document.getElementById('voucherSecurityBase').textContent = formatAmount(values.billAmount);
        document.getElementById('voucherAmountInWords').textContent = numberToWords(Math.round(values.netPayment)) + ' Rupees Only';
        document.getElementById('voucherNarration').textContent = data.narration;
        document.getElementById('voucherFromDate').textContent = formatDate(data.fromDate);
        document.getElementById('voucherToDate').textContent = formatDate(data.toDate);
        document.getElementById('voucherDr').textContent = formatAmount(values.billAmount);
        document.getElementById('voucherSubTotal').textContent = formatAmount(values.amount);
        document.getElementById('voucherCgst').textContent = formatAmount(values.gstAmount / 2);
        document.getElementById('voucherSgst').textContent = formatAmount(values.gstAmount / 2);
        document.getElementById('voucherBillAmt').textContent = formatAmount(values.billAmount);
        document.getElementById('voucherTdsAmount').textContent = formatAmount(values.tdsAmount);
        document.getElementById('voucherSecurityAmount').textContent = formatAmount(values.securityDepositAmount);
        document.getElementById('voucherPassForPayment').textContent = formatAmount(values.netPayment);

        const viewModalElement = document.getElementById('viewSecurityBillModal');
        const viewModal = bootstrap.Modal.getOrCreateInstance(viewModalElement);
        viewModal.show();
    }

    function filterBills() {
        const searchValue = document.getElementById('securityBillSearch').value.trim().toLowerCase();
        const selectedProject = document.getElementById('securityProjectFilter').value;
        const selectedVendor = document.getElementById('securityVendorFilter').value;

        const cards = document.querySelectorAll('.security-bill-card');

        cards.forEach(function (card) {
            const searchableText = [card.dataset.billNo, card.dataset.project, card.dataset.vendor].join(' ').toLowerCase();
            const matchesSearch = !searchValue || searchableText.includes(searchValue);
            const matchesProject = !selectedProject || card.dataset.project === selectedProject;
            const matchesVendor = !selectedVendor || card.dataset.vendor === selectedVendor;

            card.style.display = matchesSearch && matchesProject && matchesVendor ? '' : 'none';
        });
    }

    document.addEventListener('click', function (event) {
        const editButton = event.target.closest('.security-edit-btn');
        const viewButton = event.target.closest('.security-view-btn');
        const deleteButton = event.target.closest('.security-delete-btn');

        if (editButton) {
            const card = editButton.closest('.security-bill-card');
            if (card) openEditModal(card);
        }

        if (viewButton) {
            const card = viewButton.closest('.security-bill-card');
            if (card) openViewModal(card);
        }

        if (deleteButton) {
            const card = deleteButton.closest('.security-bill-card');
            if (!card) return;
            const billNo = card.dataset.billNo;
            const confirmed = confirm('Are you sure you want to delete ' + billNo + '?');
            if (!confirmed) return;
            card.remove();
            filterBills();
        }
    });

    newButton.addEventListener('click', function () {
        resetModal();
    });

    saveButton.addEventListener('click', function () {
        const data = getFormData();

        if (!data.project) { alert('Please select Project.'); return; }
        if (!data.vendor) { alert('Please select Vendor.'); return; }
        if (!data.voucherNo) { alert('Please enter Voucher No.'); return; }
        if (!data.workOrderNo) { alert('Please enter Work Order No.'); return; }
        if (!data.fromDate) { alert('Please select From Date.'); return; }
        if (!data.toDate) { alert('Please select To Date.'); return; }
        if (!data.accountHead) { alert('Please enter Account Head.'); return; }
        if (!data.amount) { alert('Please enter Amount.'); return; }
        if (!data.gst) { alert('Please select GST %.'); return; }

        if (editingCard) {
            updateCard(editingCard, data);
        } else {
            createCard(data);
        }

        modal.hide();
        filterBills();
    });

    const searchInput = document.getElementById('securityBillSearch');
    const projectFilter = document.getElementById('securityProjectFilter');
    const vendorFilter = document.getElementById('securityVendorFilter');

    if (searchInput) searchInput.addEventListener('input', filterBills);
    if (projectFilter) projectFilter.addEventListener('change', filterBills);
    if (vendorFilter) vendorFilter.addEventListener('change', filterBills);

    const initialBills = [
        {
            billNo: 'WO-2026-CCB-012',
            project: 'Commercial Complex - Block',
            vendor: 'UltraTech Cement Ltd',
            voucherNo: 'VP-2026-0045',
            workOrderNo: 'WO-2026-CCB-012',
            agencyBillNo: 'AB-2026-112',
            fromDate: '2025-06-01',
            toDate: '2025-06-30',
            accountHead: 'Civil Construction Work',
            amount: 500000.00,
            gst: 18,
            tds: 2,
            securityDeposit: 5,
            narration: 'Running bill for RCC slab and masonry work for Phase II building.'
        },
        {
            billNo: '003',
            project: 'Solar Power Plant Installation',
            vendor: 'PowerLine Electricals',
            voucherNo: 'VCH-002',
            workOrderNo: '003',
            agencyBillNo: 'AG-002',
            fromDate: '2026-07-01',
            toDate: '2026-07-31',
            accountHead: 'Material Purchase',
            amount: 526752.00,
            gst: 18,
            tds: 2,
            securityDeposit: 5,
            narration: 'Solar panels'
        },
        {
            billNo: '002',
            project: 'Smart City Drainage Upgrade',
            vendor: 'TechNova Solutions Pvt Ltd',
            voucherNo: 'VCH-003',
            workOrderNo: '002',
            agencyBillNo: 'AG-003',
            fromDate: '2026-06-01',
            toDate: '2026-06-30',
            accountHead: 'Material Purchase',
            amount: 823050.00,
            gst: 18,
            tds: 2,
            securityDeposit: 5,
            narration: 'Drainage pipes'
        },
        {
            billNo: '001',
            project: 'Industrial Warehouse Construction',
            vendor: 'ABC Heavy Equipments Pvt Ltd',
            voucherNo: 'VCH-004',
            workOrderNo: '001',
            agencyBillNo: 'AG-004',
            fromDate: '2026-06-01',
            toDate: '2026-06-30',
            accountHead: 'Material Purchase',
            amount: 548700.00,
            gst: 18,
            tds: 2,
            securityDeposit: 5,
            narration: 'Steel structures'
        },
        {
            billNo: '20',
            project: 'KWRP',
            vendor: 'SK Construction',
            voucherNo: 'VCH-005',
            workOrderNo: '20',
            agencyBillNo: 'AG-005',
            fromDate: '2026-05-01',
            toDate: '2026-05-31',
            accountHead: 'Material Purchase',
            amount: 1296295.35,
            gst: 18,
            tds: 2,
            securityDeposit: 5,
            narration: 'Construction material'
        }
    ];

    initialBills.forEach(function (bill) {
        createCard(bill);
    });

    calculateBill();
});
</script>

@endsection