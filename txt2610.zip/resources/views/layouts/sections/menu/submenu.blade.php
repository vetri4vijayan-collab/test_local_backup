<style>
  .menu-sub.menu-sub-line {
    position: relative;
    margin-left: 1.25rem;   // ml-5
    padding-left: 1rem;     // pl-4
    margin-top: 0.25rem;
    border-left: 1px solid rgba(94, 97, 104, 0.4);

    // Kill the theme's default ::before dot/pill on submenu links
    > .menu-item > .menu-link::before {
      display: none !important;
      content: none !important;
    }

    // Reset any left padding the theme adds to make room for the dot,
    // since the line now sits outside the <ul> instead of per-item.
    > .menu-item > .menu-link {
      padding-left: 0.5rem;
    }

    // Nested submenus (e.g. a 3rd level) get their own line, indented further
    .menu-sub.menu-sub-line {
      margin-left: 0.75rem;
    }
  }
</style>

@php
  use Illuminate\Support\Str;

  $currentRouteName = Route::currentRouteName();
  $configData = Helper::appClasses();
  $isVertical = ($configData['layout'] ?? 'vertical') === 'vertical';
@endphp

<ul class="menu-sub menu-sub-line">
  @if (isset($menu))
    @foreach ($menu as $submenu)
      @php
        $slugs = is_array($submenu->slug ?? null) ? $submenu->slug : [$submenu->slug ?? null];
        $hasSubmenu = isset($submenu->submenu);

        $isExactMatch = in_array($currentRouteName, $slugs, true);

        // Prefix match only against a real dotted boundary, so a slug
        // never falsely matches an unrelated sibling with a shared prefix.
        $isDescendantMatch = false;
        foreach ($slugs as $slug) {
          if ($slug && Str::startsWith($currentRouteName, $slug . '.')) {
            $isDescendantMatch = true;
            break;
          }
        }

        $activeClass = null;
        if ($isExactMatch) {
          $activeClass = 'active';
        } elseif ($hasSubmenu && $isDescendantMatch) {
          $activeClass = $isVertical ? 'active open' : 'active';
        }
      @endphp

      <li class="menu-item {{ $activeClass }}">
        <a href="{{ isset($submenu->url) ? url($submenu->url) : 'javascript:void(0)' }}"
           class="{{ $hasSubmenu ? 'menu-link menu-toggle' : 'menu-link' }}"
           @if (!empty($submenu->target)) target="_blank" @endif>
          @if (isset($submenu->icon))
            <i class="{{ $submenu->icon }} me-1"></i>
          @endif
          <div class="fs-7 fw-medium">{{ isset($submenu->name) ? __($submenu->name) : '' }}</div>
          @isset($submenu->badge)
            <div class="badge bg-{{ $submenu->badge[0] }} rounded-pill ms-auto">{{ $submenu->badge[1] }}</div>
          @endisset
        </a>

        @if ($hasSubmenu)
          @include('layouts.sections.menu.submenu', ['menu' => $submenu->submenu])
        @endif
      </li>
    @endforeach
  @endif
</ul>