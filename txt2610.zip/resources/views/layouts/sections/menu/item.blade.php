@php
    use Illuminate\Support\Str;

    $currentRouteName = Route::currentRouteName();
    $configData = Helper::appClasses();
    $isVertical = ($configData['layout'] ?? 'vertical') === 'vertical';

    /*
    |--------------------------------------------------------------------------
    | Recursive active route checker
    |--------------------------------------------------------------------------
    */
    $isItemActive = function ($item) use (&$isItemActive, $currentRouteName) {

        $slugs = is_array($item->slug ?? null)
            ? $item->slug
            : [$item->slug ?? null];

        // Exact match
        foreach ($slugs as $slug) {
            if ($slug && $currentRouteName === $slug) {
                return true;
            }
        }

        // Check all children recursively
        if (isset($item->submenu)) {
            foreach ($item->submenu as $child) {
                if ($isItemActive($child)) {
                    return true;
                }
            }
        }

        return false;
    };
@endphp


@foreach ($items as $item)

    @php
        $hasSubmenu = isset($item->submenu);

        /*
        |--------------------------------------------------------------------------
        | Determine whether this item or any child is active
        |--------------------------------------------------------------------------
        */
        $isActive = $isItemActive($item);

        /*
        |--------------------------------------------------------------------------
        | Exact match for this particular item
        |--------------------------------------------------------------------------
        */
        $slugs = is_array($item->slug ?? null)
            ? $item->slug
            : [$item->slug ?? null];

        $isExactMatch = false;

        foreach ($slugs as $slug) {
            if ($slug && $currentRouteName === $slug) {
                $isExactMatch = true;
                break;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Parent with active child
        |--------------------------------------------------------------------------
        */
        $activeClass = null;

        if ($isExactMatch) {

            $activeClass = 'active';

        } elseif ($hasSubmenu && $isActive) {

            $activeClass = $isVertical
                ? 'active open'
                : 'active';
        }
    @endphp


    <li class="menu-item {{ $activeClass }}">

        <a
            href="{{ isset($item->url) ? url($item->url) : 'javascript:void(0)' }}"
            class="{{ $hasSubmenu ? 'menu-link menu-toggle' : 'menu-link' }}"
            @if (!empty($item->target)) target="_blank" @endif
        >

            @if (isset($item->icon))
                <i class="{{ $item->icon }} me-1"></i>
            @endif

            <div class="d-flex flex-column">

                <span class="fs-7 fw-medium">
                    {{ __($item->name) }}
                </span>

                @isset($item->desc)
                    <span
                        class="menu-item-desc"
                        style="font-size: 10px; line-height: 1; opacity: .6;"
                    >
                        {{ $item->desc }}
                    </span>
                @endisset

            </div>

            @isset($item->badge)
                <div class="badge bg-{{ $item->badge[0] }} rounded-pill ms-auto">
                    {{ $item->badge[1] }}
                </div>
            @endisset

        </a>


        @if ($hasSubmenu)

            @include('layouts.sections.menu.submenu', [
                'menu' => $item->submenu
            ])

        @endif

    </li>

@endforeach