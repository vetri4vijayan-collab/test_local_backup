
<?php
  // merged-vertical-menu.php
  // This file combines both main menu and submenu functionality

  $configData = Helper::appClasses();
?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" style="background-color: #0F172B !important;">

    <!-- ! Hide app brand if navbar-full -->
    <?php if(!isset($navbarFull)): ?>
        <div class="app-brand demo">
            <a href="{{ url('/dashboards') }}" class="app-brand-link">
                <?php if(isset($logoUrl)): ?>
                <img id="logo-left" src="{{ asset('assets/phdizone_images/phdizone_icon.png') }}" class=""
                    width="55px"alt="M Logo">
                <!-- Image for Right (Compact state) - Initially hidden -->
                <img id="logo-right" src="<?= $logoUrl ?>" class="" width="200px" height="70px" alt="L Logo"
                    style="display: none;">
                <?php else: ?>
                <!-- Display a placeholder image or default logo if $logoUrl is not available -->
                <img id="logo-left" src="{{ asset('assets/phdizone_images/phdizone_icon.png') }}" class=""
                    width="45" alt="Logo">
                <img id="logo-right" src="{{ asset('logos/35810.png') }}" class="app-brand-text demo" width="200px"
                    height="70" alt="Logo">
                <?php endif; ?>
            </a>
            <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto">
                <span class="mdi mdi-chevron-double-right text-white fs-3"></span>
            </a>
        </div>
    <?php endif; ?>

    <!-- <div class="menu-inner-shadow"></div> -->

    <ul class="menu-inner py-1 mb-9">
        <?php foreach ($menuData[0]->menu as $menu): ?>

        <?php if(auth()->user()->hasPermission($menu->name)): ?>

        <?php // adding active and open class if child is active ?>
        <?php // menu headers ?>
        <?php if (isset($menu->menuHeader)): ?>
            <li class="menu-header fw-medium mt-4">
                <span class="menu-header-text"><?= __($menu->menuHeader) ?></span>
            </li>
        <?php else: ?>
            <?php // active menu method ?>
            <?php
              $isAISuggestion = $menu->name === 'AI Suggestion';
              $isElearningPortal = $menu->name === 'Elearning Portal';
              $isExamPortal = $menu->name === 'Exam Portal';
              $activeClass = null;
              $currentRouteName = Route::currentRouteName();

              if ($currentRouteName === $menu->slug) {
                    if ($isAISuggestion) {
                        $activeClass = 'bg-info bg-opacity-25 text-info rounded';
                    } elseif ($isElearningPortal) {
                        $activeClass = 'bg-warning bg-opacity-25 text-dark rounded';
                    } elseif ($isExamPortal) {
                        $activeClass = 'bg-warning bg-opacity-25 text-dark rounded';
                    } else {
                        $activeClass = 'active';
                    }
              } elseif (isset($menu->submenu)) {
                  if (gettype($menu->slug) === 'array') {
                      foreach($menu->slug as $slug){
                          if (str_contains($currentRouteName,$slug) and strpos($currentRouteName,$slug) === 0) {
                              $activeClass = 'active open';
                          }
                      }
                  } else {
                      if (str_contains($currentRouteName,$menu->slug) and strpos($currentRouteName,$menu->slug) === 0) {
                          $activeClass = 'active open';
                      }
                  }
              }
            ?>

           <?php // main menu ?>
            <li class="menu-item <?= $activeClass ?>">
                <a href="<?= isset($menu->url) ? url($menu->url) : 'javascript:void(0);' ?>"
                    class="<?= isset($menu->submenu) ? 'menu-link menu-toggle' : 'menu-link' ?>"
                    <?php if (isset($menu->target) && !empty($menu->target)): ?> target="_blank" <?php endif; ?>>

                    <?php if(isset($menu->icon)): ?>
                        <i class="<?= $menu->icon ?>"></i>
                    <?php endif; ?>

                    <div class="fs-7 fw-medium d-flex align-items-center">
                        <?php if ($isAISuggestion): ?>
                            <span class="fs-6 badge bg-info text-white px-2 py-1 rounded-pill glow-badge_sidebar">
                                <?= __($menu->name) ?>
                                <img src="<?= asset('assets/eapl_images/Bulb.gif') ?>" class="w-35px h-35px mb-1" />
                            </span>
                        <?php elseif ($isElearningPortal): ?>
                            <span class="btn btn-sm  text-white fw-bold px-3 fs-6 py-1  shadow-sm"  style="background-color: #e141cc;">
                                <?= __($menu->name) ?>
                                <i class="mdi mdi-open-in-new ms-1 text-white"></i> <?php // Optional icon ?>
                            </span>
                        <?php elseif ($isExamPortal): ?>
                            <span class="btn btn-sm  text-white fw-bold px-3 fs-6 py-1  shadow-sm"  style="background-color: #e14141;">
                                <?= __($menu->name) ?>
                                <i class="mdi mdi-open-in-new ms-1 text-white"></i> <?php // Optional icon ?>
                            </span>
                        <?php else: ?>
                            <?= __($menu->name) ?>
                        <?php endif; ?>
                    </div>

                    <?php if(isset($menu->badge)): ?>
                        <div class="badge bg-<?= $menu->badge[0] ?> rounded-pill ms-auto"><?= $menu->badge[1] ?></div>
                    <?php endif; ?>
                </a>

                <?php // submenu ?>
                <?php if(isset($menu->submenu)): ?>
                    <ul class="menu-sub">
                        <?php foreach ($menu->submenu as $submenu): ?>
                            <?php if (auth()->user()->hasPermission($menu->name, null, $submenu->name)): ?>
                                <?php
                                $activeClass = null;
                                $active = $configData["layout"] === 'vertical' ? 'active open':'active';
                                $currentRouteName = Route::currentRouteName();

                                if ($currentRouteName === $submenu->slug) {
                                    $activeClass = 'active';
                                } elseif (isset($submenu->submenu)) {
                                    if (gettype($submenu->slug) === 'array') {
                                        foreach($submenu->slug as $slug){
                                            if (str_contains($currentRouteName,$slug) and strpos($currentRouteName,$slug) === 0) {
                                                $activeClass = $active;
                                            }
                                        }
                                    } else {
                                        if (str_contains($currentRouteName,$submenu->slug) and strpos($currentRouteName,$submenu->slug) === 0) {
                                            $activeClass = $active;
                                        }
                                    }
                                }
                                ?>

                              @php
                                
 
                                // Default link class
                                $linkClass = isset($submenu->submenu) ? 'menu-link menu-toggle' : 'menu-link';
 
                                // Default active
                                $activeMenuClass = $activeClass;
 
                                // Special condition for Schedule Daily Call
                                
                            @endphp
 
                            <li class="menu-item {{ $submenu->name === 'Schedule Daily Call' ? '' : $activeMenuClass }}"
                                    data-menu-name="{{ $submenu->name }}" >
 
                                <a href="{{ isset($submenu->url) ? url($submenu->url) : 'javascript:void(0);' }}"
                                  class="{{ $linkClass }} {{ $submenu->name === 'Schedule Daily Call' ? $activeMenuClass : '' }}"
                                  @if(isset($submenu->target) && !empty($submenu->target)) target="_blank" @endif>
 
                                    @if(isset($submenu->icon))
                                        <i class="{{ $submenu->icon }}"></i>
                                    @endif
 
                                    <div class="fs-7 fw-medium">
                                        {{ $submenu->name }}
                                        @if($submenu->name === 'Schedule Daily Call')

                                            <span
                                                class="badge bg-light text-danger ms-1 menu-count-badge"
                                                data-menu-count="{{ $submenu->name }}"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Count"
                                                style="display:none;">
                                            </span>

                                        @else

                                            <span
                                                class="animated-badge menu-count-badge"
                                                data-menu-count="{{ $submenu->name }}"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Count"
                                                style="display:none;">
                                            </span>

                                        @endif
                                    </div>
 
                                    @if(isset($submenu->badge))
                                        <div class="badge bg-{{ $submenu->badge[0] }} rounded-pill ms-auto">
                                            {{ $submenu->badge[1] }}
                                        </div>
                                    @endif
 
                                </a>
                            </li>
                                
                                
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; ?>
    </ul>
</aside>

<style>
    .fw-medium {
        overflow: visible !important;
        position: relative;
    }

    .animated-badge {
        position: absolute;
        top: -3px;
        /* Adjust as needed */
        right: -38px;
        /* Adjust as needed */
        padding: 2px 6px;
        background-color: #fa3f2d;
        /* Vibrant green color */
        color: #fff;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: bold;
        animation: blinkAnimation 1.5s infinite ease-in-out;
        /* Blink animation */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        z-index: 10;
    }

    .animated-badge-success {
        position: absolute;
        top: -3px;
        /* Adjust as needed */
        right: -55px;
        /* Adjust as needed */
        padding: 2px 6px;
        background-color: #50cd89;
        /* Vibrant green color */
        color: #fff;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: bold;
        animation: blinkAnimation 1.5s infinite ease-in-out;
        /* Blink animation */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        z-index: 10;
    }

    /* Blink animation keyframes */
    @keyframes blinkAnimation {

        0%,
        100% {
            opacity: 1;
            transform: scale(1);
        }

        50% {
            opacity: 0.6;
            transform: scale(1.1);
        }
    }
</style>
<script>
      document.addEventListener("DOMContentLoaded", function() {
        const html = document.documentElement;
        const toggleButton = document.querySelector('.layout-menu-toggle');
        const logoLeft = document.getElementById('logo-right'); // big
        const logoRight = document.getElementById('logo-left'); // small

        if (!logoLeft || !logoRight) return;

        // Decide which logo to show based on classes:
        // - if NOT collapsed -> big logo
        // - if collapsed AND hovered (layout-menu-hover) -> big logo
        // - if collapsed AND NOT hovered -> small logo
        function updateLogos() {
            const collapsed = html.classList.contains('layout-menu-collapsed');
            const hovered = html.classList.contains('layout-menu-hover');

            if (!collapsed) {
                // expanded -> show big
                logoLeft.style.display = 'block';
                logoRight.style.display = 'none';
            } else {
                // collapsed
                if (hovered) {
                    // collapsed but hovered -> show big
                    logoLeft.style.display = 'block';
                    logoRight.style.display = 'none';

                } else {
                    // collapsed and not hovered -> show small
                    logoLeft.style.display = 'none';
                    logoRight.style.display = 'block';
                }
            }
        }

        // Initial set
        updateLogos();

        // Toggle button may change classes after an animation; allow slight delay
        if (toggleButton) {
            toggleButton.addEventListener('click', function() {
                setTimeout(updateLogos, 120); // small delay to let template update classes
            });
        }

        // MutationObserver to watch for class changes on <html>
        const mo = new MutationObserver((mutations) => {
            for (const m of mutations) {
                if (m.type === 'attributes' && m.attributeName === 'class') {
                    updateLogos();
                    break;
                }
            }
        });

        mo.observe(html, {
            attributes: true,
            attributeFilter: ['class']
        });

        // Optional: clean up when page unloads
        window.addEventListener('beforeunload', () => mo.disconnect());
    });
</script>
