{{-- resources/views/partials/settings-site_sidebar.blade.php --}}

<div class="col-12 col-lg-3">
    <div class="card h-100">
        <div class="card-body p-2">
            <ul class="nav nav-pills flex-column w-100 gap-1 settings-nav">
                {{-- Structure Type --}}
                <li clsss="nav-item w-100">
                    <a href="{{ Route::has('settings-structure-setting') ? route('settings-structure-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-structure-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-office-building-outline fs-4"></i>
                        <span class="fw-semibold text-start">
                            Structure Type
                        </span>
                    </a>
                </li>


                {{-- Structure Type Item --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-structuretypeitem-setting') ? route('settings-structuretypeitem-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-structuretypeitem-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-format-list-bulleted-type fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Structure Type Item
                        </span>
                    </a>
                </li>


                {{-- Vendor Type --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-vendor-setting') ? route('settings-vendor-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-vendor-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-store-cog-outline fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Vendor Type
                        </span>
                    </a>
                </li>


                {{-- Contractor Type --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-contractor-setting') ? route('settings-contractor-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-contractor-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-hard-hat fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Contractor Type
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

</div>


@push('styles')

<style>
/* =======
   CONSTRUCTION SETTINGS SIDEBAR
   ======= */

.settings-sidebar {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    box-sizing: border-box;
}


/* =======
   UL
   ======= */

.settings-sidebar ul {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}


/* =======
   LI
   ======= */

.settings-sidebar ul li {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}


/* =======
   LINK
   ======= */

.settings-sidebar ul li a {
    display: flex;
    align-items: center;

    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;

    padding: 8px 10px;
    gap: 8px;

    text-decoration: none;
    white-space: nowrap;

    overflow: hidden;
}


/* =======
   ICON
   ======= */

.settings-sidebar ul li a i {
    flex: 0 0 18px;

    width: 18px;
    min-width: 18px;

    text-align: center;
}


/* =======
   TEXT
   ======= */

.settings-sidebar ul li a span {
    flex: 1 1 auto;

    width: auto;
    min-width: 0;
    max-width: 100%;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;

    text-align: left;
}


/* =======
   ACTIVE
   ======= */

.settings-sidebar ul li a.active {
    width: 100%;
    max-width: 100%;
}


/* =======
   CARD
   ======= */

.settings-sidebar .card {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}


/* =======
   CARD BODY
   ======= */

.settings-sidebar .card-body {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}


/* =======
   DESKTOP
   ======= */

@media (min-width: 992px) {

    .settings-sidebar {
        width: 100%;
        max-width: 100%;
        min-width: 0;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px;
    }

}


/* =======
   TABLET
   ======= */

@media (max-width: 991.98px) {

    .settings-sidebar,
    .settings-sidebar .card,
    .settings-sidebar .card-body,
    .settings-sidebar ul,
    .settings-sidebar ul li,
    .settings-sidebar ul li a {

        width: 100%;
        max-width: 100%;
        min-width: 0;

    }

}


/* =======
   MOBILE
   ======= */

@media (max-width: 575.98px) {

    .settings-sidebar .card-body {
        padding: 8px !important;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px !important;
        gap: 6px !important;
    }

    .settings-sidebar ul li a i {
        flex: 0 0 18px;
        width: 18px;
        min-width: 18px;
    }

    .settings-sidebar ul li a span {
        font-size: 14px;
    }

}
</style>

@endpush
