@php
    // Central tab registry — add a new settings page by adding one line here.
    $settingsTabs = [
        ['key' => 'payslip',     'label' => 'Payslip Type', 'route' => 'settings-payslip-type', 'icon'  => 'mdi-cash-sync',],
        ['key' => 'ledger',      'label' => 'Ledger Head',       'route' => 'settings-ledger', 'icon' => 'mdi-invoice-text-clock-outline'],
        ['key' => 'sub-ledger',  'label' => 'Sub Ledger Head',   'route' => 'settings-sub-ledger', 'icon' => 'mdi-file-sign'],
    ];

    $activeTab = $activeTab ?? 'payslip';
@endphp

<div class="col-12 col-lg-3 settings-sidebar">
    <div class="card h-100">
        <div class="card-body p-2">

            <ul class="nav nav-pills flex-column w-100 gap-1 settings-nav">
                {{-- Dynamic Settings Tabs --}}
                @foreach ($settingsTabs as $tab)

                    <li class="nav-item w-100">
                        <a href="{{ Route::has($tab['route']) 
                            ? route($tab['route']) 
                            : 'javascript:void(0);' }}"
                            class="nav-link {{ request()->routeIs($tab['route']) ? 'active' : 'text-muted' }}
                            d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                            <i class="mdi {{ $tab['icon']}} fs-4"></i>

                            <span class="fw-semibold text-start">
                                {{ $tab['label'] }}
                            </span>

                        </a>
                    </li>

                @endforeach

            </ul>

        </div>
    </div>
</div>