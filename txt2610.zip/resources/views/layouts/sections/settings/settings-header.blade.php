@php
  // Central tab registry — add a new settings page by adding one line here.
  $settingsTabs = [
    ['key' => 'general',     'label' => 'General Settings',        'route' => 'settings-general-settings'],
    ['key' => 'rbac',        'label' => 'Users & Roles',  'route' => 'settings-user-role'],
    ['key' => 'common', 'label' => 'Common Settings','route' => 'settings-common-setting'],
    ['key' => 'admin_hr', 'label' => 'Admin & HR', 'route' => 'settings-department-setting'],
    ['key' => 'site_log', 'label' => 'Site Log', 'route' => 'settings-structure-setting'],
    ['key' => 'accounts', 'label' => 'Accounts', 'route' => 'settings-payslip-type'],
    ['key' => 'purchase', 'label' => 'Store & Purchase', 'route' => 'settings-material-type'],
    ['key' => 'machinery', 'label' => 'Plant & Machinery', 'route' => 'settings-machinery-type'],
  ];

  $activeTab = $activeTab ?? 'general';
@endphp

<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-cog-outline"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Central System Configuration Panel' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Configure corporate workflows, role authorizations, and automated telemetry parameters' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="settingsTabScroller">
          @foreach ($settingsTabs as $tab)
            <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}"
               class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}">
              {{ $tab['label'] }}
            </a>
          @endforeach
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>

<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('settingsTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>