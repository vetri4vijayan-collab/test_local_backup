import { Navigate } from "react-router-dom";
import VendorLogin from "../pages/VendorLogin";
import VendorTermsAcceptance from "../pages/VendorTermsAcceptance";
import VendorSummary from "../components/vendor_dashboard/vendor_summary";
import VendorNotifications from "../pages/VendorNotifications";
import VendorModulePlaceholder from "../pages/VendorModulePlaceholder";
import RolesPermissions from "../pages/Settings/RolesPermissions";
import Users from "../pages/Users";
import ProjectList from "../components/projects/project_list";
import ProjectOverview from "../components/projects/project_overview";
import Projects from "../components/projects/project";
import InvoiceList from "../components/invoices/invoice_list";
import InvoiceGenerate from "../components/invoices/invoice_generate";
import VendorBidsProposals from "../pages/VendorBidsProposals";
import VendorSurveyPack from "../components/SurveyReport/SurveyPack";
import NewQuotation from "../components/quotations/NewQuotation";
import { VendorProjects, VendorInvoices, VendorTasks } from "../pages/VendorWorkflowPages";

export const routes = [
    { path: "/", element: <Navigate to="/vendor-login" replace />, layout: "blank" },
    { path: "/vendor-login", element: <VendorLogin />, layout: "blank" },
    {
        path: "/vendor_terms",
        element: <VendorTermsAcceptance />,
        layout: "blank",
        auth: true,
    },
    {
        path: "/vendor_dashboard",
        element: <VendorSummary />,
        layout: "default",
        auth: true,
    },
    {
        path: "/notifications",
        element: <VendorNotifications />,
        layout: "default",
        auth: true,
    },
    {
         path: "/bids-proposals", element: <VendorBidsProposals />,
    },
    {
        path: "/quotation/edit_quotation",
        element: (
            <NewQuotation
                onBack={() => window.history.back()}
                onOpenMasterRate={() => undefined}
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/quotation/survey-form",
        element: <VendorSurveyPack />,
        layout: "default",
        auth: true,
    },
    {
        path: "/invoices",
        element: <InvoiceList />,
        layout: "default",
        auth: true,
    },
    {
        path: "/invoices/new_invoice",
        element: <InvoiceGenerate />,
        layout: "default",
        auth: true,
    },
    {
        path: "/projects",
        element: <Projects />,
        layout: "default",
        auth: true,
        children: [
            { index: true, element: <ProjectList /> },
            { path: "project_details/:projectId", element: <ProjectOverview /> },
        ],
    },
    {
        path: "/tasks",
         element: <VendorTasks />,
        layout: "default",
        auth: true,
    },
    {
        path: "/user_management",
        element: <Users />,
        layout: "default",
        auth: true,
    },
    {
        path: "/settings/roles_permissions",
        element: <RolesPermissions />,
        layout: "default",
        auth: true,
    },
    { path: "*", element: <Navigate to="/vendor_dashboard" replace />, layout: "default", auth: true },
];
