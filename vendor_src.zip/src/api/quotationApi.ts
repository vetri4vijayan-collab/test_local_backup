import api from "./axios";

function unwrap(response: any) {
    return response?.data?.data ?? response?.data ?? null;
}

export async function listVendorQuotations(params: Record<string, any> = {}) {
    const response = await api.get("/quotations", { params });
    return response.data as { success: boolean; data: any[]; pagination?: any };
}

export async function listQuotationValidityPeriods() {
    const response = await api.get("/quotations/settings/validity-periods");
    return (response.data?.data ?? response.data ?? []) as Array<{
        id: string;
        name: string;
        description?: string;
        days: number;
        status?: boolean;
        sortOrder?: number;
    }>;
}

export async function getVendorQuotation(id: string) {
    return unwrap(await api.get(`/quotations/${id}`)) as any;
}
export async function updateVendorQuotation(id: string, payload: Record<string, any>) {
    return unwrap(await api.patch(`/quotations/${id}`, payload)) as any;
}
export async function getVendorQuotationSurvey(id: string) {
    return unwrap(await api.get(`/quotations/${id}/survey`)) as { quotation: any; template: any; response: any; surveyDate?: string | null };
}
export async function submitVendorQuotationSurvey(id: string, response: Record<string, any>, surveyDate?: string) {
    return unwrap(await api.post(`/quotations/${id}/survey/submit`, { response, surveyDate })) as any;
}
export function toVendorQuotationView(row: any): any {
    if (!row) return row;
    return {
        ...row,
        id: String(row.id ?? row._id),
        quotationNo: row.quotationNo ?? "",
        vendor: row.vendor ?? row.vendorId ?? "",
        vendorName: row.vendorName ?? "",
        projectTitle: row.projectTitle ?? "",
        date: row.date ?? row.dueDate ?? row.quotationDate ?? "",
        grandTotal: Number(row.grandTotal ?? 0),
        currency: row.currency ?? "USD",
        status: row.status ?? "Draft",
        category: row.category ?? "",
        items: Number(row.items ?? row.lines?.length ?? 0),
        validUntil: row.validUntil ?? "",
        createdDate: row.createdDate ?? row.createdAt ?? "",
        clientName: row.clientName ?? "",
        formTemplate: row.formTemplate ?? row.formTemplateName ?? "",
    };
}
