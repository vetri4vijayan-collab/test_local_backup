import api from './axios';

export interface ProjectApiQuery {
  page?: number;
  limit?: number;
  search?: string;
  status?: string;
}

export interface ProjectScopeItemApi {
  id: string;
  type: 'inScope' | 'outOfScope';
  text: string;
  completed: boolean;
}

export interface ProjectDeliverableApi {
  id: string;
  name: string;
  dueDate: string | null;
  completed: boolean;
}

export interface ProjectPhaseApi {
  id: string;
  name: string;
  description: string;
  estimatedHours: number;
  order: number;
}

export interface ProjectTaskApi {
  id: string;
  projectId: string;
  phaseId: string | null;
  phaseName: string;
  title: string;
  name: string;
  description: string;
  ownerIds: string[];
  ownerNames: string[];
  assignedStaff: Array<{ name: string; rate: number; hours: number; amount: number; userId?: string | null }>;
  startDate: string | null;
  dueDate: string | null;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: 'Pending' | 'In Progress' | 'On Hold' | 'Due Date' | 'Completed';
  progress: number;
  estimatedHours: number;
  actualHours: number;
  hourlyRate: number;
  materialCost: number;
  otherExpenses: number;
  timerStartedAt: string | null;
  totalWorkedSeconds: number;
  isTimerRunning: boolean;
  workLogs: Array<{ id: string; startedAt: string; stoppedAt: string; duration: number }>;
  materials: Array<{ id: string; name: string; unitCost: number; quantity: number }>;
  otherExpensesBreakdown: Array<{ id: string; name: string; amount: number; description: string }>;
  comments: Array<{ id: string; type: string; text: string; image?: string | null; createdAt: string; authorName: string }>;
  attachments: Array<{ id: string; name: string; url: string; mimeType: string; size: number; createdAt: string }>;
}

export interface ProjectBudgetApi {
  id: string | null;
  totalAllocation: number;
  utilized: number;
  remaining: number;
  thresholdWarning: number;
  thresholdCritical: number;
  lines: Array<{
    id: string;
    boqLineId: string | null;
    description: string;
    unit: string;
    quantity: number;
    allocatedAmount: number;
    utilizedAmount: number;
    remainingAmount: number;
  }>;
}

export interface ProjectApiModel {
  id: string;
  projectName: string;
  name: string;
  location: string;
  client: string;
  vendorId: string | null;
  vendorName: string;
  managerId: string | null;
  managerName: string;
  managerEmail: string;
  contractor: string;
  startDate: string | null;
  endDate: string | null;
  projectValue: number;
  budget: number;
  surveyRef: string;
  version: string;
  versionDate: string | null;
  status: 'Planned' | 'In Progress' | 'On Hold' | 'Completed' | 'Closed';
  progress: number;
  description: string;
  currency: string;
  sourceQuotationId: string | null;
  sourceQuotationNo: string;
  sourceBOQId: string | null;
}

export interface ProjectDetailApiResponse {
  project: ProjectApiModel;
  phases: ProjectPhaseApi[];
  tasks: ProjectTaskApi[];
  scopeItems: ProjectScopeItemApi[];
  deliverables: ProjectDeliverableApi[];
  budget: ProjectBudgetApi;
  paymentSchedule: Array<{ id: string; name: string; amount: number; type: 'advance' | 'balance' | 'custom'; dueDate: string | null; status: 'Paid' | 'Pending' }>;
  teamMembers: string[];
}

function payload<T>(response: any): T {
  return (response?.data?.data ?? response?.data ?? {}) as T;
}

export async function listProjects(query: ProjectApiQuery = {}) {
  const response = await api.get('/projects', { params: query });
  return payload<{ data: ProjectApiModel[]; pagination: any }>(response);
}

export async function getProject(projectId: string) {
  const response = await api.get(`/projects/${encodeURIComponent(projectId)}`);
  return payload<ProjectDetailApiResponse>(response);
}

export async function updateProject(projectId: string, updates: Record<string, unknown>) {
  const response = await api.patch(`/projects/${encodeURIComponent(projectId)}`, updates);
  return payload<ProjectApiModel>(response);
}

export async function updateProjectStatus(projectId: string, status: string) {
  const response = await api.patch(`/projects/${encodeURIComponent(projectId)}/status`, { status });
  return payload<ProjectApiModel>(response);
}

export async function createPhase(projectId: string, data: { name: string; description?: string; estimatedHours?: number }) {
  const response = await api.post(`/projects/${encodeURIComponent(projectId)}/phases`, data);
  return payload<ProjectPhaseApi>(response);
}

export async function addScopeItem(projectId: string, data: { type: 'inScope' | 'outOfScope'; text: string; completed?: boolean }) {
  const response = await api.post(`/projects/${encodeURIComponent(projectId)}/scope`, data);
  return payload<ProjectScopeItemApi>(response);
}

export async function updateScopeItem(projectId: string, scopeId: string, data: Partial<ProjectScopeItemApi>) {
  const response = await api.patch(`/projects/${encodeURIComponent(projectId)}/scope/${encodeURIComponent(scopeId)}`, data);
  return payload<ProjectScopeItemApi>(response);
}

export async function deleteScopeItem(projectId: string, scopeId: string) {
  await api.delete(`/projects/${encodeURIComponent(projectId)}/scope/${encodeURIComponent(scopeId)}`);
}

export async function addDeliverable(projectId: string, data: { name: string; dueDate?: string | null; completed?: boolean }) {
  const response = await api.post(`/projects/${encodeURIComponent(projectId)}/deliverables`, data);
  return payload<ProjectDeliverableApi>(response);
}

export async function updateDeliverable(projectId: string, deliverableId: string, data: Partial<ProjectDeliverableApi>) {
  const response = await api.patch(`/projects/${encodeURIComponent(projectId)}/deliverables/${encodeURIComponent(deliverableId)}`, data);
  return payload<ProjectDeliverableApi>(response);
}

export async function deleteDeliverable(projectId: string, deliverableId: string) {
  await api.delete(`/projects/${encodeURIComponent(projectId)}/deliverables/${encodeURIComponent(deliverableId)}`);
}

export async function listTasks(projectId: string) {
  const response = await api.get('/tasks', { params: { projectId } });
  return payload<{ data: ProjectTaskApi[]; pagination: any }>(response);
}

export async function createTask(data: Record<string, unknown>) {
  const response = await api.post('/tasks', data);
  return payload<ProjectTaskApi>(response);
}

export async function updateTask(taskId: string, data: Record<string, unknown>) {
  const response = await api.patch(`/tasks/${encodeURIComponent(taskId)}`, data);
  return payload<ProjectTaskApi>(response);
}

export async function deleteTask(taskId: string) {
  await api.delete(`/tasks/${encodeURIComponent(taskId)}`);
}

export async function getBudget(projectId: string) {
  const response = await api.get(`/budgets/project/${encodeURIComponent(projectId)}`);
  return payload<ProjectBudgetApi>(response);
}
