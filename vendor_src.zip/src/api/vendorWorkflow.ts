import api from './axios';

export type VendorQuotation = {
  id: string; quotationNo: string; boqId: string | null; boqReference: string;
  vendorId: string; vendorName: string; vendorEmail: string; projectTitle: string;
  projectLocation: string; currency: string; status: string; statusLabel: string;
  rejectionStage?: string | null; rejectionReason?: string; formIssuedAt?: string | null;
  formSubmittedAt?: string | null; formApprovedAt?: string | null; submittedAt?: string | null;
  grandTotal: number; subtotal: number; taxTotal: number; otherCharges: number;
  survey?: { id: string; status: string; statusLabel: string; response: Record<string, unknown>; templateSnapshot?: Record<string, unknown> | null; revision?: number } | null;
  lines: Array<{ id: string; boqLineId: string | null; description: string; unit: string; quantity: number; masterRate?: number; quotedRate: number; taxRate: number; lineSubtotal: number; lineTax: number; lineTotal: number; module: string; category: string }>;
};

type Envelope<T> = { success?: boolean; message?: string; data?: T; pagination?: { page:number; limit:number; total:number; totalPages:number } };
const ensure = <T>(r: { data?: Envelope<T> }, fallback: string): T => {
  if (r.data?.success === false) throw new Error(r.data.message || fallback);
  if (r.data?.data === undefined) throw new Error(fallback);
  return r.data.data as T;
};
export async function listVendorQuotations(params: Record<string, unknown> = {}) {
  const r = await api.get<Envelope<VendorQuotation[]>>('/vendor-portal/quotations', { params });
  return { data: Array.isArray(r.data?.data) ? r.data.data : [], pagination: r.data?.pagination };
}
export async function getVendorQuotation(id: string) { return ensure<VendorQuotation>(await api.get<Envelope<VendorQuotation>>(`/vendor-portal/quotations/${encodeURIComponent(id)}`), 'Unable to load quotation.'); }
export async function saveVendorSurvey(id: string, response: Record<string, unknown>, revision?: number) { return ensure<VendorQuotation>(await api.put<Envelope<VendorQuotation>>(`/vendor-portal/quotations/${encodeURIComponent(id)}/survey`, { response, revision }), 'Unable to save survey.'); }
export async function submitVendorSurvey(id: string) { return ensure<VendorQuotation>(await api.post<Envelope<VendorQuotation>>(`/vendor-portal/quotations/${encodeURIComponent(id)}/survey/submit`, {}), 'Unable to submit survey.'); }
export async function updateVendorQuotation(id: string, payload: Record<string, unknown>) { return ensure<VendorQuotation>(await api.put<Envelope<VendorQuotation>>(`/vendor-portal/quotations/${encodeURIComponent(id)}`, payload), 'Unable to save quotation.'); }
export async function submitVendorQuotation(id: string) { return ensure<VendorQuotation>(await api.post<Envelope<VendorQuotation>>(`/vendor-portal/quotations/${encodeURIComponent(id)}/submit`, {}), 'Unable to submit quotation.'); }

export type VendorInvoice = { id: string; invoiceNo: string; project: string; quotationNo: string; amount: number; currency: string; dueDate: string; invoiceDate: string; status: string; statusLabel: string; rejectionRemarks: string; };
export async function listVendorInvoices(params: Record<string, unknown> = {}) {
  const r = await api.get<Envelope<VendorInvoice[]>>('/vendor-portal/invoices', { params });
  return { data: Array.isArray(r.data?.data) ? r.data.data : [], pagination: r.data?.pagination };
}
export async function getVendorInvoice(id: string) { return ensure<VendorInvoice>(await api.get<Envelope<VendorInvoice>>(`/vendor-portal/invoices/${encodeURIComponent(id)}`), 'Unable to load invoice.'); }
export async function createVendorInvoice(payload: Record<string, unknown>) { return ensure<VendorInvoice>(await api.post<Envelope<VendorInvoice>>('/vendor-portal/invoices', payload), 'Unable to create invoice.'); }
export async function updateVendorInvoice(id: string, payload: Record<string, unknown>) { return ensure<VendorInvoice>(await api.patch<Envelope<VendorInvoice>>(`/vendor-portal/invoices/${encodeURIComponent(id)}`, payload), 'Unable to save invoice.'); }
export async function submitVendorInvoice(id: string) { return ensure<VendorInvoice>(await api.post<Envelope<VendorInvoice>>(`/vendor-portal/invoices/${encodeURIComponent(id)}/submit`, {}), 'Unable to submit invoice.'); }

export type VendorProject = { id: string; reference: string; projectName?: string; name?: string; location?: string; status: string; progress: number; projectValue: number; currency: string; vendor?: { vendorId: string; name: string }; };
export async function listVendorProjects(params: Record<string, unknown> = {}) { const r = await api.get<Envelope<VendorProject[]>>('/vendor-portal/projects', { params }); return { data: Array.isArray(r.data?.data) ? r.data.data : [], pagination: r.data?.pagination }; }
export async function getVendorProject(id: string) { return ensure<VendorProject>(await api.get<Envelope<VendorProject>>(`/vendor-portal/projects/${encodeURIComponent(id)}`), 'Unable to load project.'); }

export type VendorTask = { id: string; reference: string; title: string; description: string; projectId: string | null; project: string; projectReference: string; phase: string; startDate: string; dueDate: string; priority: string; status: string; progress: number; estimatedHours: number; };
export async function listVendorTasks(params: Record<string, unknown> = {}) { const r = await api.get<Envelope<VendorTask[]>>('/vendor-portal/tasks', { params }); return { data: Array.isArray(r.data?.data) ? r.data.data : [], pagination: r.data?.pagination }; }
export async function getVendorTask(id: string) { return ensure<VendorTask>(await api.get<Envelope<VendorTask>>(`/vendor-portal/tasks/${encodeURIComponent(id)}`), 'Unable to load task.'); }
