import api from "./axios";

export type InvoiceStatus = "Draft" | "Submitted" | "Approved" | "Rejected" | "Paid" | "Overdue";

function unwrap(response: any) {
    return response?.data?.data ?? response?.data ?? null;
}

export async function listInvoices(params: Record<string, any> = {}) {
    const response = await api.get("/invoices", { params });
    return response.data as { success: boolean; data: any[]; pagination?: any };
}

export async function getInvoice(id: string) {
    return unwrap(await api.get(`/invoices/${id}`));
}

export async function listAvailableInvoiceQuotations(params: Record<string, any> = {}) {
    const response = await api.get("/invoices/available-quotations", { params });
    return response.data as { success: boolean; data: any[]; pagination?: any };
}

export async function getInvoiceCreationContext(quotationId: string) {
    return unwrap(await api.get(`/invoices/quotations/${quotationId}/context`));
}

function toFormData(payload: Record<string, any>, document?: File | null) {
    const form = new FormData();
    Object.entries(payload).forEach(([key, value]) => {
        if (value === undefined || value === null) return;
        if (Array.isArray(value)) {
            value.forEach((item) => form.append(`${key}[]`, String(item)));
            return;
        }
        form.append(key, String(value));
    });
    if (document) form.append("documents", document, document.name);
    return form;
}

export async function createInvoice(payload: Record<string, any>, document?: File | null) {
    return unwrap(await api.post("/invoices", toFormData(payload, document), {
        headers: { "Content-Type": "multipart/form-data" },
    }));
}

export async function updateInvoice(id: string, payload: Record<string, any>, document?: File | null) {
    return unwrap(await api.patch(`/invoices/${id}`, toFormData(payload, document), {
        headers: { "Content-Type": "multipart/form-data" },
    }));
}

export async function submitInvoice(id: string) {
    return unwrap(await api.post(`/invoices/${id}/submit`));
}

export async function approveInvoice(id: string, remarks = "") {
    return unwrap(await api.post(`/invoices/${id}/approve`, { remarks }));
}

export async function rejectInvoice(id: string, remarks: string) {
    return unwrap(await api.post(`/invoices/${id}/reject`, { remarks }));
}

export async function deleteInvoice(id: string) {
    return unwrap(await api.delete(`/invoices/${id}`));
}

export async function recordPayment(payload: Record<string, any>, documents: File[]) {
    const form = new FormData();
    Object.entries(payload).forEach(([key, value]) => {
        if (value === undefined || value === null) return;
        form.append(key, String(value));
    });
    documents.forEach((file) => form.append("proof", file, file.name));
    return unwrap(await api.post("/payments", form, { headers: { "Content-Type": "multipart/form-data" } }));
}
