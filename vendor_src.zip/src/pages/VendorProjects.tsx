import { Outlet } from 'react-router-dom';
import { useState } from 'react';
import ProjectList from '../components/projects/project_list';
import type { Project, ActivityLog } from '../components/projects/project';

/**
 * Vendor project shell using the exact project list UI from the admin panel.
 * Vendor-scoped project API integration is deliberately separated for the
 * next implementation phase because the supplied backend project controller
 * is not yet vendor-scoped/fully implemented.
 */
export default function VendorProjects() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

    const updateProject = (projectId: string, changes: Partial<Project>) => {
        setProjects((current) => current.map((project) => (
            project.id === projectId ? { ...project, ...changes } : project
        )));
    };

    const addActivityLog = (entry: Omit<ActivityLog, 'id' | 'createdAt'>) => {
        setActivityLogs((current) => [
            {
                ...entry,
                id: `VENDOR-ACT-${Date.now()}`,
                createdAt: new Date().toISOString(),
            },
            ...current,
        ]);
    };

    return (
        <Outlet context={{ projects, updateProject, activityLogs, addActivityLog }} />
    );
}

export function VendorProjectList() {
    return <ProjectList />;
}
