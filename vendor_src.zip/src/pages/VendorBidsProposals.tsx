import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BidsAndProposals from '../components/quotations/Bids&Proposal';
import QuotationDashboard from '../components/quotations/QuotationDashboard';
import QuotationDetails from '../components/quotations/QuotationDetails';
import type { Quotation } from '../types/quotation';
import { listVendorQuotations, toVendorQuotationView } from '../api/quotationApi';

export default function VendorBidsProposals() {
    const navigate = useNavigate();
    const [quotations, setQuotations] = useState<Quotation[]>([]);
    const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
    const [loading, setLoading] = useState(true);

    const loadQuotations = async () => {
        setLoading(true);
        try {
            const response = await listVendorQuotations({ page: 1, limit: 200, sortBy: 'updatedAt', sortOrder: 'desc' });
            setQuotations((response.data || []).map(toVendorQuotationView) as Quotation[]);
        } catch (error: any) {
            console.error('Failed to load vendor quotations', error);
            setQuotations([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        void loadQuotations();
    }, []);

    const stats = useMemo(() => ({
        total: quotations.length,
        pending: quotations.filter((q) => q.status === 'Form Submitted' || q.status === 'Submitted').length,
        approved: quotations.filter((q) => q.status === 'Form Approved' || q.status === 'Awarded').length,
        approvedValue: quotations.filter((q) => q.status === 'Awarded').reduce((sum, q) => sum + Number(q.grandTotal || 0), 0),
    }), [quotations]);

    if (selectedQuotation) {
        return (
            <QuotationDetails
                quotation={selectedQuotation}
                onBack={() => {
                    setSelectedQuotation(null);
                    void loadQuotations();
                }}
            />
        );
    }

    return (
        <div className="min-h-screen">
            <div className="mb-6">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">Bids &amp; Proposals</h1>
                <p className="mt-1 text-sm text-slate-500">Vendor quotations, bid submissions and proposal status tracking.</p>
            </div>

            <QuotationDashboard total={stats.total} pending={stats.pending} approved={stats.approved} approvedValue={stats.approvedValue} />

            {loading ? (
                <div className="mt-5 rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading quotations...</div>
            ) : (
                <BidsAndProposals
                    quotations={quotations}
                    onView={(quotation) => setSelectedQuotation(quotation)}
                />
            )}
        </div>
    );
}
