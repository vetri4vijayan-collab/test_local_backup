import PerfectScrollbar from 'react-perfect-scrollbar';
import { useDispatch, useSelector } from 'react-redux';
import { NavLink, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { BuildingOfficeIcon, CaretDoubleLeftIcon, ClipboardTextIcon, FileTextIcon, FolderIcon, GearSixIcon, HouseSimpleIcon, ListChecksIcon, UsersIcon, BellIcon } from '@phosphor-icons/react';
import { toggleSidebar } from '../../store/themeConfigSlice';
import { IRootState } from '../../store';
import { favIcon } from '../../assets/image';

interface MenuItem {
    label: string;
    icon: React.ElementType;
    url: string;
    matchPaths?: string[];
}

const VendorSidebar = () => {
    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const semidark = useSelector((state: IRootState) => state.themeConfig.semidark);
    const location = useLocation();
    const dispatch = useDispatch();

    const menuItems: MenuItem[] = [
        { label: 'Vendor Dashboard', icon: HouseSimpleIcon, url: '/vendor_dashboard' },
        // { label: 'Notifications', icon: BellIcon, url: '/notifications' },
        { label: 'Quotations', icon: FileTextIcon, url: '/bids-proposals' },
        { label: 'Projects', icon: FolderIcon, url: '/projects' },
        { label: 'My Tasks', icon: ListChecksIcon, url: '/tasks' },
        { label: 'User Management', icon: UsersIcon, url: '/user_management' },
        {
            label: 'Settings',
            icon: GearSixIcon,
            url: '/settings/roles_permissions',
            matchPaths: ['/settings/roles_permissions'],
        },
    ];

    const isItemActive = (item: MenuItem) => {
        const candidates = item.matchPaths?.length ? item.matchPaths : [item.url];
        return candidates.some((path) => location.pathname === path || location.pathname.startsWith(`${path}/`));
    };

    useEffect(() => {
        if (window.innerWidth < 1024 && themeConfig.sidebar) {
            dispatch(toggleSidebar());
        }
    }, [dispatch, location.pathname, themeConfig.sidebar]);

    return (
        <div className={semidark ? 'dark' : ''}>
            <nav
                className={`sidebar fixed min-h-screen h-full top-0 bottom-0 w-[260px] shadow-[5px_0_25px_0_rgba(94,92,154,0.1)] z-50 transition-all duration-300 ${semidark ? 'text-white-dark' : ''}`}
            >
                <div className="bg-secondary dark:bg-black h-full">
                    <div className="flex justify-between items-center px-4 py-3">
                        <NavLink to="/vendor_dashboard" className="main-logo flex items-center shrink-0 bg-white rounded-xl px-4 py-1">
                            <img className="w-8 ml-[5px] flex-none" src={favIcon} alt="ARGUS" />
                            <span className="text-2xl ltr:ml-1.5 rtl:mr-1.5 font-bold align-middle text-primary lg:inline dark:text-white-light">ARGUS</span>
                        </NavLink>

                        <button
                            type="button"
                            className="collapse-icon w-5 h-5 text-white rounded-full flex items-center hover:bg-gray-500/10 dark:hover:bg-dark-light/10 dark:text-white-light transition duration-300 rtl:rotate-180"
                            onClick={() => dispatch(toggleSidebar())}
                            aria-label="Collapse sidebar"
                        >
                            <CaretDoubleLeftIcon size={20} className="m-auto" />
                        </button>
                    </div>

                    <PerfectScrollbar className="h-[calc(100vh-80px)] relative">
                        <ul className="relative font-semibold space-y-0.5 p-4 py-0">
                            {menuItems.map((item) => {
                                const { label, icon: Icon, url } = item;
                                const active = isItemActive(item);

                                return (
                                    <li className="nav-item" key={url}>
                                        <NavLink to={url} className={`nav-link group w-full ${active ? 'active' : ''}`}>
                                            <div className="flex items-center">
                                                <Icon className="group-hover:!text-white shrink-0" />
                                                <span className="ltr:pl-3 rtl:pr-3 text-slate-400 group-hover:text-white dark:text-[#506690] dark:group-hover:text-white-dark">
                                                    {label}
                                                </span>
                                            </div>
                                        </NavLink>
                                    </li>
                                );
                            })}
                        </ul>
                    </PerfectScrollbar>
                </div>
            </nav>
        </div>
    );
};

export default VendorSidebar;
