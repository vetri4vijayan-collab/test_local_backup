export { default } from "./IconSettings";
