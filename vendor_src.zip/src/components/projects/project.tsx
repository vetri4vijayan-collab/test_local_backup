import { Outlet } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { listProjects, updateProject as updateProjectApi, ProjectApiModel } from "../../api/projectApi";

export interface Project {
    id: string;
    projectName: string;
    location: string;
    vendorName: string;
    managerName: string;
    managerEmail: string;
    startDate: string;
    endDate: string;
    projectValue: number;
    budget: number;
    surveyRef: string;
    version: string;
    status: "Planned" | "In Progress" | "On Hold" | "Completed" | "Closed";
    progress: number;
    vendorId?: string | null;
    managerId?: string | null;
    client?: string;
    contractor?: string;
    description?: string;
    currency?: string;
    sourceQuotationId?: string | null;
    sourceQuotationNo?: string;
    sourceBOQId?: string | null;
    versionDate?: string | null;
}

export interface Deliverable {
    id: string;
    projectId: string;
    name: string;
    dueDate: string;
    completed: boolean;
}

export interface ActivityLog {
    id: string;
    projectId: string;
    entity: "DELIVERABLE";
    entityId: string;
    action: "ADD" | "MODIFY" | "DELETE";
    description: string;
    createdAt: string;
}

// Kept for existing non-Projects consumers that import this compatibility
// constant. The Projects menu itself no longer uses mock data.
export const PROJECT_DATA: Project[] = [
    { id: "PRJ-001", projectName: "Al Noor Commercial Tower", location: "Dubai, UAE", vendorName: "Seiretsu JA Ltd", managerName: "Sarah Johnson", managerEmail: "sarah.j@projectflow.com", startDate: "18 Aug 2026", endDate: "30 Jun 2027", projectValue: 485000, budget: 520000, status: "Planned", progress: 75, surveyRef: "Seiretsu FTTx 5.31.26", version: "v1.0 — July 19, 2026" },
    { id: "PRJ-002", projectName: "Kingston Office Renovation", location: "Kingston, Jamaica", vendorName: "Flow Jamaica", managerName: "Michael Brown", managerEmail: "michael_brown@projectflow.com", startDate: "18 Aug 2026", endDate: "30 Jun 2027", projectValue: 275000, budget: 300000, status: "In Progress", progress: 52, surveyRef: "Flow Jamaica FTTx 5.31.26", version: "v1.0 — July 25, 2026" },
    { id: "PRJ-003", projectName: "Metro Network Expansion", location: "Montego Bay, Jamaica", vendorName: "Digicel Metro Networks", managerName: "David Wilson", managerEmail: "david_wilson@projectflow.com", startDate: "18 Aug 2026", endDate: "30 Jun 2027", projectValue: 350000, budget: 375000, status: "On Hold", progress: 35, surveyRef: "Digicel Metro FTTx 5.26.26", version: "v1.0 — July 29, 2026" },
    { id: "PRJ-004", projectName: "Regional Operations Center", location: "Miami, USA", vendorName: "Global Tech Solutions", managerName: "Emily Davis", managerEmail: "sarah.j@projectflow.com", startDate: "18 Aug 2026", endDate: "30 Jun 2027", projectValue: 620000, budget: 650000, status: "Completed", progress: 100, surveyRef: "Global Tech FTTx 3.26.26", version: "v1.0 — July 03, 2026" },
    { id: "PRJ-005", projectName: "Regional Operations Center", location: "Miami, USA", vendorName: "City Council - Kingston & St. Andrew Corporation", managerName: "Emily Davis", managerEmail: "sarah.j@projectflow.com", startDate: "18 Aug 2026", endDate: "30 Jun 2027", projectValue: 620000, budget: 650000, status: "Closed", progress: 100, surveyRef: "Digicel Metro FTTx 3.24.26", version: "v1.0 — July 19, 2026" },
];

export interface ProjectsContextType {
    projects: Project[];
    loading: boolean;
    refreshProjects: () => Promise<void>;
    updateProject: (projectId: string, updates: Partial<Project>) => Promise<void>;
    activityLogs: ActivityLog[];
    addActivityLog: (activity: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => void;
}

function toProject(row: ProjectApiModel): Project {
    const formatDate = (value: string | null) => {
        if (!value) return "";
        const d = new Date(value);
        if (Number.isNaN(d.getTime())) return value;
        return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
    };
    return {
        id: row.id,
        projectName: row.projectName || row.name,
        location: row.location || "",
        vendorName: row.vendorName || "",
        managerName: row.managerName || "",
        managerEmail: row.managerEmail || "",
        startDate: formatDate(row.startDate),
        endDate: formatDate(row.endDate),
        projectValue: Number(row.projectValue) || 0,
        budget: Number(row.budget) || 0,
        surveyRef: row.surveyRef || "",
        version: row.version || "",
        status: row.status,
        progress: Number(row.progress) || 0,
        vendorId: row.vendorId,
        managerId: row.managerId,
        client: row.client,
        contractor: row.contractor,
        description: row.description,
        currency: row.currency,
        sourceQuotationId: row.sourceQuotationId,
        sourceQuotationNo: row.sourceQuotationNo,
        sourceBOQId: row.sourceBOQId,
        versionDate: row.versionDate,
    };
}

function extractRows(response: any): ProjectApiModel[] {
    const candidate = response?.data;
    if (Array.isArray(candidate)) return candidate;
    if (Array.isArray(candidate?.items)) return candidate.items;
    return [];
}

export default function Projects() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);
    const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

    const refreshProjects = useCallback(async () => {
        setLoading(true);
        try {
            const response = await listProjects({ page: 1, limit: 200 });
            setProjects(extractRows(response).map(toProject));
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        void refreshProjects().catch(() => {
            setProjects([]);
        });
    }, [refreshProjects]);

    const updateProject = useCallback(async (projectId: string, updates: Partial<Project>) => {
        const payload: Record<string, unknown> = {};
        if (updates.projectName !== undefined) payload.projectName = updates.projectName;
        if (updates.location !== undefined) payload.location = updates.location;
        if (updates.vendorName !== undefined) payload.vendorName = updates.vendorName;
        if (updates.managerName !== undefined) payload.managerName = updates.managerName;
        if (updates.endDate !== undefined) payload.endDate = updates.endDate;
        if (updates.status !== undefined) payload.status = updates.status;
        if (updates.progress !== undefined) payload.progress = updates.progress;
        if (updates.budget !== undefined) payload.budget = updates.budget;
        if (updates.projectValue !== undefined) payload.projectValue = updates.projectValue;

        const row = await updateProjectApi(projectId, payload);
        setProjects((current) => current.map((project) => project.id === projectId ? toProject(row) : project));
    }, []);

    const addActivityLog = useCallback(({ projectId, entity, entityId, action, description }: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => {
        setActivityLogs((currentLogs) => [{
            id: `ACT-${Date.now()}`,
            projectId,
            entity,
            entityId,
            action,
            description,
            createdAt: new Date().toISOString(),
        }, ...currentLogs]);
    }, []);


    return (
        <Outlet context={{ projects, loading, refreshProjects, updateProject, activityLogs, addActivityLog }} />
    );
}
