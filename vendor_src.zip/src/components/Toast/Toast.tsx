import { CheckCircleIcon, InfoIcon, XCircleIcon, XIcon } from "@phosphor-icons/react";

export type ToastState = {
    type: "success" | "error" | "info";
    message: string;
};

export function Toast({ toast, onClose }: { toast: ToastState; onClose?: () => void }) {
    if (!toast.message) return null;
    const isSuccess = toast.type === "success";
    const isError = toast.type === "error";
    return (
        <div className="pointer-events-none fixed right-4 top-4 z-[10000] w-[min(420px,calc(100vw-2rem))]">
            <div
                className={`pointer-events-auto flex items-start gap-3 rounded-xl border px-4 py-3 shadow-lg backdrop-blur-sm ${
                    isSuccess
                        ? "border-emerald-200 bg-emerald-50/95 text-emerald-700"
                        : isError
                          ? "border-red-200 bg-red-50/95 text-red-700"
                          : "border-slate-200 bg-white/95 text-slate-700"
                }`}
                role="status"
                aria-live="polite"
            >
                {isSuccess ? (
                    <CheckCircleIcon size={19} weight="duotone" className="mt-0.5 shrink-0" />
                ) : isError ? (
                    <XCircleIcon size={19} weight="duotone" className="mt-0.5 shrink-0" />
                ) : (
                    <InfoIcon size={19} weight="duotone" className="mt-0.5 shrink-0" />
                )}
                <p className="flex-1 text-xs font-semibold leading-5">{toast.message}</p>
                {onClose ? (
                    <button type="button" onClick={onClose} aria-label="Dismiss notification" className="shrink-0 rounded-md p-1 opacity-70 transition hover:bg-black/5 hover:opacity-100">
                        <XIcon size={14} weight="bold" />
                    </button>
                ) : null}
            </div>
        </div>
    );
}

export default Toast;
